// ==== CWorldKernel::helper_140001ce0  @140001ce0  [medium:callgraph-r0]  (orig: FUN_140001ce0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140001ce0(char *param_1,char *param_2,char *param_3,char *param_4,char *param_5)

{
  char cVar1;
  int iVar2;
  int _Value;
  int _Value_00;
  ulong uVar3;
  __time32_t _Var4;
  undefined8 uVar5;
  tm *ptVar6;
  longlong lVar7;
  char *pcVar8;
  undefined1 auStack_168 [32];
  undefined4 local_148;
  int local_138 [2];
  char *local_130;
  tm local_128;
  undefined8 local_100;
  _TIME_ZONE_INFORMATION local_f8;
  ulonglong local_48;
  
  local_100 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_168;
  local_130 = param_5;
  if (param_5 == (char *)0x0) {
    local_148 = 0x227;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = 0;
  }
  else {
    lVar7 = -1;
    pcVar8 = param_5;
    do {
      if (lVar7 == 0) break;
      lVar7 = lVar7 + -1;
      cVar1 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar1 != '\0');
    if (lVar7 == -2) {
      local_148 = 0x228;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar5 = 0;
    }
    else {
      *(undefined2 *)param_1 = *(undefined2 *)param_5;
      *(undefined2 *)param_2 = *(undefined2 *)(param_5 + 2);
      *(undefined2 *)param_3 = *(undefined2 *)(param_5 + 4);
      *(undefined2 *)param_4 = *(undefined2 *)(param_5 + 6);
      GetTimeZoneInformation(&local_f8);
      if (local_f8.Bias != -0x1e0) {
        uVar3 = strtoul(param_1,(char **)0x0,10);
        local_128.tm_year = uVar3 + 100;
        uVar3 = strtoul(param_2,(char **)0x0,10);
        local_128.tm_mon = uVar3 - 1;
        local_128.tm_mday = strtoul(param_3,(char **)0x0,10);
        local_128.tm_hour = strtoul(param_4,(char **)0x0,10);
        local_128.tm_min = 0;
        local_128.tm_sec = 0;
        local_128.tm_isdst = 0;
        _Var4 = _mktime32(&local_128);
        local_138[0] = _Var4 + -0x7080 + local_f8.Bias * -0x3c;
        ptVar6 = _localtime32(local_138);
        if (ptVar6 == (tm *)0x0) {
          local_148 = 0x244;
          log_InlineLogERROR(&DAT_1406d9c10);
          return 0;
        }
        iVar2 = ptVar6->tm_mon;
        _Value = ptVar6->tm_mday;
        _Value_00 = ptVar6->tm_hour;
        _itoa((ptVar6->tm_year + 0x76c) % 100,param_1,10);
        _itoa(iVar2 + 1,param_2,10);
        _itoa(_Value,param_3,10);
        _itoa(_Value_00,param_4,10);
      }
      uVar5 = 1;
    }
  }
  return uVar5;
}

// ==== CWorldKernel::helper_140005860  @140005860  [medium:callgraph-r0]  (orig: FUN_140005860)
void FUN_140005860(longlong param_1,undefined1 param_2)

{
  if (*(char *)(param_1 + 0x18) != '\0') {
    *(undefined1 *)(param_1 + 0x19) = param_2;
  }
  return;
}

// ==== CWorldKernel::helper_140015820  @140015820  [medium:callgraph-r0]  (orig: FUN_140015820)
void FUN_140015820(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x21);
  while (cVar1 == '\0') {
    FUN_140015820(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x21);
  }
  return;
}

// ==== CWorldKernel::helper_140016690  @140016690  [medium:callgraph-r0]  (orig: FUN_140016690)
void FUN_140016690(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x21);
  while (cVar1 == '\0') {
    FUN_140015820(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x21);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CWorldKernel::helper_140018030  @140018030  [medium:callgraph-r1]  (orig: FUN_140018030)
undefined8 * FUN_140018030(longlong *param_1,undefined8 *param_2,longlong *param_3,int *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  int iVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_140015f40(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(int *)(lVar3 + 0x18)) {
        FUN_140015f40(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(int *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_140015f40(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        iVar7 = *param_4;
        if (iVar7 < *(int *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x21) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x21) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x21);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x21);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x21);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x21);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x21) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x21) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          iVar7 = *param_4;
          if ((int)plVar8[3] < iVar7) {
            if (*(char *)(plVar8[2] + 0x21) != '\0') {
              FUN_140015f40(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_140015f40(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(int *)(param_3[1] + 0x18) < iVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x21) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x21);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x21);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x21);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x21);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < (int)plVar9[3])) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x21) != '\0') {
              FUN_140015f40(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_140015f40(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_1400173d0(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CWorldKernel::helper_140018880  @140018880  [medium:callgraph-r0]  (orig: FUN_140018880)
longlong FUN_140018880(longlong *param_1,int *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  int local_res8 [2];
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x21) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(int *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x21) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(int *)(puVar3 + 3))) {
    local_48 = SUB84(plVar5,0);
    uStack_44 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_40 = SUB84(puVar3,0);
    uStack_3c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_res8[0] = *param_2;
    local_38 = local_48;
    uStack_34 = uStack_44;
    uStack_30 = uStack_40;
    uStack_2c = uStack_3c;
    local_res8[1] = 0;
    puVar3 = (undefined8 *)FUN_140018030(param_1,local_28,&local_38,local_res8);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return (longlong)puVar3 + 0x1c;
}

// ==== CWorldKernel::helper_14001bd70  @14001bd70  [medium:callgraph-r1]  (orig: FUN_14001bd70)
undefined1 FUN_14001bd70(undefined4 *param_1,longlong param_2)

{
  int iVar1;
  undefined1 uVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    iVar1 = *(int *)(param_2 + 8);
    if (iVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar2 = 0;
    }
    else {
      uVar5 = FUN_14002e300();
      lVar3 = FUN_14002dc30(uVar5,iVar1);
      if (lVar3 == 0) {
        log_InlineLogERROR("CMainProcedure::ProcessOperatingUserInfoProcedure pRec is null.");
        uVar2 = 0;
      }
      else {
        lVar4 = FUN_140008520(*param_1);
        if (*(longlong *)(lVar4 + 0x1c8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar4 + 0x1c8);
        }
        FUN_1400d36d0(uVar5,lVar3);
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

// ==== CWorldKernel::helper_14001be80  @14001be80  [medium:callgraph-r1]  (orig: FUN_14001be80)
undefined8 FUN_14001be80(undefined4 *param_1,longlong param_2)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong lVar5;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    iVar1 = *(int *)(param_2 + 8);
    if (iVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar2 = 0;
    }
    else if (*(int *)(param_2 + 0xc) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_14002e300();
      puVar3 = (undefined8 *)FUN_14002dc30(uVar2,iVar1);
      uVar2 = FUN_14002e300();
      puVar4 = (undefined8 *)FUN_14002dc30(uVar2,*(undefined4 *)(param_2 + 0xc));
      if ((puVar3 == (undefined8 *)0x0) || (puVar4 == (undefined8 *)0x0)) {
        if (puVar3 != (undefined8 *)0x0) {
          (**(code **)*puVar3)(puVar3,1);
        }
        if (puVar4 != (undefined8 *)0x0) {
          (**(code **)*puVar4)(puVar4,1);
        }
        log_InlineLogERROR(
                          "CMainProcedure::ProcessOperatingMailProcedure pRecItem or pRecMail is NULL."
                          );
        uVar2 = 0;
      }
      else if (*(int *)(param_2 + 0x20) == 0) {
        log_InlineLogERROR("CMainProcedure::ProcessOperatingMailProcedure ret is 0.");
        (**(code **)*puVar3)(puVar3,1);
        (**(code **)*puVar4)(puVar4,1);
        uVar2 = 0;
      }
      else {
        lVar5 = FUN_140008520(*param_1);
        if (*(longlong *)(lVar5 + 0x180) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x180);
        }
        FUN_1400dfe30(uVar2,puVar3,puVar4);
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

// ==== CWorldKernel::helper_14001c070  @14001c070  [medium:callgraph-r1]  (orig: FUN_14001c070)
undefined1 FUN_14001c070(undefined4 *param_1,longlong param_2)

{
  undefined1 uVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    uVar4 = FUN_14002e300();
    lVar2 = FUN_14002dc30(uVar4,*(undefined4 *)(param_2 + 8));
    if (lVar2 == 0) {
      log_InlineLogERROR("CMainProcedure::ProcessCommonMailProcedure pRecMail is NULL, id:%u.");
      uVar1 = 0;
    }
    else {
      lVar3 = FUN_140008520(*param_1);
      if (*(longlong *)(lVar3 + 0x180) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar4 = 0;
      }
      else {
        uVar4 = *(undefined8 *)(lVar3 + 0x180);
      }
      FUN_1400e04d0(uVar4,lVar2);
      uVar1 = 1;
    }
  }
  return uVar1;
}

// ==== CWorldKernel::helper_14001c2a0  @14001c2a0  [medium:callgraph-r0]  (orig: FUN_14001c2a0)
undefined8 FUN_14001c2a0(undefined8 param_1,longlong param_2)

{
  int iVar1;
  undefined8 uVar2;
  
  iVar1 = *(int *)(param_2 + 4);
  if (iVar1 == 0) {
    uVar2 = FUN_14001bd70(param_1,param_2);
    return uVar2;
  }
  if (iVar1 != 1) {
    if (iVar1 != 2) {
      log_InlineLogERROR("ProcessProcedure error type[%u]");
      return 1;
    }
    uVar2 = FUN_14001c070(param_1,param_2);
    return uVar2;
  }
  uVar2 = FUN_14001be80(param_1,param_2);
  return uVar2;
}

// ==== CWorldKernel::helper_140033870  @140033870  [medium:callgraph-r3]  (orig: FUN_140033870)
longlong FUN_140033870(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *param_1,
                      basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                      *param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = (longlong)param_2 - (longlong)param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - (longlong)param_1;
    do {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                 (param_1 + lVar1),param_1);
      param_1 = param_1 + 0x28;
    } while (param_1 != param_2);
  }
  return param_3 + (lVar2 / 0x28) * 0x28;
}

// ==== CWorldKernel::helper_140033a80  @140033a80  [medium:callgraph-r3]  (orig: FUN_140033a80)
undefined8 FUN_140033a80(longlong param_1,ulonglong param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  uVar2 = 0;
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  if (param_2 != 0) {
    if (0x666666666666666 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_1400326f0();
    }
    lVar1 = FUN_140033490(param_1 + 0x10);
    *(longlong *)(param_1 + 0x18) = lVar1;
    *(longlong *)(param_1 + 0x20) = lVar1;
    lVar1 = lVar1 + param_2 * 0x28;
    *(longlong *)(param_1 + 0x28) = lVar1;
    uVar2 = CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
  }
  return uVar2;
}

// ==== CWorldKernel::helper_1400367a0  @1400367a0  [medium:callgraph-r3]  (orig: FUN_1400367a0)
void FUN_1400367a0(undefined8 param_1,
                  basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2,
                  basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  for (; param_2 != param_3; param_2 = param_2 + 0x28) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2);
  }
  return;
}

// ==== CWorldKernel::helper_140054bc0  @140054bc0  [medium:callgraph-r0]  (orig: FUN_140054bc0)
undefined8 FUN_140054bc0(void)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140073590(0x88);
  if (lVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1400736b0(lVar1);
  }
  return uVar2;
}

// ==== CWorldKernel::helper_140054eb0  @140054eb0  [medium:callgraph-r2]  (orig: FUN_140054eb0)
undefined1 * FUN_140054eb0(undefined8 *param_1)

{
  char cVar1;
  longlong lVar2;
  int iVar3;
  char *pcVar4;
  
  pcVar4 = (char *)*param_1;
  iVar3 = 0;
  DAT_140975ad8 = 0;
  if (pcVar4 != (char *)0x0) {
    cVar1 = *pcVar4;
    while( true ) {
      if (' ' < cVar1) {
        cVar1 = *pcVar4;
        lVar2 = 0;
        do {
          if (lVar2 < 0x20) {
            (&DAT_140975ad8)[lVar2] = cVar1;
            iVar3 = iVar3 + 1;
            lVar2 = lVar2 + 1;
          }
          cVar1 = pcVar4[1];
          pcVar4 = pcVar4 + 1;
        } while (' ' < cVar1);
        if (iVar3 == 0x20) {
          log_InlineLogERROR("Token exceeded %i chars, discarded.\n");
          iVar3 = 0;
        }
        (&DAT_140975ad8)[iVar3] = 0;
        *param_1 = pcVar4;
        return &DAT_140975ad8;
      }
      if (cVar1 == '\0') break;
      cVar1 = pcVar4[1];
      pcVar4 = pcVar4 + 1;
    }
  }
  return (undefined1 *)0x0;
}

// ==== CWorldKernel::helper_140055080  @140055080  [medium:callgraph-r0]  (orig: FUN_140055080)
undefined8 FUN_140055080(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  
  plVar2 = (longlong *)FUN_140006ad0(0x4e21,1);
  if (plVar2 != (longlong *)0x0) {
    lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
    if (lVar3 != 0) {
      plVar4 = (longlong *)(*(code *)((undefined8 *)*plVar2)[4])(plVar2,2);
      iVar1 = (**(code **)(*plVar4 + 0x48))(plVar4);
      if (iVar1 == 1) {
        *(undefined1 *)(param_1 + 0x1f8) = 1;
      }
      (**(code **)*plVar2)(plVar2);
      return 1;
    }
    (**(code **)*plVar2)();
  }
  return 0;
}

// ==== CWorldKernel::helper_140055110  @140055110  [medium:callgraph-r0]  (orig: FUN_140055110)
undefined8 FUN_140055110(longlong param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  if (*(longlong *)(param_1 + 0x58) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x18))();
  uVar3 = 0;
  if (uVar1 != 0) {
    do {
      iVar2 = FUN_14050c390(uVar3);
      if ((DAT_140975780 < iVar2) || ((uVar3 == 0xe && (DAT_140975784 < iVar2)))) {
        return 1;
      }
      uVar3 = uVar3 + 1;
    } while (uVar3 < uVar1);
  }
  return 0;
}

// ==== CWorldKernel::helper_1400551c0  @1400551c0  [medium:callgraph-r0]  (orig: FUN_1400551c0)
undefined8
FUN_1400551c0(longlong param_1,undefined8 param_2,int param_3,longlong param_4,int param_5)

{
  if (((param_3 != 0) && (param_4 != 0)) && (param_5 - 1U < 0x400)) {
    FUN_140075640(*(undefined4 *)(param_1 + 0x50));
    return 1;
  }
  return 0;
}

// ==== CWorldKernel::vfunc_1  @140055220  [high:rtti-vtable]  (orig: FUN_140055220)
ulonglong FUN_140055220(longlong *param_1,longlong param_2)

{
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (*(int *)(param_2 + 0x414) != -1) {
    uVar1 = (**(code **)*param_1)(param_1,*(int *)(param_2 + 0x414));
    return uVar1;
  }
  uVar1 = (*(code *)((undefined8 *)*param_1)[2])
                    (param_1,*(undefined4 *)(param_2 + 0x418),*(undefined4 *)(param_2 + 8),
                     param_2 + 0x10,*(undefined4 *)(param_2 + 0xc));
  return uVar1;
}

// ==== CWorldKernel::vfunc_0  @1400552a0  [high:rtti-vtable]  (orig: FUN_1400552a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400552a0(longlong param_1,undefined4 param_2,int param_3,void *param_4,int param_5)

{
  undefined8 uVar1;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined8 local_448;
  undefined4 local_438;
  int local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_448 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  if (param_4 == (void *)0x0) {
    log_InlineLogERROR("Error: null msg point found in CGameSocket::SendMsg.");
    uVar1 = 0;
  }
  else if (param_3 == 0) {
    log_InlineLogERROR("invalid msg type in CWorldKernel::SendMsg().");
    uVar1 = 0;
  }
  else if (param_5 + 4 < 0x401) {
    local_430 = param_5;
    local_438 = param_2;
    local_434 = param_3;
    memcpy(local_42c,param_4,(longlong)param_5);
    local_458 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x50) + 0x50))
              (*(longlong **)(param_1 + 0x50),1,0x7533,0x418);
    uVar1 = 1;
  }
  else {
    log_InlineLogERROR("Error: msg length overflow. MsgID:%u, MsgLen:%d");
    uVar1 = 0;
  }
  return uVar1;
}

// ==== CWorldKernel::helper_140055390  @140055390  [medium:callgraph-r0]  (orig: FUN_140055390)
undefined8
FUN_140055390(longlong param_1,undefined8 param_2,int param_3,longlong param_4,int param_5)

{
  if (((param_3 != 0) && (param_4 != 0)) && (param_5 - 1U < 0x400)) {
    FUN_140075e30(*(undefined4 *)(param_1 + 0x50));
    return 1;
  }
  return 0;
}

// ==== CWorldKernel::vfunc_6  @1400553f0  [high:rtti-vtable]  (orig: FUN_1400553f0)
ulonglong FUN_1400553f0(longlong param_1,longlong param_2)

{
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar1 = (**(code **)(*(longlong *)(param_1 + 8) + 0x10))
                    (param_1 + 8,*(undefined4 *)(param_2 + 0x418),*(undefined4 *)(param_2 + 8),
                     param_2 + 0x10,*(undefined4 *)(param_2 + 0xc));
  return uVar1;
}

// ==== CWorldKernel::vfunc_2  @140055450  [high:rtti-vtable]  (orig: FUN_140055450)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140055450(longlong param_1,undefined4 param_2,int param_3,void *param_4,int param_5)

{
  undefined8 uVar1;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined8 local_448;
  undefined4 local_438;
  int local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_448 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  if (param_4 == (void *)0x0) {
    log_InlineLogERROR("Error: null msg point found in CGameSocket::SendMsg.");
    uVar1 = 0;
  }
  else if (param_3 == 0) {
    log_InlineLogERROR("invalid msg type in CWorldKernel::SendNpcMsg. NPC[%u]");
    uVar1 = 0;
  }
  else {
    local_430 = param_5;
    local_438 = param_2;
    local_434 = param_3;
    memcpy(local_42c,param_4,(longlong)param_5);
    local_458 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x50) + 0x50))
              (*(longlong **)(param_1 + 0x50),1,0x7534,0x418);
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CWorldKernel::vfunc_3  @140055510  [high:rtti-vtable]  (orig: FUN_140055510)
undefined8 FUN_140055510(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  (**(code **)(**(longlong **)(param_1 + 0x50) + 0x50))
            (*(longlong **)(param_1 + 0x50),1,0x7538,0xea65,local_res10);
  return 1;
}

// ==== CWorldKernel::vfunc_7  @140055550  [high:rtti-vtable]  (orig: FUN_140055550)
ulonglong FUN_140055550(longlong param_1,undefined4 param_2,longlong param_3)

{
  ulonglong in_RAX;
  ulonglong uVar1;
  
  if (param_3 == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  *(undefined4 *)(param_3 + 0x414) = param_2;
  *(undefined4 *)(param_3 + 0x410) = 2;
  *(undefined4 *)(param_3 + 0x418) = 0;
                    /* WARNING: Could not recover jumptable at 0x00014005557f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(*(longlong *)(param_1 + 8) + 8))((longlong *)(param_1 + 8),param_3);
  return uVar1;
}

// ==== CWorldKernel::vfunc_5  @140055590  [high:rtti-vtable]  (orig: FUN_140055590)
void FUN_140055590(longlong *param_1,undefined4 param_2,longlong param_3)

{
  *(undefined4 *)(param_3 + 0x418) = param_2;
  *(undefined4 *)(param_3 + 0x410) = 2;
  *(undefined4 *)(param_3 + 0x414) = 0xffffffff;
                    /* WARNING: Could not recover jumptable at 0x0001400555b3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x30))(param_1,param_3);
  return;
}

// ==== CWorldKernel::vfunc_8  @1400555c0  [high:rtti-vtable]  (orig: FUN_1400555c0)
void FUN_1400555c0(longlong param_1,char *param_2)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  
  lVar2 = -1;
  pcVar3 = param_2;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
            (*(longlong **)(param_1 + 0x58),0,0x9c41,~(uint)lVar2,param_2);
  return;
}

// ==== CWorldKernel::helper_140055600  @140055600  [medium:callgraph-r0]  (orig: FUN_140055600)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140055600(longlong param_1,void *param_2,int param_3)

{
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined1 local_444 [1052];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  if (*(int *)(param_1 + 0xf8) == 0) {
    local_28 = local_28 & 0xffffffffffffff00;
  }
  else {
    memset((void *)((longlong)&local_448 + 1),0,0x417);
    local_448 = param_3;
    memcpy(local_444,param_2,(longlong)param_3);
    local_458 = &local_448;
    local_28 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                         (*(longlong **)(param_1 + 0x58),1,0x7570,0x418);
  }
  return local_28;
}

// ==== CWorldKernel::helper_1400556a0  @1400556a0  [medium:callgraph-r0]  (orig: FUN_1400556a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_1400556a0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 param_5)

{
  undefined1 uVar1;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1056];
  undefined2 *local_48;
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  FUN_140076510(local_468);
  local_488 = param_5;
  FUN_140076590(local_468,param_2,param_3,param_4);
  uVar1 = FUN_140055600(param_1,local_48,*local_48);
  FUN_140076560(local_468);
  return uVar1;
}

// ==== CWorldKernel::helper_140055740  @140055740  [medium:callgraph-r2]  (orig: FUN_140055740)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

longlong FUN_140055740(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
                      char *param_5)

{
  ushort uVar1;
  uint7 extraout_var;
  longlong lVar2;
  ulonglong _Size;
  undefined1 auStack_498 [32];
  undefined4 *local_478;
  ushort local_468 [2];
  undefined4 local_464;
  undefined4 local_460;
  undefined2 local_45c;
  char local_45a [18];
  undefined4 local_448;
  undefined1 local_444 [1052];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  local_468[0] = 0x20;
  local_468[1] = 0x3ea;
  local_464 = param_2;
  local_460 = param_3;
  local_45c = param_4;
  tq::SafeCopy(local_45a,param_5,0x10);
  uVar1 = local_468[0];
  lVar2 = (ulonglong)extraout_var << 8;
  _Size = (ulonglong)local_468[0];
  if (*(int *)(param_1 + 0xf8) != 0) {
    memset((void *)((longlong)&local_448 + 1),0,0x417);
    local_448 = (uint)uVar1;
    memcpy(local_444,local_468,_Size);
    local_478 = &local_448;
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                      (*(longlong **)(param_1 + 0x58),1,0x7570,0x418);
  }
  return lVar2;
}

// ==== CWorldKernel::helper_140055820  @140055820  [medium:callgraph-r0]  (orig: FUN_140055820)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140055820(longlong param_1,undefined4 param_2,undefined1 param_3)

{
  undefined8 uVar1;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined2 local_448;
  undefined2 uStack_446;
  undefined4 uStack_444;
  undefined4 local_440;
  undefined4 local_438;
  undefined8 local_434;
  undefined4 local_42c;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  local_440 = CONCAT31(local_440._1_3_,param_3);
  local_448 = 0xc;
  uStack_446 = 0x4b0;
  if (*(int *)(param_1 + 0xf8) == 0) {
    uVar1 = 0x400;
  }
  else {
    uStack_444 = param_2;
    memset((void *)((longlong)&local_438 + 1),0,0x417);
    local_458 = &local_438;
    local_434 = CONCAT44(uStack_444,CONCAT22(uStack_446,local_448));
    local_438 = 0xc;
    local_42c = local_440;
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                      (*(longlong **)(param_1 + 0x58),1,0x7570,0x418);
  }
  return uVar1;
}

// ==== CWorldKernel::helper_1400559b0  @1400559b0  [medium:callgraph-r2]  (orig: FUN_1400559b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

longlong FUN_1400559b0(longlong param_1,char *param_2,undefined4 param_3,undefined1 param_4)

{
  ushort uVar1;
  uint7 extraout_var;
  longlong lVar2;
  ulonglong _Size;
  undefined1 auStack_5a8 [32];
  undefined4 *local_588;
  ushort local_578 [2];
  char local_574 [32];
  undefined4 local_554;
  undefined1 local_550;
  undefined4 local_448;
  undefined1 local_444 [1052];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_5a8;
  local_578[0] = 300;
  local_578[1] = 0x519;
  tq::SafeCopy(local_574,param_2,0x20);
  uVar1 = local_578[0];
  lVar2 = (ulonglong)extraout_var << 8;
  _Size = (ulonglong)local_578[0];
  if (*(int *)(param_1 + 0xf8) != 0) {
    local_554 = param_3;
    local_550 = param_4;
    memset((void *)((longlong)&local_448 + 1),0,0x417);
    local_448 = (uint)uVar1;
    memcpy(local_444,local_578,_Size);
    local_588 = &local_448;
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                      (*(longlong **)(param_1 + 0x58),1,0x7570,0x418);
  }
  return lVar2;
}

// ==== CWorldKernel::helper_140055b70  @140055b70  [medium:callgraph-r0]  (orig: FUN_140055b70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140055b70(longlong param_1)

{
  uint uVar1;
  undefined1 uVar2;
  longlong lVar3;
  uint *puVar4;
  undefined4 *puVar5;
  undefined1 auStack_498 [32];
  int local_478 [3];
  undefined4 local_46c;
  undefined4 local_468;
  undefined4 local_464;
  undefined4 local_460;
  undefined8 local_458;
  undefined1 local_448 [16];
  undefined1 local_438 [1040];
  undefined2 *local_28;
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  lVar3 = FUN_140054e10();
  uVar1 = *(uint *)(lVar3 + 0x68);
  puVar4 = (uint *)MaxPlayerGet();
  local_478[0] = (uVar1 / *puVar4) * 100;
  local_478[1] = 0;
  lVar3 = FUN_140054e10();
  local_478[2] = *(undefined4 *)(lVar3 + 0x68);
  puVar5 = (undefined4 *)MaxPlayerGet();
  local_46c = *puVar5;
  local_468 = *(undefined4 *)(param_1 + 300);
  local_464 = *(undefined4 *)(param_1 + 500);
  local_460 = 0;
  FUN_140076770(local_448);
  FUN_1400767f0(local_448,1,7,local_478);
  uVar2 = FUN_140055600(param_1,local_438,*local_28);
  FUN_1400767c0(local_448);
  return uVar2;
}

// ==== CWorldKernel::helper_140055c60  @140055c60  [medium:callgraph-r1]  (orig: FUN_140055c60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_140055c60(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 uVar1;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined4 local_464;
  undefined4 local_460;
  undefined8 local_458;
  undefined1 local_448 [16];
  undefined1 local_438 [1040];
  undefined2 *local_28;
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  local_468 = param_2;
  local_464 = param_3;
  local_460 = param_4;
  FUN_140076770(local_448);
  FUN_1400767f0(local_448,2,3,&local_468);
  uVar1 = FUN_140055600(param_1,local_438,*local_28);
  FUN_1400767c0(local_448);
  return uVar1;
}

// ==== CWorldKernel::helper_140055d00  @140055d00  [medium:callgraph-r0]  (orig: FUN_140055d00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140055d00(longlong param_1)

{
  char cVar1;
  undefined1 uVar2;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [16];
  undefined1 local_448 [1040];
  undefined2 *local_38;
  ulonglong local_18;
  
  local_468 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  FUN_140076930(local_458);
  cVar1 = FUN_140076a20(local_458,1,param_1 + 0xfc,0);
  if (cVar1 == '\0') {
    local_478 = 0x579;
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_1400769b0(local_458);
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_140055600(param_1,local_448,*local_38);
    FUN_1400769b0(local_458);
  }
  return uVar2;
}

// ==== CWorldKernel::helper_140055dd0  @140055dd0  [medium:callgraph-r1]  (orig: FUN_140055dd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140055dd0(longlong *param_1,longlong param_2)

{
  short sVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  undefined1 auStack_5a8 [32];
  undefined4 local_588;
  CStringPacker local_578 [24];
  undefined8 local_560;
  undefined1 local_558 [16];
  undefined1 local_548 [1040];
  undefined2 *local_138;
  char local_118;
  undefined1 local_117 [255];
  ulonglong local_18;
  
  local_560 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_5a8;
  if (param_2 == 0) {
    local_588 = 0x638;
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pMobileString",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.cpp"
                      );
  }
  else {
    sVar1 = *(short *)(param_2 + 8);
    if (sVar1 == 2) {
      local_118 = '\0';
      memset(local_117,0,0xff);
      tq::CStringPacker::CStringPacker(local_578);
      tq::CStringPacker::SetBuf(local_578,(char *)(param_2 + 10),0x3f5,false);
      tq::CStringPacker::GetString(local_578,0,&local_118,0x100);
      uVar4 = FUN_140076f20(param_1,&local_118);
      FUN_140076930(local_558);
      cVar3 = FUN_140076b70(local_558,3,uVar4);
      if (cVar3 == '\0') {
        local_588 = 0x646;
        log_InlineLogERROR(&DAT_1406d9c10,"CHECK",
                           "msgStringA.Create(CMsgMobileString_A::STRGSACT_AUTH_CHALLENGE_REP, dwHash)"
                           ,
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.cpp"
                          );
        FUN_1400769b0(local_558);
        tq::CStringPacker::~CStringPacker(local_578);
      }
      else {
        FUN_140055600(param_1,local_548,*local_138);
        FUN_1400769b0(local_558);
        tq::CStringPacker::~CStringPacker(local_578);
      }
    }
    else if (sVar1 == 4) {
      DAT_1409757c4 = 1;
      *(undefined4 *)(param_1 + 0x1f) = 3;
      (**(code **)(*param_1 + 0x40))(param_1,"Mobile Account server login OK.");
    }
    else if ((sVar1 == 5) && (iVar2 = *(int *)(param_2 + 4), iVar2 != 0)) {
      local_118 = '\0';
      memset(local_117,0,0xff);
      tq::CStringPacker::CStringPacker(local_578);
      tq::CStringPacker::SetBuf(local_578,(char *)(param_2 + 10),0x3f5,false);
      tq::CStringPacker::GetString(local_578,0,&local_118,0x100);
      uVar5 = FUN_140054e10();
      FUN_14006ffe0(uVar5,iVar2,&local_118);
      tq::CStringPacker::~CStringPacker(local_578);
    }
  }
  return;
}

// ==== CWorldKernel::helper_140056030  @140056030  [medium:callgraph-r2]  (orig: FUN_140056030)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140056030(longlong param_1,undefined2 param_2,undefined4 param_3,uint param_4,void *param_5
                  )

{
  longlong *plVar1;
  undefined1 auStack_498 [32];
  undefined2 *local_478;
  undefined2 local_468;
  undefined4 local_464;
  undefined8 local_460;
  undefined2 local_458;
  undefined4 local_454;
  uint local_450;
  undefined1 local_44c [1044];
  ulonglong local_38;
  
  local_460 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  plVar1 = *(longlong **)(param_1 + 0x58);
  local_468 = param_2;
  local_464 = param_3;
  if (plVar1 == (longlong *)0x0) {
    local_478 = (undefined2 *)CONCAT44(local_478._4_4_,0x6aa);
    tq::MyLogSave("gmlog/cheater","ProcessTQPCheat failed, pPort == NULL, idUser(%u), at %s, %d");
  }
  else {
    local_458 = local_458 & 0xff00;
    memset((void *)((longlong)&local_458 + 1),0,0x417);
    if (param_4 < 0x40a) {
      local_458 = param_2;
      local_454 = param_3;
      local_450 = param_4;
      memcpy(local_44c,param_5,(ulonglong)param_4);
      local_478 = &local_458;
      (**(code **)(*plVar1 + 0x50))(plVar1,0xe,0x2745,0x418);
    }
  }
  return;
}

// ==== CWorldKernel::helper_140056130  @140056130  [medium:callgraph-r1]  (orig: FUN_140056130)
void FUN_140056130(longlong *param_1,int param_2,undefined4 param_3,undefined4 param_4,
                  undefined8 param_5)

{
  if (param_2 == 0) {
    (**(code **)(*param_1 + 0x40))(param_1,"Account server login failed!");
  }
  else {
    (**(code **)(*param_1 + 0x40))(param_1,"Account server login OK.");
    FUN_140055740(param_1,param_2,param_3,param_4,param_5);
    *(undefined4 *)(param_1 + 0x1f) = 3;
    DAT_1409757c4 = 1;
  }
  return;
}

// ==== CWorldKernel::helper_1400561b0  @1400561b0  [medium:callgraph-r0]  (orig: FUN_1400561b0)
ulonglong FUN_1400561b0(longlong param_1)

{
  __time32_t _Var1;
  int iVar2;
  
  _Var1 = _time32((__time32_t *)0x0);
  iVar2 = _Var1 - *(int *)(param_1 + 0x80);
  if (iVar2 < 0x709) {
    return CONCAT71((uint7)(uint3)((uint)iVar2 >> 8),1);
  }
  if (DAT_1409756f0 < 200) {
    return (ulonglong)(*(int *)(param_1 + 0x8c) < 0xf);
  }
  if (DAT_1409756f0 < 500) {
    return (ulonglong)(*(int *)(param_1 + 0x8c) < 10);
  }
  iVar2 = 4;
  if (DAT_1409756f0 < 0x514) {
    iVar2 = 5;
  }
  return (ulonglong)(*(int *)(param_1 + 0x8c) < iVar2);
}

// ==== CWorldKernel::helper_140056240  @140056240  [medium:callgraph-r1]  (orig: FUN_140056240)
void FUN_140056240(undefined8 param_1,ulonglong param_2,int param_3)

{
  undefined8 uVar1;
  char cVar2;
  
  if (param_3 == 3) {
    FUN_140055820(param_1,param_2,3);
  }
  else if (param_3 == 4) {
    log_InlineLogMessage(&DAT_1406eb5e8);
    uVar1 = FUN_140054e10();
    cVar2 = FUN_140070190(uVar1,param_2 & 0xffffffff,"Someone is trying to log into this account!",0
                         );
    if (cVar2 == '\0') {
      FUN_140055820(param_1,param_2 & 0xffffffff,5);
      return;
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400562c0  @1400562c0  [medium:callgraph-r1]  (orig: FUN_1400562c0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1400562c0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong *plVar1;
  int iVar2;
  undefined8 uVar3;
  undefined4 *puVar4;
  undefined4 local_24;
  undefined4 local_20 [2];
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  uVar3 = FUN_140054e10();
  puVar4 = (undefined4 *)FUN_14006e620(uVar3,param_4);
  if (puVar4 != (undefined4 *)0x0) {
    plVar1 = *(longlong **)(param_1 + 0x58);
    if (plVar1 != (longlong *)0x0) {
      local_20[0] = 0;
      local_24 = 0;
      iVar2 = sscanf((char *)(puVar4 + 0x1f),"%d %u %d",local_20,&local_24);
      if (0 < iVar2) {
        local_18 = puVar4[0x18];
        local_14 = *puVar4;
        local_10 = 0;
        (**(code **)(*plVar1 + 0x50))(plVar1,puVar4[6],0x2730,0xc);
        FUN_1400559b0(param_1,param_2,param_5,1);
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400563a0  @1400563a0  [medium:callgraph-r1]  (orig: FUN_1400563a0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1400563a0(longlong param_1,uint param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong lVar3;
  
  if (param_2 == 0) {
    tq::MyLogSave("gmlog/cheater",
                  "OfflineCheatingGotoJail failed, ulAccountID == ID_NONE, at %s, %d",
                  "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.cpp",
                  0x92c);
  }
  else {
    plVar1 = *(longlong **)(param_1 + 0x58);
    if (plVar1 == (longlong *)0x0) {
      tq::MyLogSave("gmlog/cheater",
                    "OfflineCheatingGotoJail failed, pPort == NULL, idAccount(%u), at %s, %d",
                    (ulonglong)param_2,
                    "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.cpp");
    }
    else {
      uVar2 = FUN_140054e10();
      lVar3 = FUN_14006e620(uVar2,param_2);
      if (lVar3 == 0) {
        (**(code **)(*plVar1 + 0x50))(plVar1,0xe,0x273d,0xc);
      }
      else {
        (**(code **)(*plVar1 + 0x50))(plVar1,*(undefined4 *)(lVar3 + 0x18),0x273d,0xc);
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400564b0  @1400564b0  [medium:callgraph-r1]  (orig: FUN_1400564b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400564b0(longlong param_1,longlong param_2)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  undefined4 *puVar5;
  longlong lVar6;
  char *pcVar7;
  undefined1 auStack_98 [32];
  undefined4 *local_78;
  longlong local_68;
  undefined8 local_60;
  undefined4 local_58;
  int local_54;
  undefined4 local_50;
  undefined8 local_4c;
  undefined1 local_44;
  undefined8 local_43;
  undefined8 local_3b;
  undefined8 local_33;
  undefined8 local_2b;
  undefined1 local_23;
  ulonglong local_20;
  
  local_60 = 0xfffffffffffffffe;
  local_20 = DAT_1409707c0 ^ (ulonglong)auStack_98;
  local_68 = param_2;
  if (param_2 == 0) {
    local_78 = (undefined4 *)CONCAT44(local_78._4_4_,0x94e);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar2 = *(int *)(param_2 + 4);
    if (iVar2 == 0) {
      tq::MyLogSave("gmlog/cheater","ProcessGameJailEx failed, ulAccountID == ID_NONE, at %s, %d");
    }
    else {
      plVar3 = *(longlong **)(param_1 + 0x58);
      if (plVar3 == (longlong *)0x0) {
        local_78 = (undefined4 *)CONCAT44(local_78._4_4_,0x95a);
        tq::MyLogSave("gmlog/cheater",
                      "ProcessGameJailEx failed, pPort == NULL, idAccount(%u), at %s, %d");
      }
      else {
        memset(&local_58,0,0x38);
        local_58 = 0;
        local_50 = *(undefined4 *)(param_2 + 8);
        lVar6 = -1;
        pcVar7 = (char *)(param_2 + 0xc);
        do {
          if (lVar6 == 0) break;
          lVar6 = lVar6 + -1;
          cVar1 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar1 != '\0');
        if (lVar6 != -2) {
          local_4c = *(undefined8 *)(param_2 + 0xc);
          local_44 = *(undefined1 *)(param_2 + 0x14);
        }
        lVar6 = -1;
        pcVar7 = (char *)(param_2 + 0x15);
        do {
          if (lVar6 == 0) break;
          lVar6 = lVar6 + -1;
          cVar1 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar1 != '\0');
        if (lVar6 != -2) {
          local_43 = *(undefined8 *)(param_2 + 0x15);
          local_3b = *(undefined8 *)(param_2 + 0x1d);
          local_33 = *(undefined8 *)(param_2 + 0x25);
          local_2b = *(undefined8 *)(param_2 + 0x2d);
          local_23 = *(undefined1 *)(param_2 + 0x35);
        }
        local_54 = iVar2;
        uVar4 = FUN_140054e10();
        puVar5 = (undefined4 *)FUN_14006e620(uVar4,iVar2);
        if (puVar5 == (undefined4 *)0x0) {
          local_78 = &local_58;
          (**(code **)(*plVar3 + 0x50))(plVar3,0xe,0x2747,0x38);
        }
        else {
          local_58 = *puVar5;
          local_78 = &local_58;
          (**(code **)(*plVar3 + 0x50))(plVar3,puVar5[6],0x2747,0x38);
        }
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_140056690  @140056690  [medium:callgraph-r2]  (orig: FUN_140056690)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140056690(longlong param_1,uint param_2)

{
  longlong *plVar1;
  
  if (param_2 == 0) {
    tq::MyLogSave("gmlog/cheater","ProcessTempCheatJail failed, idUser == ID_NONE, at %s, %d",
                  "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.cpp",
                  0x981);
  }
  else {
    plVar1 = *(longlong **)(param_1 + 0x58);
    if (plVar1 == (longlong *)0x0) {
      tq::MyLogSave("gmlog/cheater",
                    "ProcessTempCheatJail failed, pPort == NULL, idUser(%u), at %s, %d",
                    (ulonglong)param_2,
                    "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.cpp");
    }
    else {
      (**(code **)(*plVar1 + 0x50))(plVar1,0xe,0x273e,8);
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400567f0  @1400567f0  [medium:callgraph-r0]  (orig: FUN_1400567f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1400567f0(longlong *param_1,undefined4 param_2)

{
  undefined1 uVar1;
  int iVar2;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  FUN_140077c40(local_448);
  iVar2 = FUN_140077cc0(local_448,*(undefined4 *)((longlong)param_1 + 0x1fc),(int)param_1[0x41]);
  if (iVar2 == 0) {
    FUN_140077c90(local_448);
    uVar1 = 0;
  }
  else {
    uVar1 = (**(code **)(*param_1 + 0x38))(param_1,param_2,local_448);
    FUN_140077c90(local_448);
  }
  return uVar1;
}

// ==== CWorldKernel::helper_140056960  @140056960  [medium:callgraph-r3]  (orig: FUN_140056960)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140056960(longlong param_1,undefined4 param_2,undefined4 param_3,char *param_4)

{
  char cVar1;
  ulonglong uVar2;
  char *pcVar3;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined4 local_444;
  uint local_440;
  undefined1 local_43c [1044];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  if (*(longlong *)(param_1 + 0x58) != 0) {
    uVar2 = 0xffffffffffffffff;
    pcVar3 = param_4;
    do {
      if (uVar2 == 0) break;
      uVar2 = uVar2 - 1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    memset((void *)((longlong)&local_448 + 1),0,0x417);
    local_440 = (uint)(~uVar2 - 1);
    if (local_440 < 0x40a) {
      local_448 = param_2;
      local_444 = param_3;
      memcpy(local_43c,param_4,~uVar2 - 1 & 0xffffffff);
      local_458 = &local_448;
      (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                (*(longlong **)(param_1 + 0x58),0xe,0x2743,0x418);
    }
  }
  return;
}

// ==== CWorldKernel::helper_140056a70  @140056a70  [medium:callgraph-r0]  (orig: FUN_140056a70)
undefined1 FUN_140056a70(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x203);
}

// ==== CWorldKernel::helper_140056f10  @140056f10  [medium:callgraph-r1]  (orig: FUN_140056f10)
void FUN_140056f10(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x75) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CWorldKernel::helper_140057430  @140057430  [medium:callgraph-r2]  (orig: FUN_140057430)
void FUN_140057430(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CWorldKernel::helper_140057520  @140057520  [medium:callgraph-r1]  (orig: FUN_140057520)
void FUN_140057520(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x75) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x75) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x75);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x75);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x75);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x75);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140057544. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CWorldKernel::helper_140058540  @140058540  [medium:callgraph-r0]  (orig: FUN_140058540)
undefined8 FUN_140058540(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined4 uVar1;
  longlong *plVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong *plVar5;
  
  plVar2 = (longlong *)FUN_140006ad0(50000,1,param_3,param_4,0xfffffffffffffffe);
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR("CWorldKernel::LoadGameVersionCfg, GameVersion Not Config at %s, %d");
    uVar3 = 0;
  }
  else {
    lVar4 = (**(code **)(*plVar2 + 0x40))(plVar2);
    if (lVar4 == 0) {
      log_InlineLogERROR("CWorldKernel::LoadGameVersionCfg, GameVersion Not Config at %s, %d");
      (**(code **)*plVar2)(plVar2);
      uVar3 = 0;
    }
    else {
      plVar5 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
      uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
      *(undefined4 *)(param_1 + 500) = uVar1;
      log_InlineLogMessage("Load Game Version[%d].");
      (**(code **)*plVar2)(plVar2);
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CWorldKernel::helper_140058610  @140058610  [medium:callgraph-r0]  (orig: FUN_140058610)
void FUN_140058610(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = (longlong *)FUN_140006ad0(0x226c8,1,param_3,param_4,0xfffffffffffffffe);
  if (plVar2 != (longlong *)0x0) {
    plVar3 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
    if (iVar1 != 0) {
      *(undefined1 *)(param_1 + 0x1e0) = 1;
    }
    (**(code **)*plVar2)(plVar2);
  }
  return;
}

// ==== CWorldKernel::helper_140058680  @140058680  [medium:callgraph-r1]  (orig: FUN_140058680)
void FUN_140058680(undefined8 param_1,short param_2,int param_3,ushort *param_4)

{
  ushort uVar1;
  undefined8 uVar2;
  int *piVar3;
  
  if (((param_4 != (ushort *)0x0) && (param_2 == 2)) && (uVar1 = *param_4, uVar1 != 0)) {
    if (uVar1 < 4) {
      FUN_140056690(param_1,*(undefined4 *)(param_4 + 2),uVar1);
    }
    else {
      if (uVar1 == 4) {
        FUN_140056030(param_1,4,0,param_3 + -0x16,param_4 + 6);
        return;
      }
      if (uVar1 == 5) {
        uVar2 = FUN_140054e10();
        piVar3 = (int *)FUN_14006e620(uVar2,*(undefined4 *)(param_4 + 4));
        if ((piVar3 != (int *)0x0) && (*piVar3 != 0)) {
          FUN_140056030(param_1,*param_4,*piVar3,param_3 + -0x16,param_4 + 6);
          return;
        }
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_140058750  @140058750  [medium:callgraph-r0]  (orig: FUN_140058750)
undefined4
FUN_140058750(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  plVar3 = (longlong *)FUN_140006ad0(30000,1,param_3,param_4,0xfffffffffffffffe);
  if ((plVar3 != (longlong *)0x0) && (iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3), iVar1 != 0)) {
    plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,"data1");
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    log_InlineLogMessage("Set current server as normal server, cq_config::data1 %d");
    (**(code **)*plVar3)(plVar3);
    return uVar2;
  }
  log_InlineLogMessage
            ("Table cq_config does not contain server type information. Set as normal server");
  if (plVar3 != (longlong *)0x0) {
    (**(code **)*plVar3)(plVar3);
  }
  return 0;
}

// ==== CWorldKernel::helper_140058800  @140058800  [medium:callgraph-r0]  (orig: FUN_140058800)
undefined8
FUN_140058800(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = (longlong *)FUN_140006ad0(0x15f98,1,param_3,param_4,0xfffffffffffffffe);
  if ((plVar2 != (longlong *)0x0) && (iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2), iVar1 != 0)) {
    plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,"data1");
    iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
    if (iVar1 != 0) {
      (**(code **)*plVar2)(plVar2);
      return 1;
    }
    (**(code **)*plVar2)(plVar2);
    return 0;
  }
  if (plVar2 != (longlong *)0x0) {
    (**(code **)*plVar2)(plVar2);
  }
  return 0;
}

// ==== CWorldKernel::helper_140058cb0  @140058cb0  [medium:callgraph-r1]  (orig: FUN_140058cb0)
void FUN_140058cb0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x75) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CWorldKernel::helper_140058eb0  @140058eb0  [medium:callgraph-r2]  (orig: FUN_140058eb0)
void FUN_140058eb0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CWorldKernel::helper_1400592b0  @1400592b0  [medium:callgraph-r3]  (orig: FUN_1400592b0)
void FUN_1400592b0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x75);
  while (cVar1 == '\0') {
    FUN_1400592b0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x75);
  }
  return;
}

// ==== CWorldKernel::helper_140059820  @140059820  [medium:callgraph-r3]  (orig: FUN_140059820)
void FUN_140059820(longlong param_1,longlong param_2,longlong param_3,undefined4 *param_4,
                  code *param_5)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  
  lVar4 = param_2;
  while( true ) {
    lVar3 = lVar4 * 2 + 2;
    if (param_3 <= lVar3) break;
    lVar2 = lVar3 * 0x10 + param_1;
    cVar1 = (*param_5)(lVar2,lVar2 + -0x10);
    if (cVar1 != '\0') {
      lVar3 = lVar4 * 2 + 1;
    }
    *(undefined4 *)(param_1 + lVar4 * 0x10) = *(undefined4 *)(param_1 + lVar3 * 0x10);
    *(undefined4 *)(param_1 + 4 + lVar4 * 0x10) = *(undefined4 *)(param_1 + 4 + lVar3 * 0x10);
    *(undefined4 *)(param_1 + 8 + lVar4 * 0x10) = *(undefined4 *)(param_1 + 8 + lVar3 * 0x10);
    *(undefined4 *)(param_1 + 0xc + lVar4 * 0x10) = *(undefined4 *)(param_1 + 0xc + lVar3 * 0x10);
    lVar4 = lVar3;
  }
  if (lVar3 == param_3) {
    *(undefined4 *)(param_1 + lVar4 * 0x10) = *(undefined4 *)(param_1 + -0x10 + param_3 * 0x10);
    *(undefined4 *)(param_1 + 4 + lVar4 * 0x10) = *(undefined4 *)(param_1 + -0xc + param_3 * 0x10);
    *(undefined4 *)(param_1 + 8 + lVar4 * 0x10) = *(undefined4 *)(param_1 + -8 + param_3 * 0x10);
    *(undefined4 *)(param_1 + 0xc + lVar4 * 0x10) = *(undefined4 *)(param_1 + -4 + param_3 * 0x10);
    lVar4 = param_3 + -1;
  }
  local_28 = *param_4;
  local_24 = param_4[1];
  local_20 = param_4[2];
  local_1c = param_4[3];
  FUN_140058410(param_1,lVar4,param_2,&local_28,param_5);
  return;
}

// ==== CWorldKernel::helper_140059e90  @140059e90  [medium:callgraph-r2]  (orig: FUN_140059e90)
undefined8 *
FUN_140059e90(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             void *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x78);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    memcpy(puVar1 + 3,param_5,0x5c);
    *(undefined1 *)((longlong)puVar1 + 0x74) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x75) = 0;
  }
  return puVar1;
}

// ==== CWorldKernel::helper_14005a370  @14005a370  [medium:callgraph-r2]  (orig: FUN_14005a370)
void FUN_14005a370(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x75);
  while (cVar1 == '\0') {
    FUN_1400592b0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x75);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CWorldKernel::helper_14005a3f0  @14005a3f0  [medium:callgraph-r1]  (orig: FUN_14005a3f0)
void FUN_14005a3f0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x78);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x74) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x75) = 0;
  return;
}

// ==== CWorldKernel::helper_14005a8b0  @14005a8b0  [medium:callgraph-r2]  (orig: FUN_14005a8b0)
void FUN_14005a8b0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CWorldKernel::helper_14005aac0  @14005aac0  [medium:callgraph-r2]  (orig: FUN_14005aac0)
void * FUN_14005aac0(void *param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  void *_Dst;
  
  lVar1 = param_2 - (longlong)param_1 >> 3;
  _Dst = (void *)(param_3 + lVar1 * -8);
  if (0 < lVar1) {
    memmove_s(_Dst,lVar1 * 8,param_1,lVar1 * 8);
  }
  return _Dst;
}

// ==== CWorldKernel::helper_14005ab50  @14005ab50  [medium:callgraph-r2]  (orig: FUN_14005ab50)
void FUN_14005ab50(undefined8 *param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = *param_3;
    }
    param_1 = param_1 + 1;
  }
  return;
}

// ==== CWorldKernel::helper_14005ab90  @14005ab90  [medium:callgraph-r2]  (orig: FUN_14005ab90)
void FUN_14005ab90(undefined4 *param_1,longlong param_2,undefined4 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined4 *)0x0) {
      *param_1 = *param_3;
      param_1[1] = param_3[1];
      param_1[2] = param_3[2];
      param_1[3] = param_3[3];
    }
    param_1 = param_1 + 4;
  }
  return;
}

// ==== CWorldKernel::helper_14005ad00  @14005ad00  [medium:callgraph-r3]  (orig: FUN_14005ad00)
void FUN_14005ad00(longlong param_1,longlong param_2,longlong param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar1 = param_3 - param_1 >> 4;
  if (0x28 < lVar1) {
    lVar1 = lVar1 + 1;
    lVar2 = (longlong)(lVar1 + (ulonglong)((uint)(lVar1 >> 0x3f) & 7)) >> 3;
    lVar1 = lVar2 * 0x10 + param_1;
    FUN_1400596d0(param_1,lVar1,lVar2 * 0x20 + param_1);
    FUN_1400596d0(param_2 + lVar2 * -0x10,param_2,lVar2 * 0x10 + param_2,param_4);
    lVar3 = param_3 + lVar2 * -0x10;
    FUN_1400596d0(param_3 + lVar2 * -0x20,lVar3,param_3,param_4);
    FUN_1400596d0(lVar1,param_2,lVar3,param_4);
    return;
  }
  FUN_1400596d0();
  return;
}

// ==== CWorldKernel::helper_14005ade0  @14005ade0  [medium:callgraph-r2]  (orig: FUN_14005ade0)
void FUN_14005ade0(longlong param_1,longlong param_2,undefined8 param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  lVar3 = param_2 - param_1 >> 4;
  lVar1 = lVar3 - (param_2 - param_1 >> 0x3f) >> 1;
  if (0 < lVar1) {
    lVar2 = lVar1 * 0x10 + param_1;
    do {
      local_18 = *(undefined4 *)(lVar2 + -0x10);
      local_14 = *(undefined4 *)(lVar2 + -0xc);
      lVar1 = lVar1 + -1;
      local_10 = *(undefined4 *)(lVar2 + -8);
      local_c = *(undefined4 *)(lVar2 + -4);
      FUN_140059820(param_1,lVar1,lVar3,&local_18,param_3);
      lVar2 = lVar2 + -0x10;
    } while (0 < lVar1);
  }
  return;
}

// ==== CWorldKernel::helper_14005ae90  @14005ae90  [medium:callgraph-r2]  (orig: FUN_14005ae90)
void FUN_14005ae90(undefined4 *param_1,undefined4 *param_2,code *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  char cVar5;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  
  puVar3 = param_1;
  puVar4 = param_1;
  if (param_1 != param_2) {
    while (puVar4 = puVar4 + 4, puVar4 != param_2) {
      local_28 = *puVar4;
      local_24 = puVar4[1];
      local_20 = puVar4[2];
      local_1c = puVar4[3];
      cVar5 = (*param_3)(&local_28,param_1);
      puVar1 = puVar4;
      if (cVar5 == '\0') {
        cVar5 = (*param_3)(&local_28,puVar3);
        puVar2 = puVar3;
        while (cVar5 != '\0') {
          *puVar1 = *puVar2;
          puVar1[1] = puVar2[1];
          puVar1[2] = puVar2[2];
          puVar1[3] = puVar2[3];
          cVar5 = (*param_3)(&local_28,puVar2 + -4);
          puVar1 = puVar2;
          puVar2 = puVar2 + -4;
        }
        *puVar1 = local_28;
        puVar1[1] = local_24;
        puVar1[2] = local_20;
        puVar1[3] = local_1c;
      }
      else {
        for (; param_1 != puVar1; puVar1 = puVar1 + -4) {
          *puVar1 = puVar1[-4];
          puVar1[1] = puVar1[-3];
          puVar1[2] = puVar1[-2];
          puVar1[3] = puVar1[-1];
        }
        *param_1 = local_28;
        param_1[1] = local_24;
        param_1[2] = local_20;
        param_1[3] = local_1c;
      }
      puVar3 = puVar3 + 4;
    }
  }
  return;
}

// ==== CWorldKernel::helper_14005b090  @14005b090  [medium:callgraph-r3]  (orig: FUN_14005b090)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_14005b090(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *param_1,
             basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 0x28) {
    if (param_3 != (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_3,param_1);
    }
    param_3 = param_3 + 0x28;
  }
  return param_3;
}

// ==== CWorldKernel::helper_14005b9b0  @14005b9b0  [medium:callgraph-r2]  (orig: FUN_14005b9b0)
void FUN_14005b9b0(undefined8 *param_1,undefined4 *param_2,undefined4 *param_3,code *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  char cVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  
  puVar12 = param_2 + (((longlong)param_3 - (longlong)param_2 >> 4) -
                       ((longlong)param_3 - (longlong)param_2 >> 0x3f) >> 1) * 4;
  FUN_14005ad00(param_2,puVar12,param_3 + -4);
  puVar11 = puVar12;
  while (puVar13 = puVar11, param_2 < puVar13) {
    puVar11 = puVar13 + -4;
    cVar9 = (*param_4)(puVar11,puVar13);
    if ((cVar9 != '\0') || (cVar9 = (*param_4)(puVar13,puVar11), cVar9 != '\0')) break;
  }
  do {
    puVar12 = puVar12 + 4;
    puVar11 = puVar12;
    puVar10 = puVar13;
    if (param_3 <= puVar12) break;
    cVar9 = (*param_4)(puVar12,puVar13);
    if ((cVar9 != '\0') || (cVar9 = (*param_4)(puVar13,puVar12), cVar9 != '\0')) break;
  } while( true );
joined_r0x00014005ba73:
  puVar6 = puVar11;
  puVar5 = puVar12;
  puVar7 = puVar13;
  puVar8 = puVar10;
  puVar12 = puVar5;
  if (param_3 <= puVar6) {
joined_r0x00014005baf3:
    for (; param_2 < puVar7; puVar7 = puVar7 + -4) {
      puVar10 = puVar13 + -4;
      cVar9 = (*param_4)(puVar10,puVar8);
      puVar11 = puVar8;
      if (cVar9 == '\0') {
        cVar9 = (*param_4)(puVar8,puVar10);
        if (cVar9 != '\0') break;
        puVar11 = puVar8 + -4;
        if (puVar11 != puVar10) {
          uVar1 = *puVar11;
          uVar2 = puVar8[-3];
          uVar3 = puVar8[-2];
          uVar4 = puVar8[-1];
          *puVar11 = *puVar10;
          puVar8[-3] = puVar13[-3];
          puVar8[-2] = puVar13[-2];
          puVar8[-1] = puVar13[-1];
          *puVar10 = uVar1;
          puVar13[-3] = uVar2;
          puVar13[-2] = uVar3;
          puVar13[-1] = uVar4;
        }
      }
      puVar13 = puVar10;
      puVar8 = puVar11;
    }
    if (puVar7 == param_2) {
      if (puVar6 == param_3) {
        *param_1 = puVar8;
        param_1[1] = puVar5;
        return;
      }
      if ((puVar5 != puVar6) && (puVar8 != puVar5)) {
        uVar1 = *puVar8;
        uVar2 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        *puVar8 = *puVar5;
        puVar8[1] = puVar5[1];
        puVar8[2] = puVar5[2];
        puVar8[3] = puVar5[3];
        *puVar5 = uVar1;
        puVar5[1] = uVar2;
        puVar5[2] = uVar3;
        puVar5[3] = uVar4;
      }
      puVar12 = puVar5 + 4;
      puVar11 = puVar6 + 4;
      puVar13 = puVar7;
      puVar10 = puVar8 + 4;
      if (puVar8 != puVar6) {
        uVar1 = *puVar8;
        uVar2 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        *puVar8 = *puVar6;
        puVar8[1] = puVar6[1];
        puVar8[2] = puVar6[2];
        puVar8[3] = puVar6[3];
        *puVar6 = uVar1;
        puVar6[1] = uVar2;
        puVar6[2] = uVar3;
        puVar6[3] = uVar4;
      }
    }
    else {
      puVar13 = puVar7 + -4;
      if (puVar6 == param_3) {
        puVar10 = puVar8 + -4;
        if (puVar13 != puVar10) {
          uVar1 = *puVar13;
          uVar2 = puVar7[-3];
          uVar3 = puVar7[-2];
          uVar4 = puVar7[-1];
          *puVar13 = *puVar10;
          puVar7[-3] = puVar8[-3];
          puVar7[-2] = puVar8[-2];
          puVar7[-1] = puVar8[-1];
          *puVar10 = uVar1;
          puVar8[-3] = uVar2;
          puVar8[-2] = uVar3;
          puVar8[-1] = uVar4;
        }
        puVar12 = puVar5 + -4;
        puVar11 = puVar6;
        if (puVar10 != puVar12) {
          uVar1 = *puVar10;
          uVar2 = puVar8[-3];
          uVar3 = puVar8[-2];
          uVar4 = puVar8[-1];
          *puVar10 = *puVar12;
          puVar8[-3] = puVar5[-3];
          puVar8[-2] = puVar5[-2];
          puVar8[-1] = puVar5[-1];
          *puVar12 = uVar1;
          puVar5[-3] = uVar2;
          puVar5[-2] = uVar3;
          puVar5[-1] = uVar4;
        }
      }
      else {
        if (puVar6 != puVar13) {
          uVar1 = *puVar6;
          uVar2 = puVar6[1];
          uVar3 = puVar6[2];
          uVar4 = puVar6[3];
          *puVar6 = *puVar13;
          puVar6[1] = puVar7[-3];
          puVar6[2] = puVar7[-2];
          puVar6[3] = puVar7[-1];
          *puVar13 = uVar1;
          puVar7[-3] = uVar2;
          puVar7[-2] = uVar3;
          puVar7[-1] = uVar4;
        }
        puVar11 = puVar6 + 4;
        puVar10 = puVar8;
      }
    }
    goto joined_r0x00014005ba73;
  }
  cVar9 = (*param_4)(puVar10,puVar6);
  if (cVar9 == '\0') {
    cVar9 = (*param_4)(puVar6,puVar10);
    if (cVar9 != '\0') goto joined_r0x00014005baf3;
    puVar12 = puVar5 + 4;
    if (puVar5 != puVar6) {
      uVar1 = *puVar5;
      uVar2 = puVar5[1];
      uVar3 = puVar5[2];
      uVar4 = puVar5[3];
      *puVar5 = *puVar6;
      puVar5[1] = puVar6[1];
      puVar5[2] = puVar6[2];
      puVar5[3] = puVar6[3];
      *puVar6 = uVar1;
      puVar6[1] = uVar2;
      puVar6[2] = uVar3;
      puVar6[3] = uVar4;
    }
  }
  puVar11 = puVar6 + 4;
  goto joined_r0x00014005ba73;
}

// ==== CWorldKernel::helper_14005c6d0  @14005c6d0  [medium:callgraph-r1]  (orig: FUN_14005c6d0)
undefined8 *
FUN_14005c6d0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x2c8590b21642c83 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140059e90(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x74);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x74) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x74) = 1;
        *(undefined1 *)(lVar4 + 0x74) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x74) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x75) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x74) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x74) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x75) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x74) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x74) = 1;
        *(undefined1 *)(lVar4 + 0x74) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x74) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x75) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x74) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x74) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x75) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x74);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x74) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CWorldKernel::helper_14005cd20  @14005cd20  [medium:callgraph-r2]  (orig: FUN_14005cd20)
void * FUN_14005cd20(undefined8 param_1,void *param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = param_3 - (longlong)param_2 >> 3;
  _DstSize = lVar1 * 8;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,param_2,_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CWorldKernel::helper_14005cda0  @14005cda0  [medium:callgraph-r2]  (orig: FUN_14005cda0)
void FUN_14005cda0(undefined4 *param_1,longlong param_2,undefined8 param_3)

{
  undefined4 local_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  for (param_2 = param_2 - (longlong)param_1; 1 < param_2 >> 4; param_2 = param_2 + -0x10) {
    local_18 = *(undefined4 *)((longlong)param_1 + param_2 + -0x10);
    uStack_14 = *(undefined4 *)((longlong)param_1 + param_2 + -0xc);
    uStack_10 = *(undefined4 *)((longlong)param_1 + param_2 + -8);
    uStack_c = *(undefined4 *)((longlong)param_1 + param_2 + -4);
    *(undefined4 *)((longlong)param_1 + param_2 + -0x10) = *param_1;
    *(undefined4 *)((longlong)param_1 + param_2 + -0xc) = param_1[1];
    *(undefined4 *)((longlong)param_1 + param_2 + -8) = param_1[2];
    *(undefined4 *)((longlong)param_1 + param_2 + -4) = param_1[3];
    FUN_140059820(param_1,0,param_2 + -0x10 >> 4,&local_18,param_3);
  }
  return;
}

// ==== CWorldKernel::helper_14005ce50  @14005ce50  [medium:callgraph-r3]  (orig: FUN_14005ce50)
void FUN_14005ce50(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  FUN_14005b090(param_2,param_3,param_4,param_1 + 0x10);
  return;
}

// ==== CWorldKernel::helper_14005d0b0  @14005d0b0  [medium:callgraph-r1]  (orig: FUN_14005d0b0)
undefined8 FUN_14005d0b0(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  uint *puVar2;
  uint uVar3;
  uint *puVar4;
  longlong lVar5;
  
  if ((*(longlong *)(param_1 + 0x1d0) - *(longlong *)(param_1 + 0x1c8) & 0xfffffffffffffff8U) == 0)
  {
    return 1;
  }
  uVar3 = Ordinal_14(param_2);
  puVar4 = *(uint **)(param_1 + 0x1c8);
  if (*(uint **)(param_1 + 0x1d0) < puVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x1b0);
  while( true ) {
    puVar2 = *(uint **)(param_1 + 0x1d0);
    if (puVar2 < *(uint **)(param_1 + 0x1c8)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x1b0))) {
      _invalid_parameter_noinfo();
    }
    if (puVar4 == puVar2) {
      tq::MyLogSave("gmlog/refuseip","invalid ip [%u]");
      return 0;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(uint **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    if ((*puVar4 <= uVar3) && (uVar3 <= puVar4[1])) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(uint **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    puVar4 = puVar4 + 2;
  }
  return 1;
}

// ==== CWorldKernel::helper_14005d200  @14005d200  [medium:callgraph-r1]  (orig: FUN_14005d200)
uint FUN_14005d200(longlong param_1,undefined4 param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong *plVar3;
  uint *puVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  uint local_res8;
  
  uVar5 = Ordinal_8(param_2);
  puVar6 = *(undefined8 **)(param_1 + 0x268);
  if (*(undefined8 **)(param_1 + 0x270) < puVar6) {
    _invalid_parameter_noinfo();
  }
  puVar1 = *(undefined8 **)(param_1 + 0x270);
  plVar2 = *(longlong **)(param_1 + 0x250);
  if (puVar1 < *(undefined8 **)(param_1 + 0x268)) {
    _invalid_parameter_noinfo();
  }
  plVar3 = *(longlong **)(param_1 + 0x250);
  while( true ) {
    if ((plVar2 == (longlong *)0x0) || (plVar2 != plVar3)) {
      _invalid_parameter_noinfo();
    }
    if (puVar6 == puVar1) goto LAB_14005d2d3;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (*(undefined8 **)(lVar7 + 0x20) <= puVar6) {
      _invalid_parameter_noinfo();
    }
    puVar4 = (uint *)*puVar6;
    if (((puVar4 != (uint *)0x0) && (puVar4[1] <= uVar5)) && (uVar5 <= puVar4[2])) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (*(undefined8 **)(lVar7 + 0x20) <= puVar6) {
      _invalid_parameter_noinfo();
    }
    puVar6 = puVar6 + 1;
  }
  local_res8 = *puVar4;
  if (local_res8 == 0) {
LAB_14005d2d3:
    local_res8 = (uint)((uint3)param_2 & 0xffff);
  }
  return local_res8;
}

// ==== CWorldKernel::helper_14005d300  @14005d300  [medium:callgraph-r1]  (orig: FUN_14005d300)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14005d300(longlong param_1,undefined4 param_2,char *param_3,uint param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  uint uVar4;
  char ***_Source;
  longlong *plVar5;
  longlong lVar6;
  undefined1 auStack_a8 [32];
  undefined8 local_88;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_80 [8];
  char **local_78 [2];
  ulonglong local_68;
  ulonglong local_60;
  ulonglong local_58;
  
  local_88 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  memset(param_3,0,(ulonglong)param_4);
  uVar4 = Ordinal_8(param_2);
  plVar5 = *(longlong **)(param_1 + 0x268);
  if (*(longlong **)(param_1 + 0x270) < plVar5) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x250);
  plVar2 = *(longlong **)(param_1 + 0x270);
  if (plVar2 < *(longlong **)(param_1 + 0x268)) {
    _invalid_parameter_noinfo();
  }
  plVar3 = *(longlong **)(param_1 + 0x250);
  while( true ) {
    if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar3)) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar2) {
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar1;
    }
    if (*(longlong **)(lVar6 + 0x20) <= plVar5) {
      _invalid_parameter_noinfo();
    }
    lVar6 = *plVar5;
    if (((lVar6 != 0) && (*(uint *)(lVar6 + 4) <= uVar4)) && (uVar4 <= *(uint *)(lVar6 + 8))) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar1;
    }
    if (*(longlong **)(lVar6 + 0x20) <= plVar5) {
      _invalid_parameter_noinfo();
    }
    plVar5 = plVar5 + 1;
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_80,(char *)(lVar6 + 0xc));
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=
            (local_80,(char *)(lVar6 + 0x28));
  if (param_4 - 1 < local_68) {
    local_68 = (ulonglong)(param_4 - 1);
  }
  _Source = local_78;
  if (0xf < local_60) {
    _Source = (char ***)local_78[0];
  }
  strncpy(param_3,(char *)_Source,local_68);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_80);
  return;
}

// ==== CWorldKernel::helper_14005d470  @14005d470  [medium:callgraph-r0]  (orig: FUN_14005d470)
void FUN_14005d470(longlong *param_1)

{
  rsize_t _DstSize;
  void *_Src;
  void *_Dst;
  longlong lVar1;
  
  _Src = (void *)param_1[4];
  if (_Src < (void *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  _Dst = (void *)param_1[3];
  if ((void *)param_1[4] < _Dst) {
    _invalid_parameter_noinfo();
  }
  if ((_Dst < (void *)param_1[3]) || ((void *)param_1[4] < _Dst)) {
    _invalid_parameter_noinfo();
  }
  lVar1 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar1 == 0) || (lVar1 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != _Src) {
    lVar1 = param_1[4] - (longlong)_Src >> 3;
    _DstSize = lVar1 * 8;
    if (0 < lVar1) {
      memmove_s(_Dst,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)_Dst);
  }
  return;
}

// ==== CWorldKernel::helper_14005d530  @14005d530  [medium:callgraph-r0]  (orig: FUN_14005d530)
longlong * FUN_14005d530(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x75) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x75) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14005d68d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14005d6bc;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x75) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x75) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x75);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x75);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x75);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x75);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x75) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x75) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14005d68d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_14005c6d0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14005d6bc:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CWorldKernel::helper_14005d6e0  @14005d6e0  [medium:callgraph-r0]  (orig: FUN_14005d6e0)
undefined8 * FUN_14005d6e0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x75) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140057520(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x75) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x75) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x75) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x74);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x74);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_14005d8cc;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x75) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x75) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x75);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x75);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x75) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x75);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x75);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_14005d8cc:
  if (*(char *)((longlong)plVar5 + 0x74) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x74) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x74) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x74) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x74) = 0;
            FUN_140058cb0(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x75) == '\0') {
            if ((*(char *)(*plVar11 + 0x74) != '\x01') || (*(char *)(plVar11[2] + 0x74) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x74) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x74) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x74) = 0;
                FUN_140056f10(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x74) = *(undefined1 *)((longlong)plVar10 + 0x74);
              *(undefined1 *)((longlong)plVar10 + 0x74) = 1;
              *(undefined1 *)(plVar11[2] + 0x74) = 1;
              FUN_140058cb0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x74) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x74) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x74) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x74) = 0;
            FUN_140056f10(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x75) == '\0') {
            if ((*(char *)(plVar11[2] + 0x74) != '\x01') || (*(char *)(*plVar11 + 0x74) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x74) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x74) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x74) = 0;
                FUN_140058cb0(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x74) = *(undefined1 *)((longlong)plVar10 + 0x74);
              *(undefined1 *)((longlong)plVar10 + 0x74) = 1;
              *(undefined1 *)(*plVar11 + 0x74) = 1;
              FUN_140056f10(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x74) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x74) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CWorldKernel::helper_14005dd10  @14005dd10  [medium:callgraph-r1]  (orig: FUN_14005dd10)
void FUN_14005dd10(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140057430();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_140058eb0(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_14005cd20(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_14005cd20(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14005aac0(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_14005dfc0  @14005dfc0  [medium:callgraph-r1]  (orig: FUN_14005dfc0)
longlong * FUN_14005dfc0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14005a370(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x75) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x75) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x75);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x75);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x75);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x75);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14005d6e0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CWorldKernel::ProcessConnect  @14005e310  [high:log-string]  (orig: FUN_14005e310)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14005e310(longlong *param_1,int param_2,int param_3,char *param_4,undefined8 param_5,
                  undefined4 param_6)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined8 uVar5;
  longlong lVar6;
  IStringManager *pIVar7;
  longlong *plVar8;
  undefined1 auStack_5d8 [32];
  char *local_5b8;
  undefined8 local_5b0;
  undefined2 local_5a8;
  undefined2 local_5a0;
  undefined4 local_598;
  undefined4 local_590;
  undefined1 local_588;
  undefined8 local_578;
  longlong local_570;
  undefined1 local_568 [24];
  undefined4 local_550;
  undefined1 local_54c [100];
  undefined4 local_4e8;
  undefined4 local_4e4;
  int local_4e0;
  undefined4 local_4dc;
  undefined4 local_4d8;
  char local_4d4 [76];
  char local_488 [1088];
  ulonglong local_48;
  
  local_578 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_5d8;
  if (DAT_140975af8 == 0) {
    local_5b8 = (char *)CONCAT44(local_5b8._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar6 = DAT_140975af8;
  if (*(longlong *)(DAT_140975af8 + 0x60) == 0) {
    local_5b8 = (char *)CONCAT44(local_5b8._4_4_,0x5c);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  iVar3 = *(int *)(*(longlong *)(lVar6 + 0x60) + 0x68);
  piVar4 = (int *)MaxPlayerGet();
  if ((*piVar4 < iVar3) && (1000 < param_2)) {
    uVar5 = FUN_140054e10();
    iVar3 = FUN_14006eb00(uVar5,param_2);
    if (iVar3 == 0) {
      uVar5 = FUN_140054dc0();
      FUN_140055820(uVar5,param_2,7);
      return;
    }
  }
  lVar6 = (**(code **)(*(longlong *)param_1[0x1d] + 0x40))((longlong *)param_1[0x1d],param_2);
  if (lVar6 != 0) {
    cVar2 = FUN_1400737b0(lVar6);
    if (cVar2 != '\0') {
      cVar2 = FUN_14007c950(param_1 + 0x13,param_2);
      if (cVar2 != '\0') {
        FUN_14007a560(local_488);
        pIVar7 = theInstance();
        uVar5 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ERROR_GIVE_BACK");
        local_588 = 1;
        local_590 = 0;
        local_598 = 0;
        local_5a0 = 0;
        local_5a8 = 0x835;
        local_5b0 = CONCAT44(local_5b0._4_4_,0xffffff);
        local_5b8 = (char *)0x0;
        iVar3 = FUN_14007a620(local_488,"SYSTEM","ALLUSERS",uVar5);
        if (iVar3 != 0) {
          (**(code **)(*param_1 + 0x38))(param_1,*(undefined4 *)(lVar6 + 0x30),local_488);
        }
        uVar1 = *(undefined4 *)(lVar6 + 0x30);
        uVar5 = FUN_140054e10();
        FUN_1400674b0(uVar5,uVar1,param_2);
        (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_2);
        FUN_14007a5e0(local_488);
        return;
      }
      uVar5 = FUN_140054e10();
      iVar3 = FUN_14006eb00(uVar5,param_2);
      if ((iVar3 == 0) && (cVar2 = FUN_1400561b0(param_1), cVar2 == '\0')) {
        FUN_14007a560(local_488);
        pIVar7 = theInstance();
        uVar5 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ERROR_SERVER_BUSY");
        local_588 = 1;
        local_590 = 0;
        local_598 = 0;
        local_5a0 = 0;
        local_5a8 = 0x835;
        local_5b0 = CONCAT44(local_5b0._4_4_,0xffffff);
        local_5b8 = (char *)0x0;
        iVar3 = FUN_14007a620(local_488,"SYSTEM","ALLUSERS",uVar5);
        if (iVar3 != 0) {
          (**(code **)(*param_1 + 0x38))(param_1,*(undefined4 *)(lVar6 + 0x30),local_488);
        }
        uVar1 = *(undefined4 *)(lVar6 + 0x30);
        uVar5 = FUN_140054e10();
        FUN_1400674b0(uVar5,uVar1,param_2);
        (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_2);
        FUN_14007a5e0(local_488);
        return;
      }
      cVar2 = FUN_1400737b0(lVar6);
      if ((cVar2 != '\0') && (*(int *)(lVar6 + 0xc) == param_3)) {
        uVar1 = *(undefined4 *)(lVar6 + 0x30);
        lVar6 = FUN_140054bc0();
        local_5b0 = 0;
        local_5b8._0_4_ = 0xffffffff;
        cVar2 = FUN_1400737f0(lVar6,param_2,param_3,param_4);
        if (cVar2 == '\0') {
          local_5b8 = (char *)CONCAT44(local_5b8._4_4_,0x700);
          log_InlineLogERROR(&DAT_1406d9c10);
          return;
        }
        *(undefined4 *)(lVar6 + 0x80) = param_6;
        (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_2);
        (**(code **)(*(longlong *)param_1[0x1e] + 0x28))();
        local_4e4 = 0;
        local_4d8 = 0;
        memset(local_4d4,0,0x41);
        local_4e8 = 1;
        local_4e0 = param_2;
        local_4dc = uVar1;
        tq::SafeCopy(local_4d4,param_4,0x41);
        *(int *)(param_1 + 0x58) = (int)param_1[0x58] + 1;
        local_550 = (undefined4)param_1[0x58];
        memcpy(local_54c,&local_4e8,0x58);
        FUN_14005d530(param_1 + 0x50,local_568,&local_550);
        memset(local_488,0,0x400);
        sprintf(local_488," worlduserlogin****worlduserlogin [%u]");
        FUN_140054dc0();
        plVar8 = (longlong *)InstanceGet();
        (**(code **)(*plVar8 + 0x30))(plVar8,local_488,0,0);
        return;
      }
      cVar2 = FUN_1400737b0(lVar6);
      if ((cVar2 != '\0') && (*(int *)(lVar6 + 0xc) != param_3)) {
        local_5b0 = CONCAT44(local_5b0._4_4_,0x718);
        local_5b8 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.cpp";
        log_InlineLogERROR(
                          "CWorldKernel::ProcessConnect() checkdata error, Account: %u, dwData: %u, szInfo:%s at %s, %d"
                          );
      }
      uVar1 = *(undefined4 *)(lVar6 + 0x30);
      uVar5 = FUN_140054e10();
      FUN_1400674b0(uVar5,uVar1,param_2);
      (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_2);
      return;
    }
    (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_2);
  }
  local_570 = FUN_140073590(0x88);
  lVar6 = 0;
  if (local_570 != 0) {
    lVar6 = FUN_1400736b0(local_570);
  }
  local_5b0 = 0;
  local_5b8._0_4_ = 0xffffffff;
  cVar2 = FUN_1400737f0(lVar6,param_2,param_3,param_4);
  if (cVar2 == '\0') {
    local_5b8 = (char *)CONCAT44(local_5b8._4_4_,0x722);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    *(undefined4 *)(lVar6 + 0x80) = param_6;
    (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_2);
    (**(code **)(*(longlong *)param_1[0x1e] + 0x28))((longlong *)param_1[0x1e],lVar6);
  }
  return;
}

// ==== CWorldKernel::helper_14005e8b0  @14005e8b0  [medium:callgraph-r1]  (orig: FUN_14005e8b0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14005e8b0(longlong param_1,undefined4 param_2,uint param_3,int param_4,int param_5)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  undefined8 uVar5;
  undefined4 *puVar6;
  IStringManager *pIVar7;
  char *pcVar8;
  longlong lVar9;
  undefined1 auStack_1998 [32];
  char *local_1978;
  int local_1970;
  undefined2 local_1968;
  undefined2 local_1960;
  undefined4 local_1958;
  undefined4 local_1950;
  undefined1 local_1948;
  undefined4 local_1938;
  undefined4 local_1934;
  int local_1930;
  uint local_192c;
  int local_1928;
  undefined8 local_1920;
  undefined1 local_1918 [1088];
  undefined1 local_14d8 [1088];
  undefined1 local_1098 [1088];
  char local_c58;
  undefined1 local_c57 [255];
  char local_b58 [1024];
  undefined1 local_758;
  undefined1 local_757 [255];
  char local_658;
  undefined1 local_657 [1022];
  undefined1 local_259;
  undefined1 local_258;
  undefined1 local_257 [255];
  undefined1 local_158;
  undefined1 local_157 [255];
  ulonglong local_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x14005e8c7;
  local_1920 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_1998;
  if ((100 < param_5) && (param_5 < 0x68)) {
    return;
  }
  if (param_5 == 0x72) {
    return;
  }
  uVar5 = FUN_140054e10();
  puVar6 = (undefined4 *)FUN_14006e620(uVar5);
  if (puVar6 == (undefined4 *)0x0) {
    local_1978 = (char *)CONCAT44(local_1978._4_4_,param_5);
    log_InlineLogWARNING(&DAT_1406ec7e0);
    return;
  }
  local_b58[0] = '\0';
  memset(local_b58 + 1,0,0x3ff);
  pIVar7 = theInstance();
  pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_FEETYPE_KNOWN");
  strncpy(local_b58,pcVar8,0x3ff);
  switch(param_5) {
  case 0:
    uVar5 = FUN_140054e10();
    FUN_140070190(uVar5,param_2,&DAT_1406eca70,0);
    return;
  case 1:
    pIVar7 = theInstance();
    pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_FEETYPE_HOUR");
    local_1978 = (char *)CONCAT44(local_1978._4_4_,(param_3 >> 1) % 10);
    _snprintf(local_b58,0x3ff,pcVar8);
    break;
  case 2:
    pIVar7 = theInstance();
    pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_FEETYPE_MONTH");
    local_1978 = (char *)CONCAT44(local_1978._4_4_,(param_4 / 100) % 100);
    local_1970 = param_4 % 100;
    _snprintf(local_b58,0x3ff,pcVar8);
    break;
  case 3:
    pIVar7 = theInstance();
    pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_FEETYPE_BARHOUR");
    _snprintf(local_b58,0x3ff,pcVar8);
    break;
  case 4:
    pIVar7 = theInstance();
    pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_FEETYPE_BARMONTH");
    _snprintf(local_b58,0x3ff,pcVar8);
    break;
  case 5:
    pIVar7 = theInstance();
    pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_FEETYPE_ISP");
    _snprintf(local_b58,0x3ff,pcVar8);
    break;
  case 6:
    pIVar7 = theInstance();
    pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_FEETYPE_FREE");
    _snprintf(local_b58,0x3ff,pcVar8);
    break;
  case 100:
    uVar2 = *puVar6;
    uVar5 = FUN_140054e10();
    FUN_140067590(uVar5,uVar2,param_3);
    return;
  case 0x68:
  case 0x69:
  case 0x6a:
  case 0x6b:
    local_1938 = puVar6[0x18];
    local_1934 = *puVar6;
    local_1930 = param_5;
    local_1978 = (char *)&local_1938;
    local_192c = param_3;
    local_1928 = param_4;
    (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
              (*(longlong **)(param_1 + 0x58),puVar6[6],0x272e,0x14);
    local_1978 = (char *)CONCAT44(local_1978._4_4_,param_5);
    FUN_1400558e0(param_1,param_2,param_3,param_4);
    return;
  case 0x6c:
    local_658 = '\0';
    memset(local_657,0,0x3ff);
    switch(param_4) {
    case 0:
      _snprintf(&local_658,0x400,"Your account has been logged out by system.");
      break;
    case 1:
      uVar5 = FUN_140054dc0();
      uVar3 = FUN_14005ce90(uVar5);
      if (uVar3 != param_3) {
        local_758 = 0;
        memset(local_757,0,0xff);
        FUN_14007d430(local_1918);
        FUN_14005d300(param_1,param_3,&local_758,0x100);
        local_1978 = &local_758;
        iVar4 = FUN_14007d4b0(local_1918,0,param_2,param_3);
        if (iVar4 != 0) {
          FUN_140067420(puVar6,local_1918);
        }
        FUN_14007d480(local_1918);
      }
      Ordinal_12(param_3);
      _snprintf(&local_658,0x400,
                "Your account has been logged in! It may have been hacked! (Login IP: %s)");
      break;
    case 2:
      _snprintf(&local_658,0x400,"Your account has been logged in.");
      break;
    case 3:
      _snprintf(&local_658,0x400,"Account server denied you access to game.");
      break;
    case 4:
      _snprintf(&local_658,0x400,"Kick out for change password.");
      FUN_14007d430(local_1918);
      local_1978 = (undefined1 *)0x0;
      iVar4 = FUN_14007d4b0(local_1918,1,param_2);
      if (iVar4 != 0) {
        FUN_140067420(puVar6,local_1918);
      }
      FUN_14007d480(local_1918);
      break;
    case 5:
      _snprintf(&local_658,0x400,"GM Management: Ban & Kick!");
      break;
    case 6:
      _snprintf(&local_658,0x400,"Your account is banned by GM.");
      FUN_14007d140(local_1918);
      iVar4 = FUN_14007d2d0(local_1918,0x1b);
      if (iVar4 != 0) {
        FUN_140067420(puVar6,local_1918);
      }
      FUN_14007d1c0(local_1918);
      break;
    case 7:
    case 8:
    case 9:
      _snprintf(&local_658,0x400,"Your account has been logged out by system.");
      break;
    default:
      log_InlineLogWARNING("invalid c_typeKickout = %d");
      return;
    }
    local_259 = 0;
    FUN_14007a560(local_14d8);
    local_1948 = 1;
    local_1950 = 0;
    local_1958 = 0;
    local_1960 = 0;
    local_1968 = 2000;
    local_1970 = 0xffffff;
    local_1978 = (char *)0x0;
    iVar4 = FUN_14007a620(local_14d8,"SYSTEM",puVar6 + 1,&local_658);
    if (iVar4 != 0) {
      FUN_140067420(puVar6,local_14d8);
    }
    uVar5 = FUN_140054e10();
    FUN_140070190(uVar5,param_2,&local_658,0);
    FUN_14007a5e0(local_14d8);
    return;
  }
  FUN_14007a560(local_1098);
  local_1948 = 1;
  local_1950 = 0;
  local_1958 = 0;
  local_1960 = 0;
  local_1968 = 2000;
  local_1970 = 0xffffff;
  local_1978 = (char *)0x0;
  iVar4 = FUN_14007a620(local_1098,"SYSTEM",puVar6 + 1,local_b58);
  if (iVar4 == 0) {
    local_1978 = (char *)CONCAT44(local_1978._4_4_,0x8da);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140067420(puVar6);
  }
  memset(local_b58,0,0x400);
  local_258 = 0;
  memset(local_257,0,0xff);
  local_158 = 0;
  memset(local_157,0,0xff);
  local_c58 = '\0';
  memset(local_c57,0,0xff);
  local_1978 = &local_c58;
  iVar4 = sscanf((char *)(puVar6 + 0x1f),"%s %s %s");
  if (iVar4 < 1) {
    local_1970 = param_5;
    local_1978 = (char *)CONCAT44(local_1978._4_4_,param_4);
    log_InlineLogERROR(&DAT_1406ec880);
    FUN_14007a5e0(local_1098);
  }
  else {
    iVar4 = _stricmp(&local_c58,&DAT_1406eca70);
    if (iVar4 == 0) {
      pIVar7 = theInstance();
      pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_LOGIN_ISP_FAIL");
      tq::SafeCopy(local_b58,pcVar8,0x400);
    }
    else {
      iVar4 = _stricmp(&local_c58,"999999");
      if (iVar4 == 0) {
        pIVar7 = theInstance();
        pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ACCOUNT_NOFEE");
        tq::SafeCopy(local_b58,pcVar8,0x400);
      }
      else if ((byte)(local_c58 - 0x30U) < 10) {
        pIVar7 = theInstance();
        pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_FEW_FEE_NOTIFY");
        _snprintf(local_b58,0x3ff,pcVar8);
      }
      else {
        tq::SafeCopy(local_b58,&local_c58,0x10);
      }
    }
    lVar9 = -1;
    pcVar8 = local_b58;
    do {
      if (lVar9 == 0) break;
      lVar9 = lVar9 + -1;
      cVar1 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar1 != '\0');
    if (lVar9 != -2) {
      FUN_14007a560(local_14d8);
      local_1948 = 1;
      local_1950 = 0;
      local_1958 = 0;
      local_1960 = 0;
      local_1968 = 2000;
      local_1970 = 0xffffff;
      local_1978 = (char *)0x0;
      iVar4 = FUN_14007a620(local_14d8,"SYSTEM",puVar6 + 1,local_b58);
      if (iVar4 == 0) {
        local_1978 = (char *)CONCAT44(local_1978._4_4_,0x8ff);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_140067420(puVar6,local_14d8);
      }
      FUN_14007a5e0(local_14d8);
    }
    FUN_14007a5e0(local_1098);
  }
  return;
}

// ==== CWorldKernel::helper_14005f320  @14005f320  [medium:callgraph-r1]  (orig: FUN_14005f320)
void FUN_14005f320(longlong param_1,undefined4 param_2,undefined4 param_3,char *param_4,
                  undefined4 param_5)

{
  char *pcVar1;
  int iVar2;
  uint uVar3;
  ulong uVar4;
  ulong uVar5;
  char *pcVar6;
  undefined8 uVar7;
  IStringManager *pIVar8;
  char *pcVar9;
  longlong lVar10;
  char cVar11;
  uint uVar12;
  char *_Str2;
  char *local_res8;
  
  uVar12 = 0;
  pcVar6 = (char *)0x0;
  DAT_140975ad8 = 0;
  _Str2 = param_4;
  if (param_4 != (char *)0x0) {
    cVar11 = *param_4;
    pcVar9 = param_4;
    while (cVar11 < '!') {
      if (cVar11 == '\0') goto LAB_14005f3d9;
      pcVar1 = pcVar9 + 1;
      pcVar9 = pcVar9 + 1;
      cVar11 = *pcVar1;
    }
    cVar11 = *pcVar9;
    uVar3 = uVar12;
    do {
      if ((longlong)pcVar6 < 0x20) {
        pcVar6[0x140975ad8] = cVar11;
        uVar3 = uVar3 + 1;
        pcVar6 = pcVar6 + 1;
      }
      cVar11 = pcVar9[1];
      pcVar9 = pcVar9 + 1;
    } while (' ' < cVar11);
    if (uVar3 == 0x20) {
      local_res8 = param_4;
      log_InlineLogERROR("Token exceeded %i chars, discarded.\n");
      uVar3 = 0;
    }
    (&DAT_140975ad8)[(int)uVar3] = 0;
    _Str2 = pcVar9;
    pcVar6 = &DAT_140975ad8;
  }
LAB_14005f3d9:
  local_res8 = _Str2;
  iVar2 = _stricmp("",param_4);
  uVar3 = uVar12;
  if ((iVar2 != 0) && (*pcVar6 != '\0')) {
    iVar2 = _stricmp("vip",pcVar6);
    if (iVar2 == 0) {
      pcVar6 = (char *)FUN_140054eb0(&local_res8);
      _Str2 = local_res8;
      if ((pcVar6 != (char *)0x0) && (*pcVar6 != '\0')) {
        uVar3 = strtoul(pcVar6,(char **)0x0,10);
        _Str2 = local_res8;
      }
    }
    else {
      uVar3 = strtoul(pcVar6,(char **)0x0,10);
      pcVar6 = (char *)FUN_140054eb0(&local_res8);
      _Str2 = local_res8;
      if ((pcVar6 != (char *)0x0) && (*pcVar6 != '\0')) {
        uVar4 = strtoul(pcVar6,(char **)0x0,10);
        uVar5 = tq::TimeGet(3);
        uVar12 = (uint)((uVar5 / 10000 - (int)uVar4 / 100) + 0x76c < 0x12);
        _Str2 = local_res8;
      }
    }
  }
  if (*(char *)(param_1 + 0x200) != '\0') {
    uVar3 = 0;
  }
  uVar7 = FUN_140054e10();
  FUN_140072120(uVar7,param_2,uVar3);
  pIVar8 = theInstance();
  pcVar9 = (char *)(*(code *)**(undefined8 **)pIVar8)(pIVar8,"Language");
  iVar2 = _stricmp(pcVar9,&DAT_1406e0658);
  if (iVar2 == 0) {
    uVar7 = FUN_140054e10();
  }
  else {
    uVar7 = FUN_140054e10();
    uVar12 = 0;
  }
  FUN_140072150(uVar7,param_2,uVar12);
  iVar2 = _stricmp("",_Str2);
  lVar10 = 0;
  if (iVar2 != 0) {
    iVar2 = 0;
    DAT_140975ad8 = 0;
    if (_Str2 == (char *)0x0) {
LAB_14005f5bc:
      pcVar6 = "";
    }
    else {
      cVar11 = *_Str2;
      while (cVar11 < '!') {
        if (cVar11 == '\0') goto LAB_14005f5bc;
        pcVar6 = _Str2 + 1;
        _Str2 = _Str2 + 1;
        cVar11 = *pcVar6;
      }
      cVar11 = *_Str2;
      pcVar6 = &DAT_140975ad8;
      do {
        if (lVar10 < 0x20) {
          (&DAT_140975ad8)[lVar10] = cVar11;
          iVar2 = iVar2 + 1;
          lVar10 = lVar10 + 1;
        }
        cVar11 = _Str2[1];
        _Str2 = _Str2 + 1;
      } while (' ' < cVar11);
      if (iVar2 == 0x20) {
        log_InlineLogERROR("Token exceeded %i chars, discarded.\n");
        iVar2 = 0;
      }
      (&DAT_140975ad8)[iVar2] = 0;
    }
  }
  FUN_14005e310(param_1,param_2,param_3,pcVar6,0,param_5);
  return;
}

// ==== CWorldKernel::helper_14005f7a0  @14005f7a0  [medium:callgraph-r1]  (orig: FUN_14005f7a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_14005f7a0(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined1 param_5,undefined4 param_6)

{
  char cVar1;
  char cVar2;
  longlong lVar3;
  int iVar4;
  undefined8 uVar5;
  char *pcVar6;
  undefined1 auStack_698 [32];
  undefined8 local_678;
  undefined1 local_668 [1072];
  char local_238 [256];
  char local_138 [256];
  ulonglong local_38;
  
  local_678 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_698;
  if ((char)param_1[0x3f] == '\0') {
    local_238[0] = '\0';
    memset(local_238 + 1,0,0xfe);
    local_138[0] = '\0';
    memset(local_138 + 1,0,0xfe);
    FUN_14005d300(param_1,param_2,local_238,0xff);
    FUN_14005d300(param_1,param_3,local_138,0xff);
    pcVar6 = local_238;
    lVar3 = -(longlong)pcVar6;
    do {
      cVar1 = *pcVar6;
      cVar2 = pcVar6[(longlong)(local_138 + lVar3)];
      if (cVar1 != cVar2) break;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    FUN_14007d5f0(local_668);
    iVar4 = FUN_14007d670(local_668,param_4,param_5,cVar1 == cVar2);
    if (iVar4 == 0) {
      FUN_14007d640(local_668);
      uVar5 = 0;
    }
    else {
      (**(code **)(*param_1 + 0x38))(param_1,param_6,local_668);
      FUN_14007d640(local_668);
      uVar5 = 1;
    }
  }
  else {
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CWorldKernel::helper_14005f900  @14005f900  [medium:callgraph-r1]  (orig: FUN_14005f900)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_14005f900(longlong *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined1 auStack_588 [32];
  undefined8 local_568;
  undefined1 local_558 [1072];
  undefined1 local_128;
  undefined1 local_127 [255];
  ulonglong local_28;
  
  local_568 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_588;
  local_128 = 0;
  memset(local_127,0,0xfe);
  FUN_14005d300(param_1,param_2,&local_128,0xff);
  FUN_14007d770(local_558);
  cVar1 = FUN_14007d7f0(local_558,&local_128);
  if (cVar1 != '\0') {
    (**(code **)(*param_1 + 0x38))(param_1,param_3,local_558);
    FUN_14007d7c0(local_558);
  }
  else {
    FUN_14007d7c0(local_558);
  }
  return cVar1 != '\0';
}

// ==== CWorldKernel::helper_14005fa10  @14005fa10  [medium:callgraph-r0]  (orig: FUN_14005fa10)
void FUN_14005fa10(longlong *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  
  puVar1 = (undefined8 *)param_1[4];
  if (puVar1 < (undefined8 *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  puVar2 = (undefined8 *)param_1[3];
  if ((undefined8 *)param_1[4] < puVar2) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < puVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((puVar1 < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < puVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (puVar2 != puVar1) {
    puVar4 = (undefined8 *)param_1[4];
    if (puVar1 != puVar4) {
      puVar6 = puVar1;
      do {
        uVar5 = *puVar6;
        puVar6 = puVar6 + 1;
        *(undefined8 *)((longlong)puVar2 + (-8 - (longlong)puVar1) + (longlong)puVar6) = uVar5;
      } while (puVar6 != puVar4);
    }
    param_1[4] = (longlong)(puVar2 + ((longlong)puVar4 - (longlong)puVar1 >> 3));
  }
  return;
}

// ==== CWorldKernel::helper_14005fcc0  @14005fcc0  [medium:callgraph-r0]  (orig: FUN_14005fcc0)
void FUN_14005fcc0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14005dfc0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CWorldKernel::helper_14005fd30  @14005fd30  [medium:callgraph-r3]  (orig: FUN_14005fd30)
void FUN_14005fd30(longlong param_1,longlong param_2,ulonglong param_3,longlong *param_4)

{
  void *pvVar1;
  undefined1 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong *plVar10;
  longlong local_res8;
  
  lVar6 = *(longlong *)(param_1 + 0x18);
  if (lVar6 == 0) {
    uVar7 = 0;
  }
  else {
    uVar7 = *(longlong *)(param_1 + 0x28) - lVar6 >> 3;
  }
  if (param_3 != 0) {
    lVar3 = *(longlong *)(param_1 + 0x20);
    lVar6 = lVar3 - lVar6 >> 3;
    if (0x1fffffffffffffffU - lVar6 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1400573a0();
    }
    uVar9 = param_3 + lVar6;
    if (uVar7 < uVar9) {
      if (0x1fffffffffffffff - (uVar7 >> 1) < uVar7) {
        uVar7 = 0;
      }
      else {
        uVar7 = uVar7 + (uVar7 >> 1);
      }
      if (uVar7 < uVar9) {
        uVar7 = uVar9;
      }
      lVar3 = FUN_140058e30(param_1 + 0x10,uVar7);
      lVar6 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      local_res8._0_1_ = (undefined1)lVar3;
      uVar2 = (undefined1)local_res8;
      local_res8 = lVar3;
      FUN_14005ab50(lVar3 + lVar6 * 8,param_3,param_4,param_1 + 0x10,uVar2,0);
      FUN_140059990(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar3,
                    param_1 + 0x10,(undefined1)local_res8,0,1);
      FUN_140059990(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    lVar3 + (lVar6 + param_3) * 8,param_1 + 0x10,(undefined1)local_res8,0,2);
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar6 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(ulonglong *)(param_1 + 0x28) = lVar3 + uVar7 * 8;
      *(ulonglong *)(param_1 + 0x20) = lVar3 + (param_3 + (lVar6 - (longlong)pvVar1 >> 3)) * 8;
      *(longlong *)(param_1 + 0x18) = lVar3;
    }
    else if ((ulonglong)(lVar3 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      lVar6 = *param_4;
      local_res8._0_1_ = (undefined1)lVar6;
      uVar2 = (undefined1)local_res8;
      local_res8 = lVar6;
      FUN_140059990(*(longlong *)(param_2 + 8),lVar3,*(longlong *)(param_2 + 8) + param_3 * 8,
                    param_1 + 0x10,uVar2,0);
      FUN_14005ab50(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 3),
                    &local_res8,param_1 + 0x10,(undefined1)local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar3 = *(longlong *)(param_1 + 0x20);
      for (plVar4 = *(longlong **)(param_2 + 8); plVar4 != (longlong *)(lVar3 + param_3 * -8);
          plVar4 = plVar4 + 1) {
        *plVar4 = lVar6;
      }
    }
    else {
      lVar6 = *param_4;
      lVar8 = lVar3 + param_3 * -8;
      uVar5 = FUN_140059990(lVar8,lVar3,lVar3,param_1 + 0x10);
      *(undefined8 *)(param_1 + 0x20) = uVar5;
      FUN_14005b8a0(*(undefined8 *)(param_2 + 8),lVar8,lVar3);
      plVar10 = *(longlong **)(param_2 + 8);
      plVar4 = plVar10 + param_3;
      for (; plVar10 != plVar4; plVar10 = plVar10 + 1) {
        *plVar10 = lVar6;
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_140060010  @140060010  [medium:callgraph-r3]  (orig: FUN_140060010)
void FUN_140060010(longlong param_1,longlong param_2,ulonglong param_3,undefined4 *param_4)

{
  void *pvVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined4 *puVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  undefined4 *puVar8;
  undefined1 local_res8;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = *(longlong *)(param_1 + 0x28) - lVar4 >> 4;
  }
  if (param_3 != 0) {
    lVar2 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar2 - lVar4 >> 4;
    if (0xfffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140057630();
    }
    uVar7 = param_3 + lVar4;
    if (uVar6 < uVar7) {
      if (0xfffffffffffffff - (uVar6 >> 1) < uVar6) {
        uVar6 = 0;
      }
      else {
        uVar6 = uVar6 + (uVar6 >> 1);
      }
      if (uVar6 < uVar7) {
        uVar6 = uVar7;
      }
      lVar2 = FUN_140059080(param_1 + 0x10,uVar6);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 4;
      local_res8 = (undefined1)lVar2;
      FUN_14005ab90(lVar4 * 0x10 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_1400599d0(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_1400599d0(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar4 + param_3) * 0x10 + lVar2,param_1 + 0x10,local_res8,0,2);
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(ulonglong *)(param_1 + 0x28) = uVar6 * 0x10 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar4 - (longlong)pvVar1 >> 4)) * 0x10 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)(lVar2 - *(longlong *)(param_2 + 8) >> 4) < param_3) {
      local_38 = *param_4;
      local_34 = param_4[1];
      local_30 = param_4[2];
      local_2c = param_4[3];
      FUN_1400599d0(*(longlong *)(param_2 + 8),lVar2,*(longlong *)(param_2 + 8) + param_3 * 0x10,
                    param_1 + 0x10);
      FUN_14005ab90(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 4),
                    &local_38,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x10;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar5 = *(undefined4 **)(param_2 + 8); puVar5 != (undefined4 *)(lVar4 + param_3 * -0x10)
          ; puVar5 = puVar5 + 4) {
        *puVar5 = local_38;
        puVar5[1] = local_34;
        puVar5[2] = local_30;
        puVar5[3] = local_2c;
      }
    }
    else {
      local_38 = *param_4;
      local_34 = param_4[1];
      local_30 = param_4[2];
      local_2c = param_4[3];
      lVar4 = lVar2 + param_3 * -0x10;
      uVar3 = FUN_1400599d0(lVar4,lVar2,lVar2,param_1 + 0x10);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14005b8f0(*(undefined8 *)(param_2 + 8),lVar4,lVar2);
      puVar8 = *(undefined4 **)(param_2 + 8);
      puVar5 = puVar8 + param_3 * 4;
      for (; puVar8 != puVar5; puVar8 = puVar8 + 4) {
        *puVar8 = local_38;
        puVar8[1] = local_34;
        puVar8[2] = local_30;
        puVar8[3] = local_2c;
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400603d0  @1400603d0  [medium:callgraph-r1]  (orig: FUN_1400603d0)
void FUN_1400603d0(longlong param_1,longlong param_2,longlong param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong local_18;
  longlong local_10;
  
  lVar1 = param_2 - param_1;
  do {
    lVar1 = lVar1 >> 4;
    if (lVar1 < 0x21) {
LAB_140060495:
      if (1 < lVar1) {
        FUN_14005ae90(param_1,param_2,param_4,0);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < lVar1) {
        if (0x10 < (longlong)(param_2 - param_1 & 0xfffffffffffffff0U)) {
          FUN_14005ade0(param_1,param_2,param_4,0,0);
        }
        FUN_14005cda0(param_1,param_2,param_4);
        return;
      }
      goto LAB_140060495;
    }
    FUN_14005b9b0(&local_18,param_1,param_2,param_4);
    param_3 = param_3 / 2 + (param_3 / 2) / 2;
    if ((longlong)(local_18 - param_1 & 0xfffffffffffffff0U) <
        (longlong)(param_2 - local_10 & 0xfffffffffffffff0U)) {
      FUN_1400603d0(param_1,local_18,param_3);
      param_1 = local_10;
    }
    else {
      FUN_1400603d0(local_10,param_2,param_3);
      param_2 = local_18;
    }
    lVar1 = param_2 - param_1;
  } while( true );
}

// ==== CWorldKernel::helper_140060510  @140060510  [medium:callgraph-r0]  (orig: FUN_140060510)
void FUN_140060510(undefined8 param_1,ushort *param_2)

{
  if (param_2 != (ushort *)0x0) {
    if (param_2[1] == 0x7533) {
      if (*param_2 == 100) {
        FUN_14005e310(param_1,*(undefined4 *)(param_2 + 2),*(undefined4 *)(param_2 + 6),param_2 + 10
                      ,0,*(undefined4 *)(param_2 + 8));
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x000140060568. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      log_InlineLogERROR(
                        "CWorldKernel::ProcessAccountNetMsg. Net CMsgMobileAccount_A Size[%d] != sizeof(CMsgMobileAccount_A::MSG_Info)"
                        );
      return;
    }
    if (param_2[1] == 0x7531) {
      if (0xb < *param_2) {
        FUN_140055dd0();
        return;
      }
      log_InlineLogERROR(
                        "CWorldKernel::ProcessAccountNetMsg. Net CMsgMobileString_A Size[%d] != sizeof(CMsgMobileString_A::MSG_Info)"
                        );
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400605b0  @1400605b0  [medium:callgraph-r0]  (orig: FUN_1400605b0)
void FUN_1400605b0(undefined8 param_1,ushort *param_2)

{
  ushort uVar1;
  IStringManager *pIVar2;
  char *pcVar3;
  ulonglong in_stack_ffffffffffffffe8;
  
  if (param_2 != (ushort *)0x0) {
    uVar1 = param_2[1];
    if (uVar1 == 0x3ea) {
      if (*param_2 == 0x20) {
        FUN_140056130(param_1,*(undefined4 *)(param_2 + 2),*(undefined4 *)(param_2 + 4),param_2[6],
                      param_2 + 7);
        return;
      }
      pcVar3 = 
      "CWorldKernel::ProcessAccountNetMsg. Net MsgLogin Size[%d] != sizeof(CMsgLogin_A::MSG_Info)";
    }
    else if (uVar1 == 0x41c) {
      if (*param_2 == 0x1c) {
        FUN_14005f320(param_1,*(undefined4 *)(param_2 + 2),*(undefined4 *)(param_2 + 4),param_2 + 6,
                      in_stack_ffffffffffffffe8 & 0xffffffff00000000);
        return;
      }
      pcVar3 = 
      "CWorldKernel::ProcessAccountNetMsg. Net MsgConnect Size[%d] != sizeof(CMsgConnect_A::MSG_Info)"
      ;
    }
    else if (uVar1 == 0x429) {
      if (*param_2 == 0xb0) {
        FUN_14007e700(param_1,*(undefined4 *)(param_2 + 2),*(undefined4 *)(param_2 + 4),
                      *(undefined4 *)(param_2 + 6),param_2 + 8,0);
        return;
      }
      pcVar3 = 
      "CWorldKernel::ProcessAccountNetMsg. Net MsgConnectFB Size[%d] != sizeof(CMsgConnectFB_A::MSG_Info)"
      ;
    }
    else if (uVar1 == 0x4b0) {
      if (*param_2 == 0xc) {
        FUN_140056240(param_1,*(undefined4 *)(param_2 + 2),(char)param_2[4]);
        return;
      }
      pcVar3 = 
      "CWorldKernel::ProcessAccountNetMsg. Net MsgFee Size[%d] != sizeof(CMsgFee_A::MSG_Info)";
    }
    else if (uVar1 == 0x4b1) {
      if (*param_2 == 0x14) {
        FUN_14005e8b0(param_1,*(undefined4 *)(param_2 + 2),*(undefined4 *)(param_2 + 4),
                      *(undefined4 *)(param_2 + 6),(char)param_2[8]);
        return;
      }
      pcVar3 = 
      "CWorldKernel::ProcessAccountNetMsg. Net MsgQFee Size[%d] != sizeof(CMsgQueryFee_A::MSG_Info)"
      ;
    }
    else if (uVar1 == 0x4b2) {
      if (*param_2 == 0x1ec) {
        FUN_1400562c0(param_1,param_2 + 2,param_2 + 0x12,*(undefined4 *)(param_2 + 0x52),
                      *(undefined4 *)(param_2 + 0x54));
        return;
      }
      pcVar3 = 
      "CWorldKernel::ProcessAccountNetMsg. Net MsgWebRequest Size[%d] != sizeof(CMsgWebRequest_A::MSG_Info)"
      ;
    }
    else if (uVar1 == 0x5fc) {
      if (*param_2 == 0xc) {
        FUN_1400563a0(param_1,*(undefined4 *)(param_2 + 2),*(undefined4 *)(param_2 + 4));
        return;
      }
      pcVar3 = 
      "CWorldKernel::ProcessAccountNetMsg. Net MsgOfflineCheating Size[%d] != sizeof(CMsgOfflineCheating_A::MSG_Info)"
      ;
    }
    else if (uVar1 == 0x609) {
      if (7 < *param_2) {
        FUN_140058680(param_1,param_2[2],*param_2,param_2 + 3);
        return;
      }
      pcVar3 = 
      "CWorldKernel::ProcessAccountNetMsg. Net MsgAccountTransfer Size[%d] < sizeof(CMsgAccountTransfer_A::MSG_Info)"
      ;
    }
    else {
      if (uVar1 != 0x643) {
        return;
      }
      if (*param_2 == 0x38) {
        if (*(char *)((longlong)param_2 + 0x15) == '\0') {
          pIVar2 = theInstance();
          pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"STR_GENERAL_BOT_SIN");
          strncpy((char *)((longlong)param_2 + 0x15),pcVar3,0x21);
        }
        FUN_1400564b0(param_1,param_2);
        return;
      }
      pcVar3 = 
      "CWorldKernel::ProcessAccountNetMsg. Net CMsgGameJailEx_A Size[%d] != sizeof(CMsgGameJailEx_A::MSG_Info)"
      ;
    }
    log_InlineLogERROR(pcVar3);
  }
  return;
}

// ==== CWorldKernel::helper_140060870  @140060870  [medium:callgraph-r0]  (orig: FUN_140060870)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140060870(longlong *param_1,undefined4 param_2,int param_3,longlong param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  IStringManager *pIVar7;
  undefined4 *puVar8;
  undefined1 auStack_5e8 [32];
  undefined1 *local_5c8;
  undefined4 local_5c0;
  undefined2 local_5b8;
  undefined2 local_5b0;
  undefined4 local_5a8;
  undefined4 local_5a0;
  undefined1 local_598;
  int local_588 [2];
  undefined8 local_580;
  undefined1 local_578 [1088];
  undefined1 local_138;
  undefined1 local_137 [255];
  ulonglong local_38;
  
  local_580 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_5e8;
  if (param_4 == 0) {
    uVar6 = 0;
  }
  else {
    local_588[0] = param_3;
    lVar5 = (**(code **)(*(longlong *)param_1[0x1d] + 0x40))();
    uVar6 = 0;
    if (lVar5 != 0) {
      if (param_3 == *(int *)(lVar5 + 0x30)) {
        uVar6 = FUN_140054e10();
        lVar5 = FUN_14006e620(uVar6,param_2);
        if (lVar5 == 0) {
          uVar4 = FUN_14005ce90(param_1,param_3);
          cVar1 = FUN_14005d0b0(param_1,uVar4);
          if (cVar1 == '\0') {
            FUN_14007a560(local_578);
            pIVar7 = theInstance();
            uVar6 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ERROR_BANDIP");
            local_598 = 1;
            local_5a0 = 0;
            local_5a8 = 0;
            local_5b0 = 0;
            local_5b8 = 0x835;
            local_5c0 = 0xffffff;
            local_5c8 = (undefined1 *)0x0;
            iVar2 = FUN_14007a620(local_578,"SYSTEM","ALLUSERS",uVar6);
            if (iVar2 != 0) {
              (**(code **)(*param_1 + 0x38))(param_1,param_3,local_578);
            }
            uVar6 = FUN_140054e10();
            FUN_1400674b0(uVar6,param_3,param_2);
            FUN_14007a5e0(local_578);
            uVar6 = 0;
          }
          else {
            uVar6 = FUN_140054e10();
            iVar2 = FUN_1400725a0(uVar6,param_2,param_3,param_4);
            if (iVar2 == 0) {
              (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_2);
              (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_2);
              puVar8 = (undefined4 *)FUN_140053460(param_1 + 0x42,local_588);
              *puVar8 = param_2;
              *(int *)((longlong)param_1 + 0x8c) = *(int *)((longlong)param_1 + 0x8c) + 1;
              uVar6 = 1;
            }
            else if (iVar2 == 1) {
              lVar5 = (**(code **)(*(longlong *)param_1[0x1e] + 0x40))
                                ((longlong *)param_1[0x1e],param_2);
              if (lVar5 != 0) {
                FUN_140073740(lVar5,0);
              }
              puVar8 = (undefined4 *)FUN_140053460(param_1 + 0x42,local_588);
              *puVar8 = param_2;
              lVar5 = (**(code **)(*(longlong *)param_1[0x1e] + 0x40))
                                ((longlong *)param_1[0x1e],param_2);
              if (lVar5 != 0) {
                FUN_140073740(lVar5,0);
              }
              FUN_14007a560(local_578);
              local_598 = 1;
              local_5a0 = 0;
              local_5a8 = 0;
              local_5b0 = 0;
              local_5b8 = 0x835;
              local_5c0 = 0xffffff;
              local_5c8 = (undefined1 *)0x0;
              iVar2 = FUN_14007a620(local_578,"SYSTEM","ALLUSERS","NEW_ROLE");
              if (iVar2 != 0) {
                (**(code **)(*param_1 + 0x38))(param_1,param_3,local_578);
              }
              FUN_14007a5e0(local_578);
              uVar6 = 1;
            }
            else if (iVar2 == 2) {
              (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_2);
              FUN_14007a560(local_578);
              pIVar7 = theInstance();
              uVar6 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ERROR_LACK_OF_BALANCE");
              local_598 = 1;
              local_5a0 = 0;
              local_5a8 = 0;
              local_5b0 = 0;
              local_5b8 = 0x835;
              local_5c0 = 0xffffff;
              local_5c8 = (undefined1 *)0x0;
              iVar2 = FUN_14007a620(local_578,"SYSTEM","ALLUSERS",uVar6);
              if (iVar2 != 0) {
                (**(code **)(*param_1 + 0x38))(param_1,param_3,local_578);
              }
              uVar6 = FUN_140054e10();
              FUN_1400674b0(uVar6,param_3,param_2);
              FUN_14007a5e0(local_578);
              uVar6 = 0;
            }
            else if (iVar2 == 3) {
              log_InlineLogERROR("GM Login Failed, kick out Account[%u]!");
              uVar6 = FUN_140054e10();
              FUN_1400674b0(uVar6,param_3,param_2);
              uVar6 = 0;
            }
            else {
              local_5c8 = (undefined1 *)CONCAT44(local_5c8._4_4_,0x829);
              log_InlineLogERROR("Account[%u] unknow login return: %d, kick out at %s, %d.!");
              uVar6 = FUN_140054e10();
              FUN_1400674b0(uVar6,param_3,param_2);
              uVar6 = 0;
            }
          }
        }
        else {
          iVar2 = FUN_14005ce90(param_1,param_3);
          iVar3 = FUN_14005ce90(param_1);
          if (iVar3 != iVar2) {
            local_138 = 0;
            memset(local_137,0,0xff);
            FUN_14007d430(local_578);
            FUN_14005d300(param_1,iVar2,&local_138,0x100);
            local_5c8 = &local_138;
            iVar2 = FUN_14007d4b0(local_578,0,param_2,iVar2);
            if (iVar2 != 0) {
              FUN_140067420(lVar5,local_578);
            }
            FUN_14007d480(local_578);
          }
          log_InlineLogWARNING("Account[%u] login repeat, kick out at %s, %d");
          uVar6 = FUN_140054e10();
          FUN_140070190(uVar6,param_2,"This account has been logged in.",0);
          uVar6 = FUN_140054e10();
          FUN_1400674b0(uVar6,param_3,param_2);
          uVar6 = 0;
        }
      }
      else {
        uVar6 = 0;
      }
    }
  }
  return uVar6;
}

// ==== CWorldKernel::helper_140060de0  @140060de0  [medium:callgraph-r2]  (orig: FUN_140060de0)
longlong * FUN_140060de0(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_14005fd30(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_140060ed4;
  }
  _invalid_parameter_noinfo();
LAB_140060ed4:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CWorldKernel::helper_140060f10  @140060f10  [medium:callgraph-r2]  (orig: FUN_140060f10)
longlong * FUN_140060f10(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar1 = 0;
  uVar3 = param_1[3];
  lVar2 = lVar1;
  if ((param_1[4] - uVar3 & 0xfffffffffffffff0) != 0) {
    if ((ulonglong)param_1[4] < uVar3) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = (longlong)(param_3[1] - uVar3) >> 4;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140060010(param_1,&local_28,1,param_4);
  uVar3 = param_1[3];
  if ((ulonglong)param_1[4] < uVar3) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar3;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar1;
  }
  else {
    lVar4 = *param_1;
  }
  uVar3 = lVar2 * 0x10 + uVar3;
  if (uVar3 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar1 = *param_1;
    }
    if (*(ulonglong *)(lVar1 + 0x18) <= uVar3) goto LAB_140061007;
  }
  _invalid_parameter_noinfo();
LAB_140061007:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar3;
  return param_2;
}

// ==== CWorldKernel::helper_140061080  @140061080  [medium:callgraph-r1]  (orig: FUN_140061080)
undefined8 * FUN_140061080(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14005a8b0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CWorldKernel::helper_140061190  @140061190  [medium:callgraph-r2]  (orig: FUN_140061190)
longlong FUN_140061190(longlong param_1,longlong param_2)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *pbVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  char cVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  undefined8 uVar8;
  ulonglong uVar9;
  undefined1 local_res8;
  
  if (param_1 == param_2) {
    return param_1;
  }
  lVar2 = *(longlong *)(param_2 + 0x18);
  uVar5 = (*(longlong *)(param_2 + 0x20) - lVar2) / 0x28;
  if (uVar5 == 0) {
    FUN_140037e80();
    return param_1;
  }
  lVar3 = *(longlong *)(param_1 + 0x18);
  uVar6 = (*(longlong *)(param_1 + 0x20) - lVar3) / 0x28;
  if (uVar6 < uVar5) {
    if (lVar3 == 0) {
      uVar9 = 0;
    }
    else {
      uVar9 = (*(longlong *)(param_1 + 0x28) - lVar3) / 0x28;
    }
    if (uVar9 < uVar5) {
      if (lVar3 != 0) {
        FUN_1400367a0(param_1,lVar3,*(longlong *)(param_1 + 0x20));
        operator_delete(*(void **)(param_1 + 0x18));
      }
      cVar7 = FUN_140033a80(param_1,(*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18))
                                    / 0x28);
      if (cVar7 != '\0') {
        uVar8 = FUN_14005ce50(param_1,*(undefined8 *)(param_2 + 0x18),
                              *(undefined8 *)(param_2 + 0x20),*(undefined8 *)(param_1 + 0x18));
        *(undefined8 *)(param_1 + 0x20) = uVar8;
      }
    }
    else {
      lVar1 = lVar2 + uVar6 * 0x28;
      FUN_140033870(lVar2,lVar1,lVar3,local_res8);
      uVar8 = FUN_14005b090(lVar1,*(undefined8 *)(param_2 + 0x20),*(undefined8 *)(param_1 + 0x20),
                            param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar8;
    }
  }
  else {
    this = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
           FUN_140033870(lVar2,*(longlong *)(param_2 + 0x20),lVar3,local_res8);
    pbVar4 = *(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)(param_1 + 0x20);
    for (; this != pbVar4; this = this + 0x28) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    }
    *(longlong *)(param_1 + 0x20) =
         *(longlong *)(param_1 + 0x18) +
         ((*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18)) / 0x28) * 0x28;
  }
  return param_1;
}

// ==== CWorldKernel::vfunc_2  @1400613e0  [high:rtti-vtable]  (orig: FUN_1400613e0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400613e0(longlong param_1,uint param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  longlong lVar3;
  char cVar4;
  int iVar5;
  BOOL BVar6;
  DWORD DVar7;
  longlong lVar8;
  undefined8 uVar9;
  undefined4 *puVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  HANDLE ProcessHandle;
  longlong *plVar13;
  int *piVar14;
  ulonglong uVar15;
  char *pcVar16;
  undefined1 auStackY_17f8 [32];
  undefined4 local_1798;
  int local_1794;
  undefined4 local_1790;
  undefined4 local_178c;
  int local_1788;
  int local_1784 [3];
  undefined2 local_1778;
  undefined2 local_1776;
  int local_1774;
  undefined1 local_1770;
  int local_1768;
  __time32_t local_1764;
  int local_1760;
  char *local_1758;
  _TOKEN_PRIVILEGES local_1750;
  ulonglong local_1740;
  HANDLE local_1738;
  undefined8 local_1730;
  longlong local_1728;
  undefined1 local_1718 [16];
  undefined1 local_1708 [1088];
  char local_12c8 [256];
  char local_11c8 [256];
  undefined2 local_10c8;
  undefined2 local_10c6;
  undefined2 local_10c4;
  undefined1 local_10c2 [1050];
  undefined2 local_ca8;
  undefined2 local_ca6;
  undefined2 local_ca4;
  undefined1 local_ca2 [1050];
  undefined2 local_888;
  int local_884;
  int local_880;
  undefined1 local_87c [1044];
  undefined2 local_468;
  int local_464;
  int local_460;
  undefined1 local_45c [1044];
  ulonglong local_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x1400613f6;
  local_1730 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStackY_17f8;
  local_1784[2] = param_2;
  if (param_2 < 0x4e22) {
    if (param_2 == 0x4e21) {
      lVar8 = -1;
      piVar14 = param_3;
      do {
        if (lVar8 == 0) break;
        lVar8 = lVar8 + -1;
        iVar5 = *piVar14;
        piVar14 = (int *)((longlong)piVar14 + 1);
      } while ((char)iVar5 != '\0');
      (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                (*(longlong **)(param_1 + 0x58),0,0x9c41,~(uint)lVar8);
      local_12c8[0] = '\0';
      memset(local_12c8 + 1,0,0xff);
      iVar5 = sscanf((char *)param_3,"%s");
      if (iVar5 != 1) {
        return 1;
      }
      iVar5 = _stricmp(local_12c8,"setmaxplayer");
      if (iVar5 != 0) {
        iVar5 = _stricmp(local_12c8,"kickoutall");
        if (iVar5 == 0) {
          local_1784[1] = 0xffffffff;
          (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                    (*(longlong **)(param_1 + 0x58),1,0x753b,0xea65);
          return 1;
        }
        iVar5 = _stricmp(local_12c8,"broadcast");
        if (iVar5 != 0) {
          iVar5 = _stricmp(local_12c8,"shutdown");
          if (iVar5 != 0) {
            iVar5 = _stricmp(local_12c8,"restartserver");
            if (iVar5 != 0) {
              iVar5 = _stricmp(local_12c8,"restartwindows");
              if (iVar5 != 0) {
                return 1;
              }
              if (DAT_1409758f4 != 0) {
                ProcessHandle = GetCurrentProcess();
                BVar6 = OpenProcessToken(ProcessHandle,0x28,&local_1738);
                if (BVar6 == 0) {
                  log_InlineLogERROR("OpenProcessToken");
                  return 1;
                }
                LookupPrivilegeValueA
                          ((LPCSTR)0x0,"SeShutdownPrivilege",&local_1750.Privileges[0].Luid);
                local_1750.PrivilegeCount = 1;
                local_1750.Privileges[0].Attributes = 2;
                AdjustTokenPrivileges(local_1738,0,&local_1750,0,(PTOKEN_PRIVILEGES)0x0,(PDWORD)0x0)
                ;
                DVar7 = GetLastError();
                if (DVar7 != 0) {
                  log_InlineLogERROR("AdjustTokenPrivileges");
                  return 1;
                }
                BVar6 = ExitWindowsEx(0x12,0);
                if (BVar6 != 0) {
                  return 1;
                }
                log_InlineLogERROR("ExitWindowsEx");
                return 1;
              }
              lVar8 = -1;
              pcVar16 = "Please <kickoutall> before <restartserver>!";
              do {
                if (lVar8 == 0) break;
                lVar8 = lVar8 + -1;
                cVar4 = *pcVar16;
                pcVar16 = pcVar16 + 1;
              } while (cVar4 != '\0');
              (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                        (*(longlong **)(param_1 + 0x58),0,0x9c41,~(uint)lVar8);
              return 1;
            }
            if (DAT_1409758f4 != 0) {
              DAT_1409758f0 = 1;
              return 1;
            }
            lVar8 = -1;
            pcVar16 = "Please <kickoutall> before <restartserver>!";
            do {
              if (lVar8 == 0) break;
              lVar8 = lVar8 + -1;
              cVar4 = *pcVar16;
              pcVar16 = pcVar16 + 1;
            } while (cVar4 != '\0');
            (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                      (*(longlong **)(param_1 + 0x58),0,0x9c41,~(uint)lVar8);
            return 1;
          }
          pIVar11 = theInstance();
          if (DAT_140975af8 == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          lVar8 = DAT_140975af8;
          if (*(longlong *)(DAT_140975af8 + 0x60) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          uVar9 = *(undefined8 *)(lVar8 + 0x60);
          uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_SHUTDOWN_NOTIFY");
          FUN_14006e8e0(uVar9,&DAT_1406e87d0,uVar12,0);
          lVar8 = -1;
          pcVar16 = "Send shut down broadcast message.";
          do {
            if (lVar8 == 0) break;
            lVar8 = lVar8 + -1;
            cVar4 = *pcVar16;
            pcVar16 = pcVar16 + 1;
          } while (cVar4 != '\0');
          (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                    (*(longlong **)(param_1 + 0x58),0,0x9c41,~(uint)lVar8);
          return 1;
        }
        uVar15 = 0xffffffffffffffff;
        pcVar16 = local_12c8;
        do {
          if (uVar15 == 0) break;
          uVar15 = uVar15 - 1;
          cVar4 = *pcVar16;
          pcVar16 = pcVar16 + 1;
        } while (cVar4 != '\0');
        pcVar16 = (char *)((longlong)param_3 + (~uVar15 - 1));
        if (*pcVar16 == ' ') {
          pcVar16 = pcVar16 + 1;
        }
        local_1758 = pcVar16;
        if (DAT_140975af8 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar8 = DAT_140975af8;
        if (*(longlong *)(DAT_140975af8 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        FUN_14006e8e0(*(undefined8 *)(lVar8 + 0x60),&DAT_1406e87d0,pcVar16,0);
        return 1;
      }
      local_178c = 0;
      iVar5 = sscanf((char *)param_3,"%s %d");
      if (iVar5 != 2) {
        return 1;
      }
      puVar10 = (undefined4 *)MaxPlayerGet();
      LOCK();
      *puVar10 = local_178c;
      UNLOCK();
      local_11c8[0] = '\0';
      memset(local_11c8 + 1,0,0xff);
      MaxPlayerGet();
      _snprintf(local_11c8,0xff,"Set max player limit to %d");
      lVar8 = -1;
      pcVar16 = local_11c8;
      do {
        if (lVar8 == 0) break;
        lVar8 = lVar8 + -1;
        cVar4 = *pcVar16;
        pcVar16 = pcVar16 + 1;
      } while (cVar4 != '\0');
      (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                (*(longlong **)(param_1 + 0x58),0,0x9c41,~(uint)lVar8);
      return 1;
    }
    if (param_2 == 0x3e9) {
      FUN_1400551c0(param_1,*param_3,param_3[1],param_3 + 3);
      return 1;
    }
    if (param_2 == 0x3ea) {
      FUN_140055390(param_1,*param_3,param_3[1],param_3 + 3);
      return 1;
    }
    if (param_2 == 0x3eb) {
      local_1794 = *param_3;
      uVar9 = FUN_140054e10();
      cVar4 = FUN_140070750(uVar9,local_1794);
      if (cVar4 != '\0') {
        local_1740 = 0xe;
        while (uVar15 = local_1740, iVar5 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x18))(),
              uVar15 < (ulonglong)(longlong)iVar5) {
          (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                    (*(longlong **)(param_1 + 0x58),uVar15 & 0xffffffff,0x3eb,0xea65);
          local_1740 = uVar15 + 1;
        }
        return 1;
      }
      uVar9 = FUN_140054e10();
      FUN_1400715e0(uVar9,local_1794);
      if (DAT_140975af8 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      FUN_14005f600(DAT_140975af8,local_1794);
      return 1;
    }
    if (param_2 == 0x3f6) {
      iVar5 = *param_3;
      iVar1 = param_3[1];
      if (iVar1 != 0) {
        lVar8 = FUN_140054e10();
        if (*(longlong *)(lVar8 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        FUN_1400814b0(*(undefined8 *)(lVar8 + 0x60),iVar5,iVar1);
        return 1;
      }
      lVar8 = FUN_140054e10();
      if (*(longlong *)(lVar8 + 0x60) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      FUN_14007f870(*(undefined8 *)(lVar8 + 0x60),iVar5);
      return 1;
    }
    if (param_2 == 0x3f7) {
      iVar5 = *param_3;
      iVar1 = param_3[1];
      iVar2 = param_3[3];
      lVar8 = FUN_140054e10();
      if (*(longlong *)(lVar8 + 0x60) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      FUN_14007f970(*(undefined8 *)(lVar8 + 0x60),iVar5,iVar1,iVar2);
      return 1;
    }
switchD_140061bb2_caseD_4e2d:
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    switch(param_2) {
    case 0x4e22:
      uVar9 = FUN_140054e10();
      FUN_140070620(uVar9,*param_3,param_3[1]);
      break;
    case 0x4e23:
      iVar5 = *param_3;
      uVar9 = FUN_140054e10();
      FUN_1400715e0(uVar9,iVar5);
      if (DAT_140975af8 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      FUN_14005f600(DAT_140975af8,iVar5);
      break;
    case 0x4e24:
      iVar5 = *param_3;
      iVar1 = param_3[1];
      uVar9 = FUN_140054e10();
      lVar8 = FUN_14006e250(uVar9,param_3 + 3);
      if (lVar8 == 0) {
        if ((iVar1 == 0x3ec) && (iVar5 != -1)) {
          uVar9 = FUN_140054e10();
          lVar8 = FUN_140070520(uVar9,iVar5);
          if (lVar8 != 0) {
            FUN_14007a560(local_1708);
            pIVar11 = theInstance();
            uVar9 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_TARGET_OFFLINE");
            FUN_14007a620(local_1708,"SYSTEM",lVar8 + 4,uVar9);
            FUN_140067420(lVar8,local_1708);
            FUN_14007a5e0(local_1708);
          }
        }
      }
      else {
        (*(code *)**(undefined8 **)(param_1 + 8))
                  ((undefined8 *)(param_1 + 8),*(undefined4 *)(lVar8 + 0x60),iVar1,param_3 + 7);
      }
      break;
    case 0x4e25:
      iVar5 = param_3[1];
      uVar9 = FUN_140054e10();
      lVar8 = FUN_14006e3a0(uVar9,param_3[3]);
      if (lVar8 != 0) {
        (*(code *)**(undefined8 **)(param_1 + 8))
                  ((undefined8 *)(param_1 + 8),*(undefined4 *)(lVar8 + 0x60),iVar5,param_3 + 4);
      }
      break;
    case 0x4e26:
      iVar5 = *param_3;
      if (DAT_140975af8 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar8 = DAT_140975af8;
      if (*(longlong *)(DAT_140975af8 + 0x60) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar8 = FUN_14006e3a0(*(undefined8 *)(lVar8 + 0x60),iVar5);
      if (lVar8 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        *(undefined4 *)(lVar8 + 0x78) = DAT_140949794;
      }
      break;
    case 0x4e27:
      if (*(int *)(param_1 + 0xf8) == 3) {
        FUN_1400558e0(param_1,*param_3,0,0);
      }
      break;
    case 0x4e28:
      iVar5 = *param_3;
      if (iVar5 == -1) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        uVar9 = FUN_140054e10();
        FUN_140067580(uVar9,iVar5);
      }
      break;
    case 0x4e29:
      if (*param_3 == -1) {
        FUN_140055390(param_1,param_3[1]);
      }
      else {
        FUN_1400551c0(param_1,*param_3,param_3[2],param_3 + 5);
      }
      break;
    case 0x4e2a:
      local_1798 = 0;
      local_1790 = 0;
      iVar5 = sscanf((char *)param_3,"%d %u");
      if (iVar5 == 2) {
        lVar8 = *(longlong *)(param_1 + 0x40);
        lVar3 = *(longlong *)(param_1 + 0x10);
        local_1728 = lVar3;
        plVar13 = (longlong *)FUN_140050f20(param_1 + 0x10,local_1718,&local_1798);
        if ((lVar3 == 0) || (lVar3 != *plVar13)) {
          _invalid_parameter_noinfo();
        }
        if (lVar8 != plVar13[1]) {
          log_InlineLogWARNING("socket id is exist, socket = %d, ip = %d");
        }
        puVar10 = (undefined4 *)FUN_140053460(param_1 + 0x10,&local_1798);
        *puVar10 = local_1790;
      }
      break;
    case 0x4e2b:
      plVar13 = (longlong *)InstanceGet();
      cVar4 = (**(code **)(*plVar13 + 0x38))(plVar13);
      if (cVar4 == '\0') {
        log_InlineLogERROR("Worldkernel reconnect database failed at %s, %d");
      }
      else {
        log_InlineLogMessage("Worldkernel reconnect database success.");
      }
      break;
    case 0x4e2c:
      local_1768 = *param_3;
      local_1764 = _time32((__time32_t *)0x0);
      local_1760 = param_3[1];
      FUN_14007cf20(param_1 + 0x98,local_1768,&local_1768);
      break;
    default:
      goto switchD_140061bb2_caseD_4e2d;
    case 0x4e2e:
      iVar5 = *param_3;
      iVar1 = param_3[1];
      if (*(int *)(param_1 + 0xf8) == 3) {
        if (param_3[2] == 0) {
          FUN_140055820(param_1,iVar1,1);
          FUN_1400558e0(param_1,iVar1,0,0);
          tq::MyLogSave("gmlog/ChangeServer",&DAT_1406ed4c8);
        }
        else {
          cVar4 = FUN_1400558e0(param_1,iVar1,0,0);
          if (cVar4 == '\0') {
            local_1784[0] = iVar1;
            piVar14 = (int *)FUN_140018880(param_1 + 0x138,local_1784);
            *piVar14 = iVar5;
            tq::MyLogSave("gmlog/ChangeServer",&DAT_1406ed478);
          }
          else {
            tq::MyLogSave("gmlog/ChangeServer",&DAT_1406ed4a0);
          }
        }
      }
      else {
        tq::MyLogSave("gmlog/ChangeServer",&DAT_1406ed450);
      }
      break;
    case 0x4e2f:
      local_468 = local_468 & 0xff00;
      memset((void *)((longlong)&local_468 + 1),0,0x417);
      local_468 = 0;
      local_464 = *param_3;
      local_460 = param_3[1];
      if (0x409 < (uint)param_3[2]) {
        return 0;
      }
      memcpy(local_45c,param_3 + 3,(ulonglong)(uint)param_3[2]);
      local_10c8 = (ushort)local_10c8._1_1_ << 8;
      memset((void *)((longlong)&local_10c8 + 1),0,0x417);
      local_10c8 = (short)param_3[2] + 0x16;
      local_10c6 = 0x608;
      local_10c4 = 2;
      memcpy(local_10c2,&local_468,(ulonglong)(ushort)((short)param_3[2] + 0xf));
      FUN_140055600(param_1,&local_10c8,local_10c8);
      break;
    case 0x4e30:
      local_888 = local_888 & 0xff00;
      memset((void *)((longlong)&local_888 + 1),0,0x417);
      local_888 = 6;
      local_884 = *param_3;
      local_880 = param_3[1];
      if (0x409 < (uint)param_3[2]) {
        return 0;
      }
      memcpy(local_87c,param_3 + 3,(ulonglong)(uint)param_3[2]);
      local_ca8 = (ushort)local_ca8._1_1_ << 8;
      memset((void *)((longlong)&local_ca8 + 1),0,0x417);
      local_ca8 = (short)param_3[2] + 0x16;
      local_ca6 = 0x608;
      local_ca4 = 2;
      memcpy(local_ca2,&local_888,(ulonglong)(ushort)((short)param_3[2] + 0xf));
      FUN_140055600(param_1,&local_ca8,local_ca8);
      break;
    case 0x4e31:
      local_1788 = *param_3;
      FUN_140050de0(param_1 + 0x10,&local_1788);
      break;
    case 0x4e32:
      local_1778 = 0xc;
      local_1776 = 0x640;
      local_1774 = *param_3;
      local_1770 = (undefined1)param_3[1];
      FUN_140055600(param_1,&local_1778);
      break;
    case 0x4e33:
      if (*param_3 == 1) {
        *(undefined4 *)(param_1 + 0xf8) = 2;
        if (*(char *)(param_1 + 0x203) == '\0') {
          FUN_1400556a0(param_1,param_1 + 0x10c,param_1 + 0x11c,param_1 + 0xfc);
        }
        else {
          FUN_140055d00(param_1);
        }
      }
      else {
        *(undefined4 *)(param_1 + 0xf8) = 0;
        DAT_1409757c4 = 0;
        lVar8 = -1;
        pcVar16 = "Account server connection broken.";
        do {
          if (lVar8 == 0) break;
          lVar8 = lVar8 + -1;
          cVar4 = *pcVar16;
          pcVar16 = pcVar16 + 1;
        } while (cVar4 != '\0');
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                  (*(longlong **)(param_1 + 0x58),0,0x9c41,~(uint)lVar8);
      }
      break;
    case 0x4e34:
      if (param_3 != (int *)0x0) {
        if (*(char *)(param_1 + 0x203) == '\0') {
          FUN_1400605b0(param_1,param_3 + 1);
        }
        else {
          FUN_140060510(param_1,param_3 + 1);
        }
      }
      break;
    case 0x4e35:
      if (param_3 == (int *)0x0) {
        log_InlineLogERROR(
                          "CWorldKernel::ProcessMsg, WORLD_M91_RECHARGE_QUERY, buf is NULL, type:%d, from:%d"
                          );
        return 0;
      }
      if (param_3[2] == 0) {
        *(undefined4 *)(param_1 + 0x1ec) = 0;
      }
      else {
        if (param_3[2] != 1) {
          log_InlineLogERROR(
                            "CWorldKernel::WORLD_M91_RECHARGE_QUERY, RECHARGE_91QUERY, case[%d] error. User[%u], type:%d, from:%d"
                            );
          return 0;
        }
        FUN_140077000(param_1,*param_3,param_3[1]);
      }
    }
  }
  return 1;
}

// ==== CWorldKernel::helper_140062510  @140062510  [medium:callgraph-r0]  (orig: FUN_140062510)
undefined8 FUN_140062510(longlong param_1,longlong *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong lVar3;
  ulonglong uVar4;
  int iVar5;
  undefined4 uVar6;
  longlong *plVar7;
  undefined4 *puVar8;
  longlong *plVar9;
  char *pcVar10;
  undefined4 *puVar11;
  undefined8 uVar12;
  undefined7 uVar13;
  uint uVar14;
  undefined4 *puVar15;
  undefined4 *puVar16;
  undefined4 *local_res10;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  plVar7 = (longlong *)
           (**(code **)(*param_2 + 0x10))
                     (param_2,"SELECT * FROM cq_iptoaddrconfig",2,param_2,0xfffffffffffffffe);
  if (plVar7 == (longlong *)0x0) {
    uVar13 = 0;
  }
  else {
    puVar16 = (undefined4 *)0x0;
    iVar5 = (**(code **)(*plVar7 + 0x40))(plVar7);
    puVar15 = puVar16;
    if (0 < iVar5) {
      do {
        (**(code **)(*plVar7 + 0x30))(plVar7);
        puVar8 = operator_new(0x80);
        puVar11 = puVar16;
        if (puVar8 != (undefined4 *)0x0) {
          *puVar8 = 0;
          puVar8[1] = 0;
          puVar8[2] = 0;
          *(undefined8 *)(puVar8 + 3) = 0;
          *(undefined8 *)(puVar8 + 5) = 0;
          *(undefined8 *)(puVar8 + 7) = 0;
          puVar8[9] = 0;
          local_res10 = puVar8;
          memset(puVar8 + 10,0,0x56);
          puVar11 = puVar8;
        }
        local_res10 = puVar11;
        if (puVar11 != (undefined4 *)0x0) {
          plVar9 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,1);
          uVar6 = (**(code **)(*plVar9 + 0x50))(plVar9);
          *puVar11 = uVar6;
          plVar9 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,2);
          uVar6 = (**(code **)(*plVar9 + 0x50))(plVar9);
          puVar11[1] = uVar6;
          plVar9 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,3);
          uVar6 = (**(code **)(*plVar9 + 0x50))(plVar9);
          puVar11[2] = uVar6;
          plVar9 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,4);
          pcVar10 = (char *)(**(code **)(*plVar9 + 0x78))(plVar9);
          tq::SafeCopy((char *)(puVar11 + 3),pcVar10,0x1c);
          plVar9 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,5);
          pcVar10 = (char *)(**(code **)(*plVar9 + 0x78))(plVar9);
          tq::SafeCopy((char *)(puVar11 + 10),pcVar10,0x56);
          puVar1 = *(undefined8 **)(param_1 + 0x268);
          puVar8 = puVar16;
          if (puVar1 != (undefined8 *)0x0) {
            puVar8 = (undefined4 *)(*(longlong *)(param_1 + 0x278) - (longlong)puVar1 >> 3);
          }
          puVar2 = *(undefined8 **)(param_1 + 0x270);
          if ((undefined4 *)((longlong)puVar2 - (longlong)puVar1 >> 3) < puVar8) {
            *puVar2 = puVar11;
            *(undefined8 **)(param_1 + 0x270) = puVar2 + 1;
          }
          else {
            if (puVar2 < puVar1) {
              _invalid_parameter_noinfo();
            }
            lVar3 = *(longlong *)(param_1 + 0x250);
            uVar4 = *(ulonglong *)(param_1 + 0x268);
            puVar11 = puVar16;
            if ((*(ulonglong *)(param_1 + 0x270) - uVar4 & 0xfffffffffffffff8) != 0) {
              if (*(ulonglong *)(param_1 + 0x270) < uVar4) {
                _invalid_parameter_noinfo();
              }
              if ((lVar3 == 0) || (lVar3 != *(longlong *)(param_1 + 0x250))) {
                _invalid_parameter_noinfo();
              }
              puVar11 = (undefined4 *)((longlong)((longlong)puVar2 - uVar4) >> 3);
            }
            local_48 = (undefined4)lVar3;
            uStack_44 = (undefined4)((ulonglong)lVar3 >> 0x20);
            uStack_40 = SUB84(puVar2,0);
            uStack_3c = (undefined4)((ulonglong)puVar2 >> 0x20);
            local_38 = local_48;
            uStack_34 = uStack_44;
            uStack_30 = uStack_40;
            uStack_2c = uStack_3c;
            FUN_14005dd10(param_1 + 0x250,&local_38,1,&local_res10);
            uVar4 = *(ulonglong *)(param_1 + 0x268);
            if (*(ulonglong *)(param_1 + 0x270) < uVar4) {
              _invalid_parameter_noinfo();
            }
            puVar1 = *(undefined8 **)(param_1 + 0x250);
            if (puVar1 == (undefined8 *)0x0) {
              _invalid_parameter_noinfo();
              puVar8 = puVar16;
            }
            else {
              puVar8 = (undefined4 *)*puVar1;
            }
            uVar4 = uVar4 + (longlong)puVar11 * 8;
            if (uVar4 <= *(ulonglong *)(puVar8 + 8)) {
              puVar11 = puVar16;
              if (puVar1 != (undefined8 *)0x0) {
                puVar11 = (undefined4 *)*puVar1;
              }
              if (*(ulonglong *)(puVar11 + 6) <= uVar4) goto LAB_1400627b7;
            }
            _invalid_parameter_noinfo();
          }
        }
LAB_1400627b7:
        uVar14 = (int)puVar15 + 1;
        iVar5 = (**(code **)(*plVar7 + 0x40))(plVar7);
        puVar15 = (undefined4 *)(ulonglong)uVar14;
      } while ((int)uVar14 < iVar5);
    }
    uVar12 = (**(code **)*plVar7)(plVar7);
    uVar13 = (undefined7)((ulonglong)uVar12 >> 8);
  }
  return CONCAT71(uVar13,1);
}

// ==== CWorldKernel::helper_140062800  @140062800  [medium:callgraph-r1]  (orig: FUN_140062800)
void FUN_140062800(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) >> 3;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) >> 3) < uVar3) {
    FUN_14005ab50(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 8;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140060de0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CWorldKernel::helper_1400628d0  @1400628d0  [medium:callgraph-r0]  (orig: FUN_1400628d0)
undefined8 * FUN_1400628d0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14005a3f0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x75) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CWorldKernel::helper_140062950  @140062950  [medium:callgraph-r1]  (orig: FUN_140062950)
void FUN_140062950(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) >> 4;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) >> 4) < uVar3) {
    FUN_14005ab90(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x10;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140060f10(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CWorldKernel::helper_1400641b0  @1400641b0  [medium:callgraph-r0]  (orig: FUN_1400641b0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_1400641b0(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  longlong *plVar3;
  char *_Src;
  ulonglong uVar4;
  int iVar5;
  int local_res8 [2];
  uint local_res10 [2];
  uint local_res18;
  uint local_res20;
  int local_38;
  uint local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  uint local_24;
  
  FUN_14005fa10(param_1 + 0x1b0);
  plVar2 = (longlong *)FUN_140006ad0(20000,0);
  if (plVar2 != (longlong *)0x0) {
    iVar5 = 0;
    iVar1 = (**(code **)(*plVar2 + 0x40))(plVar2);
    if (0 < iVar1) {
      do {
        (**(code **)(*plVar2 + 0x30))(plVar2,(longlong)iVar5);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,7);
        _Src = (char *)(**(code **)(*plVar3 + 0x78))(plVar3);
        iVar1 = sscanf(_Src,"%u.%u.%u.%u %u.%u.%u.%u",local_res8,local_res10);
        if (iVar1 == 8) {
          local_28 = ((local_res8[0] << 8 | local_res10[0]) << 8 | local_res18) << 8 | local_res20;
          local_24 = ((local_38 << 8 | local_34) << 8 | local_30) << 8 | local_2c;
          FUN_140062800(param_1 + 0x1b0,&local_28);
        }
        else {
          plVar3 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0);
          uVar4 = (**(code **)(*plVar3 + 0x48))(plVar3);
          log_InlineLogERROR("CWorldKernel::LoadIpConfig bad config record %u",uVar4 & 0xffffffff);
        }
        iVar5 = iVar5 + 1;
        iVar1 = (**(code **)(*plVar2 + 0x40))(plVar2);
      } while (iVar5 < iVar1);
    }
    (**(code **)*plVar2)(plVar2);
  }
  return 1;
}

// ==== CWorldKernel::helper_140064330  @140064330  [medium:callgraph-r0]  (orig: FUN_140064330)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140064330(undefined8 param_1,int param_2,int param_3,undefined4 param_4)

{
  uint uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  int iVar4;
  __time32_t _Var5;
  int iVar6;
  int iVar7;
  ulonglong *puVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined1 uVar11;
  int *piVar12;
  int *piVar13;
  longlong lVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  int iVar18;
  undefined1 auStack_668 [32];
  int local_648;
  int local_640;
  int local_638;
  int local_630;
  int local_628;
  int local_620;
  int local_618;
  undefined4 local_610;
  undefined4 local_608;
  uint local_600;
  undefined4 local_5f8;
  undefined4 local_5f0;
  undefined4 local_5e8;
  uint local_5e0;
  undefined4 local_5d8;
  undefined4 local_5d0;
  undefined4 local_5c8;
  undefined4 local_5c0;
  undefined4 local_5b8;
  int local_5b0;
  int local_5a8;
  int local_5a0;
  int local_598;
  int local_594;
  int local_590;
  ulonglong *local_588 [3];
  int *local_570;
  int *local_568;
  undefined8 local_560;
  int local_558;
  undefined4 local_554;
  uint local_550;
  int local_548 [2];
  ulonglong *local_540;
  int local_538 [6];
  int local_520 [6];
  undefined4 local_508;
  undefined8 local_500;
  undefined8 local_4f8;
  int local_4e8 [20];
  undefined8 local_498;
  uint local_490;
  uint local_48c;
  undefined4 local_488;
  int local_480 [2];
  undefined8 local_478;
  undefined4 local_470;
  ulonglong *local_468 [2];
  char local_458 [1023];
  undefined1 local_59;
  ulonglong local_58;
  
  local_4f8 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_668;
  local_558 = param_2;
  local_508 = param_4;
  local_500 = param_1;
  iVar4 = FUN_14005d200(param_1,param_3);
  local_590 = iVar4;
  _Var5 = _time32((__time32_t *)0x0);
  puVar8 = (ulonglong *)0x0;
  local_598 = 0;
  local_554 = 0;
  local_550 = local_550 & 0xffffff00;
  iVar18 = 0;
  local_548[0] = 0;
  local_548[1] = 0;
  local_594 = _Var5;
  local_540 = operator_new(8);
  if (local_540 != (ulonglong *)0x0) {
    *local_540 = (ulonglong)local_588;
    puVar8 = local_540;
  }
  local_570 = (int *)0x0;
  local_568 = (int *)0x0;
  local_560 = 0;
  local_588[0] = puVar8;
  local_468[0] = local_540;
  _snprintf(local_458,0x400,"SELECT * FROM cq_ippointrecord WHERE account_id=%u");
  local_59 = 0;
  plVar9 = (longlong *)InstanceGet();
  plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,local_458,1);
  iVar6 = iVar18;
  if (plVar9 != (longlong *)0x0) {
    plVar10 = (longlong *)(**(code **)(*plVar9 + 0x38))(plVar9);
    (**(code **)*plVar9)(plVar9);
    if (plVar10 == (longlong *)0x0) {
      plVar9 = (longlong *)InstanceGet();
      plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"cq_ippointrecord");
      if (plVar10 == (longlong *)0x0) {
        local_648 = 0xac5;
        log_InlineLogERROR(&DAT_1406d9c10);
        _Var5 = local_594;
        goto LAB_1400646ea;
      }
    }
    plVar9 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,"lastloginip");
    local_598 = (**(code **)(*plVar9 + 0x40))(plVar9);
    plVar9 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,"lastlogintime");
    local_554 = (**(code **)(*plVar9 + 0x40))(plVar9);
    plVar9 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,"initialip");
    iVar6 = (**(code **)(*plVar9 + 0x40))(plVar9);
    iVar4 = 1;
    piVar12 = local_4e8 + 1;
    piVar13 = local_4e8;
    do {
      local_498 = 0;
      local_490 = local_490 & 0xffff0000;
      _snprintf((char *)&local_498,10,"ippoint%d");
      local_490._0_2_ = (ushort)(byte)local_490;
      plVar9 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,&local_498);
      iVar7 = (**(code **)(*plVar9 + 0x48))(plVar9);
      if (0 < iVar7) {
        local_468[0] = (ulonglong *)0x0;
        local_540 = (ulonglong *)((ulonglong)local_540 & 0xffffffff00000000);
        local_480[0] = 0;
        local_480[1] = 0;
        local_478 = 0;
        _snprintf((char *)local_468,8,"ipcode%d");
        local_468[0] = (ulonglong *)((ulonglong)local_468[0] & 0xffffffffffffff);
        _snprintf((char *)&local_540,4,"ip%d");
        local_540._0_4_ = (uint)(uint3)local_540;
        _snprintf((char *)local_480,0x10,"iplogintime%d");
        local_478 = local_478 & 0xffffffffffffff;
        plVar9 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,&local_540);
        iVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
        piVar12[-1] = iVar7;
        plVar9 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,local_468);
        iVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
        *piVar12 = iVar7;
        plVar9 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,&local_498);
        iVar7 = (**(code **)(*plVar9 + 0x48))(plVar9);
        piVar12[1] = iVar7;
        plVar9 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,local_480);
        iVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
        piVar12[2] = iVar7;
        FUN_140062950(local_588,piVar13);
      }
      iVar4 = iVar4 + 1;
      piVar13 = piVar13 + 4;
      piVar12 = piVar12 + 4;
    } while (iVar4 < 6);
    (**(code **)*plVar10)(plVar10);
    _Var5 = local_594;
    iVar4 = local_590;
    param_2 = local_558;
  }
LAB_1400646ea:
  piVar12 = local_570;
  iVar7 = local_594;
  if (((longlong)local_568 - (longlong)local_570 & 0xfffffffffffffff0U) == 0) {
    memset(local_458,0,0x400);
    if (iVar6 == 0) {
      local_648 = param_3;
      local_640 = iVar4;
      local_638 = _Var5;
      local_630 = param_3;
      local_628 = _Var5;
      local_620 = param_3;
      local_618 = iVar4;
      _snprintf(local_458,0x400,
                "INSERT cq_ippointrecord SET account_id=%u, ip1=%u, ipcode1=%u, ippoint1=30, iplogintime1=%u, lastloginip=%u, lastlogintime=%u, initialip=%u, initialipcode=%u"
               );
    }
    else {
      local_648 = iVar4;
      local_640 = _Var5;
      local_638 = param_3;
      local_630 = _Var5;
      local_628 = param_2;
      _snprintf(local_458,0x400,
                "UPDATE cq_ippointrecord SET ip1=%u, ipcode1=%u, ippoint1=30, iplogintime1=%u,lastloginip=%u, lastlogintime=%u WHERE account_id=%u LIMIT 1"
               );
    }
    local_59 = 0;
    plVar9 = (longlong *)InstanceGet();
    (**(code **)(*plVar9 + 0x30))(plVar9,local_458,1);
    iVar4 = 0;
  }
  else {
    uVar1 = local_594 / 0x15180;
    if (local_568 < local_570) {
      _invalid_parameter_noinfo();
    }
    puVar8 = local_588[0];
    iVar18 = 0;
    lVar14 = 0;
    while( true ) {
      piVar13 = local_568;
      if (local_568 < local_570) {
        _invalid_parameter_noinfo();
      }
      if ((puVar8 == (ulonglong *)0x0) || (puVar8 != local_588[0])) {
        _invalid_parameter_noinfo();
      }
      if (piVar12 == piVar13) goto LAB_1400649e0;
      if (puVar8 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar15 = 0;
      }
      else {
        uVar15 = *puVar8;
      }
      if (*(int **)(uVar15 + 0x20) <= piVar12) {
        _invalid_parameter_noinfo();
      }
      iVar4 = *piVar12;
      local_498 = *(undefined8 *)piVar12;
      local_490 = piVar12[2];
      local_48c = piVar12[3];
      if (lVar14 < 2) {
        local_548[lVar14] = iVar4;
      }
      if (iVar4 == param_3) break;
      iVar18 = iVar18 + 1;
      lVar14 = lVar14 + 1;
      if (puVar8 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar15 = 0;
      }
      else {
        uVar15 = *puVar8;
      }
      if (*(int **)(uVar15 + 0x20) <= piVar12) {
        _invalid_parameter_noinfo();
      }
      piVar12 = piVar12 + 4;
    }
    if (iVar18 < 2) {
      if (uVar1 != local_48c / 0x15180) {
        if (iVar4 == local_598) {
          iVar4 = local_490 + 2;
        }
        else {
          iVar4 = local_490 + 1;
        }
        if (0x3c < iVar4) {
          iVar4 = 0x3c;
        }
        if (puVar8 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar15 = 0;
        }
        else {
          uVar15 = *puVar8;
        }
        if (*(int **)(uVar15 + 0x20) <= piVar12) {
          _invalid_parameter_noinfo();
        }
        piVar12[2] = iVar4;
        if (puVar8 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar15 = 0;
        }
        else {
          uVar15 = *puVar8;
        }
        if (*(int **)(uVar15 + 0x20) <= piVar12) {
          _invalid_parameter_noinfo();
        }
        piVar12[3] = iVar7;
      }
    }
    else if (uVar1 != local_48c / 0x15180) {
      if (iVar4 == local_598) {
        iVar4 = local_490 + 4;
      }
      else {
        iVar4 = local_490 + 3;
      }
      if (0x3c < iVar4) {
        iVar4 = 0x3c;
      }
      if (puVar8 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar15 = 0;
      }
      else {
        uVar15 = *puVar8;
      }
      if (*(int **)(uVar15 + 0x20) <= piVar12) {
        _invalid_parameter_noinfo();
      }
      piVar12[2] = iVar4;
      if (puVar8 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar15 = 0;
      }
      else {
        uVar15 = *puVar8;
      }
      if (*(int **)(uVar15 + 0x20) <= piVar12) {
        _invalid_parameter_noinfo();
      }
      piVar12[3] = iVar7;
    }
LAB_1400649e0:
    piVar12 = local_570;
    iVar4 = (int)((longlong)local_568 - (longlong)local_570 >> 4);
    if (iVar4 <= iVar18) {
      if (iVar4 < 5) {
        lVar14 = (longlong)iVar4;
        local_4e8[lVar14 * 4] = param_3;
        local_4e8[lVar14 * 4 + 1] = local_590;
        local_4e8[lVar14 * 4 + 2] = 0x1e;
        local_4e8[lVar14 * 4 + 3] = iVar7;
        FUN_140062950(local_588);
      }
      else {
        if (local_568 < local_570) {
          _invalid_parameter_noinfo();
        }
        puVar8 = local_588[0];
        iVar18 = local_590;
        uVar16 = 0;
        uVar15 = uVar16;
        while( true ) {
          piVar13 = local_568;
          if (local_568 < local_570) {
            _invalid_parameter_noinfo();
          }
          if ((puVar8 == (ulonglong *)0x0) || (puVar8 != local_588[0])) {
            _invalid_parameter_noinfo();
          }
          if (piVar12 == piVar13) break;
          iVar4 = (int)uVar15;
          if (iVar4 < 2) {
            if (puVar8 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar16;
            }
            else {
              uVar15 = *puVar8;
            }
            if (*(int **)(uVar15 + 0x20) <= piVar12) {
              _invalid_parameter_noinfo();
            }
            piVar12[2] = piVar12[2] + -2;
            if (puVar8 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar16;
            }
            else {
              uVar15 = *puVar8;
            }
            if (*(int **)(uVar15 + 0x20) <= piVar12) {
              _invalid_parameter_noinfo();
            }
            if (piVar12[2] < 0x1e) {
              if (puVar8 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar15 = uVar16;
              }
              else {
                uVar15 = *puVar8;
              }
              if (*(int **)(uVar15 + 0x20) <= piVar12) {
                _invalid_parameter_noinfo();
              }
              piVar12[2] = 0x1e;
            }
          }
          else if (iVar4 < 4) {
            if (puVar8 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar16;
            }
            else {
              uVar15 = *puVar8;
            }
            if (*(int **)(uVar15 + 0x20) <= piVar12) {
              _invalid_parameter_noinfo();
            }
            piVar12[2] = piVar12[2] + -1;
            if (puVar8 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar16;
            }
            else {
              uVar15 = *puVar8;
            }
            if (*(int **)(uVar15 + 0x20) <= piVar12) {
              _invalid_parameter_noinfo();
            }
            if (piVar12[2] < 1) {
              if (puVar8 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar15 = uVar16;
              }
              else {
                uVar15 = *puVar8;
              }
              if (*(int **)(uVar15 + 0x20) <= piVar12) {
                _invalid_parameter_noinfo();
              }
              piVar12[2] = 1;
            }
          }
          else {
            if (puVar8 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar16;
            }
            else {
              uVar15 = *puVar8;
            }
            if (*(int **)(uVar15 + 0x20) <= piVar12) {
              _invalid_parameter_noinfo();
            }
            *piVar12 = param_3;
            if (puVar8 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar16;
            }
            else {
              uVar15 = *puVar8;
            }
            if (*(int **)(uVar15 + 0x20) <= piVar12) {
              _invalid_parameter_noinfo();
            }
            piVar12[1] = iVar18;
            if (puVar8 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar16;
            }
            else {
              uVar15 = *puVar8;
            }
            if (*(int **)(uVar15 + 0x20) <= piVar12) {
              _invalid_parameter_noinfo();
            }
            piVar12[2] = 1;
            if (puVar8 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar16;
            }
            else {
              uVar15 = *puVar8;
            }
            if (*(int **)(uVar15 + 0x20) <= piVar12) {
              _invalid_parameter_noinfo();
            }
            piVar12[3] = iVar7;
          }
          uVar15 = (ulonglong)(iVar4 + 1);
          if (puVar8 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar17 = uVar16;
          }
          else {
            uVar17 = *puVar8;
          }
          if (*(int **)(uVar17 + 0x20) <= piVar12) {
            _invalid_parameter_noinfo();
          }
          piVar12 = piVar12 + 4;
        }
      }
    }
    piVar12 = local_568;
    uVar15 = 0;
    if (1 < (int)((longlong)local_568 - (longlong)local_570 >> 4)) {
      if (local_568 < local_570) {
        _invalid_parameter_noinfo();
      }
      piVar13 = local_570;
      puVar8 = local_588[0];
      if (local_568 < local_570) {
        _invalid_parameter_noinfo();
      }
      if ((puVar8 == (ulonglong *)0x0) || (puVar8 != local_588[0])) {
        _invalid_parameter_noinfo();
      }
      FUN_1400603d0(piVar13,piVar12,(longlong)piVar12 - (longlong)piVar13 >> 4,&LAB_1400567c0);
    }
    memset(local_458,0,0x400);
    piVar12 = local_570;
    local_538[0] = 0;
    local_538[1] = 0;
    local_538[2] = 0;
    local_538[3] = 0;
    local_538[4] = 0;
    local_520[0] = 0;
    local_520[1] = 0;
    local_520[2] = 0;
    local_520[3] = 0;
    local_520[4] = 0;
    local_498 = 0;
    local_490 = 0;
    local_48c = 0;
    local_488 = 0;
    local_480[0] = 0;
    local_480[1] = 0;
    local_478 = 0;
    local_470 = 0;
    uVar16 = uVar15;
    puVar8 = local_588[0];
    if (local_568 < local_570) {
      _invalid_parameter_noinfo();
      puVar8 = local_588[0];
    }
    while( true ) {
      piVar13 = local_568;
      if (local_568 < local_570) {
        _invalid_parameter_noinfo();
      }
      if ((puVar8 == (ulonglong *)0x0) || (puVar8 != local_588[0])) {
        _invalid_parameter_noinfo();
      }
      if (piVar12 == piVar13) break;
      if (puVar8 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar17 = uVar15;
      }
      else {
        uVar17 = *puVar8;
      }
      if (*(int **)(uVar17 + 0x20) <= piVar12) {
        _invalid_parameter_noinfo();
      }
      *(int *)((longlong)local_538 + uVar16) = *piVar12;
      if (puVar8 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar17 = uVar15;
      }
      else {
        uVar17 = *puVar8;
      }
      if (*(int **)(uVar17 + 0x20) <= piVar12) {
        _invalid_parameter_noinfo();
      }
      *(int *)((longlong)local_520 + uVar16) = piVar12[1];
      if (puVar8 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar17 = uVar15;
      }
      else {
        uVar17 = *puVar8;
      }
      if (*(int **)(uVar17 + 0x20) <= piVar12) {
        _invalid_parameter_noinfo();
      }
      *(int *)((longlong)&local_498 + uVar16) = piVar12[2];
      if (puVar8 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar17 = uVar15;
      }
      else {
        uVar17 = *puVar8;
      }
      if (*(int **)(uVar17 + 0x20) <= piVar12) {
        _invalid_parameter_noinfo();
      }
      *(int *)((longlong)local_480 + uVar16) = piVar12[3];
      if (puVar8 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar17 = uVar15;
      }
      else {
        uVar17 = *puVar8;
      }
      if (*(int **)(uVar17 + 0x20) <= piVar12) {
        _invalid_parameter_noinfo();
      }
      piVar12 = piVar12 + 4;
      uVar16 = uVar16 + 4;
    }
    local_5a0 = local_558;
    local_5a8 = iVar7;
    local_5b8 = local_470;
    local_5c0 = local_488;
    local_5c8 = local_520[4];
    local_5d0 = local_538[4];
    local_5d8 = local_478._4_4_;
    local_5e0 = local_48c;
    local_5e8 = local_520[3];
    local_5f0 = local_538[3];
    local_5f8 = (undefined4)local_478;
    local_600 = local_490;
    local_608 = local_520[2];
    local_610 = local_538[2];
    local_618 = local_480[1];
    local_620 = local_498._4_4_;
    local_628 = local_520[1];
    local_630 = local_538[1];
    local_638 = local_480[0];
    local_640 = (undefined4)local_498;
    local_648 = local_520[0];
    local_5b0 = param_3;
    _snprintf(local_458,0x400,
              "UPDATE cq_ippointrecord SET ip1=%u, ipcode1=%u, ippoint1=%d, iplogintime1=%u, \t\t\tip2=%u, ipcode2=%u, ippoint2=%d, iplogintime2=%u, ip3=%u, ipcode3=%u, ippoint3=%d, iplogintime3=%u, \t\t\tip4=%u, ipcode4=%u, ippoint4=%d, iplogintime4=%u, ip5=%u, ipcode5=%u, ippoint5=%d, iplogintime5=%u, \t\t\tlastloginip=%u, lastlogintime=%u WHERE account_id=%u LIMIT 1"
             );
    local_59 = 0;
    plVar9 = (longlong *)InstanceGet();
    (**(code **)(*plVar9 + 0x30))(plVar9,local_458,1);
    iVar4 = local_548[1];
    iVar18 = local_548[0];
  }
  uVar3 = local_500;
  uVar2 = local_508;
  uVar11 = (undefined1)local_550;
  if ((iVar18 != local_598) && (iVar4 != local_598)) {
    uVar11 = 1;
  }
  local_640 = local_508;
  local_648 = CONCAT31(local_648._1_3_,uVar11);
  FUN_14005f7a0(local_500,param_3,local_598,local_554);
  FUN_14005f900(uVar3,param_3,uVar2);
  if (local_570 != (int *)0x0) {
    operator_delete(local_570);
  }
  local_570 = (int *)0x0;
  local_568 = (int *)0x0;
  local_560 = 0;
  operator_delete(local_588[0]);
  return;
}

// ==== CWorldKernel::helper_1400650f0  @1400650f0  [medium:callgraph-r0]  (orig: FUN_1400650f0)
undefined8 * FUN_1400650f0(undefined1 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = ISingleMap<CConnectUser>::vftable;
    *puVar1 = CSingleMap<CConnectUser>::vftable;
    FUN_140061080(puVar1 + 2);
    *(undefined1 *)(puVar1 + 1) = param_1;
  }
  return puVar1;
}

// ==== CWorldKernel::helper_140065160  @140065160  [medium:callgraph-r1]  (orig: FUN_140065160)
longlong FUN_140065160(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - param_1;
    do {
      FUN_140061190(lVar1 + param_1,param_1);
      param_1 = param_1 + 0x30;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x30) * 0x30 + param_3;
}

// ==== CWorldKernel::vfunc_1  @1400651f0  [high:rtti-vtable]  (orig: FUN_1400651f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400651f0(longlong param_1,longlong *param_2)

{
  undefined1 uVar1;
  char cVar2;
  uint _Seed;
  undefined4 uVar3;
  int iVar4;
  ulong uVar5;
  longlong lVar6;
  undefined8 uVar7;
  undefined1 auStack_458 [32];
  undefined4 local_438;
  void *local_428;
  undefined8 local_420;
  CIniFile local_418 [1024];
  ulonglong local_18;
  
  local_420 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  _Seed = _time32((__time32_t *)0x0);
  srand(_Seed);
  *(longlong **)(param_1 + 0x58) = param_2;
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  *(undefined4 *)(param_1 + 0x50) = uVar3;
  (**(code **)(**(longlong **)(param_1 + 0x58) + 0x38))();
  (**(code **)(**(longlong **)(param_1 + 0x58) + 0x40))(*(longlong **)(param_1 + 0x58),0x14);
  if (*(int *)(param_1 + 0x50) != 2) {
    local_438 = 0x9f;
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_idProcess == MSGPORT_WORLD",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.cpp"
                      );
  }
  local_428 = (void *)FUN_140068b60(0x1d0);
  if (local_428 == (void *)0x0) {
    lVar6 = 0;
  }
  else {
    lVar6 = FUN_140072430(local_428);
  }
  *(longlong *)(param_1 + 0x60) = lVar6;
  uVar7 = 0;
  if (lVar6 != 0) {
    FUN_140073410(lVar6,param_1 + 8);
    local_428 = operator_new(0x38);
    if (local_428 == (void *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = FUN_140074450(local_428);
    }
    *(longlong *)(param_1 + 0x68) = lVar6;
    uVar7 = 0;
    if (lVar6 != 0) {
      FUN_140074a70(lVar6);
      lVar6 = FUN_14007a4f0();
      *(longlong *)(param_1 + 0x70) = lVar6;
      if (lVar6 == 0) {
        log_InlineLogERROR("CWorldKernel::Create, failed in creating NewbieInfo");
        uVar7 = 0;
      }
      else {
        DAT_140975af8 = param_1;
        uVar7 = FUN_1400650f0(1);
        *(undefined8 *)(param_1 + 0xe8) = uVar7;
        uVar7 = FUN_1400650f0(1);
        *(undefined8 *)(param_1 + 0xf0) = uVar7;
        CIniFile::CIniFile(local_418,"shell.ini","Database");
        CIniFile::SetSection(local_418,"System");
        iVar4 = CIniFile::GetInt(local_418,"SERVE_PORT");
        if (iVar4 != 0) {
          *(int *)(param_1 + 300) = iVar4;
        }
        *(undefined4 *)(param_1 + 0x78) = 0x1e;
        uVar5 = tq::TimeGet(0);
        *(uint *)(param_1 + 0x7c) = uVar5 / 1000;
        CIniFile::SetSection(local_418,"IPADPaymentsClient");
        iVar4 = CIniFile::GetInt(local_418,"IsSupportIPADPayments");
        if (iVar4 == 1) {
          *(undefined1 *)(param_1 + 0x200) = 1;
        }
        CIniFile::SetSection(local_418,"GooglePaymentsClient");
        iVar4 = CIniFile::GetInt(local_418,"IsSupportGooglePayments");
        if (iVar4 == 1) {
          *(undefined1 *)(param_1 + 0x201) = 1;
        }
        CIniFile::SetSection(local_418,"91AuthServerInfo");
        iVar4 = CIniFile::GetInt(local_418,"Is91AccountServer");
        if (iVar4 == 1) {
          *(undefined1 *)(param_1 + 0x203) = 1;
        }
        if (((*(char *)(param_1 + 0x200) == '\0') && (*(char *)(param_1 + 0x201) == '\0')) &&
           (*(char *)(param_1 + 0x203) == '\0')) {
          uVar1 = 0;
        }
        else {
          uVar1 = 1;
        }
        *(undefined1 *)(param_1 + 0x202) = uVar1;
        CIniFile::SetSection(local_418,"AccountServer");
        CIniFile::GetString(local_418,(char *)(param_1 + 0xfc),"SERVERNAME",0x10);
        CIniFile::GetString(local_418,(char *)(param_1 + 0x10c),"LOGINNAME",0x10);
        CIniFile::GetString(local_418,(char *)(param_1 + 0x11c),"PASSWORD",0x10);
        FUN_1400641b0(param_1);
        uVar7 = InstanceGet();
        FUN_140062510(param_1,uVar7);
        FUN_140055080(param_1);
        cVar2 = FUN_140058540(param_1);
        if (cVar2 == '\0') {
          CIniFile::~CIniFile(local_418);
          uVar7 = 0;
        }
        else {
          FUN_140058610(param_1);
          uVar3 = FUN_140058750(param_1);
          *(undefined4 *)(param_1 + 0x1fc) = uVar3;
          uVar3 = FUN_140058800(param_1);
          *(undefined4 *)(param_1 + 0x208) = uVar3;
          FUN_140072f80();
          *(undefined4 *)(param_1 + 0x84) = 10;
          uVar5 = tq::TimeGet(0);
          *(uint *)(param_1 + 0x88) = uVar5 / 1000;
          *(undefined4 *)(param_1 + 0x8c) = 0;
          *(undefined4 *)(param_1 + 0x90) = 0x1e;
          uVar5 = tq::TimeGet(0);
          *(uint *)(param_1 + 0x94) = uVar5 / 1000;
          *(undefined4 *)(param_1 + 0x178) = 300;
          uVar5 = tq::TimeGet(0);
          *(uint *)(param_1 + 0x17c) = uVar5 / 1000;
          *(undefined4 *)(param_1 + 0xe0) = 0x1e;
          uVar5 = tq::TimeGet(0);
          *(uint *)(param_1 + 0xe4) = uVar5 / 1000;
          *(undefined4 *)(param_1 + 0x1e4) = 10;
          uVar5 = tq::TimeGet(0);
          *(uint *)(param_1 + 0x1e8) = uVar5 / 1000;
          CIniFile::~CIniFile(local_418);
          uVar7 = 1;
        }
      }
    }
  }
  return uVar7;
}

// ==== CWorldKernel::vfunc_3  @140065630  [high:rtti-vtable]  (orig: FUN_140065630)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140065630(longlong param_1,longlong *param_2)

{
  int iVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong *plVar6;
  char cVar7;
  ulong uVar8;
  undefined8 uVar9;
  longlong lVar10;
  int *piVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  longlong *plVar14;
  longlong lVar15;
  longlong *plVar16;
  uint uVar17;
  undefined1 auStack_148 [32];
  int *local_128;
  longlong *local_118;
  longlong *plStack_110;
  longlong *local_108;
  longlong *plStack_100;
  longlong *local_f8;
  longlong local_f0;
  longlong local_e8;
  undefined8 local_e0;
  longlong local_d8;
  undefined8 *local_d0;
  undefined1 local_c8 [16];
  int local_b8;
  undefined4 local_b4;
  undefined4 local_b0;
  undefined4 local_ac;
  undefined4 local_a8;
  int local_a4 [19];
  ulonglong local_58;
  
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_148;
  uVar17 = 1;
  local_118 = param_2;
  do {
    uVar8 = CAsyncDBThread::GetWorldUserLoginSerial();
    if (uVar8 == 0) goto LAB_1400659cf;
    puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0x2b0))[1];
    cVar7 = *(char *)((longlong)puVar13 + 0x75);
    puVar4 = *(undefined8 **)(param_1 + 0x2b0);
    while (cVar7 == '\0') {
      if (*(uint *)(puVar13 + 3) < uVar8) {
        puVar12 = (undefined8 *)puVar13[2];
        puVar13 = puVar4;
      }
      else {
        puVar12 = (undefined8 *)*puVar13;
      }
      puVar4 = puVar13;
      puVar13 = puVar12;
      cVar7 = *(char *)((longlong)puVar12 + 0x75);
    }
    puVar13 = *(undefined8 **)(param_1 + 0x2b0);
    local_d0 = puVar4;
    local_d8 = *(longlong *)(param_1 + 0x280);
    if (*(longlong *)(param_1 + 0x280) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar4 == puVar13) || (uVar8 < *(uint *)(puVar4 + 3))) {
      plVar16 = &local_e8;
      local_e0 = *(undefined8 *)(param_1 + 0x2b0);
      local_e8 = *(longlong *)(param_1 + 0x280);
    }
    else {
      plVar16 = &local_d8;
    }
    plVar14 = (longlong *)*plVar16;
    lVar10 = *(longlong *)(param_1 + 0x2b0);
    local_f0 = plVar16[1];
    local_f8 = plVar14;
    if ((plVar14 == (longlong *)0x0) || (plVar14 != *(longlong **)(param_1 + 0x280))) {
      _invalid_parameter_noinfo();
    }
    lVar15 = local_f0;
    if (local_f0 == lVar10) {
      log_InlineLogERROR("CWorldKernel::OnTimer cannot find login serial %u");
      goto LAB_1400659cf;
    }
    if (plVar14 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar14;
    }
    if (lVar15 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    memcpy(&local_b8,(void *)(lVar15 + 0x1c),0x58);
    if (local_b8 == 1) {
      cVar7 = FUN_140060870(param_1,local_b0,local_ac,local_a4);
      if (cVar7 == '\0') {
        (**(code **)(**(longlong **)(param_1 + 0xf0) + 0x30))
                  (*(longlong **)(param_1 + 0xf0),local_b0);
        (**(code **)(**(longlong **)(param_1 + 0xe8) + 0x30))
                  (*(longlong **)(param_1 + 0xe8),local_b0);
      }
    }
    else if (local_b8 == 2) {
      cVar7 = FUN_140060870(param_1,local_b0,local_ac,local_a4);
      if (cVar7 == '\0') {
        (**(code **)(**(longlong **)(param_1 + 0xf0) + 0x30))
                  (*(longlong **)(param_1 + 0xf0),local_b0);
        (**(code **)(**(longlong **)(param_1 + 0xe8) + 0x30))
                  (*(longlong **)(param_1 + 0xe8),local_b0);
      }
      FUN_1400567f0(param_1,local_ac);
      FUN_140064330(param_1,local_b0,local_a8,local_ac);
    }
    else if (local_b8 == 3) {
      local_128 = local_a4;
      cVar7 = FUN_14007ea10(param_1,local_b4,local_b0,local_ac);
      if (cVar7 == '\0') {
        (**(code **)(**(longlong **)(param_1 + 0xf0) + 0x30))
                  (*(longlong **)(param_1 + 0xf0),local_b0);
        (**(code **)(**(longlong **)(param_1 + 0xe8) + 0x30))
                  (*(longlong **)(param_1 + 0xe8),local_b0);
      }
    }
    else if (local_b8 == 4) {
      local_128 = local_a4;
      cVar7 = FUN_14007ea10(param_1,local_b4,local_b0,local_ac);
      if (cVar7 == '\0') {
        (**(code **)(**(longlong **)(param_1 + 0xf0) + 0x30))
                  (*(longlong **)(param_1 + 0xf0),local_b0);
        (**(code **)(**(longlong **)(param_1 + 0xe8) + 0x30))
                  (*(longlong **)(param_1 + 0xe8),local_b0);
      }
      FUN_140064330(param_1,local_b0,local_a8,local_ac);
    }
    else {
      log_InlineLogERROR("CWorldKernel::OnTimer, Login Type(%d) Error.");
    }
    local_108 = (longlong *)*plVar16;
    plStack_100 = (longlong *)plVar16[1];
    FUN_14005d6e0(param_1 + 0x280,local_c8,&local_108);
    uVar17 = uVar17 + 1;
  } while (uVar17 < 0x186a1);
  local_128 = (int *)CONCAT44(local_128._4_4_,0x33d);
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_1400659cf:
  uVar9 = FUN_140054e10();
  FUN_140070370(uVar9,local_118);
  if ((*(char *)(param_1 + 0x203) == '\0') &&
     (uVar8 = tq::TimeGet(0),
     (uint)(*(int *)(param_1 + 0x7c) + *(int *)(param_1 + 0x78)) <= uVar8 / 1000)) {
    uVar8 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x7c) = uVar8 / 1000;
    lVar10 = FUN_140054d10(param_1);
    local_128 = (int *)CONCAT44(local_128._4_4_,0x67);
    FUN_1400558e0(param_1,0,*(undefined4 *)(lVar10 + 0x68),0);
    lVar10 = FUN_140054d10(param_1);
    iVar1 = *(int *)(lVar10 + 0x68);
    piVar11 = (int *)MaxPlayerGet();
    if (iVar1 < *piVar11) {
      cVar7 = FUN_140055110(param_1);
      if (cVar7 == '\0') {
        piVar11 = (int *)(param_1 + 0x130);
        if (*piVar11 != 0) {
          log_InlineLogMessage("Server normal.");
          *piVar11 = 0;
          local_128 = piVar11;
          (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                    (*(longlong **)(param_1 + 0x58),0,0x9c44,0xea65);
        }
      }
      else {
        uVar9 = FUN_140054dc0();
        FUN_140055820(uVar9,0,6);
        piVar11 = (int *)(param_1 + 0x130);
        if (*piVar11 != 2) {
          log_InlineLogMessage("Server busy.");
          *piVar11 = 2;
          local_128 = piVar11;
          (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                    (*(longlong **)(param_1 + 0x58),0,0x9c44,0xea65);
        }
      }
    }
    else {
      uVar9 = FUN_140054dc0();
      FUN_140055820(uVar9,0,7);
      if (*(int *)(param_1 + 0x130) != 1) {
        FUN_140054d10(param_1);
        MaxPlayerGet();
        log_InlineLogMessage("Server full. user amount: %u, g_dwMaxPlayer: %u");
        *(undefined4 *)(param_1 + 0x130) = 1;
      }
    }
  }
  uVar8 = tq::TimeGet(0);
  if ((uint)(*(int *)(param_1 + 0x88) + *(int *)(param_1 + 0x84)) <= uVar8 / 1000) {
    uVar8 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x88) = uVar8 / 1000;
    *(undefined4 *)(param_1 + 0x8c) = 0;
  }
  uVar8 = tq::TimeGet(0);
  if ((uint)(*(int *)(param_1 + 0x94) + *(int *)(param_1 + 0x90)) <= uVar8 / 1000) {
    uVar8 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x94) = uVar8 / 1000;
    FUN_14007ca30(param_1 + 0x98);
  }
  if ((*(char *)(param_1 + 0x203) == '\0') &&
     (uVar8 = tq::TimeGet(0),
     (uint)(*(int *)(param_1 + 0x17c) + *(int *)(param_1 + 0x178)) <= uVar8 / 1000)) {
    uVar8 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x17c) = uVar8 / 1000;
    if (DAT_1409757c4 == '\0') goto LAB_140065e0c;
    plVar16 = *(longlong **)(param_1 + 0x138);
    plVar14 = (longlong *)**(longlong **)(param_1 + 0x168);
    local_118 = plVar16;
    plStack_110 = plVar14;
    while( true ) {
      plVar2 = *(longlong **)(param_1 + 0x168);
      if ((plVar16 == (longlong *)0x0) || (plVar16 != *(longlong **)(param_1 + 0x138))) {
        _invalid_parameter_noinfo();
      }
      if (plVar14 == plVar2) goto LAB_140065de2;
      if (plVar16 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar16;
      }
      if (plVar14 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar10 = plVar14[3];
      if (plVar16 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar15 = 0;
      }
      else {
        lVar15 = *plVar16;
      }
      if (plVar14 == *(longlong **)(lVar15 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      local_128 = (int *)CONCAT44(local_128._4_4_,0x7c);
      cVar7 = FUN_1400558e0(param_1,(int)lVar10,0,0);
      if (cVar7 == '\0') break;
      tq::MyLogSave("gmlog/ChangeServer",&DAT_1406edd98);
      plVar5 = plStack_110;
      plVar2 = local_118;
      if (plVar16 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar14 + 0x21) == '\0') {
        plVar3 = (longlong *)plVar14[2];
        if (*(char *)((longlong)plVar3 + 0x21) == '\0') {
          cVar7 = *(char *)(*plVar3 + 0x21);
          plVar14 = plVar3;
          plVar3 = (longlong *)*plVar3;
          while (plStack_110 = plVar14, cVar7 == '\0') {
            cVar7 = *(char *)(*plVar3 + 0x21);
            plVar14 = plVar3;
            plVar3 = (longlong *)*plVar3;
          }
        }
        else {
          cVar7 = *(char *)(plVar14[1] + 0x21);
          plVar6 = (longlong *)plVar14[1];
          plVar3 = plVar14;
          while ((plVar14 = plVar6, plStack_110 = plVar14, cVar7 == '\0' &&
                 (plVar3 == (longlong *)plVar14[2]))) {
            cVar7 = *(char *)(plVar14[1] + 0x21);
            plVar6 = (longlong *)plVar14[1];
            plVar3 = plVar14;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_108 = plVar2;
      plStack_100 = plVar5;
      FUN_1400162d0(param_1 + 0x138,local_c8);
    }
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406edd70);
  }
LAB_140065de2:
  if (((DAT_1409757c4 != '\0') && (*(char *)(param_1 + 0x203) != '\0')) &&
     (cVar7 = FUN_1400149a0(param_1 + 0xe0), cVar7 != '\0')) {
    FUN_140055b70(param_1);
  }
LAB_140065e0c:
  FUN_140077550(param_1);
  return 1;
}

// ==== CWorldKernel::ClientConnect  @140065e50  [high:log-string]  (orig: FUN_140065e50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140065e50(longlong *param_1,undefined4 param_2,int param_3,undefined8 param_4,int param_5,
                  int param_6)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong lVar5;
  IStringManager *pIVar6;
  undefined1 auStack_638 [32];
  char *local_618;
  undefined8 local_610;
  undefined2 local_608;
  undefined2 local_600;
  undefined4 local_5f8;
  undefined4 local_5f0;
  undefined1 local_5e8;
  longlong local_5d8;
  int local_5d0;
  undefined4 local_5cc;
  longlong *local_5c8;
  undefined8 local_5c0;
  undefined1 local_5b8 [24];
  undefined4 local_5a0;
  undefined1 local_59c [100];
  undefined4 local_538;
  undefined4 local_534;
  undefined4 local_530;
  int local_52c;
  int local_528;
  char local_524 [76];
  char local_4d8 [1023];
  undefined1 local_d9;
  char local_98 [80];
  ulonglong local_48;
  
  local_5c0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_638;
  local_5d8 = param_4;
  local_5d0 = param_3;
  local_5cc = param_2;
  local_5c8 = param_1;
  if ((param_5 == -1) || (param_6 == 0)) {
    local_618 = (char *)CONCAT44(local_618._4_4_,0x72c);
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (((char)param_1[0x3c] != '\0') && (*(char *)((longlong)param_1 + 0x203) != '\0')) {
    _snprintf(local_4d8,0x400,"SELECT * FROM cq_appointment_account WHERE account=\'%s\'");
    local_d9 = 0;
    plVar3 = (longlong *)InstanceGet();
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,local_4d8,1);
    if (plVar3 == (longlong *)0x0) {
      local_618 = (char *)CONCAT44(local_618._4_4_,0x735);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar4 = FUN_140054e10();
      FUN_1400674b0(uVar4,param_5,0);
      return;
    }
    lVar5 = (**(code **)(*plVar3 + 0x40))(plVar3);
    if (lVar5 == 0) {
      uVar4 = FUN_140054e10();
      FUN_1400674b0(uVar4,param_5,0);
      (**(code **)*plVar3)(plVar3);
      return;
    }
    (**(code **)*plVar3)(plVar3);
  }
  lVar5 = (**(code **)(*(longlong *)param_1[0x1e] + 0x40))((longlong *)param_1[0x1e],param_2);
  if (lVar5 != 0) {
    cVar1 = FUN_1400737b0(lVar5);
    if (cVar1 != '\0') {
      cVar1 = FUN_14007c950(param_1 + 0x13,param_2);
      if (cVar1 != '\0') {
        FUN_14007a560(local_4d8);
        pIVar6 = theInstance();
        uVar4 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_GIVE_BACK");
        local_5e8 = 1;
        local_5f0 = 0;
        local_5f8 = 0;
        local_600 = 0;
        local_608 = 0x835;
        local_610 = CONCAT44(local_610._4_4_,0xffffff);
        local_618 = (char *)0x0;
        iVar2 = FUN_14007a620(local_4d8,"SYSTEM","ALLUSERS",uVar4);
        if (iVar2 != 0) {
          (**(code **)(*param_1 + 0x38))(param_1,param_5,local_4d8);
        }
        uVar4 = FUN_140054e10();
        FUN_1400674b0(uVar4,param_5,param_2);
        (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_2);
        FUN_14007a5e0(local_4d8);
        return;
      }
      uVar4 = FUN_140054e10();
      iVar2 = FUN_14006eb00(uVar4,param_2);
      if ((iVar2 == 0) && (cVar1 = FUN_1400561b0(param_1), cVar1 == '\0')) {
        FUN_14007a560(local_4d8);
        pIVar6 = theInstance();
        uVar4 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_SERVER_BUSY");
        local_5e8 = 1;
        local_5f0 = 0;
        local_5f8 = 0;
        local_600 = 0;
        local_608 = 0x835;
        local_610 = CONCAT44(local_610._4_4_,0xffffff);
        local_618 = (char *)0x0;
        iVar2 = FUN_14007a620(local_4d8,"SYSTEM","ALLUSERS",uVar4);
        if (iVar2 != 0) {
          (**(code **)(*param_1 + 0x38))(param_1,param_5,local_4d8);
        }
        uVar4 = FUN_140054e10();
        FUN_1400674b0(uVar4,param_5,param_2);
        (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_2);
        FUN_14007a5e0(local_4d8);
        return;
      }
      local_98[0] = '\0';
      local_98[1] = '\0';
      local_98[2] = '\0';
      local_98[3] = '\0';
      local_98[4] = '\0';
      local_98[5] = '\0';
      local_98[6] = '\0';
      local_98[7] = '\0';
      local_98[8] = '\0';
      local_98[9] = '\0';
      local_98[10] = '\0';
      local_98[0xb] = '\0';
      local_98[0xc] = '\0';
      local_98[0xd] = '\0';
      local_98[0xe] = '\0';
      local_98[0xf] = '\0';
      local_98[0x10] = '\0';
      local_98[0x11] = '\0';
      local_98[0x12] = '\0';
      local_98[0x13] = '\0';
      local_98[0x14] = '\0';
      local_98[0x15] = '\0';
      local_98[0x16] = '\0';
      local_98[0x17] = '\0';
      local_98[0x18] = '\0';
      local_98[0x19] = '\0';
      local_98[0x1a] = '\0';
      local_98[0x1b] = '\0';
      local_98[0x1c] = '\0';
      local_98[0x1d] = '\0';
      local_98[0x1e] = '\0';
      local_98[0x1f] = '\0';
      local_98[0x20] = '\0';
      local_98[0x21] = '\0';
      local_98[0x22] = '\0';
      local_98[0x23] = '\0';
      local_98[0x24] = '\0';
      local_98[0x25] = '\0';
      local_98[0x26] = '\0';
      local_98[0x27] = '\0';
      local_98[0x28] = '\0';
      local_98[0x29] = '\0';
      local_98[0x2a] = '\0';
      local_98[0x2b] = '\0';
      local_98[0x2c] = '\0';
      local_98[0x2d] = '\0';
      local_98[0x2e] = '\0';
      local_98[0x2f] = '\0';
      local_98[0x30] = '\0';
      local_98[0x31] = '\0';
      local_98[0x32] = '\0';
      local_98[0x33] = '\0';
      local_98[0x34] = '\0';
      local_98[0x35] = '\0';
      local_98[0x36] = '\0';
      local_98[0x37] = '\0';
      local_98[0x38] = '\0';
      local_98[0x39] = '\0';
      local_98[0x3a] = '\0';
      local_98[0x3b] = '\0';
      local_98[0x3c] = '\0';
      local_98[0x3d] = '\0';
      local_98[0x3e] = '\0';
      local_98[0x3f] = '\0';
      local_98[0x40] = '\0';
      tq::SafeCopy(local_98,(char *)(lVar5 + 0x10),0x41);
      cVar1 = FUN_1400737b0(lVar5);
      if ((cVar1 != '\0') && (*(int *)(lVar5 + 0xc) == param_3)) {
        local_5d8 = FUN_140054bc0();
        local_610 = 0;
        local_618._0_4_ = param_5;
        cVar1 = FUN_1400737f0(local_5d8,param_2,param_3,param_4);
        if (cVar1 == '\0') {
          local_618 = (char *)CONCAT44(local_618._4_4_,0x771);
          log_InlineLogERROR(&DAT_1406d9c10);
          return;
        }
        (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_2);
        (**(code **)(*(longlong *)param_1[0x1d] + 0x28))();
        local_534 = 0;
        memset(local_524,0,0x41);
        local_538 = 2;
        local_52c = param_5;
        local_528 = param_6;
        local_530 = param_2;
        tq::SafeCopy(local_524,local_98,0x41);
        *(int *)(param_1 + 0x58) = (int)param_1[0x58] + 1;
        local_5a0 = (undefined4)param_1[0x58];
        memcpy(local_59c,&local_538,0x58);
        FUN_14005d530(param_1 + 0x50,local_5b8,&local_5a0);
        memset(local_4d8,0,0x400);
        sprintf(local_4d8," worlduserlogin****worlduserlogin [%u]");
        FUN_140054dc0();
        plVar3 = (longlong *)InstanceGet();
        (**(code **)(*plVar3 + 0x30))(plVar3,local_4d8,0,0);
        return;
      }
      cVar1 = FUN_1400737b0(lVar5);
      if ((cVar1 != '\0') && (*(int *)(lVar5 + 0xc) != param_3)) {
        local_610 = CONCAT44(local_610._4_4_,0x788);
        local_618 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.cpp";
        log_InlineLogWARNING
                  (
                  "CWorldKernel::ClientConnect() checkdata fault, Account: %u, dwData: %u, szInfo:%s at %s, %d"
                  );
      }
      uVar4 = FUN_140054e10();
      FUN_1400674b0(uVar4,param_5,param_2);
      (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_2);
      return;
    }
    (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_2);
  }
  (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_2);
  local_5d8 = FUN_140073590(0x88);
  if (local_5d8 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_1400736b0(local_5d8);
  }
  local_610 = 0;
  local_618._0_4_ = param_5;
  cVar1 = FUN_1400737f0(uVar4,param_2,param_3,param_4);
  if (cVar1 == '\0') {
    local_618 = (char *)CONCAT44(local_618._4_4_,0x794);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*(longlong *)param_1[0x1d] + 0x28))((longlong *)param_1[0x1d],uVar4);
    FUN_1400567f0(param_1,param_5);
    FUN_140064330(param_1,param_2,param_6,param_5);
  }
  return;
}

// ==== CWorldKernel::helper_1400667c0  @1400667c0  [medium:callgraph-r0]  (orig: FUN_1400667c0)
void FUN_1400667c0(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined1 local_res8;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar3 = FUN_140065160(uVar1,param_1[4],uVar2,local_res8,local_res8,0);
    FUN_140066540(lVar3,param_1[4],param_1 + 2,local_res8);
    param_1[4] = lVar3;
  }
  return;
}

// ==== CWorldKernel::ctor_or_dtor  @140066890  [high:vtable-assign]  (orig: FUN_140066890)
undefined8 * FUN_140066890(undefined8 *param_1)

{
  __time32_t _Var1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  *param_1 = IWorld::vftable;
  *param_1 = CWorldKernel::vftable;
  param_1[1] = CWorldKernel::vftable;
  FUN_1400546e0(param_1 + 2);
  plVar4 = (longlong *)0x0;
  param_1[0xe] = 0;
  *(undefined4 *)(param_1 + 0xf) = 0;
  *(undefined4 *)((longlong)param_1 + 0x7c) = 0;
  *(undefined4 *)((longlong)param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x11) = 0;
  *(undefined4 *)(param_1 + 0x12) = 0;
  *(undefined4 *)((longlong)param_1 + 0x94) = 0;
  CXMLParserRoot::CXMLParserRoot((CXMLParserRoot *)(param_1 + 0x13));
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)((longlong)param_1 + 0xe4) = 0;
  *(undefined4 *)(param_1 + 0x26) = 0;
  FUN_1400194a0(param_1 + 0x27);
  *(undefined4 *)(param_1 + 0x2f) = 0;
  *(undefined4 *)((longlong)param_1 + 0x17c) = 0;
  plVar2 = operator_new(8);
  plVar3 = plVar4;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x30);
    plVar3 = plVar2;
  }
  param_1[0x30] = plVar3;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  plVar2 = operator_new(8);
  plVar3 = plVar4;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x36);
    plVar3 = plVar2;
  }
  param_1[0x36] = plVar3;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  *(undefined1 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1e4) = 0;
  *(undefined4 *)(param_1 + 0x3d) = 0;
  *(undefined4 *)((longlong)param_1 + 500) = 0;
  *(undefined1 *)(param_1 + 0x3f) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1fc) = 0;
  *(undefined1 *)(param_1 + 0x40) = 0;
  *(undefined1 *)((longlong)param_1 + 0x201) = 0;
  *(undefined1 *)((longlong)param_1 + 0x202) = 0;
  *(undefined1 *)((longlong)param_1 + 0x203) = 0;
  *(undefined4 *)(param_1 + 0x41) = 0;
  FUN_1400546e0(param_1 + 0x42);
  plVar3 = operator_new(8);
  if (plVar3 != (longlong *)0x0) {
    *plVar3 = (longlong)(param_1 + 0x4a);
    plVar4 = plVar3;
  }
  param_1[0x4a] = plVar4;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  FUN_1400628d0(param_1 + 0x50);
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)((longlong)param_1 + 0x8c) = 0;
  *(undefined4 *)(param_1 + 10) = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  *(undefined4 *)(param_1 + 0x1f) = 0;
  DAT_1409757c4 = 0;
  *(undefined1 *)((longlong)param_1 + 0xfc) = 0;
  *(undefined1 *)((longlong)param_1 + 0x10c) = 0;
  *(undefined1 *)((longlong)param_1 + 0x11c) = 0;
  *(undefined4 *)((longlong)param_1 + 300) = 0x16b8;
  *(undefined4 *)((longlong)param_1 + 0x204) = 0;
  _Var1 = _time32((__time32_t *)0x0);
  *(__time32_t *)(param_1 + 0x10) = _Var1;
  *(undefined4 *)(param_1 + 0x3e) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1ec) = 6;
  FUN_140016690(param_1 + 0x27);
  *(undefined4 *)(param_1 + 0x3d) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1e4) = 0;
  return param_1;
}

// ==== CWorldKernel::ctor_or_dtor  @140066ae0  [high:vtable-assign]  (orig: FUN_140066ae0)
void FUN_140066ae0(undefined8 *param_1)

{
  *param_1 = CWorldKernel::vftable;
  param_1[1] = CWorldKernel::vftable;
  FUN_14005fcc0(param_1 + 0x50);
  operator_delete((void *)param_1[0x50]);
  if ((void *)param_1[0x4d] != (void *)0x0) {
    operator_delete((void *)param_1[0x4d]);
  }
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  operator_delete((void *)param_1[0x4a]);
  FUN_140050610(param_1 + 0x42);
  operator_delete((void *)param_1[0x42]);
  if ((void *)param_1[0x39] != (void *)0x0) {
    operator_delete((void *)param_1[0x39]);
  }
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  operator_delete((void *)param_1[0x36]);
  if (param_1[0x33] != 0) {
    FUN_140066540(param_1[0x33],param_1[0x34],param_1 + 0x32,(ulonglong)param_1 & 0xff);
    operator_delete((void *)param_1[0x33]);
  }
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  operator_delete((void *)param_1[0x30]);
  FUN_140018350(param_1 + 0x27);
  operator_delete((void *)param_1[0x27]);
  FUN_14007cee0(param_1 + 0x13);
  FUN_140050610(param_1 + 2);
  operator_delete((void *)param_1[2]);
  *param_1 = IWorld::vftable;
  return;
}

// ==== CWorldKernel::vfunc_0  @140066c60  [high:rtti-vtable]  (orig: FUN_140066c60)
void * FUN_140066c60(void *param_1,uint param_2)

{
  FUN_140066ae0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CWorldKernel::vfunc_4  @140066c90  [high:rtti-vtable]  (orig: FUN_140066c90)
undefined8 FUN_140066c90(undefined8 *param_1)

{
  char cVar1;
  ulonglong uVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  ulonglong uVar8;
  longlong lVar9;
  longlong lVar10;
  
  if ((longlong)(param_1[0x34] - param_1[0x33]) / 0x30 != 0) {
    uVar8 = param_1[0x33];
    if ((ulonglong)param_1[0x34] < uVar8) {
      _invalid_parameter_noinfo();
    }
    plVar7 = (longlong *)param_1[0x30];
    uVar2 = param_1[0x34];
    if (uVar2 < (ulonglong)param_1[0x33]) {
      _invalid_parameter_noinfo();
    }
    plVar3 = (longlong *)param_1[0x30];
    lVar10 = 0;
    while( true ) {
      if ((plVar7 == (longlong *)0x0) || (plVar7 != plVar3)) {
        _invalid_parameter_noinfo();
      }
      if (uVar8 == uVar2) break;
      if (plVar7 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar7;
      }
      if (*(ulonglong *)(lVar9 + 0x20) <= uVar8) {
        _invalid_parameter_noinfo();
      }
      if ((*(longlong *)(uVar8 + 0x20) - *(longlong *)(uVar8 + 0x18)) / 0x28 != 0) {
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = lVar10;
        }
        else {
          lVar9 = *plVar7;
        }
        if (*(ulonglong *)(lVar9 + 0x20) <= uVar8) {
          _invalid_parameter_noinfo();
        }
        FUN_140037e80(uVar8);
      }
      if (plVar7 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar7;
      }
      if (*(ulonglong *)(lVar9 + 0x20) <= uVar8) {
        _invalid_parameter_noinfo();
      }
      uVar8 = uVar8 + 0x30;
    }
    FUN_1400667c0(param_1 + 0x30);
  }
  lVar10 = 0;
  FUN_14005fa10(param_1 + 0x36);
  if ((param_1[0x4e] - param_1[0x4d] & 0xfffffffffffffff8) != 0) {
    plVar7 = (longlong *)param_1[0x4d];
    if ((longlong *)param_1[0x4e] < plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar3 = (longlong *)param_1[0x4a];
    plVar4 = (longlong *)param_1[0x4e];
    if (plVar4 < (longlong *)param_1[0x4d]) {
      _invalid_parameter_noinfo();
    }
    plVar5 = (longlong *)param_1[0x4a];
    while( true ) {
      if ((plVar3 == (longlong *)0x0) || (plVar3 != plVar5)) {
        _invalid_parameter_noinfo();
      }
      if (plVar7 == plVar4) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar3;
      }
      if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
        _invalid_parameter_noinfo();
      }
      if (*plVar7 != 0) {
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = lVar10;
        }
        else {
          lVar9 = *plVar3;
        }
        if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
          _invalid_parameter_noinfo();
        }
        operator_delete((void *)*plVar7);
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = lVar10;
        }
        else {
          lVar9 = *plVar3;
        }
        if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
          _invalid_parameter_noinfo();
        }
        *plVar7 = 0;
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar3;
      }
      if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
        _invalid_parameter_noinfo();
      }
      plVar7 = plVar7 + 1;
    }
    FUN_14005d470(param_1 + 0x4a);
  }
  if (param_1[0x2e] != 0) {
    plVar7 = *(longlong **)param_1[0x2d];
    plVar3 = (longlong *)param_1[0x27];
    while( true ) {
      plVar4 = (longlong *)param_1[0x2d];
      if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)param_1[0x27])) {
        _invalid_parameter_noinfo();
      }
      if (plVar7 == plVar4) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar3;
      }
      if (plVar7 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar3;
      }
      if (plVar7 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::MyLogSave("gmlog/ChangeServer",&DAT_1406ee168);
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar7 + 0x21) == '\0') {
        plVar4 = (longlong *)plVar7[2];
        if (*(char *)((longlong)plVar4 + 0x21) == '\0') {
          cVar1 = *(char *)(*plVar4 + 0x21);
          plVar7 = plVar4;
          plVar4 = (longlong *)*plVar4;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*plVar4 + 0x21);
            plVar7 = plVar4;
            plVar4 = (longlong *)*plVar4;
          }
        }
        else {
          cVar1 = *(char *)(plVar7[1] + 0x21);
          plVar5 = (longlong *)plVar7[1];
          plVar4 = plVar7;
          while ((plVar7 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar7[2]))) {
            cVar1 = *(char *)(plVar7[1] + 0x21);
            plVar5 = (longlong *)plVar7[1];
            plVar4 = plVar7;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    cVar1 = *(char *)((longlong)*(longlong **)(param_1[0x2d] + 8) + 0x21);
    plVar7 = *(longlong **)(param_1[0x2d] + 8);
    while (cVar1 == '\0') {
      FUN_140015820(param_1 + 0x27,plVar7[2]);
      plVar3 = (longlong *)*plVar7;
      operator_delete(plVar7);
      plVar7 = plVar3;
      cVar1 = *(char *)((longlong)plVar3 + 0x21);
    }
    *(undefined8 *)(param_1[0x2d] + 8) = param_1[0x2d];
    param_1[0x2e] = 0;
    *(undefined8 *)param_1[0x2d] = param_1[0x2d];
    *(undefined8 *)(param_1[0x2d] + 0x10) = param_1[0x2d];
  }
  if (param_1[0xc] != 0) {
    FUN_140072c60();
    puVar6 = (undefined8 *)param_1[0xc];
    if (puVar6 != (undefined8 *)0x0) {
      (**(code **)*puVar6)(puVar6,1);
    }
  }
  puVar6 = (undefined8 *)param_1[0xd];
  if (puVar6 != (undefined8 *)0x0) {
    (**(code **)*puVar6)(puVar6,1);
  }
  (**(code **)(*(longlong *)param_1[0xb] + 0x30))();
  if ((DAT_140975af8 != 0) || (log_InlineLogERROR(&DAT_1406d9c10), DAT_140975af8 != 0)) {
    FUN_140055820(DAT_140975af8,0,8);
  }
  if (param_1[0x1d] != 0) {
    (**(code **)(*(longlong *)param_1[0x1d] + 8))();
  }
  if (param_1[0x1e] != 0) {
    (**(code **)(*(longlong *)param_1[0x1e] + 8))();
  }
  if (param_1[0xe] != 0) {
    FUN_1400792c0(param_1[0xe]);
    param_1[0xe] = 0;
  }
  (**(code **)*param_1)(param_1,1);
  return 1;
}

// ==== CWorldKernel::helper_140067580  @140067580  [medium:callgraph-r0]  (orig: FUN_140067580)
void FUN_140067580(void)

{
  return;
}

// ==== CWorldKernel::helper_140067590  @140067590  [medium:callgraph-r2]  (orig: FUN_140067590)
void FUN_140067590(void)

{
  return;
}

// ==== CWorldKernel::helper_1400675d0  @1400675d0  [medium:callgraph-r1]  (orig: FUN_1400675d0)
longlong * FUN_1400675d0(longlong *param_1,longlong param_2)

{
  if ((*param_1 == 0) && (param_2 != 0)) {
    *param_1 = param_2;
    return param_1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  *param_1 = param_2;
  return param_1;
}

// ==== CWorldKernel::helper_140068410  @140068410  [medium:callgraph-r1]  (orig: FUN_140068410)
longlong FUN_140068410(longlong param_1,int param_2)

{
  ulong uVar1;
  __time64_t _Var2;
  
  uVar1 = tq::TimeGet(0);
  if (uVar1 / 1000 < (uint)(param_2 + *(int *)(param_1 + 4))) {
    return (ulonglong)(uint3)((uint)*(int *)(param_1 + 4) >> 8) << 8;
  }
  _Var2 = _time64((__time64_t *)0x0);
  if (*(int *)(param_1 + 4) + param_2 * 2 <= _Var2) {
    uVar1 = tq::TimeGet(0);
    *(uint *)(param_1 + 4) = uVar1 / 1000;
    return CONCAT71((uint7)((ulonglong)uVar1 * 0x10624dd3 >> 8) & 0xffffff,1);
  }
  param_2 = *(int *)(param_1 + 4) + param_2;
  *(int *)(param_1 + 4) = param_2;
  return CONCAT71((uint7)(uint3)((uint)param_2 >> 8),1);
}

// ==== CWorldKernel::helper_140068b60  @140068b60  [medium:callgraph-r0]  (orig: FUN_140068b60)
void FUN_140068b60(__uint64 param_1)

{
  if ((DAT_140975b18 & 1) == 0) {
    DAT_140975b18 = DAT_140975b18 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975b10,"CUserList");
    atexit((_func_5014 *)&LAB_1406d65d0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140068bb5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140975b10,param_1);
  return;
}

// ==== CWorldKernel::helper_14006a150  @14006a150  [medium:callgraph-r2]  (orig: FUN_14006a150)
int FUN_14006a150(longlong param_1)

{
  ulong uVar1;
  
  *(undefined4 *)(param_1 + 0x100) = 0x78;
  uVar1 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x104) = uVar1 / 1000;
  return uVar1 * 0x10624dd3;
}

// ==== CWorldKernel::helper_14006a190  @14006a190  [medium:callgraph-r1]  (orig: FUN_14006a190)
ulonglong FUN_14006a190(longlong param_1)

{
  int iVar1;
  __time32_t _Var2;
  ulong uVar3;
  uint uVar4;
  ulonglong uVar5;
  undefined8 uVar6;
  
  if (*(int *)(param_1 + 0x78) < DAT_140949794) {
    _Var2 = _time32((__time32_t *)0x0);
    *(__time32_t *)(param_1 + 0x68) = _Var2;
    uVar3 = tq::TimeGet(0);
    uVar5 = (ulonglong)uVar3 * 0x10624dd3 & 0xffffffff;
    if (*(int *)(param_1 + 0x70) + 0xb4U <= uVar3 / 1000) {
      uVar3 = tq::TimeGet(0);
      *(uint *)(param_1 + 0x70) = uVar3 / 1000;
      if (DAT_140975af8 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      uVar5 = FUN_140055820(DAT_140975af8,*(undefined4 *)(param_1 + 0x74),9);
      return uVar5;
    }
  }
  else {
    if (DAT_140975af8 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar5 = DAT_140975af8;
    if (*(int *)(DAT_140975af8 + 0xf8) == 3) {
      iVar1 = *(int *)(param_1 + 0x68);
      uVar4 = _time32((__time32_t *)0x0);
      uVar5 = (ulonglong)uVar4;
      if (iVar1 + 10 < (int)uVar4) {
        *(int *)(param_1 + 0x68) = iVar1 + 0xb4;
        uVar6 = FUN_140054dc0();
        uVar5 = FUN_140055820(uVar6,*(undefined4 *)(param_1 + 0x74),2);
      }
    }
  }
  return uVar5;
}

// ==== CWorldKernel::helper_14006ae10  @14006ae10  [medium:callgraph-r3]  (orig: FUN_14006ae10)
void FUN_14006ae10(undefined8 *param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = *param_3;
    }
    param_1 = param_1 + 1;
  }
  return;
}

// ==== CWorldKernel::helper_14006beb0  @14006beb0  [medium:callgraph-r2]  (orig: FUN_14006beb0)
undefined8 * FUN_14006beb0(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CWorldKernel::helper_14006bfd0  @14006bfd0  [medium:callgraph-r3]  (orig: FUN_14006bfd0)
undefined8 *
FUN_14006bfd0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14006a8e0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CWorldKernel::helper_14006dc80  @14006dc80  [medium:callgraph-r3]  (orig: FUN_14006dc80)
longlong * FUN_14006dc80(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14006dddd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14006de0c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14006dddd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_14006bfd0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14006de0c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CWorldKernel::helper_14006e250  @14006e250  [medium:callgraph-r0]  (orig: FUN_14006e250)
longlong FUN_14006e250(longlong param_1,longlong param_2)

{
  char cVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  char *pcVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  
  plVar3 = *(longlong **)(param_1 + 0x18);
  plVar7 = (longlong *)**(undefined8 **)(param_1 + 0x48);
  lVar8 = 0;
  do {
    plVar4 = *(longlong **)(param_1 + 0x48);
    if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x18))) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar4) {
      return 0;
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar8;
    }
    else {
      lVar9 = *plVar3;
    }
    if (plVar7 == *(longlong **)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    pcVar6 = (char *)(plVar7[4] + 4);
    lVar9 = param_2 - (longlong)pcVar6;
    do {
      cVar1 = *pcVar6;
      cVar2 = pcVar6[lVar9];
      if (cVar1 != cVar2) break;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    if (cVar1 == cVar2) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar8 = *plVar3;
      }
      if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      return plVar7[4];
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar4 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar4 + 0x29);
        plVar7 = plVar4;
        plVar4 = (longlong *)*plVar4;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar4 + 0x29);
          plVar7 = plVar4;
          plVar4 = (longlong *)*plVar4;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar5 = (longlong *)plVar7[1];
        plVar4 = plVar7;
        while ((plVar7 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar5 = (longlong *)plVar7[1];
          plVar4 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CWorldKernel::helper_14006e750  @14006e750  [medium:callgraph-r1]  (orig: FUN_14006e750)
void FUN_14006e750(longlong param_1,longlong param_2,int *param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  int *piVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  
  if (param_2 != 0) {
    plVar2 = *(longlong **)(param_1 + 0x18);
    plVar6 = (longlong *)**(undefined8 **)(param_1 + 0x48);
    while( true ) {
      plVar3 = *(longlong **)(param_1 + 0x48);
      if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x18))) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 == plVar3) break;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      piVar4 = (int *)plVar6[4];
      if ((param_3 == (int *)0x0) || (*param_3 != *piVar4)) {
        if (DAT_140975af8 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        (**(code **)(*DAT_140975af8 + 0x38))(DAT_140975af8,piVar4[0x18],param_2);
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        plVar3 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar6 = plVar3;
          plVar3 = (longlong *)*plVar3;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*plVar3 + 0x29);
            plVar6 = plVar3;
            plVar3 = (longlong *)*plVar3;
          }
        }
        else {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar5 = (longlong *)plVar6[1];
          plVar3 = plVar6;
          while ((plVar6 = plVar5, cVar1 == '\0' && (plVar3 == (longlong *)plVar6[2]))) {
            cVar1 = *(char *)(plVar6[1] + 0x29);
            plVar5 = (longlong *)plVar6[1];
            plVar3 = plVar6;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CWorldKernel::helper_14006e8e0  @14006e8e0  [medium:callgraph-r0]  (orig: FUN_14006e8e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14006e8e0(undefined8 param_1,undefined8 param_2,longlong param_3,undefined8 param_4,
                  undefined8 param_5,undefined4 param_6,undefined2 param_7)

{
  int iVar1;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  undefined4 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1088];
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  if (param_3 == 0) {
    local_4c8 = CONCAT44(local_4c8._4_4_,0x3ff);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_14007a560(local_478);
    local_498 = 1;
    local_4a0 = 0;
    local_4a8 = 0;
    local_4b0 = 0;
    local_4b8 = param_7;
    local_4c0 = param_6;
    local_4c8 = param_5;
    iVar1 = FUN_14007a620(local_478,param_2,"ALLUSERS",param_3);
    if (iVar1 != 0) {
      FUN_14006e750(param_1,local_478,param_4);
    }
    FUN_14007a5e0(local_478);
  }
  return;
}

// ==== CWorldKernel::helper_14006eb00  @14006eb00  [medium:callgraph-r0]  (orig: FUN_14006eb00)
undefined4 FUN_14006eb00(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 400))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 400);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 400);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x160);
  if (*(longlong *)(param_1 + 0x160) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 400);
    local_28 = *(longlong *)(param_1 + 0x160);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 400);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x160))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CWorldKernel::helper_14006ee80  @14006ee80  [medium:callgraph-r1]  (orig: FUN_14006ee80)
longlong FUN_14006ee80(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_14006beb0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_14006d4e0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CWorldKernel::helper_14006efc0  @14006efc0  [medium:callgraph-r1]  (orig: FUN_14006efc0)
longlong * FUN_14006efc0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CWorldKernel::helper_14006f1d0  @14006f1d0  [medium:callgraph-r1]  (orig: FUN_14006f1d0)
longlong * FUN_14006f1d0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x49) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x49) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CWorldKernel::helper_14006f620  @14006f620  [medium:callgraph-r2]  (orig: FUN_14006f620)
undefined8 * FUN_14006f620(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_14006bfd0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_14006bfd0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_14006bfd0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_14006bfd0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_14006bfd0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_14006bfd0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_14006bfd0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_14006dc80(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CWorldKernel::helper_14006ffe0  @14006ffe0  [medium:callgraph-r2]  (orig: FUN_14006ffe0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_14006ffe0(undefined8 param_1,undefined8 param_2,longlong param_3)

{
  int iVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  ulonglong uVar3;
  longlong *plVar4;
  undefined1 auStack_4d8 [32];
  longlong local_4b8;
  undefined4 local_4b0;
  undefined2 local_4a8;
  undefined2 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined1 local_488;
  undefined8 local_478;
  undefined1 local_468 [1088];
  ulonglong local_28;
  
  local_478 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (param_3 == 0) {
    local_4b8 = CONCAT44(local_4b8._4_4_,0x19e);
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = FUN_14006e3a0();
  if (lVar2 == 0) {
    return 0;
  }
  FUN_14007a560(local_468);
  plVar4 = (longlong *)0x0;
  local_488 = 1;
  local_490 = 0;
  local_498 = 0;
  local_4a0 = 0;
  local_4a8 = 0x835;
  local_4b0 = 0xffffff;
  local_4b8 = 0;
  iVar1 = FUN_14007a620(local_468,"SYSTEM","ALLUSERS",param_3);
  if (iVar1 != 0) {
    if (DAT_140975af8 == (longlong *)0x0) {
      local_4b8 = CONCAT44(local_4b8._4_4_,0x128);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    (**(code **)(*DAT_140975af8 + 0x38))(DAT_140975af8,*(undefined4 *)(lVar2 + 0x60),local_468);
  }
  FUN_14007a5e0(local_468);
  local_4b8 = param_3;
  log_InlineLogWARNING(&DAT_1406eefa0);
  if (DAT_140975af8 == (longlong *)0x0) {
    local_4b8 = CONCAT44(local_4b8._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
    if (DAT_140975af8 == (longlong *)0x0) goto LAB_14007015d;
  }
  plVar4 = DAT_140975af8 + 1;
LAB_14007015d:
  uVar3 = (**(code **)(*plVar4 + 0x18))(plVar4,*(undefined4 *)(lVar2 + 0x60));
  return uVar3;
}

// ==== CWorldKernel::helper_140070370  @140070370  [medium:callgraph-r0]  (orig: FUN_140070370)
void FUN_140070370(longlong param_1,undefined8 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  ulong uVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  bool bVar8;
  
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x48);
  plVar1 = *(longlong **)(param_1 + 0x18);
  do {
    while( true ) {
      while( true ) {
        plVar6 = *(longlong **)(param_1 + 0x48);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x18))) {
          _invalid_parameter_noinfo();
        }
        if (plVar5 == plVar6) {
          cVar3 = FUN_140068410(param_1 + 0xc,300);
          if (cVar3 != '\0') {
            *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
            *(int *)(param_1 + 8) = *(int *)(param_1 + 8) % 0x18;
          }
          return;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar1;
        }
        if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar7 = plVar5[4];
        if (((lVar7 != 0) && (FUN_14006a190(lVar7,param_2), *(int *)(lVar7 + 0x104) != 0)) &&
           (uVar4 = tq::TimeGet(0),
           (uint)(*(int *)(lVar7 + 0x104) + *(int *)(lVar7 + 0x100)) <= uVar4 / 1000)) {
          FUN_140070190(param_1,*(undefined4 *)(lVar7 + 0x74),"Map loading has timed out!",1);
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar6 = plVar5;
      plVar2 = (longlong *)plVar5[2];
      if (*(char *)(plVar5[2] + 0x29) != '\0') break;
      do {
        plVar5 = plVar2;
        plVar2 = (longlong *)*plVar5;
      } while (*(char *)(*plVar5 + 0x29) == '\0');
    }
    do {
      plVar5 = (longlong *)plVar6[1];
      if (*(char *)((longlong)plVar5 + 0x29) != '\0') break;
      bVar8 = plVar6 == (longlong *)plVar5[2];
      plVar6 = plVar5;
    } while (bVar8);
  } while( true );
}

// ==== CWorldKernel::helper_140070620  @140070620  [medium:callgraph-r0]  (orig: FUN_140070620)
void FUN_140070620(longlong param_1,undefined4 param_2,uint param_3)

{
  int iVar1;
  longlong lVar2;
  undefined4 local_res10 [6];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  if (0xd < param_3) {
    if (DAT_140975af8 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    iVar1 = (**(code **)(**(longlong **)(DAT_140975af8 + 0x58) + 0x18))();
    if ((int)param_3 < iVar1) {
      FUN_14006efc0(param_1 + 0x18,&local_18,local_res10);
      if (local_18 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar2 = 0;
      }
      else {
        lVar2 = *local_18;
      }
      if (local_10 == *(longlong *)(lVar2 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *(uint *)(*(longlong *)(local_10 + 0x20) + 0x14) = param_3;
      return;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CWorldKernel::helper_140070750  @140070750  [medium:callgraph-r0]  (orig: FUN_140070750)
bool FUN_140070750(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  bool bVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x48))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x48);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x48);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x18);
  if (*(longlong *)(param_1 + 0x18) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x48);
    local_28 = *(longlong *)(param_1 + 0x18);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0x48);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar8) {
    bVar9 = false;
  }
  else {
    lVar8 = 0;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    bVar9 = 0xd < *(uint *)(*(longlong *)(lVar4 + 0x20) + 0x14);
  }
  return bVar9;
}

// ==== CWorldKernel::helper_140070990  @140070990  [medium:callgraph-r1]  (orig: FUN_140070990)
undefined8 * FUN_140070990(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_14006f620(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CWorldKernel::helper_1400715e0  @1400715e0  [medium:callgraph-r0]  (orig: FUN_1400715e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400715e0(longlong param_1,uint param_2)

{
  int iVar1;
  undefined4 uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  uint *puVar5;
  void *pvVar6;
  undefined8 *puVar7;
  char cVar8;
  __time32_t _Var9;
  ulong uVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  undefined8 uVar13;
  longlong lVar14;
  longlong *plVar15;
  ulonglong *puVar16;
  undefined8 *puVar17;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  uint local_4c0;
  char *local_4b8;
  undefined8 local_4b0;
  uint local_4a8;
  uint local_498 [2];
  longlong local_490;
  longlong *local_488;
  longlong local_480;
  ulonglong local_478;
  undefined8 local_470;
  ulonglong local_468;
  undefined8 *local_460;
  undefined8 local_458;
  char local_450;
  undefined7 uStack_44f;
  undefined1 local_448;
  undefined4 uStack_447;
  undefined2 uStack_443;
  undefined1 uStack_441;
  char local_438;
  undefined1 local_437 [1023];
  ulonglong local_38;
  
  local_458 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  puVar12 = *(undefined8 **)(param_1 + 0x48);
  cVar8 = *(char *)((longlong)puVar12[1] + 0x29);
  puVar7 = puVar12;
  puVar17 = (undefined8 *)puVar12[1];
  while (cVar8 == '\0') {
    if (*(uint *)(puVar17 + 3) < param_2) {
      puVar11 = (undefined8 *)puVar17[2];
      puVar17 = puVar7;
    }
    else {
      puVar11 = (undefined8 *)*puVar17;
    }
    puVar7 = puVar17;
    puVar17 = puVar11;
    cVar8 = *(char *)((longlong)puVar11 + 0x29);
  }
  local_460 = puVar7;
  local_468 = *(ulonglong *)(param_1 + 0x18);
  local_498[0] = param_2;
  local_490 = param_1;
  if (*(ulonglong *)(param_1 + 0x18) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar7 == puVar12) || (param_2 < *(uint *)(puVar7 + 3))) {
    local_470 = *(undefined8 *)(param_1 + 0x48);
    local_478 = *(ulonglong *)(param_1 + 0x18);
    puVar16 = &local_478;
  }
  else {
    puVar16 = &local_468;
  }
  uVar3 = *puVar16;
  local_450 = (char)uVar3;
  uStack_44f = (undefined7)(uVar3 >> 8);
  uVar4 = puVar16[1];
  local_448 = (undefined1)uVar4;
  uStack_447 = (undefined4)(uVar4 >> 8);
  uStack_443 = (undefined2)(uVar4 >> 0x28);
  uStack_441 = (undefined1)(uVar4 >> 0x38);
  lVar14 = *(longlong *)(param_1 + 0x48);
  if ((uVar3 == 0) || (uVar3 != *(ulonglong *)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  if (CONCAT17(uStack_441,CONCAT25(uStack_443,CONCAT41(uStack_447,local_448))) == lVar14) {
    uVar13 = 0;
  }
  else {
    puVar12 = (undefined8 *)FUN_140070990(param_1 + 0x18,local_498);
    puVar5 = (uint *)*puVar12;
    if (puVar5 == (uint *)0x0) {
      local_4c8 = CONCAT44(local_4c8._4_4_,0x163);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pPlayer",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\userlist.cpp")
      ;
      uVar13 = 0;
    }
    else {
      if (DAT_140975af8 == 0) {
        local_4c8 = CONCAT44(local_4c8._4_4_,0x128);
        log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","CWorldKernel::m_pWorld",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.h"
                          );
      }
      cVar8 = FUN_140056a70(DAT_140975af8);
      if (cVar8 == '\0') {
        uVar13 = FUN_140054dc0();
        FUN_140055820(uVar13,puVar5[0x1d],1);
      }
      else {
        uVar13 = FUN_140054dc0();
        FUN_140055c60(uVar13,puVar5[0x1d],*puVar5,0);
      }
      _Var9 = _time32((__time32_t *)0x0);
      if ((int)(puVar5[0x1a] + 0xb4) < _Var9) {
        log_InlineLogWARNING
                  (&DAT_1406ef420,puVar5 + 1,(ulonglong)*puVar5,
                   (ulonglong)(uint)((int)(_Var9 - puVar5[0x1a]) / 0xb4));
      }
      uVar10 = tq::TimeGet(0);
      FUN_14006f1d0(param_1 + 0x70,&local_488,puVar5 + 0x1d);
      lVar14 = *(longlong *)(param_1 + 0xa0);
      if ((local_488 == (longlong *)0x0) || (local_488 != *(longlong **)(param_1 + 0x70))) {
        _invalid_parameter_noinfo();
      }
      if (local_480 != lVar14) {
        if (local_488 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar14 = 0;
        }
        else {
          lVar14 = *local_488;
        }
        if (local_480 == *(longlong *)(lVar14 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        local_450 = '\0';
        uStack_44f = 0;
        local_448 = 0;
        uStack_447 = 0;
        uStack_443 = 0;
        uStack_441 = 0;
        local_4a8 = (uint)*(byte *)(local_480 + 0x3d);
        local_4b0 = CONCAT44(local_4b0._4_4_,(uint)*(byte *)(local_480 + 0x3c));
        local_4b8 = (char *)CONCAT44(local_4b8._4_4_,(uint)*(byte *)(local_480 + 0x3b));
        local_4c0 = (uint)*(byte *)(local_480 + 0x3a);
        local_4c8 = CONCAT44(local_4c8._4_4_,(uint)*(byte *)(local_480 + 0x39));
        _snprintf(&local_450,0xf,"%02x%02x%02x%02x%02x%02x",(ulonglong)*(byte *)(local_480 + 0x38));
        iVar1 = *(int *)(local_480 + 0x24);
        uVar2 = *(undefined4 *)(local_480 + 0x40);
        local_438 = '\0';
        memset(local_437,0,0x3ff);
        local_4b0 = Ordinal_12(uVar2);
        local_4a8 = *(undefined4 *)(local_480 + 0x44);
        local_4b8 = &local_450;
        local_4c8 = *(undefined8 *)(local_480 + 0x30);
        local_4c0 = (uVar10 - iVar1) / 1000;
        _snprintf(&local_438,0x3ff,
                  "INSERT INTO login_rcd SET account_id=%u,login_time=%I64u,online_second=%u,mac_adr=\'%s\',ip_adr=\'%s\',res_src=%u"
                  ,(ulonglong)puVar5[0x1d]);
        uVar13 = FUN_140054dc0();
        plVar15 = (longlong *)InstanceGet(uVar13);
        (**(code **)(*plVar15 + 0x30))(plVar15,&local_438,0,1);
      }
      *(int *)(param_1 + 0x68) = *(int *)(param_1 + 0x68) + -1;
      DAT_1409756f0 = *(undefined4 *)(param_1 + 0x68);
      LOCK();
      UNLOCK();
      LOCK();
      DAT_1409756fc = DAT_1409756fc + 1;
      UNLOCK();
      LOCK();
      DAT_140975704 = DAT_140975704 + 1;
      UNLOCK();
      plVar15 = (longlong *)FUN_140070990(param_1 + 0x18,local_498);
      if (*plVar15 != 0) {
        pvVar6 = (void *)*plVar15;
        if ((DAT_140975b08 & 1) == 0) {
          DAT_140975b08 = DAT_140975b08 | 1;
          CMyHeap::CMyHeap((CMyHeap *)&DAT_140975b00,"CLoginPlayer");
          atexit((_func_5014 *)&LAB_1406d65c0);
        }
        CMyHeap::Free((CMyHeap *)&DAT_140975b00,pvVar6);
        *plVar15 = 0;
      }
      FUN_14006ee80(param_1 + 0x18,local_498);
      uVar13 = 1;
    }
  }
  return uVar13;
}

// ==== CWorldKernel::helper_140071a40  @140071a40  [medium:callgraph-r2]  (orig: FUN_140071a40)
/* WARNING: Restarted to delay deadcode elimination for space: register */

ulonglong FUN_140071a40(longlong param_1,uint param_2,uint param_3,char *param_4,uint param_5,
                       uint param_6,uint param_7,char *param_8,char *param_9)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  char *pcVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  ulonglong uVar9;
  uint *puVar10;
  undefined8 *puVar11;
  longlong local_60;
  undefined8 *local_58;
  longlong local_50;
  undefined8 local_48;
  longlong local_40;
  longlong local_38;
  
  uVar5 = param_6;
  puVar8 = *(undefined8 **)(param_1 + 0x48);
  cVar1 = *(char *)((longlong)puVar8[1] + 0x29);
  puVar3 = puVar8;
  puVar11 = (undefined8 *)puVar8[1];
  while (cVar1 == '\0') {
    if (*(uint *)(puVar11 + 3) < param_6) {
      puVar6 = (undefined8 *)puVar11[2];
      puVar11 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar11;
    }
    puVar3 = puVar11;
    puVar11 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x29);
  }
  local_58 = puVar3;
  local_60 = *(longlong *)(param_1 + 0x18);
  if (*(longlong *)(param_1 + 0x18) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (uVar5 < *(uint *)(puVar3 + 3))) {
    local_48 = *(undefined8 *)(param_1 + 0x48);
    local_50 = *(longlong *)(param_1 + 0x18);
    plVar7 = &local_50;
  }
  else {
    plVar7 = &local_60;
  }
  local_40 = *plVar7;
  local_38 = plVar7[1];
  lVar2 = *(longlong *)(param_1 + 0x48);
  if ((local_40 == 0) || (local_40 != *(longlong *)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  if (local_38 == lVar2) {
    if ((DAT_140975b08 & 1) == 0) {
      DAT_140975b08 = DAT_140975b08 | 1;
      CMyHeap::CMyHeap((CMyHeap *)&DAT_140975b00,"CLoginPlayer");
      atexit((_func_5014 *)&LAB_1406d65c0);
    }
    puVar10 = CMyHeap::Alloc((CMyHeap *)&DAT_140975b00,0x108);
    if (puVar10 == (uint *)0x0) {
      puVar10 = (uint *)0x0;
    }
    else {
      puVar10[0x1b] = 0;
      puVar10[0x1c] = 0;
      puVar10[6] = 0xffffffff;
      *puVar10 = 0;
      puVar10[0x1a] = 0;
      puVar10[0x18] = 0xffffffff;
      puVar10[0x19] = 0;
      puVar10[0x41] = 0;
      puVar10[0x40] = 0;
      *(undefined8 *)((longlong)puVar10 + 0xbd) = 0;
      *(undefined8 *)((longlong)puVar10 + 0xc5) = 0;
      *(undefined8 *)((longlong)puVar10 + 0xcd) = 0;
      *(undefined8 *)((longlong)puVar10 + 0xd5) = 0;
      *(undefined8 *)((longlong)puVar10 + 0xdd) = 0;
      *(undefined8 *)((longlong)puVar10 + 0xe5) = 0;
      *(undefined8 *)((longlong)puVar10 + 0xed) = 0;
      *(undefined8 *)((longlong)puVar10 + 0xf5) = 0;
    }
    if (puVar10 == (uint *)0x0) {
      uVar9 = 0;
    }
    else {
      puVar8 = (undefined8 *)FUN_140070990(param_1 + 0x18,&param_6);
      *puVar8 = puVar10;
      *puVar10 = param_3;
      tq::SafeCopy((char *)(puVar10 + 1),param_4,0x10);
      pcVar4 = param_8;
      puVar10[5] = 2;
      puVar10[6] = param_2;
      tq::SafeCopy((char *)(puVar10 + 7),param_8,0x41);
      puVar10[0x18] = uVar5;
      puVar10[0x1d] = param_5;
      puVar10[0x1e] = param_7;
      tq::SafeCopy((char *)(puVar10 + 0x1f),pcVar4,0x41);
      if (param_9 != (char *)0x0) {
        strncpy((char *)((longlong)puVar10 + 0xbd),param_9,0x40);
      }
      uVar5 = _time32((__time32_t *)0x0);
      puVar10[0x1a] = uVar5;
      *(int *)(param_1 + 0x68) = *(int *)(param_1 + 0x68) + 1;
      DAT_1409756f0 = *(int *)(param_1 + 0x68);
      if (*(int *)(param_1 + 0x6c) < DAT_1409756f0) {
        *(int *)(param_1 + 0x6c) = DAT_1409756f0;
      }
      LOCK();
      UNLOCK();
      LOCK();
      UNLOCK();
      LOCK();
      DAT_1409756f8 = DAT_1409756f8 + 1;
      UNLOCK();
      LOCK();
      DAT_140975700 = DAT_140975700 + 1;
      UNLOCK();
      uVar9 = CONCAT71((uint7)(uint3)((uint)DAT_1409756ec >> 8),1);
      DAT_1409756ec = *(undefined4 *)(param_1 + 0x6c);
    }
  }
  else {
    FUN_140070990(param_1 + 0x18,&param_6);
    FUN_140070990(param_1 + 0x18,&param_6);
    tq::MyLogSave("gmlog/cheater",&DAT_1406ef4a0,param_4,(ulonglong)param_3);
    if (DAT_140975af8 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","CWorldKernel::m_pWorld",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.h"
                        );
    }
    FUN_140056960(DAT_140975af8,(ulonglong)param_3,param_5,&DAT_1406ef478);
    if (DAT_140975af8 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","CWorldKernel::m_pWorld",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\worldkernel.h"
                        );
    }
    lVar2 = DAT_140975af8;
    plVar7 = (longlong *)FUN_140070990(param_1 + 0x18,&param_6);
    puVar8 = (undefined8 *)FUN_140070990(param_1 + 0x18,&param_6);
    FUN_140056960(lVar2,*(undefined4 *)*puVar8,*(undefined4 *)(*plVar7 + 0x74),&DAT_1406ef478);
    uVar9 = FUN_1400674b0(param_1,uVar5,param_5);
    uVar9 = uVar9 & 0xffffffffffffff00;
  }
  return uVar9;
}

// ==== CWorldKernel::helper_140072120  @140072120  [medium:callgraph-r2]  (orig: FUN_140072120)
void FUN_140072120(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  puVar1 = (undefined4 *)FUN_140053460(param_1 + 0x160,local_res10);
  *puVar1 = param_3;
  return;
}

// ==== CWorldKernel::helper_140072150  @140072150  [medium:callgraph-r2]  (orig: FUN_140072150)
void FUN_140072150(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  puVar1 = (undefined4 *)FUN_140070860(param_1 + 0xf0,local_res10);
  *puVar1 = param_3;
  return;
}

// ==== CWorldKernel::helper_140072300  @140072300  [medium:callgraph-r3]  (orig: FUN_140072300)
longlong * FUN_140072300(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140070ed0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1400723f4;
  }
  _invalid_parameter_noinfo();
LAB_1400723f4:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CWorldKernel::helper_1400725a0  @1400725a0  [medium:callgraph-r1]  (orig: FUN_1400725a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400725a0(longlong param_1,undefined8 param_2,undefined4 param_3,char *param_4)

{
  longlong *plVar1;
  int *piVar2;
  undefined8 *puVar3;
  char cVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 uVar7;
  int iVar8;
  ulong uVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong *plVar12;
  IStringManager *pIVar13;
  char *pcVar14;
  undefined8 uVar15;
  undefined8 *puVar16;
  int *piVar17;
  undefined8 *puVar18;
  char *pcVar19;
  bool bVar20;
  undefined1 auStack_938 [32];
  char *local_918;
  int local_910;
  int local_908;
  char *local_900;
  undefined8 local_8f8;
  int local_8e8;
  undefined4 local_8e4;
  longlong *local_8d8;
  int *piStack_8d0;
  undefined4 local_8c8;
  undefined4 local_8c4;
  undefined4 local_8c0;
  char *local_8b8;
  longlong local_8b0;
  undefined8 *local_8a8;
  longlong local_8a0;
  undefined8 local_898;
  undefined8 local_890;
  undefined1 local_888 [1072];
  char local_458 [15];
  undefined1 local_449;
  char local_448;
  undefined1 local_447 [1023];
  ulonglong local_48;
  
  local_890 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_938;
  local_448 = '\0';
  local_8c0 = param_3;
  local_8b8 = param_4;
  memset(local_447,0,0x3ff);
  _snprintf(&local_448,0x3ff,
            "SELECT id, name, account_id, recordmap_id, level, auto_exercise FROM cq_user WHERE account_id=\'%u\'"
           );
  if (DAT_140975af8 == (longlong *)0x0) {
    local_918 = (char *)CONCAT44(local_918._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar10 = (longlong *)InstanceGet(DAT_140975af8);
  plVar10 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,&local_448,2);
  if (plVar10 == (longlong *)0x0) {
    return 1;
  }
  lVar11 = (**(code **)(*plVar10 + 0x40))(plVar10);
  if (lVar11 == 0) {
    (**(code **)*plVar10)(plVar10);
    return 1;
  }
  plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,&DAT_1406de8d4);
  uVar5 = (**(code **)(*plVar12 + 0x40))(plVar12);
  local_8e4 = uVar5;
  pIVar13 = theInstance();
  pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)(pIVar13,"NOMATE_NAME");
  strncpy(local_458,pcVar14,0xf);
  local_449 = 0;
  plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,&DAT_1406ef6e0);
  pcVar14 = (char *)(**(code **)(*plVar12 + 0x78))(plVar12);
  tq::StrCopy(local_458,pcVar14,0x10);
  plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"account_id");
  uVar6 = (**(code **)(*plVar12 + 0x40))(plVar12);
  plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"recordmap_id");
  uVar7 = (**(code **)(*plVar12 + 0x40))(plVar12);
  uVar15 = FUN_140067320();
  local_8c4 = FUN_140074f20(uVar15,uVar7);
  plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"level");
  local_8e8 = (**(code **)(*plVar12 + 0x48))(plVar12);
  plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"auto_exercise");
  iVar8 = (**(code **)(*plVar12 + 0x48))(plVar12);
  if (iVar8 == 1) {
    uVar7 = 0x259;
  }
  bVar20 = (*(longlong *)(param_1 + 0x150) - *(longlong *)(param_1 + 0x148) & 0xfffffffffffffffcU)
           == 0;
  local_8c8 = uVar7;
  if (!bVar20) {
    pcVar14 = strstr(local_458,"PM");
    if (pcVar14 == (char *)0x0) {
      pcVar14 = strstr(local_458,"GM");
      bVar20 = true;
      if (pcVar14 == (char *)0x0) goto LAB_140072a46;
    }
    puVar18 = (undefined8 *)(*(undefined8 **)(param_1 + 0xa0))[1];
    cVar4 = *(char *)((longlong)puVar18 + 0x49);
    puVar3 = *(undefined8 **)(param_1 + 0xa0);
    while (cVar4 == '\0') {
      if (*(uint *)(puVar18 + 3) < uVar6) {
        puVar16 = (undefined8 *)puVar18[2];
        puVar18 = puVar3;
      }
      else {
        puVar16 = (undefined8 *)*puVar18;
      }
      puVar3 = puVar18;
      puVar18 = puVar16;
      cVar4 = *(char *)((longlong)puVar16 + 0x49);
    }
    local_8a8 = puVar3;
    local_8b0 = *(longlong *)(param_1 + 0x70);
    puVar18 = *(undefined8 **)(param_1 + 0xa0);
    if (*(longlong *)(param_1 + 0x70) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar18) || (uVar6 < *(uint *)(puVar3 + 3))) {
      local_898 = *(undefined8 *)(param_1 + 0xa0);
      local_8a0 = *(longlong *)(param_1 + 0x70);
      plVar12 = &local_8a0;
    }
    else {
      plVar12 = &local_8b0;
    }
    plVar1 = (longlong *)*plVar12;
    piStack_8d0 = (int *)plVar12[1];
    lVar11 = *(longlong *)(param_1 + 0xa0);
    local_8d8 = plVar1;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x70))) {
      _invalid_parameter_noinfo();
    }
    piVar17 = piStack_8d0;
    if (piStack_8d0 == (int *)lVar11) {
      local_910 = 0x116;
      local_918 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\userlist.cpp";
      log_InlineLogERROR("not find GM(id:%u, account_id:%u, name:%s) login record at %s, %d");
      (**(code **)*plVar10)(plVar10);
      return 3;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = 0;
    }
    else {
      lVar11 = *plVar1;
    }
    if (piVar17 == (int *)*(longlong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    iVar8 = *(int *)((longlong)piVar17 + 0x40);
    piVar17 = *(int **)(param_1 + 0x148);
    if (*(int **)(param_1 + 0x150) < piVar17) {
      _invalid_parameter_noinfo();
    }
    plVar12 = *(longlong **)(param_1 + 0x130);
    local_8d8 = plVar12;
    piStack_8d0 = piVar17;
    while( true ) {
      piVar2 = *(int **)(param_1 + 0x150);
      if (piVar2 < *(int **)(param_1 + 0x148)) {
        _invalid_parameter_noinfo();
      }
      if ((plVar12 == (longlong *)0x0) || (plVar12 != *(longlong **)(param_1 + 0x130))) {
        _invalid_parameter_noinfo();
      }
      if (piVar17 == piVar2) {
        local_918 = local_458;
        local_910 = iVar8;
        log_InlineLogDBERROR
                  (
                  "table:cq_config, type = %d, GM(id:%u, account_id:%u, name:%s) ip(%u) not config."
                  );
        (**(code **)*plVar10)(plVar10);
        return 3;
      }
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar12;
      }
      if (*(int **)(lVar11 + 0x20) <= piVar17) {
        _invalid_parameter_noinfo();
      }
      if (*piVar17 == iVar8) break;
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar12;
      }
      if (*(int **)(lVar11 + 0x20) <= piVar17) {
        _invalid_parameter_noinfo();
      }
      piVar17 = piVar17 + 1;
    }
    bVar20 = true;
    uVar5 = local_8e4;
  }
LAB_140072a46:
  uVar15 = 2;
  lVar11 = 5;
  pcVar14 = local_8b8;
  pcVar19 = "!NP!";
  do {
    if (lVar11 == 0) break;
    lVar11 = lVar11 + -1;
    bVar20 = *pcVar14 == *pcVar19;
    pcVar14 = pcVar14 + 1;
    pcVar19 = pcVar19 + 1;
  } while (bVar20);
  if ((!bVar20) || (local_8e8 < DAT_140949794)) {
    local_8f8 = 0;
    local_900 = local_8b8;
    local_908 = local_8e8;
    local_910 = local_8c0;
    local_918 = (char *)CONCAT44(local_918._4_4_,uVar6);
    cVar4 = FUN_140071a40(param_1,local_8c4,uVar5,local_458);
    if (cVar4 != '\0') {
      lVar11 = FUN_14006e3a0(param_1,uVar5);
      if (lVar11 != 0) {
        FUN_140081c40(local_888);
        iVar8 = FUN_140081cf0(local_888,0,local_8c8);
        if (iVar8 != 0) {
          if (DAT_140975af8 == (longlong *)0x0) {
            local_918 = (char *)CONCAT44(local_918._4_4_,0x128);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          (**(code **)(*DAT_140975af8 + 0x38))
                    (DAT_140975af8,*(undefined4 *)(lVar11 + 0x60),local_888);
        }
        *(undefined4 *)(lVar11 + 0x100) = 0x78;
        uVar9 = tq::TimeGet(0);
        *(uint *)(lVar11 + 0x104) = uVar9 / 1000;
        uVar15 = FUN_140054dc0();
        cVar4 = FUN_140056a70(uVar15);
        if (cVar4 == '\0') {
          uVar15 = FUN_140054dc0();
          FUN_140055820(uVar15,uVar6,0);
          uVar15 = FUN_140054dc0();
          local_918 = (char *)CONCAT44(local_918._4_4_,100);
          FUN_1400558e0(uVar15,uVar6,0,0);
        }
        else {
          uVar15 = FUN_140054dc0();
          FUN_140055c60(uVar15,uVar6,uVar5,1);
        }
        uVar15 = 0;
        FUN_140081c90(local_888);
      }
      goto LAB_140072c24;
    }
  }
  if (DAT_140975af8 == (longlong *)0x0) {
    local_918 = (char *)CONCAT44(local_918._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140055820(DAT_140975af8,uVar6,5);
LAB_140072c24:
  (**(code **)*plVar10)(plVar10);
  return uVar15;
}

// ==== CWorldKernel::helper_140072c60  @140072c60  [medium:callgraph-r0]  (orig: FUN_140072c60)
void FUN_140072c60(longlong param_1)

{
  char cVar1;
  undefined8 *puVar2;
  undefined4 *puVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined4 *puVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  
  plVar4 = operator_new(8);
  plVar9 = (longlong *)0x0;
  local_68[0] = plVar9;
  if (plVar4 != (longlong *)0x0) {
    *plVar4 = (longlong)local_68;
    local_68[0] = plVar4;
  }
  local_50 = (undefined4 *)0x0;
  local_48 = (undefined4 *)0x0;
  local_40 = 0;
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x48);
  puVar2 = *(undefined8 **)(param_1 + 0x18);
  do {
    plVar6 = *(longlong **)(param_1 + 0x48);
    if ((puVar2 == (undefined8 *)0x0) || (puVar2 != *(undefined8 **)(param_1 + 0x18))) {
      _invalid_parameter_noinfo();
    }
    puVar7 = local_50;
    if (plVar4 == plVar6) {
      plVar4 = local_68[0];
      if (local_48 < local_50) {
        _invalid_parameter_noinfo();
        plVar4 = local_68[0];
      }
      while( true ) {
        puVar3 = local_48;
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        if ((plVar4 == (longlong *)0x0) || (plVar4 != local_68[0])) {
          _invalid_parameter_noinfo();
        }
        if (puVar7 == puVar3) break;
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar6 = plVar9;
        }
        else {
          plVar6 = (longlong *)*plVar4;
        }
        if ((undefined4 *)plVar6[4] <= puVar7) {
          _invalid_parameter_noinfo();
        }
        FUN_1400715e0(param_1,*puVar7);
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar6 = plVar9;
        }
        else {
          plVar6 = (longlong *)*plVar4;
        }
        if ((undefined4 *)plVar6[4] <= puVar7) {
          _invalid_parameter_noinfo();
        }
        puVar7 = puVar7 + 1;
      }
      if (local_50 != (undefined4 *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (undefined4 *)0x0;
      local_48 = (undefined4 *)0x0;
      local_40 = 0;
      operator_delete(local_68[0]);
      return;
    }
    if (puVar2 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar6 = plVar9;
    }
    else {
      plVar6 = (longlong *)*puVar2;
    }
    if (plVar4 == (longlong *)plVar6[6]) {
      _invalid_parameter_noinfo();
    }
    puVar7 = local_48;
    plVar6 = plVar9;
    if (local_50 != (undefined4 *)0x0) {
      plVar6 = (longlong *)(local_40 - (longlong)local_50 >> 2);
    }
    if ((longlong *)((longlong)local_48 - (longlong)local_50 >> 2) < plVar6) {
      *local_48 = (int)plVar4[3];
      local_48 = local_48 + 1;
    }
    else {
      if (local_48 < local_50) {
        _invalid_parameter_noinfo();
      }
      puVar3 = local_50;
      plVar6 = local_68[0];
      plVar8 = plVar9;
      if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) != 0) {
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        if ((plVar6 == (longlong *)0x0) || (plVar6 != local_68[0])) {
          _invalid_parameter_noinfo();
        }
        plVar8 = (longlong *)((longlong)puVar7 - (longlong)puVar3 >> 2);
      }
      local_88 = SUB84(plVar6,0);
      uStack_84 = (undefined4)((ulonglong)plVar6 >> 0x20);
      uStack_80 = SUB84(puVar7,0);
      uStack_7c = (undefined4)((ulonglong)puVar7 >> 0x20);
      local_78 = local_88;
      uStack_74 = uStack_84;
      uStack_70 = uStack_80;
      uStack_6c = uStack_7c;
      FUN_140036c20(local_68,&local_78,1,plVar4 + 3);
      puVar7 = local_50;
      if (local_48 < local_50) {
        _invalid_parameter_noinfo();
      }
      plVar6 = local_68[0];
      if (local_68[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar5 = plVar9;
      }
      else {
        plVar5 = (longlong *)*local_68[0];
      }
      if (puVar7 + (longlong)plVar8 <= (undefined4 *)plVar5[4]) {
        plVar5 = plVar9;
        if (plVar6 != (longlong *)0x0) {
          plVar5 = (longlong *)*plVar6;
        }
        if ((undefined4 *)plVar5[3] <= puVar7 + (longlong)plVar8) goto LAB_140072e31;
      }
      _invalid_parameter_noinfo();
    }
LAB_140072e31:
    if (puVar2 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar6 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar4 = plVar6;
        plVar6 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x29);
          plVar4 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar6 = plVar4;
        while ((plVar4 = plVar8, cVar1 == '\0' && (plVar6 == (longlong *)plVar4[2]))) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar6 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CWorldKernel::helper_140072f80  @140072f80  [medium:callgraph-r0]  (orig: FUN_140072f80)
void FUN_140072f80(longlong param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined1 uVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  ulonglong uVar8;
  longlong lVar9;
  int iVar10;
  undefined4 local_res10;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  plVar5 = (longlong *)FUN_140006ad0(4000,0);
  if (plVar5 != (longlong *)0x0) {
    iVar10 = 0;
    iVar4 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (0 < iVar4) {
      do {
        (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)iVar10);
        plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"data1");
        uVar3 = (**(code **)(*plVar6 + 0x48))(plVar6);
        local_res10 = CONCAT31(local_res10._1_3_,uVar3);
        plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"data2");
        uVar3 = (**(code **)(*plVar6 + 0x48))(plVar6);
        local_res10._0_2_ = CONCAT11(uVar3,(undefined1)local_res10);
        plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"data3");
        uVar3 = (**(code **)(*plVar6 + 0x48))(plVar6);
        local_res10._0_3_ = CONCAT12(uVar3,(undefined2)local_res10);
        plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"data4");
        uVar3 = (**(code **)(*plVar6 + 0x48))();
        puVar1 = *(undefined4 **)(param_1 + 0x148);
        local_res10 = CONCAT13(uVar3,(undefined3)local_res10);
        if (puVar1 == (undefined4 *)0x0) {
          uVar8 = 0;
        }
        else {
          uVar8 = *(longlong *)(param_1 + 0x158) - (longlong)puVar1 >> 2;
        }
        puVar2 = *(undefined4 **)(param_1 + 0x150);
        if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 2) < uVar8) {
          *puVar2 = local_res10;
          *(undefined4 **)(param_1 + 0x150) = puVar2 + 1;
        }
        else {
          if (puVar2 < puVar1) {
            _invalid_parameter_noinfo();
          }
          uVar8 = *(ulonglong *)(param_1 + 0x148);
          lVar7 = *(longlong *)(param_1 + 0x130);
          if ((*(ulonglong *)(param_1 + 0x150) - uVar8 & 0xfffffffffffffffc) == 0) {
            lVar9 = 0;
          }
          else {
            if (*(ulonglong *)(param_1 + 0x150) < uVar8) {
              _invalid_parameter_noinfo();
            }
            if ((lVar7 == 0) || (lVar7 != *(longlong *)(param_1 + 0x130))) {
              _invalid_parameter_noinfo();
            }
            lVar9 = (longlong)((longlong)puVar2 - uVar8) >> 2;
          }
          local_38 = (undefined4)lVar7;
          uStack_34 = (undefined4)((ulonglong)lVar7 >> 0x20);
          uStack_30 = SUB84(puVar2,0);
          uStack_2c = (undefined4)((ulonglong)puVar2 >> 0x20);
          local_28 = local_38;
          uStack_24 = uStack_34;
          uStack_20 = uStack_30;
          uStack_1c = uStack_2c;
          FUN_140036c20(param_1 + 0x130,&local_28,1,&local_res10);
          uVar8 = *(ulonglong *)(param_1 + 0x148);
          if (*(ulonglong *)(param_1 + 0x150) < uVar8) {
            _invalid_parameter_noinfo();
          }
          plVar6 = *(longlong **)(param_1 + 0x130);
          if (plVar6 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar6;
          }
          uVar8 = uVar8 + lVar9 * 4;
          if (uVar8 <= *(ulonglong *)(lVar7 + 0x20)) {
            if (plVar6 == (longlong *)0x0) {
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar6;
            }
            if (*(ulonglong *)(lVar7 + 0x18) <= uVar8) goto LAB_14007317c;
          }
          _invalid_parameter_noinfo();
        }
LAB_14007317c:
        iVar10 = iVar10 + 1;
        iVar4 = (**(code **)(*plVar5 + 0x40))(plVar5);
      } while (iVar10 < iVar4);
    }
    (**(code **)*plVar5)(plVar5);
  }
  return;
}

// ==== CWorldKernel::helper_1400731c0  @1400731c0  [medium:callgraph-r2]  (orig: FUN_1400731c0)
void FUN_1400731c0(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) >> 3;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) >> 3) < uVar3) {
    FUN_14006ae10(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 8;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140072300(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CWorldKernel::helper_140073290  @140073290  [medium:callgraph-r1]  (orig: FUN_140073290)
void FUN_140073290(longlong param_1)

{
  int iVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  int iVar7;
  undefined4 local_res8;
  undefined4 local_resc;
  
  param_1 = param_1 + 0x1a0;
  FUN_140070c90(param_1);
  plVar3 = (longlong *)FUN_140006ad0(0x222eb,1);
  if ((plVar3 == (longlong *)0x0) || (lVar4 = (**(code **)(*plVar3 + 0x40))(plVar3), lVar4 == 0)) {
    local_res8 = 299;
    local_resc = 0x101;
    FUN_1400731c0(param_1,&local_res8);
    local_res8 = 0xf9;
    local_resc = 0xec;
    FUN_1400731c0(param_1,&local_res8);
    local_res8 = 0x109;
    local_resc = 0x120;
    FUN_1400731c0(param_1,&local_res8);
    local_res8 = 0x146;
    local_resc = 0xed;
    FUN_1400731c0(param_1,&local_res8);
  }
  else {
    iVar7 = 0;
    iVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
    if (0 < iVar1) {
      do {
        (**(code **)(*plVar3 + 0x30))(plVar3,(longlong)iVar7);
        plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,3);
        plVar6 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,2);
        uVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
        local_res8 = (**(code **)(*plVar6 + 0x48))(plVar6);
        local_resc = uVar2;
        FUN_1400731c0(param_1,&local_res8);
        iVar7 = iVar7 + 1;
        iVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
      } while (iVar7 < iVar1);
    }
  }
  if (plVar3 != (longlong *)0x0) {
    (**(code **)*plVar3)(plVar3);
  }
  return;
}

// ==== CWorldKernel::helper_140073410  @140073410  [medium:callgraph-r0]  (orig: FUN_140073410)
undefined8 FUN_140073410(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    *(longlong *)(param_1 + 0x58) = param_2;
    lVar2 = FUN_14007f750(0x38);
    if (lVar2 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_140080930(lVar2);
    }
    FUN_1400675d0(param_1 + 0x60,uVar3);
    if (*(longlong *)(param_1 + 0x60) != 0) {
      if (*(longlong *)(param_1 + 0x60) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      cVar1 = FUN_1400812d0(*(undefined8 *)(param_1 + 0x60));
      if (cVar1 != '\0') {
        FUN_140073290(param_1);
        return 1;
      }
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CWorldKernel::helper_140073590  @140073590  [medium:callgraph-r0]  (orig: FUN_140073590)
void FUN_140073590(__uint64 param_1)

{
  if ((DAT_140975b28 & 1) == 0) {
    DAT_140975b28 = DAT_140975b28 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975b20,"CConnectUser");
    atexit((_func_5014 *)&LAB_1406d65e0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001400735e5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140975b20,param_1);
  return;
}

// ==== CWorldKernel::helper_140073740  @140073740  [medium:callgraph-r1]  (orig: FUN_140073740)
ulonglong FUN_140073740(longlong param_1,int param_2)

{
  ulong uVar1;
  ulonglong extraout_RAX;
  
  if (param_2 == 0) {
    *(undefined4 *)(param_1 + 0x7c) = 0;
    *(undefined4 *)(param_1 + 0x78) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
    return 0;
  }
  if (param_2 != 1) {
                    /* WARNING: Could not recover jumptable at 0x00014007375e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("CConnectUser::SetType, wrong type: %d");
    return extraout_RAX;
  }
  *(undefined4 *)(param_1 + 0x78) = 0x14;
  uVar1 = tq::TimeGet(0);
  *(undefined4 *)(param_1 + 0x34) = 1;
  *(uint *)(param_1 + 0x7c) = uVar1 / 1000;
  return (ulonglong)uVar1 * 0x10624dd3 & 0xffffffff;
}

// ==== CWorldKernel::helper_1400737b0  @1400737b0  [medium:callgraph-r0]  (orig: FUN_1400737b0)
bool FUN_1400737b0(longlong param_1)

{
  ulong uVar1;
  
  if (*(int *)(param_1 + 0x34) == 0) {
    return true;
  }
  uVar1 = tq::TimeGet(0);
  return uVar1 / 1000 < (uint)(*(int *)(param_1 + 0x7c) + *(int *)(param_1 + 0x78));
}

// ==== CWorldKernel::helper_1400737f0  @1400737f0  [medium:callgraph-r0]  (orig: FUN_1400737f0)
undefined8
FUN_1400737f0(longlong param_1,undefined4 param_2,undefined4 param_3,char *param_4,
             undefined4 param_5,char *param_6)

{
  ulong uVar1;
  
  *(undefined4 *)(param_1 + 8) = param_2;
  *(undefined4 *)(param_1 + 0xc) = param_3;
  tq::SafeCopy((char *)(param_1 + 0x10),param_4,0x20);
  *(undefined4 *)(param_1 + 0x30) = param_5;
  *(undefined4 *)(param_1 + 0x78) = 0x14;
  uVar1 = tq::TimeGet(0);
  *(undefined4 *)(param_1 + 0x34) = 1;
  *(undefined4 *)(param_1 + 0x78) = 0x14;
  *(uint *)(param_1 + 0x7c) = uVar1 / 1000;
  uVar1 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x7c) = uVar1 / 1000;
  if (param_6 != (char *)0x0) {
    strncpy((char *)(param_1 + 0x38),param_6,0x40);
  }
  return 1;
}

// ==== CWorldKernel::helper_140074a70  @140074a70  [medium:callgraph-r0]  (orig: FUN_140074a70)
undefined8 FUN_140074a70(longlong param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined4 *puVar8;
  longlong *plVar9;
  longlong lVar10;
  ulonglong uVar11;
  longlong lVar12;
  int iVar13;
  undefined4 *local_res10;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  plVar5 = (longlong *)InstanceGet();
  plVar6 = (longlong *)
           (**(code **)(*plVar5 + 0x10))
                     (plVar5,"SELECT id,mapgroup,portal0_x,portal0_y FROM cq_map LIMIT 1234567890",2
                     );
  if (plVar6 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar7 = 0;
  }
  else {
    iVar13 = 0;
    iVar3 = (**(code **)(*plVar6 + 0x40))(plVar6);
    if (0 < iVar3) {
      do {
        (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)iVar13);
        puVar8 = operator_new(0x10);
        if (puVar8 == (undefined4 *)0x0) {
          puVar8 = (undefined4 *)0x0;
        }
        else {
          *puVar8 = 0;
        }
        local_res10 = puVar8;
        if (puVar8 != (undefined4 *)0x0) {
          plVar9 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&DAT_1406de8d4);
          uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
          *puVar8 = uVar4;
          plVar9 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"mapgroup");
          uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
          puVar8[1] = uVar4;
          plVar9 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"portal0_x");
          uVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
          puVar8[2] = uVar4;
          plVar9 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"portal0_y");
          uVar4 = (**(code **)(*plVar9 + 0x48))();
          puVar8[3] = uVar4;
          puVar1 = *(undefined8 **)(param_1 + 0x20);
          if (puVar1 == (undefined8 *)0x0) {
            uVar11 = 0;
          }
          else {
            uVar11 = *(longlong *)(param_1 + 0x30) - (longlong)puVar1 >> 3;
          }
          puVar2 = *(undefined8 **)(param_1 + 0x28);
          if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar11) {
            *puVar2 = puVar8;
            *(undefined8 **)(param_1 + 0x28) = puVar2 + 1;
          }
          else {
            if (puVar2 < puVar1) {
              _invalid_parameter_noinfo();
            }
            lVar10 = *(longlong *)(param_1 + 8);
            uVar11 = *(ulonglong *)(param_1 + 0x20);
            if ((*(ulonglong *)(param_1 + 0x28) - uVar11 & 0xfffffffffffffff8) == 0) {
              lVar12 = 0;
            }
            else {
              if (*(ulonglong *)(param_1 + 0x28) < uVar11) {
                _invalid_parameter_noinfo();
              }
              if ((lVar10 == 0) || (lVar10 != *(longlong *)(param_1 + 8))) {
                _invalid_parameter_noinfo();
              }
              lVar12 = (longlong)((longlong)puVar2 - uVar11) >> 3;
            }
            local_48 = (undefined4)lVar10;
            uStack_44 = (undefined4)((ulonglong)lVar10 >> 0x20);
            uStack_40 = SUB84(puVar2,0);
            uStack_3c = (undefined4)((ulonglong)puVar2 >> 0x20);
            local_38 = local_48;
            uStack_34 = uStack_44;
            uStack_30 = uStack_40;
            uStack_2c = uStack_3c;
            FUN_1400745b0(param_1 + 8,&local_38,1,&local_res10);
            uVar11 = *(ulonglong *)(param_1 + 0x20);
            if (*(ulonglong *)(param_1 + 0x28) < uVar11) {
              _invalid_parameter_noinfo();
            }
            plVar9 = *(longlong **)(param_1 + 8);
            if (plVar9 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar10 = 0;
            }
            else {
              lVar10 = *plVar9;
            }
            uVar11 = uVar11 + lVar12 * 8;
            if (uVar11 <= *(ulonglong *)(lVar10 + 0x20)) {
              if (plVar9 == (longlong *)0x0) {
                lVar10 = 0;
              }
              else {
                lVar10 = *plVar9;
              }
              if (*(ulonglong *)(lVar10 + 0x18) <= uVar11) goto LAB_140074cc6;
            }
            _invalid_parameter_noinfo();
          }
        }
LAB_140074cc6:
        iVar13 = iVar13 + 1;
        iVar3 = (**(code **)(*plVar6 + 0x40))(plVar6);
      } while (iVar13 < iVar3);
    }
    (**(code **)*plVar6)(plVar6);
    plVar5 = (longlong *)
             (**(code **)(*plVar5 + 0x10))
                       (plVar5,
                        "SELECT id,mapgroup,portal0_x,portal0_y FROM cq_dynamap LIMIT 1234567890",2)
    ;
    if (plVar5 != (longlong *)0x0) {
      iVar13 = 0;
      iVar3 = (**(code **)(*plVar5 + 0x40))(plVar5);
      if (0 < iVar3) {
        do {
          (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)iVar13);
          puVar8 = operator_new(0x10);
          if (puVar8 == (undefined4 *)0x0) {
            puVar8 = (undefined4 *)0x0;
          }
          else {
            *puVar8 = 0;
          }
          local_res10 = puVar8;
          if (puVar8 != (undefined4 *)0x0) {
            plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,&DAT_1406de8d4);
            uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
            *puVar8 = uVar4;
            plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"mapgroup");
            uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
            puVar8[1] = uVar4;
            plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"portal0_x");
            uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
            puVar8[2] = uVar4;
            plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"portal0_y");
            uVar4 = (**(code **)(*plVar6 + 0x48))();
            puVar8[3] = uVar4;
            puVar1 = *(undefined8 **)(param_1 + 0x20);
            if (puVar1 == (undefined8 *)0x0) {
              uVar11 = 0;
            }
            else {
              uVar11 = *(longlong *)(param_1 + 0x30) - (longlong)puVar1 >> 3;
            }
            puVar2 = *(undefined8 **)(param_1 + 0x28);
            if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar11) {
              *puVar2 = puVar8;
              *(undefined8 **)(param_1 + 0x28) = puVar2 + 1;
            }
            else {
              if (puVar2 < puVar1) {
                _invalid_parameter_noinfo();
              }
              lVar10 = *(longlong *)(param_1 + 8);
              uVar11 = *(ulonglong *)(param_1 + 0x20);
              if ((*(ulonglong *)(param_1 + 0x28) - uVar11 & 0xfffffffffffffff8) == 0) {
                lVar12 = 0;
              }
              else {
                if (*(ulonglong *)(param_1 + 0x28) < uVar11) {
                  _invalid_parameter_noinfo();
                }
                if ((lVar10 == 0) || (lVar10 != *(longlong *)(param_1 + 8))) {
                  _invalid_parameter_noinfo();
                }
                lVar12 = (longlong)((longlong)puVar2 - uVar11) >> 3;
              }
              local_48 = (undefined4)lVar10;
              uStack_44 = (undefined4)((ulonglong)lVar10 >> 0x20);
              uStack_40 = SUB84(puVar2,0);
              uStack_3c = (undefined4)((ulonglong)puVar2 >> 0x20);
              local_38 = local_48;
              uStack_34 = uStack_44;
              uStack_30 = uStack_40;
              uStack_2c = uStack_3c;
              FUN_1400745b0(param_1 + 8,&local_38,1,&local_res10);
              uVar11 = *(ulonglong *)(param_1 + 0x20);
              if (*(ulonglong *)(param_1 + 0x28) < uVar11) {
                _invalid_parameter_noinfo();
              }
              plVar6 = *(longlong **)(param_1 + 8);
              if (plVar6 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar10 = 0;
              }
              else {
                lVar10 = *plVar6;
              }
              uVar11 = uVar11 + lVar12 * 8;
              if (uVar11 <= *(ulonglong *)(lVar10 + 0x20)) {
                if (plVar6 == (longlong *)0x0) {
                  lVar10 = 0;
                }
                else {
                  lVar10 = *plVar6;
                }
                if (*(ulonglong *)(lVar10 + 0x18) <= uVar11) goto LAB_140074ed7;
              }
              _invalid_parameter_noinfo();
            }
          }
LAB_140074ed7:
          iVar13 = iVar13 + 1;
          iVar3 = (**(code **)(*plVar5 + 0x40))(plVar5);
        } while (iVar13 < iVar3);
      }
      (**(code **)*plVar5)(plVar5);
    }
    uVar7 = 1;
  }
  return uVar7;
}

// ==== CWorldKernel::helper_140075640  @140075640  [medium:callgraph-r1]  (orig: FUN_140075640)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140075640(undefined4 param_1,undefined4 param_2,uint param_3,void *param_4,uint param_5,
                  undefined4 param_6)

{
  longlong lVar1;
  ulonglong _Size;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [8];
  uint local_480;
  uint local_47c;
  undefined1 local_478 [1024];
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  ulonglong local_48;
  
  local_498 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (DAT_140975af8 == 0) {
    local_4a8 = 0x128;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = DAT_140975af8;
  if ((((param_3 != 0) && (DAT_140975af8 != 0)) && (param_4 != (void *)0x0)) &&
     (_Size = (ulonglong)param_5, (int)param_5 < 0x401)) {
    local_480 = param_3;
    local_78 = param_1;
    local_74 = param_2;
    if (param_3 < 0x7f1) {
      if (param_3 == 0x7f0) {
        FUN_140082700(local_488);
        local_70 = 0;
        local_480 = 0x7f0;
        local_47c = param_5;
        local_6c = param_6;
        memmove(local_478,param_4,_Size);
        FUN_140082a90(local_488,lVar1);
        FUN_140082780(local_488);
      }
      else {
        switch(param_3) {
        case 0x3e9:
          FUN_140083630(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_1400836e0(local_488,lVar1);
          FUN_140083680(local_488);
          break;
        case 0x3ea:
          FUN_140083d70(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_140083f20(local_488,lVar1);
          FUN_140083dc0(local_488);
          break;
        case 0x3ec:
          FUN_14007a560(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_14007a880(local_488,lVar1);
          FUN_14007a5e0(local_488);
          break;
        case 0x3f7:
          FUN_14007d140(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_14007d3c0(local_488,lVar1);
          FUN_14007d1c0(local_488);
          break;
        case 0x3fb:
          FUN_140084330(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_1400844b0(local_488,lVar1);
          FUN_140084380(local_488);
          break;
        case 0x414:
          FUN_140081c40(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_140081de0(local_488,lVar1);
          FUN_140081c90(local_488);
          break;
        case 0x41c:
          FUN_140083080(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_1400831e0(local_488,lVar1);
          FUN_1400830d0(local_488);
          break;
        case 0x457:
          FUN_140081ed0(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_140081fc0(local_488,lVar1);
          FUN_140081f50(local_488);
          break;
        case 0x4b2:
          FUN_140084960(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_140084a10(local_488,lVar1);
          FUN_1400849b0(local_488);
          break;
        case 0x4b3:
          FUN_1400850b0(local_488);
          local_70 = 0;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_140085210(local_488,lVar1);
          FUN_140085100(local_488);
        }
      }
    }
    else if (param_3 == 0x7f2) {
      FUN_140082b30(local_488);
      local_70 = 0;
      local_480 = 0x7f2;
      local_47c = param_5;
      local_6c = param_6;
      memmove(local_478,param_4,_Size);
      FUN_140082c60(local_488,lVar1);
      FUN_140082b80(local_488);
    }
    else if (param_3 == 0x8b5) {
      FUN_140084560(local_488);
      local_70 = 0;
      local_480 = 0x8b5;
      local_47c = param_5;
      local_6c = param_6;
      memmove(local_478,param_4,_Size);
      FUN_140084670(local_488,lVar1);
      FUN_1400845e0(local_488);
    }
    else if (param_3 == 0x4e21) {
      FUN_140082cf0(local_488);
      local_70 = 0;
      local_47c = param_5;
      local_6c = param_6;
      memmove(local_478,param_4,_Size);
      FUN_140082ee0(local_488,lVar1);
      FUN_140082d40(local_488);
    }
  }
  return;
}

// ==== CWorldKernel::helper_140075e30  @140075e30  [medium:callgraph-r1]  (orig: FUN_140075e30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140075e30(undefined4 param_1,undefined4 param_2,uint param_3,void *param_4,uint param_5,
                  undefined4 param_6)

{
  longlong lVar1;
  ulonglong _Size;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [8];
  undefined4 local_480;
  uint local_47c;
  undefined1 local_478 [1024];
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  ulonglong local_48;
  
  local_498 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (DAT_140975af8 == 0) {
    local_4a8 = 0x128;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = DAT_140975af8;
  if (((param_3 != 0) && (DAT_140975af8 != 0)) && (param_4 != (void *)0x0)) {
    _Size = (ulonglong)param_5;
    if ((int)param_5 < 0x401) {
      local_78 = param_1;
      local_70 = param_2;
      if (param_3 < 0x41d) {
        if (param_3 == 0x41c) {
          FUN_140083080(local_488);
          local_74 = 0xffffffff;
          local_480 = 0x41c;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_1400831e0(local_488,lVar1);
          FUN_1400830d0(local_488);
        }
        else if (param_3 == 0x3e9) {
          FUN_140083630(local_488);
          local_74 = 0xffffffff;
          local_480 = 0x3e9;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_1400836e0(local_488,lVar1);
          FUN_140083680(local_488);
        }
        else if (param_3 == 0x3ea) {
          FUN_140083d70(local_488);
          local_74 = 0xffffffff;
          local_480 = 0x3ea;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_140083f20(local_488,lVar1);
          FUN_140083dc0(local_488);
        }
        else if (param_3 == 0x3ec) {
          FUN_14007a560(local_488);
          local_74 = 0xffffffff;
          local_480 = 0x3ec;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_14007a880(local_488,lVar1);
          FUN_14007a5e0(local_488);
        }
        else if (param_3 == 0x3f7) {
          FUN_14007d140(local_488);
          local_74 = 0xffffffff;
          local_480 = 0x3f7;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_14007d3c0(local_488,lVar1);
          FUN_14007d1c0(local_488);
        }
        else if (param_3 == 0x3fb) {
          FUN_140084330(local_488);
          local_74 = 0xffffffff;
          local_480 = 0x3fb;
          local_47c = param_5;
          local_6c = param_6;
          memmove(local_478,param_4,_Size);
          FUN_1400844b0(local_488,lVar1);
          FUN_140084380(local_488);
        }
      }
      else if (param_3 == 0x457) {
        FUN_140081ed0(local_488);
        local_74 = 0xffffffff;
        local_480 = 0x457;
        local_47c = param_5;
        local_6c = param_6;
        memmove(local_478,param_4,_Size);
        FUN_140081fc0(local_488,lVar1);
        FUN_140081f50(local_488);
      }
      else if (param_3 == 0x7f0) {
        FUN_140082700(local_488);
        local_74 = 0xffffffff;
        local_480 = 0x7f0;
        local_47c = param_5;
        local_6c = param_6;
        memmove(local_478,param_4,_Size);
        FUN_140082a90(local_488,lVar1);
        FUN_140082780(local_488);
      }
      else if (param_3 == 0x7f2) {
        FUN_140082b30(local_488);
        local_74 = 0xffffffff;
        local_480 = 0x7f2;
        local_47c = param_5;
        local_6c = param_6;
        memmove(local_478,param_4,_Size);
        FUN_140082c60(local_488,lVar1);
        FUN_140082b80(local_488);
      }
      else if (param_3 == 0x4e21) {
        FUN_140082cf0(local_488);
        local_74 = 0xffffffff;
        local_480 = 0x4e21;
        local_47c = param_5;
        local_6c = param_6;
        memmove(local_478,param_4,_Size);
        FUN_140082ee0(local_488,lVar1);
        FUN_140082d40(local_488);
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_140076590  @140076590  [medium:callgraph-r1]  (orig: FUN_140076590)
undefined8
FUN_140076590(longlong param_1,char *param_2,char *param_3,char *param_4,undefined4 param_5)

{
  char cVar1;
  ulonglong uVar2;
  char *pcVar3;
  
  if (param_2 != (char *)0x0) {
    uVar2 = 0xffffffffffffffff;
    pcVar3 = param_2;
    do {
      if (uVar2 == 0) break;
      uVar2 = uVar2 - 1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    if ((~uVar2 - 1 < 0x10) && (param_3 != (char *)0x0)) {
      uVar2 = 0xffffffffffffffff;
      pcVar3 = param_3;
      do {
        if (uVar2 == 0) break;
        uVar2 = uVar2 - 1;
        cVar1 = *pcVar3;
        pcVar3 = pcVar3 + 1;
      } while (cVar1 != '\0');
      if ((~uVar2 - 1 < 0x10) && (param_4 != (char *)0x0)) {
        uVar2 = 0xffffffffffffffff;
        pcVar3 = param_4;
        do {
          if (uVar2 == 0) break;
          uVar2 = uVar2 - 1;
          cVar1 = *pcVar3;
          pcVar3 = pcVar3 + 1;
        } while (cVar1 != '\0');
        if (~uVar2 - 1 < 0x10) {
          FUN_1400752b0(param_1);
          pcVar3 = (char *)(*(longlong *)(param_1 + 0x420) + 4);
          do {
            cVar1 = *param_2;
            param_2 = param_2 + 1;
            *pcVar3 = cVar1;
            pcVar3 = pcVar3 + 1;
          } while (cVar1 != '\0');
          pcVar3 = (char *)(*(longlong *)(param_1 + 0x420) + 0x14);
          do {
            cVar1 = *param_3;
            param_3 = param_3 + 1;
            *pcVar3 = cVar1;
            pcVar3 = pcVar3 + 1;
          } while (cVar1 != '\0');
          pcVar3 = (char *)(*(longlong *)(param_1 + 0x420) + 0x24);
          do {
            cVar1 = *param_4;
            param_4 = param_4 + 1;
            *pcVar3 = cVar1;
            pcVar3 = pcVar3 + 1;
          } while (cVar1 != '\0');
          *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 0x34) = param_5;
          *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 2) = 1099;
          **(undefined2 **)(param_1 + 0x420) = 0x38;
          return 1;
        }
      }
    }
  }
  return 0;
}

// ==== CWorldKernel::helper_140076770  @140076770  [medium:callgraph-r1]  (orig: FUN_140076770)
undefined8 * FUN_140076770(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgMoblieDataArray_A::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CWorldKernel::helper_1400767c0  @1400767c0  [medium:callgraph-r1]  (orig: FUN_1400767c0)
void FUN_1400767c0(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgMoblieDataArray_A::vftable;
  FUN_1400752a0();
  return;
}

// ==== CWorldKernel::helper_1400767f0  @1400767f0  [medium:callgraph-r1]  (orig: FUN_1400767f0)
bool FUN_1400767f0(longlong param_1,undefined2 param_2,int param_3,void *param_4)

{
  bool bVar1;
  
  if (param_3 < 1) {
    bVar1 = false;
  }
  else {
    bVar1 = (longlong)(param_3 + -1) * 4 + 0xcU < 0x400;
    if (bVar1) {
      FUN_1400752b0();
      **(short **)(param_1 + 0x420) = ((short)(param_3 + -1) + 3) * 4;
      *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 2) = 0x7532;
      *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 4) = param_2;
      *(char *)(*(longlong *)(param_1 + 0x420) + 6) = (char)param_3;
      memcpy((void *)(*(longlong *)(param_1 + 0x420) + 8),param_4,(longlong)param_3 << 2);
    }
    else {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  return bVar1;
}

// ==== CWorldKernel::helper_140076930  @140076930  [medium:callgraph-r1]  (orig: FUN_140076930)
undefined8 * FUN_140076930(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgMobileString_A::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x85),(char *)((longlong)param_1 + 0x1a),0x3f5,true);
  return param_1;
}

// ==== CWorldKernel::helper_1400769b0  @1400769b0  [medium:callgraph-r1]  (orig: FUN_1400769b0)
void FUN_1400769b0(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgMobileString_A::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  return;
}

// ==== CWorldKernel::helper_140076a20  @140076a20  [medium:callgraph-r1]  (orig: FUN_140076a20)
ulonglong FUN_140076a20(longlong param_1,short param_2,char *param_3,undefined4 param_4)

{
  short sVar1;
  uint uVar2;
  ulonglong in_RAX;
  undefined4 extraout_var;
  ulonglong uVar3;
  
  if ((param_2 == 0) || (param_3 == (char *)0x0)) {
    uVar3 = in_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1400752b0();
    *(short *)(*(longlong *)(param_1 + 0x420) + 8) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 4) = param_4;
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x428),param_3);
    *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 2) = 0x7531;
    uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x428));
    sVar1 = (short)uVar2 + 0xb;
    **(short **)(param_1 + 0x420) = sVar1;
    uVar3 = CONCAT71((int7)(CONCAT62((int6)(CONCAT44(extraout_var,uVar2) >> 0x10),sVar1) >> 8),1);
  }
  return uVar3;
}

// ==== CWorldKernel::helper_140076b70  @140076b70  [medium:callgraph-r2]  (orig: FUN_140076b70)
ulonglong FUN_140076b70(longlong param_1,short param_2,undefined4 param_3)

{
  short sVar1;
  uint uVar2;
  ulonglong in_RAX;
  undefined4 extraout_var;
  
  if (param_2 == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1400752b0();
  *(short *)(*(longlong *)(param_1 + 0x420) + 8) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 4) = param_3;
  *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 2) = 0x7531;
  uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x428));
  sVar1 = (short)uVar2 + 0xb;
  **(short **)(param_1 + 0x420) = sVar1;
  return CONCAT71((int7)(CONCAT62((int6)(CONCAT44(extraout_var,uVar2) >> 0x10),sVar1) >> 8),1);
}

// ==== CWorldKernel::helper_140076f20  @140076f20  [medium:callgraph-r2]  (orig: FUN_140076f20)
uint FUN_140076f20(undefined8 param_1,char *param_2)

{
  char cVar1;
  uint uVar2;
  
  uVar2 = 0;
  cVar1 = *param_2;
  while (cVar1 != '\0') {
    param_2 = param_2 + 1;
    uVar2 = uVar2 * 0x83 + (int)cVar1;
    cVar1 = *param_2;
  }
  return uVar2 & 0x7fffffff;
}

// ==== CWorldKernel::helper_140076f50  @140076f50  [medium:callgraph-r1]  (orig: FUN_140076f50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140076f50(undefined8 param_1,undefined4 param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  char cVar1;
  char cVar2;
  undefined8 uVar3;
  longlong lVar4;
  char *pcVar5;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *pbVar6;
  undefined1 auStack_48 [32];
  undefined8 local_28;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_20;
  ulonglong local_18;
  
  local_28 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_48;
  local_20 = param_3;
  uVar3 = FUN_140054e10();
  lVar4 = FUN_14006e620(uVar3,param_2);
  if (lVar4 != 0) {
    if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
      pbVar6 = param_3 + 8;
    }
    else {
      pbVar6 = *(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)(param_3 + 8);
    }
    pcVar5 = (char *)(lVar4 + 0x1c);
    lVar4 = (longlong)pbVar6 - (longlong)pcVar5;
    do {
      cVar1 = *pcVar5;
      cVar2 = pcVar5[lVar4];
      if (cVar1 != cVar2) break;
      pcVar5 = pcVar5 + 1;
    } while (cVar2 != '\0');
    if (cVar1 == cVar2) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_3);
      return 1;
    }
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_3);
  return 0;
}

// ==== CWorldKernel::helper_140077000  @140077000  [medium:callgraph-r0]  (orig: FUN_140077000)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140077000(longlong param_1,int param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  ulong uVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong *plVar12;
  char *pcVar13;
  undefined8 uVar14;
  ulonglong uVar15;
  undefined1 auStack_538 [32];
  uint *local_518;
  undefined8 ***local_510;
  uint local_508;
  char *local_500;
  char *local_4f8;
  uint local_4f0;
  char *local_4e8;
  undefined4 local_4e0;
  uint local_4d8;
  uint local_4d4;
  int local_4d0;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_4c8;
  int local_4c0;
  longlong local_4b8;
  uint local_4b0 [2];
  undefined4 local_4a8;
  undefined8 local_4a0;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_498 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_470 [8];
  undefined8 ***local_468 [3];
  ulonglong local_450;
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_4a0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_538;
  if ((param_2 != 0) && (param_3 != 0)) {
    local_4d0 = param_3;
    local_4b8 = param_1;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470,"");
    local_448 = '\0';
    memset(local_447,0,0x3ff);
    local_518 = (uint *)CONCAT44(local_518._4_4_,param_2);
    _snprintf(&local_448,0x400,"SELECT * FROM %s WHERE roleid=%lu AND used=0 limit 1",
              "emoney_card_ndsdk");
    local_49 = 0;
    plVar10 = (longlong *)InstanceGet();
    plVar10 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,&local_448,2);
    if (plVar10 == (longlong *)0x0) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470);
    }
    else {
      lVar11 = (**(code **)(*plVar10 + 0x40))(plVar10);
      if (lVar11 == 0) {
        (**(code **)*plVar10)(plVar10);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470);
      }
      else {
        local_4c0 = 0;
        while (iVar1 = local_4c0, iVar3 = (**(code **)(*plVar10 + 0x40))(plVar10), iVar1 < iVar3) {
          (**(code **)(*plVar10 + 0x30))(plVar10,(longlong)iVar1);
          plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,&DAT_1406de8d4);
          local_4d8 = (**(code **)(*plVar12 + 0x50))(plVar12);
          plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"ref_id");
          uVar4 = (**(code **)(*plVar12 + 0x40))(plVar12);
          plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"chk_sum");
          local_4d4 = (**(code **)(*plVar12 + 0x50))(plVar12);
          plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,&DAT_1406de6d4);
          uVar5 = (**(code **)(*plVar12 + 0x50))(plVar12);
          plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"itemcount");
          uVar6 = (**(code **)(*plVar12 + 0x48))(plVar12);
          local_4c8 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                      CONCAT44(local_4c8._4_4_,uVar6);
          plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"card_in_time");
          uVar7 = (**(code **)(*plVar12 + 0x50))(plVar12);
          plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"roleid");
          uVar8 = (**(code **)(*plVar12 + 0x40))(plVar12);
          uVar15 = (ulonglong)uVar8;
          plVar12 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,"account_id");
          pcVar13 = (char *)(**(code **)(*plVar12 + 0x78))(plVar12);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                    (local_470,pcVar13);
          if ((uVar5 == 0) || ((int)(uint)local_4c8 < 1)) {
            local_4f8 = (char *)CONCAT44(local_4f8._4_4_,200);
            local_500 = 
            "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\mobilerecharge.cpp";
            local_508 = (uint)local_4c8;
            local_510 = (undefined8 ***)CONCAT44(local_510._4_4_,uVar5);
            local_518 = (uint *)CONCAT44(local_518._4_4_,uVar4);
            log_InlineLogERROR("CWorldKernel::ProcessMobileRechargeSelect failed. ID[%u] User[%u] CardInTime=%u, RefID=%lu, Type=%u, ItemCount=%d at %s, %d"
                               ,(ulonglong)local_4d8,uVar15,(ulonglong)uVar7);
          }
          else {
            local_4c8 = local_498;
            uVar14 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                     basic_string<char,std::char_traits<char>,std::allocator<char>_>
                               (local_498,
                                (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                                 *)local_470);
            cVar2 = FUN_140076f50(local_4b8,local_4d0,uVar14);
            if (cVar2 == '\0') {
              local_510 = local_468;
              if (0xf < local_450) {
                local_510 = local_468[0];
              }
              local_4e0 = 0xcf;
              local_4e8 = 
              "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\mobilerecharge.cpp";
              local_4f0 = local_4d4;
              local_4f8 = (char *)CONCAT44(local_4f8._4_4_,uVar5);
              local_500 = (char *)CONCAT44(local_500._4_4_,uVar4);
              local_518 = (uint *)CONCAT44(local_518._4_4_,local_4d0);
              local_508 = uVar7;
              log_InlineLogERROR("CWorldKernel::ProcessMobileRechargeSelect. Check %s Account failed. ID[%u] User[%lu] AccountID[%lu] AccountStr[%s] CardInTime=%u, RefID=%lu, Type=%u, Chksum=%u at %s, %d"
                                 ,"emoney_card_ndsdk",(ulonglong)local_4d8,uVar15);
            }
            else {
              uVar9 = tq::Calc91EmoneyCardChksum(uVar7,uVar4,uVar5);
              if (uVar9 == local_4d4) {
                local_4a8 = 1;
                local_518 = local_4b0;
                local_4b0[0] = uVar8;
                (**(code **)(**(longlong **)(local_4b8 + 0x58) + 0x50))
                          (*(longlong **)(local_4b8 + 0x58),0xe,0x2748,0xc);
                break;
              }
              local_4f0 = 0xd6;
              local_4f8 = 
              "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\mobilerecharge.cpp";
              local_500 = (char *)CONCAT44(local_500._4_4_,local_4d4);
              local_510 = (undefined8 ***)CONCAT44(local_510._4_4_,uVar4);
              local_518 = (uint *)CONCAT44(local_518._4_4_,uVar7);
              local_508 = uVar5;
              log_InlineLogERROR("CWorldKernel::ProcessMobileRechargeSelect. Check %s chksum failed. ID[%u] User[%lu] CardInTime=%u, RefID=%lu, Type=%u, Chksum=%u at %s, %d"
                                 ,"emoney_card_ndsdk",(ulonglong)local_4d8,uVar15);
            }
          }
          local_4c0 = iVar1 + 1;
        }
        (**(code **)*plVar10)(plVar10);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470);
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_140077550  @140077550  [medium:callgraph-r0]  (orig: FUN_140077550)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140077550(longlong param_1)

{
  undefined8 uVar1;
  void *pvVar2;
  undefined8 *puVar3;
  int iVar4;
  char cVar5;
  ulong uVar6;
  int iVar7;
  uint uVar8;
  undefined4 uVar9;
  uint uVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong *plVar13;
  char *pcVar14;
  undefined1 auStack_618 [32];
  uint *local_5f8;
  uint local_5f0;
  uint local_5e8;
  char *local_5e0;
  char *local_5d8;
  undefined4 local_5d0;
  uint local_5c8;
  uint local_5c4;
  uint local_5c0;
  undefined8 local_5b8;
  undefined8 uStack_5b0;
  uint local_5a8;
  int local_5a4;
  ulong local_5a0;
  uint local_59c;
  void *local_598 [6];
  undefined8 *local_568;
  undefined8 local_560;
  undefined4 local_558;
  undefined4 uStack_554;
  undefined4 uStack_550;
  undefined4 uStack_54c;
  void *local_548;
  undefined8 uStack_540;
  void *local_538;
  undefined8 uStack_530;
  undefined8 local_528;
  undefined8 uStack_520;
  undefined8 local_518;
  undefined8 uStack_510;
  uint local_508 [2];
  undefined4 local_500;
  void *local_4f8;
  undefined8 uStack_4f0;
  void *local_4e8 [2];
  undefined4 local_4d8;
  undefined4 uStack_4d4;
  undefined4 uStack_4d0;
  undefined4 uStack_4cc;
  undefined4 local_4c8;
  undefined4 uStack_4c4;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  undefined4 local_4b8;
  undefined4 uStack_4b4;
  undefined4 uStack_4b0;
  undefined4 uStack_4ac;
  undefined4 local_4a8;
  undefined4 uStack_4a4;
  undefined4 uStack_4a0;
  undefined4 uStack_49c;
  undefined8 local_498;
  undefined4 local_488;
  undefined4 uStack_484;
  undefined4 uStack_480;
  undefined4 uStack_47c;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_468 [48];
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_618;
  cVar5 = FUN_140056a70();
  if ((cVar5 != '\0') &&
     (uVar6 = tq::TimeGet(0),
     (uint)(*(int *)(param_1 + 0x1e8) + *(int *)(param_1 + 0x1e4)) <= uVar6 / 1000)) {
    uVar6 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x1e8) = uVar6 / 1000;
    if (*(int *)(param_1 + 0x1ec) < 6) {
      *(int *)(param_1 + 0x1ec) = *(int *)(param_1 + 0x1ec) + 1;
      local_5c8 = 0;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_468,"");
      FUN_14000ef40(local_598);
      local_438 = '\0';
      memset(local_437,0,0x3ff);
      local_5f8 = (uint *)CONCAT44(local_5f8._4_4_,*(undefined4 *)(param_1 + 0x1f0));
      _snprintf(&local_438,0x400,"SELECT * FROM %s WHERE id > %lu AND used=0","emoney_card_ndsdk");
      local_39 = 0;
      plVar11 = (longlong *)InstanceGet();
      plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,&local_438,2);
      if (plVar11 == (longlong *)0x0) {
        uStack_5b0 = local_568;
        puVar3 = uStack_5b0;
        local_5b8 = local_598[0];
        pvVar2 = local_5b8;
        uVar1 = *local_568;
        local_4f8 = local_598[0];
        local_5b8._0_4_ = (uint)local_598[0];
        local_5b8._4_4_ = (undefined4)((ulonglong)local_598[0] >> 0x20);
        uStack_5b0._0_4_ = SUB84(local_568,0);
        uStack_5b0._4_4_ = (undefined4)((ulonglong)local_568 >> 0x20);
        local_4a8 = (uint)local_5b8;
        uStack_4a4 = local_5b8._4_4_;
        uStack_4a0 = (undefined4)uStack_5b0;
        uStack_49c = uStack_5b0._4_4_;
        uStack_4f0._0_4_ = (undefined4)uVar1;
        uStack_4f0._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
        local_4c8 = (uint)local_5b8;
        uStack_4c4 = local_5b8._4_4_;
        uStack_4c0 = (undefined4)uStack_4f0;
        uStack_4bc = uStack_4f0._4_4_;
        local_5b8 = pvVar2;
        uStack_5b0 = puVar3;
        uStack_4f0 = uVar1;
        FUN_14000bd50(local_598,&local_558,&local_4c8,&local_4a8);
        operator_delete(local_568);
        local_568 = (undefined8 *)0x0;
        local_560 = 0;
        operator_delete(local_598[0]);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_468);
      }
      else {
        lVar12 = (**(code **)(*plVar11 + 0x40))(plVar11);
        if (lVar12 == 0) {
          (**(code **)*plVar11)(plVar11);
          uStack_520 = local_568;
          puVar3 = uStack_520;
          local_528 = local_598[0];
          pvVar2 = local_528;
          uVar1 = *local_568;
          local_548 = local_598[0];
          local_528._0_4_ = SUB84(local_598[0],0);
          local_528._4_4_ = (undefined4)((ulonglong)local_598[0] >> 0x20);
          uStack_520._0_4_ = SUB84(local_568,0);
          uStack_520._4_4_ = (undefined4)((ulonglong)local_568 >> 0x20);
          local_4d8 = (undefined4)local_528;
          uStack_4d4 = local_528._4_4_;
          uStack_4d0 = (undefined4)uStack_520;
          uStack_4cc = uStack_520._4_4_;
          uStack_540._0_4_ = (undefined4)uVar1;
          uStack_540._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
          local_4b8 = (undefined4)local_528;
          uStack_4b4 = local_528._4_4_;
          uStack_4b0 = (undefined4)uStack_540;
          uStack_4ac = uStack_540._4_4_;
          uStack_540 = uVar1;
          local_528 = pvVar2;
          uStack_520 = puVar3;
          FUN_14000bd50(local_598,&local_558,&local_4b8,&local_4d8);
          operator_delete(local_568);
          local_568 = (undefined8 *)0x0;
          local_560 = 0;
          operator_delete(local_598[0]);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_468);
        }
        else {
          local_5a4 = 0;
          while (iVar4 = local_5a4, iVar7 = (**(code **)(*plVar11 + 0x40))(plVar11), iVar4 < iVar7)
          {
            (**(code **)(*plVar11 + 0x30))(plVar11,(longlong)iVar4);
            plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,&DAT_1406de8d4);
            uVar8 = (**(code **)(*plVar13 + 0x40))(plVar13);
            if (*(uint *)(param_1 + 0x1f0) < uVar8) {
              plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,&DAT_1406de8d4);
              uVar9 = (**(code **)(*plVar13 + 0x40))(plVar13);
              *(undefined4 *)(param_1 + 0x1f0) = uVar9;
            }
            plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,&DAT_1406de8d4);
            local_5c0 = (**(code **)(*plVar13 + 0x50))(plVar13);
            plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,"ref_id");
            uVar6 = (**(code **)(*plVar13 + 0x40))(plVar13);
            local_5a0 = uVar6;
            plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,"chk_sum");
            local_59c = (**(code **)(*plVar13 + 0x50))(plVar13);
            plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,&DAT_1406de6d4);
            uVar8 = (**(code **)(*plVar13 + 0x50))(plVar13);
            local_5a8 = uVar8;
            plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,"itemcount");
            uVar9 = (**(code **)(*plVar13 + 0x48))(plVar13);
            local_5b8 = (undefined8 *)CONCAT44(local_5b8._4_4_,uVar9);
            plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,"card_in_time");
            local_5c4 = (**(code **)(*plVar13 + 0x50))(plVar13);
            plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,"roleid");
            local_5c8 = (**(code **)(*plVar13 + 0x40))(plVar13);
            plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,"account_id");
            pcVar14 = (char *)(**(code **)(*plVar13 + 0x78))(plVar13);
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                      (local_468,pcVar14);
            pvVar2 = local_598[0];
            if ((uVar8 == 0) || ((int)(uint)local_5b8 < 1)) {
              local_5d8 = (char *)CONCAT44(local_5d8._4_4_,0x79);
              local_5e0 = 
              "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\mobilerecharge.cpp";
              local_5e8 = (uint)local_5b8;
              local_5f8 = (uint *)CONCAT44(local_5f8._4_4_,uVar6);
              local_5f0 = uVar8;
              log_InlineLogERROR("CWorldKernel::OnProcess91EmoneyCardQuery failed. ID[%u] User[%lu] CardInTime=%u, RefID=%lu, Type=%u, ItemCount=%d at %s, %d"
                                 ,(ulonglong)local_5c0,(ulonglong)local_5c8,(ulonglong)local_5c4);
            }
            else {
              local_5b8 = local_568;
              local_4e8[0] = local_598[0];
              plVar13 = (longlong *)FUN_140077480(local_598,&local_558,&local_5c8);
              if (((void *)*plVar13 == (void *)0x0) || ((void *)*plVar13 != pvVar2)) {
                _invalid_parameter_noinfo();
              }
              uVar6 = local_5a0;
              uVar8 = local_5a8;
              if ((undefined8 *)plVar13[1] == local_5b8) {
                uVar10 = tq::Calc91EmoneyCardChksum(local_5c4,local_5a0,local_5a8);
                if (uVar10 == local_59c) {
                  FUN_14000d480(local_598,&local_488,&local_5c8);
                  local_508[0] = local_5c8;
                  local_500 = 1;
                  local_5f8 = local_508;
                  (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))
                            (*(longlong **)(param_1 + 0x58),0xe,0x2748,0xc);
                }
                else {
                  local_5d0 = 0x85;
                  local_5d8 = 
                  "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\mobilerecharge.cpp";
                  local_5e0 = (char *)CONCAT44(local_5e0._4_4_,local_59c);
                  local_5e8 = uVar8;
                  local_5f0 = uVar6;
                  local_5f8 = (uint *)CONCAT44(local_5f8._4_4_,local_5c4);
                  log_InlineLogERROR("CWorldKernel::OnProcess91EmoneyCardQuery. Check %s chksum failed. ID[%u] User[%lu] CardInTime=%u, RefID=%lu, Type=%u, Chksum=%u at %s, %d"
                                     ,"emoney_card_ndsdk",(ulonglong)local_5c0,(ulonglong)local_5c8)
                  ;
                }
              }
            }
            local_5a4 = iVar4 + 1;
          }
          (**(code **)*plVar11)(plVar11);
          uStack_510 = local_568;
          puVar3 = uStack_510;
          local_518 = local_598[0];
          pvVar2 = local_518;
          uVar1 = *local_568;
          local_538 = local_598[0];
          local_518._0_4_ = SUB84(local_598[0],0);
          local_518._4_4_ = (undefined4)((ulonglong)local_598[0] >> 0x20);
          uStack_510._0_4_ = SUB84(local_568,0);
          uStack_510._4_4_ = (undefined4)((ulonglong)local_568 >> 0x20);
          local_488 = (undefined4)local_518;
          uStack_484 = local_518._4_4_;
          uStack_480 = (undefined4)uStack_510;
          uStack_47c = uStack_510._4_4_;
          uStack_530._0_4_ = (undefined4)uVar1;
          uStack_530._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
          local_558 = (undefined4)local_518;
          uStack_554 = local_518._4_4_;
          uStack_550 = (undefined4)uStack_530;
          uStack_54c = uStack_530._4_4_;
          uStack_530 = uVar1;
          local_518 = pvVar2;
          uStack_510 = puVar3;
          FUN_14000bd50(local_598,local_4e8,&local_558,&local_488);
          operator_delete(local_568);
          local_568 = (undefined8 *)0x0;
          local_560 = 0;
          operator_delete(local_598[0]);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_468);
        }
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_140077cc0  @140077cc0  [medium:callgraph-r1]  (orig: FUN_140077cc0)
undefined8 FUN_140077cc0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_1400752b0();
  **(undefined4 **)(param_1 + 0x420) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 4) = param_3;
  *(undefined4 *)(param_1 + 8) = 0x81f;
  *(undefined4 *)(param_1 + 0xc) = 8;
  return 1;
}

// ==== CWorldKernel::helper_14007af30  @14007af30  [medium:callgraph-r2]  (orig: FUN_14007af30)
void FUN_14007af30(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CWorldKernel::helper_14007b0a0  @14007b0a0  [medium:callgraph-r2]  (orig: FUN_14007b0a0)
void FUN_14007b0a0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014007b0c4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CWorldKernel::helper_14007b380  @14007b380  [medium:callgraph-r2]  (orig: FUN_14007b380)
void FUN_14007b380(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CWorldKernel::helper_14007b7c0  @14007b7c0  [medium:callgraph-r2]  (orig: FUN_14007b7c0)
undefined8 * FUN_14007b7c0(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CWorldKernel::helper_14007b8a0  @14007b8a0  [medium:callgraph-r3]  (orig: FUN_14007b8a0)
undefined8 *
FUN_14007b8a0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    *(undefined4 *)(puVar1 + 3) = *param_5;
    *(undefined4 *)((longlong)puVar1 + 0x1c) = param_5[1];
    *(undefined4 *)(puVar1 + 4) = param_5[2];
    *(undefined4 *)((longlong)puVar1 + 0x24) = param_5[3];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CWorldKernel::helper_14007bbc0  @14007bbc0  [medium:callgraph-r2]  (orig: FUN_14007bbc0)
undefined8 *
FUN_14007bbc0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14007b8a0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CWorldKernel::helper_14007c080  @14007c080  [medium:callgraph-r1]  (orig: FUN_14007c080)
longlong * FUN_14007c080(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14007c1dd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14007c20c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14007c1dd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_14007bbc0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14007c20c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CWorldKernel::helper_14007c230  @14007c230  [medium:callgraph-r1]  (orig: FUN_14007c230)
undefined8 * FUN_14007c230(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14007b0a0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14007c41c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14007c41c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14007b380(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14007af30(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_14007b380(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14007af30(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14007b380(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_14007af30(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CWorldKernel::helper_14007c950  @14007c950  [medium:callgraph-r0]  (orig: FUN_14007c950)
bool FUN_14007c950(longlong param_1,uint param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar6 + 3) < param_2) {
      puVar4 = (undefined8 *)puVar6[2];
      puVar6 = puVar3;
    }
    else {
      puVar4 = (undefined8 *)*puVar6;
    }
    puVar3 = puVar6;
    puVar6 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x29);
  }
  puVar6 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar6) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar5 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar5 = &local_38;
  }
  local_18 = *plVar5;
  lVar2 = *(longlong *)(param_1 + 0x38);
  local_10 = plVar5[1];
  if ((local_18 == 0) || (local_18 != *(longlong *)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  return local_10 != lVar2;
}

// ==== CWorldKernel::helper_14007ca30  @14007ca30  [medium:callgraph-r0]  (orig: FUN_14007ca30)
void FUN_14007ca30(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  uint uVar6;
  longlong *plVar7;
  uint uVar8;
  longlong lVar9;
  longlong *plStack_50;
  longlong *local_48;
  longlong *plStack_40;
  undefined1 local_38 [32];
  
  uVar6 = _time32((__time32_t *)0x0);
  uVar8 = 0;
  plVar7 = (longlong *)**(longlong **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  plStack_50 = plVar7;
  while( true ) {
    plVar4 = plStack_50;
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar3) break;
    uVar8 = uVar8 + 1;
    if (1000000 < uVar8) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (plVar7 == *(longlong **)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((uint)((int)plVar7[4] + *(int *)((longlong)plVar7 + 0x24)) < uVar6) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
        plVar3 = (longlong *)plVar7[2];
        if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar7 = plVar3;
          plVar3 = (longlong *)*plVar3;
          while (plStack_50 = plVar7, cVar1 == '\0') {
            cVar1 = *(char *)(*plVar3 + 0x29);
            plVar7 = plVar3;
            plVar3 = (longlong *)*plVar3;
          }
        }
        else {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar5 = (longlong *)plVar7[1];
          plVar3 = plVar7;
          while ((plVar7 = plVar5, plStack_50 = plVar7, cVar1 == '\0' &&
                 (plVar3 == (longlong *)plVar7[2]))) {
            cVar1 = *(char *)(plVar7[1] + 0x29);
            plVar5 = (longlong *)plVar7[1];
            plVar3 = plVar7;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      plStack_40 = plVar4;
      local_48 = plVar2;
      FUN_14007c230(param_1 + 8,local_38,&local_48);
    }
    else {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
        plVar3 = (longlong *)plVar7[2];
        if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar7 = plVar3;
          plVar3 = (longlong *)*plVar3;
          while (plStack_50 = plVar7, cVar1 == '\0') {
            cVar1 = *(char *)(*plVar3 + 0x29);
            plVar7 = plVar3;
            plVar3 = (longlong *)*plVar3;
          }
        }
        else {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar4 = (longlong *)plVar7[1];
          plVar3 = plVar7;
          while ((plVar7 = plVar4, plStack_50 = plVar7, cVar1 == '\0' &&
                 (plVar3 == (longlong *)plVar7[2]))) {
            cVar1 = *(char *)(plVar7[1] + 0x29);
            plVar4 = (longlong *)plVar7[1];
            plVar3 = plVar7;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_14007cc60  @14007cc60  [medium:callgraph-r1]  (orig: FUN_14007cc60)
longlong FUN_14007cc60(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_14007b7c0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_14007c6e0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CWorldKernel::helper_14007cf20  @14007cf20  [medium:callgraph-r0]  (orig: FUN_14007cf20)
void FUN_14007cf20(longlong param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 local_res10 [2];
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined1 local_28 [32];
  
  local_res10[0] = param_2;
  FUN_14007cc60(param_1 + 8,local_res10);
  local_34 = *param_3;
  local_30 = param_3[1];
  local_2c = param_3[2];
  local_38 = param_2;
  FUN_14007c080(param_1 + 8,local_28,&local_38);
  return;
}

// ==== CWorldKernel::helper_14007d140  @14007d140  [medium:callgraph-r2]  (orig: FUN_14007d140)
undefined8 * FUN_14007d140(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgName::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x85),(char *)((longlong)param_1 + 0x19),0x3f5,true);
  return param_1;
}

// ==== CWorldKernel::helper_14007d1c0  @14007d1c0  [medium:callgraph-r2]  (orig: FUN_14007d1c0)
void FUN_14007d1c0(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgName::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  return;
}

// ==== CWorldKernel::helper_14007d2d0  @14007d2d0  [medium:callgraph-r2]  (orig: FUN_14007d2d0)
undefined8 FUN_14007d2d0(longlong param_1,int param_2,undefined4 param_3)

{
  ulong uVar1;
  uint uVar2;
  
  if (param_2 == 0) {
    return 0;
  }
  FUN_1400752b0();
  *(char *)(*(longlong *)(param_1 + 0x420) + 8) = (char)param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 4) = param_3;
  uVar1 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x420) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0x3f7;
  uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x428));
  *(uint *)(param_1 + 0xc) = uVar2 + 0xb;
  return 1;
}

// ==== CWorldKernel::helper_14007d4b0  @14007d4b0  [medium:callgraph-r1]  (orig: FUN_14007d4b0)
undefined8
FUN_14007d4b0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             char *param_5)

{
  char cVar1;
  ulonglong uVar2;
  char *pcVar3;
  
  if (param_5 != (char *)0x0) {
    uVar2 = 0xffffffffffffffff;
    pcVar3 = param_5;
    do {
      if (uVar2 == 0) break;
      uVar2 = uVar2 - 1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    if (~uVar2 - 1 < 0xff) {
      FUN_1400752b0(param_1);
      *(undefined4 *)(param_1 + 0xc) = 0x10c;
      *(undefined4 *)(param_1 + 8) = 0x45b;
      **(undefined4 **)(param_1 + 0x420) = param_2;
      *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 4) = param_3;
      *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 8) = param_4;
      tq::SafeCopy((char *)(*(longlong *)(param_1 + 0x420) + 0xc),param_5,0x100);
      return 1;
    }
  }
  return 0;
}

// ==== CWorldKernel::helper_14007d670  @14007d670  [medium:callgraph-r2]  (orig: FUN_14007d670)
undefined8 FUN_14007d670(longlong param_1,undefined4 param_2,undefined1 param_3,undefined1 param_4)

{
  FUN_1400752b0();
  *(undefined4 *)(param_1 + 8) = 0x81e;
  *(undefined4 *)(param_1 + 0xc) = 8;
  **(undefined4 **)(param_1 + 0x420) = param_2;
  *(undefined1 *)(*(longlong *)(param_1 + 0x420) + 4) = param_3;
  *(undefined1 *)(*(longlong *)(param_1 + 0x420) + 5) = param_4;
  return 1;
}

// ==== CWorldKernel::helper_14007d7f0  @14007d7f0  [medium:callgraph-r2]  (orig: FUN_14007d7f0)
ulonglong FUN_14007d7f0(longlong param_1,char *param_2)

{
  char cVar1;
  ulonglong in_RAX;
  undefined7 extraout_var;
  ulonglong uVar2;
  char *pcVar3;
  
  if (param_2 != (char *)0x0) {
    uVar2 = 0xffffffffffffffff;
    in_RAX = 0;
    pcVar3 = param_2;
    do {
      if (uVar2 == 0) break;
      uVar2 = uVar2 - 1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    if (~uVar2 - 1 < 0xff) {
      FUN_1400752b0(param_1);
      *(undefined4 *)(param_1 + 0xc) = 0x100;
      *(undefined4 *)(param_1 + 8) = 0x822;
      tq::SafeCopy(*(char **)(param_1 + 0x420),param_2,0x100);
      return CONCAT71(extraout_var,1);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CWorldKernel::helper_14007d930  @14007d930  [medium:callgraph-r2]  (orig: FUN_14007d930)
undefined1 * FUN_14007d930(undefined8 *param_1)

{
  char cVar1;
  longlong lVar2;
  int iVar3;
  char *pcVar4;
  
  pcVar4 = (char *)*param_1;
  iVar3 = 0;
  DAT_140975b30 = 0;
  if (pcVar4 != (char *)0x0) {
    cVar1 = *pcVar4;
    while( true ) {
      if (' ' < cVar1) {
        cVar1 = *pcVar4;
        lVar2 = 0;
        do {
          if (lVar2 < 0x20) {
            (&DAT_140975b30)[lVar2] = cVar1;
            iVar3 = iVar3 + 1;
            lVar2 = lVar2 + 1;
          }
          cVar1 = pcVar4[1];
          pcVar4 = pcVar4 + 1;
        } while (' ' < cVar1);
        if (iVar3 == 0x20) {
          log_InlineLogERROR("Token exceeded %i chars, discarded.\n");
          iVar3 = 0;
        }
        (&DAT_140975b30)[iVar3] = 0;
        *param_1 = pcVar4;
        return &DAT_140975b30;
      }
      if (cVar1 == '\0') break;
      cVar1 = pcVar4[1];
      pcVar4 = pcVar4 + 1;
    }
  }
  return (undefined1 *)0x0;
}

// ==== CWorldKernel::ProcessConnect  @14007d9d0  [high:log-string]  (orig: FUN_14007d9d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14007d9d0(longlong *param_1,undefined4 param_2,int param_3,int param_4,char *param_5,
                  undefined4 param_6)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined8 uVar5;
  longlong lVar6;
  IStringManager *pIVar7;
  longlong *plVar8;
  undefined1 auStack_5e8 [32];
  char *local_5c8;
  undefined8 local_5c0;
  undefined2 local_5b8;
  undefined2 local_5b0;
  undefined4 local_5a8;
  undefined4 local_5a0;
  undefined1 local_598;
  undefined8 local_588;
  longlong local_580;
  undefined1 local_578 [24];
  undefined4 local_560;
  undefined1 local_55c [100];
  undefined4 local_4f8;
  undefined4 local_4f4;
  int local_4f0;
  undefined4 local_4ec;
  undefined4 local_4e8;
  char local_4e4 [76];
  char local_498 [1088];
  ulonglong local_58;
  
  local_588 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_5e8;
  local_5c8 = param_5;
  log_InlineLogFACEBOOK("Facebook:ProcessConnect, idUin:%u, idAccount:%u, dwData: %X, szInfo:%s");
  if (DAT_140975af8 == 0) {
    local_5c8 = (char *)CONCAT44(local_5c8._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar6 = DAT_140975af8;
  if (*(longlong *)(DAT_140975af8 + 0x60) == 0) {
    local_5c8 = (char *)CONCAT44(local_5c8._4_4_,0x5c);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  iVar3 = *(int *)(*(longlong *)(lVar6 + 0x60) + 0x68);
  piVar4 = (int *)MaxPlayerGet();
  if ((*piVar4 < iVar3) && (1000 < param_3)) {
    uVar5 = FUN_140054e10();
    iVar3 = FUN_14006eb00(uVar5,param_3);
    if (iVar3 == 0) {
      uVar5 = FUN_140054dc0();
      FUN_140055820(uVar5,param_3,7);
      return;
    }
  }
  lVar6 = (**(code **)(*(longlong *)param_1[0x1d] + 0x40))((longlong *)param_1[0x1d],param_3);
  if (lVar6 != 0) {
    cVar2 = FUN_1400737b0(lVar6);
    if (cVar2 != '\0') {
      cVar2 = FUN_14007c950(param_1 + 0x13,param_3);
      if (cVar2 != '\0') {
        FUN_14007a560(local_498);
        pIVar7 = theInstance();
        uVar5 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ERROR_GIVE_BACK");
        local_598 = 1;
        local_5a0 = 0;
        local_5a8 = 0;
        local_5b0 = 0;
        local_5b8 = 0x835;
        local_5c0 = CONCAT44(local_5c0._4_4_,0xffffff);
        local_5c8 = (char *)0x0;
        iVar3 = FUN_14007a620(local_498,"SYSTEM","ALLUSERS",uVar5);
        if (iVar3 != 0) {
          (**(code **)(*param_1 + 0x38))(param_1,*(undefined4 *)(lVar6 + 0x30),local_498);
        }
        uVar1 = *(undefined4 *)(lVar6 + 0x30);
        uVar5 = FUN_140054e10();
        FUN_1400674b0(uVar5,uVar1,param_3);
        (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_3);
        log_InlineLogFACEBOOK("Facebook:m_PunishDisableLogin.IsDisable(idAccount)");
        FUN_14007a5e0(local_498);
        return;
      }
      uVar5 = FUN_140054e10();
      iVar3 = FUN_14006eb00(uVar5,param_3);
      if ((iVar3 == 0) && (cVar2 = FUN_1400561b0(param_1), cVar2 == '\0')) {
        FUN_14007a560(local_498);
        pIVar7 = theInstance();
        uVar5 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ERROR_SERVER_BUSY");
        local_598 = 1;
        local_5a0 = 0;
        local_5a8 = 0;
        local_5b0 = 0;
        local_5b8 = 0x835;
        local_5c0 = CONCAT44(local_5c0._4_4_,0xffffff);
        local_5c8 = (char *)0x0;
        iVar3 = FUN_14007a620(local_498,"SYSTEM","ALLUSERS",uVar5);
        if (iVar3 != 0) {
          (**(code **)(*param_1 + 0x38))(param_1,*(undefined4 *)(lVar6 + 0x30),local_498);
        }
        uVar1 = *(undefined4 *)(lVar6 + 0x30);
        uVar5 = FUN_140054e10();
        FUN_1400674b0(uVar5,uVar1,param_3);
        (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_3);
        log_InlineLogFACEBOOK
                  ("Facebook:0 == UserList()->GetVipLevel(idAccount) && !CheckLoginCount()");
        FUN_14007a5e0(local_498);
        return;
      }
      cVar2 = FUN_1400737b0(lVar6);
      if ((cVar2 != '\0') && (*(int *)(lVar6 + 0xc) == param_4)) {
        uVar1 = *(undefined4 *)(lVar6 + 0x30);
        lVar6 = FUN_140054bc0();
        local_5c0 = 0;
        local_5c8._0_4_ = 0xffffffff;
        cVar2 = FUN_1400737f0(lVar6,param_3,param_4,param_5);
        if (cVar2 == '\0') {
          local_5c8 = (char *)CONCAT44(local_5c8._4_4_,0xd9);
          log_InlineLogERROR(&DAT_1406d9c10);
          return;
        }
        *(undefined4 *)(lVar6 + 0x80) = param_6;
        (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_3);
        (**(code **)(*(longlong *)param_1[0x1e] + 0x28))();
        local_4e8 = 0;
        memset(local_4e4,0,0x41);
        local_4f8 = 3;
        local_4f4 = param_2;
        local_4f0 = param_3;
        local_4ec = uVar1;
        tq::SafeCopy(local_4e4,param_5,0x41);
        *(int *)(param_1 + 0x58) = (int)param_1[0x58] + 1;
        local_560 = (undefined4)param_1[0x58];
        memcpy(local_55c,&local_4f8,0x58);
        FUN_14005d530(param_1 + 0x50,local_578,&local_560);
        memset(local_498,0,0x400);
        sprintf(local_498," worlduserlogin****worlduserlogin [%u]");
        uVar5 = FUN_140054dc0();
        plVar8 = (longlong *)InstanceGet(uVar5);
        (**(code **)(*plVar8 + 0x30))(plVar8,local_498,0,0);
        return;
      }
      cVar2 = FUN_1400737b0(lVar6);
      if ((cVar2 != '\0') && (*(int *)(lVar6 + 0xc) != param_4)) {
        local_5c0 = CONCAT44(local_5c0._4_4_,0xf2);
        local_5c8 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\wordkernelfb.cpp";
        log_InlineLogERROR(
                          "CWorldKernel::ProcessConnect() checkdata error, Account: %u, dwData: %u, szInfo:%s at %s, %d"
                          );
      }
      uVar1 = *(undefined4 *)(lVar6 + 0x30);
      uVar5 = FUN_140054e10();
      FUN_1400674b0(uVar5,uVar1,param_3);
      (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_3);
      return;
    }
    (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_3);
  }
  local_580 = FUN_140073590(0x88);
  lVar6 = 0;
  if (local_580 != 0) {
    lVar6 = FUN_1400736b0(local_580);
  }
  local_5c0 = 0;
  local_5c8._0_4_ = 0xffffffff;
  cVar2 = FUN_1400737f0(lVar6,param_3,param_4,param_5);
  if (cVar2 == '\0') {
    local_5c8 = (char *)CONCAT44(local_5c8._4_4_,0xfc);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    *(undefined4 *)(lVar6 + 0x80) = param_6;
    (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_3);
    (**(code **)(*(longlong *)param_1[0x1e] + 0x28))((longlong *)param_1[0x1e],lVar6);
  }
  return;
}

// ==== CWorldKernel::ClientConnect  @14007dfb0  [high:log-string]  (orig: FUN_14007dfb0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14007dfb0(longlong *param_1,undefined4 param_2,undefined4 param_3,int param_4,char *param_5
                  ,int param_6,int param_7,longlong param_8)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong lVar5;
  IStringManager *pIVar6;
  undefined1 auStack_648 [32];
  char *local_628;
  longlong local_620;
  int local_618;
  undefined2 local_610;
  undefined4 local_608;
  undefined4 local_600;
  undefined1 local_5f8;
  undefined4 local_5e8;
  undefined4 local_5e4;
  int local_5e0;
  undefined4 local_5dc;
  longlong local_5d8;
  char *local_5d0;
  longlong *local_5c8;
  undefined8 local_5c0;
  undefined1 local_5b8 [24];
  undefined4 local_5a0;
  undefined1 local_59c [100];
  undefined4 local_538;
  undefined4 local_534;
  undefined4 local_530;
  int local_52c;
  undefined4 local_528;
  char local_524 [76];
  char local_4d8 [1023];
  undefined1 local_d9;
  char local_98 [80];
  ulonglong local_48;
  
  local_5c0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_648;
  local_5d0 = param_5;
  local_5d8 = param_8;
  local_618 = param_7;
  local_620 = CONCAT44(local_620._4_4_,param_6);
  local_628 = param_5;
  local_5e8 = param_2;
  local_5e4 = param_3;
  local_5e0 = param_4;
  local_5dc = param_2;
  local_5c8 = param_1;
  log_InlineLogFACEBOOK
            (
            "Facebook:ClientConnect, idUin:%u, idAccount:%u, dwData:%X, szInfo:%s, idSocket:%s, dwIP:%X"
            );
  log_InlineLogFACEBOOK("Facebook:ClientConnect, szSessionKey: %s");
  if ((param_6 == -1) || (param_7 == 0)) {
    local_628 = (char *)CONCAT44(local_628._4_4_,0x10b);
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (param_8 == 0) {
    return;
  }
  if (((char)param_1[0x3c] != '\0') && (cVar1 = FUN_140056a70(param_1), cVar1 != '\0')) {
    _snprintf(local_4d8,0x400,"SELECT * FROM cq_appointment_account WHERE account=\'%s\'");
    local_d9 = 0;
    plVar3 = (longlong *)InstanceGet(param_1);
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,local_4d8,1);
    if (plVar3 == (longlong *)0x0) {
      local_628 = (char *)CONCAT44(local_628._4_4_,0x119);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar4 = FUN_140054e10();
      FUN_1400674b0(uVar4,param_6,0);
      return;
    }
    lVar5 = (**(code **)(*plVar3 + 0x40))(plVar3);
    if (lVar5 == 0) {
      uVar4 = FUN_140054e10();
      FUN_1400674b0(uVar4,param_6,0);
      (**(code **)*plVar3)(plVar3);
      return;
    }
    (**(code **)*plVar3)(plVar3);
  }
  lVar5 = (**(code **)(*(longlong *)param_1[0x1e] + 0x40))((longlong *)param_1[0x1e],param_3);
  if (lVar5 != 0) {
    cVar1 = FUN_1400737b0(lVar5);
    if (cVar1 != '\0') {
      log_InlineLogFACEBOOK("Facebook:ClientConnect, found connect in m_setConnectAccount");
      goto LAB_14007e1e0;
    }
    (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_3);
    lVar5 = 0;
  }
  log_InlineLogFACEBOOK("Facebook:ClientConnect, can not found connect in m_setConnectAccount");
LAB_14007e1e0:
  if (lVar5 == 0) {
    uVar4 = FUN_140054bc0();
    local_620 = local_5d8;
    local_628._0_4_ = param_6;
    cVar1 = FUN_1400737f0(uVar4,param_3,param_4,param_5);
    if (cVar1 == '\0') {
      local_628 = (char *)CONCAT44(local_628._4_4_,0x186);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_3);
      (**(code **)(*(longlong *)param_1[0x1d] + 0x28))((longlong *)param_1[0x1d],uVar4);
      FUN_140064330(param_1,param_3,param_7,param_6);
    }
  }
  else {
    cVar1 = FUN_14007c950(param_1 + 0x13,param_3);
    if (cVar1 == '\0') {
      uVar4 = FUN_140054e10();
      iVar2 = FUN_14006eb00(uVar4,param_3);
      if ((iVar2 == 0) && (cVar1 = FUN_1400561b0(param_1), cVar1 == '\0')) {
        log_InlineLogFACEBOOK("Facebook:ClientConnect, server busy");
        FUN_14007a560(local_4d8);
        pIVar6 = theInstance();
        uVar4 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_SERVER_BUSY");
        local_5f8 = 1;
        local_600 = 0;
        local_608 = 0;
        local_610 = 0;
        local_618 = CONCAT22(local_618._2_2_,0x835);
        local_620 = CONCAT44(local_620._4_4_,0xffffff);
        local_628 = (char *)0x0;
        iVar2 = FUN_14007a620(local_4d8,"SYSTEM","ALLUSERS",uVar4);
        if (iVar2 != 0) {
          (**(code **)(*param_1 + 0x38))(param_1,param_6,local_4d8);
        }
        uVar4 = FUN_140054e10();
        FUN_1400674b0(uVar4,param_6,param_3);
        (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_3);
        FUN_14007a5e0(local_4d8);
      }
      else {
        local_98[0] = '\0';
        local_98[1] = '\0';
        local_98[2] = '\0';
        local_98[3] = '\0';
        local_98[4] = '\0';
        local_98[5] = '\0';
        local_98[6] = '\0';
        local_98[7] = '\0';
        local_98[8] = '\0';
        local_98[9] = '\0';
        local_98[10] = '\0';
        local_98[0xb] = '\0';
        local_98[0xc] = '\0';
        local_98[0xd] = '\0';
        local_98[0xe] = '\0';
        local_98[0xf] = '\0';
        local_98[0x10] = '\0';
        local_98[0x11] = '\0';
        local_98[0x12] = '\0';
        local_98[0x13] = '\0';
        local_98[0x14] = '\0';
        local_98[0x15] = '\0';
        local_98[0x16] = '\0';
        local_98[0x17] = '\0';
        local_98[0x18] = '\0';
        local_98[0x19] = '\0';
        local_98[0x1a] = '\0';
        local_98[0x1b] = '\0';
        local_98[0x1c] = '\0';
        local_98[0x1d] = '\0';
        local_98[0x1e] = '\0';
        local_98[0x1f] = '\0';
        local_98[0x20] = '\0';
        local_98[0x21] = '\0';
        local_98[0x22] = '\0';
        local_98[0x23] = '\0';
        local_98[0x24] = '\0';
        local_98[0x25] = '\0';
        local_98[0x26] = '\0';
        local_98[0x27] = '\0';
        local_98[0x28] = '\0';
        local_98[0x29] = '\0';
        local_98[0x2a] = '\0';
        local_98[0x2b] = '\0';
        local_98[0x2c] = '\0';
        local_98[0x2d] = '\0';
        local_98[0x2e] = '\0';
        local_98[0x2f] = '\0';
        local_98[0x30] = '\0';
        local_98[0x31] = '\0';
        local_98[0x32] = '\0';
        local_98[0x33] = '\0';
        local_98[0x34] = '\0';
        local_98[0x35] = '\0';
        local_98[0x36] = '\0';
        local_98[0x37] = '\0';
        local_98[0x38] = '\0';
        local_98[0x39] = '\0';
        local_98[0x3a] = '\0';
        local_98[0x3b] = '\0';
        local_98[0x3c] = '\0';
        local_98[0x3d] = '\0';
        local_98[0x3e] = '\0';
        local_98[0x3f] = '\0';
        local_98[0x40] = '\0';
        tq::SafeCopy(local_98,(char *)(lVar5 + 0x10),0x41);
        cVar1 = FUN_1400737b0(lVar5);
        if ((cVar1 == '\0') || (*(int *)(lVar5 + 0xc) != param_4)) {
          log_InlineLogFACEBOOK("Facebook:ClientConnect: do not login user");
          cVar1 = FUN_1400737b0(lVar5);
          if ((cVar1 != '\0') && (*(int *)(lVar5 + 0xc) != param_4)) {
            local_620 = CONCAT44(local_620._4_4_,0x17c);
            local_628 = 
            "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\wordkernelfb.cpp";
            log_InlineLogWARNING
                      (
                      "CWorldKernel::ClientConnect() checkdata fault, Account: %u, dwData: %u, szInfo:%s at %s, %d"
                      );
          }
          uVar4 = FUN_140054e10();
          FUN_1400674b0(uVar4,param_6,param_3);
          (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_3);
        }
        else {
          log_InlineLogFACEBOOK
                    (
                    "Facebook:ClientConnect: pConnect->IsValid() && pConnect->CheckData(dwData), begin loginuser"
                    );
          uVar4 = FUN_140054bc0();
          local_620 = local_5d8;
          local_628._0_4_ = param_6;
          cVar1 = FUN_1400737f0(uVar4,param_3,param_4,param_5);
          if (cVar1 == '\0') {
            local_628 = (char *)CONCAT44(local_628._4_4_,0x163);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_3);
            (**(code **)(*(longlong *)param_1[0x1d] + 0x28))();
            local_528 = 0;
            memset(local_524,0,0x41);
            local_538 = 4;
            local_534 = local_5e8;
            local_52c = param_6;
            local_530 = param_3;
            tq::SafeCopy(local_524,local_98,0x41);
            *(int *)(param_1 + 0x58) = (int)param_1[0x58] + 1;
            local_5a0 = (undefined4)param_1[0x58];
            memcpy(local_59c,&local_538,0x58);
            FUN_14005d530(param_1 + 0x50,local_5b8,&local_5a0);
            memset(local_4d8,0,0x400);
            sprintf(local_4d8," worlduserlogin****worlduserlogin [%u]");
            uVar4 = FUN_140054dc0();
            plVar3 = (longlong *)InstanceGet(uVar4);
            (**(code **)(*plVar3 + 0x30))(plVar3,local_4d8,0,0);
          }
        }
      }
    }
    else {
      log_InlineLogFACEBOOK("Facebook:ClientConnect, m_PunishDisableLogin.IsDisable(idAccount)");
      FUN_14007a560(local_4d8);
      pIVar6 = theInstance();
      uVar4 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_GIVE_BACK");
      local_5f8 = 1;
      local_600 = 0;
      local_608 = 0;
      local_610 = 0;
      local_618 = CONCAT22(local_618._2_2_,0x835);
      local_620 = CONCAT44(local_620._4_4_,0xffffff);
      local_628 = (char *)0x0;
      iVar2 = FUN_14007a620(local_4d8,"SYSTEM","ALLUSERS",uVar4);
      if (iVar2 != 0) {
        (**(code **)(*param_1 + 0x38))(param_1,param_6,local_4d8);
      }
      uVar4 = FUN_140054e10();
      FUN_1400674b0(uVar4,param_6,param_3);
      (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_3);
      FUN_14007a5e0(local_4d8);
    }
  }
  return;
}

// ==== CWorldKernel::helper_14007e700  @14007e700  [medium:callgraph-r1]  (orig: FUN_14007e700)
void FUN_14007e700(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  char *param_5,undefined4 param_6)

{
  char *pcVar1;
  int iVar2;
  ulong uVar3;
  ulong uVar4;
  ulong uVar5;
  char *pcVar6;
  char *pcVar7;
  undefined8 uVar8;
  IStringManager *pIVar9;
  char *pcVar10;
  longlong lVar11;
  char cVar12;
  char *pcVar13;
  char *pcVar14;
  
  pcVar10 = param_5;
  log_InlineLogFACEBOOK
            ("Facebook:PlayerConnectByAccount, idUin: %u, idAccount:%u, dwData: %X, szInfo:%s");
  pcVar14 = (char *)0x0;
  DAT_140975b30 = 0;
  pcVar13 = pcVar10;
  pcVar7 = pcVar14;
  if (pcVar10 != (char *)0x0) {
    cVar12 = *pcVar10;
    pcVar6 = pcVar10;
    while (cVar12 < '!') {
      if (cVar12 == '\0') goto LAB_14007e7d6;
      pcVar1 = pcVar6 + 1;
      pcVar6 = pcVar6 + 1;
      cVar12 = *pcVar1;
    }
    cVar12 = *pcVar6;
    pcVar13 = pcVar14;
    do {
      if ((longlong)pcVar13 < 0x20) {
        pcVar13[0x140975b30] = cVar12;
        pcVar7 = (char *)(ulonglong)((int)pcVar7 + 1);
        pcVar13 = pcVar13 + 1;
      }
      iVar2 = (int)pcVar7;
      cVar12 = pcVar6[1];
      pcVar6 = pcVar6 + 1;
    } while (' ' < cVar12);
    if (iVar2 == 0x20) {
      param_5 = pcVar10;
      log_InlineLogERROR("Token exceeded %i chars, discarded.\n");
      iVar2 = 0;
    }
    (&DAT_140975b30)[iVar2] = 0;
    pcVar13 = pcVar6;
    pcVar7 = &DAT_140975b30;
  }
LAB_14007e7d6:
  param_5 = pcVar13;
  iVar2 = _stricmp("",pcVar10);
  uVar3 = 0;
  if ((iVar2 != 0) && (uVar3 = 0, *pcVar7 != '\0')) {
    iVar2 = _stricmp("vip",pcVar7);
    if (iVar2 == 0) {
      pcVar7 = (char *)FUN_14007d930(&param_5);
      pcVar13 = param_5;
      uVar3 = 0;
      if ((pcVar7 != (char *)0x0) && (uVar3 = 0, *pcVar7 != '\0')) {
        uVar3 = strtoul(pcVar7,(char **)0x0,10);
        pcVar13 = param_5;
      }
    }
    else {
      uVar3 = strtoul(pcVar7,(char **)0x0,10);
      pcVar7 = (char *)FUN_14007d930(&param_5);
      pcVar13 = param_5;
      if ((pcVar7 != (char *)0x0) && (*pcVar7 != '\0')) {
        uVar4 = strtoul(pcVar7,(char **)0x0,10);
        uVar5 = tq::TimeGet(3);
        pcVar14 = (char *)(ulonglong)((uVar5 / 10000 - (int)uVar4 / 100) + 0x76c < 0x12);
        pcVar13 = param_5;
      }
    }
  }
  if (*(char *)(param_1 + 0x200) != '\0') {
    uVar3 = 0;
  }
  uVar8 = FUN_140054e10();
  FUN_140072120(uVar8,param_3,uVar3);
  pIVar9 = theInstance();
  pcVar10 = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"Language");
  iVar2 = _stricmp(pcVar10,&DAT_1406e0658);
  if (iVar2 == 0) {
    uVar8 = FUN_140054e10();
  }
  else {
    uVar8 = FUN_140054e10();
    pcVar14 = (char *)0x0;
  }
  FUN_140072150(uVar8,param_3,pcVar14);
  iVar2 = _stricmp("",pcVar13);
  if (iVar2 != 0) {
    lVar11 = 0;
    iVar2 = 0;
    DAT_140975b30 = 0;
    if (pcVar13 == (char *)0x0) {
LAB_14007e9bf:
      pcVar7 = "";
    }
    else {
      cVar12 = *pcVar13;
      while (cVar12 < '!') {
        if (cVar12 == '\0') goto LAB_14007e9bf;
        pcVar10 = pcVar13 + 1;
        pcVar13 = pcVar13 + 1;
        cVar12 = *pcVar10;
      }
      cVar12 = *pcVar13;
      pcVar7 = &DAT_140975b30;
      do {
        if (lVar11 < 0x20) {
          (&DAT_140975b30)[lVar11] = cVar12;
          iVar2 = iVar2 + 1;
          lVar11 = lVar11 + 1;
        }
        cVar12 = pcVar13[1];
        pcVar13 = pcVar13 + 1;
      } while (' ' < cVar12);
      if (iVar2 == 0x20) {
        log_InlineLogERROR("Token exceeded %i chars, discarded.\n");
        iVar2 = 0;
      }
      (&DAT_140975b30)[iVar2] = 0;
    }
  }
  FUN_14007d9d0(param_1,param_2,param_3,param_4,pcVar7,param_6);
  return;
}

// ==== CWorldKernel::helper_14007ea10  @14007ea10  [medium:callgraph-r0]  (orig: FUN_14007ea10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_14007ea10(longlong *param_1,undefined4 param_2,undefined4 param_3,int param_4,
             undefined1 *param_5)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong lVar7;
  IStringManager *pIVar8;
  undefined4 *puVar9;
  undefined1 auStack_5f8 [32];
  undefined1 *local_5d8;
  longlong local_5d0;
  undefined2 local_5c8;
  undefined2 local_5c0;
  undefined4 local_5b8;
  undefined4 local_5b0;
  undefined1 local_5a8;
  int local_598 [2];
  undefined8 local_590;
  undefined1 local_588 [1088];
  undefined1 local_148;
  undefined1 local_147 [255];
  ulonglong local_48;
  
  local_590 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_5f8;
  local_5d8 = param_5;
  local_598[0] = param_4;
  log_InlineLogFACEBOOK("Facebook:LoginUser, idUin:%u, idAccount:%u, idSocket:%u, szInfo:%s");
  if (param_5 == (undefined1 *)0x0) {
    uVar6 = 0;
  }
  else {
    lVar5 = (**(code **)(*(longlong *)param_1[0x1d] + 0x40))((longlong *)param_1[0x1d],param_3);
    uVar6 = 0;
    if (lVar5 != 0) {
      if (param_4 == *(int *)(lVar5 + 0x30)) {
        uVar6 = FUN_140054e10();
        lVar7 = FUN_14006e620(uVar6,param_3);
        if (lVar7 == 0) {
          uVar4 = FUN_14005ce90(param_1,param_4);
          cVar1 = FUN_14005d0b0(param_1,uVar4);
          if (cVar1 == '\0') {
            FUN_14007a560(local_588);
            pIVar8 = theInstance();
            uVar6 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_ERROR_BANDIP");
            local_5a8 = 1;
            local_5b0 = 0;
            local_5b8 = 0;
            local_5c0 = 0;
            local_5c8 = 0x835;
            local_5d0 = CONCAT44(local_5d0._4_4_,0xffffff);
            local_5d8 = (undefined1 *)0x0;
            iVar2 = FUN_14007a620(local_588,"SYSTEM","ALLUSERS",uVar6);
            if (iVar2 != 0) {
              (**(code **)(*param_1 + 0x38))(param_1,param_4,local_588);
            }
            uVar6 = FUN_140054e10();
            FUN_1400674b0(uVar6,param_4,param_3);
            FUN_14007a5e0(local_588);
            uVar6 = 0;
          }
          else {
            uVar6 = FUN_140054e10();
            local_5d8 = param_5;
            local_5d0 = lVar5 + 0x38;
            iVar2 = FUN_1400864c0(uVar6,param_2,param_3,param_4);
            if (iVar2 == 0) {
              log_InlineLogFACEBOOK("Facebook: LoginUser, OK");
              (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_3);
              (**(code **)(*(longlong *)param_1[0x1d] + 0x30))((longlong *)param_1[0x1d],param_3);
              puVar9 = (undefined4 *)FUN_140053460(param_1 + 0x42,local_598);
              *puVar9 = param_3;
              *(int *)((longlong)param_1 + 0x8c) = *(int *)((longlong)param_1 + 0x8c) + 1;
              uVar6 = 1;
            }
            else if (iVar2 == 1) {
              log_InlineLogFACEBOOK("Facebook: LoginUser, Create new user");
              puVar9 = (undefined4 *)FUN_140053460(param_1 + 0x42,local_598);
              *puVar9 = param_3;
              FUN_1400568e0(param_1,param_3,0);
              FUN_14007a560(local_588);
              local_5a8 = 1;
              local_5b0 = 0;
              local_5b8 = 0;
              local_5c0 = 0;
              local_5c8 = 0x835;
              local_5d0 = CONCAT44(local_5d0._4_4_,0xffffff);
              local_5d8 = (undefined1 *)0x0;
              iVar2 = FUN_14007a620(local_588,"SYSTEM","ALLUSERS","NEW_ROLE");
              if (iVar2 != 0) {
                (**(code **)(*param_1 + 0x38))(param_1,param_4,local_588);
              }
              FUN_14007a5e0(local_588);
              uVar6 = 1;
            }
            else if (iVar2 == 2) {
              log_InlineLogFACEBOOK("Facebook: LoginUser, Ban");
              (**(code **)(*(longlong *)param_1[0x1e] + 0x30))((longlong *)param_1[0x1e],param_3);
              FUN_14007a560(local_588);
              pIVar8 = theInstance();
              uVar6 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_ERROR_LACK_OF_BALANCE");
              local_5a8 = 1;
              local_5b0 = 0;
              local_5b8 = 0;
              local_5c0 = 0;
              local_5c8 = 0x835;
              local_5d0 = CONCAT44(local_5d0._4_4_,0xffffff);
              local_5d8 = (undefined1 *)0x0;
              iVar2 = FUN_14007a620(local_588,"SYSTEM","ALLUSERS",uVar6);
              if (iVar2 != 0) {
                (**(code **)(*param_1 + 0x38))(param_1,param_4,local_588);
              }
              uVar6 = FUN_140054e10();
              FUN_1400674b0(uVar6,param_4,param_3);
              FUN_14007a5e0(local_588);
              uVar6 = 0;
            }
            else if (iVar2 == 3) {
              log_InlineLogERROR("GM Login Failed, kick out Account[%u]!");
              uVar6 = FUN_140054e10();
              FUN_1400674b0(uVar6,param_4,param_3);
              uVar6 = 0;
            }
            else {
              local_5d8 = (undefined1 *)CONCAT44(local_5d8._4_4_,0x1ff);
              log_InlineLogERROR("Account[%u] unknow login return: %d, kick out at %s, %d.!");
              uVar6 = FUN_140054e10();
              FUN_1400674b0(uVar6,param_4,param_3);
              uVar6 = 0;
            }
          }
        }
        else {
          iVar2 = FUN_14005ce90(param_1,param_4);
          iVar3 = FUN_14005ce90(param_1);
          if (iVar3 != iVar2) {
            local_148 = 0;
            memset(local_147,0,0xff);
            FUN_14007d430(local_588);
            FUN_14005d300(param_1,iVar2,&local_148,0x100);
            local_5d8 = &local_148;
            iVar2 = FUN_14007d4b0(local_588,0,param_3,iVar2);
            if (iVar2 != 0) {
              FUN_140067420(lVar7,local_588);
            }
            FUN_14007d480(local_588);
          }
          log_InlineLogWARNING("Account[%u] login repeat, kick out at %s, %d");
          uVar6 = FUN_140054e10();
          FUN_140070190(uVar6,param_3,"This account has been logged in.",0);
          uVar6 = FUN_140054e10();
          FUN_1400674b0(uVar6,param_4,param_3);
          uVar6 = 0;
        }
      }
      else {
        uVar6 = 0;
      }
    }
  }
  return uVar6;
}

// ==== CWorldKernel::helper_14007ef10  @14007ef10  [medium:callgraph-r1]  (orig: FUN_14007ef10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14007ef10(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  uint uVar2;
  int iVar3;
  ulonglong uVar4;
  undefined1 auStack_48 [32];
  undefined4 *local_28;
  undefined4 local_18;
  undefined4 local_14;
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_48;
  local_18 = param_2;
  local_14 = param_3;
  if (DAT_140975af8 == 0) {
    local_28 = (undefined4 *)CONCAT44(local_28._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar1 = *(longlong **)(DAT_140975af8 + 0x58);
  uVar4 = 0xe;
  uVar2 = (**(code **)(*plVar1 + 0x18))(plVar1);
  if (0xe < uVar2) {
    do {
      local_28 = &local_18;
      (**(code **)(*plVar1 + 0x50))(plVar1,uVar4 & 0xffffffff,0x3f6,8);
      uVar4 = uVar4 + 1;
      iVar3 = (**(code **)(*plVar1 + 0x18))(plVar1);
    } while (uVar4 < (ulonglong)(longlong)iVar3);
  }
  return;
}

// ==== CWorldKernel::helper_14007efe0  @14007efe0  [medium:callgraph-r1]  (orig: FUN_14007efe0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14007efe0(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  undefined1 auStack_448 [32];
  undefined4 local_428;
  char local_418;
  undefined1 local_417 [1023];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_418 = '\0';
  memset(local_417,0,0x3ff);
  local_428 = param_3;
  _snprintf(&local_418,0x3ff,"INSERT cq_superman SET id=%u,number=%d");
  if (DAT_140975af8 == 0) {
    local_428 = 0x128;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar1 = (longlong *)InstanceGet(DAT_140975af8);
  (**(code **)(*plVar1 + 0x30))(plVar1,&local_418,0,1);
  return;
}

// ==== CWorldKernel::helper_14007f0c0  @14007f0c0  [medium:callgraph-r1]  (orig: FUN_14007f0c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14007f0c0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined1 auStack_448 [32];
  undefined4 local_428;
  char local_418;
  undefined1 local_417 [1023];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_418 = '\0';
  memset(local_417,0,0x3ff);
  local_428 = param_2;
  _snprintf(&local_418,0x3ff,"UPDATE cq_superman SET number=%d WHERE id=%u LIMIT 1");
  if (DAT_140975af8 == 0) {
    local_428 = 0x128;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar1 = (longlong *)InstanceGet(DAT_140975af8);
  (**(code **)(*plVar1 + 0x30))(plVar1,&local_418,0,1);
  return;
}

// ==== CWorldKernel::helper_14007f1a0  @14007f1a0  [medium:callgraph-r1]  (orig: FUN_14007f1a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14007f1a0(void)

{
  longlong *plVar1;
  undefined1 auStack_448 [32];
  undefined4 local_428;
  char local_418;
  undefined1 local_417 [1023];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_418 = '\0';
  memset(local_417,0,0x3ff);
  _snprintf(&local_418,0x3ff,"DELETE FROM cq_superman WHERE id=%u LIMIT 1");
  if (DAT_140975af8 == 0) {
    local_428 = 0x128;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar1 = (longlong *)InstanceGet(DAT_140975af8);
  (**(code **)(*plVar1 + 0x30))(plVar1,&local_418,0,1);
  return;
}

// ==== CWorldKernel::helper_14007f390  @14007f390  [medium:callgraph-r3]  (orig: FUN_14007f390)
void FUN_14007f390(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CWorldKernel::helper_14007f750  @14007f750  [medium:callgraph-r1]  (orig: FUN_14007f750)
void FUN_14007f750(__uint64 param_1)

{
  if ((DAT_140975b58 & 1) == 0) {
    DAT_140975b58 = DAT_140975b58 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975b50,"CSupermanList");
    atexit((_func_5014 *)&LAB_1406d65f0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014007f7a5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140975b50,param_1);
  return;
}

// ==== CWorldKernel::helper_14007f870  @14007f870  [medium:callgraph-r0]  (orig: FUN_14007f870)
void FUN_14007f870(longlong param_1,int param_2)

{
  int iVar1;
  ulonglong uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  
  lVar5 = *(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20);
  uVar3 = 0;
  uVar2 = 0;
  lVar5 = lVar5 / 6 + (lVar5 >> 0x3f);
  lVar6 = lVar5 >> 2;
  lVar5 = lVar5 >> 0x3f;
  if (lVar6 != lVar5) {
    lVar4 = 0;
    do {
      if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) <=
          uVar2) {
        _invalid_parameter_noinfo();
      }
      if (*(int *)(lVar4 + *(longlong *)(param_1 + 0x20)) == param_2) {
        iVar1 = (int)uVar2;
        if (iVar1 < 0) {
          if (2 < iVar1) goto LAB_14007f924;
          if (iVar1 < 0x32) goto LAB_14007f940;
        }
        else {
          if (iVar1 < 3) {
            uVar3 = 3;
            goto LAB_14007f940;
          }
LAB_14007f924:
          if (iVar1 < 0x32) {
            uVar3 = 2;
            goto LAB_14007f940;
          }
        }
        uVar3 = 0;
        if (iVar1 < 100) {
          uVar3 = 1;
        }
LAB_14007f940:
        FUN_14007ef10(param_1,param_2,uVar3);
        return;
      }
      uVar2 = uVar2 + 1;
      lVar4 = lVar4 + 0x18;
    } while (uVar2 < (ulonglong)(lVar6 - lVar5));
  }
  return;
}

// ==== CWorldKernel::helper_14007f970  @14007f970  [medium:callgraph-r0]  (orig: FUN_14007f970)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14007f970(longlong param_1,undefined4 param_2,uint param_3,int param_4,undefined4 param_5)

{
  longlong lVar1;
  int iVar2;
  undefined8 uVar3;
  longlong lVar4;
  IStringManager *pIVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  longlong lVar8;
  ulonglong uVar9;
  undefined1 auStack_a08 [32];
  undefined8 local_9e8;
  undefined4 local_9e0;
  undefined8 local_9d8;
  undefined1 local_9c8 [1088];
  undefined1 local_588 [1088];
  char local_148;
  undefined1 local_147 [255];
  ulonglong local_48;
  
  local_9d8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_a08;
  uVar6 = (ulonglong)(int)param_3;
  if ((int)param_3 < 0) {
    local_9e8 = CONCAT44(local_9e8._4_4_,0xd7);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar3 = FUN_140054e10();
    lVar4 = FUN_14006e3a0(uVar3,param_2);
    if (lVar4 != 0) {
      FUN_140082700(local_9c8);
      pIVar5 = theInstance();
      uVar3 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_KO_LIST_TITLE");
      local_9e8 = (ulonglong)local_9e8._4_4_ << 0x20;
      iVar2 = FUN_1400827c0(local_9c8,1,uVar3,0xffffffff);
      if (iVar2 != 0) {
        FUN_140067420(lVar4,local_9c8);
      }
      local_9e8 = local_9e8 & 0xffffffff00000000;
      iVar2 = FUN_1400827c0(local_9c8,1,"-------------------------");
      if (iVar2 == 0) {
        local_9e8 = CONCAT44(local_9e8._4_4_,0xe7);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_140067420(lVar4,local_9c8);
      }
      FUN_140082780(local_9c8);
      param_4 = param_3 + param_4;
      if ((int)param_3 < param_4) {
        lVar8 = uVar6 * 0x18;
        uVar7 = uVar6;
        do {
          param_3 = (uint)uVar6;
          if ((int)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) <=
              (int)param_3) break;
          local_148 = '\0';
          memset(local_147,0,0xff);
          if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) <=
              uVar7) {
            _invalid_parameter_noinfo();
          }
          lVar1 = *(longlong *)(param_1 + 0x20);
          uVar9 = (ulonglong)(int)param_3;
          if ((ulonglong)((*(longlong *)(param_1 + 0x28) - lVar1) / 0x18) <= uVar9) {
            _invalid_parameter_noinfo();
          }
          param_3 = param_3 + 1;
          uVar6 = (ulonglong)param_3;
          local_9e8 = *(longlong *)(param_1 + 0x20) + 8 + uVar9 * 0x18;
          local_9e0 = *(undefined4 *)(lVar8 + 4 + lVar1);
          _snprintf(&local_148,0xff,"%3d %-16s %d");
          FUN_140082700(local_9c8);
          local_9e8 = local_9e8 & 0xffffffff00000000;
          iVar2 = FUN_1400827c0(local_9c8,1,&local_148,0xffffffff);
          if (iVar2 == 0) {
            local_9e8 = CONCAT44(local_9e8._4_4_,0xf2);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            FUN_140067420(lVar4,local_9c8);
          }
          FUN_140082780(local_9c8);
          uVar7 = uVar7 + 1;
          lVar8 = lVar8 + 0x18;
        } while ((int)param_3 < param_4);
      }
      FUN_140082700(local_9c8);
      local_9e8 = local_9e8 & 0xffffffff00000000;
      iVar2 = FUN_1400827c0(local_9c8,1,"-------------------------");
      if (iVar2 == 0) {
        local_9e8 = CONCAT44(local_9e8._4_4_,0xfb);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_140067420(lVar4,local_9c8);
      }
      FUN_140082780(local_9c8);
      if (param_4 <= (int)param_3) {
        FUN_140082700(local_9c8);
        pIVar5 = theInstance();
        uVar3 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_NEXT_PAGE");
        local_9e8 = local_9e8 & 0xffffffff00000000;
        iVar2 = FUN_1400827c0(local_9c8,2,uVar3,param_5);
        if (iVar2 != 0) {
          FUN_140067420(lVar4,local_9c8);
        }
        FUN_140082780(local_9c8);
      }
      FUN_140082700(local_9c8);
      pIVar5 = theInstance();
      uVar3 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_CLOSE_BUTTON");
      local_9e8 = local_9e8 & 0xffffffff00000000;
      iVar2 = FUN_1400827c0(local_9c8,2,uVar3);
      if (iVar2 != 0) {
        FUN_140067420(lVar4,local_9c8);
      }
      FUN_140082780(local_9c8);
      FUN_140082700(local_588);
      iVar2 = FUN_140082990(local_588,100);
      if (iVar2 == 0) {
        local_9e8 = CONCAT44(local_9e8._4_4_,0x112);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_140067420(lVar4,local_588);
      }
      FUN_140082780(local_588);
    }
  }
  return;
}

// ==== CWorldKernel::helper_14007fe50  @14007fe50  [medium:callgraph-r3]  (orig: FUN_14007fe50)
void FUN_14007fe50(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x18)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x18);
  return;
}

// ==== CWorldKernel::helper_14007ff20  @14007ff20  [medium:callgraph-r1]  (orig: FUN_14007ff20)
longlong FUN_14007ff20(undefined4 *param_1,undefined4 *param_2,longlong param_3)

{
  longlong lVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  if (param_1 != param_2) {
    lVar1 = param_3 - (longlong)param_1;
    puVar2 = param_1;
    do {
      puVar3 = puVar2 + 6;
      *(undefined4 *)(lVar1 + -0x18 + (longlong)puVar3) = *puVar2;
      *(undefined4 *)(lVar1 + -0x14 + (longlong)puVar3) = puVar2[1];
      *(undefined4 *)(lVar1 + -0x10 + (longlong)puVar3) = puVar2[2];
      *(undefined4 *)(lVar1 + -0xc + (longlong)puVar3) = puVar2[3];
      *(undefined4 *)(lVar1 + -8 + (longlong)puVar3) = puVar2[4];
      *(undefined4 *)(lVar1 + -4 + (longlong)puVar3) = puVar2[5];
      puVar2 = puVar3;
    } while (puVar3 != param_2);
  }
  return param_3 + (((longlong)param_2 - (longlong)param_1) / 0x18) * 0x18;
}

// ==== CWorldKernel::helper_14007fff0  @14007fff0  [medium:callgraph-r3]  (orig: FUN_14007fff0)
longlong FUN_14007fff0(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  
  if (param_1 != param_2) {
    lVar1 = param_3 - param_2;
    lVar2 = param_2;
    do {
      lVar3 = lVar2 + -0x18;
      *(undefined4 *)(lVar1 + lVar3) = *(undefined4 *)(lVar2 + -0x18);
      *(undefined4 *)(lVar1 + 4 + lVar3) = *(undefined4 *)(lVar2 + -0x14);
      *(undefined4 *)(lVar1 + 8 + lVar3) = *(undefined4 *)(lVar2 + -0x10);
      *(undefined4 *)(lVar1 + 0xc + lVar3) = *(undefined4 *)(lVar2 + -0xc);
      *(undefined4 *)(lVar1 + 0x10 + lVar3) = *(undefined4 *)(lVar2 + -8);
      *(undefined4 *)(lVar1 + 0x14 + lVar3) = *(undefined4 *)(lVar2 + -4);
      lVar2 = lVar3;
    } while (lVar3 != param_1);
  }
  return param_3 + ((param_2 - param_1) / 0x18) * -0x18;
}

// ==== CWorldKernel::helper_140080080  @140080080  [medium:callgraph-r3]  (orig: FUN_140080080)
undefined4 * FUN_140080080(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 6) {
    if (param_3 != (undefined4 *)0x0) {
      *param_3 = *param_1;
      param_3[1] = param_1[1];
      param_3[2] = param_1[2];
      param_3[3] = param_1[3];
      param_3[4] = param_1[4];
      param_3[5] = param_1[5];
    }
    param_3 = param_3 + 6;
  }
  return param_3;
}

// ==== CWorldKernel::helper_140080360  @140080360  [medium:callgraph-r3]  (orig: FUN_140080360)
void FUN_140080360(undefined4 *param_1,longlong param_2,undefined4 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined4 *)0x0) {
      *param_1 = *param_3;
      param_1[1] = param_3[1];
      param_1[2] = param_3[2];
      param_1[3] = param_3[3];
      param_1[4] = param_3[4];
      param_1[5] = param_3[5];
    }
    param_1 = param_1 + 6;
  }
  return;
}

// ==== CWorldKernel::helper_1400809f0  @1400809f0  [medium:callgraph-r2]  (orig: FUN_1400809f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400809f0(longlong param_1,longlong param_2,ulonglong param_3,undefined4 *param_4)

{
  ulonglong uVar1;
  void *pvVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined4 *puVar6;
  ulonglong uVar7;
  undefined4 *puVar8;
  undefined1 auStack_a8 [32];
  undefined1 local_88;
  undefined1 local_80;
  undefined1 local_78;
  undefined4 local_74;
  longlong local_70;
  longlong local_68;
  undefined8 local_60;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  ulonglong local_40;
  
  local_60 = 0xfffffffffffffffe;
  local_40 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  lVar5 = *(longlong *)(param_1 + 0x18);
  if (lVar5 == 0) {
    uVar7 = 0;
  }
  else {
    lVar3 = *(longlong *)(param_1 + 0x28) - lVar5;
    lVar3 = lVar3 / 6 + (lVar3 >> 0x3f);
    uVar7 = (lVar3 >> 2) - (lVar3 >> 0x3f);
  }
  if (param_3 != 0) {
    lVar3 = *(longlong *)(param_1 + 0x20);
    lVar5 = (lVar3 - lVar5) / 0x18;
    if (0xaaaaaaaaaaaaaaaU - lVar5 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14007f390();
    }
    uVar1 = lVar5 + param_3;
    if (uVar7 < uVar1) {
      if (0xaaaaaaaaaaaaaaa - (uVar7 >> 1) < uVar7) {
        uVar7 = 0;
      }
      else {
        uVar7 = uVar7 + (uVar7 >> 1);
      }
      if (uVar7 < uVar1) {
        uVar7 = uVar1;
      }
      lVar3 = FUN_14007fe50(param_1 + 0x10,uVar7);
      lVar5 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18);
      lVar5 = lVar5 / 6 + (lVar5 >> 0x3f);
      local_70 = (lVar5 >> 2) - (lVar5 >> 0x3f);
      local_80 = 0;
      local_88 = local_78;
      local_68 = lVar3;
      FUN_140080360(lVar3 + local_70 * 0x18,param_3,param_4,param_1 + 0x10);
      local_74 = 1;
      local_80 = 0;
      local_88 = local_78;
      FUN_140080080(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar3,
                    param_1 + 0x10);
      local_74 = 2;
      local_80 = 0;
      local_88 = local_78;
      FUN_140080080(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    lVar3 + (local_70 + param_3) * 0x18,param_1 + 0x10);
      pvVar2 = *(void **)(param_1 + 0x18);
      lVar5 = *(longlong *)(param_1 + 0x20);
      if (pvVar2 != (void *)0x0) {
        operator_delete(pvVar2);
      }
      *(ulonglong *)(param_1 + 0x28) = lVar3 + uVar7 * 0x18;
      *(ulonglong *)(param_1 + 0x20) = lVar3 + (param_3 + (lVar5 - (longlong)pvVar2) / 0x18) * 0x18;
      *(longlong *)(param_1 + 0x18) = lVar3;
    }
    else if ((ulonglong)((lVar3 - *(longlong *)(param_2 + 8)) / 0x18) < param_3) {
      local_58 = *param_4;
      local_54 = param_4[1];
      local_50 = param_4[2];
      local_4c = param_4[3];
      local_48 = param_4[4];
      local_44 = param_4[5];
      local_80 = 0;
      FUN_140080080(*(longlong *)(param_2 + 8),lVar3,*(longlong *)(param_2 + 8) + param_3 * 0x18,
                    param_1 + 0x10);
      local_80 = 0;
      local_88 = local_78;
      FUN_140080360(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x18,
                    &local_58,param_1 + 0x10);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x18;
      lVar5 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined4 **)(param_2 + 8); puVar6 != (undefined4 *)(lVar5 + param_3 * -0x18)
          ; puVar6 = puVar6 + 6) {
        *puVar6 = local_58;
        puVar6[1] = local_54;
        puVar6[2] = local_50;
        puVar6[3] = local_4c;
        puVar6[4] = local_48;
        puVar6[5] = local_44;
      }
    }
    else {
      local_58 = *param_4;
      local_54 = param_4[1];
      local_50 = param_4[2];
      local_4c = param_4[3];
      local_48 = param_4[4];
      local_44 = param_4[5];
      lVar5 = lVar3 + param_3 * -0x18;
      local_80 = 0;
      uVar4 = FUN_140080080(lVar5,lVar3,lVar3,param_1 + 0x10);
      *(undefined8 *)(param_1 + 0x20) = uVar4;
      local_80 = 0;
      local_88 = local_78;
      FUN_14007fff0(*(undefined8 *)(param_2 + 8),lVar5,lVar3,local_78);
      puVar8 = *(undefined4 **)(param_2 + 8);
      puVar6 = puVar8 + param_3 * 6;
      for (; puVar8 != puVar6; puVar8 = puVar8 + 6) {
        *puVar8 = local_58;
        puVar8[1] = local_54;
        puVar8[2] = local_50;
        puVar8[3] = local_4c;
        puVar8[4] = local_48;
        puVar8[5] = local_44;
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_140080e70  @140080e70  [medium:callgraph-r1]  (orig: FUN_140080e70)
longlong * FUN_140080e70(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[3];
  lVar5 = param_1[4] - uVar1;
  lVar3 = 0;
  lVar2 = lVar5 >> 0x3f;
  lVar4 = lVar3;
  if (lVar5 / 0x18 + lVar2 != lVar2) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = (longlong)(param_3[1] - uVar1) / 6 + ((longlong)(param_3[1] - uVar1) >> 0x3f);
    lVar4 = (lVar2 >> 2) - (lVar2 >> 0x3f);
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1400809f0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 + lVar4 * 0x18;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar3 = *param_1;
    }
    if (*(ulonglong *)(lVar3 + 0x18) <= uVar1) goto LAB_140080f94;
  }
  _invalid_parameter_noinfo();
LAB_140080f94:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CWorldKernel::helper_140080fd0  @140080fd0  [medium:callgraph-r1]  (orig: FUN_140080fd0)
void FUN_140080fd0(longlong *param_1,ulonglong param_2,undefined8 param_3)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  longlong lVar5;
  longlong lVar6;
  undefined1 local_48;
  longlong local_38;
  ulonglong uStack_30;
  
  uVar1 = param_1[4];
  uVar2 = param_1[3];
  uVar4 = (longlong)(uVar1 - uVar2) / 0x18;
  if (uVar4 < param_2) {
    if (uVar1 < uVar2) {
      _invalid_parameter_noinfo();
    }
    local_38 = *param_1;
    uStack_30 = uVar1;
    FUN_1400809f0(param_1,&local_38,param_2 - (param_1[4] - param_1[3]) / 0x18,param_3);
    return;
  }
  if (uVar4 <= param_2) {
    return;
  }
  if (uVar1 < uVar2) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  plVar3 = (longlong *)*param_1;
  lVar5 = 0;
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = lVar5;
  }
  else {
    lVar6 = *plVar3;
  }
  uVar2 = uVar2 + param_2 * 0x18;
  if (uVar2 <= *(ulonglong *)(lVar6 + 0x20)) {
    if (plVar3 != (longlong *)0x0) {
      lVar5 = *plVar3;
    }
    if (*(ulonglong *)(lVar5 + 0x18) <= uVar2) goto LAB_1400810e0;
  }
  _invalid_parameter_noinfo();
LAB_1400810e0:
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar5 == 0) || (lVar5 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar5 = FUN_14007ff20(uVar1,param_1[4],uVar2,local_48,local_48,0);
    param_1[4] = lVar5;
  }
  return;
}

// ==== CWorldKernel::helper_1400811d0  @1400811d0  [medium:callgraph-r2]  (orig: FUN_1400811d0)
void FUN_1400811d0(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar4 = 0;
  }
  else {
    lVar3 = (longlong)(param_1[5] - uVar1) / 6 + ((longlong)(param_1[5] - uVar1) >> 0x3f);
    uVar4 = (lVar3 >> 2) - (lVar3 >> 0x3f);
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0x18) < uVar4) {
    FUN_140080360(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x18;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140080e70(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CWorldKernel::helper_1400812d0  @1400812d0  [medium:callgraph-r1]  (orig: FUN_1400812d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400812d0(longlong param_1)

{
  char cVar1;
  uint uVar2;
  longlong *plVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  longlong *plVar6;
  char *pcVar7;
  longlong lVar8;
  ulonglong uVar9;
  undefined1 auStack_78 [32];
  undefined4 local_58;
  uint local_48;
  longlong local_40;
  longlong *local_38;
  undefined8 local_30;
  undefined4 local_28;
  undefined4 local_24;
  char local_20 [16];
  ulonglong local_10;
  
  local_30 = 0xfffffffffffffffe;
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  local_40 = param_1;
  plVar3 = (longlong *)InstanceGet();
  plVar3 = (longlong *)
           (**(code **)(*plVar3 + 0x10))
                     (plVar3,
                      "SELECT cq_superman.id,cq_superman.number,cq_user.name FROM cq_superman LEFT JOIN cq_user ON cq_user.id=cq_superman.id ORDER BY number DESC LIMIT 100"
                      ,2);
  local_38 = plVar3;
  if (plVar3 == (longlong *)0x0) {
    local_58 = 0x3b;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = 0;
  }
  else {
    local_48 = 0;
    while( true ) {
      uVar2 = local_48;
      uVar9 = (ulonglong)local_48;
      uVar5 = (**(code **)(*plVar3 + 0x40))(plVar3);
      if (uVar5 <= uVar9) break;
      (**(code **)(*plVar3 + 0x30))(plVar3,uVar9);
      plVar6 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,&DAT_1406ef6e0);
      pcVar7 = (char *)(**(code **)(*plVar6 + 0x78))();
      lVar8 = -1;
      do {
        if (lVar8 == 0) break;
        lVar8 = lVar8 + -1;
        cVar1 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar1 != '\0');
      if (lVar8 == -2) {
        plVar6 = (longlong *)(**(code **)(*plVar3 + 0x38))(plVar3);
        if (plVar6 != (longlong *)0x0) {
          (**(code **)(*plVar6 + 0x40))(plVar6,0);
          (**(code **)*plVar6)(plVar6,1);
        }
      }
      else {
        plVar6 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,&DAT_1406de8d4);
        local_28 = (**(code **)(*plVar6 + 0x40))(plVar6);
        plVar6 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,"number");
        local_24 = (**(code **)(*plVar6 + 0x40))(plVar6);
        plVar6 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,&DAT_1406ef6e0);
        pcVar7 = (char *)(**(code **)(*plVar6 + 0x78))(plVar6);
        tq::StrCopy(local_20,pcVar7,0x10);
        FUN_1400811d0(param_1 + 8,&local_28);
      }
      local_48 = uVar2 + 1;
    }
    (**(code **)*plVar3)(plVar3);
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CWorldKernel::helper_1400814b0  @1400814b0  [medium:callgraph-r0]  (orig: FUN_1400814b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400814b0(longlong param_1,int param_2,int param_3)

{
  longlong *plVar1;
  int iVar2;
  int iVar3;
  undefined8 uVar4;
  IStringManager *pIVar5;
  char *_Format;
  longlong lVar6;
  uint uVar7;
  int iVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  longlong lVar11;
  uint uVar12;
  longlong lVar13;
  undefined1 auStack_968 [32];
  undefined8 local_948;
  uint local_940;
  uint local_938;
  undefined2 local_930;
  undefined4 local_928;
  undefined4 local_920;
  undefined1 local_918;
  undefined1 local_908;
  int local_904;
  int local_900;
  longlong *local_8f8;
  ulonglong uStack_8f0;
  undefined4 local_8e8;
  undefined4 local_8e4;
  longlong local_8d0;
  undefined4 local_8c8;
  undefined4 local_8c4;
  undefined4 local_8c0;
  undefined4 local_8bc;
  undefined4 local_8b8;
  undefined4 local_8b4;
  undefined8 local_8b0;
  int local_8a8;
  int local_8a4;
  char local_8a0 [24];
  undefined1 local_888 [1088];
  char local_448;
  undefined1 local_447 [1023];
  ulonglong local_48;
  
  local_8b0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_968;
  local_904 = param_2;
  local_900 = param_3;
  uVar4 = FUN_140054e10();
  local_8d0 = FUN_14006e3a0(uVar4,param_2);
  if (local_8d0 == 0) {
    local_948 = CONCAT44(local_948._4_4_,0x5b);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (99 < (ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18)) {
    uVar9 = (*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18 - 1;
    if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) <= uVar9
       ) {
      _invalid_parameter_noinfo();
    }
    if (param_3 <= *(int *)(*(longlong *)(param_1 + 0x20) + 4 + uVar9 * 0x18)) {
      return 0;
    }
  }
  iVar3 = -1;
  uVar10 = 0xffffffff;
  iVar8 = -1;
  lVar6 = *(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20);
  lVar6 = lVar6 / 6 + (lVar6 >> 0x3f);
  lVar13 = lVar6 >> 2;
  lVar6 = lVar6 >> 0x3f;
  uVar9 = 0;
  if (lVar13 != lVar6) {
    lVar11 = 0;
    do {
      if (iVar3 == -1) {
        if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) <=
            uVar9) {
          _invalid_parameter_noinfo();
        }
        if (*(int *)(lVar11 + *(longlong *)(param_1 + 0x20)) == param_2) {
          iVar3 = (int)uVar9;
        }
      }
      if ((int)uVar10 == -1) {
        if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) <=
            uVar9) {
          _invalid_parameter_noinfo();
        }
        if (*(int *)(*(longlong *)(param_1 + 0x20) + 4 + lVar11) < param_3) {
          uVar10 = uVar9 & 0xffffffff;
        }
      }
      iVar8 = (int)uVar10;
      uVar9 = uVar9 + 1;
      lVar11 = lVar11 + 0x18;
    } while (uVar9 < (ulonglong)(lVar13 - lVar6));
  }
  uVar12 = 0;
  if (iVar3 < 0) {
    if (2 < iVar3) goto LAB_1400816c4;
    if (iVar3 < 0x32) goto LAB_1400816dd;
LAB_1400816d6:
    if (iVar3 < 100) {
      uVar12 = 1;
    }
  }
  else if (iVar3 < 3) {
    uVar12 = 3;
  }
  else {
LAB_1400816c4:
    if (0x31 < iVar3) goto LAB_1400816d6;
    uVar12 = 2;
  }
LAB_1400816dd:
  if (iVar3 != -1) {
    uVar9 = *(ulonglong *)(param_1 + 0x20);
    if (*(ulonglong *)(param_1 + 0x28) < uVar9) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(param_1 + 8);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar1;
    }
    lVar13 = 0;
    uVar9 = uVar9 + (longlong)iVar3 * 0x18;
    if (*(ulonglong *)(lVar6 + 0x20) < uVar9) {
LAB_140081737:
      _invalid_parameter_noinfo();
    }
    else {
      if (plVar1 != (longlong *)0x0) {
        lVar13 = *plVar1;
      }
      if (uVar9 < *(ulonglong *)(lVar13 + 0x18)) goto LAB_140081737;
    }
    local_940 = local_940 & 0xffffff00;
    local_948 = CONCAT71(local_948._1_7_,local_908);
    FUN_14007ff20(uVar9 + 0x18,*(undefined8 *)(param_1 + 0x28),uVar9);
    *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + -0x18;
    if ((uVar9 < *(ulonglong *)(param_1 + 0x20)) || (*(ulonglong *)(param_1 + 0x28) < uVar9)) {
      _invalid_parameter_noinfo();
    }
    param_2 = local_904;
    if (iVar3 < iVar8) {
      iVar8 = iVar8 + -1;
    }
  }
  if (iVar8 == -1) {
    lVar6 = *(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20);
    lVar6 = lVar6 / 6 + (lVar6 >> 0x3f);
    iVar8 = (int)(lVar6 >> 2) - (int)(lVar6 >> 0x3f);
  }
  uVar7 = 0;
  if (iVar8 < 0) {
    if (2 < iVar8) goto LAB_1400817dd;
    if (iVar8 < 0x32) goto LAB_1400817f5;
LAB_1400817ee:
    if (iVar8 < 100) {
      uVar7 = 1;
    }
  }
  else if (iVar8 < 3) {
    uVar7 = 3;
  }
  else {
LAB_1400817dd:
    if (0x31 < iVar8) goto LAB_1400817ee;
    uVar7 = 2;
  }
LAB_1400817f5:
  local_8a8 = param_2;
  local_8a4 = param_3;
  tq::SafeCopy(local_8a0,(char *)(local_8d0 + 4),0x10);
  uVar9 = *(ulonglong *)(param_1 + 0x20);
  if (*(ulonglong *)(param_1 + 0x28) < uVar9) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 8);
  local_8f8 = plVar1;
  uStack_8f0 = uVar9;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar1;
  }
  uVar9 = uVar9 + (longlong)iVar8 * 0x18;
  if (*(ulonglong *)(lVar6 + 0x20) < uVar9) {
LAB_140081886:
    _invalid_parameter_noinfo();
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar1;
    }
    if (uVar9 < *(ulonglong *)(lVar6 + 0x18)) goto LAB_140081886;
  }
  uStack_8f0 = uVar9;
  FUN_140080e70(param_1 + 8,&local_8c8,&local_8f8,&local_8a8);
  if (100 < (ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18)) {
    if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) < 0x65)
    {
      _invalid_parameter_noinfo();
    }
    FUN_14007ef10(param_1,*(undefined4 *)(*(longlong *)(param_1 + 0x20) + 0x960),0);
    if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) < 0x65)
    {
      _invalid_parameter_noinfo();
    }
    FUN_14007f1a0(param_1,*(undefined4 *)(*(longlong *)(param_1 + 0x20) + 0x960));
    local_8c8 = 0;
    local_8c4 = 0;
    local_8c0 = 0;
    local_8bc = 0;
    local_8b8 = 0;
    local_8b4 = 0;
    local_8f8 = (longlong *)0x0;
    uStack_8f0 = 0;
    local_8e8 = 0;
    local_8e4 = 0;
    FUN_140080fd0(param_1 + 8,100,&local_8f8);
  }
  iVar3 = local_904;
  if (uVar12 != uVar7) {
    FUN_14007ef10(param_1,local_904,uVar7);
    if (uVar7 == 3) {
      if (3 < (ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18)) {
        if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) < 4)
        {
          _invalid_parameter_noinfo();
        }
        FUN_14007ef10(param_1,*(undefined4 *)(*(longlong *)(param_1 + 0x20) + 0x48),2);
      }
      if (1 < uVar12) goto LAB_140081ad0;
    }
    else if (uVar7 != 2) goto LAB_140081ad0;
    if (0x32 < (ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18))
    {
      if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) < 0x33
         ) {
        _invalid_parameter_noinfo();
      }
      FUN_14007ef10(param_1,*(undefined4 *)(*(longlong *)(param_1 + 0x20) + 0x4b0),1);
    }
  }
LAB_140081ad0:
  iVar2 = local_900;
  if (uVar12 == 0) {
    FUN_14007efe0(param_1,iVar3,local_900);
  }
  else {
    FUN_14007f0c0(param_1,iVar3,local_900);
  }
  local_448 = '\0';
  memset(local_447,0,0x3ff);
  pIVar5 = theInstance();
  _Format = (char *)(*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_SUPERMAN_BROADCAST_sddd");
  local_948 = CONCAT44(local_948._4_4_,iVar2);
  local_940 = iVar8 + 1;
  local_938 = uVar7;
  _snprintf(&local_448,0x3ff,_Format);
  FUN_14007a560();
  local_918 = 1;
  local_920 = 0;
  local_928 = 0;
  local_930 = 0;
  local_938 = CONCAT22(local_938._2_2_,2000);
  local_940 = 0xffffff;
  local_948 = 0;
  iVar3 = FUN_14007a620(local_888,"SYSTEM","ALLUSERS",&local_448);
  if (iVar3 == 0) {
    local_948 = CONCAT44(local_948._4_4_,0x99);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140067420(local_8d0,local_888);
  }
  FUN_14007a5e0(local_888);
  return 1;
}

// ==== CWorldKernel::helper_140081c40  @140081c40  [medium:callgraph-r2]  (orig: FUN_140081c40)
undefined8 * FUN_140081c40(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgLoadMap::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CWorldKernel::helper_140081c90  @140081c90  [medium:callgraph-r2]  (orig: FUN_140081c90)
void FUN_140081c90(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgLoadMap::vftable;
  FUN_1400752a0();
  return;
}

// ==== CWorldKernel::helper_140081cf0  @140081cf0  [medium:callgraph-r2]  (orig: FUN_140081cf0)
undefined8 FUN_140081cf0(longlong param_1,undefined2 param_2,int param_3)

{
  ulong uVar1;
  
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  *(undefined4 *)(param_1 + 8) = 0x414;
  uVar1 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x420) = uVar1;
  *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 4) = param_2;
  if (param_3 != 0) {
    *(int *)(*(longlong *)(param_1 + 0x420) + 0xc) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 8) = 1;
  }
  return 1;
}

// ==== CWorldKernel::helper_140081ed0  @140081ed0  [medium:callgraph-r2]  (orig: FUN_140081ed0)
undefined8 * FUN_140081ed0(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgMessageBoard::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x85),(char *)((longlong)param_1 + 0x15),0x3fb,true);
  return param_1;
}

// ==== CWorldKernel::helper_140081f50  @140081f50  [medium:callgraph-r2]  (orig: FUN_140081f50)
void FUN_140081f50(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgMessageBoard::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  return;
}

// ==== CWorldKernel::helper_140082700  @140082700  [medium:callgraph-r1]  (orig: FUN_140082700)
undefined8 * FUN_140082700(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgDialog::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x85),(char *)((longlong)param_1 + 0x1c),0x3f1,true);
  return param_1;
}

// ==== CWorldKernel::helper_140082780  @140082780  [medium:callgraph-r1]  (orig: FUN_140082780)
void FUN_140082780(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgDialog::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  return;
}

// ==== CWorldKernel::helper_1400827c0  @1400827c0  [medium:callgraph-r1]  (orig: FUN_1400827c0)
bool FUN_1400827c0(longlong param_1,undefined1 param_2,char *param_3,undefined1 param_4,
                  undefined2 param_5)

{
  bool bVar1;
  ulong uVar2;
  uint uVar3;
  
  if (param_3 == (char *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","szText",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\network2\\msgdialog.cpp"
                       ,0x22);
    bVar1 = false;
  }
  else {
    FUN_1400752b0();
    *(undefined1 *)(*(longlong *)(param_1 + 0x420) + 10) = param_4;
    *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 8) = param_5;
    *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 4) = 0;
    *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 6) = 0;
    *(undefined1 *)(*(longlong *)(param_1 + 0x420) + 0xb) = param_2;
    bVar1 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x428),param_3);
    uVar2 = tq::TimeGet(0);
    **(ulong **)(param_1 + 0x420) = uVar2;
    *(undefined4 *)(param_1 + 8) = 0x7f0;
    uVar3 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x428));
    *(uint *)(param_1 + 0xc) = uVar3 + 0xf;
  }
  return bVar1;
}

// ==== CWorldKernel::helper_140082990  @140082990  [medium:callgraph-r1]  (orig: FUN_140082990)
undefined8 FUN_140082990(longlong param_1,int param_2,undefined1 param_3)

{
  ulong uVar1;
  uint uVar2;
  
  if (param_2 != 100) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","nAction == MSGDIALOG_CREATE",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\network2\\msgdialog.cpp"
                       ,0x50);
    return 0;
  }
  FUN_1400752b0();
  *(undefined1 *)(*(longlong *)(param_1 + 0x420) + 10) = param_3;
  *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 8) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 4) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 6) = 0;
  *(undefined1 *)(*(longlong *)(param_1 + 0x420) + 0xb) = 100;
  uVar1 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x420) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0x7f0;
  uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x428));
  *(uint *)(param_1 + 0xc) = uVar2 + 0xf;
  return 1;
}

// ==== CWorldKernel::helper_140082b30  @140082b30  [medium:callgraph-r2]  (orig: FUN_140082b30)
undefined8 * FUN_140082b30(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgTime::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CWorldKernel::helper_140082b80  @140082b80  [medium:callgraph-r2]  (orig: FUN_140082b80)
void FUN_140082b80(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgTime::vftable;
  FUN_1400752a0();
  return;
}

// ==== CWorldKernel::helper_140082cf0  @140082cf0  [medium:callgraph-r2]  (orig: FUN_140082cf0)
undefined8 * FUN_140082cf0(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgAiNpcInfo::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CWorldKernel::helper_140082d40  @140082d40  [medium:callgraph-r2]  (orig: FUN_140082d40)
void FUN_140082d40(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgAiNpcInfo::vftable;
  FUN_1400752a0();
  return;
}

// ==== CWorldKernel::helper_140083630  @140083630  [medium:callgraph-r2]  (orig: FUN_140083630)
undefined8 * FUN_140083630(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgRegister::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CWorldKernel::helper_140083680  @140083680  [medium:callgraph-r2]  (orig: FUN_140083680)
void FUN_140083680(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgRegister::vftable;
  FUN_1400752a0();
  return;
}

// ==== CWorldKernel::helper_140084330  @140084330  [medium:callgraph-r2]  (orig: FUN_140084330)
undefined8 * FUN_140084330(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgFriend::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CWorldKernel::helper_140084380  @140084380  [medium:callgraph-r2]  (orig: FUN_140084380)
void FUN_140084380(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgFriend::vftable;
  FUN_1400752a0();
  return;
}

// ==== CWorldKernel::helper_140084560  @140084560  [medium:callgraph-r2]  (orig: FUN_140084560)
undefined8 * FUN_140084560(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgIPadInfo::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x85),(char *)((longlong)param_1 + 0x11),0x3ff,true);
  return param_1;
}

// ==== CWorldKernel::helper_1400845e0  @1400845e0  [medium:callgraph-r2]  (orig: FUN_1400845e0)
void FUN_1400845e0(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgIPadInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  return;
}

// ==== CWorldKernel::helper_140084960  @140084960  [medium:callgraph-r2]  (orig: FUN_140084960)
undefined8 * FUN_140084960(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = world_kernel::CMsgRegisterFB::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CWorldKernel::helper_1400849b0  @1400849b0  [medium:callgraph-r2]  (orig: FUN_1400849b0)
void FUN_1400849b0(undefined8 *param_1)

{
  *param_1 = world_kernel::CMsgRegisterFB::vftable;
  FUN_1400752a0();
  return;
}

// ==== CWorldKernel::helper_1400864c0  @1400864c0  [medium:callgraph-r1]  (orig: FUN_1400864c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1400864c0(longlong param_1,int param_2,undefined8 param_3,undefined4 param_4,char *param_5,
             undefined8 param_6)

{
  longlong *plVar1;
  int *piVar2;
  undefined8 *puVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined4 uVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined8 uVar12;
  IStringManager *pIVar13;
  char *pcVar14;
  undefined8 *puVar15;
  int *piVar16;
  undefined8 *puVar17;
  char *pcVar18;
  bool bVar19;
  undefined1 auStack_d48 [32];
  char *local_d28;
  int local_d20;
  int local_d18;
  char *local_d10;
  undefined8 local_d08;
  int local_cf8;
  undefined4 local_cf4;
  longlong *local_ce8;
  int *piStack_ce0;
  undefined4 local_cd8;
  undefined4 local_cd4;
  undefined4 local_cd0;
  undefined8 local_cc8;
  char *local_cc0;
  longlong local_cb8;
  undefined8 *local_cb0;
  longlong local_ca8;
  undefined8 local_ca0;
  undefined8 local_c98;
  undefined1 local_c88 [1072];
  char local_858 [15];
  undefined1 local_849;
  char local_848;
  undefined1 local_847 [1023];
  char local_448 [1023];
  undefined1 local_49;
  ulonglong local_48;
  
  local_c98 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_d48;
  local_cc0 = param_5;
  local_cc8 = param_6;
  local_cd0 = param_4;
  log_InlineLogFACEBOOK("CuserListFB::LoginUser idUin=%u");
  local_848 = '\0';
  memset(local_847,0,0x3ff);
  _snprintf(&local_848,0x3ff,
            "SELECT id, name, account_id, uin, recordmap_id, level FROM cq_user WHERE account_id=\'%u\'"
           );
  if (DAT_140975af8 == 0) {
    local_d28 = (char *)CONCAT44(local_d28._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar9 = (longlong *)InstanceGet(DAT_140975af8);
  plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,&local_848,2);
  if (plVar9 == (longlong *)0x0) {
    return 1;
  }
  lVar10 = (**(code **)(*plVar9 + 0x40))(plVar9);
  if (lVar10 == 0) {
    (**(code **)*plVar9)(plVar9);
    return 1;
  }
  plVar11 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,&DAT_1406de8d4);
  uVar5 = (**(code **)(*plVar11 + 0x40))(plVar11);
  local_cf4 = uVar5;
  plVar11 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,&DAT_1406f3818);
  iVar6 = (**(code **)(*plVar11 + 0x40))(plVar11);
  log_InlineLogFACEBOOK(" CUserList::LoginUser, User Account : %u, Old UIN:%u, UIN:%u");
  if (param_2 != iVar6) {
    if (iVar6 != 0) {
      log_InlineLogFACEBOOK
                (
                "CUserList::LoginUser Failed in differen UIN, User Account : %u, Old UIN:%u, UIN:%u"
                );
      log_InlineLogERROR(
                        "CUserList::LoginUser Failed in differen UIN, User Account : %u, Old UIN:%u, UIN:%u"
                        );
      (**(code **)*plVar9)(plVar9);
      return 2;
    }
    log_InlineLogFACEBOOK("CUserList::LoginUser Update UIN, User Account : %u, Old UIN:%u, UIN:%u");
    local_d28 = (char *)CONCAT44(local_d28._4_4_,uVar5);
    _snprintf(local_448,0x400,"UPDATE cq_user SET uin=%u WHERE id=%u LIMIT 1");
    local_49 = 0;
    uVar12 = FUN_140054dc0();
    plVar11 = (longlong *)InstanceGet(uVar12);
    (**(code **)(*plVar11 + 0x30))(plVar11,local_448,1,1);
  }
  pIVar13 = theInstance();
  pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)(pIVar13,"NOMATE_NAME");
  strncpy(local_858,pcVar14,0xf);
  local_849 = 0;
  plVar11 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,&DAT_1406ef6e0);
  pcVar14 = (char *)(**(code **)(*plVar11 + 0x78))(plVar11);
  tq::StrCopy(local_858,pcVar14,0x10);
  plVar11 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,"account_id");
  uVar7 = (**(code **)(*plVar11 + 0x40))(plVar11);
  plVar11 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,"recordmap_id");
  uVar8 = (**(code **)(*plVar11 + 0x40))(plVar11);
  local_cd8 = uVar8;
  uVar12 = FUN_140067320();
  local_cd4 = FUN_140074f20(uVar12,uVar8);
  plVar11 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,"level");
  local_cf8 = (**(code **)(*plVar11 + 0x48))(plVar11);
  bVar19 = (*(longlong *)(param_1 + 0x150) - *(longlong *)(param_1 + 0x148) & 0xfffffffffffffffcU)
           == 0;
  if (!bVar19) {
    pcVar14 = strstr(local_858,"PM");
    if (pcVar14 == (char *)0x0) {
      pcVar14 = strstr(local_858,"GM");
      bVar19 = true;
      if (pcVar14 == (char *)0x0) goto LAB_140086a46;
    }
    puVar17 = (undefined8 *)(*(undefined8 **)(param_1 + 0xa0))[1];
    cVar4 = *(char *)((longlong)puVar17 + 0x49);
    puVar3 = *(undefined8 **)(param_1 + 0xa0);
    while (cVar4 == '\0') {
      if (*(uint *)(puVar17 + 3) < uVar7) {
        puVar15 = (undefined8 *)puVar17[2];
        puVar17 = puVar3;
      }
      else {
        puVar15 = (undefined8 *)*puVar17;
      }
      puVar3 = puVar17;
      puVar17 = puVar15;
      cVar4 = *(char *)((longlong)puVar15 + 0x49);
    }
    local_cb0 = puVar3;
    local_cb8 = *(longlong *)(param_1 + 0x70);
    puVar17 = *(undefined8 **)(param_1 + 0xa0);
    if (*(longlong *)(param_1 + 0x70) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar17) || (uVar7 < *(uint *)(puVar3 + 3))) {
      local_ca0 = *(undefined8 *)(param_1 + 0xa0);
      local_ca8 = *(longlong *)(param_1 + 0x70);
      plVar11 = &local_ca8;
    }
    else {
      plVar11 = &local_cb8;
    }
    plVar1 = (longlong *)*plVar11;
    piStack_ce0 = (int *)plVar11[1];
    lVar10 = *(longlong *)(param_1 + 0xa0);
    local_ce8 = plVar1;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x70))) {
      _invalid_parameter_noinfo();
    }
    piVar16 = piStack_ce0;
    if (piStack_ce0 == (int *)lVar10) {
      local_d20 = 0x56;
      local_d28 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\userlistfb.cpp";
      log_InlineLogERROR("not find GM(id:%u, account_id:%u, name:%s) login record at %s, %d");
      (**(code **)*plVar9)(plVar9);
      return 3;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (piVar16 == (int *)*(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    iVar6 = *(int *)((longlong)piVar16 + 0x40);
    piVar16 = *(int **)(param_1 + 0x148);
    if (*(int **)(param_1 + 0x150) < piVar16) {
      _invalid_parameter_noinfo();
    }
    plVar11 = *(longlong **)(param_1 + 0x130);
    local_ce8 = plVar11;
    piStack_ce0 = piVar16;
    while( true ) {
      piVar2 = *(int **)(param_1 + 0x150);
      if (piVar2 < *(int **)(param_1 + 0x148)) {
        _invalid_parameter_noinfo();
      }
      if ((plVar11 == (longlong *)0x0) || (plVar11 != *(longlong **)(param_1 + 0x130))) {
        _invalid_parameter_noinfo();
      }
      if (piVar16 == piVar2) {
        local_d28 = local_858;
        local_d20 = iVar6;
        log_InlineLogDBERROR
                  (
                  "table:cq_config, type = %d, GM(id:%u, account_id:%u, name:%s) ip(%u) not config."
                  );
        (**(code **)*plVar9)(plVar9);
        return 3;
      }
      if (plVar11 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar11;
      }
      if (*(int **)(lVar10 + 0x20) <= piVar16) {
        _invalid_parameter_noinfo();
      }
      if (*piVar16 == iVar6) break;
      if (plVar11 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar11;
      }
      if (*(int **)(lVar10 + 0x20) <= piVar16) {
        _invalid_parameter_noinfo();
      }
      piVar16 = piVar16 + 1;
    }
    bVar19 = true;
    uVar5 = local_cf4;
  }
LAB_140086a46:
  uVar12 = 2;
  lVar10 = 5;
  pcVar14 = local_cc0;
  pcVar18 = "!NP!";
  do {
    if (lVar10 == 0) break;
    lVar10 = lVar10 + -1;
    bVar19 = *pcVar14 == *pcVar18;
    pcVar14 = pcVar14 + 1;
    pcVar18 = pcVar18 + 1;
  } while (bVar19);
  if ((!bVar19) || (local_cf8 < DAT_140949794)) {
    local_d08 = local_cc8;
    local_d10 = local_cc0;
    local_d18 = local_cf8;
    local_d20 = local_cd0;
    local_d28 = (char *)CONCAT44(local_d28._4_4_,uVar7);
    cVar4 = FUN_140071a40(param_1,local_cd4,uVar5,local_858);
    if (cVar4 != '\0') {
      lVar10 = FUN_14006e3a0(param_1,uVar5);
      if (lVar10 != 0) {
        FUN_140081c40(local_c88);
        iVar6 = FUN_140081cf0(local_c88,0,local_cd8);
        if (iVar6 != 0) {
          FUN_140067420(lVar10,local_c88);
        }
        FUN_14006a150(lVar10);
        uVar12 = FUN_140054dc0();
        cVar4 = FUN_140056a70(uVar12);
        if (cVar4 == '\0') {
          uVar12 = FUN_140054dc0();
          FUN_140055820(uVar12,uVar7,0);
          uVar12 = FUN_140054dc0();
          local_d28 = (char *)CONCAT44(local_d28._4_4_,100);
          FUN_1400558e0(uVar12,uVar7,0,0);
        }
        else {
          uVar12 = FUN_140054dc0();
          FUN_140055c60(uVar12,uVar7,uVar5,1);
        }
        uVar12 = 0;
        FUN_140081c90(local_c88);
      }
      goto LAB_140086bce;
    }
  }
  if (DAT_140975af8 == 0) {
    local_d28 = (char *)CONCAT44(local_d28._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140055820(DAT_140975af8,uVar7,5);
LAB_140086bce:
  (**(code **)*plVar9)(plVar9);
  return uVar12;
}

// ==== CWorldKernel::helper_14008a780  @14008a780  [medium:callgraph-r1]  (orig: FUN_14008a780)
void FUN_14008a780(longlong param_1,undefined8 param_2)

{
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),8,0x15f91,0x60,param_2);
  return;
}

// ==== CWorldKernel::helper_14008a800  @14008a800  [medium:callgraph-r0]  (orig: FUN_14008a800)
void FUN_14008a800(void)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = FUN_140087ed0();
  if (lVar1 != 0) {
    plVar2 = (longlong *)FUN_140087ed0();
    (**(code **)(*plVar2 + 0x408))(plVar2);
  }
  return;
}

// ==== CWorldKernel::helper_14008ac40  @14008ac40  [medium:callgraph-r0]  (orig: FUN_14008ac40)
void FUN_14008ac40(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x69f) = param_2;
  return;
}

// ==== CWorldKernel::helper_14008ac50  @14008ac50  [medium:callgraph-r0]  (orig: FUN_14008ac50)
void FUN_14008ac50(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x6a0) = param_2;
  return;
}

// ==== CWorldKernel::helper_14008ac60  @14008ac60  [medium:callgraph-r0]  (orig: FUN_14008ac60)
void FUN_14008ac60(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x6a1) = param_2;
                    /* WARNING: Could not recover jumptable at 0x00014008ac84. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogMessage("Change Server Status: %s, CurrAppCount[%d]");
  return;
}

// ==== CWorldKernel::helper_14008b410  @14008b410  [medium:callgraph-r0]  (orig: FUN_14008b410)
undefined4 FUN_14008b410(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x6cc);
}

// ==== CWorldKernel::helper_140092840  @140092840  [medium:callgraph-r0]  (orig: FUN_140092840)
undefined1 FUN_140092840(longlong param_1)

{
  undefined1 uVar1;
  
  uVar1 = 0x14;
  if (*(char *)(param_1 + 0x69e) != '\0') {
    uVar1 = *(undefined1 *)(param_1 + 0x2d8);
  }
  return uVar1;
}

// ==== CWorldKernel::helper_1400a72a0  @1400a72a0  [medium:callgraph-r0]  (orig: FUN_1400a72a0)
int FUN_1400a72a0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  
  plVar2 = *(longlong **)(param_1 + 0x648);
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x678);
  lVar6 = 0;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x678);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x648))) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar3) {
      return 6;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar6;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (param_2 < *(uint *)((longlong)plVar5 + 0x1c)) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x21) == '\0') {
      plVar3 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar3 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x21);
        plVar5 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x21);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x21);
        plVar4 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x21);
          plVar4 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar6 = *plVar2;
  }
  if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return (int)plVar5[3] + -1;
}

// ==== CWorldKernel::helper_1400a7930  @1400a7930  [medium:callgraph-r0]  (orig: FUN_1400a7930)
void FUN_1400a7930(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined4 local_res8 [2];
  
  plVar2 = *(longlong **)(param_1 + 0x438);
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 0x468);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar3;
          plVar3 = *(longlong **)(param_1 + 0x468);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x438))) {
            _invalid_parameter_noinfo();
          }
          if (plVar6 == plVar3) {
            lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
            if (*(longlong *)(lVar5 + 0x90) == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            FUN_1402b3aa0(*(undefined8 *)(lVar5 + 0x90),0,0);
            local_res8[0] = 0;
            (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                      (*(longlong **)(param_1 + 0x80),6,0x3f1,4,local_res8);
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar5 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          *(undefined1 *)(plVar6 + 6) = 0;
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x49) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar6;
        }
        plVar3 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar3 + 0x49) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x49);
        plVar6 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x49);
          plVar3 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar3 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar3 + 0x49) != '\0');
    do {
      plVar4 = plVar3;
      plVar3 = plVar4;
      if (plVar6 != (longlong *)plVar4[2]) break;
      plVar3 = (longlong *)plVar4[1];
      plVar6 = plVar4;
    } while (*(char *)((longlong)plVar3 + 0x49) == '\0');
  } while( true );
}

// ==== CWorldKernel::helper_1400a7f50  @1400a7f50  [medium:callgraph-r0]  (orig: FUN_1400a7f50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400a7f50(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  ulonglong uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined8 local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_470 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (param_2 == 0) {
    local_488 = 0x1579;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1402c33d0(local_468);
    FUN_1402c3480(local_468);
    plVar8 = (longlong *)**(undefined8 **)(param_1 + 0x710);
    plVar1 = *(longlong **)(param_1 + 0x6e0);
    while( true ) {
      plVar2 = *(longlong **)(param_1 + 0x710);
      if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x6e0))) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == plVar2) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar1;
      }
      if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar3 = *(ulonglong *)((longlong)plVar8 + 0x1c);
      local_478 = uVar3;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar1;
      }
      if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar4 = local_478._4_4_;
      cVar6 = FUN_1402c34c0(local_468,(int)plVar8[3],uVar3 & 0xffffffff,local_478._4_4_);
      if (cVar6 == '\0') {
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_468)
        ;
        FUN_1402c3480(local_468);
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = 0;
        }
        else {
          lVar9 = *plVar1;
        }
        if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_1402c34c0(local_468,(int)plVar8[3],uVar3 & 0xffffffff,uVar4);
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar8 + 0x25) == '\0') {
        plVar2 = (longlong *)plVar8[2];
        if (*(char *)((longlong)plVar2 + 0x25) == '\0') {
          cVar6 = *(char *)(*plVar2 + 0x25);
          plVar8 = plVar2;
          plVar2 = (longlong *)*plVar2;
          while (cVar6 == '\0') {
            cVar6 = *(char *)(*plVar2 + 0x25);
            plVar8 = plVar2;
            plVar2 = (longlong *)*plVar2;
          }
        }
        else {
          cVar6 = *(char *)(plVar8[1] + 0x25);
          plVar5 = (longlong *)plVar8[1];
          plVar2 = plVar8;
          while ((plVar8 = plVar5, cVar6 == '\0' && (plVar2 == (longlong *)plVar8[2]))) {
            cVar6 = *(char *)(plVar8[1] + 0x25);
            plVar5 = (longlong *)plVar8[1];
            plVar2 = plVar8;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    iVar7 = FUN_1402c3530(local_468);
    if (iVar7 != 0) {
      (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_468);
    }
    FUN_1402c3420(local_468);
  }
  return;
}

// ==== CWorldKernel::helper_1400c7b80  @1400c7b80  [medium:callgraph-r3]  (orig: FUN_1400c7b80)
ulonglong FUN_1400c7b80(longlong param_1)

{
  ulonglong extraout_RAX;
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),3);
                    /* WARNING: Could not recover jumptable at 0x0001400c7bd5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
  return uVar2;
}

// ==== CWorldKernel::helper_1400d2fc0  @1400d2fc0  [medium:callgraph-r3]  (orig: FUN_1400d2fc0)
longlong FUN_1400d2fc0(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_1400cd310(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x25) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x25) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x25);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x25);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x25);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x25);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_1400d0960(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CWorldKernel::helper_1400d36d0  @1400d36d0  [medium:callgraph-r2]  (orig: FUN_1400d36d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400d36d0(longlong param_1,longlong *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong *plVar9;
  undefined8 uVar10;
  longlong lVar11;
  undefined8 *puVar12;
  bool bVar13;
  undefined1 auStack_4c8 [32];
  uint *local_4a8;
  uint local_498;
  undefined4 local_494;
  longlong local_490;
  undefined8 local_488;
  undefined1 local_480 [24];
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (param_2 == (longlong *)0x0) {
    local_4a8 = (uint *)CONCAT44(local_4a8._4_4_,0x255);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar9 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,1);
    uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
    if (uVar4 == 0) {
      log_InlineLogERROR("COperatingActMgr::ProcessOperatingUserInfoProcedureRet user id is 0.");
      (**(code **)*param_2)(param_2,1);
    }
    else {
      plVar9 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,2);
      local_494 = (**(code **)(*plVar9 + 0x40))(plVar9);
      local_498 = uVar4;
      FUN_1400d2fc0(param_1 + 200,&local_498);
      uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x188));
      plVar9 = (longlong *)FUN_1400875f0(uVar10);
      plVar9 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,uVar4);
      if (plVar9 == (longlong *)0x0) {
        (**(code **)*param_2)(param_2,1);
      }
      else {
        plVar9 = (longlong *)(**(code **)(*plVar9 + 0x2b0))(plVar9);
        if (plVar9 == (longlong *)0x0) {
          log_InlineLogERROR(
                            "COperatingActMgr::ProcessOperatingUserInfoProcedureRet IRole is not user, id:%u."
                            );
          (**(code **)*param_2)(param_2,1);
        }
        else {
          lVar11 = FUN_14032a780();
          if (lVar11 == 0) {
            local_4a8 = (uint *)CONCAT44(local_4a8._4_4_,0x27d);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            cVar3 = FUN_140329ee0(lVar11,param_2);
            if (cVar3 == '\0') {
              log_InlineLogERROR(
                                "COperatingActMgr::ProcessOperatingUserInfoProcedureRet pOperatingUserInfo Create failed. user id:%u."
                                );
              FUN_14032aa50(lVar11);
            }
            else {
              cVar3 = FUN_1400c7b80(lVar11);
              if (cVar3 == '\a') {
                uVar5 = (**(code **)(*plVar9 + 0x108))(plVar9);
                if (2 < uVar5) {
                  uVar5 = 2;
                }
                iVar6 = (**(code **)(plVar9[2] + 0x70))();
                FUN_14032a070(lVar11,4,uVar5 * 0x8c + iVar6,1);
              }
              puVar1 = (undefined8 *)(*(undefined8 **)(param_1 + 0xb8))[1];
              bVar13 = true;
              cVar3 = *(char *)((longlong)puVar1 + 0x29);
              puVar2 = *(undefined8 **)(param_1 + 0xb8);
              while (cVar3 == '\0') {
                bVar13 = uVar4 < *(uint *)(puVar1 + 3);
                if (bVar13) {
                  puVar12 = (undefined8 *)*puVar1;
                }
                else {
                  puVar12 = (undefined8 *)puVar1[2];
                }
                puVar2 = puVar1;
                puVar1 = puVar12;
                cVar3 = *(char *)((longlong)puVar12 + 0x29);
              }
              local_4a8 = &local_498;
              local_498 = uVar4;
              local_490 = lVar11;
              FUN_1400ccde0(param_1 + 0x88,local_480,bVar13,puVar2);
              FUN_14035bb80(local_468);
              uVar7 = FUN_1400c7be0(lVar11);
              uVar8 = FUN_1400c7b20(lVar11);
              local_4a8 = (uint *)CONCAT44(local_4a8._4_4_,uVar7);
              cVar3 = FUN_14035bc30(local_468,uVar8,1,0);
              if (cVar3 != '\0') {
                (**(code **)(plVar9[2] + 0x350))(plVar9 + 2,local_468);
              }
              FUN_14035bbd0(local_468);
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400dfe30  @1400dfe30  [medium:callgraph-r2]  (orig: FUN_1400dfe30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400dfe30(undefined8 *param_1,longlong *param_2,longlong *param_3)

{
  undefined8 *puVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong *plVar9;
  undefined8 uVar10;
  longlong lVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong *plVar17;
  undefined8 uVar18;
  undefined1 auStack_628 [32];
  undefined8 local_608;
  undefined8 local_600;
  undefined4 local_5f8;
  undefined4 local_5f0;
  undefined4 local_5e8;
  undefined4 local_5e0;
  undefined4 local_5d8;
  undefined8 local_5c8;
  undefined8 uStack_5c0;
  longlong *local_5b8;
  longlong *local_5b0;
  undefined8 *local_5a8;
  undefined8 uStack_5a0;
  longlong *local_598;
  longlong *local_590;
  longlong *local_588;
  undefined4 local_578;
  undefined4 uStack_574;
  undefined4 uStack_570;
  undefined4 uStack_56c;
  undefined4 local_558 [2];
  longlong local_550;
  undefined4 local_548 [2];
  longlong local_540;
  undefined8 *local_538 [2];
  undefined8 *local_528 [6];
  longlong *local_4f8;
  undefined8 local_4f0;
  undefined8 local_4e8;
  undefined4 local_4d8;
  undefined4 uStack_4d4;
  undefined4 uStack_4d0;
  undefined4 uStack_4cc;
  int local_4c8 [2];
  void *local_4c0 [9];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_4e8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_628;
  local_5b0 = param_2;
  local_598 = param_3;
  local_590 = param_3;
  local_588 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_608 = CONCAT44(local_608._4_4_,0x2a5);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar10 = 0;
  }
  else if (param_3 == (longlong *)0x0) {
    local_608 = CONCAT44(local_608._4_4_,0x2a6);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar10 = 0;
  }
  else {
    plVar9 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,1);
    iVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
    local_5b8 = (longlong *)CONCAT44(local_5b8._4_4_,iVar4);
    if (iVar4 == 0) {
      log_InlineLogERROR("CMailMgr::ProcessOperatingMailAsynRet idUser is 0.");
      (**(code **)*param_3)(param_3,1);
      (**(code **)*param_2)(param_2,1);
      uVar10 = 0;
    }
    else {
      uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 8));
      plVar9 = (longlong *)FUN_140087650(uVar10);
      local_5b0 = (longlong *)(**(code **)(*plVar9 + 0x98))(plVar9,iVar4);
      if (local_5b0 != (longlong *)0x0) {
        local_5c8 = (void **)(**(code **)(*param_2 + 0x10))(param_2,0);
        plVar9 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_608 = CONCAT44(local_608._4_4_,0x3c0);
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar9 = (longlong *)0x0;
        }
        plVar12 = (longlong *)0x0;
        lVar11 = *plVar9;
        uVar5 = (**(code **)((longlong)*local_5c8 + 0x40))();
        lVar11 = (**(code **)(lVar11 + 0x60))(plVar9,uVar5);
        if (lVar11 != 0) {
          return 0;
        }
        plVar9 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_608 = CONCAT44(local_608._4_4_,0x3c0);
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar9 = plVar12;
        }
        lVar11 = (**(code **)(*plVar9 + 0x10))(plVar9,param_2,0);
        if (lVar11 == 0) {
          (**(code **)*param_3)(param_3,1);
          log_InlineLogERROR("CMailMgr::ProcessOperatingMailAsynRet CreateItem failed, user id:%u.")
          ;
          return 0;
        }
        lVar11 = FUN_14035b110();
        if (lVar11 == 0) {
          return 0;
        }
        cVar2 = FUN_14035abd0(lVar11,param_3);
        if (cVar2 == '\0') {
          FUN_14035b7a0(lVar11);
          return 0;
        }
        uVar5 = FUN_14035ab70(lVar11);
        local_5c8 = (void **)CONCAT44(local_5c8._4_4_,uVar5);
        FUN_1400db220(param_1,&local_5a8,&local_5b8);
        puVar1 = local_5a8;
        local_5b8 = (longlong *)param_1[6];
        local_538[0] = (undefined8 *)*param_1;
        if ((local_5a8 == (undefined8 *)0x0) || (local_5a8 != local_538[0])) {
          _invalid_parameter_noinfo();
        }
        if (uStack_5a0 == local_5b8) {
          FUN_1400ddfe0(local_528);
          local_548[0] = (undefined4)local_5c8;
          local_540 = lVar11;
          FUN_1400db2f0(local_528,&local_578,local_548);
          local_5c8 = local_4c0;
          local_4c8[0] = iVar4;
          FUN_1400dd8e0(local_4c0,local_528);
          FUN_1400de680(param_1,&local_578,local_4c8);
          local_5c8 = local_4c0;
          FUN_1400dd560(local_4c0);
          operator_delete(local_4c0[0]);
          uStack_5c0 = local_4f8;
          plVar12 = uStack_5c0;
          local_5c8 = (void **)local_528[0];
          puVar1 = local_5c8;
          plVar9 = (longlong *)*local_4f8;
          local_5a8 = local_528[0];
          local_5c8._0_4_ = SUB84(local_528[0],0);
          local_5c8._4_4_ = (undefined4)((ulonglong)local_528[0] >> 0x20);
          uStack_5c0._0_4_ = SUB84(local_4f8,0);
          uStack_5c0._4_4_ = (undefined4)((ulonglong)local_4f8 >> 0x20);
          local_4d8 = (undefined4)local_5c8;
          uStack_4d4 = local_5c8._4_4_;
          uStack_4d0 = (undefined4)uStack_5c0;
          uStack_4cc = uStack_5c0._4_4_;
          uStack_5a0._0_4_ = SUB84(plVar9,0);
          uStack_5a0._4_4_ = (undefined4)((ulonglong)plVar9 >> 0x20);
          local_578 = (undefined4)local_5c8;
          uStack_574 = local_5c8._4_4_;
          uStack_570 = (undefined4)uStack_5a0;
          uStack_56c = uStack_5a0._4_4_;
          local_5c8 = (void **)puVar1;
          uStack_5c0 = plVar12;
          uStack_5a0 = plVar9;
          FUN_1400dbab0(local_528,local_538,&local_578,&local_4d8);
          operator_delete(local_4f8);
          local_4f8 = (longlong *)0x0;
          local_4f0 = 0;
          operator_delete(local_528[0]);
        }
        else {
          if (puVar1 == (undefined8 *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            plVar12 = (longlong *)*puVar1;
          }
          plVar9 = uStack_5a0;
          if (uStack_5a0 == (longlong *)plVar12[6]) {
            _invalid_parameter_noinfo();
          }
          local_558[0] = (undefined4)local_5c8;
          local_550 = lVar11;
          FUN_1400db2f0(plVar9 + 4,&local_578,local_558);
        }
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,0);
        uVar5 = (**(code **)(*plVar9 + 0x40))(plVar9);
        plVar9 = local_5b0;
        FUN_14033cc10(local_5b0,uVar5);
        FUN_14035c930(local_478);
        cVar2 = FUN_14035c9f0(local_478,4);
        if (cVar2 != '\0') {
          (**(code **)(*(longlong *)((longlong)plVar9 + 0x10) + 0x350))
                    ((longlong *)((longlong)plVar9 + 0x10),local_478);
        }
        FUN_14035c980(local_478);
      }
      local_5c8 = (void **)(**(code **)(*param_3 + 0x10))(param_3,10);
      plVar9 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,7);
      plVar12 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,9);
      plVar13 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,6);
      plVar14 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,5);
      plVar15 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,4);
      plVar16 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,3);
      plVar17 = (longlong *)(**(code **)(*local_598 + 0x10))(local_598,2);
      local_5b8 = (longlong *)(**(code **)(*local_598 + 0x10))(local_598,1);
      bVar3 = (**(code **)((longlong)*local_5c8 + 0x20))(local_5c8);
      local_5c8 = (void **)CONCAT44(local_5c8._4_4_,(uint)bVar3);
      uVar5 = (**(code **)(*plVar9 + 0x40))(plVar9);
      uVar6 = (**(code **)(*plVar12 + 0x50))(plVar12);
      uVar7 = (**(code **)(*plVar13 + 0x50))(plVar13);
      uVar8 = (**(code **)(*plVar14 + 0x50))(plVar14);
      uVar10 = (**(code **)(*plVar15 + 0x78))(plVar15);
      uVar18 = (**(code **)(*plVar16 + 0x78))(plVar16);
      (**(code **)(*plVar17 + 0x78))(plVar17);
      (**(code **)(*local_5b8 + 0x50))(local_5b8);
      local_5d8 = (undefined4)local_5c8;
      local_608 = uVar18;
      local_600 = uVar10;
      local_5f8 = uVar8;
      local_5f0 = uVar7;
      local_5e8 = uVar6;
      local_5e0 = uVar5;
      tq::MyLogSave("gmlog/mail",
                    "Send Mail Success| idReceiver[%u] szSenderName[%s] szTitle[%s] szContent[%s] unMoney[%u]  unEMoney[%u] idItem[%u] Action[%u] RcdType[%u]"
                   );
      if (local_5b0 == (longlong *)0x0) {
        (**(code **)*local_588)(local_588,1);
        (**(code **)*local_598)(local_598,1);
      }
      uVar10 = 1;
    }
  }
  return uVar10;
}

// ==== CWorldKernel::helper_1400e04d0  @1400e04d0  [medium:callgraph-r2]  (orig: FUN_1400e04d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400e04d0(longlong *param_1,longlong *param_2)

{
  void **ppvVar1;
  undefined8 *puVar2;
  char cVar3;
  byte bVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  longlong *plVar10;
  undefined8 uVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong *plVar17;
  longlong *plVar18;
  undefined8 uVar19;
  longlong lVar20;
  undefined1 auStack_618 [32];
  undefined8 local_5f8;
  undefined8 local_5f0;
  undefined4 local_5e8;
  undefined4 local_5e0;
  undefined4 local_5d8;
  undefined4 local_5d0;
  undefined4 local_5c8;
  void **local_5b8 [2];
  undefined8 local_5a8;
  undefined8 uStack_5a0;
  longlong local_598;
  longlong *local_588;
  undefined8 uStack_580;
  longlong *local_578;
  undefined4 local_568;
  undefined4 uStack_564;
  undefined4 uStack_560;
  undefined4 uStack_55c;
  undefined4 local_548 [2];
  longlong local_540;
  longlong *local_538 [2];
  undefined4 local_528 [2];
  longlong local_520;
  longlong *local_518 [6];
  undefined8 *local_4e8;
  undefined8 local_4e0;
  undefined8 local_4d8;
  undefined4 local_4c8;
  undefined4 uStack_4c4;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  int local_4b8 [2];
  void *local_4b0 [9];
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_4d8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_618;
  local_578 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_5f8 = CONCAT44(local_5f8._4_4_,0x301);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = 0;
  }
  else {
    plVar10 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,1);
    iVar5 = (**(code **)(*plVar10 + 0x40))(plVar10);
    local_5b8[0] = (void **)CONCAT44(local_5b8[0]._4_4_,iVar5);
    if (iVar5 == 0) {
      plVar10 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,0);
      (**(code **)(*plVar10 + 0x40))(plVar10);
      log_InlineLogERROR("CMailMgr::ProcessCommonMailAsynRet idUser is ID_NONE, mail id:%u.");
      (**(code **)*param_2)(param_2,1);
      uVar11 = 0;
    }
    else {
      uVar11 = FUN_140008520((int)param_1[8]);
      plVar10 = (longlong *)FUN_140087650(uVar11);
      local_598 = (**(code **)(*plVar10 + 0x98))(plVar10,iVar5);
      if (local_598 != 0) {
        lVar12 = FUN_14035b110();
        if (lVar12 == 0) {
          return 0;
        }
        cVar3 = FUN_14035abd0(lVar12,param_2);
        if (cVar3 == '\0') {
          FUN_14035b7a0(lVar12);
          return 0;
        }
        uVar6 = FUN_14035ab70(lVar12);
        local_5a8 = (longlong *)CONCAT44(local_5a8._4_4_,uVar6);
        FUN_1400db220(param_1,&local_588,local_5b8);
        plVar10 = local_588;
        local_5b8[0] = (void **)param_1[6];
        lVar20 = 0;
        local_538[0] = (longlong *)*param_1;
        if ((local_588 == (longlong *)0x0) || (local_588 != local_538[0])) {
          _invalid_parameter_noinfo();
        }
        ppvVar1 = uStack_580;
        if (uStack_580 == local_5b8[0]) {
          FUN_1400ddfe0(local_518);
          local_548[0] = (undefined4)local_5a8;
          local_540 = lVar12;
          FUN_1400db2f0(local_518,&local_568,local_548);
          local_5b8[0] = local_4b0;
          local_4b8[0] = iVar5;
          FUN_1400dd8e0(local_4b0,local_518);
          FUN_1400de680(param_1,&local_568,local_4b8);
          local_5b8[0] = local_4b0;
          FUN_1400dd560(local_4b0);
          operator_delete(local_4b0[0]);
          uStack_5a0 = local_4e8;
          puVar2 = uStack_5a0;
          local_5a8 = local_518[0];
          plVar10 = local_5a8;
          ppvVar1 = (void **)*local_4e8;
          local_588 = local_518[0];
          local_5a8._0_4_ = SUB84(local_518[0],0);
          local_5a8._4_4_ = (undefined4)((ulonglong)local_518[0] >> 0x20);
          uStack_5a0._0_4_ = SUB84(local_4e8,0);
          uStack_5a0._4_4_ = (undefined4)((ulonglong)local_4e8 >> 0x20);
          local_4c8 = (undefined4)local_5a8;
          uStack_4c4 = local_5a8._4_4_;
          uStack_4c0 = (undefined4)uStack_5a0;
          uStack_4bc = uStack_5a0._4_4_;
          uStack_580._0_4_ = SUB84(ppvVar1,0);
          uStack_580._4_4_ = (undefined4)((ulonglong)ppvVar1 >> 0x20);
          local_568 = (undefined4)local_5a8;
          uStack_564 = local_5a8._4_4_;
          uStack_560 = (undefined4)uStack_580;
          uStack_55c = uStack_580._4_4_;
          local_5a8 = plVar10;
          uStack_5a0 = puVar2;
          uStack_580 = ppvVar1;
          FUN_1400dbab0(local_518,local_538,&local_568,&local_4c8);
          operator_delete(local_4e8);
          local_4e8 = (undefined8 *)0x0;
          local_4e0 = 0;
          operator_delete(local_518[0]);
        }
        else {
          if (plVar10 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar20 = *plVar10;
          }
          if (ppvVar1 == *(void ***)(lVar20 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          local_528[0] = (undefined4)local_5a8;
          local_520 = lVar12;
          FUN_1400db2f0(ppvVar1 + 4,&local_568,local_528);
        }
        plVar10 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,9);
        iVar5 = (**(code **)(*plVar10 + 0x40))(plVar10);
        lVar12 = local_598;
        if (iVar5 != 0) {
          FUN_14033cc10(local_598,iVar5);
        }
        FUN_14035c930(local_468);
        cVar3 = FUN_14035c9f0(local_468,4);
        if (cVar3 != '\0') {
          (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x350))((longlong *)(lVar12 + 0x10),local_468)
          ;
        }
        FUN_14035c980(local_468);
      }
      local_5b8[0] = (void **)(**(code **)(*param_2 + 0x10))(param_2,10);
      plVar10 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,7);
      plVar13 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,9);
      plVar14 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,6);
      plVar15 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,5);
      plVar16 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,4);
      plVar17 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,3);
      plVar18 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,2);
      local_5a8 = (longlong *)(**(code **)(*local_578 + 0x10))(local_578,1);
      bVar4 = (**(code **)((longlong)*local_5b8[0] + 0x20))(local_5b8[0]);
      local_5b8[0] = (void **)CONCAT44(local_5b8[0]._4_4_,(uint)bVar4);
      uVar6 = (**(code **)(*plVar10 + 0x40))(plVar10);
      uVar7 = (**(code **)(*plVar13 + 0x50))(plVar13);
      uVar8 = (**(code **)(*plVar14 + 0x50))(plVar14);
      uVar9 = (**(code **)(*plVar15 + 0x50))(plVar15);
      uVar11 = (**(code **)(*plVar16 + 0x78))(plVar16);
      uVar19 = (**(code **)(*plVar17 + 0x78))(plVar17);
      (**(code **)(*plVar18 + 0x78))(plVar18);
      (**(code **)(*local_5a8 + 0x50))(local_5a8);
      local_5c8 = local_5b8[0]._0_4_;
      local_5f8 = uVar19;
      local_5f0 = uVar11;
      local_5e8 = uVar9;
      local_5e0 = uVar8;
      local_5d8 = uVar7;
      local_5d0 = uVar6;
      tq::MyLogSave("gmlog/mail",
                    "Send Mail Success| idReceiver[%u] szSenderName[%s] szTitle[%s] szContent[%s] unMoney[%u]  unEMoney[%u] idItem[%u] Action[%u] RcdType[%u]"
                   );
      if (local_598 == 0) {
        (**(code **)*local_578)(local_578,1);
      }
      uVar11 = 1;
    }
  }
  return uVar11;
}

// ==== CWorldKernel::helper_1400e2080  @1400e2080  [medium:callgraph-r0]  (orig: FUN_1400e2080)
void FUN_1400e2080(undefined8 param_1,undefined4 param_2,short param_3)

{
  longlong *plVar1;
  
  if (param_3 == 1) {
    plVar1 = (longlong *)FUN_1400e1e60();
    (**(code **)(*plVar1 + 0xe0))(plVar1,param_2);
  }
  else {
    if (param_3 == 2) {
      plVar1 = (longlong *)FUN_1400e1e60();
                    /* WARNING: Could not recover jumptable at 0x0001400e20c6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar1 + 0xe8))(plVar1,1);
      return;
    }
    if (param_3 == 3) {
      plVar1 = (longlong *)FUN_1400e1e60();
                    /* WARNING: Could not recover jumptable at 0x0001400e20ad. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar1 + 0xe8))(plVar1,0);
      return;
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400e20f0  @1400e20f0  [medium:callgraph-r0]  (orig: FUN_1400e20f0)
undefined8
FUN_1400e20f0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,longlong param_6,int param_7)

{
  undefined8 uVar1;
  CTickAnalyst local_30 [24];
  
  uVar1 = 0xfffffffffffffffe;
  CTickAnalyst::CTickAnalyst(local_30,10);
  if ((param_6 == 0) || (0x3ff < param_7 - 1U)) {
    CTickAnalyst::~CTickAnalyst(local_30);
    uVar1 = 0;
  }
  else {
    FUN_1402b9050(param_1,*(undefined4 *)(param_1 + 0x10),param_2,param_3,param_4,param_5,param_6,
                  param_7,uVar1);
    CTickAnalyst::~CTickAnalyst(local_30);
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CWorldKernel::helper_1400e32a0  @1400e32a0  [medium:callgraph-r0]  (orig: FUN_1400e32a0)
void FUN_1400e32a0(longlong param_1)

{
  char in_stack_00000028;
  
  if ((*(longlong *)(param_1 + 0x60) == 0) || (*(char *)(param_1 + 0x68) == '\0')) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(**(longlong **)(param_1 + 0x60) + 0x68))();
    if (in_stack_00000028 != '\0') {
                    /* WARNING: Could not recover jumptable at 0x0001400e32d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x70))();
      return;
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400e3310  @1400e3310  [medium:callgraph-r0]  (orig: FUN_1400e3310)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1400e3310(longlong param_1,int param_2,ulonglong param_3,int param_4)

{
  ulonglong uVar1;
  char *pcVar2;
  
  if ((*(longlong *)(param_1 + 0x60) == 0) || (*(char *)(param_1 + 0x68) == '\0')) {
    pcVar2 = "m_pData && IsDynaNpc()";
  }
  else {
    if (param_2 < 4) {
      if ((*(int *)(param_1 + 0x58) == 0x334) && (param_2 == 0)) {
        uVar1 = FUN_140087300();
        tq::MyLogSave("gmlog/npc_820",&DAT_1407026f0,uVar1 & 0xffffffff,param_3 & 0xffffffff);
      }
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),param_2 + 0x12,param_3 & 0xffffffff);
      if (param_4 == 0) {
        return;
      }
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x70))();
      return;
    }
    pcVar2 = "idx < MAX_NPCDATA";
  }
  log_InlineLogERROR(&DAT_1406d9c10,"CHECK",pcVar2,
                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h");
  return;
}

// ==== CWorldKernel::helper_1400e3570  @1400e3570  [medium:callgraph-r0]  (orig: FUN_1400e3570)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400e3570(longlong param_1,short param_2,undefined4 param_3,undefined4 param_4,
                  undefined8 param_5)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined1 auStack_488 [32];
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (param_2 == 4) {
    FUN_14035ca70(local_458);
    cVar1 = FUN_14035cb20(local_458,param_4,param_5);
    if (cVar1 != '\0') {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      (**(code **)(*plVar3 + 0x68))(plVar3,local_458,0xffffffff);
    }
    FUN_14035cac0(local_458);
  }
  else if (param_2 == 5) {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x98))(plVar3,param_3);
    if (lVar4 != 0) {
      FUN_14035ca70(local_458);
      cVar1 = FUN_14035cb20(local_458,param_4,param_5);
      if (cVar1 != '\0') {
        (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x350))((longlong *)(lVar4 + 0x10),local_458);
      }
      FUN_14035cac0(local_458);
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400e36a0  @1400e36a0  [medium:callgraph-r0]  (orig: FUN_1400e36a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400e36a0(longlong param_1,undefined4 param_2,undefined4 param_3,char *param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong lVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong lVar11;
  char *pcVar12;
  undefined1 auStack_8f8 [32];
  char *local_8d8;
  undefined4 local_8d0;
  undefined4 local_8c8;
  int local_8b8;
  int local_8b4;
  undefined4 local_8b0;
  longlong local_8a8;
  undefined8 local_8a0;
  char local_898 [1023];
  undefined1 local_499;
  char local_448;
  undefined1 local_447 [1023];
  ulonglong local_48;
  
  local_8a0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_8f8;
  local_8b0 = param_3;
  local_8a8 = param_1;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    local_8d8 = (char *)CONCAT44(local_8d8._4_4_,0x130);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar6 = (**(code **)(**(longlong **)(lVar6 + 0x90) + 0x98))(*(longlong **)(lVar6 + 0x90),param_2);
  if (lVar6 == 0) {
    _snprintf(local_898,0x400,"SELECT  id, recordmap_id FROM cq_user WHERE account_id = %u LIMIT 1")
    ;
    local_499 = 0;
    FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    plVar9 = (longlong *)InstanceGet();
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,local_898,2);
    if (plVar9 == (longlong *)0x0) {
      local_8d8 = (char *)CONCAT44(local_8d8._4_4_,0x669);
      tq::MyLogSave("gmlog/cheater",
                    "OfflineCheatingGotoJail failed, arrest player(idAccount:%u), connect to db failed, at %s, %d"
                   );
    }
    else {
      lVar6 = (**(code **)(*plVar9 + 0x40))(plVar9);
      if (lVar6 == 0) {
        local_8d8 = (char *)CONCAT44(local_8d8._4_4_,0x66e);
        tq::MyLogSave("gmlog/cheater",
                      "OfflineCheatingGotoJail failed, arrest player(idAccount:%u), db can not find the palyer, at %s, %d"
                     );
        (**(code **)*plVar9)(plVar9);
      }
      else {
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,0);
        iVar2 = (**(code **)(*plVar10 + 0x40))(plVar10);
        local_8b4 = iVar2;
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,1);
        iVar3 = (**(code **)(*plVar10 + 0x40))(plVar10);
        local_8b8 = iVar3;
        (**(code **)*plVar9)(plVar9);
        if (iVar2 == 0) {
          local_8d8 = (char *)CONCAT44(local_8d8._4_4_,0x679);
          tq::MyLogSave("gmlog/cheater",
                        "OfflineCheatingGotoJail failed, arrest player(idAccount:%u), idCheater == ID_NONE, at %s, %d"
                       );
        }
        else if (iVar3 == 0x1772) {
          local_8d8 = (char *)CONCAT44(local_8d8._4_4_,0x67e);
          tq::MyLogSave("gmlog/cheater",
                        "OfflineCheatingGotoJail failed, arrest player(idAccount:%u), have been in prison, at %s, %d"
                       );
        }
        else {
          uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          plVar9 = (longlong *)FUN_1400876b0(uVar8);
          lVar6 = (**(code **)(*plVar9 + 0x10))(plVar9,0x1772,1);
          if (lVar6 == 0) {
            local_8d0 = 0x685;
            local_8d8 = 
            "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp";
            tq::MyLogSave("gmlog/cheater",
                          "OfflineCheatingGotoJail failed,arrest player(idAccount:%u), can not find cheat prison map(%u), at %s, %d"
                         );
          }
          else {
            uVar4 = (**(code **)(**(longlong **)(lVar6 + 0x58) + 0x10))
                              (*(longlong **)(lVar6 + 0x58),0xb);
            uVar5 = (**(code **)(**(longlong **)(lVar6 + 0x58) + 0x10))();
            local_448 = '\0';
            memset(local_447,0,0x3ff);
            local_8d0 = uVar5;
            local_8c8 = param_3;
            local_8d8._0_4_ = uVar4;
            _snprintf(&local_448,0x3ff,
                      "UPDATE cq_user SET recordmap_id = %u, recordx = %d, recordy = %d WHERE account_id = %u LIMIT 1"
                     );
            FUN_140008520(*(undefined4 *)(param_1 + 0x10));
            plVar9 = (longlong *)InstanceGet();
            cVar1 = (**(code **)(*plVar9 + 0x30))(plVar9,&local_448,0,1);
            if (cVar1 == '\0') {
              local_8d8._0_4_ = 0x68f;
              tq::MyLogSave("gmlog/cheater",
                            "OfflineCheatingGotoJail failed,arrest player(idAccount:%u), update sql error, at %s, %d"
                           );
            }
            pIVar7 = theInstance();
            plVar9 = (longlong *)FUN_1400e1de0();
            lVar6 = *plVar9;
            uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_OFFLINE_CHEATING_GOTO_JAIL");
            local_8d0 = 0;
            local_8d8 = (char *)CONCAT44(local_8d8._4_4_,3);
            (**(code **)(lVar6 + 8))(plVar9,"SYSTEM",iVar2,uVar8);
          }
        }
      }
    }
  }
  else {
    iVar2 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x168))();
    if (iVar2 == 0x1772) {
      local_8d0 = 0x65c;
      local_8d8 = 
      "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp";
      tq::MyLogSave("gmlog/cheater",
                    "OfflineCheatingGotoJail failed, arrest Player(idUser:%u, idAccount:%u), have been in prison, at %s, %d"
                   );
    }
    else {
      if (param_4 != (char *)0x0) {
        lVar11 = -1;
        pcVar12 = param_4;
        do {
          if (lVar11 == 0) break;
          lVar11 = lVar11 + -1;
          cVar1 = *pcVar12;
          pcVar12 = pcVar12 + 1;
        } while (cVar1 != '\0');
        if (lVar11 != -2) {
          FUN_14035cce0(local_898);
          iVar2 = FUN_14035cda0(local_898,param_2,param_4);
          if (iVar2 != 0) {
            (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x350))(lVar6 + 0x10,local_898);
          }
          FUN_14035cd60(local_898);
        }
      }
      pIVar7 = theInstance();
      uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_OFFLINE_CHEATING_GOTO_JAIL");
      FUN_1401ca920(lVar6,0x1772,uVar8,3);
    }
  }
  return;
}

// ==== CWorldKernel::helper_1400e3b20  @1400e3b20  [medium:callgraph-r0]  (orig: FUN_1400e3b20)
undefined8
FUN_1400e3b20(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,longlong param_6,uint param_7)

{
  undefined1 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined2 uVar6;
  undefined8 uVar7;
  CTickAnalyst local_40 [24];
  
  uVar7 = 0xfffffffffffffffe;
  CTickAnalyst::CTickAnalyst(local_40,0xb);
  if ((param_6 == 0) || (0x3ff < param_7 - 1)) {
    CTickAnalyst::~CTickAnalyst(local_40);
    uVar7 = 0;
  }
  else {
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    plVar4 = (longlong *)FUN_140087650(uVar3);
    lVar5 = (**(code **)(*plVar4 + 0xa0))(plVar4,param_2,param_3);
    if ((lVar5 == 0) || (*(char *)(lVar5 + 0x12c8) == '\0')) {
      FUN_1402b9730(param_1,*(undefined4 *)(param_1 + 0x10),param_2,param_3,param_4,param_5,param_6,
                    param_7,uVar7);
      uVar6 = (undefined2)((uint)param_4 >> 0x10);
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar4 = (longlong *)FUN_140087650(uVar7);
      plVar4 = (longlong *)(**(code **)(*plVar4 + 0xa0))(plVar4,param_2,param_3);
      if (plVar4 == (longlong *)0x0) {
        (**(code **)(**(longlong **)(param_1 + 0x38) + 0x10))
                  (*(longlong **)(param_1 + 0x38),param_3,param_6,param_7 & 0xffff,
                   CONCAT22(uVar6,(short)param_5),1);
      }
      else {
        lVar5 = **(longlong **)(param_1 + 0x38);
        uVar1 = FUN_140167b70(plVar4);
        uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
        (**(code **)(lVar5 + 0x10))
                  (*(undefined8 *)(param_1 + 0x38),uVar2,param_6,param_7 & 0xffff,
                   CONCAT22(uVar6,(short)param_5),uVar1);
      }
      CTickAnalyst::~CTickAnalyst(local_40);
      uVar7 = 1;
    }
    else {
      CTickAnalyst::~CTickAnalyst(local_40);
      uVar7 = 0;
    }
  }
  return uVar7;
}

// ==== CWorldKernel::helper_1400e4d30  @1400e4d30  [medium:callgraph-r2]  (orig: FUN_1400e4d30)
undefined8 *
FUN_1400e4d30(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             void *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x80);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    memcpy(puVar1 + 3,param_5,0x60);
    *(undefined1 *)(puVar1 + 0xf) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x79) = 0;
  }
  return puVar1;
}

// ==== CWorldKernel::helper_1400e6cd0  @1400e6cd0  [medium:callgraph-r1]  (orig: FUN_1400e6cd0)
undefined8 *
FUN_1400e6cd0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x2aaaaaaaaaaaaa8 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1400e4d30(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x78);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x78) == '\0') {
        *(undefined1 *)(plVar2 + 0xf) = 1;
        *(undefined1 *)(lVar4 + 0x78) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x78) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x79) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x78) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x78) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x79) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x78) == '\0') {
        *(undefined1 *)(plVar2 + 0xf) = 1;
        *(undefined1 *)(lVar4 + 0x78) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x78) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x79) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x78) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x78) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x79) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x78);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x78) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CWorldKernel::helper_1400e83d0  @1400e83d0  [medium:callgraph-r0]  (orig: FUN_1400e83d0)
longlong * FUN_1400e83d0(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x79) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x79) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1400e852d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1400e855c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x79) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x79) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x79);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x79);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x79);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x79);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x79) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x79) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1400e852d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1400e6cd0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1400e855c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CWorldKernel::helper_1400eb8e0  @1400eb8e0  [medium:callgraph-r1]  (orig: FUN_1400eb8e0)
void FUN_1400eb8e0(longlong param_1,uint param_2,uint param_3,ushort *param_4)

{
  ushort uVar1;
  uint *puVar2;
  int local_res20 [2];
  undefined1 local_28 [32];
  
  if (param_4 == (ushort *)0x0) {
    return;
  }
  if (0x528 < param_2) {
    if (param_2 < 0x8fd) {
      if (param_2 != 0x8fc) {
        switch(param_2) {
        case 0x7ee:
        case 0x7f1:
        case 0x7f3:
        case 0x817:
        case 0x818:
        case 0x819:
        case 0x81b:
        case 0x81d:
        case 0x82b:
        case 0x82c:
        case 0x82e:
        case 0x82f:
        case 0x831:
        case 0x832:
        case 0x87c:
        case 0x8a0:
        case 0x8a1:
        case 0x8a2:
        case 0x8ad:
          goto switchD_1400eb932_caseD_3ee;
        case 0x7ef:
          goto switchD_1400eb932_caseD_3f1;
        case 0x7f0:
          uVar1 = (ushort)*(char *)((longlong)param_4 + 0xb);
          break;
        default:
          goto switchD_1400eb932_caseD_3ed;
        case 0x7f4:
        case 0x802:
          goto switchD_1400eb9a8_caseD_7f4;
        case 0x7fe:
        case 0x800:
          goto switchD_1400eb932_caseD_3fb;
        case 0x82a:
        case 0x82d:
          uVar1 = param_4[1];
          break;
        case 0x89e:
          uVar1 = param_4[8];
        }
        goto LAB_1400eba17;
      }
    }
    else {
      if (param_2 < 0xa8d) {
        if (param_2 == 0xa8c) {
switchD_1400eb9a8_caseD_7f4:
          uVar1 = (ushort)(char)*param_4;
          goto LAB_1400eba17;
        }
        if (param_2 < 0x96b) {
          if ((param_2 == 0x96a) || (param_2 == 0x910)) goto switchD_1400eb932_caseD_420;
          if ((0x91a < param_2) && (param_2 < 0x91d)) goto switchD_1400eb932_caseD_3ee;
        }
        else {
          if (param_2 == 0x9e5) goto switchD_1400eb932_caseD_420;
          if (param_2 == 0xa32) goto switchD_1400eb9a8_caseD_7f4;
        }
switchD_1400eb932_caseD_3ed:
        uVar1 = *param_4;
        goto LAB_1400eba17;
      }
      if (param_2 != 0x2715) {
        if (param_2 == 0x271a) goto switchD_1400eb932_caseD_3fe;
        if (((param_2 != 0x271e) && (param_2 != 0x2721)) && (param_2 != 0x4e21))
        goto switchD_1400eb932_caseD_3ed;
      }
    }
switchD_1400eb932_caseD_3ee:
    uVar1 = 0;
    goto LAB_1400eba17;
  }
  if (param_2 == 0x528) {
switchD_1400eb932_caseD_420:
    uVar1 = param_4[2];
  }
  else {
    switch(param_2) {
    case 0x3ec:
      uVar1 = param_4[4];
      break;
    default:
      goto switchD_1400eb932_caseD_3ed;
    case 0x3ee:
    case 0x3f0:
    case 0x3f4:
    case 0x3f8:
    case 0x400:
    case 0x401:
    case 0x404:
    case 0x405:
    case 0x410:
    case 0x411:
    case 0x412:
    case 0x421:
    case 0x422:
    case 0x426:
    case 0x428:
    case 0x42a:
    case 0x439:
    case 0x450:
    case 0x451:
    case 0x452:
    case 0x454:
    case 0x455:
    case 0x456:
    case 0x458:
      goto switchD_1400eb932_caseD_3ee;
    case 0x3f1:
switchD_1400eb932_caseD_3f1:
      uVar1 = param_4[6];
      break;
    case 0x3f7:
      uVar1 = (ushort)(char)param_4[4];
      break;
    case 0x3fb:
    case 0x40c:
    case 0x44e:
    case 0x457:
switchD_1400eb932_caseD_3fb:
      uVar1 = (ushort)(char)param_4[2];
      break;
    case 0x3fe:
switchD_1400eb932_caseD_3fe:
      uVar1 = param_4[10];
      break;
    case 0x403:
      uVar1 = param_4[9];
      break;
    case 0x40a:
      uVar1 = (ushort)(char)param_4[8];
      break;
    case 0x420:
      goto switchD_1400eb932_caseD_420;
    case 0x44d:
      uVar1 = (ushort)(char)param_4[9];
      break;
    case 0x46a:
      uVar1 = (ushort)*(char *)((longlong)param_4 + 5);
    }
  }
LAB_1400eba17:
  local_res20[0] = (uint)uVar1 % 1000 + param_2 * 1000;
  puVar2 = (uint *)FUN_1400ea580(param_1 + 0x88,local_res20);
  *puVar2 = *puVar2 + param_3;
  puVar2[1] = puVar2[1] + 1;
  if (puVar2[2] < param_3) {
    puVar2[2] = param_3;
  }
  if ((0x32 < param_3) || (10000 < *puVar2)) {
    FUN_14000d480(param_1 + 0x48,local_28,local_res20);
  }
  return;
}

// ==== CWorldKernel::helper_1400ebc80  @1400ebc80  [medium:callgraph-r1]  (orig: FUN_1400ebc80)
void FUN_1400ebc80(longlong param_1,undefined4 param_2,uint param_3)

{
  uint *puVar1;
  undefined4 local_res10 [6];
  undefined1 local_28 [32];
  
  local_res10[0] = param_2;
  puVar1 = (uint *)FUN_1400ea580(param_1 + 0x188,local_res10);
  *puVar1 = *puVar1 + param_3;
  puVar1[1] = puVar1[1] + 1;
  if (puVar1[2] < param_3) {
    puVar1[2] = param_3;
  }
  if ((0x32 < param_3) || (10000 < *puVar1)) {
    FUN_14000d480(param_1 + 0x148,local_28,local_res10);
  }
  return;
}

// ==== CWorldKernel::helper_1400ebce0  @1400ebce0  [medium:callgraph-r0]  (orig: FUN_1400ebce0)
undefined8
FUN_1400ebce0(longlong param_1,undefined4 param_2,undefined4 param_3,longlong param_4,uint param_5,
             undefined4 param_6)

{
  longlong lVar1;
  char cVar2;
  undefined1 uVar3;
  ulong uVar4;
  ulong uVar5;
  undefined4 uVar6;
  ulong uVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong *plVar10;
  undefined8 in_stack_ffffffffffffff68;
  undefined8 in_stack_ffffffffffffff70;
  longlong lVar11;
  CTickAnalyst local_58 [24];
  undefined8 local_40;
  
  uVar6 = (undefined4)((ulonglong)in_stack_ffffffffffffff70 >> 0x20);
  uVar8 = (undefined4)((ulonglong)in_stack_ffffffffffffff68 >> 0x20);
  local_40 = 0xfffffffffffffffe;
  CTickAnalyst::CTickAnalyst(local_58,7);
  if ((param_4 == 0) || (0x3ff < param_5 - 1)) {
    CTickAnalyst::~CTickAnalyst(local_58);
    return 0;
  }
  uVar4 = tq::TimeGet(0);
  uVar5 = tq::TimeGet(0);
  uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  plVar10 = (longlong *)FUN_140087650(uVar9);
  plVar10 = (longlong *)(**(code **)(*plVar10 + 0xa8))(plVar10,param_2);
  if (plVar10 != (longlong *)0x0) {
    FUN_1401673b0(plVar10,uVar5);
    lVar1 = plVar10[0x1e2];
    uVar6 = (**(code **)(*plVar10 + 8))(plVar10);
    uVar9 = FUN_14035f190();
    lVar11 = param_4;
    FUN_14035e8a0(uVar9,(int)lVar1,uVar6,param_3,CONCAT44(uVar8,param_5),param_4);
    uVar6 = (undefined4)((ulonglong)lVar11 >> 0x20);
    cVar2 = FUN_140188cf0(plVar10,param_3,param_4);
    if (cVar2 == '\0') {
      CTickAnalyst::~CTickAnalyst(local_58);
      return 0;
    }
    if ((char)plVar10[0x259] != '\0') {
      CTickAnalyst::~CTickAnalyst(local_58);
      return 0;
    }
  }
  FUN_1402b6710(param_1,*(undefined4 *)(param_1 + 0x10),param_2,param_3,param_4,
                CONCAT44(uVar6,param_5),param_6);
  uVar7 = tq::TimeGet(0);
  if (DAT_14097576c < (int)(uVar7 - uVar5)) {
    LOCK();
    UNLOCK();
    DAT_14097576c = uVar7 - uVar5;
  }
  if (*(int *)(param_1 + 0x10) == 0xe) {
    uVar9 = FUN_140008520(0xe);
    plVar10 = (longlong *)FUN_140087650(uVar9);
    plVar10 = (longlong *)(**(code **)(*plVar10 + 0xa8))(plVar10,param_2);
    if (plVar10 != (longlong *)0x0) {
      lVar1 = **(longlong **)(param_1 + 0x38);
      uVar3 = FUN_140167b70(plVar10);
      uVar8 = (**(code **)(*plVar10 + 8))(plVar10);
      (**(code **)(lVar1 + 0x10))
                (*(undefined8 *)(param_1 + 0x38),uVar8,param_4,param_5 & 0xffff,(short)param_3,uVar3
                );
    }
  }
  uVar5 = tq::TimeGet(0);
  FUN_1400eb8e0(param_1,param_3,uVar5 - uVar4,param_4);
  CTickAnalyst::~CTickAnalyst(local_58);
  return 1;
}

// ==== CWorldKernel::helper_1400ebf50  @1400ebf50  [medium:callgraph-r0]  (orig: FUN_1400ebf50)
undefined8
FUN_1400ebf50(longlong param_1,undefined4 param_2,undefined4 param_3,longlong param_4,int param_5,
             undefined4 param_6)

{
  ulong uVar1;
  ulong uVar2;
  ulong uVar3;
  
  if ((param_4 != 0) && (param_5 - 1U < 0x400)) {
    uVar1 = tq::TimeGet(0);
    uVar2 = tq::TimeGet(0);
    FUN_1402b6710(param_1,*(undefined4 *)(param_1 + 0x10),param_2,param_3,param_4,param_5,param_6);
    uVar3 = tq::TimeGet(0);
    if (DAT_14097576c < (int)(uVar3 - uVar2)) {
      LOCK();
      UNLOCK();
      DAT_14097576c = uVar3 - uVar2;
    }
    uVar2 = tq::TimeGet(0);
    FUN_1400eb8e0(param_1,param_3,uVar2 - uVar1,param_4);
    return 1;
  }
  return 0;
}

// ==== CWorldKernel::helper_1400ec060  @1400ec060  [medium:callgraph-r0]  (orig: FUN_1400ec060)
undefined8
FUN_1400ec060(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             longlong param_5,int param_6)

{
  ulong uVar1;
  ulong uVar2;
  undefined8 uVar3;
  CTickAnalyst local_50 [24];
  
  CTickAnalyst::CTickAnalyst(local_50,9);
  if ((param_5 == 0) || (0x3ff < param_6 - 1U)) {
    CTickAnalyst::~CTickAnalyst(local_50);
    uVar3 = 0;
  }
  else {
    uVar1 = tq::TimeGet(0);
    FUN_1402b8910(param_1,*(undefined4 *)(param_1 + 0x10),param_2,param_3,param_4,param_5,param_6);
    uVar2 = tq::TimeGet(0);
    FUN_1400ebc80(param_1,param_4,uVar2 - uVar1);
    CTickAnalyst::~CTickAnalyst(local_50);
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CWorldKernel::helper_1400ec160  @1400ec160  [medium:callgraph-r0]  (orig: FUN_1400ec160)
undefined8
FUN_1400ec160(longlong param_1,undefined4 param_2,undefined4 param_3,longlong param_4,int param_5,
             undefined4 param_6)

{
  ulong uVar1;
  ulong uVar2;
  uint *puVar3;
  uint uVar4;
  undefined4 local_res18 [2];
  ulong local_res20;
  undefined1 local_50 [32];
  
  if ((param_4 != 0) && (param_5 - 1U < 0x400)) {
    local_res18[0] = param_3;
    uVar1 = tq::TimeGet(0);
    local_res20 = uVar1;
    FUN_1402b7ee0(param_1,*(undefined4 *)(param_1 + 0x10),param_2,param_3,param_4,param_5,param_6);
    uVar2 = tq::TimeGet(0);
    uVar4 = uVar2 - uVar1;
    puVar3 = (uint *)FUN_1400ea580(param_1 + 0x108,local_res18);
    *puVar3 = *puVar3 + uVar4;
    puVar3[1] = puVar3[1] + 1;
    if (puVar3[2] < uVar4) {
      puVar3[2] = uVar4;
    }
    if ((0x14 < uVar4) || (10000 < *puVar3)) {
      FUN_14000d480(param_1 + 200,local_50,local_res18);
    }
    return 1;
  }
  return 0;
}

// ==== CWorldKernel::ProcessMsg  @1400ec8e0  [high:log-string]  (orig: FUN_1400ec8e0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400ec8e0(ulonglong param_1,uint param_2,uint *param_3,undefined4 param_4)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined1 *puVar4;
  undefined1 uVar5;
  char cVar6;
  undefined2 uVar7;
  uint uVar8;
  uint uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  ulong uVar12;
  int iVar13;
  int iVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  longlong *plVar17;
  longlong *plVar18;
  undefined8 *puVar19;
  undefined8 uVar20;
  IStringManager *pIVar21;
  char *pcVar22;
  undefined8 uVar23;
  longlong lVar24;
  longlong *plVar25;
  ulonglong uVar26;
  uint *puVar27;
  uint *_Str1;
  undefined1 auStack_10f8 [32];
  uint **local_10d8;
  undefined8 local_10d0;
  longlong local_10c8;
  undefined8 local_10c0;
  undefined3 local_10b8 [2];
  undefined8 local_10b0;
  char local_10a8;
  undefined1 local_10a4;
  undefined2 local_10a3;
  ulonglong local_10a0;
  uint *local_1098;
  undefined4 local_1090;
  uint local_1088;
  undefined4 local_1084;
  uint local_1080;
  uint local_107c;
  uint local_1078;
  int local_1074;
  int local_1070;
  CTickAnalyst local_1068 [24];
  CTickAnalyst local_1050 [24];
  undefined8 local_1038;
  uint local_1030;
  uint uStack_102c;
  uint local_1018;
  char local_1014 [60];
  uint local_fd8;
  char local_fd4 [254];
  undefined1 local_ed6;
  undefined4 local_ed4;
  undefined4 local_ed0;
  undefined4 local_ecc;
  undefined4 local_ec8;
  undefined4 local_ec4;
  undefined1 local_ec0;
  uint local_eb8;
  char local_eb4 [60];
  uint local_e78;
  char local_e74 [254];
  undefined1 local_d76;
  undefined4 local_d74;
  undefined4 local_d70;
  undefined4 local_d6c;
  undefined4 local_d68;
  undefined4 local_d64;
  undefined1 local_d60;
  undefined8 local_d58;
  undefined4 local_d50;
  undefined4 local_d4c;
  int local_d48;
  undefined1 local_d44 [1003];
  undefined1 local_959;
  char local_908;
  undefined1 local_907 [7];
  undefined4 local_900;
  int local_8fc;
  undefined1 local_8f8 [1056];
  CIniFile local_4d8;
  undefined1 local_4d7 [1022];
  undefined1 local_d9;
  undefined8 local_d8;
  undefined4 uStack_d0;
  undefined1 uStack_cc;
  undefined2 local_cb;
  undefined1 local_c9;
  undefined8 local_c8;
  ulonglong local_48;
  undefined8 uStack_40;
  
  puVar4 = DAT_140975bd8;
  uStack_40 = 0x1400ec8f6;
  local_1038 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_10f8;
  local_10a0 = param_1;
  local_1098 = param_3;
  if (param_2 < 0x2712) {
    if (param_2 == 0x2711) {
      if (param_3[1] != 0xffffffff) {
        memset(&local_908,0,0x400);
        sprintf(&local_908," userlogin****userlogin [%u]",(ulonglong)*(uint *)(param_1 + 0x208));
        *param_3 = *(uint *)(param_1 + 0x208);
        local_c8._0_4_ = *(undefined4 *)(param_1 + 0x208);
        memcpy((void *)((longlong)&local_c8 + 4),param_3,0x5c);
        FUN_1400e83d0(param_1 + 0x1c8,local_1068,&local_c8);
        plVar17 = (longlong *)InstanceGet();
        (**(code **)(*plVar17 + 0x30))(plVar17,&local_908,0,0);
        *(int *)(param_1 + 0x208) = *(int *)(param_1 + 0x208) + 1;
        return 1;
      }
      log_InlineLogERROR("MAPGROUP_LOGIN pPacket->idSocket = SOCKET_NONE");
      return 1;
    }
    switch(param_2) {
    case 0x3e9:
      local_1088 = param_3[1];
      if (*param_3 != 0x10000) {
        local_10d0 = (ulonglong *)((ulonglong)local_10d0._4_4_ << 0x20);
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,param_3[2]);
        FUN_1400ebce0(param_1,*param_3,local_1088,param_3 + 3);
        return 1;
      }
      local_10d0 = (ulonglong *)((ulonglong)local_10d0._4_4_ << 0x20);
      local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,param_3[2]);
      FUN_1400ebf50(param_1);
      return 1;
    case 0x3ea:
      local_10d0 = (ulonglong *)((ulonglong)local_10d0._4_4_ << 0x20);
      local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,param_3[2]);
      FUN_1400ec160(param_1,*param_3,param_3[1],param_3 + 3);
      return 1;
    case 0x3eb:
      CTickAnalyst::CTickAnalyst(local_1050,2);
      local_10b0 = (longlong *)CONCAT44(local_10b0._4_4_,*param_3);
      if (*(int *)(param_1 + 0x10) == 0xe) {
        FUN_14035cfb0(&local_d58);
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        plVar17 = (longlong *)FUN_140087650(uVar23);
        plVar17 = (longlong *)(**(code **)(*plVar17 + 0xa8))(plVar17);
        if (plVar17 != (longlong *)0x0) {
          if ((char)plVar17[0x259] != '\0') {
            memset(&local_c8,0,0x80);
            uVar8 = (**(code **)(*plVar17 + 8))(plVar17);
            _snprintf((char *)&local_c8,0x7f,"%u",(ulonglong)uVar8);
            lVar24 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
            if (*(longlong *)(lVar24 + 0x80) == 0) {
              local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x140);
              log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMsgPort",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                );
              plVar25 = (longlong *)0x0;
            }
            else {
              plVar25 = *(longlong **)(lVar24 + 0x80);
            }
            local_10d8 = (uint **)&local_c8;
            (**(code **)(*plVar25 + 0x50))(plVar25,6,0x11172,0x80);
            FUN_140368e20(&local_908);
            uVar15 = (**(code **)(*plVar17 + 8))(plVar17);
            cVar6 = FUN_140368ed0(&local_908,2,uVar15,0);
            if (cVar6 != '\0') {
              (**(code **)(*plVar17 + 0x130))(plVar17,&local_908);
            }
            FUN_140368e70(&local_908);
          }
          if (*(longlong *)(param_1 + 0x38) != 0) {
            uVar15 = (**(code **)(*plVar17 + 8))(plVar17);
            cVar6 = FUN_14035d050(&local_d58,uVar15);
            if (cVar6 != '\0') {
              FUN_1401662a0(plVar17);
              lVar24 = **(longlong **)(param_1 + 0x38);
              uVar5 = FUN_140167b70(plVar17);
              uVar15 = (**(code **)(*plVar17 + 8))(plVar17);
              local_10d0 = (ulonglong *)CONCAT71(local_10d0._1_7_,uVar5);
              local_10d8 = (uint **)CONCAT62(local_10d8._2_6_,local_d50._2_2_);
              (**(code **)(lVar24 + 0x10))
                        (*(undefined8 *)(param_1 + 0x38),uVar15,&local_d4c,(short)local_d50 + -4);
            }
          }
        }
        FUN_14035d010(&local_d58);
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      uVar23 = FUN_140087650(uVar23);
      cVar6 = FUN_1402ac250(uVar23,(ulonglong)local_10b0 & 0xffffffff);
      if (cVar6 == '\0') {
        local_10d8 = (uint **)&local_10b0;
        (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                  (*(longlong **)(param_1 + 0x20),2,0x4e23,0xea65);
      }
      else {
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        plVar17 = (longlong *)FUN_140087650(uVar23);
        local_10d0 = (ulonglong *)CONCAT71(local_10d0._1_7_,1);
        local_10d8 = (uint **)((ulonglong)local_10d8 & 0xffffffffffffff00);
        (**(code **)(*plVar17 + 0x40))(plVar17,(ulonglong)local_10b0 & 0xffffffff,0,0);
        local_10d8 = (uint **)&local_10b0;
        (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                  (*(longlong **)(param_1 + 0x20),8,0x15f98,0xea65);
      }
      CTickAnalyst::~CTickAnalyst(local_1050);
      return 1;
    case 0x3ee:
      uVar8 = *param_3;
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0xa8))(plVar17,uVar8);
      if (lVar24 != 0) {
        FUN_1401788f0(lVar24);
        return 1;
      }
      return 1;
    case 0x3f6:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (lVar24 != 0) {
        FUN_1401aa210(lVar24,param_3[1]);
        return 1;
      }
      return 1;
    case 0x3fa:
      if (DAT_140975bd8 == (undefined1 *)0x0) {
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x3ce);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pGm",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
      }
      *puVar4 = 0;
      return 1;
    case 0x3fd:
      local_1078 = param_3[3];
      local_10d0 = (ulonglong *)(param_3 + 5);
      local_10c8 = CONCAT44(local_10c8._4_4_,param_3[4]);
      local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,local_1078);
      FUN_1400e20f0(param_1,*param_3,param_3[1],param_3[2]);
      return 1;
    case 0x3fe:
      uVar8 = param_3[1];
      uVar9 = *param_3;
      uVar1 = param_3[2];
      uVar2 = param_3[3];
      uVar3 = param_3[4];
      local_107c = uVar2;
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      uVar23 = FUN_140087650(uVar23);
      cVar6 = FUN_1402af140(uVar23,uVar9,uVar8);
      if (cVar6 != '\0') {
        local_10c8 = CONCAT44(local_10c8._4_4_,uVar3);
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,uVar2);
        local_10d0 = (ulonglong *)(param_3 + 5);
        FUN_1400e3b20(param_1,uVar9,uVar8,uVar1);
        return 1;
      }
      return 1;
    }
switchD_1400ec95f_caseD_3ec:
    local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x604);
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","!\"CWorldKernel::ProcessMsg()\"",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                      );
    return 1;
  }
  if (0xea61 < param_2) {
    if (param_2 == 0x186a5) {
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (lVar24 == 0) {
        local_10d8 = (uint **)(param_3 + 3);
        tq::MyLogSave("gmlog/GooglePayments",
                      "iduser[%u] is not exist or user off line,web server payments result unAction[%u], szTransactionId[%s]"
                      ,(ulonglong)*param_3,(ulonglong)param_3[2]);
        return 1;
      }
      FUN_1401677f0(lVar24,param_3[2],param_3 + 3);
      return 1;
    }
    if (param_2 == 0x186a6) {
      if (param_3 == (uint *)0x0) {
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x44c);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pWebNotifyData",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                          );
        return 0;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      plVar17 = (longlong *)(**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (plVar17 != (longlong *)0x0) {
        if (param_3[1] == *(uint *)(plVar17 + 0x1e2)) {
          FUN_14035f2f0(&local_d58);
          uVar15 = (**(code **)(*plVar17 + 8))(plVar17);
          local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,1);
          local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,1);
          iVar13 = FUN_14035f5f0(&local_d58,0x25,uVar15,1);
          if (iVar13 != 0) {
            (**(code **)(plVar17[2] + 0x350))(plVar17 + 2,&local_d58);
          }
          FUN_14035f340(&local_d58);
          return 1;
        }
        return 1;
      }
      return 1;
    }
    if (param_2 == 0x186a7) {
      if (param_3 == (uint *)0x0) {
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x460);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pRechargeData",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                          );
        return 0;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,param_3[1]);
      if (lVar24 != 0) {
        local_10c0 = (uint *)CONCAT44(local_10c0._4_4_,1);
        local_10c8 = CONCAT44(local_10c8._4_4_,param_3[6]);
        local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,param_3[5]);
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,param_3[4]);
        FUN_1401ae7f0(lVar24,*param_3,param_3[2],param_3[3]);
        return 1;
      }
      return 1;
    }
    goto switchD_1400ec95f_caseD_3ec;
  }
  if (param_2 != 0xea61) {
    switch(param_2 - 0x2713) {
    case 0:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      puVar19 = (undefined8 *)(**(code **)(*plVar17 + 0x10))(plVar17);
      (**(code **)*puVar19)(puVar19,*param_3,param_3 + 2);
      local_1030 = *param_3;
      uStack_102c = *(undefined4 *)(param_1 + 0x10);
      local_10d8 = (uint **)&local_1030;
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                (*(longlong **)(param_1 + 0x20),1,0x7532,8);
      local_10d8 = (uint **)&local_1030;
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                (*(longlong **)(param_1 + 0x20),2,0x4e22,8);
      return 1;
    case 1:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (lVar24 == 0) {
        return 1;
      }
      FUN_1401c2720(lVar24,param_3[1],param_3 + 2);
      return 1;
    case 2:
      uVar8 = *param_3;
      local_10b0 = (longlong *)CONCAT44(local_10b0._4_4_,param_3[1]);
      uVar9 = param_3[2];
      uVar1 = param_3[3];
      uVar2 = param_3[4];
      if (uVar8 != 0xffffffff) {
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        plVar17 = (longlong *)FUN_140087650(uVar23);
        lVar24 = (**(code **)(*plVar17 + 0xa8))(plVar17,uVar8);
        if (lVar24 != 0) {
          return 1;
        }
        local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,uVar2);
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,uVar1);
        FUN_1400ebce0(param_1,uVar8,uVar9,param_3 + 5);
        return 1;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      uVar26 = (ulonglong)local_10b0;
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,(ulonglong)local_10b0 & 0xffffffff);
      if (lVar24 != 0) {
        return 1;
      }
      local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,uVar2);
      local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,uVar1);
      FUN_1400ec160(param_1,uVar26 & 0xffffffff,uVar9,param_3 + 5);
      return 1;
    default:
      goto switchD_1400ec95f_caseD_3ec;
    case 7:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (lVar24 == 0) {
        return 1;
      }
      FUN_1401c7af0(lVar24,param_3[1],param_3[2],param_3[3]);
      return 1;
    case 8:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_1400e1d30(uVar23);
      (**(code **)(*plVar17 + 0x18))(plVar17,param_3);
      return 1;
    case 10:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (lVar24 == 0) {
        return 1;
      }
      FUN_140163560(lVar24,param_3);
      return 1;
    case 0xb:
      uVar8 = *param_3;
      _Str1 = param_3 + 1;
      uVar26 = 0xffffffffffffffff;
      puVar27 = _Str1;
      do {
        if (uVar26 == 0) break;
        uVar26 = uVar26 - 1;
        uVar9 = *puVar27;
        puVar27 = (uint *)((longlong)puVar27 + 1);
      } while ((char)uVar9 != '\0');
      uVar12 = strtoul((char *)(~uVar26 + (longlong)_Str1),(char **)0x0,10);
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_1400875f0(uVar23);
      plVar17 = (longlong *)(**(code **)(*plVar17 + 0x20))(plVar17,uVar8);
      if (plVar17 == (longlong *)0x0) {
        return 0;
      }
      cVar6 = (**(code **)(*plVar17 + 0x298))(plVar17,0x1040,&local_1030);
      if (cVar6 == '\0') {
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x23b);
        log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pRole->QueryObj(OBJ_NPC, IPP_OF(pTarget))",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                          );
        return 0;
      }
      iVar13 = _stricmp((char *)_Str1,"lookface");
      if (iVar13 == 0) {
        FUN_1400922d0(CONCAT44(uStack_102c,local_1030),5,uVar12,0);
        return 1;
      }
      iVar13 = _stricmp((char *)_Str1,"datastr");
      if (iVar13 != 0) {
        iVar13 = _strnicmp((char *)_Str1,"data",4);
        if (iVar13 != 0) {
          return 1;
        }
        uVar8 = (int)(char)param_3[2] - 0x30;
        if (uVar8 < 4) {
          FUN_1400e3310(CONCAT44(uStack_102c,local_1030),uVar8,uVar12,0);
          return 1;
        }
        return 0;
      }
      local_10d8 = (uint **)((ulonglong)local_10d8 & 0xffffffffffffff00);
      FUN_1400e32a0(CONCAT44(uStack_102c,local_1030),0x16,(char *)(~uVar26 + (longlong)_Str1),0x10);
      return 1;
    case 0xc:
      plVar17 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      local_10d0 = (ulonglong *)((ulonglong)local_10d0 & 0xffffffffffffff00);
      local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,param_3[3]);
      (**(code **)(*plVar17 + 0x108))(plVar17,*param_3,param_3[1],param_3[2]);
      return 1;
    case 0xd:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_1400e1d30(uVar23);
      (**(code **)(*plVar17 + 0x10))(plVar17);
      return 1;
    case 0xe:
      uVar8 = *param_3;
      uVar9 = param_3[1];
      plVar17 = (longlong *)FUN_140087ed0();
      (**(code **)(*plVar17 + 0x318))(plVar17,uVar8,uVar9);
      return 1;
    case 0xf:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_1400875f0(uVar23);
      (**(code **)(*plVar17 + 0x80))(plVar17);
      return 1;
    case 0x10:
      FUN_1403689a0(&local_d58,param_3,param_4);
      if ((short)local_d50 == 0x1008) {
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        plVar17 = (longlong *)FUN_1400876b0(uVar23);
        lVar24 = (**(code **)(*plVar17 + 0x10))(plVar17,local_d4c,1);
        if (lVar24 != 0) {
          FUN_1402cbfe0(lVar24,&local_d58);
        }
      }
      else {
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0xef);
        log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","!\"switch(MAPGROUP_RPC)\"",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                          );
      }
      FUN_140368a50(&local_d58);
      return 1;
    case 0x11:
      plVar17 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      local_10c0 = (uint *)((ulonglong)local_10c0 & 0xffffffffffffff00);
      local_10c8 = CONCAT44(local_10c8._4_4_,param_3[5]);
      local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,param_3[4]);
      local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,param_3[3]);
      (**(code **)(*plVar17 + 0x100))(plVar17,*param_3,param_3[1],param_3[2]);
      return 1;
    case 0x12:
      if (param_3 == (uint *)0x0) {
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x282);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pstAddr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                          );
        return 0;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0xa8))(plVar17,*param_3);
      if (lVar24 == 0) {
        return 1;
      }
      *(uint *)(lVar24 + 0x1234) = param_3[1];
      return 1;
    case 0x13:
      CTickAnalyst::CTickAnalyst(local_1050,3);
      plVar17 = (longlong *)0x0;
      local_1084 = 0;
      if (param_3 == (uint *)0x0) {
        CTickAnalyst::~CTickAnalyst(local_1050);
        return 1;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      uVar23 = FUN_140087650(uVar23);
      plVar25 = (longlong *)FUN_1402ae4a0(uVar23,param_3[2]);
      local_d8._0_4_ = (uint)plVar25;
      local_d8._4_4_ = (uint)((ulonglong)plVar25 >> 0x20);
      if (plVar25 == (longlong *)0x0) {
        local_10d8 = (uint **)(param_3 + 1);
        (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                  (*(longlong **)(param_1 + 0x20),1,0x7538,0xea65);
      }
      else {
        local_1084 = (**(code **)(*plVar25 + 8))(plVar25);
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        uVar23 = FUN_140087650(uVar23);
        FUN_1402b0840(uVar23,param_3[2]);
        FUN_140178260(plVar25);
        CTickAnalyst::CTickAnalyst(local_1068,4);
        FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        uVar23 = InstanceGet();
        FUN_140359330(plVar25,uVar23);
        CTickAnalyst::~CTickAnalyst(local_1068);
        FUN_140164850(plVar25,param_3[3]);
        FUN_140165170(plVar25,param_3[4]);
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        cVar6 = FUN_14008abd0(uVar23);
        if (cVar6 == '\0') {
          FUN_1401649d0(plVar25,param_3[5]);
        }
        else {
          uVar15 = FUN_1401649b0(plVar25);
          uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          uVar15 = FUN_1400a72a0(uVar23,uVar15);
          FUN_1401649d0(plVar25,uVar15);
          uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          uVar5 = FUN_140092840(uVar23);
          uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          uVar15 = FUN_14008b410(uVar23);
          FUN_1403686d0(&local_d58);
          cVar6 = FUN_140368780(&local_d58,uVar5,uVar15);
          if (cVar6 != '\0') {
            (**(code **)(plVar25[2] + 0x350))(plVar25 + 2,&local_d58);
          }
          FUN_140368720(&local_d58);
        }
        FUN_1403623c0(&local_908);
        uVar15 = FUN_140167980(plVar25);
        cVar6 = FUN_140362470(&local_908,uVar15);
        if (cVar6 != '\0') {
          (**(code **)(plVar25[2] + 0x350))(plVar25 + 2,&local_908);
        }
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        FUN_1400a7f50(uVar23,plVar25);
        puVar27 = param_3 + 1;
        local_1030 = *puVar27;
        uStack_102c = *(uint *)(param_1 + 0x10);
        local_10d8 = (uint **)&local_1030;
        (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                  (*(longlong **)(param_1 + 0x20),1,0x7532,8);
        CTickAnalyst::CTickAnalyst(local_1068,6);
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        plVar18 = (longlong *)FUN_140087650(uVar23);
        (**(code **)(*plVar18 + 0x38))(plVar18,*puVar27,plVar25);
        CTickAnalyst::~CTickAnalyst(local_1068);
        lVar24 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        if (*(longlong *)(lVar24 + 0x80) == 0) {
          local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x140);
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMsgPort",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
        }
        else {
          plVar17 = *(longlong **)(lVar24 + 0x80);
        }
        local_10d8 = (uint **)puVar27;
        (**(code **)(*plVar17 + 0x50))(plVar17,2,0x4e28,0xea65);
        if (*(int *)(param_1 + 0x10) == 0xe) {
          CTickAnalyst::CTickAnalyst(local_1068,5);
          FUN_140368570(&local_d58);
          uVar15 = (**(code **)(*plVar25 + 8))(plVar25);
          cVar6 = FUN_140368610(&local_d58,uVar15);
          if (cVar6 != '\0') {
            local_10b8[0] = CONCAT12(local_10b8[0]._2_1_,local_d50._2_2_);
            lVar24 = **(longlong **)(param_1 + 0x38);
            uVar5 = FUN_140167b70(plVar25);
            uVar15 = (**(code **)(*plVar25 + 8))(plVar25);
            local_10d0 = (ulonglong *)CONCAT71(local_10d0._1_7_,uVar5);
            local_10d8 = (uint **)CONCAT62(local_10d8._2_6_,(undefined2)local_10b8[0]);
            (**(code **)(lVar24 + 0x10))
                      (*(undefined8 *)(param_1 + 0x38),uVar15,&local_d4c,(short)local_d50 + -4);
          }
          FUN_1403685d0(&local_d58);
          CTickAnalyst::~CTickAnalyst(local_1068);
        }
        plVar17 = plVar25 + 2;
        local_10b0 = plVar17;
        cVar6 = (**(code **)(*plVar17 + 0x230))(plVar17);
        if (cVar6 != '\0') {
          FUN_14018fc20(plVar25);
        }
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        plVar18 = (longlong *)FUN_1400876b0(uVar23);
        lVar24 = *plVar18;
        uVar15 = (**(code **)(*plVar17 + 0x168))(plVar17);
        lVar24 = (**(code **)(lVar24 + 0x10))(plVar18,uVar15,1);
        if (lVar24 == 0) {
          local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x1ba);
          log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",&DAT_140705b14,
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                            );
          uVar8 = (**(code **)(*plVar25 + 8))(plVar25);
          uVar9 = (**(code **)(*plVar17 + 0x168))(plVar17);
          log_InlineLogERROR("MAPGROUP_LOGINOVER EnterMap: invalid map id[%u] of user:%u",
                             (ulonglong)uVar9,(ulonglong)uVar8);
        }
        else {
          uVar15 = (**(code **)(**(longlong **)(lVar24 + 0x58) + 0x10))
                             (*(longlong **)(lVar24 + 0x58),3);
          FUN_140362560(&local_d58);
          plVar25 = plVar25 + 2;
          uVar7 = (**(code **)(*plVar25 + 0x50))(plVar25);
          uVar16 = (**(code **)(*plVar25 + 0x48))(plVar25);
          uVar10 = (**(code **)(*plVar25 + 0x40))(plVar25);
          uVar11 = (**(code **)(*local_10b0 + 0x168))(local_10b0);
          local_10c0 = (uint *)((ulonglong)local_10c0._4_4_ << 0x20);
          local_10c8 = CONCAT44(local_10c8._4_4_,uVar15);
          local_10d0 = (ulonglong *)CONCAT62(local_10d0._2_6_,0x4a);
          local_10d8 = (uint **)CONCAT62(local_10d8._2_6_,uVar7);
          iVar13 = FUN_140362620(&local_d58,uVar11,uVar10,uVar16);
          if (iVar13 != 0) {
            (**(code **)(*local_10b0 + 0x350))(local_10b0,&local_d58);
          }
          lVar24 = CONCAT44(local_d8._4_4_,(uint)local_d8);
          FUN_1401c4e10(lVar24,1);
          plVar17 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          (**(code **)(*plVar17 + 0xf0))(plVar17,*(undefined4 *)(lVar24 + 0xf10));
          FUN_1403625e0(&local_d58);
        }
        FUN_140362410(&local_908);
      }
      local_10d8 = (uint **)param_3;
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                (*(longlong **)(param_1 + 0x20),4,0xc355,0x5c);
      CTickAnalyst::~CTickAnalyst(local_1050);
      return 1;
    case 0x14:
      local_10b0 = (longlong *)CONCAT44(local_10b0._4_4_,*param_3);
      local_10d8 = (uint **)&local_10b0;
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                (*(longlong **)(param_1 + 0x20),8,0x15f98,0xea65);
      return 1;
    case 0x1b:
      if (*param_3 == 0xffffffff) {
        return 1;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,param_3[1]);
      if (lVar24 == 0) {
        return 1;
      }
      FUN_1401754c0(lVar24,param_3[2],param_3[3],param_3[4]);
      return 1;
    case 0x1c:
      plVar17 = (longlong *)InstanceGet();
      cVar6 = (**(code **)(*plVar17 + 0x38))(plVar17);
      if (cVar6 == '\0') {
        log_InlineLogERROR("MapGroup reconnect database failed at %s, %d",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                           ,0x2c8);
        return 1;
      }
      log_InlineLogMessage("MapGroup reconnect database success.");
      return 1;
    case 0x1d:
      if (*param_3 == 0xffffffff) {
        return 1;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,param_3[1]);
      if (lVar24 == 0) {
        return 1;
      }
      FUN_140175720(lVar24,param_3[2]);
      return 1;
    case 0x1e:
      if (DAT_140949790 != '\0') {
        log_InlineLogERROR("mapgroup enter dead loop...");
      }
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    case 0x1f:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (lVar24 == 0) {
        return 1;
      }
      FUN_140164920(lVar24,param_3[1]);
      return 1;
    case 0x20:
      local_1080 = param_3[2];
      local_10d8 = (uint **)(param_3 + 5);
      local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,param_3[4]);
      FUN_1400ec060(param_1,*param_3,param_3[1]);
      return 1;
    case 0x21:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_1400876b0(uVar23);
      (**(code **)(*plVar17 + 0x180))(plVar17);
      return 1;
    case 0x22:
      if (0 < (int)param_3[1]) {
        local_d58._0_4_ = (uint)local_d58 & 0xffffff00;
        memset((void *)((longlong)&local_d58 + 1),0,0x417);
        local_d58._0_4_ = 0;
        local_1070 = 0;
        while (iVar13 = local_1070, local_1070 < (int)param_3[1]) {
          uVar8 = param_3[(longlong)local_1070 + 2];
          uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          plVar17 = (longlong *)FUN_140087650(uVar23);
          lVar24 = (**(code **)(*plVar17 + 0xa8))(plVar17,uVar8);
          if (lVar24 != 0) {
            if (0x418 < (longlong)local_d58._4_4_ * 4 + 0xcU) {
              local_10d8 = (uint **)&local_d58;
              (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                        (*(longlong **)(param_1 + 0x20),1,0x7541,0x418);
              local_d58._4_4_ = 0;
            }
            (&local_d50)[local_d58._4_4_] = uVar8;
            local_d58._4_4_ = local_d58._4_4_ + 1;
          }
          local_1070 = iVar13 + 1;
        }
        if (0 < local_d58._4_4_) {
          local_10d8 = (uint **)&local_d58;
          (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                    (*(longlong **)(param_1 + 0x20),1,0x7541,0x418);
        }
        local_1074 = 0;
        while (iVar13 = local_1074, local_1074 < (int)param_3[1]) {
          uVar8 = param_3[(longlong)local_1074 + 2];
          uVar9 = *param_3;
          uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          plVar17 = (longlong *)FUN_140087650(uVar23);
          lVar24 = (**(code **)(*plVar17 + 0xa8))(plVar17,uVar8);
          if (lVar24 != 0) {
            if (uVar9 == 0) {
              uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
              plVar17 = (longlong *)FUN_140087650(uVar23);
              (**(code **)(*plVar17 + 0x48))(plVar17,uVar8,"CrossKernel logout timeout!");
            }
            else if (uVar9 == 1) {
              uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
              plVar17 = (longlong *)FUN_140087650(uVar23);
              (**(code **)(*plVar17 + 0x48))(plVar17,uVar8,"Cross connection is broken!");
            }
            else if (uVar9 == 2) {
              uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
              plVar17 = (longlong *)FUN_140087650(uVar23);
              (**(code **)(*plVar17 + 0x48))(plVar17,uVar8,"OS connection is broken!");
            }
          }
          local_1074 = iVar13 + 1;
        }
        return 1;
      }
      return 0;
    case 0x23:
      local_d8._0_4_ = 0;
      local_d8._4_4_ = 0;
      uStack_d0 = 0;
      uStack_cc = 0;
      local_cb = 0;
      local_c9 = 0;
      CIniFile::CIniFile(&local_4d8,"shell.ini","AccountServer");
      CIniFile::GetString(&local_4d8,(char *)&local_d8,"SERVERNAME",0x10);
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      FUN_1400a7930(uVar23);
      FUN_140361c60(&local_908);
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      uVar15 = FUN_14008b420(uVar23);
      cVar6 = FUN_140361d10(&local_908,uVar15,&local_d8);
      if (cVar6 != '\0') {
        local_d58._0_4_ = 0;
        local_d4c = 1;
        local_d50 = local_900;
        local_d48 = local_8fc;
        memcpy(local_d44,local_8f8,(longlong)local_8fc);
        local_10d8 = (uint **)&local_d58;
        (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                  (*(longlong **)(param_1 + 0x20),6,0x3fc);
        FUN_140361cb0(&local_908);
        CIniFile::~CIniFile(&local_4d8);
        return 1;
      }
      log_InlineLogERROR("MAPGROUP_CROSS_SERVERNAME: failed in create CCrossMsgServerName msg");
      FUN_140361cb0(&local_908);
      CIniFile::~CIniFile(&local_4d8);
      return 1;
    case 0x24:
      uVar8 = *param_3;
      lVar24 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      if (*(longlong *)(lVar24 + 0x148) == 0) {
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x14d);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pCrossConfig",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        uVar23 = 0;
      }
      else {
        uVar23 = *(undefined8 *)(lVar24 + 0x148);
      }
      FUN_140005860(uVar23,(char)uVar8);
      if ((char)uVar8 != '\0') {
        return 1;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      FUN_1400a7930(uVar23);
      return 1;
    case 0x25:
      local_10b0 = (longlong *)((ulonglong)local_10b0._4_4_ << 0x20);
      local_10a0 = param_1 & 0xffffffff00000000;
      iVar13 = sscanf((char *)param_3,"%u %u",&local_10b0,&local_10a0);
      if (iVar13 != 2) {
        log_InlineLogERROR("CSocketKernel::ProcessMsg(MAPGROUP_CROSS_ADD_SOCKET_END) invalid param."
                          );
        return 1;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      plVar17 = (longlong *)
                (**(code **)(*plVar17 + 0x98))(plVar17,(ulonglong)local_10b0 & 0xffffffff);
      if (plVar17 == (longlong *)0x0) {
        return 1;
      }
      FUN_14017bb90(plVar17,0);
      FUN_140168db0(plVar17);
      FUN_140361e70(&local_d58);
      cVar6 = FUN_140361f20(&local_d58,(ulonglong)local_10b0 & 0xffffffff,1);
      if (cVar6 != '\0') {
        (**(code **)(*plVar17 + 0x130))(plVar17,&local_d58);
      }
      FUN_140361ec0(&local_d58);
      return 1;
    case 0x26:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (lVar24 != 0) {
        FUN_140167590(lVar24,param_3[2],param_3 + 3);
        return 1;
      }
      local_10d8 = (uint **)(param_3 + 3);
      tq::MyLogSave("gmlog/IPADPayments",
                    "iduser[%u] is not exist or user off line,web server payments result unAction[%u], szTransactionId[%s]"
                    ,(ulonglong)*param_3,(ulonglong)param_3[2]);
      return 1;
    case 0x27:
      if (param_3 != (uint *)0x0) {
        lVar24 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        if (*(longlong *)(lVar24 + 0x188) == 0) {
          local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x154);
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pAuctionMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar23 = 0;
        }
        else {
          uVar23 = *(undefined8 *)(lVar24 + 0x188);
        }
        FUN_14022d6f0(uVar23,param_3);
        return 1;
      }
      return 0;
    case 0x28:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,param_3[1]);
      if (lVar24 != 0) {
        FUN_1401676c0(lVar24,param_3[2],param_3[3]);
        return 1;
      }
      local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,param_3[3]);
      local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,param_3[2]);
      tq::MyLogSave("gmlog/IPADPayments",
                    "iduser[%u] is not exist or user off line,query paments info result:accoutid:[%u], CurrentMoney:[%u], ConstraintMoney:[%u]"
                    ,(ulonglong)param_3[1],(ulonglong)*param_3);
      return 1;
    case 0x29:
      uVar15 = (**(code **)(**(longlong **)(param_1 + 0x20) + 8))();
      uVar23 = FUN_140008520(uVar15);
      FUN_14008a800(uVar23);
      return 1;
    case 0x2a:
      if (param_3 != (uint *)0x0) {
        FUN_1400e36a0(param_1,*param_3,param_3[1],0);
        return 1;
      }
      tq::MyLogSave("gmlog/cheater","OfflineCheatingGotoJail failed, pPacket == NULL, at %s, %d",
                    "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                    ,0x539);
      return 0;
    case 0x2b:
      if (param_3 != (uint *)0x0) {
        FUN_1400e2080(param_1,*param_3,(short)param_3[1]);
        return 1;
      }
      tq::MyLogSave("gmlog/cheater","ProcessTempCheatJail failed, pPacket == NULL, at %s, %d",
                    "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                    ,0x585);
      return 0;
    case 0x2c:
      if (param_3 != (uint *)0x0) {
        if (*param_3 == 3) {
          uVar23 = 0;
          local_eb8 = 0;
          local_eb4[0] = '\0';
          local_eb4[1] = '\0';
          local_eb4[2] = '\0';
          local_eb4[3] = '\0';
          local_eb4[4] = '\0';
          local_eb4[5] = '\0';
          local_eb4[6] = '\0';
          local_eb4[7] = '\0';
          local_eb4[8] = '\0';
          local_eb4[9] = '\0';
          local_eb4[10] = '\0';
          local_eb4[0xb] = '\0';
          local_eb4[0xc] = '\0';
          local_eb4[0xd] = '\0';
          local_eb4[0xe] = '\0';
          local_eb4[0xf] = '\0';
          local_eb4[0x10] = '\0';
          local_eb4[0x11] = '\0';
          local_eb4[0x12] = '\0';
          local_eb4[0x13] = '\0';
          local_eb4[0x14] = '\0';
          local_eb4[0x15] = '\0';
          local_eb4[0x16] = '\0';
          local_eb4[0x17] = '\0';
          local_eb4[0x18] = '\0';
          local_eb4[0x19] = '\0';
          local_eb4[0x1a] = '\0';
          local_eb4[0x1b] = '\0';
          local_eb4[0x1c] = '\0';
          local_eb4[0x1d] = '\0';
          local_eb4[0x1e] = '\0';
          local_eb4[0x1f] = '\0';
          local_eb4[0x20] = '\0';
          local_eb4[0x21] = '\0';
          local_eb4[0x22] = '\0';
          local_eb4[0x23] = '\0';
          local_eb4[0x24] = '\0';
          local_eb4[0x25] = '\0';
          local_eb4[0x26] = '\0';
          local_eb4[0x27] = '\0';
          local_eb4[0x28] = '\0';
          local_eb4[0x29] = '\0';
          local_eb4[0x2a] = '\0';
          local_eb4[0x2b] = '\0';
          local_eb4[0x2c] = '\0';
          local_eb4[0x2d] = '\0';
          local_eb4[0x2e] = '\0';
          local_eb4[0x2f] = '\0';
          local_eb4[0x30] = '\0';
          local_eb4[0x31] = '\0';
          local_eb4[0x32] = '\0';
          local_eb4[0x33] = '\0';
          local_eb4[0x34] = '\0';
          local_eb4[0x35] = '\0';
          local_eb4[0x36] = '\0';
          local_eb4[0x37] = '\0';
          local_eb4[0x38] = '\0';
          local_eb4[0x39] = '\0';
          local_eb4[0x3a] = '\0';
          local_eb4[0x3b] = '\0';
          local_e78 = 0;
          memset(local_e74,0,0xff);
          local_d74 = 0;
          local_d70 = 0;
          local_d6c = 0;
          local_d68 = 0;
          local_d64 = 0x1e;
          local_d60 = 0;
          local_eb8 = param_3[1];
          pIVar21 = theInstance();
          pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_CHANGSERVER_NAME");
          strncpy(local_eb4,pcVar22,0x10);
          pIVar21 = theInstance();
          pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)
                                      (pIVar21,"STR_CHANGESERVER_RESULT_MAIL_TITLE");
          _snprintf(local_eb4 + 0x20,0x20,pcVar22);
          local_e78 = local_e78 & 0xffffff;
          pIVar21 = theInstance();
          pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)
                                      (pIVar21,"STR_CHANGESERVER_NO_CONNECT");
          _snprintf(local_e74,0xff,pcVar22);
          local_d76 = 0;
          lVar24 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          if (*(longlong *)(lVar24 + 0x180) == 0) {
            local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x153);
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMailMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                              );
          }
          else {
            uVar23 = *(undefined8 *)(lVar24 + 0x180);
          }
          FUN_1400df9c0(uVar23);
          local_1098 = *(uint **)(param_3 + 1);
          local_1090 = 1;
          local_10d8 = &local_1098;
          (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                    (*(longlong **)(param_1 + 0x20),2,0x4e2e,0xc);
        }
        else if (*param_3 == 4) {
          if ((param_3[0x10] < 0x14) && (-1 < (int)param_3[0x10])) {
            uVar23 = 0;
            local_1018 = 0;
            local_1014[0] = '\0';
            local_1014[1] = '\0';
            local_1014[2] = '\0';
            local_1014[3] = '\0';
            local_1014[4] = '\0';
            local_1014[5] = '\0';
            local_1014[6] = '\0';
            local_1014[7] = '\0';
            local_1014[8] = '\0';
            local_1014[9] = '\0';
            local_1014[10] = '\0';
            local_1014[0xb] = '\0';
            local_1014[0xc] = '\0';
            local_1014[0xd] = '\0';
            local_1014[0xe] = '\0';
            local_1014[0xf] = '\0';
            local_1014[0x10] = '\0';
            local_1014[0x11] = '\0';
            local_1014[0x12] = '\0';
            local_1014[0x13] = '\0';
            local_1014[0x14] = '\0';
            local_1014[0x15] = '\0';
            local_1014[0x16] = '\0';
            local_1014[0x17] = '\0';
            local_1014[0x18] = '\0';
            local_1014[0x19] = '\0';
            local_1014[0x1a] = '\0';
            local_1014[0x1b] = '\0';
            local_1014[0x1c] = '\0';
            local_1014[0x1d] = '\0';
            local_1014[0x1e] = '\0';
            local_1014[0x1f] = '\0';
            local_1014[0x20] = '\0';
            local_1014[0x21] = '\0';
            local_1014[0x22] = '\0';
            local_1014[0x23] = '\0';
            local_1014[0x24] = '\0';
            local_1014[0x25] = '\0';
            local_1014[0x26] = '\0';
            local_1014[0x27] = '\0';
            local_1014[0x28] = '\0';
            local_1014[0x29] = '\0';
            local_1014[0x2a] = '\0';
            local_1014[0x2b] = '\0';
            local_1014[0x2c] = '\0';
            local_1014[0x2d] = '\0';
            local_1014[0x2e] = '\0';
            local_1014[0x2f] = '\0';
            local_1014[0x30] = '\0';
            local_1014[0x31] = '\0';
            local_1014[0x32] = '\0';
            local_1014[0x33] = '\0';
            local_1014[0x34] = '\0';
            local_1014[0x35] = '\0';
            local_1014[0x36] = '\0';
            local_1014[0x37] = '\0';
            local_1014[0x38] = '\0';
            local_1014[0x39] = '\0';
            local_1014[0x3a] = '\0';
            local_1014[0x3b] = '\0';
            local_fd8 = 0;
            memset(local_fd4,0,0xff);
            local_ed4 = 0;
            local_ed0 = 0;
            local_ecc = 0;
            local_ec8 = 0;
            local_ec4 = 0x1e;
            local_ec0 = 0;
            local_1018 = param_3[1];
            pIVar21 = theInstance();
            pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_CHANGSERVER_NAME");
            strncpy(local_1014,pcVar22,0x10);
            if (param_3[0x10] == 1) {
              pIVar21 = theInstance();
              pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)
                                          (pIVar21,"STR_CHANGESERVER_SUCCESS_MAIL_TITLE");
              _snprintf(local_1014 + 0x20,0x20,pcVar22);
              local_fd8 = local_fd8 & 0xffffff;
              local_10c8 = CONCAT44(local_10c8._4_4_,param_3[0x11]);
              local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,param_3[0x11]);
              local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,param_3[2]);
              tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4273\t%d\t%d\t1\t",
                            (ulonglong)param_3[1],param_3 + 3);
            }
            else {
              pIVar21 = theInstance();
              pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)
                                          (pIVar21,"STR_CHANGESERVER_FAIL_MAIL_TITLE");
              _snprintf(local_1014 + 0x20,0x20,pcVar22);
              local_fd8 = local_fd8 & 0xffffff;
            }
            pIVar21 = theInstance();
            pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)
                                        (pIVar21,"STR_CHGSERVER_RESULT_NONE" +
                                                 (longlong)(int)param_3[0x10] * 0x80);
            _snprintf(local_fd4,0xff,pcVar22);
            local_ed6 = 0;
            lVar24 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
            if (*(longlong *)(lVar24 + 0x180) == 0) {
              local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x153);
              log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMailMgr",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                );
            }
            else {
              uVar23 = *(undefined8 *)(lVar24 + 0x180);
            }
            FUN_1400df9c0(uVar23,&local_1018);
          }
          uStack_102c = param_3[0xf];
          local_10d0 = (ulonglong *)Ordinal_12();
          local_10c8 = CONCAT44(local_10c8._4_4_,param_3[0x10]);
          local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,param_3[2]);
          local_10c0 = param_3 + 7;
          tq::MyLogSave("gmlog/ChangeServer",
                        "MAPGROUP_CHANGESERVERNOTIFY APP_CHANGE_SERVER_RESULT. action:%u, iduser:%u, idacount:%u, ip:%s Result[%d] InServer[%s]"
                        ,(ulonglong)*param_3,(ulonglong)param_3[1]);
          local_d8._0_4_ = param_3[1];
          local_d8._4_4_ = param_3[2];
          uStack_d0 = 1;
          local_10d8 = (uint **)&local_d8;
          (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                    (*(longlong **)(param_1 + 0x20),2,0x4e2e,0xc);
        }
        local_10c0 = param_3 + 7;
        local_10c8 = CONCAT44(local_10c8._4_4_,param_3[0x10]);
        local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,param_3[2]);
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,*param_3);
        tq::MyLogSave("gmlog/ChangeServer",
                      "MAPGROUP_CHANGESERVER_NOTIFY iduser[%u] is %s,change server result:action:%u, idacount:%u, Result[%d] InServer[%s]"
                      ,(ulonglong)param_3[1],"offline");
        return 1;
      }
      return 0;
    case 0x2d:
      if (param_3 == (uint *)0x0) {
        return 0;
      }
      uVar8 = *param_3;
      if (uVar8 == 0) {
        uVar8 = param_3[1];
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        FUN_14008ac50(uVar23,uVar8 != 0);
        if (param_3[1] == 0) {
          return 1;
        }
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        FUN_14008ac40(uVar23,1);
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        FUN_14008ac60(uVar23,1,0);
        return 1;
      }
      if (uVar8 == 1) {
        uVar8 = param_3[1];
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        FUN_14008ac40(uVar23,uVar8 != 1);
        return 1;
      }
      if (uVar8 != 2) {
        if (uVar8 != 3) {
          return 1;
        }
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        FUN_14008ac60(uVar23,1,param_3[1]);
        return 1;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      FUN_14008ac60(uVar23,0,param_3[1]);
      return 1;
    case 0x2e:
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      plVar17 = (longlong *)(**(code **)(*plVar17 + 0xa8))(plVar17,*param_3);
      if (plVar17 == (longlong *)0x0) {
        return 1;
      }
      uVar23 = Ordinal_12(param_3[2]);
      uVar8 = (**(code **)(*plVar17 + 8))(plVar17);
      local_10d8 = (uint **)uVar23;
      tq::SysLogSave("detectmsgcount","User[%u] MsgCount[%d] ip[%s]",(ulonglong)uVar8,
                     (ulonglong)param_3[1]);
      if ((char)plVar17[0x259] != '\0') {
        uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        plVar25 = (longlong *)FUN_140087650(uVar23);
        (**(code **)(*plVar25 + 0x50))(plVar25,plVar17,"User in Corss. msg count over limit");
        return 1;
      }
      plVar25 = (longlong *)FUN_1400e1e60();
      lVar24 = *plVar25;
      uVar15 = (**(code **)(*plVar17 + 8))(plVar17);
      (**(code **)(lVar24 + 0xc0))(plVar25,uVar15,100);
      return 1;
    case 0x2f:
      if (param_3 != (uint *)0x0) {
        lVar24 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        if (*(longlong *)(lVar24 + 0x1e0) == 0) {
          local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x160);
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMainProcedure",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar23 = 0;
        }
        else {
          uVar23 = *(undefined8 *)(lVar24 + 0x1e0);
        }
        FUN_14001c2a0(uVar23,param_3);
        return 1;
      }
      return 0;
    case 0x30:
      if (param_3 != (uint *)0x0) {
        plVar17 = (longlong *)FUN_1400e1e60();
        (**(code **)(*plVar17 + 0xd8))(plVar17,*param_3,param_3[1],param_3 + 3);
        return 1;
      }
      tq::MyLogSave("gmlog/cheater",
                    "MAPGROUP_ARRESTED_TEMP_JAIL failed, pTempCheatJail == NULL, at %s, %d",
                    "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                    ,0x5c3);
      return 0;
    case 0x31:
      uVar8 = *param_3;
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      plVar17 = (longlong *)(**(code **)(*plVar17 + 0xa8))(plVar17,uVar8);
      if (plVar17 == (longlong *)0x0) {
        return 1;
      }
      FUN_140368e20(&local_d58);
      uVar15 = (**(code **)(*plVar17 + 8))(plVar17);
      cVar6 = FUN_140368ed0(&local_d58,2,uVar15,0);
      if (cVar6 != '\0') {
        (**(code **)(*plVar17 + 0x130))(plVar17,&local_d58);
      }
      FUN_140368e70(&local_d58);
      return 1;
    case 0x32:
      if (param_3 != (uint *)0x0) {
        local_10d8 = (uint **)(param_3 + 3);
        FUN_1400e3570(param_1,(short)*param_3,param_3[1],param_3[2]);
        return 1;
      }
      tq::MyLogSave("gmlog/cheater","MAPGROUP_CHEAT_TQP failed, pPacket == NULL, at %s, %d",
                    "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                    ,0x592);
      return 0;
    case 0x33:
      if (param_3 == (uint *)0x0) {
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x5dc);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pSelectNameData",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                          );
        return 0;
      }
      cVar6 = '\0';
      local_10a8 = '\0';
      if ((char)param_3[2] == '\x01') {
        plVar17 = (longlong *)CurrentInstanceGet();
        plVar17 = (longlong *)(**(code **)(*plVar17 + 0x20))(plVar17,8);
        if (plVar17 != (longlong *)0x0) {
          local_10d8 = (uint **)CONCAT71(local_10d8._1_7_,(char)param_3[0xe] == '\0');
          cVar6 = (**(code **)(*plVar17 + 0x110))(plVar17,*param_3,param_3[1],(longlong)param_3 + 9)
          ;
          local_10a8 = cVar6;
        }
      }
      else {
        if ((char)param_3[2] != '\x02') {
          return 1;
        }
        plVar17 = (longlong *)CurrentInstanceGet();
        plVar17 = (longlong *)(**(code **)(*plVar17 + 0x20))(plVar17,0x16);
        if (plVar17 != (longlong *)0x0) {
          local_10d8 = (uint **)CONCAT71(local_10d8._1_7_,(char)param_3[0xe] == '\0');
          cVar6 = (**(code **)(*plVar17 + 0x240))(plVar17,*param_3,param_3[1],(longlong)param_3 + 9)
          ;
          local_10a8 = cVar6;
        }
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      uVar23 = (**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (cVar6 != '\0') {
        uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        uVar20 = FUN_140087730(uVar20);
        local_10d0 = (ulonglong *)0x0;
        local_10d8 = (uint **)((ulonglong)local_10d8 & 0xffffffff00000000);
        FUN_140145f60(uVar20,param_3[0xc],uVar23,0);
        return 1;
      }
      uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      uVar20 = FUN_140087730(uVar20);
      local_10d0 = (ulonglong *)0x0;
      local_10d8 = (uint **)((ulonglong)local_10d8 & 0xffffffff00000000);
      FUN_140145f60(uVar20,param_3[0xd],uVar23,0);
      return 1;
    case 0x34:
      goto switchD_1400ecefa_caseD_34;
    case 0x35:
      if (param_3 == (uint *)0x0) {
        local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x481);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pNotifyData",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                          );
        return 0;
      }
      uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      plVar17 = (longlong *)FUN_140087650(uVar23);
      plVar17 = (longlong *)(**(code **)(*plVar17 + 0x98))(plVar17,*param_3);
      if (plVar17 == (longlong *)0x0) {
        return 1;
      }
      uVar8 = (**(code **)(*plVar17 + 8))(plVar17);
      if (*param_3 != uVar8) {
        return 1;
      }
      FUN_140167920(plVar17,1);
      FUN_14035f2f0(&local_d58);
      uVar15 = (**(code **)(*plVar17 + 8))(plVar17);
      local_10d0 = (ulonglong *)CONCAT44(local_10d0._4_4_,1);
      local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,1);
      iVar13 = FUN_14035f5f0(&local_d58,0x25,uVar15,2);
      if (iVar13 != 0) {
        (**(code **)(plVar17[2] + 0x350))(plVar17 + 2,&local_d58);
      }
      FUN_14035f340(&local_d58);
      return 1;
    }
  }
  if (param_3 == (uint *)0x0) {
    log_InlineLogERROR("cheating program monitor invalid pMsg at %s, %d",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                       ,0x2e0);
    return 1;
  }
  uVar8 = *param_3;
  local_1030 = uVar8;
  if (uVar8 == 0) {
    log_InlineLogERROR("cheating program monitor invalid idUser at %s, %d",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                       ,0x2e7);
    return 1;
  }
  log_InlineLogMessage
            ("cheating program monitor wants to arrest player(idUser:%u) at %s, %d",(ulonglong)uVar8
             ,"f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp",
             0x2ec);
  local_10b8[0] = 0;
  local_10a4 = 0;
  local_10a3 = 0;
  local_10a0 = local_10a0 & 0xffffffffff000000;
  local_10b0 = (longlong *)((ulonglong)local_10b0 & 0xffffffffff000000);
  local_10d8 = (uint **)((longlong)param_3 + 6);
  cVar6 = FUN_140001ce0(local_10b8,&local_10a4,&local_10a0,&local_10b0);
  if (cVar6 == '\0') {
    log_InlineLogERROR("CCheatingProgramMonitor::ExtractLocalTime() failed, at %s, %d",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                       ,0x2f9);
  }
  uVar12 = strtoul((char *)&local_10b0,(char **)0x0,10);
  if ((int)uVar12 < 0) {
    if (5 < (int)uVar12) goto LAB_1400ef09a;
    if (0xb < (int)uVar12) goto LAB_1400ef0be;
    if (0x11 < (int)uVar12) goto LAB_1400ef0e2;
  }
  else {
    if ((int)uVar12 < 6) {
      pIVar21 = theInstance();
      pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS1");
      goto LAB_1400ef119;
    }
LAB_1400ef09a:
    if ((int)uVar12 < 0xc) {
      pIVar21 = theInstance();
      pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS2");
      goto LAB_1400ef119;
    }
LAB_1400ef0be:
    if ((int)uVar12 < 0x12) {
      pIVar21 = theInstance();
      pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS3");
      goto LAB_1400ef119;
    }
LAB_1400ef0e2:
    if ((int)uVar12 < 0x18) {
      pIVar21 = theInstance();
      pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS4");
      goto LAB_1400ef119;
    }
  }
  pIVar21 = theInstance();
  pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS1");
LAB_1400ef119:
  uVar9 = param_3[1];
  local_10d8 = (uint **)((longlong)param_3 + 0xf);
  tq::MyLogSave("gmlog/cheater","Cheater found.  UserID:[%u], cheat type:[%s], subtype:[%s]",
                (ulonglong)uVar8,"_TYPE_CHEATING_SYSTEM");
  local_4d8 = (CIniFile)0x0;
  memset(local_4d7,0,0x3ff);
  local_10c0 = (uint *)CONCAT44(local_10c0._4_4_,(uint)(ushort)uVar9);
  local_10d0 = &local_10a0;
  local_10d8 = (uint **)&local_10a4;
  local_10c8 = (longlong)param_3 + 0xf;
  _snprintf((char *)&local_4d8,0x400,pcVar22,local_10b8);
  local_d9 = 0;
  uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  plVar17 = (longlong *)FUN_140087650(uVar23);
  lVar24 = (**(code **)(*plVar17 + 0x98))(plVar17,uVar8);
  if (lVar24 != 0) {
    iVar13 = (**(code **)(*(longlong *)(lVar24 + 0x10) + 0x168))(lVar24 + 0x10);
    if (iVar13 != 0x1772) {
      FUN_14035cce0(&local_d58);
      iVar13 = FUN_14035cda0(&local_d58,uVar8,&local_4d8);
      if (iVar13 != 0) {
        (**(code **)(*(longlong *)(lVar24 + 0x10) + 0x350))(lVar24 + 0x10,&local_d58);
      }
      pIVar21 = theInstance();
      uVar23 = (*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_GOTO_CHEATJAIL");
      FUN_1401ca920(lVar24,0x1772,uVar23,1);
      FUN_14035cd60(&local_d58);
      return 1;
    }
    return 1;
  }
  _snprintf((char *)&local_d58,0x400,"SELECT  id, recordmap_id FROM cq_user WHERE id = %u LIMIT 1",
            (ulonglong)uVar8);
  local_959 = 0;
  FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  plVar17 = (longlong *)InstanceGet();
  plVar17 = (longlong *)(**(code **)(*plVar17 + 0x10))(plVar17,&local_d58,2);
  if (plVar17 == (longlong *)0x0) {
    log_InlineLogERROR("cheating program monitor wants to arrest player(idUser:%u), bug cant not query db at %s, %d"
                       ,(ulonglong)uVar8,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                       ,0x339);
    return 1;
  }
  lVar24 = (**(code **)(*plVar17 + 0x40))(plVar17);
  if (lVar24 == 0) {
    (**(code **)*plVar17)(plVar17);
    log_InlineLogWARNING
              ("cheating program monitor wants to arrest player(idUser:%u), bug cant not find player at %s, %d"
               ,(ulonglong)uVar8,
               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp",
               0x33f);
    return 1;
  }
  plVar25 = (longlong *)(**(code **)(*plVar17 + 0x20))(plVar17,0);
  iVar13 = (**(code **)(*plVar25 + 0x40))(plVar25);
  plVar25 = (longlong *)(**(code **)(*plVar17 + 0x20))(plVar17,1);
  iVar14 = (**(code **)(*plVar25 + 0x40))(plVar25);
  (**(code **)*plVar17)(plVar17);
  if (iVar13 != 0) {
    if (iVar14 == 0x1772) {
      log_InlineLogERROR("cheating program monitor wants to arrest player(idUser:%u), bug he is already in the map at %s, %d"
                         ,(ulonglong)uVar8,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                         ,0x350);
      return 1;
    }
    uVar23 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    plVar17 = (longlong *)FUN_1400876b0(uVar23);
    lVar24 = (**(code **)(*plVar17 + 0x10))(plVar17,0x1772,1);
    if (lVar24 == 0) {
      local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x358);
      log_InlineLogERROR("cheatingprogram monitor wants to arrest player(idUser:%u), bug cant find map(%u) at %s, %d"
                         ,(ulonglong)uVar8,0x1772,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                        );
      return 1;
    }
    uVar15 = (**(code **)(**(longlong **)(lVar24 + 0x58) + 0x10))(*(longlong **)(lVar24 + 0x58),0xb)
    ;
    local_d8._0_4_ = uVar15;
    uVar16 = (**(code **)(**(longlong **)(lVar24 + 0x58) + 0x10))();
    local_908 = '\0';
    memset(local_907,0,0x3ff);
    local_10c8 = CONCAT44(local_10c8._4_4_,uVar8);
    local_10d0._0_4_ = uVar16;
    local_10d8._0_4_ = uVar15;
    _snprintf(&local_908,0x3ff,
              "UPDATE cq_user SET recordmap_id = %u, recordx = %d, recordy = %d WHERE id = %u LIMIT 1"
              ,0x1772);
    FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    plVar17 = (longlong *)InstanceGet();
    (**(code **)(*plVar17 + 0x30))(plVar17,&local_908,0,1);
    plVar17 = (longlong *)FUN_1400e1de0();
    local_10d0 = (ulonglong *)((ulonglong)local_10d0._4_4_ << 0x20);
    local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,3);
    (**(code **)(*plVar17 + 8))(plVar17,"SYSTEM",uVar8,&local_4d8);
    return 1;
  }
  local_10d8 = (uint **)CONCAT44(local_10d8._4_4_,0x34a);
  log_InlineLogERROR("cheating program monitor wants to arrest player(idUser:%u), bug hes ID is %u at %s, %d"
                     ,(ulonglong)uVar8,0,
                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                    );
  return 1;
switchD_1400ecefa_caseD_34:
  if (param_3 == (uint *)0x0) {
    tq::MyLogSave("gmlog/cheater","GameJailEx failed, pPacket == NULL, at %s, %d",
                  "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                  ,0x548);
    return 0;
  }
  local_10b0 = (longlong *)((ulonglong)local_10b0 & 0xffffffffff000000);
  local_10a0 = param_1 & 0xffffffffff000000;
  local_10a4 = 0;
  local_10a3 = 0;
  local_10b8[0] = 0;
  local_10d8 = (uint **)(param_3 + 3);
  cVar6 = FUN_140001ce0(&local_10b0,&local_10a0,&local_10a4,local_10b8);
  if (cVar6 == '\0') {
    log_InlineLogERROR("CCheatingProgramMonitor::ExtractLocalTime() failed, at %s, %d",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                       ,0x556);
  }
  uVar12 = strtoul((char *)local_10b8,(char **)0x0,10);
  if ((int)uVar12 < 0) {
    if (5 < (int)uVar12) goto LAB_1400eea30;
    if (0xb < (int)uVar12) goto LAB_1400eea54;
    if (0x11 < (int)uVar12) goto LAB_1400eea78;
  }
  else {
    if ((int)uVar12 < 6) {
      pIVar21 = theInstance();
      pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS1");
      goto LAB_1400eeabf;
    }
LAB_1400eea30:
    if ((int)uVar12 < 0xc) {
      pIVar21 = theInstance();
      pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS2");
      goto LAB_1400eeabf;
    }
LAB_1400eea54:
    if ((int)uVar12 < 0x12) {
      pIVar21 = theInstance();
      pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS3");
      goto LAB_1400eeabf;
    }
LAB_1400eea78:
    if ((int)uVar12 < 0x18) {
      pIVar21 = theInstance();
      pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS4");
      goto LAB_1400eeabf;
    }
  }
  pIVar21 = theInstance();
  pcVar22 = (char *)(*(code *)**(undefined8 **)pIVar21)(pIVar21,"STR_USE_NONLICET_TOOLS1");
  log_InlineLogERROR("GameJailEx time(%s) is error.",param_3 + 3);
LAB_1400eeabf:
  local_10d8 = (uint **)((longlong)param_3 + 0x15);
  tq::MyLogSave("gmlog/cheater","Cheater found.  AccountID:[%lu], cheat type:[%s], subtype:[%s]",
                (ulonglong)param_3[1],"_TYPE_CHEATING_SYSTEM");
  local_4d8 = (CIniFile)0x0;
  memset(local_4d7,0,0x3ff);
  local_10c0 = (uint *)CONCAT44(local_10c0._4_4_,param_3[2]);
  local_10d0 = (ulonglong *)&local_10a4;
  local_10d8 = (uint **)&local_10a0;
  local_10c8 = (longlong)param_3 + 0x15;
  _snprintf((char *)&local_4d8,0x400,pcVar22,&local_10b0);
  local_d9 = 0;
  FUN_1400e36a0(param_1,*param_3,param_3[1],&local_4d8);
  return 1;
}

// ==== CWorldKernel::helper_1401629f0  @1401629f0  [medium:callgraph-r1]  (orig: FUN_1401629f0)
undefined8 FUN_1401629f0(longlong *param_1,longlong param_2)

{
  int iVar1;
  longlong lVar2;
  
  iVar1 = (**(code **)(*param_1 + 8))();
  if (*(int *)(param_2 + 4) == iVar1) {
    lVar2 = FUN_14039dc70(param_2,0);
    if (lVar2 != 0) {
      (**(code **)(*(longlong *)param_1[0x222] + 0x20))((longlong *)param_1[0x222],lVar2);
      return 1;
    }
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CWorldKernel::helper_140163560  @140163560  [medium:callgraph-r0]  (orig: FUN_140163560)
void FUN_140163560(longlong *param_1,longlong param_2)

{
  int iVar1;
  longlong lVar2;
  undefined4 uVar3;
  longlong *plVar4;
  
  if (*(char *)(param_2 + 6) == '\x05') {
    plVar4 = (longlong *)FUN_1401182a0();
    iVar1 = *(int *)(param_2 + 0x10);
    lVar2 = *plVar4;
    uVar3 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar2 + 0x10))
              (plVar4,uVar3,*(undefined4 *)(param_2 + 8),*(undefined4 *)(param_2 + 0xc),
               (longlong)iVar1);
  }
  return;
}

// ==== CWorldKernel::helper_140164850  @140164850  [medium:callgraph-r0]  (orig: FUN_140164850)
void FUN_140164850(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x20) = param_2;
  return;
}

// ==== CWorldKernel::helper_140164880  @140164880  [medium:callgraph-r1]  (orig: FUN_140164880)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140164880(longlong *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  FUN_14039e680(local_448);
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  iVar2 = FUN_14039e700(local_448,uVar1,0x22,(longlong)param_2);
  if (iVar2 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_448);
  }
  FUN_14039e6d0(local_448);
  return;
}

// ==== CWorldKernel::helper_140164920  @140164920  [medium:callgraph-r0]  (orig: FUN_140164920)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140164920(longlong param_1,undefined4 param_2)

{
  int iVar1;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  FUN_1403b58f0(local_468);
  iVar1 = FUN_1403b59b0(local_468,1,param_2);
  if (iVar1 != 0) {
    (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_468);
  }
  FUN_1403b5970(local_468);
  return;
}

// ==== CWorldKernel::helper_140164ac0  @140164ac0  [medium:callgraph-r1]  (orig: FUN_140164ac0)
undefined8 FUN_140164ac0(longlong *param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  plVar3 = (longlong *)CurrentInstanceGet();
  if (plVar3 != (longlong *)0x0) {
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,8);
    if (plVar3 != (longlong *)0x0) {
      lVar1 = *plVar3;
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
                    /* WARNING: Could not recover jumptable at 0x000140164b1b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar4 = (**(code **)(lVar1 + 0x128))(plVar3,uVar2);
      return uVar4;
    }
  }
  return 0;
}

// ==== CWorldKernel::helper_140164d90  @140164d90  [medium:callgraph-r1]  (orig: FUN_140164d90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140164d90(longlong *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  FUN_14039e680(local_448);
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  iVar2 = FUN_14039e700(local_448,uVar1,0x21,(longlong)param_2);
  if (iVar2 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_448);
  }
  FUN_14039e6d0(local_448);
  return;
}

// ==== CWorldKernel::helper_140165170  @140165170  [medium:callgraph-r0]  (orig: FUN_140165170)
void FUN_140165170(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x104) = param_2;
  return;
}

// ==== CWorldKernel::helper_1401673b0  @1401673b0  [medium:callgraph-r1]  (orig: FUN_1401673b0)
void FUN_1401673b0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x12f8) = param_2;
  return;
}

// ==== CWorldKernel::helper_140167590  @140167590  [medium:callgraph-r0]  (orig: FUN_140167590)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140167590(longlong *param_1,undefined4 param_2,undefined8 param_3)

{
  longlong lVar1;
  char cVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined4 local_490;
  undefined8 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  FUN_1403b6e00(local_468);
  cVar2 = FUN_1403b6eb0(local_468,param_2,param_3);
  if (cVar2 != '\0') {
    cVar2 = (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
    local_490 = param_2;
    local_488 = param_3;
    if (cVar2 == '\0') {
      lVar1 = param_1[0x1e2];
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      (**(code **)(*param_1 + 8))(param_1);
      local_498 = (int)lVar1;
      tq::MyLogSave("gmlog/IPADPayments",
                    "send web server payments result to client failure, iduser:%u, username:%s, idacount:%u, unAction:%u, szTransactionId:%s"
                   );
    }
    else {
      lVar1 = param_1[0x1e2];
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      (**(code **)(*param_1 + 8))(param_1);
      local_498 = (int)lVar1;
      tq::MyLogSave("gmlog/IPADPayments",
                    "send web server payments result to client succeed, iduser:%u, username:%s, idacount:%u, unAction:%u, szTransactionId:%s"
                   );
    }
  }
  FUN_1403b6e50(local_468);
  return;
}

// ==== CWorldKernel::helper_1401676c0  @1401676c0  [medium:callgraph-r0]  (orig: FUN_1401676c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401676c0(longlong *param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  char cVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  FUN_1403b73e0(local_468);
  cVar2 = FUN_1403b7490(local_468,param_2,param_3);
  if (cVar2 != '\0') {
    cVar2 = (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
    local_490 = param_2;
    local_488 = param_3;
    if (cVar2 == '\0') {
      lVar1 = param_1[0x1e2];
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      (**(code **)(*param_1 + 8))(param_1);
      local_498 = (int)lVar1;
      tq::MyLogSave("gmlog/IPADPayments",
                    "send web server query ipad payments info message to client failure, iduser:[%u], username:[%s], idacount:[%u], CurrentMoney:[%u], ConstraintMoney:[%u]"
                   );
    }
    else {
      lVar1 = param_1[0x1e2];
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      (**(code **)(*param_1 + 8))(param_1);
      local_498 = (int)lVar1;
      tq::MyLogSave("gmlog/IPADPayments",
                    "send web server query ipad payments info message to client succeed, iduser:[%u], username:[%s], idacount:[%u], CurrentMoney:[%u], ConstraintMoney:[%u]"
                   );
    }
  }
  FUN_1403b7430(local_468);
  return;
}

// ==== CWorldKernel::helper_1401677f0  @1401677f0  [medium:callgraph-r0]  (orig: FUN_1401677f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401677f0(longlong *param_1,undefined4 param_2,undefined8 param_3)

{
  longlong lVar1;
  char cVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined4 local_490;
  undefined8 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  FUN_1403b6e00(local_468);
  cVar2 = FUN_1403b6eb0(local_468,param_2,param_3);
  if (cVar2 != '\0') {
    cVar2 = (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
    local_490 = param_2;
    local_488 = param_3;
    if (cVar2 == '\0') {
      lVar1 = param_1[0x1e2];
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      (**(code **)(*param_1 + 8))(param_1);
      local_498 = (int)lVar1;
      tq::MyLogSave("gmlog/GooglePayments",
                    "send web server payments result to client failure, iduser:%u, username:%s, idacount:%u, unAction:%u, szTransactionId:%s"
                   );
    }
    else {
      lVar1 = param_1[0x1e2];
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      (**(code **)(*param_1 + 8))(param_1);
      local_498 = (int)lVar1;
      tq::MyLogSave("gmlog/GooglePayments",
                    "send web server payments result to client succeed, iduser:%u, username:%s, idacount:%u, unAction:%u, szTransactionId:%s"
                   );
    }
  }
  FUN_1403b6e50(local_468);
  return;
}

// ==== CWorldKernel::helper_140167920  @140167920  [medium:callgraph-r0]  (orig: FUN_140167920)
void FUN_140167920(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x12f4) = param_2;
  return;
}

// ==== CWorldKernel::helper_140168db0  @140168db0  [medium:callgraph-r0]  (orig: FUN_140168db0)
void FUN_140168db0(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x135c) = 0;
  *(undefined4 *)(param_1 + 0x1360) = 0;
  *(undefined4 *)(param_1 + 0x1364) = 0;
  *(undefined4 *)(param_1 + 0x1368) = 0;
  return;
}

// ==== CWorldKernel::helper_1401754c0  @1401754c0  [medium:callgraph-r0]  (orig: FUN_1401754c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401754c0(longlong *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  int iVar2;
  undefined4 uVar3;
  ulong uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  undefined1 auStack_8c8 [32];
  undefined8 local_8a8;
  undefined1 local_898 [1072];
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_8a8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_8c8;
  if (((int)param_1[6] == -1) && (param_2 == 0x6b)) {
    *(undefined4 *)(param_1 + 6) = 1;
    DAT_140975954 = DAT_140975954 + 1;
  }
  FUN_140008520((int)param_1[0x246]);
  iVar2 = FUN_14008a6b0();
  if (iVar2 != 0) {
    if (iVar2 == 1) {
      if ((int)param_1[4] == 0) goto LAB_1401756b9;
    }
    else if (iVar2 != 2) goto LAB_1401756b9;
    if (param_2 != 0x6b) {
      if ((int)param_1[6] == 0) {
        iVar2 = *(int *)((longlong)param_1 + 0x2c);
        if (iVar2 == 0) {
          DAT_140975960 = DAT_140975960 + -1;
        }
        else if (iVar2 == 0x32) {
          DAT_14097595c = DAT_14097595c + -1;
        }
        else if (iVar2 == 100) {
          DAT_140975958 = DAT_140975958 + -1;
        }
      }
      uVar5 = 0;
      *(undefined4 *)(param_1 + 6) = 0;
      if (param_2 == 0x68) {
        uVar5 = 0x32;
        *(undefined4 *)((longlong)param_1 + 0x2c) = 0x32;
        DAT_14097595c = DAT_14097595c + 1;
        *(undefined4 *)((longlong)param_1 + 0x1204) = 0x3c;
        uVar4 = tq::TimeGet(0);
        *(uint *)(param_1 + 0x241) = uVar4 / 1000;
      }
      else if (param_2 == 0x69) {
        *(undefined4 *)((longlong)param_1 + 0x2c) = 0;
        DAT_140975960 = DAT_140975960 + 1;
        *(undefined4 *)((longlong)param_1 + 0x1204) = 0x3c;
        uVar4 = tq::TimeGet(0);
        *(uint *)(param_1 + 0x241) = uVar4 / 1000;
      }
      else {
        uVar5 = 100;
        if (param_2 == 0x6a) {
          *(undefined4 *)((longlong)param_1 + 0x2c) = 100;
          DAT_140975958 = DAT_140975958 + 1;
          FUN_14039e680(local_898);
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          iVar2 = FUN_14039e700(local_898,uVar3,0x23,0);
          if (iVar2 != 0) {
            (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_898);
          }
          FUN_14039e6d0(local_898);
        }
      }
      FUN_14039e680(local_468);
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      iVar2 = FUN_14039e700(local_468,uVar3,0x20,uVar5);
      if (iVar2 != 0) {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
      }
      FUN_140164d90(param_1,param_3);
      FUN_140164880(param_1,param_4);
      FUN_14039e6d0(local_468);
    }
  }
LAB_1401756b9:
  if (*(char *)((longlong)param_1 + 0x34) != '\0') {
    plVar6 = (longlong *)CurrentInstanceGet();
    if ((plVar6 != (longlong *)0x0) &&
       (plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0xf), plVar6 != (longlong *)0x0))
    {
      lVar1 = *plVar6;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar1 + 8))(plVar6,uVar5);
    }
    *(undefined1 *)((longlong)param_1 + 0x34) = 0;
  }
  return;
}

// ==== CWorldKernel::helper_140175720  @140175720  [medium:callgraph-r0]  (orig: FUN_140175720)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140175720(longlong *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined1 auStack_488 [32];
  int local_468;
  int local_460;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  iVar1 = FUN_140174650();
  iVar2 = FUN_1401749c0(param_1);
  iVar3 = FUN_140174b80(param_1);
  iVar4 = FUN_140174d40(param_1);
  if ((((0 < iVar1) || (0 < iVar2)) || (0 < iVar3)) || (0 < iVar4)) {
    FUN_14035f2f0(local_448);
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    local_468 = iVar1;
    local_460 = iVar2;
    iVar1 = FUN_14035f5f0(local_448,0x25,uVar5,0);
    if (iVar1 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_448);
    }
    FUN_14035f340(local_448);
  }
  return;
}

// ==== CWorldKernel::helper_140178260  @140178260  [medium:callgraph-r0]  (orig: FUN_140178260)
void FUN_140178260(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  lVar1 = *(longlong *)(lVar1 + 0x100);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1402f0cb0(lVar1,*(undefined4 *)(param_1 + 0x1230),param_1);
  return;
}

// ==== CWorldKernel::helper_1401788f0  @1401788f0  [medium:callgraph-r0]  (orig: FUN_1401788f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401788f0(longlong *param_1)

{
  char cVar1;
  undefined4 uVar2;
  ulong uVar3;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  FUN_1403ee710(local_448);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_1403ee7c0(local_448,0,uVar2);
  if (cVar1 != '\0') {
    (**(code **)(*param_1 + 0x130))(param_1,local_448);
  }
  *(undefined4 *)((longlong)param_1 + 0x12dc) = 10;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x25c) = uVar3 / 1000;
  FUN_1403ee760(local_448);
  return;
}

// ==== CWorldKernel::helper_14017bb90  @14017bb90  [medium:callgraph-r0]  (orig: FUN_14017bb90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14017bb90(longlong *param_1,byte param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined4 local_470;
  undefined4 local_468;
  undefined4 local_460;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if ((*(int *)((longlong)param_1 + 0x135c) != 0) && ((int)param_1[0x26c] != 0)) {
    if (param_2 == 0) {
      FUN_1403ef810(local_448);
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      uVar4 = FUN_140008520((int)param_1[0x246]);
      uVar1 = FUN_14008b420(uVar4);
      local_460 = (undefined4)param_1[0x26d];
      local_468 = *(undefined4 *)((longlong)param_1 + 0x1364);
      local_470 = (undefined4)param_1[0x26c];
      local_478 = *(undefined4 *)((longlong)param_1 + 0x135c);
      iVar2 = FUN_1403ef8c0(local_448,0,uVar1,uVar3);
      if (iVar2 != 0) {
        (**(code **)(*param_1 + 0x130))(param_1,local_448);
      }
      FUN_1403ef860(local_448);
    }
    else if (1 < param_2) {
      if (param_2 < 5) {
        FUN_1403ef810(local_448);
        uVar3 = *(undefined4 *)((longlong)param_1 + 0x12fc);
        uVar1 = (**(code **)(*param_1 + 0x38))(param_1);
        local_460 = (undefined4)param_1[0x26d];
        local_468 = *(undefined4 *)((longlong)param_1 + 0x1364);
        local_470 = (undefined4)param_1[0x26c];
        local_478 = *(undefined4 *)((longlong)param_1 + 0x135c);
        iVar2 = FUN_1403ef8c0(local_448,0,uVar3,uVar1);
        if (iVar2 != 0) {
          (**(code **)(*param_1 + 0x130))(param_1,local_448);
        }
        FUN_1403ef860(local_448);
      }
      else if (param_2 == 5) {
        FUN_1403ef810(local_448);
        uVar3 = *(undefined4 *)((longlong)param_1 + 0x12fc);
        uVar1 = (**(code **)(*param_1 + 0x38))(param_1);
        local_460 = (undefined4)param_1[0x26d];
        local_468 = *(undefined4 *)((longlong)param_1 + 0x1364);
        local_470 = (undefined4)param_1[0x26c];
        local_478 = *(undefined4 *)((longlong)param_1 + 0x135c);
        iVar2 = FUN_1403ef8c0(local_448,1,uVar3,uVar1);
        if (iVar2 != 0) {
          (**(code **)(*param_1 + 0x138))(param_1,local_448,4);
        }
        FUN_1403ef860(local_448);
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_140188cf0  @140188cf0  [medium:callgraph-r1]  (orig: FUN_140188cf0)
undefined8 FUN_140188cf0(longlong *param_1,int param_2,char *param_3)

{
  short sVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  
  if (param_3 == (char *)0x0) {
    return 0;
  }
  uVar6 = FUN_140008520((int)param_1[0x246]);
  iVar4 = FUN_14008a6b0(uVar6);
  if (iVar4 == 0) {
    return 1;
  }
  if (iVar4 == 1) {
    if ((int)param_1[4] == 0) {
      return 1;
    }
  }
  else if (iVar4 != 2) {
    return 1;
  }
  if (*(int *)((longlong)param_1 + 0x2c) != 0) {
    return 1;
  }
  plVar7 = (longlong *)FUN_1400e1e60();
  lVar2 = *plVar7;
  uVar5 = (**(code **)(*param_1 + 8))(param_1);
  iVar4 = (**(code **)(lVar2 + 0xa8))(plVar7,uVar5);
  if (iVar4 != 9) {
    return 1;
  }
  if (param_2 == 0x2715) {
LAB_140188dc0:
    if (param_2 != 0x271a) goto LAB_140188e47;
  }
  else if (param_2 != 0x271a) {
    if (((param_2 != 0x7fc) && (param_2 != 0x3ec)) && (param_2 != 0x3f7)) {
      return 0;
    }
    goto LAB_140188dc0;
  }
  sVar1 = *(short *)(param_3 + 0x10);
  if (sVar1 == 0x89) {
LAB_140188de8:
    if (sVar1 != 0x55) goto LAB_140188e47;
  }
  else if (sVar1 != 0x55) {
    if (sVar1 != 0xb1) {
      return 0;
    }
    goto LAB_140188de8;
  }
  plVar7 = (longlong *)(**(code **)(param_1[2] + 0x160))(param_1 + 2);
  if (plVar7 == (longlong *)0x0) {
    return 0;
  }
  iVar4 = (**(code **)(*plVar7 + 8))(plVar7);
  if (((iVar4 == 0x3ea) || (iVar4 == 0x259)) || (cVar3 = FUN_14016cc60(plVar7), cVar3 != '\0')) {
    FUN_140185db0(param_1);
    return 0;
  }
LAB_140188e47:
  if (((param_2 == 0x7fc) && (*param_3 != '\0')) && (*param_3 != '\x01')) {
    return 0;
  }
  return 1;
}

// ==== CWorldKernel::helper_14018fc20  @14018fc20  [medium:callgraph-r0]  (orig: FUN_14018fc20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14018fc20(longlong *param_1)

{
  char cVar1;
  undefined8 uVar2;
  char *_Source;
  undefined1 auStack_98 [32];
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  char local_60 [16];
  undefined2 local_50;
  undefined2 local_4e;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined1 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined2 local_2c;
  undefined8 local_28;
  undefined4 local_20;
  undefined4 local_1c;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_98;
  local_78 = (**(code **)(*param_1 + 8))();
  local_74 = (**(code **)(*param_1 + 0x38))(param_1);
  local_70 = *(undefined4 *)((longlong)param_1 + 0x12fc);
  local_6c = *(undefined4 *)((longlong)param_1 + 0x122c);
  local_68 = *(undefined4 *)((longlong)param_1 + 0xf04);
  local_64 = FUN_140164ac0(param_1);
  local_4c = (**(code **)(param_1[2] + 0x168))(param_1 + 2);
  local_48 = (undefined4)param_1[0x21b];
  local_44 = *(undefined4 *)((longlong)param_1 + 0x10dc);
  local_50 = (**(code **)(param_1[2] + 0x70))(param_1 + 2);
  local_4e = (**(code **)(*param_1 + 0x108))(param_1);
  local_40 = (**(code **)(param_1[2] + 0x30))(param_1 + 2);
  local_3c = (int)param_1[0x1f8] == 1;
  uVar2 = FUN_140008520((int)param_1[0x246]);
  cVar1 = FUN_14008ab60(uVar2,0xb);
  if (cVar1 == '\0') {
    local_38 = 0;
  }
  else {
    local_38 = (undefined4)param_1[0x20];
  }
  local_34 = *(undefined4 *)((longlong)param_1 + 0xfa4);
  local_30 = FUN_140373290(param_1 + 0x1cf);
  local_1c = FUN_1403732c0(param_1 + 0x1cf);
  local_2c = (undefined2)param_1[0x214];
  local_28 = FUN_140373200(param_1 + 0x1cf);
  local_20 = FUN_14018eb30(param_1);
  _Source = (char *)(**(code **)(param_1[2] + 0x18))(param_1 + 2);
  strncpy(local_60,_Source,0x10);
  uVar2 = FUN_140008520((int)param_1[0x246]);
  FUN_14008a780(uVar2,&local_78);
  return;
}

// ==== CWorldKernel::helper_1401aa210  @1401aa210  [medium:callgraph-r0]  (orig: FUN_1401aa210)
void FUN_1401aa210(longlong param_1,int param_2)

{
  *(int *)(param_1 + 0xa74) = param_2;
  FUN_1401a6420(param_1,0x15,(longlong)param_2,1);
  return;
}

// ==== CWorldKernel::helper_1401ae7f0  @1401ae7f0  [medium:callgraph-r0]  (orig: FUN_1401ae7f0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401ae7f0(longlong *param_1,int param_2,ulong param_3,undefined4 param_4,undefined4 param_5
                  ,uint param_6,int param_7,int param_8)

{
  char cVar1;
  int iVar2;
  ulong uVar3;
  uint uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 uVar8;
  ulonglong uVar9;
  IStringManager *pIVar10;
  char *pcVar11;
  ulong uVar12;
  undefined1 auStack_1398 [32];
  undefined8 local_1378;
  ulong local_1370;
  ulong local_1368;
  undefined4 local_1360;
  undefined4 local_1358;
  ulong local_1350;
  undefined4 local_1348;
  int local_1344;
  ulong local_1340;
  undefined4 local_133c;
  undefined4 local_1338;
  longlong *local_1330;
  undefined8 local_1328;
  undefined4 local_1318;
  char local_1314 [60];
  uint local_12d8;
  char local_12d4 [254];
  undefined1 local_11d6;
  undefined4 local_11d4;
  undefined4 local_11d0;
  undefined4 local_11cc;
  undefined4 local_11c8;
  undefined4 local_11c4;
  undefined1 local_11c0;
  undefined1 local_11b8 [1072];
  char local_d88;
  undefined1 local_d87 [510];
  undefined1 local_b89;
  char local_b88;
  undefined1 local_b87 [1022];
  undefined1 local_789;
  char local_788;
  undefined1 local_787 [1855];
  ulonglong local_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x1401ae806;
  local_1328 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_1398;
  if ((((param_2 != 0) && (0 < (int)param_6)) && (0 < param_7)) && (param_8 == 1)) {
    iVar2 = 0;
    local_133c = 0;
    local_d88 = '\0';
    local_1348 = param_4;
    local_1344 = param_2;
    local_1340 = param_3;
    local_1338 = param_4;
    local_1330 = param_1;
    memset(local_d87,0,0x1ff);
    _snprintf(&local_d88,0x1ff,"SELECT * FROM emoney_card_google WHERE id = %lu AND used=0 LIMIT 1")
    ;
    local_b89 = 0;
    plVar6 = (longlong *)InstanceGet();
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&local_d88,2);
    if (plVar6 != (longlong *)0x0) {
      lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6);
      if (lVar7 == 0) {
        (**(code **)*plVar6)(plVar6);
      }
      else {
        (**(code **)*plVar6)(plVar6);
        if (DAT_140975bb8 != 0) {
          iVar2 = FUN_140276390();
        }
        uVar12 = iVar2 * param_7;
        if (uVar12 == 0) {
          local_1378 = CONCAT44(local_1378._4_4_,param_7);
          log_InlineLogERROR(
                            "OnProcessRechargeResult google failed. AccountID=%lu, RefID=%lu, Type=%u, ItemCount=%d."
                            );
        }
        else {
          local_b88 = '\0';
          memset(local_b87,0,0x3ff);
          uVar3 = tq::TimeStampGet();
          uVar4 = tq::Calc91EmoneyCardChksum(uVar3,param_3,param_6);
          tq::TimeStampGet();
          local_1378 = CONCAT44(local_1378._4_4_,uVar4);
          local_1370 = param_2;
          _snprintf(&local_b88,0x400,
                    "UPDATE emoney_card_google SET used=1, time_stamp=%u, chk_sum=%u WHERE id=%lu LIMIT 1"
                   );
          local_789 = 0;
          FUN_140008520((int)param_1[0x246]);
          plVar6 = (longlong *)InstanceGet();
          cVar1 = (**(code **)(*plVar6 + 0x30))(plVar6,&local_b88,1);
          if (cVar1 == '\0') {
            (**(code **)(*param_1 + 8))(param_1);
            log_InlineLogERROR("CUser::OnProcessRechargeResult, UserID[%lu] UPDATE SQL[%s] fail");
          }
          else {
            local_1378 = 0;
            (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,uVar12,1);
            uVar5 = (**(code **)(*param_1 + 8))(param_1);
            local_1378._0_4_ = uVar12;
            FUN_1401742b0(param_1,6,param_3,uVar5);
            lVar7 = param_1[0x1e2];
            (**(code **)(param_1[2] + 0x18))(param_1 + 2);
            (**(code **)(*param_1 + 8))(param_1);
            local_1358 = param_5;
            local_1360 = local_1348;
            local_1370 = param_2;
            local_1368 = param_3;
            local_1350 = uVar12;
            local_1378._0_4_ = (int)lVar7;
            tq::MyLogSave("gmlog/GooglePayments",
                          "checkout emoney_card_google user_id:%lu, user_name:%s, account_id:%lu, emoneycard_id:%lu, idRef:%lu, flag:%d, systemType:%d, price:%u"
                         );
            uVar8 = FUN_140008520((int)param_1[0x246]);
            cVar1 = FUN_14008a710(uVar8);
            if (cVar1 != '\0') {
              local_788 = '\0';
              memset(local_787,0,0x73f);
              local_1370 = (ulong)param_1[0x25e];
              local_1378._0_4_ = (ulong)param_1[0x1e2];
              local_1368 = uVar12;
              _snprintf(&local_788,0x73f,"[card]: %d,%lu,%d,%u");
              tq::log_Save("gmlog/Card",&local_788,5);
            }
            FUN_14035f2f0(local_11b8);
            uVar5 = (**(code **)(*param_1 + 8))(param_1);
            local_1378 = (ulonglong)local_1378._4_4_ << 0x20;
            local_1370 = uVar12;
            iVar2 = FUN_14035f5f0(local_11b8,0x27,uVar5,1);
            if (iVar2 != 0) {
              (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_11b8);
            }
            FUN_140175810(param_1,uVar12);
            uVar9 = FUN_140373ed0(param_1 + 0x1cf);
            if ((uVar9 & 1) == 0) {
              uVar4 = FUN_140373ed0(param_1 + 0x1cf);
              FUN_1401a6420(param_1,0x47,uVar4 | 3,1);
            }
            uVar8 = FUN_140008520((int)param_1[0x246]);
            uVar8 = FUN_14001b600(uVar8);
            FUN_1400d2660(uVar8,param_1,1,uVar12);
            uVar8 = FUN_140008520((int)param_1[0x246]);
            uVar8 = FUN_14001b600(uVar8);
            FUN_1400d2b30(uVar8,param_1,2,uVar12);
            local_1318 = 0;
            local_1314[0] = '\0';
            local_1314[1] = '\0';
            local_1314[2] = '\0';
            local_1314[3] = '\0';
            local_1314[4] = '\0';
            local_1314[5] = '\0';
            local_1314[6] = '\0';
            local_1314[7] = '\0';
            local_1314[8] = '\0';
            local_1314[9] = '\0';
            local_1314[10] = '\0';
            local_1314[0xb] = '\0';
            local_1314[0xc] = '\0';
            local_1314[0xd] = '\0';
            local_1314[0xe] = '\0';
            local_1314[0xf] = '\0';
            local_1314[0x10] = '\0';
            local_1314[0x11] = '\0';
            local_1314[0x12] = '\0';
            local_1314[0x13] = '\0';
            local_1314[0x14] = '\0';
            local_1314[0x15] = '\0';
            local_1314[0x16] = '\0';
            local_1314[0x17] = '\0';
            local_1314[0x18] = '\0';
            local_1314[0x19] = '\0';
            local_1314[0x1a] = '\0';
            local_1314[0x1b] = '\0';
            local_1314[0x1c] = '\0';
            local_1314[0x1d] = '\0';
            local_1314[0x1e] = '\0';
            local_1314[0x1f] = '\0';
            local_1314[0x20] = '\0';
            local_1314[0x21] = '\0';
            local_1314[0x22] = '\0';
            local_1314[0x23] = '\0';
            local_1314[0x24] = '\0';
            local_1314[0x25] = '\0';
            local_1314[0x26] = '\0';
            local_1314[0x27] = '\0';
            local_1314[0x28] = '\0';
            local_1314[0x29] = '\0';
            local_1314[0x2a] = '\0';
            local_1314[0x2b] = '\0';
            local_1314[0x2c] = '\0';
            local_1314[0x2d] = '\0';
            local_1314[0x2e] = '\0';
            local_1314[0x2f] = '\0';
            local_1314[0x30] = '\0';
            local_1314[0x31] = '\0';
            local_1314[0x32] = '\0';
            local_1314[0x33] = '\0';
            local_1314[0x34] = '\0';
            local_1314[0x35] = '\0';
            local_1314[0x36] = '\0';
            local_1314[0x37] = '\0';
            local_1314[0x38] = '\0';
            local_1314[0x39] = '\0';
            local_1314[0x3a] = '\0';
            local_1314[0x3b] = '\0';
            local_12d8 = 0;
            memset(local_12d4,0,0xff);
            local_11d4 = 0;
            local_11d0 = 0;
            local_11cc = 0;
            local_11c8 = 0;
            local_11c4 = 0x1e;
            local_11c0 = 0;
            local_1318 = (**(code **)(*param_1 + 8))(param_1);
            local_11c4 = 0x1e;
            pIVar10 = theInstance();
            pcVar11 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                        (pIVar10,"STR_RECHARGE_CENTER_NAME");
            strncpy(local_1314,pcVar11,0x10);
            pIVar10 = theInstance();
            pcVar11 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                        (pIVar10,"STR_RECHARGE_SUCCESS_TITLE");
            _snprintf(local_1314 + 0x20,0x20,pcVar11);
            local_12d8 = local_12d8 & 0xffffff;
            pIVar10 = theInstance();
            pcVar11 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                        (pIVar10,"STR_RECHARGE_SUCCESS_CONTENT");
            _snprintf(local_12d4,0xff,pcVar11);
            local_11d6 = 0;
            uVar8 = FUN_140008520((int)param_1[0x246]);
            uVar8 = FUN_14001b5b0(uVar8);
            FUN_1400df9c0(uVar8,&local_1318);
            FUN_14035f340(local_11b8);
          }
        }
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_1401b2610  @1401b2610  [medium:callgraph-r1]  (orig: FUN_1401b2610)
undefined8 FUN_1401b2610(longlong *param_1,longlong param_2)

{
  int iVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined4 local_res8;
  undefined4 local_resc;
  undefined1 local_38 [32];
  
  iVar1 = (**(code **)(*param_1 + 8))();
  if (*(int *)(param_2 + 8) != iVar1) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  plVar3 = (longlong *)
           (**(code **)(*plVar3 + 0x20))
                     (plVar3,param_2,0,0,*(undefined4 *)((longlong)param_1 + 0x12fc),0);
  if (plVar3 != (longlong *)0x0) {
    iVar1 = *(int *)(param_2 + 0x1c);
    if (((0 < iVar1) && (iVar1 < 0x14)) || ((0x14 < iVar1 && (iVar1 < 0x1e)))) {
      plVar4 = (longlong *)FUN_140087d40();
      lVar5 = *plVar4;
      uVar2 = FUN_140337820(param_1,*(undefined4 *)(param_2 + 0x1c));
      lVar5 = (**(code **)(lVar5 + 0x60))(plVar4,uVar2);
      if (lVar5 == 0) {
        local_resc = (**(code **)(*plVar3 + 8))(plVar3);
        local_res8 = *(undefined4 *)(param_2 + 0x1c);
        FUN_1400173d0(param_1 + 0x19f,local_38,&local_res8);
        if (0x13 < *(int *)(param_2 + 0x1c)) {
          return 1;
        }
        uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
        *(undefined4 *)((longlong)param_1 + (longlong)*(int *)(param_2 + 0x1c) * 4 + 0xd94) = uVar2;
        return 1;
      }
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    local_res8 = (**(code **)(*plVar3 + 8))(plVar3);
    FUN_140037fe0(param_1 + 0x181,&local_res8);
    return 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CWorldKernel::helper_1401c2720  @1401c2720  [medium:callgraph-r0]  (orig: FUN_1401c2720)
undefined8 FUN_1401c2720(longlong *param_1,int param_2,undefined8 param_3)

{
  undefined4 uVar1;
  longlong lVar2;
  
  if (param_2 == 1) {
    FUN_1401b2610(param_1,param_3);
    return 1;
  }
  if (param_2 != 4) {
    if (param_2 != 5) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 1;
    }
    lVar2 = FUN_140008520((int)param_1[0x246]);
    lVar2 = *(longlong *)(lVar2 + 0x100);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    FUN_1402f2700(lVar2,uVar1,param_3);
    return 1;
  }
  FUN_1401629f0(param_1,param_3);
  return 1;
}

// ==== CWorldKernel::helper_1401c7af0  @1401c7af0  [medium:callgraph-r0]  (orig: FUN_1401c7af0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1401c7af0(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined8 local_4a8;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  lVar5 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar5 + 0x98) == 0) {
    local_4c8 = 0x131;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x98) + 0x20))
                    (*(longlong **)(lVar5 + 0x98),param_2,1);
  param_1[0x220] = lVar5;
  *(undefined4 *)(param_1 + 0x21b) = param_3;
  *(undefined4 *)((longlong)param_1 + 0x10dc) = param_4;
  FUN_1401783c0(param_1);
  FUN_140362560(local_498);
  uVar2 = (**(code **)(**(longlong **)(param_1[0x220] + 0x58) + 0x10))
                    (*(longlong **)(param_1[0x220] + 0x58),3);
  uVar1 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  local_4b0 = 0;
  local_4c0 = 0x56;
  local_4c8 = CONCAT22(local_4c8._2_2_,uVar1);
  local_4b8 = uVar2;
  iVar4 = FUN_140362620(local_498,uVar3,param_3,param_4);
  if (iVar4 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_498);
  }
  FUN_1401c4e10(param_1,3);
  FUN_1403625e0(local_498);
  return 1;
}

// ==== CWorldKernel::helper_14022d6f0  @14022d6f0  [medium:callgraph-r0]  (orig: FUN_14022d6f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14022d6f0(longlong param_1,int *param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  char cVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined1 auStack_568 [32];
  undefined4 local_548;
  uint local_538;
  longlong *local_530 [3];
  longlong *local_518;
  longlong *local_510;
  undefined8 local_508;
  longlong *local_500;
  longlong local_4f8;
  longlong local_4f0;
  longlong *local_4e8;
  undefined8 local_4d8;
  longlong *local_4d0;
  undefined4 local_4b8;
  undefined2 local_4b4;
  undefined4 local_4b0;
  undefined4 local_4ac;
  undefined4 local_4a8;
  undefined4 local_4a4;
  undefined4 local_4a0;
  undefined1 local_49c;
  undefined4 local_498;
  undefined4 local_494;
  undefined4 local_490;
  undefined4 local_48c;
  undefined4 local_488;
  undefined4 local_484;
  undefined4 local_480;
  undefined4 local_47c;
  undefined4 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_4d8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_568;
  local_4f0 = param_1;
  if (param_2 == (int *)0x0) {
    local_548 = 0x6dc;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar1 = param_2[2];
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    plVar7 = (longlong *)FUN_140087650(uVar6);
    local_4f8 = (**(code **)(*plVar7 + 0x98))(plVar7,iVar1);
    if (local_4f8 != 0) {
      _time64((__time64_t *)0x0);
      local_500 = operator_new(8);
      if (local_500 == (longlong *)0x0) {
        local_530[0] = (longlong *)0x0;
      }
      else {
        *local_500 = (longlong)local_530;
        local_530[0] = local_500;
      }
      local_518 = (longlong *)0x0;
      local_510 = (longlong *)0x0;
      local_508 = 0;
      local_538 = 0;
      plVar9 = (longlong *)0x0;
      plVar7 = plVar9;
      local_4e8 = local_500;
      while ((int)plVar7 < *param_2) {
        local_500 = (longlong *)FUN_14022b140(param_1);
        if ((local_500 != (longlong *)0x0) && (cVar4 = FUN_14041e650(local_500), cVar4 == '\0')) {
          FUN_14022ce90(local_530);
        }
        local_538 = (int)plVar7 + 1;
        plVar7 = (longlong *)(ulonglong)local_538;
      }
      FUN_14041f890(local_468);
      cVar4 = FUN_14041f940(local_468,0,(short)param_2[1],*(undefined2 *)((longlong)param_2 + 0xe));
      plVar7 = local_518;
      if (cVar4 == '\0') {
        FUN_14041f8e0(local_468);
        if (local_518 != (longlong *)0x0) {
          operator_delete(local_518);
        }
        local_518 = (longlong *)0x0;
        local_510 = (longlong *)0x0;
        local_508 = 0;
        operator_delete(local_530[0]);
      }
      else {
        local_4e8 = (longlong *)0x0;
        if (local_510 < local_518) {
          _invalid_parameter_noinfo();
        }
        plVar3 = local_530[0];
        local_4e8 = local_530[0];
        while( true ) {
          plVar10 = local_510;
          local_4d0 = (longlong *)0x0;
          if (local_510 < local_518) {
            _invalid_parameter_noinfo();
          }
          local_4d0 = local_530[0];
          if ((plVar3 == (longlong *)0x0) || (plVar3 != local_530[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar7 == plVar10) break;
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar10 = plVar9;
          }
          else {
            plVar10 = (longlong *)*plVar3;
          }
          if ((longlong *)plVar10[4] <= plVar7) {
            _invalid_parameter_noinfo();
          }
          lVar2 = *plVar7;
          if (lVar2 != 0) {
            plVar10 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_548 = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar10 = plVar9;
            }
            lVar8 = *plVar10;
            uVar5 = FUN_14041e8c0(lVar2);
            lVar8 = (**(code **)(lVar8 + 0x60))(plVar10,uVar5);
            if (lVar8 != 0) {
              local_4b8 = 0;
              local_4b4 = 0;
              local_4b0 = 0;
              local_49c = 1;
              local_498 = 0;
              local_494 = 0;
              local_490 = 0;
              local_48c = 0;
              local_488 = 0;
              local_4ac = 0;
              local_4a8 = 0;
              local_4a4 = 0;
              local_4a0 = 0;
              local_484 = 0;
              local_480 = 0;
              local_47c = 0;
              local_478 = 0;
              cVar4 = FUN_14041f330(lVar2,&local_4b8);
              lVar2 = local_4f8;
              if (cVar4 != '\0') {
                FUN_14022b560(local_4f0,local_4f8,lVar8);
                cVar4 = FUN_14041f9d0(local_468,&local_4b8);
                if (cVar4 == '\0') {
                  (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))
                            ((longlong *)(lVar2 + 0x10),local_468);
                  cVar4 = FUN_14041f940(local_468,0,(short)param_2[1],
                                        *(undefined2 *)((longlong)param_2 + 0xe));
                  if (cVar4 != '\0') {
                    FUN_14041f9d0(local_468,&local_4b8);
                  }
                }
              }
            }
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar10 = plVar9;
          }
          else {
            plVar10 = (longlong *)*plVar3;
          }
          if ((longlong *)plVar10[4] <= plVar7) {
            _invalid_parameter_noinfo();
          }
          plVar7 = plVar7 + 1;
        }
        (**(code **)(*(longlong *)(local_4f8 + 0x10) + 0x350))
                  ((longlong *)(local_4f8 + 0x10),local_468);
        FUN_14041f8e0(local_468);
        if (local_518 != (longlong *)0x0) {
          operator_delete(local_518);
        }
        local_518 = (longlong *)0x0;
        local_510 = (longlong *)0x0;
        local_508 = 0;
        operator_delete(local_530[0]);
      }
    }
  }
  return;
}

// ==== CWorldKernel::helper_1402ac250  @1402ac250  [medium:callgraph-r0]  (orig: FUN_1402ac250)
bool FUN_1402ac250(longlong param_1,uint param_2)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong local_28;
  undefined8 *local_20;
  
  puVar2 = *(undefined8 **)(param_1 + 0x238);
  lVar3 = *(longlong *)(param_1 + 0x208);
  cVar1 = *(char *)((longlong)puVar2[1] + 0x29);
  puVar4 = puVar2;
  puVar7 = (undefined8 *)puVar2[1];
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar4;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar4 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  local_40 = puVar4;
  local_48 = lVar3;
  if (lVar3 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar2) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar6 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x238);
    local_38 = *(longlong *)(param_1 + 0x208);
  }
  else {
    plVar6 = &local_48;
  }
  local_28 = *plVar6;
  local_20 = (undefined8 *)plVar6[1];
  if ((local_28 == 0) || (local_28 != lVar3)) {
    _invalid_parameter_noinfo();
  }
  return local_20 != puVar2;
}

// ==== CWorldKernel::helper_1402af140  @1402af140  [medium:callgraph-r0]  (orig: FUN_1402af140)
bool FUN_1402af140(longlong param_1,ulonglong param_2,uint param_3)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  ulonglong uVar8;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong local_28;
  undefined8 *local_20;
  
  puVar2 = *(undefined8 **)(param_1 + 0x108);
  lVar3 = *(longlong *)(param_1 + 0xd8);
  uVar8 = ((ulonglong)param_3 << 0x20) + (param_2 & 0xffffffff);
  cVar1 = *(char *)((longlong)puVar2[1] + 0x31);
  puVar4 = puVar2;
  puVar7 = (undefined8 *)puVar2[1];
  while (cVar1 == '\0') {
    if ((ulonglong)puVar7[3] < uVar8) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar4;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar4 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x31);
  }
  local_40 = puVar4;
  local_48 = lVar3;
  if (lVar3 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar2) || (uVar8 < (ulonglong)puVar4[3])) {
    plVar6 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x108);
    local_38 = *(longlong *)(param_1 + 0xd8);
  }
  else {
    plVar6 = &local_48;
  }
  local_28 = *plVar6;
  local_20 = (undefined8 *)plVar6[1];
  if ((local_28 == 0) || (local_28 != lVar3)) {
    _invalid_parameter_noinfo();
  }
  return local_20 == puVar2;
}

// ==== CWorldKernel::helper_1402b0840  @1402b0840  [medium:callgraph-r0]  (orig: FUN_1402b0840)
void FUN_1402b0840(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  CMySingleLock local_res8 [8];
  undefined4 local_res10 [6];
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  local_res10[0] = param_2;
  tq::CMySingleLock::CMySingleLock(local_res8,(ILockObj *)&DAT_140975f50);
  FUN_1402af5f0(param_1 + 0x288,local_res10,param_3,param_4,uVar1);
  tq::CMySingleLock::~CMySingleLock(local_res8);
  return;
}

// ==== CWorldKernel::helper_1402b6710  @1402b6710  [medium:callgraph-r1]  (orig: FUN_1402b6710)
undefined8
FUN_1402b6710(longlong param_1,undefined4 param_2,undefined4 param_3,uint param_4,longlong param_5,
             int param_6,undefined4 param_7)

{
  int iVar1;
  void *pvVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  if ((((param_4 == 0) || (param_1 == 0)) || (param_5 == 0)) || (0x400 < param_6)) {
    return 0;
  }
  if (param_4 < 0x524) {
    if (param_4 == 0x523) {
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14035bb80(pvVar2);
      }
    }
    else {
      switch(param_4 - 0x3ec) {
      case 0:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14015b240(pvVar2);
        }
        break;
      default:
        goto LAB_1402b79db;
      case 2:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14044df40(pvVar2);
        }
        break;
      case 4:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140458720(pvVar2);
        }
        break;
      case 5:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1400f83e0(pvVar2);
        }
        break;
      case 8:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403edea0(pvVar2);
        }
        break;
      case 0xb:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14037dfb0(pvVar2);
        }
        break;
      case 0xc:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140456d30(pvVar2);
        }
        break;
      case 0x12:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14035f2f0(pvVar2);
        }
        break;
      case 0x14:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404575b0(pvVar2);
        }
        break;
      case 0x15:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b3fd0(pvVar2);
        }
        break;
      case 0x17:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140456ad0(pvVar2);
        }
        break;
      case 0x18:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404592c0(pvVar2);
        }
        break;
      case 0x1c:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403f0c40(pvVar2);
        }
        break;
      case 0x1d:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403a6980(pvVar2);
        }
        break;
      case 0x20:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b3d40(pvVar2);
        }
        break;
      case 0x21:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140455d00(pvVar2);
        }
        break;
      case 0x22:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404557e0(pvVar2);
        }
        break;
      case 0x23:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140457e30(pvVar2);
        }
        break;
      case 0x24:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14036fe70(pvVar2);
        }
        break;
      case 0x26:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404579b0(pvVar2);
        }
        break;
      case 0x27:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140455550(pvVar2);
        }
        break;
      case 0x28:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403eed30(pvVar2);
        }
        break;
      case 0x29:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14035c460(pvVar2);
        }
        break;
      case 0x2a:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14035bec0(pvVar2);
        }
        break;
      case 0x3e:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14045aff0(pvVar2);
        }
        break;
      case 0x40:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b58f0(pvVar2);
        }
        break;
      case 0x41:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403865d0(pvVar2);
        }
        break;
      case 0x42:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b75b0(pvVar2);
        }
        break;
      case 0x61:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403a5840(pvVar2);
        }
        break;
      case 99:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140456f30(pvVar2);
        }
        break;
      case 100:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403eff70(pvVar2);
        }
        break;
      case 0x65:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140386780(pvVar2);
        }
        break;
      case 0x68:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140387320(pvVar2);
        }
        break;
      case 0x69:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140456560(pvVar2);
        }
        break;
      case 0x6a:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140456380(pvVar2);
        }
        break;
      case 0x6b:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140458b20(pvVar2);
        }
        break;
      case 0x6d:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140455ef0(pvVar2);
        }
        break;
      case 0x7a:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140455a10(pvVar2);
        }
        break;
      case 0x7b:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403f33e0(pvVar2);
        }
        break;
      case 0x7c:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14045a870(pvVar2);
        }
        break;
      case 0x84:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403778c0(pvVar2);
        }
      }
    }
  }
  else if (param_4 < 0x8fd) {
    if (param_4 == 0x8fc) {
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140451580(pvVar2);
      }
    }
    else if (param_4 < 0x7ef) {
      if (param_4 == 0x7ee) {
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140454910(pvVar2);
        }
      }
      else {
        switch(param_4 - 0x528) {
        case 0:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14045a4c0(pvVar2);
          }
          break;
        case 1:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14041f890(pvVar2);
          }
          break;
        case 2:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14041fbd0(pvVar2);
          }
          break;
        case 3:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140454ef0(pvVar2);
          }
          break;
        default:
          goto LAB_1402b79db;
        case 0x1f:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140424690(pvVar2);
          }
          break;
        case 0x23:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14045a260(pvVar2);
          }
        }
      }
    }
    else {
      switch(param_4 - 0x7ef) {
      case 0:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14037d4a0(pvVar2);
        }
        break;
      case 1:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403a6340(pvVar2);
        }
        break;
      default:
LAB_1402b79db:
        return 0;
      case 4:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140454650(pvVar2);
        }
        break;
      case 5:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140453a60(pvVar2);
        }
        break;
      case 0x11:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403f2320(pvVar2);
        }
        break;
      case 0x29:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140452560(pvVar2);
        }
        break;
      case 0x2d:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140452310(pvVar2);
        }
        break;
      case 0x31:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403ee140(pvVar2);
        }
        break;
      case 0x39:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140459f10(pvVar2);
        }
        break;
      case 0x3a:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140459c90(pvVar2);
        }
        break;
      case 0x3b:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404531c0(pvVar2);
        }
        break;
      case 0x3e:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140452b50(pvVar2);
        }
        break;
      case 0x41:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140452f10(pvVar2);
        }
        break;
      case 0x44:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140453510(pvVar2);
        }
        break;
      case 0x4f:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140451eb0(pvVar2);
        }
        break;
      case 0x8c:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140453760(pvVar2);
        }
        break;
      case 0xbd:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403f2a40(pvVar2);
        }
        break;
      case 0xc5:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b6e00(pvVar2);
        }
        break;
      case 0xc6:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404518e0(pvVar2);
        }
        break;
      case 0xe6:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14044e580(pvVar2);
        }
        break;
      case 0xe8:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b73e0(pvVar2);
        }
      }
    }
  }
  else if (param_4 < 0xa29) {
    if (param_4 == 0xa28) {
      pvVar2 = operator_new(0x468);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140450b00(pvVar2);
      }
    }
    else {
      switch(param_4 - 0x906) {
      case 0:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140451200(pvVar2);
        }
        break;
      default:
        goto LAB_1402b79db;
      case 10:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b0410(pvVar2);
        }
        break;
      case 0x5a:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140420930(pvVar2);
        }
        break;
      case 0x5b:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140422f50(pvVar2);
        }
        break;
      case 100:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140423310(pvVar2);
        }
        break;
      case 0x78:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b66d0(pvVar2);
        }
        break;
      case 0x82:
        pvVar2 = operator_new(0x468);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b8560(pvVar2);
        }
        break;
      case 0xdf:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b6340(pvVar2);
        }
        break;
      case 0xe2:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140450dc0(pvVar2);
        }
      }
    }
  }
  else if (param_4 < 0xb55) {
    if (param_4 == 0xb54) {
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14044fb40(pvVar2);
      }
    }
    else {
      switch(param_4 - 0xa32) {
      case 0:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14040a650(pvVar2);
        }
        break;
      default:
        goto LAB_1402b79db;
      case 0x5a:
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140400920(pvVar2);
        }
        break;
      case 0x5c:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140401810(pvVar2);
        }
        break;
      case 0x5d:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404503d0(pvVar2);
        }
        break;
      case 0x5e:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140459ad0(pvVar2);
        }
        break;
      case 0x65:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14035ca70(pvVar2);
        }
        break;
      case 0xbe:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404507d0(pvVar2);
        }
        break;
      case 0xc2:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404500a0(pvVar2);
        }
        break;
      case 0xc3:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404131e0(pvVar2);
        }
        break;
      case 0xc9:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404249a0(pvVar2);
        }
        break;
      case 0xca:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14044f830(pvVar2);
        }
        break;
      case 0xd2:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14042bb20(pvVar2);
        }
        break;
      case 0xd4:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1404598d0(pvVar2);
        }
        break;
      case 0xdc:
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140459630(pvVar2);
        }
      }
    }
  }
  else if (param_4 < 0x271f) {
    if (param_4 == 0x271e) {
      pvVar2 = operator_new(0x448);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14039ed70(pvVar2);
      }
    }
    else if (param_4 == 0xb56) {
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14044fd60(pvVar2);
      }
    }
    else if (param_4 == 0xc80) {
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140413680(pvVar2);
      }
    }
    else if (param_4 == 0x2715) {
      pvVar2 = operator_new(0x478);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403ed0f0(pvVar2);
      }
    }
    else {
      if (param_4 != 0x271a) {
        return 0;
      }
      pvVar2 = operator_new(0x448);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140362560(pvVar2);
      }
    }
  }
  else if (param_4 == 0x2721) {
    pvVar2 = operator_new(0x430);
    if (pvVar2 == (void *)0x0) {
      plVar3 = (longlong *)0x0;
    }
    else {
      plVar3 = (longlong *)FUN_14039e680(pvVar2);
    }
  }
  else if (param_4 == 0x4e21) {
    pvVar2 = operator_new(0x430);
    if (pvVar2 == (void *)0x0) {
      plVar3 = (longlong *)0x0;
    }
    else {
      plVar3 = (longlong *)FUN_14044f280(pvVar2);
    }
  }
  else {
    if (param_4 != 0x4e22) {
      return 0;
    }
    pvVar2 = operator_new(0x430);
    if (pvVar2 == (void *)0x0) {
      plVar3 = (longlong *)0x0;
    }
    else {
      plVar3 = (longlong *)FUN_14044f5d0(pvVar2);
    }
  }
  if (plVar3 == (longlong *)0x0) {
    uVar4 = 0;
  }
  else {
    *(undefined4 *)(plVar3 + 0x82) = param_2;
    *(undefined4 *)((longlong)plVar3 + 0x414) = param_3;
    *(undefined4 *)(plVar3 + 0x83) = 0;
    *(uint *)(plVar3 + 1) = param_4;
    *(int *)((longlong)plVar3 + 0xc) = param_6;
    *(undefined4 *)((longlong)plVar3 + 0x424) = param_7;
    iVar1 = (**(code **)(*plVar3 + 8))(plVar3,param_5,param_6);
    if (iVar1 == 0) {
      (**(code **)*plVar3)(plVar3,1);
      uVar4 = 0;
    }
    else {
      (**(code **)(*plVar3 + 0x18))(plVar3,param_1);
      (**(code **)*plVar3)(plVar3,1);
      uVar4 = 1;
    }
  }
  return uVar4;
}

// ==== CWorldKernel::helper_1402b7ee0  @1402b7ee0  [medium:callgraph-r1]  (orig: FUN_1402b7ee0)
void FUN_1402b7ee0(longlong param_1,undefined4 param_2,undefined4 param_3,uint param_4,
                  longlong param_5,int param_6,undefined4 param_7)

{
  int iVar1;
  void *pvVar2;
  longlong *plVar3;
  
  if (param_4 == 0) {
    return;
  }
  if (((param_1 != 0) && (param_5 != 0)) && (param_6 < 0x401)) {
    if (param_4 < 0x7ef) {
      if (param_4 == 0x7ee) {
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140454910(pvVar2);
        }
      }
      else {
        switch(param_4) {
        case 0x3ea:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14045b790(pvVar2);
          }
          break;
        default:
          goto LAB_1402b881b;
        case 0x3ec:
          pvVar2 = operator_new(0x448);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14015b240(pvVar2);
          }
          break;
        case 0x3ee:
          pvVar2 = operator_new(0x448);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14044df40(pvVar2);
          }
          break;
        case 0x3f0:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140458720(pvVar2);
          }
          break;
        case 0x3f1:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1400f83e0(pvVar2);
          }
          break;
        case 0x3f4:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1403edea0(pvVar2);
          }
          break;
        case 0x3f7:
          pvVar2 = operator_new(0x448);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14037dfb0(pvVar2);
          }
          break;
        case 0x3f8:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140456d30(pvVar2);
          }
          break;
        case 0x3fe:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14035f2f0(pvVar2);
          }
          break;
        case 0x400:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1404575b0(pvVar2);
          }
          break;
        case 0x401:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1403b3fd0(pvVar2);
          }
          break;
        case 0x403:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140456ad0(pvVar2);
          }
          break;
        case 0x404:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1404592c0(pvVar2);
          }
          break;
        case 0x408:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1403f0c40(pvVar2);
          }
          break;
        case 0x40f:
          pvVar2 = operator_new(0x448);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140457e30(pvVar2);
          }
          break;
        case 0x412:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1404579b0(pvVar2);
          }
          break;
        case 0x413:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140455550(pvVar2);
          }
          break;
        case 0x44d:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1403a5840(pvVar2);
          }
          break;
        case 0x44f:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140456f30(pvVar2);
          }
          break;
        case 0x450:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1403eff70(pvVar2);
          }
          break;
        case 0x451:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140386780(pvVar2);
          }
          break;
        case 0x454:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140387320(pvVar2);
          }
          break;
        case 0x455:
          pvVar2 = operator_new(0x448);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140456560(pvVar2);
          }
          break;
        case 0x456:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140456380(pvVar2);
          }
          break;
        case 0x457:
          pvVar2 = operator_new(0x448);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140458b20(pvVar2);
          }
          break;
        case 0x459:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140455ef0(pvVar2);
          }
          break;
        case 0x466:
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140455a10(pvVar2);
          }
        }
      }
    }
    else if (param_4 < 0x911) {
      if (param_4 == 0x910) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b0410(pvVar2);
        }
      }
      else if (param_4 < 0x801) {
        if (param_4 == 0x800) {
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1403f2320(pvVar2);
          }
        }
        else if (param_4 == 0x7ef) {
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14037d4a0(pvVar2);
          }
        }
        else if (param_4 == 0x7f0) {
          pvVar2 = operator_new(0x448);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1403a6340(pvVar2);
          }
        }
        else if (param_4 == 0x7f3) {
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140454650(pvVar2);
          }
        }
        else {
          if (param_4 != 0x7f4) {
            return;
          }
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140453a60(pvVar2);
          }
        }
      }
      else if (param_4 == 0x83e) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140451eb0(pvVar2);
        }
      }
      else if (param_4 == 0x8ac) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403f2a40(pvVar2);
        }
      }
      else if (param_4 == 0x8fc) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140451580(pvVar2);
        }
      }
      else {
        if (param_4 != 0x906) {
          return;
        }
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140451200(pvVar2);
        }
      }
    }
    else if (param_4 < 0x271b) {
      if (param_4 == 0x271a) {
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140362560(pvVar2);
        }
      }
      else if (param_4 == 0x960) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140420930(pvVar2);
        }
      }
      else if (param_4 == 0x961) {
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140422f50(pvVar2);
        }
      }
      else if (param_4 == 0x96a) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140423310(pvVar2);
        }
      }
      else {
        if (param_4 != 0x2715) {
          return;
        }
        pvVar2 = operator_new(0x478);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403ed0f0(pvVar2);
        }
      }
    }
    else if (param_4 == 0x271e) {
      pvVar2 = operator_new(0x448);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14039ed70(pvVar2);
      }
    }
    else if (param_4 == 0x2721) {
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14039e680(pvVar2);
      }
    }
    else if (param_4 == 0x4e21) {
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14044f280(pvVar2);
      }
    }
    else {
      if (param_4 != 0x4e22) {
        return;
      }
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14044f5d0(pvVar2);
      }
    }
    if (plVar3 != (longlong *)0x0) {
      *(undefined4 *)(plVar3 + 0x82) = param_2;
      *(undefined4 *)((longlong)plVar3 + 0x414) = 0xffffffff;
      *(undefined4 *)(plVar3 + 0x83) = param_3;
      *(uint *)(plVar3 + 1) = param_4;
      *(int *)((longlong)plVar3 + 0xc) = param_6;
      *(undefined4 *)((longlong)plVar3 + 0x424) = param_7;
      iVar1 = (**(code **)(*plVar3 + 8))(plVar3,param_5,param_6);
      if (iVar1 != 0) {
        (**(code **)(*plVar3 + 0x18))(plVar3,param_1);
      }
      (**(code **)*plVar3)(plVar3,1);
    }
  }
LAB_1402b881b:
  return;
}

// ==== CWorldKernel::helper_1402b8910  @1402b8910  [medium:callgraph-r1]  (orig: FUN_1402b8910)
undefined8
FUN_1402b8910(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,uint param_5
             ,void *param_6,uint param_7)

{
  void *pvVar1;
  longlong *plVar2;
  
  if ((param_1 == 0) || (param_6 == (void *)0x0)) {
    return 0;
  }
  if ((param_5 == 0) || (0x400 < (int)param_7)) {
    return 0;
  }
  if (param_5 < 0x9c42) {
    if (param_5 == 0x9c41) {
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f39b0(pvVar1);
      }
    }
    else if (param_5 == 0x3ec) {
      pvVar1 = operator_new(0x448);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045e190(pvVar1);
      }
    }
    else if (param_5 == 0x9c7) {
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045f740(pvVar1);
      }
    }
    else if (param_5 == 0x9c8) {
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140449990(pvVar1);
      }
    }
    else if (param_5 == 0x9cb) {
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045fa10(pvVar1);
      }
    }
    else {
      if (param_5 != 0x271a) {
        return 1;
      }
      pvVar1 = operator_new(0x448);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045fbe0(pvVar1);
      }
    }
  }
  else {
    switch(param_5) {
    case 0x9c42:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1402b5280(pvVar1);
      }
      break;
    default:
      goto LAB_1402b8f8e;
    case 0x9c44:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140361e70(pvVar1);
      }
      break;
    case 0x9c45:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f16f0(pvVar1);
      }
      break;
    case 0x9c46:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045da90(pvVar1);
      }
      break;
    case 0x9c48:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045dd90(pvVar1);
      }
      break;
    case 0x9c49:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f0820(pvVar1);
      }
      break;
    case 0x9c4a:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14036ee80(pvVar1);
      }
      break;
    case 0x9c4b:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f1970(pvVar1);
      }
      break;
    case 0x9c4c:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f0130(pvVar1);
      }
      break;
    case 0x9c4d:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403ee710(pvVar1);
      }
      break;
    case 0x9c4e:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f1310(pvVar1);
      }
      break;
    case 0x9c51:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045d6c0(pvVar1);
      }
      break;
    case 0x9c52:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14044ec50(pvVar1);
      }
      break;
    case 0x9c53:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140402260(pvVar1);
      }
      break;
    case 0x9c54:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140401a90(pvVar1);
      }
      break;
    case 0x9c58:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1400f7f70(pvVar1);
      }
      break;
    case 0x9c59:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140370ec0(pvVar1);
      }
      break;
    case 0x9c5a:
      pvVar1 = operator_new(0x438);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045d010(pvVar1);
      }
      break;
    case 0x9c5c:
      pvVar1 = operator_new(0x448);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140433120(pvVar1);
      }
      break;
    case 0x9c60:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045cc80(pvVar1);
      }
      break;
    case 0x9c61:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045c830(pvVar1);
      }
      break;
    case 0x9c62:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045bc40(pvVar1);
      }
      break;
    case 0x9c63:
      pvVar1 = operator_new(0x448);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f36a0(pvVar1);
      }
      break;
    case 0x9c64:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045c670(pvVar1);
      }
      break;
    case 0x9c65:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403ef810(pvVar1);
      }
      break;
    case 0x9c68:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045c010(pvVar1);
      }
      break;
    case 0x9c69:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045c3a0(pvVar1);
      }
      break;
    case 0x9c6a:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045c1d0(pvVar1);
      }
    }
  }
  if (plVar2 != (longlong *)0x0) {
    *(undefined4 *)(plVar2 + 0x82) = param_2;
    *(undefined4 *)((longlong)plVar2 + 0x414) = 0xffffffff;
    *(undefined4 *)(plVar2 + 0x83) = 0;
    *(uint *)(plVar2 + 1) = param_5;
    *(uint *)((longlong)plVar2 + 0xc) = param_7;
    *(undefined4 *)(plVar2 + 0x84) = param_3;
    *(undefined4 *)((longlong)plVar2 + 0x41c) = param_4;
    memmove(plVar2 + 2,param_6,(ulonglong)param_7);
    (**(code **)(*plVar2 + 0x18))(plVar2,param_1);
    (**(code **)*plVar2)(plVar2,1);
  }
LAB_1402b8f8e:
  return 1;
}

// ==== CWorldKernel::helper_1402b9050  @1402b9050  [medium:callgraph-r1]  (orig: FUN_1402b9050)
undefined8
FUN_1402b9050(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,uint param_6,void *param_7,uint param_8)

{
  void *pvVar1;
  longlong *plVar2;
  
  if ((((param_6 == 0) || (param_1 == 0)) || (param_7 == (void *)0x0)) || (0x400 < (int)param_8)) {
    return 0;
  }
  if (param_6 < 0x9c42) {
    if (param_6 == 0x9c41) {
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f39b0(pvVar1);
      }
    }
    else if (param_6 == 0x3ec) {
      pvVar1 = operator_new(0x448);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140461620(pvVar1);
      }
    }
    else if (param_6 == 0x9c7) {
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045f740(pvVar1);
      }
    }
    else if (param_6 == 0x9c8) {
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140449990(pvVar1);
      }
    }
    else {
      if (param_6 != 0x9cb) {
        return 1;
      }
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045fa10(pvVar1);
      }
    }
  }
  else {
    switch(param_6) {
    case 0x9c42:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1402b5280(pvVar1);
      }
      break;
    case 0x9c43:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403ef2a0(pvVar1);
      }
      break;
    case 0x9c44:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140361e70(pvVar1);
      }
      break;
    default:
      goto LAB_1402b964a;
    case 0x9c47:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f1ea0(pvVar1);
      }
      break;
    case 0x9c49:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f0820(pvVar1);
      }
      break;
    case 0x9c4a:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14036ee80(pvVar1);
      }
      break;
    case 0x9c4d:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403ee710(pvVar1);
      }
      break;
    case 0x9c4e:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f1310(pvVar1);
      }
      break;
    case 0x9c52:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14044ec50(pvVar1);
      }
      break;
    case 0x9c55:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140368e20(pvVar1);
      }
      break;
    case 0x9c56:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f04c0(pvVar1);
      }
      break;
    case 0x9c57:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1404612d0(pvVar1);
      }
      break;
    case 0x9c58:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1400f7f70(pvVar1);
      }
      break;
    case 0x9c59:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140370ec0(pvVar1);
      }
      break;
    case 0x9c5c:
      pvVar1 = operator_new(0x448);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140433120(pvVar1);
      }
      break;
    case 0x9c5e:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f0d80(pvVar1);
      }
      break;
    case 0x9c5f:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403ef4f0(pvVar1);
      }
      break;
    case 0x9c65:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403ef810(pvVar1);
      }
      break;
    case 0x9c66:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140460da0(pvVar1);
      }
      break;
    case 0x9c67:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140460a10(pvVar1);
      }
      break;
    case 0x9c69:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14045c3a0(pvVar1);
      }
      break;
    case 0x9c6b:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140460fa0(pvVar1);
      }
      break;
    case 0x9c6c:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_140460630(pvVar1);
      }
      break;
    case 0x9c6d:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403f4080(pvVar1);
      }
      break;
    case 0x9c6e:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_14044f0b0(pvVar1);
      }
      break;
    case 0x9c6f:
      pvVar1 = operator_new(0x430);
      if (pvVar1 == (void *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)FUN_1403ee3f0(pvVar1);
      }
    }
  }
  if (plVar2 != (longlong *)0x0) {
    *(undefined4 *)(plVar2 + 0x82) = param_2;
    *(undefined4 *)((longlong)plVar2 + 0x414) = param_5;
    *(undefined4 *)(plVar2 + 0x83) = 0;
    *(uint *)(plVar2 + 1) = param_6;
    *(uint *)((longlong)plVar2 + 0xc) = param_8;
    *(undefined4 *)(plVar2 + 0x84) = param_3;
    *(undefined4 *)((longlong)plVar2 + 0x41c) = param_4;
    memmove(plVar2 + 2,param_7,(ulonglong)param_8);
    (**(code **)(*plVar2 + 0x18))(plVar2,param_1);
    (**(code **)*plVar2)(plVar2,1);
  }
LAB_1402b964a:
  return 1;
}

// ==== CWorldKernel::helper_1402b9730  @1402b9730  [medium:callgraph-r1]  (orig: FUN_1402b9730)
undefined8
FUN_1402b9730(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,uint param_6,longlong param_7,int param_8)

{
  int iVar1;
  void *pvVar2;
  longlong *plVar3;
  
  if ((((param_6 == 0) || (param_1 == 0)) || (param_7 == 0)) || (0x400 < param_8)) {
    return 0;
  }
  if (param_6 < 0x9c42) {
    if (param_6 == 0x9c41) {
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f39b0(pvVar2);
      }
    }
    else if (param_6 < 0x8d6) {
      if (param_6 == 0x8d5) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14044e580(pvVar2);
        }
      }
      else if (param_6 < 0x3ff) {
        if (param_6 == 0x3fe) {
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14035f2f0(pvVar2);
          }
        }
        else if (param_6 == 0x3ec) {
          pvVar2 = operator_new(0x448);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_140462b90(pvVar2);
          }
        }
        else if (param_6 == 0x3f1) {
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1400f83e0(pvVar2);
          }
        }
        else if (param_6 == 0x3f4) {
          pvVar2 = operator_new(0x430);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_1403edea0(pvVar2);
          }
        }
        else {
          if (param_6 != 0x3f7) {
            return 1;
          }
          pvVar2 = operator_new(0x448);
          if (pvVar2 == (void *)0x0) {
            plVar3 = (longlong *)0x0;
          }
          else {
            plVar3 = (longlong *)FUN_14037dfb0(pvVar2);
          }
        }
      }
      else if (param_6 == 0x410) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14036fe70(pvVar2);
        }
      }
      else if (param_6 == 0x44d) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403a5840(pvVar2);
        }
      }
      else if (param_6 == 0x7ef) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14037d4a0(pvVar2);
        }
      }
      else {
        if (param_6 != 0x7f0) {
          return 1;
        }
        pvVar2 = operator_new(0x448);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403a6340(pvVar2);
        }
      }
    }
    else if (param_6 < 0xa33) {
      if (param_6 == 0xa32) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_14040a650(pvVar2);
        }
      }
      else if (param_6 == 0x96a) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140423310(pvVar2);
        }
      }
      else if (param_6 == 0x9c8) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140449990(pvVar2);
        }
      }
      else if (param_6 == 0x9e5) {
        pvVar2 = operator_new(0x430);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_1403b6340(pvVar2);
        }
      }
      else {
        if (param_6 != 0xa28) {
          return 1;
        }
        pvVar2 = operator_new(0x468);
        if (pvVar2 == (void *)0x0) {
          plVar3 = (longlong *)0x0;
        }
        else {
          plVar3 = (longlong *)FUN_140450b00(pvVar2);
        }
      }
    }
    else if (param_6 == 0xa8c) {
      pvVar2 = operator_new(0x448);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140400920(pvVar2);
      }
    }
    else if (param_6 == 0xafc) {
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14044f830(pvVar2);
      }
    }
    else if (param_6 == 0x2715) {
      pvVar2 = operator_new(0x478);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403ed0f0(pvVar2);
      }
    }
    else {
      if (param_6 != 0x271a) {
        return 1;
      }
      pvVar2 = operator_new(0x448);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140362560(pvVar2);
      }
    }
  }
  else {
    switch(param_6) {
    case 0x9c42:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1402b5280(pvVar2);
      }
      break;
    case 0x9c43:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403ef2a0(pvVar2);
      }
      break;
    case 0x9c44:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140361e70(pvVar2);
      }
      break;
    case 0x9c45:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f16f0(pvVar2);
      }
      break;
    case 0x9c46:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14045da90(pvVar2);
      }
      break;
    case 0x9c47:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f1ea0(pvVar2);
      }
      break;
    case 0x9c48:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14045dd90(pvVar2);
      }
      break;
    case 0x9c49:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f0820(pvVar2);
      }
      break;
    default:
      goto LAB_1402ba0e2;
    case 0x9c4b:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f1970(pvVar2);
      }
      break;
    case 0x9c4c:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f0130(pvVar2);
      }
      break;
    case 0x9c4d:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403ee710(pvVar2);
      }
      break;
    case 0x9c4e:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f1310(pvVar2);
      }
      break;
    case 0x9c50:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403b6940(pvVar2);
      }
      break;
    case 0x9c51:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14045d6c0(pvVar2);
      }
      break;
    case 0x9c52:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14044ec50(pvVar2);
      }
      break;
    case 0x9c53:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140402260(pvVar2);
      }
      break;
    case 0x9c54:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140401a90(pvVar2);
      }
      break;
    case 0x9c55:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140368e20(pvVar2);
      }
      break;
    case 0x9c56:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f04c0(pvVar2);
      }
      break;
    case 0x9c58:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1400f7f70(pvVar2);
      }
      break;
    case 0x9c5a:
      pvVar2 = operator_new(0x438);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14045d010(pvVar2);
      }
      break;
    case 0x9c5c:
      pvVar2 = operator_new(0x448);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140433120(pvVar2);
      }
      break;
    case 0x9c5e:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f0d80(pvVar2);
      }
      break;
    case 0x9c5f:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403ef4f0(pvVar2);
      }
      break;
    case 0x9c60:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_14045cc80(pvVar2);
      }
      break;
    case 0x9c65:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403ef810(pvVar2);
      }
      break;
    case 0x9c6b:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140460fa0(pvVar2);
      }
      break;
    case 0x9c6c:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_140460630(pvVar2);
      }
      break;
    case 0x9c6d:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403f4080(pvVar2);
      }
      break;
    case 0x9c6f:
      pvVar2 = operator_new(0x430);
      if (pvVar2 == (void *)0x0) {
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)FUN_1403ee3f0(pvVar2);
      }
    }
  }
  if (plVar3 != (longlong *)0x0) {
    *(undefined4 *)(plVar3 + 0x82) = param_2;
    *(undefined4 *)((longlong)plVar3 + 0x414) = param_5;
    *(undefined4 *)(plVar3 + 0x83) = 0;
    *(uint *)(plVar3 + 1) = param_6;
    *(int *)((longlong)plVar3 + 0xc) = param_8;
    *(undefined4 *)(plVar3 + 0x84) = param_3;
    *(undefined4 *)((longlong)plVar3 + 0x41c) = param_4;
    iVar1 = (**(code **)(*plVar3 + 8))(plVar3,param_7,param_8);
    if (iVar1 == 0) {
      (**(code **)*plVar3)(plVar3,1);
      return 0;
    }
    (**(code **)(*plVar3 + 0x18))(plVar3,param_1);
    (**(code **)*plVar3)(plVar3,1);
  }
LAB_1402ba0e2:
  return 1;
}

// ==== CWorldKernel::helper_1402c3480  @1402c3480  [medium:callgraph-r1]  (orig: FUN_1402c3480)
undefined1 FUN_1402c3480(longlong param_1)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0xa98;
  *(undefined4 *)(param_1 + 0xc) = 4;
  return 1;
}

// ==== CWorldKernel::helper_1402c34c0  @1402c34c0  [medium:callgraph-r1]  (orig: FUN_1402c34c0)
ulonglong FUN_1402c34c0(longlong param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  ulonglong uVar2;
  
  uVar2 = (longlong)*(int *)(param_1 + 0xc) + 0xc;
  if (0x3ff < uVar2) {
    return uVar2 & 0xffffffffffffff00;
  }
  (*(int **)(param_1 + 0x428))[(longlong)**(int **)(param_1 + 0x428) * 3 + 1] = param_2;
  (*(int **)(param_1 + 0x428))[(longlong)**(int **)(param_1 + 0x428) * 3 + 2] = param_3;
  (*(int **)(param_1 + 0x428))[(longlong)**(int **)(param_1 + 0x428) * 3 + 3] = param_4;
  piVar1 = *(int **)(param_1 + 0x428);
  *piVar1 = *piVar1 + 1;
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0xc;
  return CONCAT71((int7)((ulonglong)piVar1 >> 8),1);
}

// ==== CWorldKernel::helper_1402c3530  @1402c3530  [medium:callgraph-r1]  (orig: FUN_1402c3530)
undefined4 FUN_1402c3530(longlong param_1)

{
  return **(undefined4 **)(param_1 + 0x428);
}

// ==== CWorldKernel::helper_1402cb9e0  @1402cb9e0  [medium:callgraph-r1]  (orig: FUN_1402cb9e0)
void FUN_1402cb9e0(longlong *param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  lVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
  if (*(longlong *)(lVar6 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar7 = (longlong *)(**(code **)(**(longlong **)(lVar6 + 0x88) + 0xd0))();
  plVar1 = (longlong *)*plVar7;
  plVar2 = *(longlong **)plVar7[6];
  do {
    do {
      while( true ) {
        while( true ) {
          plVar9 = plVar2;
          plVar2 = (longlong *)plVar7[6];
          if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*plVar7)) {
            _invalid_parameter_noinfo();
          }
          if (plVar9 == plVar2) {
            return;
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar1;
          }
          if (plVar9 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar6 = plVar9[4];
          if (lVar6 != 0) {
            iVar4 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x168))(lVar6 + 0x10);
            iVar5 = (**(code **)(*param_1 + 8))(param_1);
            if ((((iVar4 == iVar5) &&
                 (iVar4 = (**(code **)(**(longlong **)(lVar6 + 0x60) + 0x10))
                                    (*(longlong **)(lVar6 + 0x60),4), iVar4 == param_2)) &&
                (*(int *)(lVar6 + 0xb4) == 0)) && (cVar3 = FUN_1402bf900(lVar6), cVar3 == '\0')) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar2 = plVar9;
        }
        plVar2 = (longlong *)plVar9[2];
        if (*(char *)((longlong)plVar2 + 0x29) != '\0') break;
        cVar3 = *(char *)(*plVar2 + 0x29);
        plVar9 = (longlong *)*plVar2;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar9 + 0x29);
          plVar2 = plVar9;
          plVar9 = (longlong *)*plVar9;
        }
      }
      plVar2 = (longlong *)plVar9[1];
    } while (*(char *)((longlong)plVar2 + 0x29) != '\0');
    do {
      plVar8 = plVar2;
      plVar2 = plVar8;
      if (plVar9 != (longlong *)plVar8[2]) break;
      plVar2 = (longlong *)plVar8[1];
      plVar9 = plVar8;
    } while (*(char *)((longlong)plVar2 + 0x29) == '\0');
  } while( true );
}

// ==== CWorldKernel::helper_1402cbfe0  @1402cbfe0  [medium:callgraph-r0]  (orig: FUN_1402cbfe0)
void FUN_1402cbfe0(undefined8 param_1,longlong param_2)

{
  undefined4 local_res10 [6];
  
  if (*(short *)(param_2 + 10) != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  local_res10[0] = 0;
  FUN_140368c30(param_2,local_res10);
  FUN_1402cb9e0(param_1,local_res10[0]);
  return;
}

// ==== CWorldKernel::helper_1402ee6c0  @1402ee6c0  [medium:callgraph-r3]  (orig: FUN_1402ee6c0)
undefined8 *
FUN_1402ee6c0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1402eda10(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CWorldKernel::helper_1402ef8e0  @1402ef8e0  [medium:callgraph-r2]  (orig: FUN_1402ef8e0)
longlong * FUN_1402ef8e0(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1402efa3d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1402efa6c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1402efa3d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1402ee6c0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1402efa6c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CWorldKernel::helper_1402f0cb0  @1402f0cb0  [medium:callgraph-r1]  (orig: FUN_1402f0cb0)
undefined8 FUN_1402f0cb0(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  char cVar6;
  uint uVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 uVar10;
  undefined8 *puVar11;
  longlong **pplVar12;
  undefined8 *puVar13;
  longlong *local_58;
  undefined8 *local_50;
  longlong *local_38;
  longlong *plStack_30;
  
  plVar8 = (longlong *)FUN_1404a1950(param_2,param_3);
  if ((plVar8 == (longlong *)0x0) || (cVar6 = FUN_14048f090(plVar8), cVar6 == '\0')) {
    uVar10 = 0;
  }
  else {
    uVar7 = (**(code **)(*plVar8 + 8))(plVar8);
    plVar1 = (longlong *)(param_1 + 0x88);
    puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0xb8))[1];
    cVar6 = *(char *)((longlong)puVar13 + 0x29);
    puVar5 = *(undefined8 **)(param_1 + 0xb8);
    while (cVar6 == '\0') {
      if (*(uint *)(puVar13 + 3) < uVar7) {
        puVar11 = (undefined8 *)puVar13[2];
        puVar13 = puVar5;
      }
      else {
        puVar11 = (undefined8 *)*puVar13;
      }
      puVar5 = puVar13;
      puVar13 = puVar11;
      cVar6 = *(char *)((longlong)puVar11 + 0x29);
    }
    local_50 = puVar5;
    local_58 = (longlong *)*plVar1;
    puVar13 = *(undefined8 **)(param_1 + 0xb8);
    if ((longlong *)*plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar5 == puVar13) || (uVar7 < *(uint *)(puVar5 + 3))) {
      plStack_30 = (longlong *)*(undefined8 *)(param_1 + 0xb8);
      local_38 = (longlong *)*plVar1;
      pplVar12 = &local_38;
    }
    else {
      pplVar12 = &local_58;
    }
    plVar2 = *pplVar12;
    plVar3 = pplVar12[1];
    plVar4 = *(longlong **)(param_1 + 0xb8);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 != plVar4) {
      log_InlineLogERROR(&DAT_140749b48);
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (plVar3 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      puVar13 = (undefined8 *)plVar3[4];
      if (puVar13 != (undefined8 *)0x0) {
        (**(code **)*puVar13)(puVar13,1);
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (plVar3 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar3[4] = 0;
      local_38 = plVar2;
      plStack_30 = plVar3;
      FUN_1402efa90(param_1 + 0x88,&local_58,&local_38);
    }
    local_38 = (longlong *)CONCAT44(local_38._4_4_,uVar7);
    plStack_30 = plVar8;
    FUN_1402ef8e0(param_1 + 0x88,&local_58,&local_38);
    uVar10 = 1;
  }
  return uVar10;
}

// ==== CWorldKernel::helper_1402f2700  @1402f2700  [medium:callgraph-r1]  (orig: FUN_1402f2700)
undefined1 FUN_1402f2700(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  undefined1 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_1402f1610();
  if (lVar2 != 0) {
    uVar1 = FUN_14048f7b0(lVar2,param_3);
    return uVar1;
  }
  return 0;
}

// ==== CWorldKernel::helper_14032a070  @14032a070  [medium:callgraph-r3]  (orig: FUN_14032a070)
void FUN_14032a070(longlong param_1,int param_2,undefined4 param_3,char param_4)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (6 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
  (**(code **)(*plVar1 + 0xb0))(plVar1,param_3);
  if (param_4 != '\0') {
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))(*(longlong **)(param_1 + 0x10),0);
  }
  return;
}

// ==== CWorldKernel::helper_14033cc10  @14033cc10  [medium:callgraph-r3]  (orig: FUN_14033cc10)
void FUN_14033cc10(longlong param_1,int param_2)

{
  longlong *plVar1;
  int *piVar2;
  longlong lVar3;
  int *piVar4;
  int *piVar5;
  int local_res10 [2];
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(param_1 + 0xd38);
    piVar2 = *(int **)(param_1 + 0xd58);
    local_res10[0] = param_2;
    if (piVar2 < *(int **)(param_1 + 0xd50)) {
      _invalid_parameter_noinfo();
    }
    piVar5 = *(int **)(param_1 + 0xd50);
    if (*(int **)(param_1 + 0xd58) < piVar5) {
      _invalid_parameter_noinfo();
    }
    lVar3 = *plVar1;
    piVar4 = *(int **)(param_1 + 0xd58);
    if (piVar4 < *(int **)(param_1 + 0xd50)) {
      _invalid_parameter_noinfo();
    }
    for (; (piVar5 != piVar2 && (*piVar5 != param_2)); piVar5 = piVar5 + 1) {
    }
    if ((lVar3 == 0) || (lVar3 != *plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (piVar5 == piVar4) {
      FUN_140037fe0(plVar1,local_res10);
    }
  }
  return;
}

// ==== CWorldKernel::helper_14035cb20  @14035cb20  [medium:callgraph-r1]  (orig: FUN_14035cb20)
ulonglong FUN_14035cb20(longlong param_1,uint param_2,void *param_3)

{
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    in_RAX = FUN_1402b5600();
    **(uint **)(param_1 + 0x428) = param_2;
    if (param_2 < 0x401) {
      memcpy((void *)(*(longlong *)(param_1 + 0x428) + 4),param_3,(ulonglong)param_2);
      *(uint *)(param_1 + 0xc) = param_2 + 7;
      *(undefined4 *)(param_1 + 8) = 0xa97;
      return CONCAT71((uint7)(uint3)(param_2 + 7 >> 8),1);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CWorldKernel::helper_14035cda0  @14035cda0  [medium:callgraph-r0]  (orig: FUN_14035cda0)
bool FUN_14035cda0(longlong param_1,int param_2,char *param_3)

{
  bool bVar1;
  uint uVar2;
  
  if (param_3 == (char *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","szText",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgcheatingprogram.cpp"
                       ,0x1f);
  }
  else if (param_2 != 0) {
    **(int **)(param_1 + 0x428) = param_2;
    bVar1 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_3);
    *(undefined4 *)(param_1 + 8) = 0x439;
    uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
    *(uint *)(param_1 + 0xc) = uVar2 + 7;
    if (0x400 < (int)(uVar2 + 7)) {
      bVar1 = false;
    }
    return bVar1;
  }
  return false;
}

// ==== CWorldKernel::helper_14035e1b0  @14035e1b0  [medium:callgraph-r3]  (orig: FUN_14035e1b0)
void FUN_14035e1b0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x20);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count_d<_iobuf,FileCloser,std::allocator<int>_>::vftable;
  }
  FUN_14035d8b0(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CWorldKernel::helper_14035e230  @14035e230  [medium:callgraph-r2]  (orig: FUN_14035e230)
longlong * FUN_14035e230(longlong *param_1,longlong *param_2,int *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x1d) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(int *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x1d) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(int *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CWorldKernel::helper_14035e8a0  @14035e8a0  [medium:callgraph-r1]  (orig: FUN_14035e8a0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8
FUN_14035e8a0(longlong param_1,int param_2,undefined4 param_3,uint param_4,undefined8 param_5,
             int param_6)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  longlong *plVar8;
  char *pcVar9;
  undefined8 *puVar10;
  uint local_res20 [2];
  longlong local_80;
  undefined8 *local_78;
  longlong local_70;
  undefined8 local_68;
  longlong local_60;
  undefined8 *local_58;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_50 [40];
  
  puVar2 = *(undefined8 **)(param_1 + 0x58);
  lVar3 = *(longlong *)(param_1 + 0x28);
  cVar1 = *(char *)((longlong)puVar2[1] + 0x1d);
  puVar5 = puVar2;
  puVar10 = (undefined8 *)puVar2[1];
  while (cVar1 == '\0') {
    if (*(int *)(puVar10 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar10[2];
      puVar10 = puVar5;
    }
    else {
      puVar6 = (undefined8 *)*puVar10;
    }
    puVar5 = puVar10;
    puVar10 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x1d);
  }
  local_78 = puVar5;
  local_80 = lVar3;
  local_res20[0] = param_4;
  if (lVar3 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar2) || (param_2 < *(int *)(puVar5 + 3))) {
    local_68 = *(undefined8 *)(param_1 + 0x58);
    local_70 = *(longlong *)(param_1 + 0x28);
    plVar8 = &local_70;
  }
  else {
    plVar8 = &local_80;
  }
  local_60 = *plVar8;
  local_58 = (undefined8 *)plVar8[1];
  if ((local_60 == 0) || (local_60 != lVar3)) {
    _invalid_parameter_noinfo();
  }
  if (local_58 == puVar2) {
    uVar7 = 0;
  }
  else {
    if (*(char *)(param_1 + 0xa8) == '\0') {
      lVar3 = *(longlong *)(param_1 + 0x98);
      lVar4 = *(longlong *)(param_1 + 0x68);
      plVar8 = (longlong *)FUN_14035e230((longlong *)(param_1 + 0x68),&local_60,local_res20);
      if ((*plVar8 == 0) || (*plVar8 != lVar4)) {
        _invalid_parameter_noinfo();
      }
      if (plVar8[1] == lVar3) {
        return 0;
      }
    }
    tq::DumpBuffer((char *)local_50,param_6);
    if (*(ulonglong *)(param_1 + 0x20) < 0x10) {
      pcVar9 = (char *)(param_1 + 8);
    }
    else {
      pcVar9 = *(char **)(param_1 + 8);
    }
    tq::MyLogSave(pcVar9,"User[%u] Msg[%u] Buf[%s]",param_3,(ulonglong)param_4);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_50);
    uVar7 = 1;
  }
  return uVar7;
}

// ==== CWorldKernel::helper_14035ea60  @14035ea60  [medium:callgraph-r3]  (orig: FUN_14035ea60)
longlong * FUN_14035ea60(longlong *param_1,longlong *param_2,int *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  bool bVar7;
  undefined8 *puVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar8 = (undefined8 *)param_1[6];
  bVar7 = true;
  if (*(char *)((longlong)puVar8[1] + 0x1d) == '\0') {
    puVar5 = (undefined8 *)puVar8[1];
    do {
      puVar8 = puVar5;
      bVar7 = *param_3 < *(int *)(puVar8 + 3);
      if (bVar7) {
        puVar5 = (undefined8 *)*puVar8;
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x1d) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar8;
  local_38 = lVar2;
  puVar4 = puVar8;
  if (bVar7 == false) {
LAB_14035ebbd:
    local_30 = puVar4;
    if (*param_3 <= *(int *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14035ebec;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar8;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x1d) == '\0') {
        puVar5 = (undefined8 *)*puVar8;
        if (*(char *)((longlong)puVar5 + 0x1d) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x1d);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x1d);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x1d);
          puVar4 = (undefined8 *)puVar8[1];
          puVar3 = puVar8;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x1d);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x1d) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x1d) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14035ebbd;
    }
    bVar7 = true;
  }
  plVar6 = (longlong *)FUN_14035e340(param_1,&local_38,bVar7,puVar8,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14035ebec:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CWorldKernel::helper_14035ec30  @14035ec30  [medium:callgraph-r3]  (orig: FUN_14035ec30)
void FUN_14035ec30(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14035e680((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CWorldKernel::helper_14035ee90  @14035ee90  [medium:callgraph-r3]  (orig: FUN_14035ee90)
undefined8 * FUN_14035ee90(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14035da80(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x1d) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CWorldKernel::helper_14035ef10  @14035ef10  [medium:callgraph-r2]  (orig: FUN_14035ef10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_14035ef10(basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_1,char *param_2
             ,char *param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  int iVar4;
  FILE *pFVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined1 local_498;
  ulong local_494;
  FILE *local_490;
  longlong *local_488;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_480;
  undefined8 local_478;
  undefined1 local_470 [24];
  undefined1 local_458 [32];
  char local_438 [1024];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_480 = param_1;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_1,param_3);
  FUN_14035ee90(param_1 + 0x28);
  FUN_14035ee90(param_1 + 0x68);
  param_1[0xa8] = (basic_string<char,std::char_traits<char>,std::allocator<char>_>)0x0;
  local_498 = 0;
  pFVar5 = fopen(param_2,"r");
  uVar8 = 0;
  local_490 = (FILE *)0x0;
  local_488 = (longlong *)0x0;
  FUN_14035e1b0(&local_490,pFVar5,0);
  plVar3 = local_488;
  pFVar5 = local_490;
  if (local_490 == (FILE *)0x0) {
    if (local_488 != (longlong *)0x0) {
      LOCK();
      plVar1 = local_488 + 2;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)*plVar1 == 0) {
        (**(code **)*local_488)(local_488);
        LOCK();
        piVar2 = (int *)((longlong)plVar3 + 0x14);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
          (**(code **)(*local_488 + 8))();
        }
      }
    }
  }
  else {
    pcVar6 = fgets(local_438,0x400,local_490);
    uVar7 = uVar8;
    while (pcVar6 != (char *)0x0) {
      uVar8 = uVar8 + 1;
      if (1000000 < uVar8) {
        local_4a8 = 0x1a;
        log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","uLoopCount",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\netmsgtracker.cpp"
                          );
        break;
      }
      if ((local_438[0] != ';') && (local_438[0] != '\n')) {
        iVar4 = _stricmp(local_438,"[AccountID]\n");
        if (iVar4 == 0) {
          uVar7 = 1;
        }
        else {
          iVar4 = _stricmp(local_438,"[MessageType]\n");
          if (iVar4 == 0) {
            uVar7 = 2;
          }
          else {
            local_494 = strtoul(local_438,(char **)0x0,10);
            if (local_494 == 0) {
              if (uVar7 == 2) {
                param_1[0xa8] = (basic_string<char,std::char_traits<char>,std::allocator<char>_>)0x1
                ;
              }
            }
            else if (uVar7 == 1) {
              FUN_14035ea60(param_1 + 0x28,local_458,&local_494);
            }
            else if (uVar7 == 2) {
              FUN_14035ea60(param_1 + 0x68,local_470,&local_494);
            }
          }
        }
      }
      pcVar6 = fgets(local_438,0x400,pFVar5);
    }
    plVar3 = local_488;
    if (local_488 != (longlong *)0x0) {
      LOCK();
      plVar1 = local_488 + 2;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)*plVar1 == 0) {
        (**(code **)*local_488)(local_488);
        LOCK();
        piVar2 = (int *)((longlong)plVar3 + 0x14);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
          (**(code **)(*local_488 + 8))();
        }
      }
    }
  }
  return param_1;
}

// ==== CWorldKernel::helper_14035f190  @14035f190  [medium:callgraph-r1]  (orig: FUN_14035f190)
undefined * FUN_14035f190(void)

{
  undefined8 in_R9;
  
  if ((DAT_140976120 & 1) == 0) {
    DAT_140976120 = DAT_140976120 | 1;
    FUN_14035ef10(&DAT_140976070,"NetMsgTracker.ini","gmlog/NetMsgTrack",in_R9,0xfffffffffffffffe);
    atexit(FUN_1406d6aa0);
  }
  return &DAT_140976070;
}

// ==== CWorldKernel::helper_14035f5f0  @14035f5f0  [medium:callgraph-r0]  (orig: FUN_14035f5f0)
undefined8
FUN_14035f5f0(longlong param_1,short param_2,int param_3,undefined4 param_4,undefined4 param_5,
             undefined4 param_6)

{
  ulong uVar1;
  undefined8 uVar2;
  
  if ((param_2 == 0) || (param_3 == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    FUN_1402b5600();
    *(short *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_2;
    *(int *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_4;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_5;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = param_6;
    uVar1 = tq::TimeGet(0);
    **(ulong **)(param_1 + 0x428) = uVar1;
    *(undefined4 *)(param_1 + 8) = 0x3fe;
    *(undefined4 *)(param_1 + 0xc) = 0x28;
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CWorldKernel::helper_140361d10  @140361d10  [medium:callgraph-r0]  (orig: FUN_140361d10)
undefined8 FUN_140361d10(longlong param_1,undefined4 param_2,char *param_3)

{
  FUN_1402b5600();
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  *(undefined4 *)(param_1 + 8) = 0x9c4f;
  *(undefined4 *)(param_1 + 0xc) = 0x14;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_2;
  strncpy(*(char **)(param_1 + 0x428),param_3,0x10);
  return 1;
}

// ==== CWorldKernel::helper_140362470  @140362470  [medium:callgraph-r0]  (orig: FUN_140362470)
undefined8 FUN_140362470(longlong param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  FUN_1402b5600();
  puVar1 = *(undefined4 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 8) = 0x419;
  *(undefined4 *)(param_1 + 0xc) = 4;
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CWorldKernel::helper_140368610  @140368610  [medium:callgraph-r0]  (orig: FUN_140368610)
ulonglong FUN_140368610(longlong param_1,int param_2)

{
  longlong lVar1;
  ulonglong in_RAX;
  
  if (param_2 == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  *(undefined2 *)(*(longlong *)(param_1 + 0x408) + 2) = 0x3ea;
  **(undefined2 **)(param_1 + 0x408) = 8;
  lVar1 = *(longlong *)(param_1 + 0x408);
  *(int *)(lVar1 + 4) = param_2;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CWorldKernel::helper_140368780  @140368780  [medium:callgraph-r0]  (orig: FUN_140368780)
undefined8 FUN_140368780(longlong param_1,undefined1 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x41a;
  *(undefined4 *)(param_1 + 0xc) = 5;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 1) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CWorldKernel::helper_140368c30  @140368c30  [medium:callgraph-r1]  (orig: FUN_140368c30)
longlong FUN_140368c30(longlong param_1,undefined4 *param_2)

{
  if (*(char *)(param_1 + 0x410) == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    return param_1;
  }
  if ((undefined4 *)(param_1 + 0x10) < (undefined4 *)(*(longlong *)(param_1 + 0x418) + 4)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return param_1;
  }
  *param_2 = *(undefined4 *)(param_1 + 0x10);
  *(longlong *)(param_1 + 0x418) = *(longlong *)(param_1 + 0x418) + 4;
  return param_1;
}

// ==== CWorldKernel::helper_1403b59b0  @1403b59b0  [medium:callgraph-r1]  (orig: FUN_1403b59b0)
undefined8 FUN_1403b59b0(longlong param_1,undefined1 param_2,undefined4 param_3)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0xb;
  *(undefined4 *)(param_1 + 8) = 0x42c;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  return 1;
}

// ==== CWorldKernel::helper_1403b7490  @1403b7490  [medium:callgraph-r1]  (orig: FUN_1403b7490)
undefined8 FUN_1403b7490(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 0x10) = param_3;
  *(undefined4 *)(param_1 + 8) = 0x8d7;
  *(undefined4 *)(param_1 + 0xc) = 0x14;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CWorldKernel::helper_1403ee7c0  @1403ee7c0  [medium:callgraph-r1]  (orig: FUN_1403ee7c0)
undefined8 FUN_1403ee7c0(longlong param_1,undefined2 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c4d;
  *(undefined4 *)(param_1 + 0xc) = 8;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 4) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CWorldKernel::helper_14048f090  @14048f090  [medium:callgraph-r2]  (orig: FUN_14048f090)
undefined8 FUN_14048f090(longlong *param_1)

{
  longlong *plVar1;
  void *pvVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  void *pvVar9;
  longlong lVar10;
  longlong *local_a8 [3];
  void *local_90;
  void *local_88;
  undefined8 local_80;
  longlong *local_78;
  void *local_70;
  undefined4 local_68 [2];
  longlong local_60;
  undefined4 local_58 [2];
  longlong local_50;
  undefined8 local_48;
  undefined1 local_40 [24];
  
  local_48 = 0xfffffffffffffffe;
  if ((*(uint *)(param_1 + 0x38) < 0xe) ||
     ((ulonglong)((DAT_140975c28 - DAT_140975c20) / 0x850) <= (ulonglong)*(uint *)(param_1 + 0x38)))
  {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else if (param_1[0x39] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    local_a8[0] = operator_new(8);
    if (local_a8[0] == (longlong *)0x0) {
      local_a8[0] = (longlong *)0x0;
    }
    else {
      *local_a8[0] = (longlong)local_a8;
    }
    lVar10 = 0;
    local_90 = (void *)0x0;
    local_88 = (void *)0x0;
    local_80 = 0;
    lVar7 = FUN_140008520((int)param_1[0x38]);
    lVar8 = *(longlong *)(lVar7 + 0x170);
    if (*(longlong *)(lVar7 + 0x170) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar10;
    }
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    FUN_140313fc0(lVar8,local_a8,uVar4,0x28);
    pvVar9 = local_90;
    if (local_88 < local_90) {
      _invalid_parameter_noinfo();
    }
    plVar1 = local_a8[0];
    local_78 = local_a8[0];
    while( true ) {
      pvVar2 = local_88;
      local_70 = pvVar9;
      if (local_88 < local_90) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_a8[0])) {
        _invalid_parameter_noinfo();
      }
      if (pvVar9 == pvVar2) break;
      lVar8 = FUN_1404186d0((int)param_1[0x38],0);
      if (lVar8 != 0) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = lVar10;
        }
        else {
          lVar7 = *plVar1;
        }
        if (*(void **)(lVar7 + 0x20) <= pvVar9) {
          _invalid_parameter_noinfo();
        }
        cVar3 = FUN_1404183f0(lVar8);
        if (cVar3 == '\0') {
          FUN_1404183d0(lVar8);
        }
        else {
          iVar5 = FUN_140418c50(lVar8,5);
          if (iVar5 == 0) {
            local_68[0] = FUN_140418430(lVar8);
            local_60 = lVar8;
            FUN_14048d7c0(param_1 + 1,local_40,local_68);
          }
          else {
            iVar5 = FUN_140418c50(lVar8);
            if (iVar5 == 1) {
              local_58[0] = FUN_140418430(lVar8);
              local_50 = lVar8;
              FUN_14048d7c0(param_1 + 9,local_40,local_58);
            }
          }
        }
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar8 = lVar10;
      }
      else {
        lVar8 = *plVar1;
      }
      if (*(void **)(lVar8 + 0x20) <= pvVar9) {
        _invalid_parameter_noinfo();
      }
      pvVar9 = (void *)((longlong)pvVar9 + 8);
    }
    if (local_90 != (void *)0x0) {
      operator_delete(local_90);
    }
    local_90 = (void *)0x0;
    local_88 = (void *)0x0;
    local_80 = 0;
    operator_delete(local_a8[0]);
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CWorldKernel::helper_14048f7b0  @14048f7b0  [medium:callgraph-r2]  (orig: FUN_14048f7b0)
undefined4 FUN_14048f7b0(longlong param_1,undefined4 *param_2)

{
  char cVar1;
  longlong lVar2;
  undefined4 local_38 [2];
  longlong local_30;
  undefined1 local_28 [32];
  
  lVar2 = FUN_1404186d0(*(undefined4 *)(param_1 + 0x1c0),0);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  cVar1 = FUN_140418400(lVar2);
  if (cVar1 == '\0') {
    FUN_1404183d0();
    return 0;
  }
  FUN_140418d90(lVar2,0,*param_2);
  FUN_140418d90(lVar2,1,param_2[1]);
  FUN_140418d90(lVar2,2,param_2[2]);
  FUN_140418d90(lVar2,3,param_2[3]);
  FUN_140418d90(lVar2,4,param_2[4]);
  FUN_140418470(lVar2);
  FUN_1404187b0(lVar2);
  local_38[0] = FUN_140418430(lVar2);
  local_30 = lVar2;
  FUN_14048d7c0(param_1 + 8,local_28,local_38);
  return 1;
}

// ==== CWorldKernel::helper_1404a1950  @1404a1950  [medium:callgraph-r2]  (orig: FUN_1404a1950)
longlong FUN_1404a1950(undefined4 param_1,undefined8 param_2)

{
  void *pvVar1;
  longlong lVar2;
  
  if ((DAT_1409764c8 & 1) == 0) {
    DAT_1409764c8 = DAT_1409764c8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409764c0,"CPlayerMagic");
    atexit((_func_5014 *)&LAB_1406d6ed0);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_1409764c0,0x1d8);
  if (pvVar1 == (void *)0x0) {
    lVar2 = 0;
  }
  else {
    lVar2 = FUN_1404a1760(pvVar1,param_1,param_2);
  }
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pMagic",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\magic\\src\\playermagic.cpp"
                       ,0xa6);
    lVar2 = 0;
  }
  else {
    *(undefined4 *)(lVar2 + 0x1c0) = param_1;
    *(undefined8 *)(lVar2 + 0x1c8) = param_2;
  }
  return lVar2;
}

// ==== CWorldKernel::helper_1406d6aa0  @1406d6aa0  [medium:callgraph-r2]  (orig: FUN_1406d6aa0)
void FUN_1406d6aa0(void)

{
  FUN_14035ec30();
  operator_delete(DAT_1409760d8);
  FUN_14035ec30();
  operator_delete(DAT_140976098);
                    /* WARNING: Could not recover jumptable at 0x0001406d6af6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)&DAT_140976070);
  return;
}

