// ==== CMsgPaint::ctor_or_dtor  @1404f6910  [high:vtable-assign]  (orig: FUN_1404f6910)
undefined8 * FUN_1404f6910(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgPaint::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgPaint::ctor_or_dtor  @1404f6960  [high:vtable-assign]  (orig: FUN_1404f6960)
void FUN_1404f6960(undefined8 *param_1)

{
  *param_1 = CMsgPaint::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgPaint::vfunc_1  @1404f6a10  [high:rtti-vtable]  (orig: FUN_1404f6a10)
ulonglong FUN_1404f6a10(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x8d6);
}

// ==== CMsgPaint::vfunc_3  @1404f6a40  [high:rtti-vtable]  (orig: FUN_1404f6a40)
void FUN_1404f6a40(void)

{
  return;
}

// ==== CMsgPaint::ctor_or_dtor  @1404f6a50  [high:vtable-assign]  (orig: FUN_1404f6a50)
undefined8 * FUN_1404f6a50(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgPaint::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

