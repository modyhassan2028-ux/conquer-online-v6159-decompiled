// ==== CActivityRewardType::helper_1404252f0  @1404252f0  [medium:callgraph-r0]  (orig: FUN_1404252f0)
void FUN_1404252f0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  
  uVar9 = 0xfffffffffffffffe;
  plVar6 = *(longlong **)param_1[7];
  plVar2 = (longlong *)param_1[1];
  plVar10 = plVar2;
  plVar11 = plVar6;
  while( true ) {
    plVar7 = (longlong *)param_1[7];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[1])) {
      _invalid_parameter_noinfo();
    }
    if (plVar6 == plVar7) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = (longlong *)plVar6[7];
    if ((longlong *)plVar6[8] < plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar3 = (longlong *)plVar6[4];
    while( true ) {
      plVar4 = (longlong *)plVar6[8];
      if (plVar4 < (longlong *)plVar6[7]) {
        _invalid_parameter_noinfo();
      }
      if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)plVar6[4])) {
        _invalid_parameter_noinfo();
      }
      if (plVar7 == plVar4) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar8 = 0;
      }
      else {
        lVar8 = *plVar3;
      }
      if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
        _invalid_parameter_noinfo();
      }
      puVar5 = (undefined8 *)*plVar7;
      if (puVar5 != (undefined8 *)0x0) {
        (**(code **)*puVar5)(puVar5,1);
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar8 = 0;
      }
      else {
        lVar8 = *plVar3;
      }
      if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
        _invalid_parameter_noinfo();
      }
      plVar7 = plVar7 + 1;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x51) == '\0') {
      plVar11 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar11 + 0x51) == '\0') {
        cVar1 = *(char *)(*plVar11 + 0x51);
        plVar6 = plVar11;
        plVar7 = (longlong *)*plVar11;
        while (plVar11 = plVar6, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar7 + 0x51);
          plVar6 = plVar7;
          plVar7 = (longlong *)*plVar7;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x51);
        plVar11 = (longlong *)plVar6[1];
        plVar7 = plVar6;
        while ((plVar6 = plVar11, plVar11 = plVar6, cVar1 == '\0' &&
               (plVar7 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x51);
          plVar11 = (longlong *)plVar6[1];
          plVar7 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  FUN_140269f10(param_1 + 1,*(undefined8 *)(param_1[7] + 8),param_3,param_4,uVar9,plVar10,plVar11);
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CActivityRewardType::ctor_or_dtor  @140425520  [high:vtable-assign]  (orig: FUN_140425520)
void FUN_140425520(undefined8 *param_1)

{
  *param_1 = CActivityRewardType::vftable;
  FUN_14026a6f0(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CActivityRewardType::ctor_or_dtor  @140425560  [high:vtable-assign]  (orig: FUN_140425560)
undefined8 * FUN_140425560(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CActivityRewardType::vftable;
  FUN_14026a890(param_1 + 1);
  *(undefined4 *)(param_1 + 9) = param_2;
  return param_1;
}

// ==== CActivityRewardType::ctor_or_dtor  @1404255b0  [high:vtable-assign]  (orig: FUN_1404255b0)
undefined8 * FUN_1404255b0(undefined8 *param_1,uint param_2)

{
  *param_1 = CActivityRewardType::vftable;
  FUN_14026a6f0(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CActivityRewardType::ctor_or_dtor  @140425620  [high:vtable-assign]  (orig: FUN_140425620)
undefined8 * FUN_140425620(undefined4 param_1)

{
  char cVar1;
  undefined8 *puVar2;
  
  puVar2 = operator_new(0x50);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CActivityRewardType::vftable;
    FUN_14026a890(puVar2 + 1);
    *(undefined4 *)(puVar2 + 9) = param_1;
  }
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_140425020(puVar2);
    if (cVar1 == '\0') {
      FUN_1404252f0(puVar2);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

