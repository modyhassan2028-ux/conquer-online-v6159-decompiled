// ==== CMsgWeaponSkill::ctor_or_dtor  @1403b3fd0  [high:vtable-assign]  (orig: FUN_1403b3fd0)
undefined8 * FUN_1403b3fd0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgWeaponSkill::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgWeaponSkill::ctor_or_dtor  @1403b4020  [high:vtable-assign]  (orig: FUN_1403b4020)
void FUN_1403b4020(undefined8 *param_1)

{
  *param_1 = CMsgWeaponSkill::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgWeaponSkill::vfunc_1  @1403b4050  [high:rtti-vtable]  (orig: FUN_1403b4050)
ulonglong FUN_1403b4050(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x401);
}

// ==== CMsgWeaponSkill::vfunc_3  @1403b4100  [high:rtti-vtable]  (orig: FUN_1403b4100)
void FUN_1403b4100(void)

{
  return;
}

// ==== CMsgWeaponSkill::ctor_or_dtor  @1403b4110  [high:vtable-assign]  (orig: FUN_1403b4110)
undefined8 * FUN_1403b4110(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgWeaponSkill::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

