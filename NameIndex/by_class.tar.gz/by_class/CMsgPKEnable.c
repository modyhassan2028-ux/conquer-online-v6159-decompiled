// ==== CMsgPKEnable::ctor_or_dtor  @1404d9d80  [high:vtable-assign]  (orig: FUN_1404d9d80)
undefined8 * FUN_1404d9d80(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgPKEnable::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgPKEnable::vfunc_1  @1404d9dd0  [high:rtti-vtable]  (orig: FUN_1404d9dd0)
ulonglong FUN_1404d9dd0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x8ad);
}

// ==== CMsgPKEnable::vfunc_0  @1404d9e60  [high:rtti-vtable]  (orig: FUN_1404d9e60)
void * FUN_1404d9e60(void *param_1,uint param_2)

{
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

