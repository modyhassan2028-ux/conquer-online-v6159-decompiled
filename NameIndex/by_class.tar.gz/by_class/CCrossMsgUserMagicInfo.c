// ==== CCrossMsgUserMagicInfo::helper_1402f1bb0  @1402f1bb0  [medium:callgraph-r0]  (orig: FUN_1402f1bb0)
void FUN_1402f1bb0(undefined8 param_1,undefined8 param_2,int param_3,undefined4 param_4,
                  undefined4 param_5,undefined2 param_6,undefined2 param_7,undefined4 param_8,
                  undefined1 param_9,undefined2 param_10,undefined1 param_11,undefined4 param_12,
                  undefined1 param_13)

{
  longlong lVar1;
  
  lVar1 = FUN_1402f1610();
  if ((lVar1 != 0) && (param_3 == 0)) {
    FUN_140490ed0(lVar1,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,param_12,
                  param_13);
  }
  return;
}

// ==== CCrossMsgUserMagicInfo::helper_140418470  @140418470  [medium:callgraph-r2]  (orig: FUN_140418470)
void FUN_140418470(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140418477. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 8) + 0x58))();
  return;
}

// ==== CCrossMsgUserMagicInfo::ctor_or_dtor  @14045dd90  [high:vtable-assign]  (orig: FUN_14045dd90)
undefined8 * FUN_14045dd90(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgUserMagicInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgUserMagicInfo::ctor_or_dtor  @14045dde0  [high:vtable-assign]  (orig: FUN_14045dde0)
void FUN_14045dde0(undefined8 *param_1)

{
  *param_1 = CCrossMsgUserMagicInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgUserMagicInfo::vfunc_1  @14045de10  [high:rtti-vtable]  (orig: FUN_14045de10)
ulonglong FUN_14045de10(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c48);
}

// ==== CCrossMsgUserMagicInfo::ctor_or_dtor  @14045dfa0  [high:vtable-assign]  (orig: FUN_14045dfa0)
undefined8 * FUN_14045dfa0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgUserMagicInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgUserMagicInfo::vfunc_3  @14045dff0  [high:rtti-vtable]  (orig: FUN_14045dff0)
void FUN_14045dff0(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  uint uVar7;
  
  iVar4 = **(int **)(param_1 + 0x428);
  if ((*(int **)(param_1 + 0x428))[1] == 0) {
    uVar1 = *(undefined4 *)(param_1 + 0x420);
    uVar2 = *(undefined4 *)(param_1 + 0x41c);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar5 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    iVar4 = FUN_1402aef00(*(undefined8 *)(lVar5 + 0x90),uVar2,uVar1);
    if (iVar4 == 0) {
      log_InlineLogOSWARNING
                (
                "CCrossMsgUserMagicInfo::Process UserManager GetNewUserID failed. server id:%u, os user id:%u."
                );
      return;
    }
  }
  uVar7 = 0;
  if (*(int *)(*(longlong *)(param_1 + 0x428) + 8) != 0) {
    lVar5 = 0;
    do {
      lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar6 = *(longlong *)(lVar6 + 0x100);
      if (lVar6 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar6 = 0;
      }
      lVar3 = *(longlong *)(param_1 + 0x428);
      FUN_1402f1bb0(lVar6,iVar4,*(undefined4 *)(lVar3 + 4),*(undefined4 *)(lVar5 + 0xc + lVar3),
                    *(undefined4 *)(lVar5 + 0x10 + lVar3),*(undefined2 *)(lVar5 + 0x14 + lVar3),
                    *(undefined2 *)(lVar5 + 0x16 + lVar3),*(undefined4 *)(lVar5 + 0x18 + lVar3),
                    *(undefined1 *)(lVar5 + 0x1c + lVar3),*(undefined2 *)(lVar5 + 0x1e + lVar3),
                    *(undefined1 *)(lVar5 + 0x20 + lVar3),*(undefined4 *)(lVar5 + 0x24 + lVar3),
                    *(undefined1 *)(lVar5 + 0x28 + lVar3));
      uVar7 = uVar7 + 1;
      lVar5 = lVar5 + 0x20;
    } while (uVar7 < *(uint *)(*(longlong *)(param_1 + 0x428) + 8));
  }
  return;
}

// ==== CCrossMsgUserMagicInfo::helper_14048dd30  @14048dd30  [medium:callgraph-r2]  (orig: FUN_14048dd30)
longlong * FUN_14048dd30(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CCrossMsgUserMagicInfo::helper_14048e920  @14048e920  [medium:callgraph-r3]  (orig: FUN_14048e920)
undefined8 * FUN_14048e920(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1404898e0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_1404898e0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1404898e0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_1404898e0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_1404898e0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_1404898e0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1404898e0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_14048d7c0(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CCrossMsgUserMagicInfo::helper_1404908f0  @1404908f0  [medium:callgraph-r2]  (orig: FUN_1404908f0)
undefined8 * FUN_1404908f0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_14048e920(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CCrossMsgUserMagicInfo::helper_140490ed0  @140490ed0  [medium:callgraph-r1]  (orig: FUN_140490ed0)
undefined8
FUN_140490ed0(longlong param_1,int param_2,undefined4 param_3,undefined2 param_4,undefined2 param_5,
             undefined4 param_6,undefined1 param_7,undefined2 param_8,undefined1 param_9,
             undefined4 param_10,undefined1 param_11)

{
  int iVar1;
  char cVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong lVar5;
  int local_res10 [2];
  undefined4 local_res18;
  longlong *local_50;
  longlong local_48;
  
  local_res10[0] = param_2;
  if ((param_2 != -0x5a915ff) && (param_2 != -0x5a915fe)) {
    local_res10[0] = *(int *)(param_1 + 0xf0);
    *(int *)(param_1 + 0xf0) = local_res10[0] + 1;
  }
  iVar1 = local_res10[0];
  local_res18 = param_3;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x1c0));
  lVar3 = *(longlong *)(lVar3 + 0x100);
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = 0;
  }
  lVar5 = 0;
  lVar3 = FUN_1402f0fe0(lVar3,param_4,param_5);
  if (lVar3 == 0) {
    FUN_140167b50(*(undefined8 *)(param_1 + 0x1c8));
    FUN_140167b40(*(undefined8 *)(param_1 + 0x1c8));
    log_InlineLogERROR(
                      "CPlayerMagic::AddOtherServerMagic can\'t find magic,type[%d],lev[%d],idOwner[%u],Serverid[%u], SrcOServerid[%u]"
                      );
    return 0;
  }
  FUN_14048dd30(param_1 + 8,&local_50,local_res10);
  lVar3 = *(longlong *)(param_1 + 0x38);
  if ((local_50 == (longlong *)0x0) || (local_50 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  if (local_48 == lVar3) {
    lVar3 = FUN_1404186d0(*(undefined4 *)(param_1 + 0x1c0),1);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    cVar2 = FUN_140418400(lVar3);
    if (cVar2 == '\0') {
      log_InlineLogOSERROR("CPlayerMagic::AddOtherServerMagic CreateNewRecord failed.");
      FUN_1404183d0(lVar3);
      return 0;
    }
    FUN_140418d90(lVar3,0,iVar1);
    FUN_140418d90(lVar3,1,local_res18);
    FUN_140418d90(lVar3,2,param_4);
    FUN_140418d90(lVar3,3,param_5);
    FUN_140418d90(lVar3,4,param_6);
    FUN_140418d90(lVar3,5,param_7);
    FUN_140418d90(lVar3,6,param_8);
    FUN_140418d90(lVar3,7,param_9);
    FUN_140418f20(lVar3,8,param_10);
    FUN_1404184e0(lVar3,param_11);
    FUN_140418470(lVar3);
    plVar4 = (longlong *)FUN_1404908f0(param_1 + 8,local_res10);
    *plVar4 = lVar3;
  }
  else {
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(local_48 + 0x20) == 0) {
      return 0;
    }
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140418d90(*(undefined8 *)(local_48 + 0x20),1,local_res18);
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140418d90(*(undefined8 *)(local_48 + 0x20),2,param_4);
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140418d90(*(undefined8 *)(local_48 + 0x20),3,param_5);
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140418d90(*(undefined8 *)(local_48 + 0x20),4,param_6);
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140418d90(*(undefined8 *)(local_48 + 0x20),5,param_7);
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140418d90(*(undefined8 *)(local_48 + 0x20),6,param_8);
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140418d90(*(undefined8 *)(local_48 + 0x20),7,param_9);
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140418f20(*(undefined8 *)(local_48 + 0x20),8,param_10);
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar5;
    }
    else {
      lVar3 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_1404184e0(*(undefined8 *)(local_48 + 0x20),param_11);
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar5 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140418470(*(undefined8 *)(local_48 + 0x20));
  }
  return 1;
}

