// ==== CThreadRecordPtrMgr::ctor_or_dtor  @14002e140  [high:vtable-assign]  (orig: FUN_14002e140)
void FUN_14002e140(undefined8 *param_1)

{
  *param_1 = CThreadRecordPtrMgr::vftable;
  FUN_14002d220();
  *(undefined ***)(param_1 + 10) = CCriticalSection::vftable;
  DeleteCriticalSection((LPCRITICAL_SECTION)(param_1 + 0xc));
  CSyncObject::~CSyncObject((CSyncObject *)(param_1 + 10));
  FUN_14002de90(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CThreadRecordPtrMgr::ctor_or_dtor  @14002e240  [high:vtable-assign]  (orig: FUN_14002e240)
undefined8 * FUN_14002e240(undefined8 *param_1)

{
  CSyncObject *this;
  int iVar1;
  
  *param_1 = CThreadRecordPtrMgr::vftable;
  FUN_14002e1c0(param_1 + 2);
  this = (CSyncObject *)(param_1 + 10);
  CSyncObject::CSyncObject(this,(char *)0x0);
  *(undefined ***)this = CCriticalSection::vftable;
  iVar1 = CCriticalSection::Init((CCriticalSection *)this);
  if (iVar1 == 0) {
    AfxThrowMemoryException();
  }
  *(undefined4 *)((longlong)param_1 + 0xc) = 1;
  *(undefined4 *)(param_1 + 0x11) = 1;
  *(undefined1 *)((longlong)param_1 + 0x8c) = 0;
  return param_1;
}

// ==== CThreadRecordPtrMgr::vfunc_0  @14002e2d0  [high:rtti-vtable]  (orig: FUN_14002e2d0)
void * FUN_14002e2d0(void *param_1,uint param_2)

{
  FUN_14002e140();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CThreadRecordPtrMgr::ctor_or_dtor  @14002e300  [high:vtable-assign]  (orig: FUN_14002e300)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14002e300(void)

{
  int iVar1;
  
  if (DAT_1409759e8 == (undefined *)0x0) {
    if ((DAT_140975a80 & 1) == 0) {
      DAT_140975a80 = DAT_140975a80 | 1;
      _DAT_1409759f0 = CThreadRecordPtrMgr::vftable;
      FUN_14002e1c0(&DAT_140975a00);
      CSyncObject::CSyncObject((CSyncObject *)&DAT_140975a40,(char *)0x0);
      _DAT_140975a40 = CCriticalSection::vftable;
      iVar1 = CCriticalSection::Init((CCriticalSection *)&DAT_140975a40);
      if (iVar1 == 0) {
        AfxThrowMemoryException();
      }
      _DAT_1409759fc = 1;
      _DAT_140975a78 = 1;
      DAT_140975a7c = 0;
      atexit(FUN_1406d6520);
    }
    DAT_1409759e8 = &DAT_1409759f0;
  }
  return;
}

// ==== CThreadRecordPtrMgr::ctor_or_dtor  @1406d6520  [high:vtable-assign]  (orig: FUN_1406d6520)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1406d6520(void)

{
  _DAT_1409759f0 = CThreadRecordPtrMgr::vftable;
  FUN_14002d220(&DAT_1409759f0);
  _DAT_140975a40 = CCriticalSection::vftable;
  DeleteCriticalSection((LPCRITICAL_SECTION)&DAT_140975a50);
  CSyncObject::~CSyncObject((CSyncObject *)&DAT_140975a40);
  FUN_14002de90();
  operator_delete(DAT_140975a00);
  return;
}

