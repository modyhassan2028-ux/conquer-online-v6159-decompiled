// ==== CAchInfo::ctor_or_dtor  @140376800  [high:vtable-assign]  (orig: FUN_140376800)
void FUN_140376800(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  *param_1 = CAchInfo::vftable;
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CAchInfo::helper_140377020  @140377020  [medium:callgraph-r0]  (orig: FUN_140377020)
void FUN_140377020(void *param_1)

{
  if ((DAT_140976160 & 1) == 0) {
    DAT_140976160 = DAT_140976160 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976158,"CAchInfo");
    atexit((_func_5014 *)&LAB_1406d6b30);
  }
                    /* WARNING: Could not recover jumptable at 0x000140377075. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976158,param_1);
  return;
}

// ==== CAchInfo::ctor_or_dtor  @1403770e0  [high:vtable-assign]  (orig: FUN_1403770e0)
undefined8 * FUN_1403770e0(undefined8 *param_1)

{
  *param_1 = CAchInfo::vftable;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  param_1[5] = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  *(undefined1 *)(param_1 + 3) = 0;
  return param_1;
}

// ==== CAchInfo::ctor_or_dtor  @140377110  [high:vtable-assign]  (orig: FUN_140377110)
undefined8 * FUN_140377110(undefined8 *param_1,uint param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CAchInfo::vftable;
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  if ((param_2 & 1) != 0) {
    FUN_140377020(param_1);
  }
  return param_1;
}

