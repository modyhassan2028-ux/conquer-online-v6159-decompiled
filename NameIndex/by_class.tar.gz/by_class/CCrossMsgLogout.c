// ==== CCrossMsgLogout::helper_140178b80  @140178b80  [medium:callgraph-r0]  (orig: FUN_140178b80)
bool FUN_140178b80(longlong param_1)

{
  return *(int *)(param_1 + 0x12e0) != 0;
}

// ==== CCrossMsgLogout::helper_140178b90  @140178b90  [medium:callgraph-r0]  (orig: FUN_140178b90)
void FUN_140178b90(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x12e0) = 0;
  *(undefined4 *)(param_1 + 0x12dc) = 0;
  return;
}

// ==== CCrossMsgLogout::ctor_or_dtor  @1403ee710  [high:vtable-assign]  (orig: FUN_1403ee710)
undefined8 * FUN_1403ee710(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLogout::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLogout::ctor_or_dtor  @1403ee760  [high:vtable-assign]  (orig: FUN_1403ee760)
void FUN_1403ee760(undefined8 *param_1)

{
  *param_1 = CCrossMsgLogout::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLogout::vfunc_1  @1403ee790  [high:rtti-vtable]  (orig: FUN_1403ee790)
undefined8 FUN_1403ee790(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLogout::ctor_or_dtor  @1403ee820  [high:vtable-assign]  (orig: FUN_1403ee820)
undefined8 * FUN_1403ee820(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLogout::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgLogout::ctor_or_dtor  @1403ee870  [high:vtable-assign]  (orig: FUN_1403ee870)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403ee870(longlong param_1)

{
  short sVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined8 uVar12;
  longlong *plVar13;
  longlong *plVar14;
  undefined1 auStack_948 [32];
  undefined4 local_928;
  undefined1 local_920;
  longlong *local_918 [3];
  undefined4 *local_900;
  undefined4 *local_8f8;
  longlong local_8f0;
  longlong *local_8e8;
  undefined4 *puStack_8e0;
  longlong *local_8d8;
  undefined8 local_8d0;
  longlong local_8c8 [6];
  undefined **local_898;
  undefined4 local_890;
  undefined4 local_88c;
  undefined2 local_888 [524];
  undefined2 *local_470;
  undefined **local_468;
  undefined4 local_460;
  undefined4 local_45c;
  undefined2 local_458 [524];
  undefined2 *local_40;
  ulonglong local_38;
  
  local_8d0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_948;
  if (*(short **)(param_1 + 0x428) == (short *)0x0) {
    return;
  }
  sVar1 = **(short **)(param_1 + 0x428);
  if (sVar1 != 0) {
    if (sVar1 != 1) {
      return;
    }
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar9 = (longlong *)FUN_140087650(uVar8);
    lVar10 = (**(code **)(*plVar9 + 0x98))
                       (plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (lVar10 == 0) {
      return;
    }
    cVar4 = FUN_140178b80(lVar10);
    if (cVar4 == '\0') {
      return;
    }
    FUN_140178b90(lVar10);
    uVar5 = *(undefined4 *)(lVar10 + 0x122c);
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    FUN_14008aa60(uVar8,uVar5);
    return;
  }
  uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar9 = (longlong *)FUN_140087650(uVar8);
  plVar9 = (longlong *)
           (**(code **)(*plVar9 + 0xa0))
                     (plVar9,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c));
  if (plVar9 == (longlong *)0x0) {
    FUN_1402ba1c0(&local_898);
    local_898 = CCrossMsgLogout::vftable;
    FUN_1402b5600(&local_898);
    local_470 = local_888;
    uVar5 = *(undefined4 *)(param_1 + 0x420);
    FUN_1402b5600(&local_898);
    local_890 = 0x9c4d;
    local_88c = 8;
    *local_470 = 1;
    *(undefined4 *)(local_470 + 2) = uVar5;
    plVar9 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    local_928 = 4;
    (**(code **)(*plVar9 + 0x28))
              (plVar9,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c),&local_898);
    local_898 = CCrossMsgLogout::vftable;
    FUN_1402b55f0(&local_898);
    return;
  }
  uVar5 = (**(code **)(*plVar9 + 0x38))(plVar9);
  uVar6 = FUN_140167b40(plVar9);
  local_8e8 = operator_new(8);
  plVar11 = (longlong *)0x0;
  local_918[0] = plVar11;
  if (local_8e8 != (longlong *)0x0) {
    *local_8e8 = (longlong)local_918;
    local_918[0] = local_8e8;
  }
  local_900 = (undefined4 *)0x0;
  local_8f8 = (undefined4 *)0x0;
  local_8f0 = 0;
  local_8d8 = local_8e8;
  uVar7 = (**(code **)(*plVar9 + 8))(plVar9);
  puVar3 = local_8f8;
  local_8d8 = (longlong *)CONCAT44(local_8d8._4_4_,uVar7);
  plVar9 = plVar11;
  if (local_900 != (undefined4 *)0x0) {
    plVar9 = (longlong *)(local_8f0 - (longlong)local_900 >> 2);
  }
  if ((longlong *)((longlong)local_8f8 - (longlong)local_900 >> 2) < plVar9) {
    *local_8f8 = uVar7;
    local_8f8 = local_8f8 + 1;
  }
  else {
    if (local_8f8 < local_900) {
      _invalid_parameter_noinfo();
    }
    puVar2 = local_900;
    plVar9 = local_918[0];
    local_8e8 = local_918[0];
    puStack_8e0 = puVar3;
    plVar13 = plVar11;
    if (((longlong)local_8f8 - (longlong)local_900 & 0xfffffffffffffffcU) != 0) {
      if (local_8f8 < local_900) {
        _invalid_parameter_noinfo();
      }
      if ((plVar9 == (longlong *)0x0) || (plVar9 != local_918[0])) {
        _invalid_parameter_noinfo();
      }
      plVar13 = (longlong *)((longlong)puVar3 - (longlong)puVar2 >> 2);
    }
    FUN_140036c20(local_918,&local_8e8,1,&local_8d8);
    puVar3 = local_900;
    if (local_8f8 < local_900) {
      _invalid_parameter_noinfo();
    }
    plVar9 = local_918[0];
    if (local_918[0] == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar14 = plVar11;
    }
    else {
      plVar14 = (longlong *)*local_918[0];
    }
    if (puVar3 + (longlong)plVar13 <= (undefined4 *)plVar14[4]) {
      if (plVar9 != (longlong *)0x0) {
        plVar11 = (longlong *)*plVar9;
      }
      if ((undefined4 *)plVar11[3] <= puVar3 + (longlong)plVar13) goto LAB_1403eebbf;
    }
    _invalid_parameter_noinfo();
  }
LAB_1403eebbf:
  local_8e8 = local_8c8;
  uVar8 = FUN_140043260(local_8c8,local_918);
  uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  uVar12 = FUN_140087650(uVar12);
  local_920 = 0;
  local_928 = CONCAT31(local_928._1_3_,1);
  FUN_1402b3560(uVar12,uVar8,0xd,1);
  FUN_1402ba1c0(&local_468);
  local_468 = CCrossMsgLogout::vftable;
  FUN_1402b5600(&local_468);
  local_40 = local_458;
  FUN_1402b5600(&local_468);
  local_460 = 0x9c4d;
  local_45c = 8;
  *local_40 = 1;
  *(undefined4 *)(local_40 + 2) = uVar5;
  plVar9 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  local_928 = 4;
  (**(code **)(*plVar9 + 0x28))(plVar9,uVar5,uVar6,&local_468);
  local_468 = CCrossMsgLogout::vftable;
  FUN_1402b55f0(&local_468);
  if (local_900 != (undefined4 *)0x0) {
    operator_delete(local_900);
  }
  local_900 = (undefined4 *)0x0;
  local_8f8 = (undefined4 *)0x0;
  local_8f0 = 0;
  operator_delete(local_918[0]);
  return;
}

