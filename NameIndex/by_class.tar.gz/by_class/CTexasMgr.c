// ==== CTexasMgr::helper_14000d2d0  @14000d2d0  [medium:callgraph-r0]  (orig: FUN_14000d2d0)
undefined4 FUN_14000d2d0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  
  plVar2 = *(longlong **)(param_1 + 0xa0);
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0xd0);
  lVar6 = 0;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0xd0);
    if ((*(longlong **)(param_1 + 0xa0) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0xa0) != plVar2)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar5) {
      return 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar6;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(int *)((longlong)plVar5 + 0x1c) == 1) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x75) == '\0') {
      plVar3 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar3 + 0x75) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x75);
        plVar5 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x75);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x75);
        plVar4 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x75);
          plVar4 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar6 = *plVar2;
  }
  if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return (int)plVar5[4];
}

// ==== CTexasMgr::helper_14020f500  @14020f500  [medium:callgraph-r0]  (orig: FUN_14020f500)
void FUN_14020f500(longlong param_1)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  __time32_t _Var4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  tm local_38;
  
  plVar5 = (longlong *)FUN_140006ad0(3000,0);
  if (plVar5 != (longlong *)0x0) {
    lVar6 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (lVar6 == 0) {
      (**(code **)*plVar5)();
      return;
    }
    plVar7 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,2);
    DAT_1409762a0 = (**(code **)(*plVar7 + 0x48))(plVar7);
    plVar7 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,3);
    uVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
    *(undefined4 *)(param_1 + 0xc) = uVar2;
    plVar7 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,4);
    uVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
    *(undefined4 *)(param_1 + 0x10) = uVar2;
    (**(code **)*plVar5)(plVar5);
    if ((*(uint *)(param_1 + 0x10) != 0) && (uVar1 = *(uint *)(param_1 + 0xc), uVar1 != 0)) {
      if (*(uint *)(param_1 + 0x10) <= uVar1) {
        *(undefined4 *)(param_1 + 0xc) = 0;
        *(undefined4 *)(param_1 + 0x10) = 0;
        log_InlineLogDBERROR("table:cq_config, type(3000), data2 data3");
        return;
      }
      *(undefined1 *)(param_1 + 0x1c) = 1;
      local_38.tm_sec = 0;
      local_38.tm_min = 0;
      local_38.tm_wday = 0;
      local_38.tm_yday = 0;
      local_38.tm_isdst = 0;
      local_38.tm_year = uVar1 / 1000000 - 0x76c;
      local_38.tm_mon =
           (int)((ulonglong)uVar1 / 10000) + (int)(((ulonglong)uVar1 / 10000) / 100) * -100 + -1;
      iVar3 = (int)((ulonglong)uVar1 / 100);
      local_38.tm_hour = uVar1 + iVar3 * -100;
      local_38.tm_mday = iVar3 + (int)(((ulonglong)uVar1 / 100) / 100) * -100;
      _Var4 = _mktime32(&local_38);
      uVar1 = *(uint *)(param_1 + 0x10);
      *(__time32_t *)(param_1 + 4) = _Var4;
      local_38.tm_sec = 0;
      local_38.tm_min = 0;
      local_38.tm_wday = 0;
      local_38.tm_yday = 0;
      local_38.tm_isdst = 0;
      local_38.tm_year = uVar1 / 1000000 - 0x76c;
      local_38.tm_mon =
           (int)((ulonglong)uVar1 / 10000) + (int)(((ulonglong)uVar1 / 10000) / 100) * -100 + -1;
      local_38.tm_hour = uVar1 % 100;
      local_38.tm_mday = (uVar1 / 100) % 100;
      _Var4 = _mktime32(&local_38);
      *(__time32_t *)(param_1 + 8) = _Var4;
    }
  }
  return;
}

// ==== CTexasMgr::helper_140211630  @140211630  [medium:callgraph-r2]  (orig: FUN_140211630)
undefined8 *
FUN_140211630(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    *(undefined4 *)(puVar1 + 3) = *param_5;
    *(undefined4 *)((longlong)puVar1 + 0x1c) = param_5[1];
    *(undefined4 *)(puVar1 + 4) = param_5[2];
    *(undefined4 *)((longlong)puVar1 + 0x24) = param_5[3];
    *(undefined4 *)(puVar1 + 5) = param_5[4];
    *(undefined1 *)((longlong)puVar1 + 0x2c) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x2d) = 0;
  }
  return puVar1;
}

// ==== CTexasMgr::helper_140213070  @140213070  [medium:callgraph-r1]  (orig: FUN_140213070)
undefined8 *
FUN_140213070(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xcccccccccccccca < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140211630(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x2c);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x2c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x2d) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x2d) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x2c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x2d) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x2d) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x2c);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x2c) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CTexasMgr::helper_140214260  @140214260  [medium:callgraph-r0]  (orig: FUN_140214260)
longlong * FUN_140214260(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x2d) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x2d) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1402143bd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1402143ec;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x2d) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x2d) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x2d);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x2d);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x2d);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x2d);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x2d) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x2d) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1402143bd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_140213070(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1402143ec:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CTexasMgr::Create  @140214780  [high:log-string]  (orig: FUN_140214780)
undefined8 FUN_140214780(undefined4 *param_1,undefined4 param_2)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  ulong uVar6;
  undefined8 uVar7;
  uint7 uVar11;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  int iVar12;
  uint local_64;
  uint local_60;
  uint local_5c;
  uint local_58;
  int local_54;
  uint local_50;
  undefined1 local_48 [32];
  
  *param_1 = param_2;
  uVar7 = FUN_14020f500();
  if (*(char *)(param_1 + 7) == '\0') {
    uVar11 = (uint7)((ulonglong)uVar7 >> 8);
  }
  else {
    plVar8 = (longlong *)InstanceGet();
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,"SELECT * FROM cq_texas_table",1);
    if (plVar8 != (longlong *)0x0) {
      iVar12 = 0;
      iVar2 = (**(code **)(*plVar8 + 0x40))(plVar8);
      if (0 < iVar2) {
        do {
          (**(code **)(*plVar8 + 0x30))(plVar8,(longlong)iVar12);
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,0);
          uVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,1);
          iVar2 = (**(code **)(*plVar9 + 0x48))(plVar9);
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,2);
          iVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,3);
          iVar5 = (**(code **)(*plVar9 + 0x48))(plVar9);
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,4);
          bVar1 = (**(code **)(*plVar9 + 0x20))(plVar9);
          if ((uVar3 < 100) && (-1 < iVar5)) {
            local_64 = 0;
            if ((byte)(bVar1 - 2) < 8) {
              local_64 = (uint)bVar1;
            }
            else if (bVar1 != 0) {
              log_InlineLogERROR("CTexasMgr::Create(). Config[%u] MinCard[%d] not in [2, 9]");
            }
            local_50 = local_64;
            local_60 = uVar3;
            local_5c = (uint)(iVar4 != 0);
            local_58 = (uint)(iVar2 != 0);
            local_54 = iVar5;
            FUN_140214260(param_1 + 0x28,local_48,&local_60);
          }
          else {
            log_InlineLogDBERROR("table:cq_texas_table ID[%u] is illegal.");
          }
          iVar12 = iVar12 + 1;
          iVar2 = (**(code **)(*plVar8 + 0x40))(plVar8);
        } while (iVar12 < iVar2);
      }
    }
    if (plVar8 != (longlong *)0x0) {
      (**(code **)*plVar8)(plVar8);
    }
    lVar10 = FUN_140008520(*param_1);
    if (*(longlong *)(lVar10 + 0xb0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    iVar2 = FUN_14000d2d0(*(undefined8 *)(lVar10 + 0xb0));
    if (iVar2 != 0) {
      param_1[6] = iVar2;
    }
    param_1[0x48] = 600;
    uVar6 = tq::TimeGet(0);
    uVar11 = (uint7)((ulonglong)uVar6 * 0x10624dd3 >> 8) & 0xffffff;
    param_1[0x49] = uVar6 / 1000;
  }
  return CONCAT71(uVar11,1);
}

