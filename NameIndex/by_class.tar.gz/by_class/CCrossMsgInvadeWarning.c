// ==== CCrossMsgInvadeWarning::ctor_or_dtor  @140460fa0  [high:vtable-assign]  (orig: FUN_140460fa0)
undefined8 * FUN_140460fa0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgInvadeWarning::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgInvadeWarning::ctor_or_dtor  @140460ff0  [high:vtable-assign]  (orig: FUN_140460ff0)
void FUN_140460ff0(undefined8 *param_1)

{
  *param_1 = CCrossMsgInvadeWarning::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgInvadeWarning::vfunc_1  @140461020  [high:rtti-vtable]  (orig: FUN_140461020)
ulonglong FUN_140461020(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c6b);
}

// ==== CCrossMsgInvadeWarning::ctor_or_dtor  @140461130  [high:vtable-assign]  (orig: FUN_140461130)
undefined8 * FUN_140461130(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgInvadeWarning::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgInvadeWarning::vfunc_3  @140461180  [high:rtti-vtable]  (orig: FUN_140461180)
void FUN_140461180(longlong param_1)

{
  short sVar1;
  longlong lVar2;
  longlong lVar3;
  undefined4 uVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined4 in_stack_ffffffffffffffe8;
  undefined2 uVar8;
  
  uVar8 = (undefined2)((uint)in_stack_ffffffffffffffe8 >> 0x10);
  plVar5 = (longlong *)FUN_140087ed0();
  if (plVar5 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  sVar1 = **(short **)(param_1 + 0x428);
  if (sVar1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0001404612bd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar5 + 0x648))
              (plVar5,*(undefined4 *)(param_1 + 0x420),
               *(undefined4 *)(*(short **)(param_1 + 0x428) + 4));
    return;
  }
  if (sVar1 != 1) {
                    /* WARNING: Could not recover jumptable at 0x0001404611f8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("CCrossMsgInvadeWarning::Process wrong action[%u]");
    return;
  }
  uVar4 = *(undefined4 *)(param_1 + 0x420);
  uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar7 = (longlong *)FUN_140087650(uVar6);
  plVar7 = (longlong *)
           (**(code **)(*plVar7 + 0xa0))
                     (plVar7,uVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
  if (plVar7 == (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140461257. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("CCrossMsgInvadeWarning::ACTION_TOKEN_ACK_OK, user[%lu] is not online.");
    return;
  }
  lVar2 = *plVar5;
  lVar3 = *(longlong *)(param_1 + 0x428);
  uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
  (**(code **)(lVar2 + 0x650))
            (plVar5,uVar4,*(undefined4 *)(lVar3 + 4),*(undefined4 *)(lVar3 + 8),
             CONCAT22(uVar8,*(undefined2 *)(lVar3 + 0xc)),*(undefined2 *)(lVar3 + 0xe));
  return;
}

