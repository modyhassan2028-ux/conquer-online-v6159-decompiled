// ==== CMsgAiNpcInfo@world_kernel::helper_140067320  @140067320  [medium:callgraph-r0]  (orig: FUN_140067320)
undefined8 FUN_140067320(void)

{
  longlong lVar1;
  
  if (DAT_140975af8 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = DAT_140975af8;
  if (*(longlong *)(DAT_140975af8 + 0x68) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return *(undefined8 *)(lVar1 + 0x68);
}

// ==== CMsgAiNpcInfo@world_kernel::helper_140074f20  @140074f20  [medium:callgraph-r0]  (orig: FUN_140074f20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_140074f20(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  ulonglong uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  undefined4 *puVar9;
  int iVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined4 *local_468 [2];
  longlong local_458;
  undefined8 *puStack_450;
  undefined8 local_448;
  char local_438;
  undefined1 local_437 [1023];
  ulonglong local_38;
  
  local_448 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  puVar9 = (undefined4 *)0x0;
  plVar1 = (longlong *)(param_1 + 8);
  puVar11 = puVar9;
  puVar12 = puVar9;
  if (0 < (int)(*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20) >> 3)) {
    do {
      if ((undefined4 *)(*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20) >> 3) <=
          puVar12) {
        _invalid_parameter_noinfo();
      }
      iVar10 = (int)puVar11;
      if (*(longlong *)(*(longlong *)(param_1 + 0x20) + (longlong)puVar12 * 8) != 0) {
        if ((undefined4 *)(*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20) >> 3) <=
            puVar12) {
          _invalid_parameter_noinfo();
        }
        if (**(int **)(*(longlong *)(param_1 + 0x20) + (longlong)puVar12 * 8) == param_2) {
          if ((ulonglong)(*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20) >> 3) <=
              (ulonglong)(longlong)iVar10) {
            _invalid_parameter_noinfo();
          }
          return *(int *)(*(longlong *)(*(longlong *)(param_1 + 0x20) + (longlong)iVar10 * 8) + 4) +
                 0xe;
        }
      }
      puVar11 = (undefined4 *)(ulonglong)(iVar10 + 1U);
      puVar12 = (undefined4 *)((longlong)puVar12 + 1);
    } while ((int)(iVar10 + 1U) <
             (int)(*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20) >> 3));
  }
  iVar10 = 0xe;
  local_438 = '\0';
  memset(local_437,0,0x3ff);
  _snprintf(&local_438,0x3ff,
            "SELECT id,mapgroup,portal0_x,portal0_y FROM cq_dynamap WHERE id=%u LIMIT 1");
  if (DAT_140975af8 == 0) {
    local_478 = 0x128;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)InstanceGet(DAT_140975af8);
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&local_438,2);
  if (plVar6 == (longlong *)0x0) {
    return 0xe;
  }
  lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6);
  if (lVar7 == 0) {
    (**(code **)*plVar6)(plVar6);
    return 0xe;
  }
  puVar12 = operator_new(0x10);
  puVar11 = puVar9;
  if (puVar12 != (undefined4 *)0x0) {
    *puVar12 = 0;
    puVar11 = puVar12;
  }
  local_468[0] = puVar11;
  if (puVar11 == (undefined4 *)0x0) goto LAB_140075259;
  plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&DAT_1406de8d4);
  uVar5 = (**(code **)(*plVar8 + 0x40))(plVar8);
  *puVar11 = uVar5;
  plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"mapgroup");
  uVar5 = (**(code **)(*plVar8 + 0x40))(plVar8);
  puVar11[1] = uVar5;
  plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"portal0_x");
  uVar5 = (**(code **)(*plVar8 + 0x48))(plVar8);
  puVar11[2] = uVar5;
  plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"portal0_y");
  uVar5 = (**(code **)(*plVar8 + 0x48))(plVar8);
  puVar11[3] = uVar5;
  puVar2 = *(undefined8 **)(param_1 + 0x20);
  puVar12 = puVar9;
  if (puVar2 != (undefined8 *)0x0) {
    puVar12 = (undefined4 *)(*(longlong *)(param_1 + 0x30) - (longlong)puVar2 >> 3);
  }
  puVar3 = *(undefined8 **)(param_1 + 0x28);
  if ((undefined4 *)((longlong)puVar3 - (longlong)puVar2 >> 3) < puVar12) {
    *puVar3 = puVar11;
    *(undefined8 **)(param_1 + 0x28) = puVar3 + 1;
  }
  else {
    if (puVar3 < puVar2) {
      _invalid_parameter_noinfo();
    }
    lVar7 = *plVar1;
    uVar4 = *(ulonglong *)(param_1 + 0x20);
    puVar12 = puVar9;
    local_458 = lVar7;
    puStack_450 = puVar3;
    if ((*(ulonglong *)(param_1 + 0x28) - uVar4 & 0xfffffffffffffff8) != 0) {
      if (*(ulonglong *)(param_1 + 0x28) < uVar4) {
        _invalid_parameter_noinfo();
      }
      if ((lVar7 == 0) || (lVar7 != *plVar1)) {
        _invalid_parameter_noinfo();
      }
      puVar12 = (undefined4 *)((longlong)((longlong)puVar3 - uVar4) >> 3);
    }
    FUN_1400745b0(plVar1,&local_458,1,local_468);
    uVar4 = *(ulonglong *)(param_1 + 0x20);
    if (*(ulonglong *)(param_1 + 0x28) < uVar4) {
      _invalid_parameter_noinfo();
    }
    puVar2 = (undefined8 *)*plVar1;
    if (puVar2 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      puVar13 = puVar9;
    }
    else {
      puVar13 = (undefined4 *)*puVar2;
    }
    uVar4 = uVar4 + (longlong)puVar12 * 8;
    if (uVar4 <= *(ulonglong *)(puVar13 + 8)) {
      if (puVar2 != (undefined8 *)0x0) {
        puVar9 = (undefined4 *)*puVar2;
      }
      if (*(ulonglong *)(puVar9 + 6) <= uVar4) goto LAB_140075256;
    }
    _invalid_parameter_noinfo();
  }
LAB_140075256:
  iVar10 = puVar11[1];
LAB_140075259:
  (**(code **)*plVar6)(plVar6);
  return iVar10;
}

// ==== CMsgAiNpcInfo@world_kernel::vfunc_1  @140082eb0  [high:rtti-vtable]  (orig: FUN_140082eb0)
undefined8 FUN_140082eb0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgAiNpcInfo@world_kernel::vfunc_3  @140082ee0  [high:rtti-vtable]  (orig: FUN_140082ee0)
void FUN_140082ee0(longlong param_1,longlong param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined8 uVar3;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined2 local_34;
  undefined2 local_32;
  undefined2 local_30;
  undefined2 local_2e;
  undefined1 local_2c;
  undefined4 local_28;
  undefined1 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_c;
  
  if (param_2 != 0) {
    uVar3 = FUN_140067320();
    iVar2 = FUN_140074f20(uVar3);
    if (iVar2 != -1) {
      memset(&local_48,0,0x40);
      puVar1 = *(undefined4 **)(param_1 + 0x420);
      local_48 = *puVar1;
      local_30 = *(undefined2 *)(puVar1 + 6);
      local_2e = *(undefined2 *)((longlong)puVar1 + 0x1a);
      local_44 = puVar1[1];
      local_34 = *(undefined2 *)(puVar1 + 5);
      local_32 = *(undefined2 *)((longlong)puVar1 + 0x16);
      local_40 = puVar1[2];
      local_3c = puVar1[3];
      local_2c = *(undefined1 *)(puVar1 + 7);
      local_38 = puVar1[4];
      local_28 = puVar1[8];
      local_20 = puVar1[9];
      local_1c = puVar1[10];
      local_24 = *(undefined1 *)(puVar1 + 0xb);
      local_c = puVar1[0xd];
      if (DAT_140975af8 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      (**(code **)(**(longlong **)(DAT_140975af8 + 0x58) + 0x50))
                (*(longlong **)(DAT_140975af8 + 0x58),iVar2,0x271b,0x40,&local_48);
    }
  }
  return;
}

// ==== CMsgAiNpcInfo@world_kernel::vfunc_0  @140083030  [high:rtti-vtable]  (orig: FUN_140083030)
undefined8 * FUN_140083030(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgAiNpcInfo::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

