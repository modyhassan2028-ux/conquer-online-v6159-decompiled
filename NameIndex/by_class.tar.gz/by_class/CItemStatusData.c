// ==== CItemStatusData::ctor_or_dtor  @140370920  [high:vtable-assign]  (orig: FUN_140370920)
void FUN_140370920(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  *param_1 = CItemStatusData::vftable;
  puVar1 = (undefined8 *)param_1[2];
  if (puVar1 != (undefined8 *)0x0) {
    if (*(char *)(param_1 + 3) != '\0') {
      (**(code **)*puVar1)(puVar1,0);
      param_1[2] = 0;
      return;
    }
    (**(code **)*puVar1)(puVar1,1);
    param_1[2] = 0;
  }
  return;
}

// ==== CItemStatusData::vfunc_0  @140370970  [high:rtti-vtable]  (orig: FUN_140370970)
void FUN_140370970(longlong *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140370978. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x30))(param_1,1);
  return;
}

// ==== CItemStatusData::vfunc_1  @140370980  [high:rtti-vtable]  (orig: FUN_140370980)
undefined8 FUN_140370980(longlong *param_1)

{
  if (param_1 != (longlong *)0x0) {
    (**(code **)(*param_1 + 0x68))(param_1,1);
  }
  return 0;
}

// ==== CItemStatusData::vfunc_2  @1403709a0  [high:rtti-vtable]  (orig: FUN_1403709a0)
void FUN_1403709a0(longlong *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403709a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x30))(param_1,5);
  return;
}

// ==== CItemStatusData::vfunc_3  @1403709b0  [high:rtti-vtable]  (orig: FUN_1403709b0)
void FUN_1403709b0(longlong *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403709b8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x30))(param_1,6);
  return;
}

// ==== CItemStatusData::vfunc_6  @140370a40  [high:rtti-vtable]  (orig: FUN_140370a40)
undefined8 FUN_140370a40(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if ((*(longlong *)(param_1 + 0x10) != 0) && (param_2 < 10)) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x000140370a64. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CItemStatusData::vfunc_7  @140370a70  [high:rtti-vtable]  (orig: FUN_140370a70)
void FUN_140370a70(longlong param_1,int param_2,undefined4 param_3,char param_4)

{
  longlong *plVar1;
  
  if ((*(longlong *)(param_1 + 0x10) != 0) && (param_2 < 10)) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_3);
    if ((param_4 != '\0') && (*(char *)(param_1 + 0x18) == '\0')) {
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))(*(longlong **)(param_1 + 0x10),0);
    }
  }
  return;
}

// ==== CItemStatusData::vfunc_4  @140370af0  [high:rtti-vtable]  (orig: FUN_140370af0)
bool FUN_140370af0(longlong *param_1)

{
  int iVar1;
  __time32_t _Var2;
  
  iVar1 = (**(code **)(*param_1 + 0x30))(param_1,7);
  if (iVar1 == 0) {
    return true;
  }
  iVar1 = (**(code **)(*param_1 + 0x30))(param_1,7);
  _Var2 = _time32((__time32_t *)0x0);
  return _Var2 <= iVar1;
}

// ==== CItemStatusData::vfunc_5  @140370b40  [high:rtti-vtable]  (orig: FUN_140370b40)
void FUN_140370b40(void)

{
  return;
}

// ==== CItemStatusData::vfunc_8  @140370b50  [high:rtti-vtable]  (orig: FUN_140370b50)
ulonglong FUN_140370b50(longlong param_1)

{
  ulonglong in_RAX;
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  if (*(char *)(param_1 + 0x18) == '\0') {
    if (*(longlong *)(param_1 + 0x10) != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140370b9f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                        (*(longlong **)(param_1 + 0x10),0);
      return uVar1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
    in_RAX = extraout_RAX;
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CItemStatusData::vfunc_9  @140370bb0  [high:rtti-vtable]  (orig: FUN_140370bb0)
undefined1 FUN_140370bb0(longlong param_1)

{
  undefined1 uVar1;
  
  if (*(char *)(param_1 + 0x18) == '\0') {
    if (*(longlong *)(param_1 + 0x10) != 0) {
      uVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                        (*(longlong **)(param_1 + 0x10),1);
      return uVar1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CItemStatusData::vfunc_10  @140370c10  [high:rtti-vtable]  (orig: FUN_140370c10)
ulonglong FUN_140370c10(longlong param_1)

{
  ulonglong in_RAX;
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  if (*(char *)(param_1 + 0x18) == '\0') {
    if (*(longlong *)(param_1 + 0x10) != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140370c5f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))
                        (*(longlong **)(param_1 + 0x10),0);
      return uVar1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
    in_RAX = extraout_RAX;
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CItemStatusData::helper_140370d30  @140370d30  [medium:callgraph-r0]  (orig: FUN_140370d30)
void FUN_140370d30(void *param_1)

{
  if ((DAT_140976140 & 1) == 0) {
    DAT_140976140 = DAT_140976140 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976138,"CItemStatusData");
    atexit((_func_5014 *)&LAB_1406d6b10);
  }
                    /* WARNING: Could not recover jumptable at 0x000140370d85. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976138,param_1);
  return;
}

// ==== CItemStatusData::ctor_or_dtor  @140370df0  [high:vtable-assign]  (orig: FUN_140370df0)
undefined8 * FUN_140370df0(undefined8 *param_1)

{
  *(undefined1 *)(param_1 + 3) = 0;
  *param_1 = CItemStatusData::vftable;
  *(undefined4 *)(param_1 + 1) = 0;
  param_1[2] = 0;
  return param_1;
}

// ==== CItemStatusData::ctor_or_dtor  @140370e10  [high:vtable-assign]  (orig: FUN_140370e10)
undefined8 * FUN_140370e10(undefined8 *param_1,ulonglong param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CItemStatusData::vftable;
  puVar1 = (undefined8 *)param_1[2];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,*(char *)(param_1 + 3) == '\0');
    param_1[2] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_140370d30(param_1);
  }
  return param_1;
}

