// ==== CMsgRouletteBet::helper_1401fe190  @1401fe190  [medium:callgraph-r2]  (orig: FUN_1401fe190)
undefined4 FUN_1401fe190(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1a4);
}

// ==== CMsgRouletteBet::helper_140205350  @140205350  [medium:callgraph-r0]  (orig: FUN_140205350)
void FUN_140205350(longlong param_1,longlong *param_2,undefined8 param_3,char param_4)

{
  undefined4 uVar1;
  IStringManager *pIVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong lVar5;
  undefined4 local_68 [2];
  undefined8 local_60;
  longlong *local_58;
  longlong local_50;
  longlong *local_48;
  
  local_60 = 0xfffffffffffffffe;
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_4 != '\0') {
    local_68[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_140050f20(param_1 + 0xd0,&local_58,local_68);
    lVar4 = *(longlong *)(param_1 + 0x100);
    lVar5 = 0;
    local_48 = *(longlong **)(param_1 + 0xd0);
    if ((local_58 == (longlong *)0x0) || (local_58 != local_48)) {
      _invalid_parameter_noinfo();
    }
    if (local_50 == lVar4) {
      pIVar2 = theInstance();
      lVar4 = param_2[2];
      uVar3 = (*(code *)**(undefined8 **)pIVar2)(pIVar2,"STR_ROULETTE_NOT_JOIN_ANY_TABLE");
      (**(code **)(lVar4 + 0x358))(param_2 + 2,uVar3);
    }
    else {
      if (local_58 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar5 = *local_58;
      }
      if (local_50 == *(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar1 = *(undefined4 *)(local_50 + 0x1c);
      lVar4 = (**(code **)(param_2[2] + 0x2a8))(param_2 + 2,uVar1);
      if (lVar4 == 0) {
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR("CRouletteMgr::PlayerWager FindAroundRole failed, idUser:%u, idNpc:%u.");
      }
      else {
        lVar4 = FUN_1401ff5c0(param_1,uVar1);
        if (lVar4 == 0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR(
                            "CRouletteMgr::PlayerWager GetRoulette failed, idUser:%u, npc id:%u, at %s, %d."
                            );
        }
        else {
          FUN_140411970(lVar4,param_2,param_3,param_4);
        }
      }
    }
  }
  return;
}

// ==== CMsgRouletteBet::helper_140205640  @140205640  [medium:callgraph-r2]  (orig: FUN_140205640)
bool FUN_140205640(longlong param_1,byte param_2)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong local_28;
  undefined8 *local_20;
  
  puVar2 = *(undefined8 **)(param_1 + 0x40);
  lVar3 = *(longlong *)(param_1 + 0x10);
  cVar1 = *(char *)((longlong)puVar2[1] + 0x1a);
  puVar4 = puVar2;
  puVar7 = (undefined8 *)puVar2[1];
  while (cVar1 == '\0') {
    if (*(byte *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar4;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar4 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x1a);
  }
  local_40 = puVar4;
  local_48 = lVar3;
  if (lVar3 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar2) || (param_2 < *(byte *)(puVar4 + 3))) {
    plVar6 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x40);
    local_38 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar6 = &local_48;
  }
  local_28 = *plVar6;
  local_20 = (undefined8 *)plVar6[1];
  if ((local_28 == 0) || (local_28 != lVar3)) {
    _invalid_parameter_noinfo();
  }
  return local_20 != puVar2;
}

// ==== CMsgRouletteBet::helper_140339f20  @140339f20  [medium:callgraph-r2]  (orig: FUN_140339f20)
int FUN_140339f20(longlong param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  int iVar5;
  ulonglong uVar6;
  
  iVar5 = 0;
  iVar2 = (int)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2);
  if (iVar2 < 1) {
    return 0;
  }
  iVar2 = iVar2 + -1;
  uVar6 = (ulonglong)iVar2;
  if (iVar2 < 0) {
    iVar5 = 0;
  }
  else {
    do {
      plVar4 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      if ((ulonglong)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) <= uVar6
         ) {
        _invalid_parameter_noinfo();
      }
      plVar4 = (longlong *)
               (**(code **)(*plVar4 + 0x60))
                         (plVar4,*(undefined4 *)(*(longlong *)(param_1 + 0xc20) + uVar6 * 4));
      if ((((plVar4 != (longlong *)0x0) && (cVar1 = FUN_1400ffc20(plVar4), cVar1 == '\0')) &&
          (cVar1 = FUN_1400ff650(plVar4,2), cVar1 == '\0')) &&
         (cVar1 = FUN_1400ff650(plVar4,1), cVar1 == '\0')) {
        uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
        cVar1 = FUN_1403380a0(param_1,uVar3);
        if ((cVar1 == '\0') && (iVar2 = FUN_1400fda10(plVar4,1,1), iVar2 == param_2)) {
          uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
          cVar1 = FUN_14032d730(param_1,uVar3);
          if (cVar1 == '\0') {
            iVar2 = FUN_140100000(plVar4);
            iVar5 = iVar5 + iVar2;
          }
        }
      }
      uVar6 = uVar6 - 1;
    } while (-1 < (longlong)uVar6);
  }
  return iVar5;
}

// ==== CMsgRouletteBet::helper_14040d0f0  @14040d0f0  [medium:callgraph-r3]  (orig: FUN_14040d0f0)
void FUN_14040d0f0(undefined8 *param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = *param_3;
    }
    param_1 = param_1 + 1;
  }
  return;
}

// ==== CMsgRouletteBet::helper_140410790  @140410790  [medium:callgraph-r3]  (orig: FUN_140410790)
longlong * FUN_140410790(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_14040f9d0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_140410884;
  }
  _invalid_parameter_noinfo();
LAB_140410884:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMsgRouletteBet::helper_1404118a0  @1404118a0  [medium:callgraph-r2]  (orig: FUN_1404118a0)
void FUN_1404118a0(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) >> 3;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) >> 3) < uVar3) {
    FUN_14040d0f0(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 8;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140410790(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMsgRouletteBet::helper_140411970  @140411970  [medium:callgraph-r1]  (orig: FUN_140411970)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong * FUN_140411970(longlong param_1,longlong *param_2,longlong param_3,byte param_4)

{
  ulonglong *puVar1;
  ulonglong *puVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  ulonglong *extraout_RAX;
  ulonglong *extraout_RAX_00;
  ulonglong *puVar9;
  ulonglong *extraout_RAX_01;
  ulonglong *extraout_RAX_02;
  ulonglong *extraout_RAX_03;
  longlong lVar10;
  ulonglong *extraout_RAX_04;
  ulonglong uVar11;
  ulonglong *extraout_RAX_05;
  ulonglong *extraout_RAX_06;
  longlong lVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  undefined1 auStack_958 [32];
  ulonglong local_938;
  uint local_930;
  ulonglong *local_928;
  undefined4 local_920;
  byte local_918;
  uint local_914;
  byte local_910;
  uint local_90c;
  longlong local_908;
  undefined8 local_900;
  longlong local_8f8;
  ulonglong *local_8f0;
  longlong local_8e8;
  uint local_8e0;
  uint local_8dc;
  uint local_8d8;
  ulonglong *local_8d0;
  ulonglong *local_8c0;
  longlong *local_8b8;
  undefined8 local_8b0;
  undefined1 local_8a8 [1072];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8b0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_958;
  local_918 = param_4;
  local_910 = param_4;
  local_908 = param_3;
  local_8e8 = param_1;
  local_8b8 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_938 = CONCAT44(local_938._4_4_,0x125);
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar9 = extraout_RAX;
  }
  else if (*(longlong *)(param_1 + 0x198) == 0) {
    local_938 = CONCAT44(local_938._4_4_,0x126);
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar9 = extraout_RAX_00;
  }
  else if (*(char *)(param_1 + 0x170) == '\x01') {
    local_914 = (**(code **)(*param_2 + 8))(param_2);
    FUN_14040ee60(param_1 + 0x20,&local_900,&local_914);
    puVar1 = local_900;
    lVar10 = *(longlong *)(param_1 + 0x50);
    uVar13 = 0;
    puVar9 = *(ulonglong **)(param_1 + 0x20);
    local_8d0 = puVar9;
    if ((local_900 == (ulonglong *)0x0) || (local_900 != puVar9)) {
      _invalid_parameter_noinfo();
      puVar9 = extraout_RAX_02;
    }
    if (local_8f8 != lVar10) {
      if (puVar1 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar11 = uVar13;
      }
      else {
        uVar11 = *puVar1;
      }
      if (local_8f8 == *(longlong *)(uVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong *)(local_8f8 + 0x20) == 0) {
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR("CRoulette::PlayerWager user_wager_info point is null, idUser:%u.");
        puVar9 = extraout_RAX_03;
      }
      else {
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar11 = uVar13;
        }
        else {
          uVar11 = *puVar1;
        }
        if (local_8f8 == *(longlong *)(uVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (*(longlong *)(*(longlong *)(local_8f8 + 0x20) + 0x38) -
            *(longlong *)(*(longlong *)(local_8f8 + 0x20) + 0x30) >> 3 == 0) {
          local_8c0 = (ulonglong *)0x0;
          uVar8 = 0;
          local_8e0 = 0;
          uVar11 = uVar13;
          while( true ) {
            puVar2 = local_8c0;
            puVar9 = (ulonglong *)(ulonglong)local_918;
            iVar5 = (int)uVar11;
            if ((int)(uint)local_918 <= iVar5) break;
            lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 400));
            if (*(longlong *)(lVar10 + 0x1d8) == 0) {
              local_938 = CONCAT44(local_938._4_4_,0x15f);
              log_InlineLogERROR(&DAT_1406d9c10);
              uVar11 = uVar13;
            }
            else {
              uVar11 = *(ulonglong *)(lVar10 + 0x1d8);
            }
            lVar10 = (longlong)iVar5;
            puVar9 = (ulonglong *)FUN_140205640(uVar11,*(undefined1 *)(local_908 + lVar10 * 5));
            if ((char)puVar9 == '\0') {
              return puVar9;
            }
            if (*(char *)(local_8e8 + 4) == '\0') {
              uVar6 = *(uint *)(lVar10 * 5 + 1 + local_908);
              uVar4 = *(int *)(local_8e8 + 0x174) * 1000;
              if (uVar4 < uVar6) {
                return (ulonglong *)(ulonglong)uVar4;
              }
            }
            else {
              puVar9 = (ulonglong *)(local_908 + lVar10 * 4);
              uVar6 = *(uint *)(lVar10 + 1 + (longlong)puVar9);
              if (*(uint *)(local_8e8 + 0x174) < uVar6) {
                return puVar9;
              }
            }
            local_8c0 = (ulonglong *)((longlong)puVar2 + (ulonglong)uVar6);
            local_8e0 = iVar5 + 1;
            uVar11 = (ulonglong)local_8e0;
            param_1 = local_8e8;
          }
          if (0 < (longlong)local_8c0) {
            if (*(char *)(param_1 + 4) == '\0') {
              puVar9 = (ulonglong *)(**(code **)(*param_2 + 0x60))(param_2);
              if ((longlong)puVar9 < (longlong)puVar2) {
                return puVar9;
              }
              cVar3 = (**(code **)(*param_2 + 0x178))(param_2,puVar2,1);
              if (cVar3 == '\0') {
                if (*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x60) == 0) {
                  local_938 = CONCAT44(local_938._4_4_,0x174);
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x198) + 0x60) + 8))();
                }
                (**(code **)(*param_2 + 8))(param_2);
                log_InlineLogERROR(
                                  "CRoulette::PlayerWager user SpendMoney failed, idNpc:%u, idUser:%u, wager sum:%I64d."
                                  );
                return extraout_RAX_04;
              }
              local_914 = *(uint *)(param_2 + 0x1e2);
              if (*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x60) == 0) {
                local_938 = CONCAT44(local_938._4_4_,0x174);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x198) + 0x60) + 8))();
              }
              uVar11 = (**(code **)(param_2[2] + 0x18))();
              (**(code **)(*param_2 + 8))(param_2);
              local_930 = local_914;
              local_938 = uVar11;
              local_928 = puVar2;
              tq::MyLogSave("gmlog/roulette",
                            "wager NpcOwner[%u] money: %u\t%s\t%u\t Total Money:%I64d\t");
              puVar9 = (ulonglong *)(ulonglong)local_918;
            }
            else if (*(char *)(param_1 + 4) == '\x01') {
              local_914 = FUN_140339f20(param_2,0x2dd80d);
              lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 400));
              if (*(longlong *)(lVar10 + 0x1d8) == 0) {
                local_938 = CONCAT44(local_938._4_4_,0x15f);
                log_InlineLogERROR(&DAT_1406d9c10);
                uVar11 = uVar13;
              }
              else {
                uVar11 = *(ulonglong *)(lVar10 + 0x1d8);
              }
              iVar5 = FUN_1401fe190(uVar11);
              uVar6 = iVar5 * local_914;
              if ((longlong)(ulonglong)(*(int *)((longlong)param_2 + 0xfa4) + uVar6) <
                  (longlong)puVar2) {
                return (ulonglong *)(ulonglong)uVar6;
              }
              local_900 = puVar2;
              local_8f0 = puVar2;
              if ((0 < (int)local_914) && (0 < iVar5)) {
                if ((longlong)(int)uVar6 < (longlong)puVar2) {
                  local_8d0 = (ulonglong *)(ulonglong)local_914;
                  local_90c = local_914;
                  local_8f0 = (ulonglong *)((longlong)puVar2 - (longlong)(int)uVar6);
                  uVar6 = local_914;
                }
                else {
                  local_8d0 = (ulonglong *)((longlong)puVar2 / (longlong)iVar5);
                  local_90c = (uint)local_8d0;
                  if ((longlong)(int)(local_90c * iVar5) < (longlong)puVar2) {
                    local_90c = local_90c + 1;
                    local_8d0 = (ulonglong *)(ulonglong)local_90c;
                  }
                  local_8f0 = (ulonglong *)0x0;
                  uVar6 = (uint)local_8d0;
                }
                local_938 = local_938 & 0xffffffffffffff00;
                local_900 = local_8f0;
                cVar3 = FUN_140345840(param_2,0x2dd80d,0x2dd80d,uVar6);
                if (cVar3 == '\0') {
                  (**(code **)(*param_2 + 8))(param_2);
                  log_InlineLogERROR(
                                    "CRoulette::PlayerWager MultiDelItemMonoPrioriy failed, idUser:%u, wager sum:%I64d, num:%d."
                                    );
                  return extraout_RAX_05;
                }
                local_8f0 = (ulonglong *)CONCAT44(local_8f0._4_4_,(int)param_2[0x1e2]);
                if (*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x60) == 0) {
                  local_938 = CONCAT44(local_938._4_4_,0x174);
                  log_InlineLogERROR(&DAT_1406d9c10);
                  local_914 = 0;
                }
                else {
                  local_914 = (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x198) + 0x60) +
                                          8))();
                }
                uVar11 = (**(code **)(param_2[2] + 0x18))();
                (**(code **)(*param_2 + 8))(param_2);
                local_920 = SUB84(local_8d0,0);
                local_930 = (uint)local_8f0;
                local_938 = uVar11;
                local_928 = puVar2;
                tq::MyLogSave("gmlog/roulette",
                              "wager NpcOwner[%u] use chip item: %u\t%s\t%u\t Total EMoney:%I64d, item num:%d."
                             );
              }
              puVar9 = local_900;
              if (local_900 == (ulonglong *)0x0) {
                puVar9 = (ulonglong *)(ulonglong)local_918;
              }
              else {
                local_938 = 0;
                cVar3 = (**(code **)(param_2[2] + 0x2e0))(param_2 + 2,0x1d,-(longlong)local_900,1);
                if (cVar3 == '\0') {
                  if (*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x60) == 0) {
                    local_938 = CONCAT44(local_938._4_4_,0x174);
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  else {
                    (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x198) + 0x60) + 8))();
                  }
                  (**(code **)(*param_2 + 8))(param_2);
                  log_InlineLogERROR(
                                    "CRoulette::PlayerWager pUser->AddAttrib failed, idNpc:%u, idUser:%u, wager sum:%I64d."
                                    );
                  return extraout_RAX_06;
                }
                uVar7 = (**(code **)(*param_2 + 8))(param_2);
                local_938._0_4_ = (int)puVar9;
                FUN_1401742b0(param_2,0x3c,uVar7);
                if (*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x60) == 0) {
                  local_938._0_4_ = 0x174;
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  uVar8 = (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x198) + 0x60) + 8))
                                    ();
                }
                (**(code **)(param_2[2] + 0x18))(param_2 + 2);
                (**(code **)(*param_2 + 8))(param_2);
                local_930 = (uint)local_900;
                local_928 = (ulonglong *)CONCAT44(local_928._4_4_,local_930);
                local_938 = CONCAT44(local_938._4_4_,uVar8);
                tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4265\t%d\t%d\t1\t");
                puVar9 = (ulonglong *)(ulonglong)local_918;
              }
            }
            local_8d8 = 0;
            uVar11 = uVar13;
            while (iVar5 = (int)uVar11, iVar5 < (int)puVar9) {
              lVar12 = (longlong)iVar5;
              lVar10 = local_908 + lVar12 * 4;
              local_900 = (ulonglong *)CONCAT71(local_900._1_7_,*(undefined1 *)(lVar12 + lVar10));
              local_900 = (ulonglong *)
                          CONCAT44(*(undefined4 *)(lVar12 + 1 + lVar10),(undefined4)local_900);
              if (puVar1 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar11 = uVar13;
              }
              else {
                uVar11 = *puVar1;
              }
              if (local_8f8 == *(longlong *)(uVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              FUN_1404118a0(*(longlong *)(local_8f8 + 0x20) + 0x18,&local_900);
              local_8d8 = iVar5 + 1;
              puVar9 = (ulonglong *)(ulonglong)local_918;
              uVar11 = (ulonglong)local_8d8;
            }
            FUN_1404dda80(local_478);
            if (puVar1 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar11 = uVar13;
            }
            else {
              uVar11 = *puVar1;
            }
            if (local_8f8 == *(longlong *)(uVar11 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            cVar3 = FUN_1404ddb30(local_478,*(undefined1 *)(*(longlong *)(local_8f8 + 0x20) + 0x15))
            ;
            if (cVar3 == '\0') {
              if (puVar1 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                uVar13 = *puVar1;
              }
              if (local_8f8 == *(longlong *)(uVar13 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR(
                                "CRoulette::PlayerWager create CMsgRoulettePlayerBet failed,idUser:%u, seat num:%u."
                                );
              puVar9 = (ulonglong *)FUN_1404ddad0(local_478);
            }
            else {
              local_8dc = 0;
              uVar11 = uVar13;
              while( true ) {
                if (puVar1 == (ulonglong *)0x0) {
                  _invalid_parameter_noinfo();
                  uVar15 = uVar13;
                }
                else {
                  uVar15 = *puVar1;
                }
                if (local_8f8 == *(longlong *)(uVar15 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                uVar15 = (ulonglong)(int)uVar11;
                if ((ulonglong)
                    (*(longlong *)(*(longlong *)(local_8f8 + 0x20) + 0x38) -
                     *(longlong *)(*(longlong *)(local_8f8 + 0x20) + 0x30) >> 3) <= uVar15) {
                  uVar8 = (**(code **)(*param_2 + 8))(param_2);
                  FUN_140410cb0(local_8e8,local_478,uVar8);
                  puVar9 = (ulonglong *)FUN_1404ddad0(local_478);
                  return puVar9;
                }
                if (puVar1 == (ulonglong *)0x0) {
                  _invalid_parameter_noinfo();
                  uVar14 = uVar13;
                }
                else {
                  uVar14 = *puVar1;
                }
                if (local_8f8 == *(longlong *)(uVar14 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                lVar10 = *(longlong *)(local_8f8 + 0x20);
                if ((ulonglong)(*(longlong *)(lVar10 + 0x38) - *(longlong *)(lVar10 + 0x30) >> 3) <=
                    uVar15) {
                  _invalid_parameter_noinfo();
                }
                local_908 = *(longlong *)(lVar10 + 0x30);
                if (puVar1 == (ulonglong *)0x0) {
                  _invalid_parameter_noinfo();
                  uVar14 = uVar13;
                }
                else {
                  uVar14 = *puVar1;
                }
                if (local_8f8 == *(longlong *)(uVar14 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                lVar10 = *(longlong *)(local_8f8 + 0x20);
                if ((ulonglong)(*(longlong *)(lVar10 + 0x38) - *(longlong *)(lVar10 + 0x30) >> 3) <=
                    uVar15) {
                  _invalid_parameter_noinfo();
                }
                cVar3 = FUN_1404ddb80(local_478,
                                      *(undefined1 *)(*(longlong *)(lVar10 + 0x30) + uVar15 * 8),
                                      *(undefined4 *)(local_908 + 4 + uVar15 * 8));
                if (cVar3 == '\0') break;
                local_8dc = (int)uVar11 + 1;
                uVar11 = (ulonglong)local_8dc;
              }
              (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR(
                                "CRoulette::PlayerWager CMsgRoulettePlayerBet Append failed, idUser:%u."
                                );
              puVar9 = (ulonglong *)FUN_1404ddad0(local_478);
            }
          }
        }
        else {
          FUN_1404500a0(local_8a8);
          cVar3 = FUN_140450150(local_8a8,4);
          if (cVar3 != '\0') {
            (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8a8);
          }
          puVar9 = (ulonglong *)FUN_1404500f0(local_8a8);
        }
      }
    }
  }
  else if (*(char *)(param_1 + 0x170) == '\x02') {
    FUN_1404500a0(local_8a8);
    cVar3 = FUN_140450150(local_8a8,5);
    if (cVar3 != '\0') {
      (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8a8);
    }
    puVar9 = (ulonglong *)FUN_1404500f0(local_8a8);
  }
  else {
    if (*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x60) == 0) {
      local_938 = CONCAT44(local_938._4_4_,0x174);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x198) + 0x60) + 8))();
    }
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR("CRoulette::PlayerWager table status error, idUser:%u, Npcid:%u,status:%u.");
    puVar9 = extraout_RAX_01;
  }
  return puVar9;
}

// ==== CMsgRouletteBet::helper_140450150  @140450150  [medium:callgraph-r2]  (orig: FUN_140450150)
undefined8 FUN_140450150(longlong param_1,undefined1 param_2)

{
  undefined1 *puVar1;
  
  puVar1 = *(undefined1 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 0xc) = 1;
  *(undefined4 *)(param_1 + 8) = 0xaf4;
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMsgRouletteBet::ctor_or_dtor  @1404507d0  [high:vtable-assign]  (orig: FUN_1404507d0)
undefined8 * FUN_1404507d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRouletteBet::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRouletteBet::ctor_or_dtor  @140450820  [high:vtable-assign]  (orig: FUN_140450820)
void FUN_140450820(undefined8 *param_1)

{
  *param_1 = CMsgRouletteBet::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRouletteBet::vfunc_1  @140450850  [high:rtti-vtable]  (orig: FUN_140450850)
ulonglong FUN_140450850(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xaf0);
}

// ==== CMsgRouletteBet::ctor_or_dtor  @140450960  [high:vtable-assign]  (orig: FUN_140450960)
undefined8 * FUN_140450960(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRouletteBet::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgRouletteBet::vfunc_3  @1404509b0  [high:rtti-vtable]  (orig: FUN_1404509b0)
void FUN_1404509b0(longlong param_1)

{
  undefined8 uVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar2 = (longlong *)FUN_140087650(uVar1);
    lVar3 = (**(code **)(*plVar2 + 0x88))(plVar2,param_1);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else if (**(char **)(param_1 + 0x428) != '\0') {
      lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      if (*(longlong *)(lVar4 + 0x1d8) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar1 = 0;
      }
      else {
        uVar1 = *(undefined8 *)(lVar4 + 0x1d8);
      }
      FUN_140205350(uVar1,lVar3,*(undefined1 **)(param_1 + 0x428) + 1,
                    **(undefined1 **)(param_1 + 0x428));
    }
  }
  return;
}

// ==== CMsgRouletteBet::helper_1404ddb30  @1404ddb30  [medium:callgraph-r2]  (orig: FUN_1404ddb30)
ulonglong FUN_1404ddb30(longlong param_1,byte param_2)

{
  byte *pbVar1;
  ulonglong extraout_RAX;
  
  if (4 < param_2) {
    log_InlineLogERROR("CMsgRoulettePlayerBet::Create failed, seat num is error, seat num:%u.");
    return extraout_RAX & 0xffffffffffffff00;
  }
  *(undefined4 *)(param_1 + 0xc) = 2;
  *(undefined4 *)(param_1 + 8) = 0xafa;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = 0;
  pbVar1 = *(byte **)(param_1 + 0x428);
  *pbVar1 = param_2;
  return CONCAT71((int7)((ulonglong)pbVar1 >> 8),1);
}

// ==== CMsgRouletteBet::helper_1404ddb80  @1404ddb80  [medium:callgraph-r2]  (orig: FUN_1404ddb80)
ulonglong FUN_1404ddb80(longlong param_1,undefined1 param_2,undefined4 param_3)

{
  char *pcVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  
  if (0x3ff < (longlong)*(int *)(param_1 + 0xc) + 5U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 5;
  *(undefined1 *)((ulonglong)*(byte *)(lVar2 + 1) * 5 + 2 + lVar2) = param_2;
  *(undefined4 *)
   ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 1) * 5 + 3 +
   *(longlong *)(param_1 + 0x428)) = param_3;
  lVar2 = *(longlong *)(param_1 + 0x428);
  pcVar1 = (char *)(lVar2 + 1);
  *pcVar1 = *pcVar1 + '\x01';
  return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
}

