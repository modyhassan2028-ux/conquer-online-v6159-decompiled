// ==== CMsgPing::helper_1401647a0  @1401647a0  [medium:callgraph-r0]  (orig: FUN_1401647a0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1401647a0(longlong *param_1)

{
  undefined8 uVar1;
  ulonglong uVar2;
  
  uVar1 = (**(code **)(param_1[2] + 0x18))();
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  tq::MyLogSave("gmlog/zf_ping","ID[%u], Name[%s], IP[%d.%d.%d.%d], Ping[%u]",uVar2 & 0xffffffff,
                uVar1);
  return;
}

// ==== CMsgPing::ctor_or_dtor  @140455d00  [high:vtable-assign]  (orig: FUN_140455d00)
undefined8 * FUN_140455d00(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgPing::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgPing::ctor_or_dtor  @140455d50  [high:vtable-assign]  (orig: FUN_140455d50)
void FUN_140455d50(undefined8 *param_1)

{
  *param_1 = CMsgPing::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgPing::vfunc_1  @140455d80  [high:rtti-vtable]  (orig: FUN_140455d80)
ulonglong FUN_140455d80(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x40d);
}

// ==== CMsgPing::ctor_or_dtor  @140455db0  [high:vtable-assign]  (orig: FUN_140455db0)
undefined8 * FUN_140455db0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgPing::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgPing::vfunc_3  @140455e00  [high:rtti-vtable]  (orig: FUN_140455e00)
void FUN_140455e00(longlong param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar5 = (longlong *)
           (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x88))(*(longlong **)(lVar4 + 0x90),param_1)
  ;
  if (plVar5 != (longlong *)0x0) {
    plVar6 = (longlong *)FUN_1400e1e60();
    lVar2 = plVar5[0x1e2];
    lVar4 = *plVar6;
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    (**(code **)(lVar4 + 0x108))(plVar6,uVar3,(int)lVar2,*puVar1);
    if (*(char *)(*(longlong *)(param_1 + 0x428) + 4) == '\0') {
      FUN_1401647a0(plVar5,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc));
    }
  }
  return;
}

