// ==== CMsgInnerStrengthInfo::ctor_or_dtor  @1404dc330  [high:vtable-assign]  (orig: FUN_1404dc330)
undefined8 * FUN_1404dc330(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgInnerStrengthInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  param_1[0x86] = 0;
  return param_1;
}

// ==== CMsgInnerStrengthInfo::ctor_or_dtor  @1404dc380  [high:vtable-assign]  (orig: FUN_1404dc380)
void FUN_1404dc380(undefined8 *param_1)

{
  *param_1 = CMsgInnerStrengthInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgInnerStrengthInfo::vfunc_5  @1404dc3b0  [high:rtti-vtable]  (orig: FUN_1404dc3b0)
bool FUN_1404dc3b0(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xa33;
    }
  }
  return false;
}

// ==== CMsgInnerStrengthInfo::vfunc_3  @1404dc870  [high:rtti-vtable]  (orig: FUN_1404dc870)
void FUN_1404dc870(void)

{
  return;
}

// ==== CMsgInnerStrengthInfo::ctor_or_dtor  @1404dc880  [high:vtable-assign]  (orig: FUN_1404dc880)
undefined8 * FUN_1404dc880(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgInnerStrengthInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

