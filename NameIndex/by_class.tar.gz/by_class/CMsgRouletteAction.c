// ==== CMsgRouletteAction::helper_140205100  @140205100  [medium:callgraph-r0]  (orig: FUN_140205100)
void FUN_140205100(longlong param_1,longlong *param_2)

{
  undefined4 uVar1;
  longlong lVar2;
  char cVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 *puVar6;
  bool bVar7;
  undefined4 local_res18 [2];
  undefined4 local_res20 [2];
  undefined4 local_98;
  undefined4 uStack_94;
  longlong local_90;
  undefined8 local_88;
  longlong local_80;
  longlong *local_70 [3];
  undefined8 local_58;
  undefined8 local_50;
  undefined8 local_48;
  
  local_88 = 0xfffffffffffffffe;
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_res18[0] = (**(code **)(*param_2 + 8))(param_2);
    lVar5 = *(longlong *)(param_1 + 0x100);
    lVar2 = *(longlong *)(param_1 + 0xd0);
    local_80 = lVar2;
    plVar4 = (longlong *)FUN_140050f20(param_1 + 0xd0,local_70,local_res18);
    if ((*plVar4 == 0) || (*plVar4 != lVar2)) {
      _invalid_parameter_noinfo();
    }
    bVar7 = plVar4[1] != lVar5;
    local_res20[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_140050f20(param_1 + 0x110,&local_98,local_res20);
    lVar5 = *(longlong *)(param_1 + 0x140);
    local_70[0] = *(longlong **)(param_1 + 0x110);
    plVar4 = (longlong *)CONCAT44(uStack_94,local_98);
    if ((plVar4 == (longlong *)0x0) || (plVar4 != local_70[0])) {
      _invalid_parameter_noinfo();
    }
    if (local_90 != lVar5) {
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar4;
      }
      if (local_90 == *(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar1 = *(undefined4 *)(local_90 + 0x1c);
      lVar5 = FUN_1401ff5c0(param_1,uVar1);
      if (lVar5 == 0) {
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR(
                          "CRouletteMgr::WitnessJoinRoulette GetRoulette failed, idUser:%u, idNpc:%u, at %s, %d."
                          );
      }
      else {
        cVar3 = FUN_140412720(lVar5,param_2,bVar7,1);
        if ((cVar3 != '\0') && (!bVar7)) {
          local_58 = 0;
          local_98 = (**(code **)(*param_2 + 8))(param_2);
          uStack_94 = uVar1;
          puVar6 = (undefined8 *)FUN_1400507e0(param_1 + 0xd0,local_70,&local_98);
          local_58 = *puVar6;
          local_50 = puVar6[1];
          local_48 = puVar6[2];
          if ((char)local_48 == '\0') {
            (**(code **)(*param_2 + 8))(param_2);
            log_InlineLogERROR(
                              "CRouletteMgr::WitnessJoinRoulette m_mapRouletteUser insert failed, idUser:%u, idNpc:%u, at %s, %d."
                              );
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgRouletteAction::helper_140205720  @140205720  [medium:callgraph-r0]  (orig: FUN_140205720)
void FUN_140205720(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  longlong lVar4;
  int iVar5;
  longlong lVar6;
  undefined4 local_res18 [2];
  undefined4 local_res20 [2];
  longlong *local_58;
  longlong local_50;
  longlong *local_48;
  longlong *local_38 [2];
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar6 = 0;
  local_res18[0] = (**(code **)(*param_2 + 8))(param_2);
  FUN_140050f20(param_1 + 0xd0,&local_58,local_res18);
  plVar1 = local_58;
  lVar4 = *(longlong *)(param_1 + 0x100);
  local_48 = *(longlong **)(param_1 + 0xd0);
  if ((local_58 == (longlong *)0x0) || (local_58 != local_48)) {
    _invalid_parameter_noinfo();
  }
  lVar2 = local_50;
  if (local_50 != lVar4) {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = lVar6;
    }
    else {
      lVar4 = *plVar1;
    }
    if (lVar2 == *(longlong *)(lVar4 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    iVar5 = *(int *)(lVar2 + 0x1c);
    if (iVar5 != 0) goto LAB_1402058ac;
  }
  local_res20[0] = (**(code **)(*param_2 + 8))(param_2);
  puVar3 = (undefined8 *)FUN_140050f20(param_1 + 0x110,local_38,local_res20);
  plVar1 = (longlong *)*puVar3;
  local_50 = puVar3[1];
  lVar4 = *(longlong *)(param_1 + 0x140);
  local_38[0] = *(longlong **)(param_1 + 0x110);
  local_58 = plVar1;
  if ((plVar1 == (longlong *)0x0) || (plVar1 != local_38[0])) {
    _invalid_parameter_noinfo();
  }
  lVar2 = local_50;
  if (local_50 == lVar4) {
    return;
  }
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar6 = *plVar1;
  }
  if (lVar2 == *(longlong *)(lVar6 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  iVar5 = *(int *)(lVar2 + 0x1c);
  if (iVar5 == 0) {
    return;
  }
LAB_1402058ac:
  lVar4 = FUN_1401ff5c0(param_1,iVar5);
  if (lVar4 == 0) {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(
                      "CRouletteMgr::QueryProfitLossList GetRoulette failed, idUser:%u, idNpc:%u, at %s, %d."
                      );
  }
  else {
    FUN_14040af30(lVar4,param_2);
  }
  return;
}

// ==== CMsgRouletteAction::helper_140205910  @140205910  [medium:callgraph-r0]  (orig: FUN_140205910)
void FUN_140205910(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  longlong lVar4;
  int iVar5;
  longlong lVar6;
  undefined4 local_res18 [2];
  undefined4 local_res20 [2];
  longlong *local_58;
  longlong local_50;
  longlong *local_48;
  longlong *local_38 [2];
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar6 = 0;
  local_res18[0] = (**(code **)(*param_2 + 8))(param_2);
  FUN_140050f20(param_1 + 0xd0,&local_58,local_res18);
  plVar1 = local_58;
  lVar4 = *(longlong *)(param_1 + 0x100);
  local_48 = *(longlong **)(param_1 + 0xd0);
  if ((local_58 == (longlong *)0x0) || (local_58 != local_48)) {
    _invalid_parameter_noinfo();
  }
  lVar2 = local_50;
  if (local_50 != lVar4) {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = lVar6;
    }
    else {
      lVar4 = *plVar1;
    }
    if (lVar2 == *(longlong *)(lVar4 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    iVar5 = *(int *)(lVar2 + 0x1c);
    if (iVar5 != 0) goto LAB_140205a9c;
  }
  local_res20[0] = (**(code **)(*param_2 + 8))(param_2);
  puVar3 = (undefined8 *)FUN_140050f20(param_1 + 0x110,local_38,local_res20);
  plVar1 = (longlong *)*puVar3;
  local_50 = puVar3[1];
  lVar4 = *(longlong *)(param_1 + 0x140);
  local_38[0] = *(longlong **)(param_1 + 0x110);
  local_58 = plVar1;
  if ((plVar1 == (longlong *)0x0) || (plVar1 != local_38[0])) {
    _invalid_parameter_noinfo();
  }
  lVar2 = local_50;
  if (local_50 == lVar4) {
    return;
  }
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar6 = *plVar1;
  }
  if (lVar2 == *(longlong *)(lVar6 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  iVar5 = *(int *)(lVar2 + 0x1c);
  if (iVar5 == 0) {
    return;
  }
LAB_140205a9c:
  lVar4 = FUN_1401ff5c0(param_1,iVar5);
  if (lVar4 == 0) {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(
                      "CRouletteMgr::QueryWatcherList GetRoulette failed, idUser:%u, idNpc:%u, at %s, %d."
                      );
  }
  else {
    FUN_14040b0e0(lVar4,param_2);
  }
  return;
}

// ==== CMsgRouletteAction::helper_14040af30  @14040af30  [medium:callgraph-r1]  (orig: FUN_14040af30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14040af30(longlong param_1,longlong param_2)

{
  int iVar1;
  char cVar2;
  longlong lVar3;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  int local_468;
  longlong local_460;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  local_460 = param_2;
  if (param_2 == 0) {
    local_478 = 0x696;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(byte *)(param_1 + 0xe0) < 0x26) {
    FUN_1404dd5b0(local_448);
    cVar2 = FUN_1404dd660(local_448,*(undefined1 *)(param_1 + 0xe0));
    if (cVar2 == '\0') {
      log_InlineLogERROR("CRoulette::QueryProfitLossList msg create failed, last win num:%u.");
      FUN_1404dd600(local_448);
    }
    else {
      local_468 = 0;
      while (iVar1 = local_468, local_468 < 5) {
        lVar3 = (longlong)local_468 * 0x1c;
        if ((*(int *)(lVar3 + 0xe4 + param_1) != 0) &&
           (cVar2 = FUN_1404dd690(local_448,*(undefined4 *)(lVar3 + 0xf8 + param_1),
                                  *(undefined4 *)(((longlong)local_468 + 9) * 0x1c + param_1),
                                  lVar3 + 0xe8 + param_1), cVar2 == '\0')) {
          FUN_1404dd780(local_448);
          log_InlineLogERROR("CRoulette::QueryProfitLossList msg Append failed, data count:%u.");
          FUN_1404dd600(local_448);
          return;
        }
        local_468 = iVar1 + 1;
      }
      cVar2 = FUN_1404dd780(local_448);
      if (cVar2 != '\0') {
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_448)
        ;
      }
      FUN_1404dd600(local_448);
    }
  }
  return;
}

// ==== CMsgRouletteAction::helper_14040b0e0  @14040b0e0  [medium:callgraph-r1]  (orig: FUN_14040b0e0)
void FUN_14040b0e0(longlong param_1)

{
  FUN_1404dc9f0(*(undefined8 *)(param_1 + 0x188));
  return;
}

// ==== CMsgRouletteAction::ctor_or_dtor  @1404500a0  [high:vtable-assign]  (orig: FUN_1404500a0)
undefined8 * FUN_1404500a0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRouletteAction::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRouletteAction::ctor_or_dtor  @1404500f0  [high:vtable-assign]  (orig: FUN_1404500f0)
void FUN_1404500f0(undefined8 *param_1)

{
  *param_1 = CMsgRouletteAction::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRouletteAction::vfunc_1  @140450120  [high:rtti-vtable]  (orig: FUN_140450120)
ulonglong FUN_140450120(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xaf4);
}

// ==== CMsgRouletteAction::ctor_or_dtor  @140450170  [high:vtable-assign]  (orig: FUN_140450170)
undefined8 * FUN_140450170(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRouletteAction::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgRouletteAction::vfunc_3  @1404501c0  [high:rtti-vtable]  (orig: FUN_1404501c0)
void FUN_1404501c0(longlong param_1)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x88))(plVar3,param_1);
    if (lVar4 != 0) {
      cVar1 = **(char **)(param_1 + 0x428);
      if (cVar1 == '\0') {
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d8);
        }
        FUN_140205720(uVar2,lVar4);
      }
      else if (cVar1 == '\x01') {
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d8);
        }
        FUN_140205910(uVar2,lVar4);
      }
      else if (cVar1 == '\x02') {
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d8);
        }
        FUN_140207dc0(uVar2,lVar4,0);
      }
      else if (cVar1 == '\x03') {
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d8);
        }
        FUN_140205100(uVar2,lVar4);
      }
    }
  }
  return;
}

// ==== CMsgRouletteAction::helper_1404dc9f0  @1404dc9f0  [medium:callgraph-r2]  (orig: FUN_1404dc9f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404dc9f0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_2 == 0) {
    local_478 = 0x96;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_1 + 0x40) != 0) {
    FUN_1404f6aa0(local_458);
    cVar4 = FUN_1404f6b50(local_458);
    if (cVar4 == '\0') {
      log_InlineLogERROR("CRouletteWitnessMgr::QueryWatcherList msg create failed.");
      FUN_1404f6af0(local_458);
    }
    else {
      plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x38);
      plVar1 = *(longlong **)(param_1 + 8);
      while( true ) {
        plVar2 = *(longlong **)(param_1 + 0x38);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
          _invalid_parameter_noinfo();
        }
        if (plVar5 == plVar2) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *plVar1;
        }
        if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if ((int)plVar5[3] != 0) {
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar1;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          FUN_1404f6b70(local_458,(int)plVar5[3]);
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar5 + 0x1d) == '\0') {
          plVar2 = (longlong *)plVar5[2];
          if (*(char *)((longlong)plVar2 + 0x1d) == '\0') {
            cVar4 = *(char *)(*plVar2 + 0x1d);
            plVar5 = plVar2;
            plVar2 = (longlong *)*plVar2;
            while (cVar4 == '\0') {
              cVar4 = *(char *)(*plVar2 + 0x1d);
              plVar5 = plVar2;
              plVar2 = (longlong *)*plVar2;
            }
          }
          else {
            cVar4 = *(char *)(plVar5[1] + 0x1d);
            plVar3 = (longlong *)plVar5[1];
            plVar2 = plVar5;
            while ((plVar5 = plVar3, cVar4 == '\0' && (plVar2 == (longlong *)plVar5[2]))) {
              cVar4 = *(char *)(plVar5[1] + 0x1d);
              plVar3 = (longlong *)plVar5[1];
              plVar2 = plVar5;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      cVar4 = FUN_1404f6c20(local_458);
      if (cVar4 != '\0') {
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_458)
        ;
      }
      FUN_1404f6af0(local_458);
    }
  }
  return;
}

// ==== CMsgRouletteAction::helper_1404dd660  @1404dd660  [medium:callgraph-r2]  (orig: FUN_1404dd660)
undefined8 FUN_1404dd660(longlong param_1,undefined1 param_2)

{
  undefined1 *puVar1;
  
  *(undefined4 *)(param_1 + 0xc) = 2;
  *(undefined4 *)(param_1 + 8) = 0xaf2;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = 0;
  puVar1 = *(undefined1 **)(param_1 + 0x428);
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMsgRouletteAction::helper_1404dd690  @1404dd690  [medium:callgraph-r2]  (orig: FUN_1404dd690)
ulonglong FUN_1404dd690(longlong param_1,undefined4 param_2,undefined4 param_3,char *param_4)

{
  char *pcVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  undefined7 extraout_var;
  
  if (0x3ff < (longlong)*(int *)(param_1 + 0xc) + 0x18U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x18;
  *(undefined4 *)(lVar2 + 2 + (ulonglong)*(byte *)(lVar2 + 1) * 0x18) = param_2;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 6 +
   (ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 1) * 0x18) = param_3;
  tq::StrCopy((char *)(*(longlong *)(param_1 + 0x428) + 10 +
                      (ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 1) * 0x18),param_4,0x10)
  ;
  pcVar1 = (char *)(*(longlong *)(param_1 + 0x428) + 1);
  *pcVar1 = *pcVar1 + '\x01';
  return CONCAT71(extraout_var,1);
}

// ==== CMsgRouletteAction::helper_1404dd780  @1404dd780  [medium:callgraph-r2]  (orig: FUN_1404dd780)
undefined8 FUN_1404dd780(longlong param_1)

{
  return CONCAT71((int7)((ulonglong)*(longlong *)(param_1 + 0x428) >> 8),
                  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1));
}

// ==== CMsgRouletteAction::helper_1404f6b50  @1404f6b50  [medium:callgraph-r3]  (orig: FUN_1404f6b50)
undefined8 FUN_1404f6b50(longlong param_1)

{
  undefined1 *puVar1;
  
  puVar1 = *(undefined1 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 0xc) = 1;
  *(undefined4 *)(param_1 + 8) = 0xaf3;
  *puVar1 = 0;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMsgRouletteAction::helper_1404f6b70  @1404f6b70  [medium:callgraph-r3]  (orig: FUN_1404f6b70)
ulonglong FUN_1404f6b70(longlong param_1,undefined4 param_2)

{
  byte *pbVar1;
  char *pcVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  
  if (0x3ff < (longlong)*(int *)(param_1 + 0xc) + 4U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  pbVar1 = *(byte **)(param_1 + 0x428);
  if (pbVar1 == (byte *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 4;
  *(undefined4 *)(pbVar1 + (ulonglong)*pbVar1 * 4 + 1) = param_2;
  pcVar2 = *(char **)(param_1 + 0x428);
  *pcVar2 = *pcVar2 + '\x01';
  return CONCAT71((int7)((ulonglong)pcVar2 >> 8),1);
}

// ==== CMsgRouletteAction::helper_1404f6c20  @1404f6c20  [medium:callgraph-r3]  (orig: FUN_1404f6c20)
undefined8 FUN_1404f6c20(longlong param_1)

{
  return CONCAT71((int7)((ulonglong)*(undefined1 **)(param_1 + 0x428) >> 8),
                  **(undefined1 **)(param_1 + 0x428));
}

