// ==== CMsgSameGroupServerList::ctor_or_dtor  @1402c36e0  [high:vtable-assign]  (orig: FUN_1402c36e0)
undefined8 * FUN_1402c36e0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgSameGroupServerList::vftable;
  FUN_140575a70(param_1 + 0x85);
  FUN_1402b5600(param_1);
  return param_1;
}

// ==== CMsgSameGroupServerList::ctor_or_dtor  @1402c3730  [high:vtable-assign]  (orig: FUN_1402c3730)
void FUN_1402c3730(undefined8 *param_1)

{
  *param_1 = CMsgSameGroupServerList::vftable;
  FUN_140575ae0(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgSameGroupServerList::ctor_or_dtor  @1402c38d0  [high:vtable-assign]  (orig: FUN_1402c38d0)
undefined8 * FUN_1402c38d0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgSameGroupServerList::vftable;
  FUN_140575ae0(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

