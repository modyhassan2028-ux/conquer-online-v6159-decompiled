// ==== CMsgRelation::ctor_or_dtor  @1403f0a00  [high:vtable-assign]  (orig: FUN_1403f0a00)
undefined8 * FUN_1403f0a00(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRelation::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRelation::ctor_or_dtor  @1403f0a50  [high:vtable-assign]  (orig: FUN_1403f0a50)
void FUN_1403f0a50(undefined8 *param_1)

{
  *param_1 = CMsgRelation::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRelation::vfunc_1  @1403f0a80  [high:rtti-vtable]  (orig: FUN_1403f0a80)
bool FUN_1403f0a80(longlong param_1,longlong param_2,int param_3)

{
  int iVar1;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x817;
    }
  }
  return false;
}

// ==== CMsgRelation::vfunc_3  @1403f0be0  [high:rtti-vtable]  (orig: FUN_1403f0be0)
void FUN_1403f0be0(void)

{
  return;
}

// ==== CMsgRelation::ctor_or_dtor  @1403f0bf0  [high:vtable-assign]  (orig: FUN_1403f0bf0)
undefined8 * FUN_1403f0bf0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRelation::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

