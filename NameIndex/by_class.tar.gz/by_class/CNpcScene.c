// ==== CNpcScene::helper_1402c7270  @1402c7270  [medium:callgraph-r0]  (orig: FUN_1402c7270)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1402c7270(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong *plVar4;
  undefined8 uVar5;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined2 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  cVar1 = (**(code **)(*(longlong *)param_1[0xc] + 0x50))();
  if (cVar1 == '\0') {
    uVar5 = 0;
  }
  else {
    FUN_140362560(local_478);
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    local_490 = 0;
    local_4a0 = 0xcc;
    local_4a8 = (uint)local_4a8._2_2_ << 0x10;
    local_498 = param_2;
    iVar3 = FUN_140362620(local_478,uVar2,0,0);
    if (iVar3 == 0) {
      local_4a8 = 0x72c;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar4 = (longlong *)FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
      (**(code **)(*plVar4 + 0x30))(plVar4,0,local_478);
    }
    FUN_1403625e0(local_478);
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CNpcScene::helper_14046a300  @14046a300  [medium:callgraph-r0]  (orig: FUN_14046a300)
void FUN_14046a300(void *param_1)

{
  if ((DAT_140976448 & 1) == 0) {
    DAT_140976448 = DAT_140976448 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976440,"CNpcScene");
    atexit((_func_5014 *)&LAB_1406d6e50);
  }
                    /* WARNING: Could not recover jumptable at 0x00014046a355. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976440,param_1);
  return;
}

// ==== CNpcScene::ctor_or_dtor  @14046a3c0  [high:vtable-assign]  (orig: FUN_14046a3c0)
undefined8 * FUN_14046a3c0(undefined8 *param_1)

{
  *param_1 = CNpcScene::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  return param_1;
}

// ==== CNpcScene::ctor_or_dtor  @14046a3e0  [high:vtable-assign]  (orig: FUN_14046a3e0)
void FUN_14046a3e0(undefined8 *param_1)

{
  undefined4 uVar1;
  
  *param_1 = CNpcScene::vftable;
  if ((((longlong *)param_1[1] != (longlong *)0x0) && (param_1[2] != 0)) &&
     (*(int *)(param_1 + 3) != 0)) {
    *(undefined4 *)(param_1 + 3) = 0;
    uVar1 = (**(code **)(*(longlong *)param_1[1] + 8))();
    FUN_1402c7270(param_1[2],uVar1);
  }
  return;
}

// ==== CNpcScene::ctor_or_dtor  @14046a520  [high:vtable-assign]  (orig: FUN_14046a520)
undefined8 * FUN_14046a520(undefined8 *param_1,ulonglong param_2)

{
  undefined4 uVar1;
  
  *param_1 = CNpcScene::vftable;
  if ((((longlong *)param_1[1] != (longlong *)0x0) && (param_1[2] != 0)) &&
     (*(int *)(param_1 + 3) != 0)) {
    *(undefined4 *)(param_1 + 3) = 0;
    uVar1 = (**(code **)(*(longlong *)param_1[1] + 8))();
    FUN_1402c7270(param_1[2],uVar1);
  }
  if ((param_2 & 1) != 0) {
    FUN_14046a300(param_1);
  }
  return param_1;
}

