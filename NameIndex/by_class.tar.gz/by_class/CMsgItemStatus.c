// ==== CMsgItemStatus::ctor_or_dtor  @1403b6000  [high:vtable-assign]  (orig: FUN_1403b6000)
undefined8 * FUN_1403b6000(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgItemStatus::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgItemStatus::ctor_or_dtor  @1403b6050  [high:vtable-assign]  (orig: FUN_1403b6050)
void FUN_1403b6050(undefined8 *param_1)

{
  *param_1 = CMsgItemStatus::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgItemStatus::vfunc_1  @1403b6080  [high:rtti-vtable]  (orig: FUN_1403b6080)
undefined8 FUN_1403b6080(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgItemStatus::vfunc_3  @1403b62e0  [high:rtti-vtable]  (orig: FUN_1403b62e0)
void FUN_1403b62e0(void)

{
  return;
}

// ==== CMsgItemStatus::ctor_or_dtor  @1403b62f0  [high:vtable-assign]  (orig: FUN_1403b62f0)
undefined8 * FUN_1403b62f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgItemStatus::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

