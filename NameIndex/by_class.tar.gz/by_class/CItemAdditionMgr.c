// ==== CItemAdditionMgr::helper_1404c5150  @1404c5150  [medium:callgraph-r0]  (orig: FUN_1404c5150)
void FUN_1404c5150(void *param_1)

{
  if ((DAT_1409764f8 & 1) == 0) {
    DAT_1409764f8 = DAT_1409764f8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409764f0,"CItemAdditionMgr");
    atexit((_func_5014 *)&LAB_1406d6f00);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404c51a5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409764f0,param_1);
  return;
}

// ==== CItemAdditionMgr::helper_1404c54b0  @1404c54b0  [medium:callgraph-r0]  (orig: FUN_1404c54b0)
void FUN_1404c54b0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1404c54b0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CItemAdditionMgr::helper_1404c5680  @1404c5680  [medium:callgraph-r1]  (orig: FUN_1404c5680)
void FUN_1404c5680(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1404c54b0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CItemAdditionMgr::helper_1404c62d0  @1404c62d0  [medium:callgraph-r0]  (orig: FUN_1404c62d0)
longlong * FUN_1404c62d0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1404c5680(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1404c5e20(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CItemAdditionMgr::ctor_or_dtor  @1404c6ca0  [high:vtable-assign]  (orig: FUN_1404c6ca0)
void FUN_1404c6ca0(undefined8 *param_1)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong local_38;
  undefined8 *puStack_30;
  longlong local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  uVar9 = 0xfffffffffffffffe;
  *param_1 = CItemAdditionMgr::vftable;
  plVar1 = param_1 + 1;
  plVar3 = (longlong *)*plVar1;
  plVar4 = *(longlong **)param_1[7];
  do {
    do {
      while( true ) {
        while( true ) {
          plVar7 = plVar4;
          plVar4 = (longlong *)param_1[7];
          if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
            _invalid_parameter_noinfo();
          }
          if (plVar7 == plVar4) {
            cVar2 = *(char *)((longlong)*(longlong **)(param_1[7] + 8) + 0x29);
            plVar3 = *(longlong **)(param_1[7] + 8);
            while (cVar2 == '\0') {
              FUN_1404c54b0(plVar1,plVar3[2]);
              plVar4 = (longlong *)*plVar3;
              operator_delete(plVar3);
              plVar3 = plVar4;
              cVar2 = *(char *)((longlong)plVar4 + 0x29);
            }
            *(undefined8 *)(param_1[7] + 8) = param_1[7];
            param_1[8] = 0;
            *(undefined8 *)param_1[7] = param_1[7];
            *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
            puStack_30 = (undefined8 *)param_1[7];
            local_38 = *plVar1;
            uStack_20 = *puStack_30;
            local_28 = local_38;
            FUN_1404c62d0(plVar1,local_18,&local_28,&local_38,uVar9);
            operator_delete((void *)param_1[7]);
            param_1[7] = 0;
            param_1[8] = 0;
            operator_delete((void *)*plVar1);
            return;
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = 0;
          }
          else {
            lVar8 = *plVar3;
          }
          if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          puVar5 = (undefined8 *)plVar7[4];
          if (puVar5 != (undefined8 *)0x0) {
            (**(code **)*puVar5)(puVar5,1);
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar7 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar4 = plVar7;
        }
        plVar4 = (longlong *)plVar7[2];
        if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
        cVar2 = *(char *)(*plVar4 + 0x29);
        plVar7 = (longlong *)*plVar4;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*plVar7 + 0x29);
          plVar4 = plVar7;
          plVar7 = (longlong *)*plVar7;
        }
      }
      plVar4 = (longlong *)plVar7[1];
    } while (*(char *)((longlong)plVar4 + 0x29) != '\0');
    do {
      plVar6 = plVar4;
      plVar4 = plVar6;
      if (plVar7 != (longlong *)plVar6[2]) break;
      plVar4 = (longlong *)plVar6[1];
      plVar7 = plVar6;
    } while (*(char *)((longlong)plVar4 + 0x29) == '\0');
  } while( true );
}

// ==== CItemAdditionMgr::vfunc_0  @1404c6f40  [high:rtti-vtable]  (orig: FUN_1404c6f40)
undefined8 FUN_1404c6f40(undefined8 param_1,uint param_2)

{
  FUN_1404c6ca0();
  if ((param_2 & 1) != 0) {
    FUN_1404c5150(param_1);
  }
  return param_1;
}

