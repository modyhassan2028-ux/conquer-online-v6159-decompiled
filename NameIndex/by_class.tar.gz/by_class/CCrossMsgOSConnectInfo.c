// ==== CCrossMsgOSConnectInfo::helper_1400b39e0  @1400b39e0  [medium:callgraph-r0]  (orig: FUN_1400b39e0)
void FUN_1400b39e0(longlong param_1,uint param_2,char param_3)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  ulonglong *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong lVar6;
  char cVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  undefined8 uVar13;
  undefined8 *puVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  longlong *local_res8;
  uint local_res10 [2];
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  ulonglong *local_38;
  longlong local_30;
  
  puVar2 = *(undefined8 **)(param_1 + 0x468);
  cVar7 = *(char *)((longlong)puVar2[1] + 0x49);
  puVar5 = puVar2;
  puVar14 = (undefined8 *)puVar2[1];
  while (cVar7 == '\0') {
    if (*(uint *)(puVar14 + 3) < param_2) {
      puVar11 = (undefined8 *)puVar14[2];
      puVar14 = puVar5;
    }
    else {
      puVar11 = (undefined8 *)*puVar14;
    }
    puVar5 = puVar14;
    puVar14 = puVar11;
    cVar7 = *(char *)((longlong)puVar11 + 0x49);
  }
  local_50 = puVar5;
  local_58 = *(longlong *)(param_1 + 0x438);
  local_res10[0] = param_2;
  if (*(longlong *)(param_1 + 0x438) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar2) || (local_res10[0] < *(uint *)(puVar5 + 3))) {
    plVar12 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0x468);
    local_48 = *(longlong *)(param_1 + 0x438);
  }
  else {
    plVar12 = &local_58;
  }
  puVar3 = (ulonglong *)*plVar12;
  lVar4 = *(longlong *)(param_1 + 0x468);
  local_38 = puVar3;
  local_30 = plVar12[1];
  if ((puVar3 == (ulonglong *)0x0) || (puVar3 != *(ulonglong **)(param_1 + 0x438))) {
    _invalid_parameter_noinfo();
  }
  lVar6 = local_30;
  if (local_30 != lVar4) {
    uVar15 = 0;
    uVar9 = 0;
    uVar10 = 0;
    if (puVar3 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar16 = uVar15;
    }
    else {
      uVar16 = *puVar3;
    }
    if (lVar6 == *(longlong *)(uVar16 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *(char *)(lVar6 + 0x30) = param_3;
    if (param_3 == '\0') {
      uVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
      uVar13 = FUN_140087650(uVar13);
      FUN_1402b3aa0(uVar13,local_res10[0],0);
      (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                (*(longlong **)(param_1 + 0x80),6,0x3f1,4,local_res10);
    }
    else {
      plVar12 = (longlong *)CurrentInstanceGet();
      if (((plVar12 != (longlong *)0x0) && (*(char *)(param_1 + 0x77c) != '\0')) &&
         (plVar12 = (longlong *)(**(code **)(*plVar12 + 0x20))(plVar12,0x25),
         plVar12 != (longlong *)0x0)) {
        (**(code **)(*plVar12 + 0x50))(plVar12,local_res10[0]);
      }
    }
    if (*(char *)(param_1 + 0x77c) != '\0') {
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar16 = uVar15;
      }
      else {
        uVar16 = *puVar3;
      }
      if (lVar6 == *(longlong *)(uVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar1 = *(undefined4 *)(lVar6 + 0x44);
      uVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
      plVar12 = (longlong *)FUN_1400875f0(uVar13);
      plVar12 = (longlong *)(**(code **)(*plVar12 + 0x30))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar12 + 0x40))(plVar12,uVar1);
      if ((plVar12 == (longlong *)0x0) ||
         (cVar7 = (**(code **)(*plVar12 + 0x298))(plVar12,0x1040,&local_res8), cVar7 == '\0')) {
        log_InlineLogERROR("CMapGroup::SetOSConnectStatus, idNpcRecord[%u] npc not find.");
      }
      else {
        if (param_3 == '\0') {
          uVar8 = (**(code **)(*local_res8 + 0x28))();
          uVar15 = (ulonglong)uVar8;
          uVar9 = (**(code **)(*local_res8 + 0x30))();
          uVar10 = (**(code **)(*local_res8 + 0x38))();
        }
        else {
          if (local_res8[0xc] == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            uVar8 = (**(code **)(*(longlong *)local_res8[0xc] + 0x10))
                              ((longlong *)local_res8[0xc],0x13);
            uVar15 = (ulonglong)uVar8;
          }
          if (local_res8[0xc] == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            uVar9 = (**(code **)(*(longlong *)local_res8[0xc] + 0x10))
                              ((longlong *)local_res8[0xc],0x14);
          }
          if (local_res8[0xc] == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            uVar10 = (**(code **)(*(longlong *)local_res8[0xc] + 0x10))
                               ((longlong *)local_res8[0xc],0x15);
          }
        }
        cVar7 = FUN_1402bf7a0(local_res8,uVar15,uVar9,uVar10);
        if (cVar7 == '\0') {
          log_InlineLogERROR(
                            "CMapGroup::SetOSConnectStatus, idNpcRecord[%u] idMap[%u] nPosX[%d] nPosY[%d] change pos error."
                            );
        }
      }
    }
    return;
  }
  log_InlineLogERROR("CMapGroup::SetOSConnectStatus not found server id, idServer:%u.");
  return;
}

// ==== CCrossMsgOSConnectInfo::ctor_or_dtor  @1404612d0  [high:vtable-assign]  (orig: FUN_1404612d0)
undefined8 * FUN_1404612d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgOSConnectInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgOSConnectInfo::ctor_or_dtor  @140461320  [high:vtable-assign]  (orig: FUN_140461320)
void FUN_140461320(undefined8 *param_1)

{
  *param_1 = CCrossMsgOSConnectInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgOSConnectInfo::vfunc_1  @140461350  [high:rtti-vtable]  (orig: FUN_140461350)
undefined8 FUN_140461350(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgOSConnectInfo::ctor_or_dtor  @1404614c0  [high:vtable-assign]  (orig: FUN_1404614c0)
undefined8 * FUN_1404614c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgOSConnectInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgOSConnectInfo::vfunc_3  @140461510  [high:rtti-vtable]  (orig: FUN_140461510)
void FUN_140461510(longlong param_1)

{
  int iVar1;
  undefined8 uVar2;
  short *psVar3;
  uint uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  
  psVar3 = *(short **)(param_1 + 0x428);
  if (psVar3 != (short *)0x0) {
    if (*psVar3 == 0) {
      uVar5 = 0;
      uVar6 = uVar5;
      if ((char)psVar3[1] != '\0') {
        do {
          iVar1 = *(int *)(uVar6 + 4 + (longlong)psVar3);
          if ((iVar1 != 0) && (iVar1 != -1)) {
            uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            FUN_1400b39e0(uVar2,iVar1,1);
          }
          psVar3 = *(short **)(param_1 + 0x428);
          uVar4 = (int)uVar5 + 1;
          uVar5 = (ulonglong)uVar4;
          uVar6 = uVar6 + 4;
        } while ((int)uVar4 < (int)(uint)*(byte *)(psVar3 + 1));
      }
    }
    else if ((*psVar3 == 1) && (uVar5 = 0, uVar6 = uVar5, (char)psVar3[1] != '\0')) {
      do {
        iVar1 = *(int *)(uVar6 + 4 + (longlong)psVar3);
        if ((iVar1 != 0) && (iVar1 != -1)) {
          uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          FUN_1400b39e0(uVar2,iVar1,0);
        }
        psVar3 = *(short **)(param_1 + 0x428);
        uVar4 = (int)uVar5 + 1;
        uVar5 = (ulonglong)uVar4;
        uVar6 = uVar6 + 4;
      } while ((int)uVar4 < (int)(uint)*(byte *)(psVar3 + 1));
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

