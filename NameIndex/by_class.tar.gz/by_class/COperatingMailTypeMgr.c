// ==== COperatingMailTypeMgr::helper_1402723c0  @1402723c0  [medium:callgraph-r2]  (orig: FUN_1402723c0)
void FUN_1402723c0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x189) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== COperatingMailTypeMgr::helper_1402725b0  @1402725b0  [medium:callgraph-r2]  (orig: FUN_1402725b0)
void FUN_1402725b0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x189) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x189) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x189);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x189);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x189);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x189);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402725d7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== COperatingMailTypeMgr::helper_140272780  @140272780  [medium:callgraph-r2]  (orig: FUN_140272780)
void FUN_140272780(longlong *param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)param_1[1];
  if (*(char *)((longlong)plVar2 + 0x189) == '\0') {
    lVar3 = *plVar2;
    if (*(char *)(lVar3 + 0x189) == '\0') {
      cVar1 = *(char *)(*(longlong *)(lVar3 + 0x10) + 0x189);
      lVar4 = *(longlong *)(lVar3 + 0x10);
      while (cVar1 == '\0') {
        cVar1 = *(char *)(*(longlong *)(lVar4 + 0x10) + 0x189);
        lVar3 = lVar4;
        lVar4 = *(longlong *)(lVar4 + 0x10);
      }
      param_1[1] = lVar3;
      return;
    }
    plVar2 = (longlong *)plVar2[1];
    cVar1 = *(char *)((longlong)plVar2 + 0x189);
    while ((cVar1 == '\0' && (param_1[1] == *plVar2))) {
      param_1[1] = (longlong)plVar2;
      plVar2 = (longlong *)plVar2[1];
      cVar1 = *(char *)((longlong)plVar2 + 0x189);
    }
    if (*(char *)(param_1[1] + 0x189) == '\0') {
      param_1[1] = (longlong)plVar2;
      return;
    }
  }
  else {
    lVar3 = plVar2[2];
    param_1[1] = lVar3;
    if (*(char *)(lVar3 + 0x189) == '\0') {
      return;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0001402727b8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== COperatingMailTypeMgr::helper_140272c40  @140272c40  [medium:callgraph-r2]  (orig: FUN_140272c40)
void FUN_140272c40(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x189) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== COperatingMailTypeMgr::helper_140273160  @140273160  [medium:callgraph-r1]  (orig: FUN_140273160)
void FUN_140273160(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x189);
  while (cVar1 == '\0') {
    FUN_140273160(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x189);
  }
  return;
}

// ==== COperatingMailTypeMgr::helper_140273260  @140273260  [medium:callgraph-r3]  (orig: FUN_140273260)
undefined8 *
FUN_140273260(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             void *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(400);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    memcpy(puVar1 + 3,param_5,0x170);
    *(undefined1 *)(puVar1 + 0x31) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x189) = 0;
  }
  return puVar1;
}

// ==== COperatingMailTypeMgr::helper_140273480  @140273480  [medium:callgraph-r1]  (orig: FUN_140273480)
void FUN_140273480(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(400);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 0x31) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x189) = 0;
  return;
}

// ==== COperatingMailTypeMgr::helper_140273620  @140273620  [medium:callgraph-r0]  (orig: FUN_140273620)
void FUN_140273620(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x189);
  while (cVar1 == '\0') {
    FUN_140273160(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x189);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== COperatingMailTypeMgr::helper_140273b50  @140273b50  [medium:callgraph-r2]  (orig: FUN_140273b50)
undefined8 *
FUN_140273b50(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xb21642c8590b1f < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140273260(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x188);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x188) == '\0') {
        *(undefined1 *)(plVar2 + 0x31) = 1;
        *(undefined1 *)(lVar4 + 0x188) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x188) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x189) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x188) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x188) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x189) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x188) == '\0') {
        *(undefined1 *)(plVar2 + 0x31) = 1;
        *(undefined1 *)(lVar4 + 0x188) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x188) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x189) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x188) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x188) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x189) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x188);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x188) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== COperatingMailTypeMgr::helper_140273f90  @140273f90  [medium:callgraph-r1]  (orig: FUN_140273f90)
longlong * FUN_140273f90(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  bool bVar4;
  longlong local_28;
  undefined8 *local_20;
  
  puVar3 = (undefined8 *)param_1[6];
  bVar4 = true;
  if (*(char *)((longlong)puVar3[1] + 0x189) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      puVar3 = puVar1;
      bVar4 = *param_3 < *(uint *)(puVar3 + 3);
      if (bVar4) {
        puVar1 = (undefined8 *)*puVar3;
      }
      else {
        puVar1 = (undefined8 *)puVar3[2];
      }
    } while (*(char *)((longlong)puVar1 + 0x189) == '\0');
  }
  local_28 = *param_1;
  local_20 = puVar3;
  if (bVar4 == false) {
LAB_140274052:
    if (*param_3 <= *(uint *)(local_20 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_28;
      goto LAB_14027407c;
    }
  }
  else {
    puVar1 = *(undefined8 **)param_1[6];
    if (local_28 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar3 != puVar1) {
      FUN_140272780(&local_28);
      goto LAB_140274052;
    }
    bVar4 = true;
  }
  plVar2 = (longlong *)FUN_140273b50(param_1,&local_28,bVar4,puVar3,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_20 = (undefined8 *)plVar2[1];
  *param_2 = *plVar2;
LAB_14027407c:
  param_2[1] = (longlong)local_20;
  return param_2;
}

// ==== COperatingMailTypeMgr::helper_1402740a0  @1402740a0  [medium:callgraph-r1]  (orig: FUN_1402740a0)
undefined8 * FUN_1402740a0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x189) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402725b0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x189) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x189) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x189) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0x31;
        plVar8 = plVar8 + 0x31;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1402742ab;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x189) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x189) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x189);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x189);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x189) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x189);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x189);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1402742ab:
  if ((char)plVar2[0x31] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0x31] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0x31] == '\0') {
            *(undefined1 *)(plVar9 + 0x31) = 1;
            *(undefined1 *)(plVar8 + 0x31) = 0;
            FUN_140272c40(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x189) == '\0') {
            if ((*(char *)(*plVar9 + 0x188) != '\x01') || (*(char *)(plVar9[2] + 0x188) != '\x01'))
            {
              if (*(char *)(plVar9[2] + 0x188) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x188) = 1;
                *(undefined1 *)(plVar9 + 0x31) = 0;
                FUN_1402723c0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0x31) = (char)plVar8[0x31];
              *(undefined1 *)(plVar8 + 0x31) = 1;
              *(undefined1 *)(plVar9[2] + 0x188) = 1;
              FUN_140272c40(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0x31) = 0;
          }
        }
        else {
          if ((char)plVar9[0x31] == '\0') {
            *(undefined1 *)(plVar9 + 0x31) = 1;
            *(undefined1 *)(plVar8 + 0x31) = 0;
            FUN_1402723c0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x189) == '\0') {
            if ((*(char *)(plVar9[2] + 0x188) != '\x01') || (*(char *)(*plVar9 + 0x188) != '\x01'))
            {
              if (*(char *)(*plVar9 + 0x188) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x188) = 1;
                *(undefined1 *)(plVar9 + 0x31) = 0;
                FUN_140272c40(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0x31) = (char)plVar8[0x31];
              *(undefined1 *)(plVar8 + 0x31) = 1;
              *(undefined1 *)(*plVar9 + 0x188) = 1;
              FUN_1402723c0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0x31) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0x31) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== COperatingMailTypeMgr::helper_140274a30  @140274a30  [medium:callgraph-r0]  (orig: FUN_140274a30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140274a30(longlong param_1)

{
  ulong uVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  char *pcVar5;
  ulonglong uVar6;
  undefined8 uVar7;
  int iVar8;
  undefined1 auStack_758 [32];
  ulong local_738;
  undefined8 local_728;
  undefined1 local_720 [24];
  undefined4 local_708;
  undefined1 local_704 [364];
  undefined4 local_598;
  undefined4 local_594;
  undefined4 local_590;
  undefined4 local_58c;
  undefined2 local_588;
  undefined2 local_586;
  undefined1 local_584;
  char local_583 [319];
  undefined4 local_444;
  undefined4 local_440;
  undefined4 local_43c;
  undefined4 local_438;
  undefined4 local_434;
  undefined1 local_430;
  char local_428;
  undefined1 local_427 [1022];
  undefined1 local_29;
  ulonglong local_28;
  
  local_728 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_758;
  uVar1 = tq::TimeGet(2);
  local_428 = '\0';
  memset(local_427,0,0x3ff);
  local_738 = uVar1;
  _snprintf(&local_428,0x3ff,
            "SELECT * FROM cq_operating_mail_type where start_time <= %u AND end_time > %u");
  local_29 = 0;
  plVar2 = (longlong *)InstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,&local_428,1);
  uVar7 = 0;
  if (plVar2 != (longlong *)0x0) {
    iVar8 = 0;
    lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
    if (lVar3 != 0) {
      do {
        (**(code **)(*plVar2 + 0x30))(plVar2);
        local_598 = 0;
        local_594 = 0;
        local_590 = 0;
        local_58c = 0;
        local_588 = 0;
        local_586 = 0;
        local_584 = 0;
        local_583[0] = '\0';
        local_583[1] = '\0';
        local_583[2] = '\0';
        local_583[3] = '\0';
        local_583[4] = '\0';
        local_583[5] = '\0';
        local_583[6] = '\0';
        local_583[7] = '\0';
        local_583[8] = '\0';
        local_583[9] = '\0';
        local_583[10] = '\0';
        local_583[0xb] = '\0';
        local_583[0xc] = '\0';
        local_583[0xd] = '\0';
        local_583[0xe] = '\0';
        local_583[0xf] = '\0';
        local_583[0x10] = '\0';
        local_583[0x11] = '\0';
        local_583[0x12] = '\0';
        local_583[0x13] = '\0';
        local_583[0x14] = '\0';
        local_583[0x15] = '\0';
        local_583[0x16] = '\0';
        local_583[0x17] = '\0';
        local_583[0x18] = '\0';
        local_583[0x19] = '\0';
        local_583[0x1a] = '\0';
        local_583[0x1b] = '\0';
        local_583[0x1c] = '\0';
        local_583[0x1d] = '\0';
        local_583[0x1e] = '\0';
        local_583[0x1f] = '\0';
        local_583[0x20] = '\0';
        local_583[0x21] = '\0';
        local_583[0x22] = '\0';
        local_583[0x23] = '\0';
        local_583[0x24] = '\0';
        local_583[0x25] = '\0';
        local_583[0x26] = '\0';
        local_583[0x27] = '\0';
        local_583[0x28] = '\0';
        local_583[0x29] = '\0';
        local_583[0x2a] = '\0';
        local_583[0x2b] = '\0';
        local_583[0x2c] = '\0';
        local_583[0x2d] = '\0';
        local_583[0x2e] = '\0';
        local_583[0x2f] = '\0';
        local_583[0x30] = '\0';
        local_583[0x31] = '\0';
        local_583[0x32] = '\0';
        local_583[0x33] = '\0';
        local_583[0x34] = '\0';
        local_583[0x35] = '\0';
        local_583[0x36] = '\0';
        local_583[0x37] = '\0';
        local_583[0x38] = '\0';
        local_583[0x39] = '\0';
        local_583[0x3a] = '\0';
        local_583[0x3b] = '\0';
        local_583[0x3c] = '\0';
        local_583[0x3d] = '\0';
        local_583[0x3e] = '\0';
        local_583[0x3f] = '\0';
        memset(local_583 + 0x40,0,0xff);
        local_444 = 0;
        local_440 = 0;
        local_43c = 0;
        local_438 = 0;
        local_434 = 0;
        local_430 = 0;
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0);
        local_598 = (**(code **)(*plVar4 + 0x50))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,1);
        local_594 = (**(code **)(*plVar4 + 0x50))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
        local_590 = (**(code **)(*plVar4 + 0x50))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,3);
        local_58c = (**(code **)(*plVar4 + 0x50))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,4);
        local_588 = (**(code **)(*plVar4 + 0x30))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,5);
        local_586 = (**(code **)(*plVar4 + 0x30))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,6);
        local_584 = (**(code **)(*plVar4 + 0x20))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,7);
        pcVar5 = (char *)(**(code **)(*plVar4 + 0x78))(plVar4);
        tq::SafeCopy(local_583,pcVar5,0x20);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,8);
        pcVar5 = (char *)(**(code **)(*plVar4 + 0x78))(plVar4);
        tq::SafeCopy(local_583 + 0x20,pcVar5,0x20);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,9);
        pcVar5 = (char *)(**(code **)(*plVar4 + 0x78))(plVar4);
        tq::SafeCopy(local_583 + 0x40,pcVar5,0xff);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,10);
        local_444 = (**(code **)(*plVar4 + 0x50))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0xb);
        local_440 = (**(code **)(*plVar4 + 0x50))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0xc);
        local_43c = (**(code **)(*plVar4 + 0x50))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0xd);
        local_438 = (**(code **)(*plVar4 + 0x50))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0xe);
        local_434 = (**(code **)(*plVar4 + 0x50))(plVar4);
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0xf);
        local_430 = (**(code **)(*plVar4 + 0x20))(plVar4);
        local_708 = local_598;
        memcpy(local_704,&local_598,0x16c);
        FUN_140273f90(param_1 + 0x10,local_720,&local_708);
        iVar8 = iVar8 + 1;
        uVar6 = (**(code **)(*plVar2 + 0x40))(plVar2);
      } while ((ulonglong)(longlong)iVar8 < uVar6);
    }
    (**(code **)*plVar2)(plVar2);
    uVar7 = 1;
  }
  return uVar7;
}

// ==== COperatingMailTypeMgr::helper_140274ee0  @140274ee0  [medium:callgraph-r0]  (orig: FUN_140274ee0)
void FUN_140274ee0(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  longlong local_38;
  undefined8 *puStack_30;
  undefined1 local_28 [32];
  
  lVar2 = *param_1;
  puVar3 = (undefined8 *)param_1[6];
  puVar5 = (undefined8 *)*puVar3;
  lVar6 = lVar2;
  if (lVar2 == 0) {
    _invalid_parameter_noinfo();
  }
  puVar10 = (undefined8 *)param_1[6];
  if ((lVar2 == 0) || (lVar2 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  lVar7 = lVar6;
  puVar9 = puVar5;
  if (puVar3 == puVar10) {
    FUN_140273620(param_1);
  }
  else {
    while( true ) {
      if ((lVar6 == 0) || (lVar6 != lVar2)) {
        _invalid_parameter_noinfo();
      }
      if (puVar5 == puVar3) break;
      lVar8 = lVar7;
      puVar10 = puVar9;
      if (lVar6 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar5 + 0x189) == '\0') {
        puVar10 = (undefined8 *)puVar5[2];
        if (*(char *)((longlong)puVar10 + 0x189) == '\0') {
          cVar1 = *(char *)((longlong)*puVar10 + 0x189);
          puVar5 = puVar10;
          puVar4 = (undefined8 *)*puVar10;
          while (puVar10 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)*puVar4 + 0x189);
            puVar5 = puVar4;
            puVar4 = (undefined8 *)*puVar4;
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar5[1] + 0x189);
          puVar10 = (undefined8 *)puVar5[1];
          puVar4 = puVar5;
          while ((puVar5 = puVar10, puVar10 = puVar5, cVar1 == '\0' &&
                 (puVar4 == (undefined8 *)puVar5[2]))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x189);
            puVar10 = (undefined8 *)puVar5[1];
            puVar4 = puVar5;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_38 = lVar7;
      puStack_30 = puVar9;
      FUN_1402740a0(param_1,local_28,&local_38,param_4,lVar8,puVar10);
      lVar7 = lVar8;
      puVar9 = puVar10;
    }
  }
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== COperatingMailTypeMgr::ctor_or_dtor  @1402752a0  [high:vtable-assign]  (orig: FUN_1402752a0)
void FUN_1402752a0(undefined8 *param_1)

{
  *param_1 = COperatingMailTypeMgr::vftable;
  param_1 = param_1 + 2;
  FUN_140273620(param_1);
  FUN_140274ee0(param_1);
  operator_delete((void *)*param_1);
  return;
}

// ==== COperatingMailTypeMgr::helper_140276040  @140276040  [medium:callgraph-r0]  (orig: FUN_140276040)
undefined8 * FUN_140276040(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140273480(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x189) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== COperatingMailTypeMgr::ctor_or_dtor  @1402760c0  [high:vtable-assign]  (orig: FUN_1402760c0)
undefined8 * FUN_1402760c0(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = COperatingMailTypeMgr::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_140276040(param_1 + 2);
  FUN_140273620(param_1 + 2);
  return param_1;
}

// ==== COperatingMailTypeMgr::ctor_or_dtor  @140276110  [high:vtable-assign]  (orig: FUN_140276110)
undefined8 * FUN_140276110(undefined8 *param_1,uint param_2)

{
  undefined8 *puVar1;
  
  *param_1 = COperatingMailTypeMgr::vftable;
  puVar1 = param_1 + 2;
  FUN_140273620(puVar1);
  FUN_140274ee0(puVar1);
  operator_delete((void *)*puVar1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== COperatingMailTypeMgr::ctor_or_dtor  @140276190  [high:vtable-assign]  (orig: FUN_140276190)
undefined8 *
FUN_140276190(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar2 = operator_new(0x50);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = COperatingMailTypeMgr::vftable;
    *(undefined4 *)(puVar2 + 1) = param_1;
    FUN_140276040(puVar2 + 2);
    FUN_140273620(puVar2 + 2);
  }
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_140274a30(puVar2);
    if (cVar1 == '\0') {
      (**(code **)*puVar2)(puVar2,1,param_3,param_4,uVar3);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

