// ==== CChatMsgLoginNotice::helper_1400497c0  @1400497c0  [medium:callgraph-r0]  (orig: FUN_1400497c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400497c0(longlong *param_1,longlong param_2,uint param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  int iVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong lVar10;
  undefined1 auStack_918 [32];
  longlong local_8f8;
  longlong local_8f0;
  longlong *local_8e8;
  longlong local_8e0;
  longlong local_8d8;
  undefined8 *local_8d0;
  undefined8 local_8c8;
  undefined1 local_8b8 [1088];
  undefined1 local_478 [1088];
  ulonglong local_38;
  
  if (param_2 != 0) {
    local_8c8 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_918;
    if (param_3 < *(uint *)(param_1 + 8)) {
      if (*(char *)((longlong)param_1 + 0x44) != '\0') {
        FUN_14004baa0(local_8b8);
        iVar5 = FUN_14004bb30(local_8b8,(int)param_1[8],(longlong)param_1 + 0x45,
                              (longlong)param_1 + 0xc5);
        if (iVar5 != 0) {
          FUN_1400330d0(DAT_140975aa0,*(undefined4 *)(param_2 + 0xc),local_8b8);
        }
        FUN_14004baf0(local_8b8);
      }
      lVar10 = 0;
      iVar5 = (uint)(*(char *)(param_2 + 0x54) != '\0') +
              ((uint)(*(int *)(param_2 + 0x10) != 0) +
              ((uint)*(ushort *)(param_2 + 0x4c) + (uint)*(ushort *)(param_2 + 0x4c) * 4) * 2) * 10;
      puVar8 = (undefined8 *)((undefined8 *)param_1[6])[1];
      cVar1 = *(char *)((longlong)puVar8 + 0x29d);
      puVar3 = (undefined8 *)param_1[6];
      while (cVar1 == '\0') {
        if (*(int *)(puVar8 + 3) < iVar5) {
          puVar6 = (undefined8 *)puVar8[2];
          puVar8 = puVar3;
        }
        else {
          puVar6 = (undefined8 *)*puVar8;
        }
        puVar3 = puVar8;
        puVar8 = puVar6;
        cVar1 = *(char *)((longlong)puVar6 + 0x29d);
      }
      local_8d0 = puVar3;
      local_8d8 = *param_1;
      puVar8 = (undefined8 *)param_1[6];
      if (*param_1 == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar3 == puVar8) || (iVar5 < *(int *)(puVar3 + 3))) {
        local_8f0 = param_1[6];
        local_8f8 = *param_1;
        plVar7 = &local_8f8;
      }
      else {
        plVar7 = &local_8d8;
      }
      plVar2 = (longlong *)*plVar7;
      local_8e8 = plVar2;
      local_8e0 = plVar7[1];
      lVar9 = param_1[6];
      if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*param_1)) {
        _invalid_parameter_noinfo();
      }
      lVar4 = local_8e0;
      if (local_8e0 != lVar9) {
        FUN_14004baa0(local_478);
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = lVar10;
        }
        else {
          lVar9 = *plVar2;
        }
        if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar10 = *plVar2;
        }
        if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        iVar5 = FUN_14004bb30(local_478,(int)param_1[8],lVar4 + 0x1c,lVar4 + 0x9c);
        if (iVar5 != 0) {
          FUN_1400330d0(DAT_140975aa0,*(undefined4 *)(param_2 + 0xc),local_478);
        }
        FUN_14004baf0(local_478);
      }
    }
  }
  return;
}

// ==== CChatMsgLoginNotice::ctor_or_dtor  @14004baa0  [high:vtable-assign]  (orig: FUN_14004baa0)
undefined8 * FUN_14004baa0(undefined8 *param_1)

{
  FUN_14003fc90();
  *param_1 = CChatMsgLoginNotice::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_14003f910(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CChatMsgLoginNotice::ctor_or_dtor  @14004baf0  [high:vtable-assign]  (orig: FUN_14004baf0)
void FUN_14004baf0(undefined8 *param_1)

{
  *param_1 = CChatMsgLoginNotice::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_14003f900(param_1);
  return;
}

// ==== CChatMsgLoginNotice::helper_14004bb30  @14004bb30  [medium:callgraph-r1]  (orig: FUN_14004bb30)
undefined8 FUN_14004bb30(longlong param_1,undefined4 param_2,char *param_3,char *param_4)

{
  char cVar1;
  ulonglong uVar2;
  
  if (param_3 != (char *)0x0) {
    uVar2 = 0xffffffffffffffff;
    do {
      if (uVar2 == 0) break;
      uVar2 = uVar2 - 1;
      cVar1 = *param_3;
      param_3 = param_3 + 1;
    } while (cVar1 != '\0');
    if ((~uVar2 - 1 < 0x80) && (param_4 != (char *)0x0)) {
      uVar2 = 0xffffffffffffffff;
      do {
        if (uVar2 == 0) break;
        uVar2 = uVar2 - 1;
        cVar1 = *param_4;
        param_4 = param_4 + 1;
      } while (cVar1 != '\0');
      if (~uVar2 - 1 < 0x200) {
        FUN_14003f910(param_1);
        **(undefined4 **)(param_1 + 0x420) = param_2;
        _snprintf((char *)(*(longlong *)(param_1 + 0x420) + 4),0x7f,"%s");
        _snprintf((char *)(*(longlong *)(param_1 + 0x420) + 0x84),0xff,"%s");
        *(undefined4 *)(param_1 + 8) = 0x42b;
        *(undefined4 *)(param_1 + 0xc) = 0x184;
        return 1;
      }
    }
  }
  return 0;
}

// ==== CChatMsgLoginNotice::vfunc_1  @14004bc30  [high:rtti-vtable]  (orig: FUN_14004bc30)
undefined8 FUN_14004bc30(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CChatMsgLoginNotice::vfunc_3  @14004bc60  [high:rtti-vtable]  (orig: FUN_14004bc60)
void FUN_14004bc60(longlong param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar2 = DAT_140975aa0;
  uVar1 = *(undefined4 *)(param_1 + 0x414);
  if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = FUN_140042e80(*(undefined8 *)(lVar2 + 0x18),uVar1);
  lVar2 = DAT_140975aa0;
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (*(longlong *)(DAT_140975aa0 + 0x30) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1400497c0(*(undefined8 *)(lVar2 + 0x30),lVar3,**(undefined4 **)(param_1 + 0x420));
  return;
}

// ==== CChatMsgLoginNotice::ctor_or_dtor  @14004bd60  [high:vtable-assign]  (orig: FUN_14004bd60)
undefined8 * FUN_14004bd60(undefined8 *param_1,uint param_2)

{
  *param_1 = CChatMsgLoginNotice::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_14003f900(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

