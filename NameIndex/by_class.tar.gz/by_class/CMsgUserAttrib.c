// ==== CMsgUserAttrib::ctor_or_dtor  @14039e680  [high:vtable-assign]  (orig: FUN_14039e680)
undefined8 * FUN_14039e680(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgUserAttrib::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgUserAttrib::ctor_or_dtor  @14039e6d0  [high:vtable-assign]  (orig: FUN_14039e6d0)
void FUN_14039e6d0(undefined8 *param_1)

{
  *param_1 = CMsgUserAttrib::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgUserAttrib::vfunc_1  @14039eb00  [high:rtti-vtable]  (orig: FUN_14039eb00)
ulonglong FUN_14039eb00(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x2721);
}

// ==== CMsgUserAttrib::vfunc_3  @14039eb30  [high:rtti-vtable]  (orig: FUN_14039eb30)
void FUN_14039eb30(void)

{
                    /* WARNING: Could not recover jumptable at 0x00014039eb37. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogERROR("invalid msg CMsgUserAttrib.");
  return;
}

// ==== CMsgUserAttrib::ctor_or_dtor  @14039eb40  [high:vtable-assign]  (orig: FUN_14039eb40)
undefined8 * FUN_14039eb40(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgUserAttrib::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

