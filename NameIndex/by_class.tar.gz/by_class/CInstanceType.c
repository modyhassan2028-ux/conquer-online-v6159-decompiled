// ==== CInstanceType::helper_140422850  @140422850  [medium:callgraph-r0]  (orig: FUN_140422850)
void FUN_140422850(void *param_1)

{
  if ((DAT_1409763f8 & 1) == 0) {
    DAT_1409763f8 = DAT_1409763f8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409763f0,"CInstanceType");
    atexit((_func_5014 *)&LAB_1406d6e00);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404228a5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409763f0,param_1);
  return;
}

// ==== CInstanceType::ctor_or_dtor  @140422990  [high:vtable-assign]  (orig: FUN_140422990)
void FUN_140422990(undefined8 *param_1)

{
  *param_1 = CInstanceType::vftable;
  FUN_14000c310(param_1 + 0xb);
  operator_delete((void *)param_1[0xb]);
  FUN_14000c310(param_1 + 3);
  operator_delete((void *)param_1[3]);
  return;
}

// ==== CInstanceType::ctor_or_dtor  @140422d40  [high:vtable-assign]  (orig: FUN_140422d40)
undefined8 * FUN_140422d40(undefined8 *param_1,undefined4 param_2,undefined8 param_3)

{
  *param_1 = CInstanceType::vftable;
  FUN_14000ef40(param_1 + 3);
  FUN_14000ef40(param_1 + 0xb);
  *(undefined4 *)(param_1 + 1) = param_2;
  param_1[2] = param_3;
  return param_1;
}

// ==== CInstanceType::ctor_or_dtor  @140422da0  [high:vtable-assign]  (orig: FUN_140422da0)
undefined8 * FUN_140422da0(undefined8 *param_1,uint param_2)

{
  *param_1 = CInstanceType::vftable;
  FUN_14000c310(param_1 + 0xb);
  operator_delete((void *)param_1[0xb]);
  FUN_14000c310(param_1 + 3);
  operator_delete((void *)param_1[3]);
  if ((param_2 & 1) != 0) {
    FUN_140422850(param_1);
  }
  return param_1;
}

