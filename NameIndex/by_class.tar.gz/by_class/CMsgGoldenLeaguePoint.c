// ==== CMsgGoldenLeaguePoint::helper_140168ce0  @140168ce0  [medium:callgraph-r0]  (orig: FUN_140168ce0)
void FUN_140168ce0(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x12e8) != 0) {
    FUN_1403b7bd0(*(longlong *)(param_1 + 0x12e8),param_1);
  }
  return;
}

// ==== CMsgGoldenLeaguePoint::helper_1403b7bd0  @1403b7bd0  [medium:callgraph-r1]  (orig: FUN_1403b7bd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403b7bd0(longlong param_1,longlong param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1136];
  ulonglong local_18;
  
  local_498 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (param_2 == 0) {
    local_4a8 = 0xbf;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar2 = 0;
    if (*(longlong *)(param_1 + 0x10) != 0) {
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                         (*(longlong **)(param_1 + 0x10),2);
      uVar2 = (**(code **)(*plVar3 + 0x50))(plVar3);
    }
    FUN_140450b00(local_488);
    cVar1 = FUN_140450c30(local_488,uVar2);
    if (cVar1 != '\0') {
      (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_488);
    }
    FUN_140450b50(local_488);
  }
  return;
}

// ==== CMsgGoldenLeaguePoint::ctor_or_dtor  @140450b00  [high:vtable-assign]  (orig: FUN_140450b00)
undefined8 * FUN_140450b00(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgGoldenLeaguePoint::vftable;
  FUN_140578250(param_1 + 0x85);
  FUN_1402b5600(param_1);
  return param_1;
}

// ==== CMsgGoldenLeaguePoint::ctor_or_dtor  @140450b50  [high:vtable-assign]  (orig: FUN_140450b50)
void FUN_140450b50(undefined8 *param_1)

{
  *param_1 = CMsgGoldenLeaguePoint::vftable;
  FUN_140578320(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgGoldenLeaguePoint::vfunc_5  @140450b90  [high:rtti-vtable]  (orig: FUN_140450b90)
undefined8 FUN_140450b90(longlong param_1,undefined8 param_2,undefined2 param_3,undefined8 param_4)

{
  longlong *plVar1;
  char cVar2;
  undefined8 uVar3;
  longlong lVar4;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (*(int *)(param_1 + 8) == 0xa28) {
    plVar1 = (longlong *)(param_1 + 0x428);
    cVar2 = FUN_140554950(plVar1,param_2,param_3,param_4,0xfffffffffffffffe);
    if (cVar2 == '\0') {
      cVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
      if (cVar2 == '\0') {
        lVar4 = (**(code **)(*plVar1 + 0x28))(plVar1,local_30);
        if (*(ulonglong *)(lVar4 + 0x20) < 0x10) {
          lVar4 = lVar4 + 8;
        }
        else {
          lVar4 = *(longlong *)(lVar4 + 8);
        }
        log_InlineLogERROR(&DAT_14077d810,lVar4);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_30);
      }
      else {
        log_InlineLogERROR("CMsgGoldenLeaguePoint_pb::CreateBufMsg ParseFromArray failed.");
      }
      uVar3 = 0;
    }
    else {
      uVar3 = 1;
    }
  }
  else {
    uVar3 = 0;
  }
  return uVar3;
}

// ==== CMsgGoldenLeaguePoint::helper_140450c30  @140450c30  [medium:callgraph-r2]  (orig: FUN_140450c30)
undefined8 FUN_140450c30(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 uVar4;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  uVar4 = 0xfffffffffffffffe;
  FUN_1402b5600();
  *(uint *)(param_1 + 0x458) = *(uint *)(param_1 + 0x458) | 1;
  *(undefined4 *)(param_1 + 0x460) = param_2;
  cVar1 = FUN_1405551c0(param_1 + 0x428,param_1 + 0x10,0x400,param_4,uVar4);
  if (cVar1 == '\0') {
    cVar1 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x20))(param_1 + 0x428);
    if (cVar1 == '\0') {
      lVar3 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x28))(param_1 + 0x428,local_30);
      if (*(ulonglong *)(lVar3 + 0x20) < 0x10) {
        lVar3 = lVar3 + 8;
      }
      else {
        lVar3 = *(longlong *)(lVar3 + 8);
      }
      log_InlineLogERROR(&DAT_14077d8c0,lVar3);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_30);
    }
    else {
      log_InlineLogERROR("CMsgGoldenLeaguePoint_pb::CreateBufMsg SerializeToArray failed.");
    }
    uVar4 = 0;
  }
  else {
    *(undefined4 *)(param_1 + 8) = 0xa28;
    uVar2 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x40))(param_1 + 0x428);
    *(undefined4 *)(param_1 + 0xc) = uVar2;
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CMsgGoldenLeaguePoint::ctor_or_dtor  @140450d10  [high:vtable-assign]  (orig: FUN_140450d10)
undefined8 * FUN_140450d10(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgGoldenLeaguePoint::vftable;
  FUN_140578320(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgGoldenLeaguePoint::vfunc_3  @140450d70  [high:rtti-vtable]  (orig: FUN_140450d70)
void FUN_140450d70(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar2 = (longlong *)FUN_140087650(uVar1);
  lVar3 = (**(code **)(*plVar2 + 0x88))(plVar2,param_1,*plVar2,param_4,uVar4);
  if (lVar3 != 0) {
    FUN_140168ce0(lVar3);
  }
  return;
}

