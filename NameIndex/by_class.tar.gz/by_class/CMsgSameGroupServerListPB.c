// ==== CMsgSameGroupServerListPB::helper_140555b00  @140555b00  [medium:callgraph-r2]  (orig: FUN_140555b00)
void FUN_140555b00(longlong param_1,int param_2)

{
  *(longlong *)(param_1 + 8) = (longlong)param_2 + *(longlong *)(param_1 + 8);
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) - param_2;
  return;
}

// ==== CMsgSameGroupServerListPB::helper_14055a5c0  @14055a5c0  [medium:callgraph-r1]  (orig: FUN_14055a5c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14055a5c0(longlong param_1,uint param_2)

{
  uint local_res10;
  undefined1 auStack_68 [32];
  int local_48;
  undefined8 local_40;
  undefined8 local_38;
  int local_30;
  byte local_20 [8];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  if (*(int *)(param_1 + 0x10) < 5) {
    local_30 = 0;
    for (local_res10 = param_2; 0x7f < local_res10; local_res10 = local_res10 >> 7) {
      local_20[local_30] = (byte)local_res10 & 0x7f | 0x80;
      local_30 = local_30 + 1;
    }
    local_20[local_30] = (byte)local_res10 & 0x7f;
    local_30 = local_30 + 1;
    FUN_14055a240(param_1,local_20,local_30);
  }
  else {
    local_38 = *(undefined8 *)(param_1 + 8);
    local_40 = FUN_14055b170(param_2,local_38);
    local_48 = (int)local_40 - (int)local_38;
    FUN_140555b00(param_1,local_48);
  }
  return;
}

// ==== CMsgSameGroupServerListPB::helper_14055b170  @14055b170  [medium:callgraph-r2]  (orig: FUN_14055b170)
byte * FUN_14055b170(uint param_1,byte *param_2)

{
  *param_2 = (byte)param_1 | 0x80;
  if (param_1 < 0x80) {
    *param_2 = *param_2 & 0x7f;
    param_2 = param_2 + 1;
  }
  else {
    param_2[1] = (byte)(param_1 >> 7) | 0x80;
    if (param_1 < 0x4000) {
      param_2[1] = param_2[1] & 0x7f;
      param_2 = param_2 + 2;
    }
    else {
      param_2[2] = (byte)(param_1 >> 0xe) | 0x80;
      if (param_1 < 0x200000) {
        param_2[2] = param_2[2] & 0x7f;
        param_2 = param_2 + 3;
      }
      else {
        param_2[3] = (byte)(param_1 >> 0x15) | 0x80;
        if (param_1 < 0x10000000) {
          param_2[3] = param_2[3] & 0x7f;
          param_2 = param_2 + 4;
        }
        else {
          param_2[4] = (byte)(param_1 >> 0x1c);
          param_2 = param_2 + 5;
        }
      }
    }
  }
  return param_2;
}

// ==== CMsgSameGroupServerListPB::vfunc_1  @140574bd0  [high:rtti-vtable]  (orig: FUN_140574bd0)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_140574bd0(undefined8 param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (param_2,"CMsgSameGroupServerListPB");
  return param_2;
}

// ==== CMsgSameGroupServerListPB::helper_140575910  @140575910  [medium:callgraph-r0]  (orig: FUN_140575910)
void FUN_140575910(longlong *param_1,longlong *param_2)

{
  int iVar1;
  undefined8 uVar2;
  int iVar3;
  longlong lVar4;
  void *local_res8;
  undefined1 local_48 [64];
  
  if (param_2 == param_1) {
    local_res8 = (void *)((ulonglong)local_res8 & 0xffffffffffffff00);
    uVar2 = FUN_140556890(local_48,3,
                          "f:\\version\\cqserver-78.0.11-1204\\include\\google\\protobuf\\repeated_field.h"
                          ,0x39f,0,0xfffffffffffffffe);
    uVar2 = FUN_1405564f0(uVar2,"CHECK failed: (&other) != (this): ");
    FUN_140556a40(&local_res8,uVar2);
    FUN_140556900(local_48);
  }
  FUN_140555c70(param_1,(int)param_1[1] + (int)param_2[1]);
  iVar3 = 0;
  if (0 < (int)param_2[1]) {
    lVar4 = 0;
    do {
      iVar1 = (int)param_1[1];
      if (iVar1 < *(int *)((longlong)param_1 + 0xc)) {
        uVar2 = *(undefined8 *)(*param_1 + (longlong)iVar1 * 8);
        *(int *)(param_1 + 1) = iVar1 + 1;
      }
      else {
        if (*(int *)((longlong)param_1 + 0xc) == (int)param_1[2]) {
          FUN_140555c70(param_1,(int)param_1[2] + 1);
        }
        local_res8 = operator_new(0x58);
        if (local_res8 == (void *)0x0) {
          uVar2 = 0;
        }
        else {
          uVar2 = FUN_140574e10(local_res8);
        }
        *(int *)((longlong)param_1 + 0xc) = *(int *)((longlong)param_1 + 0xc) + 1;
        *(undefined8 *)(*param_1 + (longlong)(int)param_1[1] * 8) = uVar2;
        *(int *)(param_1 + 1) = (int)param_1[1] + 1;
      }
      FUN_1405749b0(uVar2,*(undefined8 *)(lVar4 + *param_2));
      iVar3 = iVar3 + 1;
      lVar4 = lVar4 + 8;
    } while (iVar3 < (int)param_2[1]);
  }
  return;
}

// ==== CMsgSameGroupServerListPB::ctor_or_dtor  @140575a70  [high:vtable-assign]  (orig: FUN_140575a70)
undefined8 * FUN_140575a70(undefined8 *param_1)

{
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CMsgSameGroupServerListPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  param_1[7] = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  return param_1;
}

// ==== CMsgSameGroupServerListPB::vfunc_11  @140575ad0  [high:rtti-vtable]  (orig: FUN_140575ad0)
undefined4 FUN_140575ad0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x34);
}

// ==== CMsgSameGroupServerListPB::ctor_or_dtor  @140575ae0  [high:vtable-assign]  (orig: FUN_140575ae0)
void FUN_140575ae0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  uint uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  
  uVar5 = 0xfffffffffffffffe;
  *param_1 = CMsgSameGroupServerListPB::vftable;
  uVar3 = 0;
  uVar4 = uVar3;
  if (0 < *(int *)((longlong)param_1 + 0x44)) {
    do {
      puVar1 = *(undefined8 **)(uVar4 + param_1[7]);
      if (puVar1 != (undefined8 *)0x0) {
        (**(code **)*puVar1)(puVar1,1,param_3,param_4,uVar5);
      }
      uVar2 = (int)uVar3 + 1;
      uVar3 = (ulonglong)uVar2;
      uVar4 = uVar4 + 8;
    } while ((int)uVar2 < *(int *)((longlong)param_1 + 0x44));
  }
  operator_delete__((void *)param_1[7]);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140554130(param_1);
  return;
}

// ==== CMsgSameGroupServerListPB::ctor_or_dtor  @140575b70  [high:vtable-assign]  (orig: FUN_140575b70)
undefined8 * FUN_140575b70(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = google::protobuf::MessageLite::vftable;
    *puVar1 = CMsgSameGroupServerListPB::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(puVar1 + 1));
    puVar1[7] = 0;
    *(undefined4 *)(puVar1 + 8) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x44) = 0;
    *(undefined4 *)(puVar1 + 9) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x34) = 0;
    *(undefined4 *)(puVar1 + 6) = 0;
  }
  return puVar1;
}

// ==== CMsgSameGroupServerListPB::vfunc_3  @140575be0  [high:rtti-vtable]  (orig: FUN_140575be0)
void FUN_140575be0(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  
  iVar1 = 0;
  if (0 < *(int *)(param_1 + 0x40)) {
    lVar2 = 0;
    do {
      (**(code **)(**(longlong **)(lVar2 + *(longlong *)(param_1 + 0x38)) + 0x18))();
      iVar1 = iVar1 + 1;
      lVar2 = lVar2 + 8;
    } while (iVar1 < *(int *)(param_1 + 0x40));
  }
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
                    /* WARNING: Could not recover jumptable at 0x000140575c38. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::clear
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8));
  return;
}

// ==== CMsgSameGroupServerListPB::vfunc_9  @140575c40  [high:rtti-vtable]  (orig: FUN_140575c40)
void FUN_140575c40(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  ulonglong uVar2;
  uint uVar3;
  ulonglong uVar4;
  
  uVar2 = 0;
  uVar4 = uVar2;
  if (0 < *(int *)(param_1 + 0x40)) {
    do {
      FUN_1405c9720(1,*(undefined8 *)(uVar2 + *(longlong *)(param_1 + 0x38)),param_2);
      uVar3 = (int)uVar4 + 1;
      uVar2 = uVar2 + 8;
      uVar4 = (ulonglong)uVar3;
    } while ((int)uVar3 < *(int *)(param_1 + 0x40));
  }
  if (*(ulonglong *)(param_1 + 0x28) < 0x10) {
    lVar1 = param_1 + 0x10;
  }
  else {
    lVar1 = *(longlong *)(param_1 + 0x10);
  }
  FUN_14055a240(param_2,lVar1,*(ulonglong *)(param_1 + 0x20) & 0xffffffff);
  return;
}

// ==== CMsgSameGroupServerListPB::vfunc_8  @140575cd0  [high:rtti-vtable]  (orig: FUN_140575cd0)
int FUN_140575cd0(longlong param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  
  uVar5 = 0;
  iVar3 = *(int *)(param_1 + 0x40);
  uVar6 = uVar5;
  if (0 < iVar3) {
    do {
      uVar1 = FUN_140574870(*(undefined8 *)(uVar6 + *(longlong *)(param_1 + 0x38)));
      if (uVar1 < 0x80) {
        iVar2 = 1;
      }
      else {
        iVar2 = FUN_14055a8a0(uVar1);
      }
      uVar4 = (int)uVar5 + 1;
      uVar5 = (ulonglong)uVar4;
      iVar3 = iVar3 + iVar2 + uVar1;
      uVar6 = uVar6 + 8;
    } while ((int)uVar4 < *(int *)(param_1 + 0x40));
  }
  iVar3 = iVar3 + *(int *)(param_1 + 0x20);
  *(int *)(param_1 + 0x34) = iVar3;
  return iVar3;
}

// ==== CMsgSameGroupServerListPB::vfunc_4  @140575d50  [high:rtti-vtable]  (orig: FUN_140575d50)
undefined8 FUN_140575d50(longlong param_1)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  
  iVar2 = *(int *)(param_1 + 0x40) + -1;
  lVar3 = (longlong)iVar2;
  if (-1 < iVar2) {
    do {
      cVar1 = (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x38) + lVar3 * 8) + 0x20))();
      if (cVar1 == '\0') {
        return 0;
      }
      lVar3 = lVar3 + -1;
    } while (-1 < lVar3);
  }
  return 1;
}

// ==== CMsgSameGroupServerListPB::vfunc_0  @140575eb0  [high:rtti-vtable]  (orig: FUN_140575eb0)
void * FUN_140575eb0(void *param_1,uint param_2)

{
  FUN_140575ae0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgSameGroupServerListPB::helper_140576180  @140576180  [medium:callgraph-r0]  (orig: FUN_140576180)
void FUN_140576180(longlong param_1,longlong param_2)

{
  undefined8 uVar1;
  undefined1 local_res8 [8];
  undefined1 local_48 [64];
  
  if (param_2 == param_1) {
    local_res8[0] = 0;
    uVar1 = FUN_140556890(local_48,3,
                          "f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgsamegroupserverlist.pb.cc"
                          ,0x271,0,0xfffffffffffffffe);
    uVar1 = FUN_1405564f0(uVar1,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(local_res8,uVar1);
    FUN_140556900(local_48);
  }
  FUN_140575910(param_1 + 0x38,param_2 + 0x38);
                    /* WARNING: Could not recover jumptable at 0x00014057622f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

// ==== CMsgSameGroupServerListPB::ctor_or_dtor  @140576280  [high:vtable-assign]  (orig: FUN_140576280)
undefined8 *
FUN_140576280(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CMsgSameGroupServerListPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  param_1[7] = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  FUN_140576180(param_1,param_2,param_3,param_4,uVar1);
  return param_1;
}

// ==== CMsgSameGroupServerListPB::vfunc_6  @1405762f0  [high:rtti-vtable]  (orig: thunk_FUN_140576180)
void thunk_FUN_140576180(longlong param_1,longlong param_2)

{
  undefined8 uVar1;
  undefined1 auStackX_8 [8];
  undefined1 auStack_48 [64];
  
  if (param_2 == param_1) {
    auStackX_8[0] = 0;
    uVar1 = FUN_140556890(auStack_48,3,
                          "f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgsamegroupserverlist.pb.cc"
                          ,0x271,0,0xfffffffffffffffe);
    uVar1 = FUN_1405564f0(uVar1,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(auStackX_8,uVar1);
    FUN_140556900(auStack_48);
  }
  FUN_140575910(param_1 + 0x38,param_2 + 0x38);
                    /* WARNING: Could not recover jumptable at 0x00014057622f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

// ==== CMsgSameGroupServerListPB::helper_1405c9720  @1405c9720  [medium:callgraph-r0]  (orig: FUN_1405c9720)
void FUN_1405c9720(undefined4 param_1,longlong *param_2,undefined8 param_3)

{
  undefined4 uVar1;
  
  FUN_1405c9d60(param_1,2,param_3);
  uVar1 = (**(code **)(*param_2 + 0x58))(param_2);
  FUN_14055a5c0(param_3,uVar1);
  (**(code **)(*param_2 + 0x48))(param_2,param_3);
  return;
}

// ==== CMsgSameGroupServerListPB::helper_1405c9c30  @1405c9c30  [medium:callgraph-r2]  (orig: FUN_1405c9c30)
uint FUN_1405c9c30(int param_1,uint param_2)

{
  return param_1 << 3 | param_2;
}

// ==== CMsgSameGroupServerListPB::helper_1405c9d60  @1405c9d60  [medium:callgraph-r1]  (orig: FUN_1405c9d60)
void FUN_1405c9d60(undefined4 param_1,undefined4 param_2,undefined8 param_3)

{
  undefined4 uVar1;
  
  uVar1 = FUN_1405c9c30(param_1,param_2);
  FUN_1405c9d90(param_3,uVar1);
  return;
}

// ==== CMsgSameGroupServerListPB::helper_1405c9d90  @1405c9d90  [medium:callgraph-r2]  (orig: FUN_1405c9d90)
void FUN_1405c9d90(undefined8 param_1,undefined4 param_2)

{
  FUN_14055a5c0(param_1,param_2);
  return;
}

