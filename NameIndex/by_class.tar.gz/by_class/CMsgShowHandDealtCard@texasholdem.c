// ==== CMsgShowHandDealtCard@texasholdem::vfunc_1  @1404dabe0  [high:rtti-vtable]  (orig: FUN_1404dabe0)
undefined8 FUN_1404dabe0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgShowHandDealtCard@texasholdem::vfunc_0  @1404dadb0  [high:rtti-vtable]  (orig: FUN_1404dadb0)
undefined8 * FUN_1404dadb0(undefined8 *param_1,uint param_2)

{
  *param_1 = texasholdem::CMsgShowHandDealtCard::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

