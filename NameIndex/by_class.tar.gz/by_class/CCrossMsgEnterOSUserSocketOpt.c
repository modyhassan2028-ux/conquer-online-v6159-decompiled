// ==== CCrossMsgEnterOSUserSocketOpt::ctor_or_dtor  @140368e20  [high:vtable-assign]  (orig: FUN_140368e20)
undefined8 * FUN_140368e20(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgEnterOSUserSocketOpt::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgEnterOSUserSocketOpt::ctor_or_dtor  @140368e70  [high:vtable-assign]  (orig: FUN_140368e70)
void FUN_140368e70(undefined8 *param_1)

{
  *param_1 = CCrossMsgEnterOSUserSocketOpt::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgEnterOSUserSocketOpt::vfunc_1  @140368ea0  [high:rtti-vtable]  (orig: FUN_140368ea0)
undefined8 FUN_140368ea0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgEnterOSUserSocketOpt::ctor_or_dtor  @140368f70  [high:vtable-assign]  (orig: FUN_140368f70)
undefined8 * FUN_140368f70(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgEnterOSUserSocketOpt::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgEnterOSUserSocketOpt::vfunc_3  @140368fc0  [high:rtti-vtable]  (orig: FUN_140368fc0)
void FUN_140368fc0(longlong param_1)

{
  short sVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  
  if (*(short **)(param_1 + 0x428) == (short *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  sVar1 = **(short **)(param_1 + 0x428);
  if (sVar1 == 0) {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x98))
                      (plVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (lVar4 == 0) {
      return;
    }
    uVar2 = 4;
  }
  else {
    if (sVar1 == 1) {
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar3 = (longlong *)FUN_140087650(uVar2);
      lVar4 = (**(code **)(*plVar3 + 0x98))
                        (plVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (lVar4 == 0) {
        return;
      }
      FUN_1401bd0d0(lVar4,4,4);
      return;
    }
    if (sVar1 != 3) {
      return;
    }
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0xa0))
                      (plVar3,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c));
    if (lVar4 == 0) {
      return;
    }
    uVar2 = 8;
  }
  FUN_1401bd0d0(lVar4,uVar2,3);
  return;
}

