// ==== CMsgProcessGoalTaskOpt::helper_140158cf0  @140158cf0  [medium:callgraph-r3]  (orig: FUN_140158cf0)
undefined8 FUN_140158cf0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar9 != local_10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(lVar4 + 0x20) != 0) {
      uVar6 = FUN_1403ad720();
      return uVar6;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMsgProcessGoalTaskOpt::helper_140267a80  @140267a80  [medium:callgraph-r2]  (orig: FUN_140267a80)
longlong * FUN_140267a80(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgProcessGoalTaskOpt::helper_1402683a0  @1402683a0  [medium:callgraph-r1]  (orig: FUN_1402683a0)
undefined8 FUN_1402683a0(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  undefined4 local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x108));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2);
  if (lVar3 != 0) {
    cVar2 = FUN_140167b70(lVar3);
    if (cVar2 == '\0') {
      FUN_140267a80((longlong *)(param_1 + 200),&local_18,local_res10);
      plVar1 = *(longlong **)(param_1 + 200);
      lVar3 = *(longlong *)(param_1 + 0xf8);
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_18)) {
        _invalid_parameter_noinfo();
      }
      if (lVar3 != local_10) {
        if (local_18 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar3 = 0;
        }
        else {
          lVar3 = *local_18;
        }
        if (local_10 == *(longlong *)(lVar3 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        return *(undefined8 *)(local_10 + 0x20);
      }
    }
  }
  return 0;
}

// ==== CMsgProcessGoalTaskOpt::helper_1402684b0  @1402684b0  [medium:callgraph-r1]  (orig: FUN_1402684b0)
undefined8 FUN_1402684b0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar9 != local_10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar6 = *(longlong **)(lVar4 + 0x20);
    if (plVar6 != (longlong *)0x0) {
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,2);
      uVar7 = (**(code **)(*plVar6 + 0x48))(plVar6);
      return uVar7;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMsgProcessGoalTaskOpt::helper_140268600  @140268600  [medium:callgraph-r2]  (orig: FUN_140268600)
undefined8 FUN_140268600(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar9 != local_10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar6 = *(longlong **)(lVar4 + 0x20);
    if (plVar6 != (longlong *)0x0) {
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,1);
      uVar7 = (**(code **)(*plVar6 + 0x48))(plVar6);
      return uVar7;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMsgProcessGoalTaskOpt::helper_140268870  @140268870  [medium:callgraph-r2]  (orig: FUN_140268870)
undefined8 FUN_140268870(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x78);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x78);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x48);
  if (*(longlong *)(param_1 + 0x48) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x78);
    local_28 = *(longlong *)(param_1 + 0x48);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x78);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((*(longlong **)(param_1 + 0x48) == (longlong *)0x0) ||
     (*(longlong **)(param_1 + 0x48) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar9 == local_10) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgProcessGoalTaskOpt::helper_140268970  @140268970  [medium:callgraph-r2]  (orig: FUN_140268970)
undefined8 FUN_140268970(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar9 == local_10) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgProcessGoalTaskOpt::helper_140268a70  @140268a70  [medium:callgraph-r0]  (orig: FUN_140268a70)
ulonglong FUN_140268a70(undefined8 param_1,longlong *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  ulonglong in_RAX;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  
  if (param_2 != (longlong *)0x0) {
    in_RAX = FUN_140167b70(param_2);
    if ((char)in_RAX == '\0') {
      uVar1 = (**(code **)(*param_2 + 8))(param_2);
      lVar2 = FUN_1402683a0(param_1,uVar1);
      if (lVar2 != 0) {
        uVar3 = FUN_140430db0(lVar2,param_2,param_3);
        return uVar3;
      }
      log_InlineLogERROR(&DAT_1406d9c10);
      in_RAX = extraout_RAX;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgProcessGoalTaskOpt::helper_140268b10  @140268b10  [medium:callgraph-r0]  (orig: FUN_140268b10)
ulonglong FUN_140268b10(undefined8 param_1,longlong *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  ulonglong in_RAX;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  
  if (param_2 != (longlong *)0x0) {
    in_RAX = FUN_140167b70(param_2);
    if ((char)in_RAX == '\0') {
      uVar1 = (**(code **)(*param_2 + 8))(param_2);
      lVar2 = FUN_1402683a0(param_1,uVar1);
      if (lVar2 != 0) {
        uVar3 = FUN_14042f640(lVar2,param_2,param_3);
        return uVar3;
      }
      log_InlineLogERROR(&DAT_1406d9c10);
      in_RAX = extraout_RAX;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgProcessGoalTaskOpt::helper_140268bb0  @140268bb0  [medium:callgraph-r0]  (orig: FUN_140268bb0)
void FUN_140268bb0(undefined8 param_1,longlong *param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  cVar1 = FUN_140167b70(param_2);
  if (cVar1 == '\0') {
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
    lVar3 = FUN_1402683a0(param_1,uVar2);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    FUN_14042f920(lVar3,param_2,param_3);
  }
  return;
}

// ==== CMsgProcessGoalTaskOpt::helper_140268e70  @140268e70  [medium:callgraph-r0]  (orig: FUN_140268e70)
void FUN_140268e70(undefined8 param_1,longlong *param_2,ulonglong param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  
  if (param_2 != (longlong *)0x0) {
    cVar1 = FUN_140167b70(param_2);
    if (cVar1 == '\0') {
      uVar2 = (**(code **)(*param_2 + 8))(param_2);
      lVar6 = FUN_1402683a0(param_1,uVar2);
      if (lVar6 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        iVar3 = (**(code **)(*param_2 + 0x108))(param_2);
        iVar4 = (**(code **)(param_2[2] + 0x70))(param_2 + 2);
        iVar5 = FUN_1402684b0(param_1,(param_3 & 0xffffffff) / 100);
        if (iVar5 <= iVar3 * 1000 + iVar4) {
          FUN_1404313a0(lVar6,param_3 & 0xffffffff);
        }
      }
    }
  }
  return;
}

// ==== CMsgProcessGoalTaskOpt::helper_1402e8d10  @1402e8d10  [medium:callgraph-r3]  (orig: FUN_1402e8d10)
longlong FUN_1402e8d10(undefined8 param_1,undefined8 param_2)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  
  lVar1 = FUN_1402e69e0(param_1,param_2,1);
  lVar2 = FUN_1402e69e0(param_1,param_2,2);
  lVar3 = FUN_1402e69e0(param_1,param_2,3);
  lVar4 = FUN_1402e69e0(param_1,param_2,4);
  return lVar4 + lVar1 + lVar2 + lVar3;
}

// ==== CMsgProcessGoalTaskOpt::helper_14032dd10  @14032dd10  [medium:callgraph-r3]  (orig: FUN_14032dd10)
int FUN_14032dd10(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  int iVar5;
  longlong *plVar6;
  
  uVar1 = *(undefined4 *)(param_1 + 0xdbc);
  plVar6 = (longlong *)0x0;
  iVar5 = 0;
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = plVar6;
  }
  lVar3 = (**(code **)(*plVar4 + 0x60))(plVar4,uVar1);
  if (lVar3 != 0) {
    iVar2 = FUN_1400fda10(lVar3,1,1);
    iVar5 = 0;
    if (iVar2 % 10 == 9) {
      iVar5 = 1;
    }
  }
  uVar1 = *(undefined4 *)(param_1 + 0xdc0);
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = plVar6;
  }
  lVar3 = (**(code **)(*plVar4 + 0x60))(plVar4,uVar1);
  if ((lVar3 != 0) && (iVar2 = FUN_1400fda10(lVar3,1,1), iVar2 % 10 == 9)) {
    iVar5 = iVar5 + 1;
  }
  uVar1 = *(undefined4 *)(param_1 + 0xde0);
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = plVar6;
  }
  lVar3 = (**(code **)(*plVar4 + 0x60))(plVar4,uVar1);
  if (lVar3 != 0) {
    iVar2 = FUN_1400fda10(lVar3,1,1);
    if (iVar2 % 10 == 9) {
      return iVar5 + 1;
    }
  }
  return iVar5;
}

// ==== CMsgProcessGoalTaskOpt::helper_14032dee0  @14032dee0  [medium:callgraph-r3]  (orig: FUN_14032dee0)
int FUN_14032dee0(longlong param_1,int param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  int iVar5;
  int *piVar6;
  
  iVar5 = 0;
  lVar4 = 1;
  piVar6 = (int *)(param_1 + 0xd98);
  do {
    if ((((lVar4 != 9) && (lVar4 != 7)) && ((lVar4 < 0xc || (0x11 < lVar4)))) &&
       (iVar1 = *piVar6, iVar1 != 0)) {
      plVar3 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar3 = (longlong *)0x0;
      }
      lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,iVar1);
      if (lVar2 != 0) {
        iVar1 = FUN_1400fda10(lVar2,1,1);
        if (param_2 <= iVar1 % 10) {
          iVar5 = iVar5 + 1;
        }
      }
    }
    lVar4 = lVar4 + 1;
    piVar6 = piVar6 + 1;
  } while (lVar4 < 0x14);
  return iVar5;
}

// ==== CMsgProcessGoalTaskOpt::helper_14032dfe0  @14032dfe0  [medium:callgraph-r3]  (orig: FUN_14032dfe0)
int FUN_14032dfe0(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  int *piVar4;
  int iVar5;
  longlong lVar6;
  
  iVar5 = 0;
  piVar4 = (int *)(param_1 + 0xd98);
  lVar6 = 0x13;
  do {
    iVar1 = *piVar4;
    if (iVar1 != 0) {
      plVar3 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar3 = (longlong *)0x0;
      }
      lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,iVar1);
      if (lVar2 != 0) {
        iVar1 = FUN_1400fda10(lVar2,0xc,1);
        iVar5 = iVar5 + iVar1;
      }
    }
    piVar4 = piVar4 + 1;
    lVar6 = lVar6 + -1;
  } while (lVar6 != 0);
  return iVar5;
}

// ==== CMsgProcessGoalTaskOpt::helper_14032e080  @14032e080  [medium:callgraph-r3]  (orig: FUN_14032e080)
int FUN_14032e080(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  int *piVar4;
  int iVar5;
  longlong lVar6;
  
  iVar5 = 0;
  piVar4 = (int *)(param_1 + 0xd98);
  lVar6 = 0x13;
  do {
    iVar1 = *piVar4;
    if (iVar1 != 0) {
      plVar3 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar3 = (longlong *)0x0;
      }
      lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,iVar1);
      if (lVar2 != 0) {
        iVar1 = FUN_1400fda10(lVar2,0xc,1);
        if (iVar5 < iVar1) {
          iVar5 = iVar1;
        }
      }
    }
    piVar4 = piVar4 + 1;
    lVar6 = lVar6 + -1;
  } while (lVar6 != 0);
  return iVar5;
}

// ==== CMsgProcessGoalTaskOpt::helper_14032e130  @14032e130  [medium:callgraph-r3]  (orig: FUN_14032e130)
int FUN_14032e130(longlong param_1,undefined4 param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  int *piVar4;
  int iVar5;
  longlong lVar6;
  
  iVar5 = 0;
  piVar4 = (int *)(param_1 + 0xd98);
  lVar6 = 0x13;
  do {
    iVar1 = *piVar4;
    if (iVar1 != 0) {
      plVar3 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar3 = (longlong *)0x0;
      }
      lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,iVar1);
      if (lVar2 != 0) {
        iVar1 = FUN_140100d10(lVar2,param_2);
        if (iVar5 < iVar1) {
          iVar5 = iVar1;
        }
      }
    }
    piVar4 = piVar4 + 1;
    lVar6 = lVar6 + -1;
  } while (lVar6 != 0);
  return iVar5;
}

// ==== CMsgProcessGoalTaskOpt::helper_14032e1f0  @14032e1f0  [medium:callgraph-r3]  (orig: FUN_14032e1f0)
int FUN_14032e1f0(longlong param_1,int param_2)

{
  int iVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  int iVar5;
  int *piVar6;
  longlong lVar7;
  
  iVar5 = 0;
  piVar6 = (int *)(param_1 + 0xd98);
  lVar7 = 0x13;
  do {
    iVar1 = *piVar6;
    if (iVar1 != 0) {
      plVar4 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar4 = (longlong *)0x0;
      }
      lVar3 = (**(code **)(*plVar4 + 0x60))(plVar4,iVar1);
      if (lVar3 != 0) {
        iVar1 = FUN_1400fda10(lVar3,8,1);
        iVar2 = FUN_1400fda10(lVar3,9,1);
        if (((iVar1 != 0xff) && (iVar1 != 0)) && (param_2 <= iVar1 % 10)) {
          iVar5 = iVar5 + 1;
        }
        if (((iVar2 != 0xff) && (iVar2 != 0)) && (param_2 <= iVar2 % 10)) {
          iVar5 = iVar5 + 1;
        }
      }
    }
    piVar6 = piVar6 + 1;
    lVar7 = lVar7 + -1;
  } while (lVar7 != 0);
  return iVar5;
}

// ==== CMsgProcessGoalTaskOpt::helper_14032e320  @14032e320  [medium:callgraph-r3]  (orig: FUN_14032e320)
int FUN_14032e320(longlong param_1,undefined4 param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  int *piVar4;
  int iVar5;
  longlong lVar6;
  
  iVar5 = 0;
  piVar4 = (int *)(param_1 + 0xd98);
  lVar6 = 0x13;
  do {
    iVar1 = *piVar4;
    if (iVar1 != 0) {
      plVar3 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar3 = (longlong *)0x0;
      }
      lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,iVar1);
      if (lVar2 != 0) {
        iVar1 = FUN_140100e10(lVar2,param_2);
        if (iVar5 < iVar1) {
          iVar5 = iVar1;
        }
      }
    }
    piVar4 = piVar4 + 1;
    lVar6 = lVar6 + -1;
  } while (lVar6 != 0);
  return iVar5;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042bd50  @14042bd50  [medium:callgraph-r3]  (orig: FUN_14042bd50)
undefined8
FUN_14042bd50(undefined8 param_1,undefined8 param_2,longlong *param_3,int param_4,undefined4 param_5
             )

{
  longlong *plVar1;
  
  if (param_3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_4 - 3U < 3) {
    plVar1 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,param_4);
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_5);
    (**(code **)(*param_3 + 0x38))(param_3,0);
    return 1;
  }
  return 0;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042c720  @14042c720  [medium:callgraph-r2]  (orig: FUN_14042c720)
bool FUN_14042c720(longlong param_1,longlong *param_2,longlong *param_3)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong lVar5;
  ulonglong uVar6;
  undefined8 uVar7;
  longlong lVar8;
  
  if ((param_2 == (longlong *)0x0) || (param_3 == (longlong *)0x0)) {
    return false;
  }
  plVar4 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,4);
  lVar5 = (**(code **)(*plVar4 + 0x58))(plVar4);
  plVar4 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,1);
  iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
  lVar8 = 0;
  switch(iVar2 + -1) {
  case 0:
    uVar6 = (**(code **)(param_2[2] + 0x70))(param_2 + 2);
    bVar1 = lVar5 <= (longlong)(uVar6 & 0xffffffff);
    break;
  case 1:
    uVar6 = (**(code **)(*param_2 + 0x108))(param_2);
    bVar1 = lVar5 <= (longlong)(uVar6 & 0xffffffff);
    break;
  default:
    goto switchD_14042c7af_caseD_2;
  case 4:
    plVar4 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,3);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    iVar2 = FUN_14032dee0(param_2,uVar3);
    bVar1 = lVar5 <= iVar2;
    break;
  case 5:
    bVar1 = lVar5 <= (longlong)
                     (ulonglong)
                     ((uint)*(byte *)((longlong)param_2 + 0xeee) +
                     (*(byte *)((longlong)param_2 + 0xeee) / 10) * -10);
    break;
  case 9:
    iVar2 = FUN_140160850(param_2);
    bVar1 = lVar5 <= iVar2;
    break;
  case 10:
    plVar4 = (longlong *)FUN_140087ed0();
    lVar8 = *plVar4;
    uVar3 = (**(code **)(param_2[2] + 0x170))();
    iVar2 = (**(code **)(lVar8 + 0x2c8))(plVar4,uVar3);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0xc:
    plVar4 = (longlong *)FUN_1401183a0();
    lVar8 = *plVar4;
    uVar3 = (**(code **)(*param_2 + 8))(param_2);
    lVar8 = (**(code **)(lVar8 + 0x148))(plVar4,uVar3);
    bVar1 = lVar5 <= lVar8;
    break;
  case 0x13:
    iVar2 = FUN_14032dd10(param_2);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0x15:
    iVar2 = FUN_14032dfe0(param_2);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0x16:
    iVar2 = FUN_14032e080(param_2);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0x17:
    uVar3 = (**(code **)(*param_2 + 8))(param_2);
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
    uVar7 = FUN_140117ed0(uVar7);
    iVar2 = FUN_140158cf0(uVar7,uVar3);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0x1a:
    iVar2 = FUN_14032e1f0(param_2,0);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0x1b:
    iVar2 = FUN_14032e1f0(param_2,3);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0x1c:
    plVar4 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,3);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    iVar2 = FUN_14032e130(param_2,uVar3);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0x1d:
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
    uVar7 = FUN_140087ab0(uVar7);
    iVar2 = FUN_1402e8d10(uVar7,param_2);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0x21:
    uVar3 = (**(code **)(*param_2 + 8))(param_2);
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
    uVar7 = FUN_140087ba0(uVar7);
    uVar6 = FUN_1401e8470(uVar7,uVar3);
    bVar1 = lVar5 <= (longlong)(uVar6 & 0xffffffff);
    break;
  case 0x22:
    uVar3 = *(undefined4 *)((longlong)param_2 + 0xf2c);
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
    plVar4 = (longlong *)FUN_1400876b0(uVar7);
    lVar8 = (**(code **)(*plVar4 + 0x10))(plVar4,uVar3,1);
    if (lVar8 != 0) {
      iVar2 = (**(code **)(**(longlong **)(lVar8 + 0x58) + 0x10))(*(longlong **)(lVar8 + 0x58),0xf);
      return lVar5 <= iVar2;
    }
LAB_14042ca91:
    bVar1 = false;
    break;
  case 0x23:
    iVar2 = (**(code **)(*param_2 + 0x48))(param_2);
    bVar1 = lVar5 <= (longlong)(ulonglong)(iVar2 != 0);
    break;
  case 0x24:
    lVar8 = FUN_140165370(param_2);
    bVar1 = lVar5 <= lVar8;
    break;
  case 0x28:
    plVar4 = (longlong *)CurrentInstanceGet();
    lVar8 = 0;
    if (plVar4 != (longlong *)0x0) {
      plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,0x10);
      if (plVar4 != (longlong *)0x0) {
        lVar8 = *plVar4;
        uVar3 = (**(code **)(*param_2 + 8))(param_2);
        iVar2 = (**(code **)(lVar8 + 0x88))(plVar4,uVar3,2);
        return lVar5 <= iVar2;
      }
      goto LAB_14042ca91;
    }
    goto switchD_14042c7af_caseD_2;
  case 0x2a:
    iVar2 = FUN_14018eb30(param_2);
    bVar1 = lVar5 <= iVar2;
    break;
  case 0x2b:
    iVar2 = FUN_140160840(param_2);
    bVar1 = lVar5 <= (longlong)(ulonglong)(iVar2 != 0);
    break;
  case 0x2d:
    plVar4 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,3);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    iVar2 = FUN_14032e320(param_2,uVar3);
    lVar8 = (longlong)iVar2;
switchD_14042c7af_caseD_2:
    bVar1 = lVar5 <= lVar8;
  }
  return bVar1;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042e9f0  @14042e9f0  [medium:callgraph-r2]  (orig: FUN_14042e9f0)
bool FUN_14042e9f0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  int iVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar9 != local_10) {
    lVar9 = 0;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = *(longlong **)(lVar4 + 0x20);
    if (plVar7 != (longlong *)0x0) {
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,5);
      iVar5 = (**(code **)(*plVar7 + 0x48))(plVar7);
      return iVar5 == 1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return false;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042eb40  @14042eb40  [medium:callgraph-r2]  (orig: FUN_14042eb40)
void FUN_14042eb40(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar8 == local_10) {
    log_InlineLogERROR(
                      "CPlayerProcessGoal::SetProcessGoalAwardRecieved: goal%u is not existed, user%u"
                      );
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar8 = *(longlong *)(lVar4 + 0x20);
    if (lVar8 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      FUN_14042bd50(param_1,param_2,lVar8,5,1);
    }
  }
  return;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042ecb0  @14042ecb0  [medium:callgraph-r2]  (orig: FUN_14042ecb0)
bool FUN_14042ecb0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  int iVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong lVar8;
  uint uVar9;
  longlong lVar10;
  undefined8 *puVar11;
  double dVar12;
  double dVar13;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar11 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar11 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar11 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar11[2];
      puVar11 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar11;
    }
    puVar3 = puVar11;
    puVar11 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar11 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar11) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar10 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar8 = local_10;
  if (lVar10 != local_10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar8 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = *(longlong **)(lVar8 + 0x20);
    if (plVar7 != (longlong *)0x0) {
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
      iVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
      lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
      lVar10 = *(longlong *)(lVar8 + 0x200);
      if (*(longlong *)(lVar8 + 0x200) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar10 = 0;
      }
      uVar5 = FUN_140268600(lVar10,param_2);
      dVar12 = DAT_14075dd60;
      dVar13 = DAT_14075cb60;
      uVar9 = uVar5;
      if ((int)uVar5 < 0) {
        uVar9 = -uVar5;
      }
      while( true ) {
        if ((uVar9 & 1) != 0) {
          dVar13 = dVar13 * dVar12;
        }
        if (uVar9 >> 1 == 0) break;
        dVar12 = dVar12 * dVar12;
        uVar9 = uVar9 >> 1;
      }
      if ((int)uVar5 < 0) {
        dVar13 = DAT_14075cb60 / dVar13;
      }
      return iVar4 == (int)dVar13 + -1;
    }
  }
  return false;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042ee80  @14042ee80  [medium:callgraph-r2]  (orig: FUN_14042ee80)
bool FUN_14042ee80(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2 / 100) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 / 100 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar9 != local_10) {
    lVar9 = 0;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = *(longlong **)(lVar4 + 0x20);
    if (plVar7 != (longlong *)0x0) {
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,3);
      uVar5 = (**(code **)(*plVar7 + 0x48))(plVar7);
      return (uVar5 >> (param_2 % 100 - 1 & 0x1f) & 1) != 0;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return false;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042f000  @14042f000  [medium:callgraph-r2]  (orig: FUN_14042f000)
bool FUN_14042f000(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2 / 100) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 / 100 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar9 != local_10) {
    lVar9 = 0;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = *(longlong **)(lVar4 + 0x20);
    if (plVar7 != (longlong *)0x0) {
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
      uVar5 = (**(code **)(*plVar7 + 0x48))(plVar7);
      return (uVar5 >> (param_2 % 100 - 1 & 0x1f) & 1) != 0;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return false;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042f180  @14042f180  [medium:callgraph-r3]  (orig: FUN_14042f180)
longlong FUN_14042f180(longlong param_1,longlong param_2)

{
  void *pvVar1;
  void *_Src;
  void *_Dst;
  char cVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  longlong lVar6;
  rsize_t _DstSize;
  ulonglong uVar7;
  
  if (param_1 != param_2) {
    _Src = *(void **)(param_2 + 0x18);
    uVar3 = *(longlong *)(param_2 + 0x20) - (longlong)_Src >> 3;
    if (uVar3 == 0) {
      FUN_14042e220();
      return param_1;
    }
    _Dst = *(void **)(param_1 + 0x18);
    uVar7 = *(longlong *)(param_1 + 0x20) - (longlong)_Dst >> 3;
    if (uVar3 <= uVar7) {
      lVar6 = *(longlong *)(param_2 + 0x20) - (longlong)_Src >> 3;
      if (0 < lVar6) {
        _DstSize = lVar6 << 3;
        memmove_s(_Dst,_DstSize,_Src,_DstSize);
      }
      *(longlong *)(param_1 + 0x20) =
           *(longlong *)(param_1 + 0x18) +
           (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3) * 8;
      return param_1;
    }
    if (_Dst == (void *)0x0) {
      uVar5 = 0;
    }
    else {
      uVar5 = *(longlong *)(param_1 + 0x28) - (longlong)_Dst >> 3;
    }
    if (uVar3 <= uVar5) {
      pvVar1 = (void *)((longlong)_Src + uVar7 * 8);
      FUN_14042d590(_Src,pvVar1,_Dst);
      uVar4 = FUN_14042d5d0(param_1,pvVar1,*(undefined8 *)(param_2 + 0x20),
                            *(undefined8 *)(param_1 + 0x20));
      *(undefined8 *)(param_1 + 0x20) = uVar4;
      return param_1;
    }
    if (_Dst != (void *)0x0) {
      operator_delete(_Dst);
    }
    cVar2 = FUN_14042d270(param_1,*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3
                         );
    if (cVar2 != '\0') {
      uVar4 = FUN_14042d5d0(param_1,*(undefined8 *)(param_2 + 0x18),*(undefined8 *)(param_2 + 0x20),
                            *(undefined8 *)(param_1 + 0x18));
      *(undefined8 *)(param_1 + 0x20) = uVar4;
    }
  }
  return param_1;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042f520  @14042f520  [medium:callgraph-r2]  (orig: FUN_14042f520)
void FUN_14042f520(longlong param_1,uint param_2,undefined8 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x51);
  puVar3 = *(undefined8 **)(param_1 + 0x78);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x51);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x78);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x48);
  if (*(longlong *)(param_1 + 0x48) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x78);
    local_28 = *(longlong *)(param_1 + 0x48);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0x78);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((*(longlong **)(param_1 + 0x48) == (longlong *)0x0) ||
     (*(longlong **)(param_1 + 0x48) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar8 != local_10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_14042f180(param_3,lVar4 + 0x20);
  }
  return;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042f640  @14042f640  [medium:callgraph-r1]  (orig: FUN_14042f640)
undefined8 FUN_14042f640(longlong param_1,longlong *param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  undefined2 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  IStringManager *pIVar10;
  ulonglong uVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  
  if ((((param_2 != (longlong *)0x0) && (param_3 != 0)) &&
      (cVar2 = FUN_14042e9f0(param_1,param_3), cVar2 == '\0')) &&
     (cVar2 = FUN_14042ecb0(param_1,param_3), cVar2 != '\0')) {
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
    uVar7 = FUN_140118060(uVar7);
    plVar8 = (longlong *)FUN_140268970(uVar7,param_3);
    if (plVar8 != (longlong *)0x0) {
      iVar14 = 3;
      iVar12 = 0;
      iVar13 = 3;
      do {
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar13);
        iVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar13 + 1);
        iVar5 = (**(code **)(*plVar9 + 0x48))(plVar9);
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar13 + 2);
        uVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
        if ((iVar4 != 0) && (0 < iVar5)) {
          iVar4 = FUN_140339ba0(param_2,iVar4,iVar5,uVar3);
          iVar12 = iVar12 + iVar4;
        }
        iVar13 = iVar13 + 3;
      } while (iVar13 < 10);
      if ((iVar12 < 1) ||
         ((ulonglong)((param_2[0x185] - param_2[0x184] >> 2) + (longlong)iVar12) < 0x29)) {
        FUN_14042eb40(param_1,param_3);
        do {
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar14);
          iVar12 = (**(code **)(*plVar9 + 0x40))(plVar9);
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar14 + 1);
          uVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
          uVar11 = (ulonglong)uVar6;
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar14 + 2);
          uVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
          if ((iVar12 != 0) && (0 < (int)uVar6)) {
            cVar2 = FUN_140102780(iVar12);
            if (cVar2 == '\0') {
              if (0 < (int)uVar6) {
                do {
                  iVar13 = FUN_14034a8d0(param_2,iVar12,uVar3,1,1,0,1);
                  if (iVar13 == 0) {
                    (**(code **)(*param_2 + 8))(param_2);
                    log_InlineLogERROR(
                                      "CPlayerProcessGoal::RecieveProcessGoalAward, AwardItem user_id[%u] item_type[%u] amount[%d], monoply[%d] error."
                                      );
                  }
                  uVar11 = uVar11 - 1;
                } while (uVar11 != 0);
              }
            }
            else {
              iVar12 = FUN_14033f6b0(param_2,iVar12,uVar6,uVar3,1,1,0);
              if (iVar12 == 0) {
                (**(code **)(*param_2 + 8))(param_2);
                log_InlineLogERROR(
                                  "CPlayerProcessGoal::RecieveProcessGoalAward, AwardMultiItem user_id[%u] item_type[%u] amount[%d], monoply[%d] error."
                                  );
              }
            }
          }
          iVar14 = iVar14 + 3;
        } while (iVar14 < 10);
        uVar7 = 1;
      }
      else {
        pIVar10 = theInstance();
        lVar1 = param_2[2];
        uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_ACTIVITY_REWARD_ITEM_NEED_SAPRE");
        (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar7,iVar12);
        uVar7 = 0;
      }
      return uVar7;
    }
  }
  return 0;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042f920  @14042f920  [medium:callgraph-r1]  (orig: FUN_14042f920)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14042f920(longlong param_1,longlong param_2,int param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined1 uVar3;
  char cVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong lVar9;
  int iVar10;
  longlong *plVar11;
  int iVar12;
  undefined1 auStack_4f8 [32];
  undefined4 local_4d8;
  longlong *local_4c8 [3];
  longlong *local_4b0;
  longlong *local_4a8;
  undefined8 local_4a0;
  longlong *local_498;
  longlong *local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (param_2 == 0) {
    local_4d8 = 0x1f2;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar3 = FUN_14042e9f0(param_1,param_3);
    FUN_1404df690(local_478);
    cVar4 = FUN_1404df750(local_478,param_3,uVar3);
    if (cVar4 != '\0') {
      lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
      lVar9 = *(longlong *)(lVar9 + 0x200);
      if (lVar9 == 0) {
        local_4d8 = 0x164;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar9 = 0;
      }
      iVar6 = FUN_140268600(lVar9,param_3);
      iVar12 = 1;
      if (0 < iVar6) {
        iVar10 = param_3 * 100;
        do {
          iVar10 = iVar10 + 1;
          cVar4 = FUN_14042f000(param_1,iVar10);
          if (((cVar4 != '\0') || (cVar5 = FUN_14042ee80(param_1,iVar10), cVar5 != '\0')) &&
             (cVar5 = FUN_1404df7d0(local_478,iVar10,0,cVar4), cVar5 == '\0')) {
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                      ((longlong *)(param_2 + 0x10),local_478);
            cVar5 = FUN_1404df750(local_478,param_3);
            if (cVar5 == '\0') {
              local_4d8 = 0x20a;
              log_InlineLogERROR(&DAT_1406d9c10);
              FUN_1404df6e0(local_478);
              return;
            }
            FUN_1404df7d0(local_478,iVar10,0,cVar4);
          }
          iVar12 = iVar12 + 1;
        } while (iVar12 <= iVar6);
      }
      local_498 = operator_new(8);
      if (local_498 == (longlong *)0x0) {
        local_4c8[0] = (longlong *)0x0;
      }
      else {
        *local_498 = (longlong)local_4c8;
        local_4c8[0] = local_498;
      }
      local_4b0 = (longlong *)0x0;
      local_4a8 = (longlong *)0x0;
      local_4a0 = 0;
      local_490 = local_498;
      FUN_14042f520(param_1,param_3,local_4c8);
      plVar11 = local_4b0;
      plVar1 = local_4c8[0];
      if (local_4a8 < local_4b0) {
        _invalid_parameter_noinfo();
        plVar1 = local_4c8[0];
      }
      while( true ) {
        plVar2 = local_4a8;
        if (local_4a8 < local_4b0) {
          _invalid_parameter_noinfo();
        }
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_4c8[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar11 == plVar2) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = 0;
        }
        else {
          lVar9 = *plVar1;
        }
        if (*(longlong **)(lVar9 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        lVar9 = *plVar11;
        if (lVar9 != 0) {
          uVar7 = FUN_1404df2e0(lVar9);
          uVar8 = FUN_1404ded60(lVar9,3);
          cVar4 = FUN_1404df7d0(local_478,uVar7,uVar8,0);
          if (cVar4 == '\0') {
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                      ((longlong *)(param_2 + 0x10),local_478);
            cVar4 = FUN_1404df750(local_478,param_3,uVar3);
            if (cVar4 == '\0') {
              local_4d8 = 0x221;
              log_InlineLogERROR(&DAT_1406d9c10);
              if (local_4b0 != (longlong *)0x0) {
                operator_delete(local_4b0);
              }
              local_4b0 = (longlong *)0x0;
              local_4a8 = (longlong *)0x0;
              local_4a0 = 0;
              operator_delete(local_4c8[0]);
              FUN_1404df6e0(local_478);
              return;
            }
            FUN_1404df7d0(local_478,uVar7,uVar8,0);
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = 0;
        }
        else {
          lVar9 = *plVar1;
        }
        if (*(longlong **)(lVar9 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        plVar11 = plVar11 + 1;
      }
      (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_478);
      if (local_4b0 != (longlong *)0x0) {
        operator_delete(local_4b0);
      }
      local_4b0 = (longlong *)0x0;
      local_4a8 = (longlong *)0x0;
      local_4a0 = 0;
      operator_delete(local_4c8[0]);
      FUN_1404df6e0(local_478);
      return;
    }
    local_4d8 = 0x1f9;
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_1404df6e0(local_478);
  }
  return;
}

// ==== CMsgProcessGoalTaskOpt::helper_14042ffa0  @14042ffa0  [medium:callgraph-r3]  (orig: FUN_14042ffa0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

longlong * FUN_14042ffa0(longlong param_1,undefined4 param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined1 auStack_458 [32];
  undefined4 local_438;
  undefined4 local_428 [4];
  char local_418;
  undefined1 local_417 [1023];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  local_418 = '\0';
  local_428[0] = param_2;
  memset(local_417,0,0x3ff);
  local_438 = param_2;
  _snprintf(&local_418,0x3ff,
            "SELECT count(id) FROM cq_player_process_goal WHERE user_id=%u AND goal_id=%u");
  FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
  puVar1 = (undefined8 *)InstanceGet();
  lVar2 = (**(code **)*puVar1)(puVar1,&local_418);
  if (lVar2 == 0) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
    lVar2 = *(longlong *)(lVar2 + 0x210);
    if (lVar2 == 0) {
      local_438 = 0x165;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar2 = 0;
    }
    plVar3 = (longlong *)FUN_14028deb0(lVar2,5);
    if (plVar3 == (longlong *)0x0) {
      log_InlineLogERROR("pop cq_player_process_goal rec err:user=%u,goal=%u");
      plVar3 = (longlong *)0x0;
    }
    else {
      plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,1);
      (**(code **)(*plVar4 + 0xb8))(plVar4,*(undefined4 *)(param_1 + 0x88));
      plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,2);
      (**(code **)(*plVar4 + 0xb8))(plVar4,param_2);
      (**(code **)(*plVar3 + 0x38))(plVar3,0);
      puVar1 = (undefined8 *)FUN_14037b790(param_1 + 8,local_428);
      *puVar1 = plVar3;
    }
  }
  else {
    log_InlineLogERROR("cq_player_process_goal data is exist, user=%u,goal=%u");
    plVar3 = (longlong *)0x0;
  }
  return plVar3;
}

// ==== CMsgProcessGoalTaskOpt::helper_140430150  @140430150  [medium:callgraph-r2]  (orig: FUN_140430150)
void FUN_140430150(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  uint uVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong **pplVar9;
  longlong lVar10;
  rsize_t _DstSize;
  uint uVar11;
  undefined8 *puVar12;
  longlong *local_48;
  longlong *local_40;
  longlong *local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong *local_20;
  
  puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  uVar11 = param_2 / 100;
  cVar1 = *(char *)((longlong)puVar12 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar12 + 3) < uVar11) {
      puVar8 = (undefined8 *)puVar12[2];
      puVar12 = puVar3;
    }
    else {
      puVar8 = (undefined8 *)*puVar12;
    }
    puVar3 = puVar12;
    puVar12 = puVar8;
    cVar1 = *(char *)((longlong)puVar8 + 0x29);
  }
  puVar12 = *(undefined8 **)(param_1 + 0x38);
  local_40 = puVar3;
  local_48 = *(longlong **)(param_1 + 8);
  if (*(longlong **)(param_1 + 8) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar12) || (uVar11 < *(uint *)(puVar3 + 3))) {
    pplVar9 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x38);
    local_38 = *(longlong **)(param_1 + 8);
  }
  else {
    pplVar9 = &local_48;
  }
  plVar6 = *pplVar9;
  plVar7 = *(longlong **)(param_1 + 0x38);
  local_28 = plVar6;
  local_20 = pplVar9[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar6)) {
    _invalid_parameter_noinfo();
  }
  plVar4 = local_20;
  if (plVar7 == local_20) {
    plVar6 = (longlong *)FUN_14042ffa0(param_1,uVar11);
  }
  else {
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar6;
    }
    if (plVar4 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar6 = (longlong *)plVar4[4];
  }
  if (plVar6 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,3);
    uVar5 = (**(code **)(*plVar7 + 0x48))(plVar7);
    FUN_14042bd50(param_1,uVar11,plVar6,3,
                  1 << (((char)param_2 + (char)uVar11 * -100) - 1U & 0x1f) | uVar5);
    puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
    cVar1 = *(char *)((longlong)puVar12 + 0x51);
    puVar3 = *(undefined8 **)(param_1 + 0x78);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar12 + 3) < uVar11) {
        puVar8 = (undefined8 *)puVar12[2];
        puVar12 = puVar3;
      }
      else {
        puVar8 = (undefined8 *)*puVar12;
      }
      puVar3 = puVar12;
      puVar12 = puVar8;
      cVar1 = *(char *)((longlong)puVar8 + 0x51);
    }
    puVar12 = *(undefined8 **)(param_1 + 0x78);
    local_20 = puVar3;
    local_28 = *(longlong **)(param_1 + 0x48);
    if (*(longlong **)(param_1 + 0x48) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar12) || (uVar11 < *(uint *)(puVar3 + 3))) {
      pplVar9 = &local_38;
      local_30 = *(undefined8 *)(param_1 + 0x78);
      local_38 = *(longlong **)(param_1 + 0x48);
    }
    else {
      pplVar9 = &local_28;
    }
    plVar6 = *pplVar9;
    plVar7 = *(longlong **)(param_1 + 0x78);
    local_48 = plVar6;
    local_40 = pplVar9[1];
    if ((*(longlong **)(param_1 + 0x48) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0x48) != plVar6)) {
      _invalid_parameter_noinfo();
    }
    plVar4 = local_40;
    if (plVar7 != local_40) {
      if (plVar6 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar6;
      }
      if (plVar4 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar6 = (longlong *)plVar4[7];
      if ((longlong *)plVar4[8] < plVar6) {
        _invalid_parameter_noinfo();
      }
      plVar7 = (longlong *)plVar4[4];
      do {
        plVar2 = (longlong *)plVar4[8];
        if (plVar2 < (longlong *)plVar4[7]) {
          _invalid_parameter_noinfo();
        }
        if ((plVar7 == (longlong *)0x0) || (plVar7 != (longlong *)plVar4[4])) {
          _invalid_parameter_noinfo();
        }
        if (plVar6 == plVar2) {
          return;
        }
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar7;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar6) {
          _invalid_parameter_noinfo();
        }
        lVar10 = *plVar6;
        if (lVar10 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          uVar11 = FUN_1404df2e0(lVar10);
          if (uVar11 == param_2) {
            FUN_1404df640(lVar10);
            lVar10 = plVar4[8] - (longlong)(plVar6 + 1) >> 3;
            if (0 < lVar10) {
              _DstSize = lVar10 << 3;
              memmove_s(plVar6,_DstSize,plVar6 + 1,_DstSize);
            }
            plVar4[8] = plVar4[8] + -8;
            if (((longlong *)plVar4[7] <= plVar6) && (plVar6 <= (longlong *)plVar4[8])) {
              return;
            }
            _invalid_parameter_noinfo();
            return;
          }
        }
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar7;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar6) {
          _invalid_parameter_noinfo();
        }
        plVar6 = plVar6 + 1;
      } while( true );
    }
  }
  return;
}

// ==== CMsgProcessGoalTaskOpt::helper_1404304d0  @1404304d0  [medium:callgraph-r2]  (orig: FUN_1404304d0)
void FUN_1404304d0(longlong param_1,uint param_2)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  uint uVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  uint uVar9;
  longlong lVar10;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  uVar9 = param_2 / 100;
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar2 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < uVar9) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar2;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar2 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_40 = puVar2;
  local_48 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar8) || (uVar9 < *(uint *)(puVar2 + 3))) {
    plVar6 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x38);
    local_38 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar6 = &local_48;
  }
  plVar7 = (longlong *)*plVar6;
  lVar10 = *(longlong *)(param_1 + 0x38);
  local_28 = plVar7;
  local_20 = plVar6[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar7)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_20;
  if (lVar10 == local_20) {
    plVar6 = (longlong *)FUN_14042ffa0(param_1,uVar9);
  }
  else {
    if (plVar7 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar7;
    }
    if (lVar3 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar6 = *(longlong **)(lVar3 + 0x20);
  }
  if (plVar6 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
    uVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
    FUN_14042bd50(param_1,uVar9,plVar6,4,
                  1 << (((char)param_2 + (char)uVar9 * -100) - 1U & 0x1f) | uVar4);
  }
  return;
}

// ==== CMsgProcessGoalTaskOpt::helper_140430c00  @140430c00  [medium:callgraph-r2]  (orig: FUN_140430c00)
longlong * FUN_140430c00(undefined8 param_1,uint param_2)

{
  undefined8 *puVar1;
  uint uVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *local_60 [3];
  undefined8 *local_48;
  undefined8 *local_40;
  undefined8 local_38;
  
  plVar3 = operator_new(8);
  plVar6 = (longlong *)0x0;
  local_60[0] = plVar6;
  if (plVar3 != (longlong *)0x0) {
    *plVar3 = (longlong)local_60;
    local_60[0] = plVar3;
  }
  local_48 = (undefined8 *)0x0;
  local_40 = (undefined8 *)0x0;
  local_38 = 0;
  FUN_14042f520(param_1,(ulonglong)param_2 / 100,local_60);
  puVar5 = local_48;
  plVar3 = local_60[0];
  if (local_40 < local_48) {
    _invalid_parameter_noinfo();
    plVar3 = local_60[0];
  }
  while( true ) {
    puVar1 = local_40;
    if (local_40 < local_48) {
      _invalid_parameter_noinfo();
    }
    if ((plVar3 == (longlong *)0x0) || (plVar3 != local_60[0])) {
      _invalid_parameter_noinfo();
    }
    plVar4 = plVar6;
    if (puVar5 == puVar1) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      plVar4 = (longlong *)*plVar3;
    }
    if ((undefined8 *)plVar4[4] <= puVar5) {
      _invalid_parameter_noinfo();
    }
    plVar4 = (longlong *)*puVar5;
    if (plVar4 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar2 = FUN_1404df2e0(plVar4);
      if (uVar2 == param_2) break;
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar4 = plVar6;
    }
    else {
      plVar4 = (longlong *)*plVar3;
    }
    if ((undefined8 *)plVar4[4] <= puVar5) {
      _invalid_parameter_noinfo();
    }
    puVar5 = puVar5 + 1;
  }
  if (local_48 != (undefined8 *)0x0) {
    operator_delete(local_48);
  }
  local_48 = (undefined8 *)0x0;
  local_40 = (undefined8 *)0x0;
  local_38 = 0;
  operator_delete(local_60[0]);
  return plVar4;
}

// ==== CMsgProcessGoalTaskOpt::helper_140430db0  @140430db0  [medium:callgraph-r1]  (orig: FUN_140430db0)
undefined8 FUN_140430db0(longlong param_1,longlong *param_2,uint param_3)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  
  if (param_2 == (longlong *)0x0) {
    return 0;
  }
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
  lVar6 = *(longlong *)(lVar6 + 0x200);
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar6 = 0;
  }
  plVar7 = (longlong *)FUN_140268870(lVar6,param_3);
  if (plVar7 == (longlong *)0x0) {
    return 0;
  }
  iVar3 = (**(code **)(*param_2 + 0x108))(param_2);
  iVar4 = (**(code **)(param_2[2] + 0x70))(param_2 + 2);
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
  lVar6 = *(longlong *)(lVar6 + 0x200);
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar6 = 0;
  }
  iVar5 = FUN_1402684b0(lVar6,(ulonglong)param_3 / 100);
  if (iVar3 * 1000 + iVar4 < iVar5) {
    return 0;
  }
  plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,2);
  iVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
  if (iVar3 == 1) {
    cVar1 = FUN_14042c720(param_1,param_2,plVar7);
  }
  else {
    if (iVar3 != 0) goto LAB_140430f09;
    cVar1 = FUN_14042ee80(param_1,param_3);
  }
  if (cVar1 == '\0') {
    return 0;
  }
LAB_140430f09:
  cVar1 = FUN_14042f000(param_1,param_3);
  if (cVar1 != '\0') {
    return 0;
  }
  plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,5);
  iVar3 = (**(code **)(*plVar8 + 0x40))(plVar8);
  plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,6);
  iVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
  plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,7);
  uVar2 = (**(code **)(*plVar7 + 0x48))(plVar7);
  if ((iVar3 != 0) && (0 < iVar4)) {
    iVar5 = FUN_140339ba0(param_2,iVar3,iVar4,uVar2);
    if ((iVar5 < 1) ||
       ((ulonglong)((param_2[0x185] - param_2[0x184] >> 2) + (longlong)iVar5) < 0x29)) {
      FUN_1404304d0(param_1,param_3);
      iVar3 = FUN_14034a8d0(param_2,iVar3,uVar2,1,iVar4,0,1);
      if (iVar3 != 0) {
        return 1;
      }
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogERROR(
                        "CPlayerProcessGoal::RecieveTaskAward, AwardItem user_id[%u] item_type[%u] amount[%d], monoply[%d] error."
                        );
    }
    else {
      pIVar9 = theInstance();
      lVar6 = param_2[2];
      uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_ACTIVITY_REWARD_ITEM_NEED_SAPRE");
      (**(code **)(lVar6 + 0x358))(param_2 + 2,uVar10,iVar5);
    }
  }
  return 0;
}

// ==== CMsgProcessGoalTaskOpt::helper_1404313a0  @1404313a0  [medium:callgraph-r1]  (orig: FUN_1404313a0)
void FUN_1404313a0(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  char cVar2;
  
  cVar2 = FUN_14042ee80();
  if (cVar2 == '\0') {
    cVar2 = FUN_14042f000(param_1,param_2);
    if (cVar2 == '\0') {
      lVar1 = FUN_140430c00(param_1,param_2);
      if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001404313ef. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        log_InlineLogERROR("CPlayerProcessGoal::CompleteTask: task %u is exited, user = %u");
        return;
      }
      FUN_140430150(param_1,param_2);
    }
  }
  return;
}

// ==== CMsgProcessGoalTaskOpt::ctor_or_dtor  @140459630  [high:vtable-assign]  (orig: FUN_140459630)
undefined8 * FUN_140459630(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgProcessGoalTaskOpt::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgProcessGoalTaskOpt::ctor_or_dtor  @140459680  [high:vtable-assign]  (orig: FUN_140459680)
void FUN_140459680(undefined8 *param_1)

{
  *param_1 = CMsgProcessGoalTaskOpt::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgProcessGoalTaskOpt::vfunc_1  @1404596b0  [high:rtti-vtable]  (orig: FUN_1404596b0)
bool FUN_1404596b0(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xb0e;
    }
  }
  return false;
}

// ==== CMsgProcessGoalTaskOpt::ctor_or_dtor  @1404596f0  [high:vtable-assign]  (orig: FUN_1404596f0)
undefined8 * FUN_1404596f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgProcessGoalTaskOpt::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgProcessGoalTaskOpt::vfunc_3  @140459740  [high:rtti-vtable]  (orig: FUN_140459740)
void FUN_140459740(longlong param_1)

{
  char *pcVar1;
  char cVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar3 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))
                      (*(longlong **)(lVar3 + 0x90),param_1);
    if ((lVar3 != 0) && (cVar2 = FUN_140167b70(lVar3), cVar2 == '\0')) {
      pcVar1 = *(char **)(param_1 + 0x428);
      cVar2 = *pcVar1;
      if (cVar2 == '\0') {
        uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar4 = FUN_140118060(uVar4);
        FUN_140268bb0(uVar4,lVar3,*(undefined4 *)(pcVar1 + 1));
      }
      else {
        if (cVar2 == '\x01') {
          uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar4 = FUN_140118060(uVar4);
          cVar2 = FUN_140268a70(uVar4,lVar3,*(undefined4 *)(pcVar1 + 1));
        }
        else {
          if (cVar2 != '\x02') {
            if (cVar2 != '\x03') {
              return;
            }
            uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            uVar4 = FUN_140118060(uVar4);
            FUN_140268e70(uVar4,lVar3,*(undefined4 *)(pcVar1 + 1));
            return;
          }
          uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar4 = FUN_140118060(uVar4);
          cVar2 = FUN_140268b10(uVar4,lVar3,*(undefined4 *)(pcVar1 + 1));
        }
        if (cVar2 != '\0') {
                    /* WARNING: Could not recover jumptable at 0x00014045988c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,param_1);
          return;
        }
      }
    }
  }
  return;
}

// ==== CMsgProcessGoalTaskOpt::helper_1404ded60  @1404ded60  [medium:callgraph-r2]  (orig: FUN_1404ded60)
undefined8 FUN_1404ded60(longlong param_1,uint param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if ((*(longlong *)(param_1 + 8) != 0) && (param_2 < 4)) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 8) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x0001404ded84. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CMsgProcessGoalTaskOpt::helper_1404df2e0  @1404df2e0  [medium:callgraph-r2]  (orig: FUN_1404df2e0)
undefined8 FUN_1404df2e0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
                    /* WARNING: Could not recover jumptable at 0x0001404df30b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
  return uVar2;
}

// ==== CMsgProcessGoalTaskOpt::helper_1404df640  @1404df640  [medium:callgraph-r3]  (orig: FUN_1404df640)
void FUN_1404df640(undefined8 *param_1)

{
  undefined8 *puVar1;
  char cVar2;
  
  cVar2 = FUN_1404def60();
  if (cVar2 != '\0') {
    (*(code *)**(undefined8 **)param_1[1])((undefined8 *)param_1[1],0);
    param_1[1] = 0;
  }
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,0);
    param_1[1] = 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001404df68d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)*param_1)(param_1,1);
  return;
}

// ==== CMsgProcessGoalTaskOpt::helper_1404df750  @1404df750  [medium:callgraph-r2]  (orig: FUN_1404df750)
ulonglong FUN_1404df750(longlong param_1,undefined4 param_2,undefined1 param_3)

{
  longlong lVar1;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0xb0f;
  *(undefined4 *)(param_1 + 0xc) = 7;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 5) = 0;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined1 *)(lVar1 + 4) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgProcessGoalTaskOpt::helper_1404df7d0  @1404df7d0  [medium:callgraph-r2]  (orig: FUN_1404df7d0)
ulonglong FUN_1404df7d0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined1 param_4)

{
  ulonglong uVar1;
  short *psVar2;
  longlong lVar3;
  
  uVar1 = (longlong)*(int *)(param_1 + 0xc) + 9;
  if (0x3fb < uVar1) {
    return uVar1 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 9;
  *(undefined4 *)
   ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 5) * 9 + 7 +
   *(longlong *)(param_1 + 0x428)) = param_2;
  *(undefined4 *)
   ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 5) * 9 + 0xb +
   *(longlong *)(param_1 + 0x428)) = param_3;
  *(undefined1 *)
   ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 5) * 9 + 0xf +
   *(longlong *)(param_1 + 0x428)) = param_4;
  lVar3 = *(longlong *)(param_1 + 0x428);
  psVar2 = (short *)(lVar3 + 5);
  *psVar2 = *psVar2 + 1;
  return CONCAT71((int7)((ulonglong)lVar3 >> 8),1);
}

