// ==== CChatKernel::helper_140031d40  @140031d40  [medium:callgraph-r3]  (orig: FUN_140031d40)
undefined8 FUN_140031d40(void)

{
  longlong lVar1;
  
  lVar1 = DAT_140975aa0;
  if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return *(undefined8 *)(lVar1 + 0x18);
}

// ==== CChatKernel::vfunc_4  @140031e60  [high:rtti-vtable]  (orig: FUN_140031e60)
undefined8 FUN_140031e60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return 1;
}

// ==== CChatKernel::helper_140031eb0  @140031eb0  [medium:callgraph-r0]  (orig: FUN_140031eb0)
undefined8
FUN_140031eb0(longlong param_1,undefined8 param_2,int param_3,longlong param_4,int param_5)

{
  if (((param_3 != 0) && (param_4 != 0)) && (param_5 - 1U < 0x400)) {
    FUN_14003fa80(*(undefined4 *)(param_1 + 8));
    return 1;
  }
  return 0;
}

// ==== CChatKernel::helper_140032000  @140032000  [medium:callgraph-r1]  (orig: FUN_140032000)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140032000(longlong param_1,undefined4 param_2,undefined4 param_3,int param_4,void *param_5,
             int param_6,undefined4 param_7)

{
  undefined8 uVar1;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  int local_430;
  undefined4 local_42c;
  int local_428;
  undefined1 local_424 [1036];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  if (param_5 == (void *)0x0) {
    log_InlineLogERROR("CChatKernel::SendCrossMsg Error: null msg point found in.");
    uVar1 = 0;
  }
  else if (param_4 == 0) {
    log_InlineLogERROR("CChatKernel::SendCrossMsg invalid msg type by User[%u].");
    uVar1 = 0;
  }
  else if (param_6 + 4 < 0x401) {
    local_428 = param_6;
    local_42c = param_7;
    local_438 = param_2;
    local_434 = param_3;
    local_430 = param_4;
    memcpy(local_424,param_5,(longlong)param_6);
    local_448 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))(*(longlong **)(param_1 + 0x10),6,0x3fc);
    uVar1 = 1;
  }
  else {
    log_InlineLogERROR("CChatKernel::SendCrossMsg msg length overflow. MsgID:%u, MsgLen:%d");
    uVar1 = 0;
  }
  return uVar1;
}

// ==== CChatKernel::helper_1400320f0  @1400320f0  [medium:callgraph-r0]  (orig: FUN_1400320f0)
ulonglong FUN_1400320f0(undefined8 param_1,int param_2,undefined8 param_3,longlong param_4,
                       undefined4 param_5)

{
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR("CChatKernel::SendOSMsg user id is null!");
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (param_4 == 0) {
    log_InlineLogERROR("CChatKernel::SendOSMsg, NULL message");
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  uVar1 = FUN_140032000(param_1,param_2,param_3,*(undefined4 *)(param_4 + 8),param_4 + 0x10,
                        *(undefined4 *)(param_4 + 0xc),param_5);
  return uVar1;
}

// ==== CChatKernel::vfunc_3  @140032300  [high:rtti-vtable]  (orig: FUN_140032300)
undefined1 FUN_140032300(longlong param_1)

{
  FUN_1400407e0(*(undefined8 *)(param_1 + 0x38));
  return 1;
}

// ==== CChatKernel::helper_140032b80  @140032b80  [medium:callgraph-r3]  (orig: FUN_140032b80)
void FUN_140032b80(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x21) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x21) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x21);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x21);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x21);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x21);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140032ba4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CChatKernel::helper_1400332a0  @1400332a0  [medium:callgraph-r0]  (orig: FUN_1400332a0)
void FUN_1400332a0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  plVar3 = (longlong *)FUN_140006ad0(30000,1,param_3,param_4,0xfffffffffffffffe);
  if ((plVar3 != (longlong *)0x0) && (iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3), iVar1 != 0)) {
    plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,"data1");
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(undefined4 *)(param_1 + 0xc0) = uVar2;
    (**(code **)*plVar3)(plVar3);
    return;
  }
  if (plVar3 != (longlong *)0x0) {
    (**(code **)*plVar3)(plVar3);
  }
  return;
}

// ==== CChatKernel::helper_140033540  @140033540  [medium:callgraph-r3]  (orig: FUN_140033540)
void FUN_140033540(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x21) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CChatKernel::helper_1400335a0  @1400335a0  [medium:callgraph-r3]  (orig: FUN_1400335a0)
void FUN_1400335a0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x21) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CChatKernel::helper_140033af0  @140033af0  [medium:callgraph-r1]  (orig: FUN_140033af0)
void FUN_140033af0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x21);
  while (cVar1 == '\0') {
    FUN_140033af0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x21);
  }
  return;
}

// ==== CChatKernel::helper_140033c60  @140033c60  [medium:callgraph-r3]  (orig: FUN_140033c60)
undefined8 *
FUN_140033c60(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    *(undefined1 *)(puVar1 + 4) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  }
  return puVar1;
}

// ==== CChatKernel::helper_140033f50  @140033f50  [medium:callgraph-r1]  (orig: FUN_140033f50)
void FUN_140033f50(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 4) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  return;
}

// ==== CChatKernel::helper_140034470  @140034470  [medium:callgraph-r0]  (orig: FUN_140034470)
void FUN_140034470(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x21);
  while (cVar1 == '\0') {
    FUN_140033af0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x21);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CChatKernel::helper_1400347e0  @1400347e0  [medium:callgraph-r2]  (orig: FUN_1400347e0)
undefined8 * FUN_1400347e0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x21) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140032b80(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x21) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 4;
        plVar8 = plVar8 + 4;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1400349cc;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x21);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x21);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1400349cc:
  if ((char)plVar2[4] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[4] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_140033540(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(*plVar9 + 0x20) != '\x01') || (*(char *)(plVar9[2] + 0x20) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x20) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_1400335a0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(plVar9[2] + 0x20) = 1;
              FUN_140033540(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        else {
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_1400335a0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(plVar9[2] + 0x20) != '\x01') || (*(char *)(*plVar9 + 0x20) != '\x01')) {
              if (*(char *)(*plVar9 + 0x20) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_140033540(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(*plVar9 + 0x20) = 1;
              FUN_1400335a0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 4) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CChatKernel::helper_140034ba0  @140034ba0  [medium:callgraph-r2]  (orig: FUN_140034ba0)
undefined8 * FUN_140034ba0(undefined8 *param_1,undefined8 *param_2,longlong *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x21) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if ((longlong)puVar2[3] < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x21) != '\0') && (*param_3 < (longlong)puVar2[3])) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x21) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x21) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x21) == '\0') {
    do {
      if (*param_3 < (longlong)puVar2[3]) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x21) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CChatKernel::helper_140034ea0  @140034ea0  [medium:callgraph-r3]  (orig: FUN_140034ea0)
void FUN_140034ea0(basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_1,
                  longlong param_2,
                  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                  *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_1,param_3);
    }
    param_1 = param_1 + 0x28;
  }
  return;
}

// ==== CChatKernel::helper_140035350  @140035350  [medium:callgraph-r1]  (orig: FUN_140035350)
longlong * FUN_140035350(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140034470(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x21) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x21);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x21);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x21);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x21);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1400347e0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CChatKernel::helper_140035560  @140035560  [medium:callgraph-r2]  (orig: FUN_140035560)
undefined8 *
FUN_140035560(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x1ffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140033c60(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x20);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x20) == '\0') {
        *(undefined1 *)(plVar2 + 4) = 1;
        *(undefined1 *)(lVar4 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x21) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x21) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x20) == '\0') {
        *(undefined1 *)(plVar2 + 4) = 1;
        *(undefined1 *)(lVar4 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x21) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x21) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x20);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x20) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CChatKernel::helper_1400358a0  @1400358a0  [medium:callgraph-r0]  (orig: FUN_1400358a0)
void FUN_1400358a0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140035350((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CChatKernel::SendMultiOSClientMsg  @140035ef0  [high:log-string]  (orig: FUN_140035ef0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140035ef0(longlong param_1,longlong *param_2,longlong param_3)

{
  longlong *plVar1;
  uint *puVar2;
  ulonglong *puVar3;
  undefined4 *puVar4;
  ulonglong *puVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  uint *puVar8;
  undefined4 *puVar9;
  longlong lVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  uint uVar13;
  ulonglong uVar14;
  undefined1 auStack_4f8 [32];
  uint *local_4d8;
  uint local_4c8;
  uint local_4c4;
  undefined4 local_4c0 [2];
  longlong *local_4b8;
  longlong *local_4a8;
  longlong local_498;
  undefined8 local_490;
  ulonglong *local_488;
  ulonglong *local_478;
  uint local_468 [3];
  undefined4 local_45c;
  int local_458;
  undefined1 local_454 [1036];
  ulonglong local_48;
  
  local_490 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  local_4b8 = (longlong *)param_1;
  local_498 = param_3;
  if (param_3 == 0) {
    log_InlineLogERROR("CChatKernel::SendMultiOSClientMsg pMsg is NULL.");
    uVar6 = 0;
  }
  else if (0x400 - *(int *)(param_3 + 0xc) < 0) {
    log_InlineLogERROR("CChatKernel::SendMultiOSClientMsg (_MAX_MSGSIZE - pMsg->GetSize()) < 0.");
    uVar6 = 0;
  }
  else if ((param_2[4] - param_2[3] & 0xfffffffffffffffcU) == 0) {
    uVar6 = 0;
  }
  else {
    local_4a8 = (longlong *)((ulonglong)(longlong)(0x3fc - *(int *)(param_3 + 0xc)) >> 2);
    puVar8 = (uint *)param_2[3];
    if ((param_2[4] - (longlong)puVar8 & 0xfffffffffffffffcU) == 4) {
      local_4d8 = (uint *)CONCAT44(local_4d8._4_4_,5);
      FUN_1400320f0(param_1,*puVar8 & 0xfffff,*puVar8 >> 0x14,param_3);
      uVar6 = 1;
    }
    else if ((int)local_4a8 < 2) {
      local_4b8 = (longlong *)0x0;
      if ((uint *)param_2[4] < puVar8) {
        _invalid_parameter_noinfo();
      }
      plVar1 = (longlong *)*param_2;
      puVar2 = (uint *)param_2[4];
      local_4a8 = (longlong *)0x0;
      local_4b8 = plVar1;
      if (puVar2 < (uint *)param_2[3]) {
        _invalid_parameter_noinfo();
      }
      param_2 = (longlong *)*param_2;
      local_4a8 = param_2;
      while( true ) {
        if ((plVar1 == (longlong *)0x0) || (plVar1 != param_2)) {
          _invalid_parameter_noinfo();
        }
        if (puVar8 == puVar2) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar1;
        }
        if (*(uint **)(lVar10 + 0x20) <= puVar8) {
          _invalid_parameter_noinfo();
        }
        local_4d8 = (uint *)CONCAT44(local_4d8._4_4_,5);
        FUN_1400320f0(param_1,*puVar8 & 0xfffff,*puVar8 >> 0x14,param_3);
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar1;
        }
        if (*(uint **)(lVar10 + 0x20) <= puVar8) {
          _invalid_parameter_noinfo();
        }
        puVar8 = puVar8 + 1;
      }
      uVar6 = 1;
    }
    else {
      uVar14 = 0;
      local_468[1] = 0;
      local_45c = 6;
      local_468[2] = *(undefined4 *)(param_3 + 8);
      local_458 = *(int *)(param_3 + 0xc);
      memmove(local_454,(void *)(param_3 + 0x10),(longlong)local_458);
      puVar9 = (undefined4 *)param_2[3];
      local_478 = (ulonglong *)0x0;
      if ((undefined4 *)param_2[4] < puVar9) {
        _invalid_parameter_noinfo();
      }
      puVar3 = (ulonglong *)*param_2;
      puVar4 = (undefined4 *)param_2[4];
      local_488 = (ulonglong *)0x0;
      local_478 = puVar3;
      if (puVar4 < (undefined4 *)param_2[3]) {
        _invalid_parameter_noinfo();
      }
      puVar5 = (ulonglong *)*param_2;
      local_4c8 = 0;
      local_4c4 = 0;
      uVar7 = uVar14;
      local_488 = puVar5;
      do {
        if ((puVar3 == (ulonglong *)0x0) || (puVar3 != puVar5)) {
          _invalid_parameter_noinfo();
        }
        if (puVar9 == puVar4) goto LAB_14003624a;
        local_4c8 = 0;
        uVar11 = uVar14;
        do {
          uVar13 = (uint)uVar11;
          if ((int)local_4a8 <= (int)uVar13) break;
          local_4c4 = (int)uVar7 + 1;
          uVar7 = (ulonglong)local_4c4;
          if (puVar3 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar11 = uVar14;
          }
          else {
            uVar11 = *puVar3;
          }
          if (*(undefined4 **)(uVar11 + 0x20) <= puVar9) {
            _invalid_parameter_noinfo();
          }
          local_4c0[0] = *puVar9;
          memmove(local_454 + (longlong)(int)uVar13 * 4 + (longlong)local_458,local_4c0,4);
          uVar13 = uVar13 + 1;
          uVar11 = (ulonglong)uVar13;
          local_4c8 = uVar13;
          if (puVar3 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar12 = uVar14;
          }
          else {
            uVar12 = *puVar3;
          }
          if (*(undefined4 **)(uVar12 + 0x20) <= puVar9) {
            _invalid_parameter_noinfo();
          }
          puVar9 = puVar9 + 1;
          if ((puVar3 == (ulonglong *)0x0) || (puVar3 != puVar5)) {
            _invalid_parameter_noinfo();
          }
        } while (puVar9 != puVar4);
        if (0 < (int)uVar13) {
          local_4d8 = local_468;
          local_468[0] = uVar13;
          (**(code **)(**(longlong **)((longlong)local_4b8 + 0x10) + 0x50))
                    (*(longlong **)((longlong)local_4b8 + 0x10),6,0x3ff);
        }
      } while ((uint)uVar7 < 0x7d1);
      log_InlineLogERROR("CChatKernel::SendMultiOSClientMsg. Dead Loop");
LAB_14003624a:
      uVar6 = 1;
    }
  }
  return uVar6;
}

// ==== CChatKernel::helper_140036280  @140036280  [medium:callgraph-r1]  (orig: FUN_140036280)
longlong * FUN_140036280(longlong *param_1,longlong *param_2,longlong *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  bool bVar7;
  undefined8 *puVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar8 = (undefined8 *)param_1[6];
  bVar7 = true;
  if (*(char *)((longlong)puVar8[1] + 0x21) == '\0') {
    puVar5 = (undefined8 *)puVar8[1];
    do {
      puVar8 = puVar5;
      bVar7 = *param_3 < (longlong)puVar8[3];
      if (bVar7) {
        puVar5 = (undefined8 *)*puVar8;
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x21) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar8;
  local_38 = lVar2;
  puVar4 = puVar8;
  if (bVar7 == false) {
LAB_1400363dd:
    local_30 = puVar4;
    if (*param_3 <= (longlong)puVar5[3]) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14003640d;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar8;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x21) == '\0') {
        puVar5 = (undefined8 *)*puVar8;
        if (*(char *)((longlong)puVar5 + 0x21) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x21);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x21);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x21);
          puVar4 = (undefined8 *)puVar8[1];
          puVar3 = puVar8;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x21);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x21) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x21) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1400363dd;
    }
    bVar7 = true;
  }
  plVar6 = (longlong *)FUN_140035560(param_1,&local_38,bVar7,puVar8,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14003640d:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CChatKernel::helper_140036430  @140036430  [medium:callgraph-r1]  (orig: FUN_140036430)
longlong FUN_140036430(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_140034ba0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x21) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x21);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x21);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x21);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x21);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140035350(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CChatKernel::helper_140036ec0  @140036ec0  [medium:callgraph-r0]  (orig: FUN_140036ec0)
void FUN_140036ec0(longlong param_1,undefined4 param_2,longlong param_3,uint param_4)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined8 local_40;
  undefined8 local_38;
  undefined1 local_30 [24];
  
  local_38 = 0xfffffffffffffffe;
  uVar3 = 0;
  uVar2 = 0;
  while( true ) {
    if (param_4 <= uVar2) {
      return;
    }
    uVar3 = uVar3 + 1;
    if (10000 < uVar3) break;
    iVar1 = *(int *)(param_3 + (ulonglong)uVar2 * 4);
    if (iVar1 != 0) {
      local_40 = CONCAT44(param_2,iVar1);
      FUN_140036280(param_1 + 0x80,local_30,&local_40);
    }
    uVar2 = uVar2 + 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CChatKernel::helper_140036f90  @140036f90  [medium:callgraph-r0]  (orig: FUN_140036f90)
void FUN_140036f90(longlong param_1,longlong param_2,ulonglong param_3,short param_4)

{
  longlong local_28;
  undefined1 local_20 [32];
  
  if (param_4 == 0) {
    local_28 = (param_2 << 0x20) + (param_3 & 0xffffffff);
    FUN_140036280(param_1 + 0x80,local_20,&local_28);
  }
  else if (param_4 == 1) {
    local_28 = (param_2 << 0x20) + (param_3 & 0xffffffff);
    FUN_140036430(param_1 + 0x80,&local_28);
    return;
  }
  return;
}

// ==== CChatKernel::helper_140037280  @140037280  [medium:callgraph-r3]  (orig: FUN_140037280)
longlong * FUN_140037280(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[3];
  lVar4 = param_1[4] - uVar1;
  lVar2 = 0;
  lVar5 = lVar4 >> 0x3f;
  lVar3 = lVar2;
  if (lVar4 / 0x28 + lVar5 != lVar5) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) / 0x28;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1400367e0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar2;
  }
  else {
    lVar5 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 0x28;
  if (uVar1 <= *(ulonglong *)(lVar5 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1400373a4;
  }
  _invalid_parameter_noinfo();
LAB_1400373a4:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CChatKernel::ProcessMsg  @140037750  [high:log-string]  (orig: FUN_140037750)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140037750(longlong param_1,uint param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  char cVar4;
  longlong lVar5;
  undefined4 *puVar6;
  longlong lVar7;
  undefined8 *puVar8;
  undefined1 auStack_4b8 [32];
  void **local_498;
  undefined4 local_490;
  uint local_488;
  undefined4 local_484;
  void *local_480;
  undefined8 local_478;
  undefined4 local_468;
  undefined4 local_464;
  int local_460;
  undefined1 local_45c [1044];
  ulonglong local_48;
  
  local_478 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  local_488 = param_2;
  if (param_2 < 0x15f92) {
    if (param_2 == 0x15f91) {
      puVar6 = (undefined4 *)FUN_140042da0(*(undefined8 *)(param_1 + 0x18),*param_3);
      if (puVar6 != (undefined4 *)0x0) {
        log_InlineLogERROR("player(%d) socket_id(%u) map_id(%u) is in dequeue now!");
        lVar5 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),puVar6[6]);
        if (lVar5 != 0) {
          FUN_14003c880(lVar5,puVar6);
        }
        FUN_140044c90(*(undefined8 *)(param_1 + 0x18),*puVar6);
      }
      lVar5 = FUN_140045fd0(param_3);
      if (lVar5 == 0) {
        return 1;
      }
      FUN_1400453e0(*(undefined8 *)(param_1 + 0x18),lVar5);
      lVar7 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),*(undefined4 *)(lVar5 + 0x18));
      if (lVar7 != 0) {
        FUN_14003cf50(lVar7,lVar5);
        return 1;
      }
      local_488 = FUN_1400423a0(*(undefined8 *)(param_1 + 0x18));
      if (local_488 != 1) {
        return 1;
      }
      local_498 = (void **)&local_488;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                (*(longlong **)(param_1 + 0x10),0xe,0x2734,0xea65);
      return 1;
    }
    if (param_2 == 0x3e9) {
      uVar1 = *param_3;
      uVar2 = param_3[1];
      iVar3 = param_3[2];
      local_484 = uVar2;
      lVar5 = FUN_140042e80(*(undefined8 *)(param_1 + 0x18));
      if ((lVar5 != 0) && (cVar4 = FUN_1400459a0(lVar5), cVar4 == '\0')) {
        local_490 = 0;
        local_498 = (void **)CONCAT44(local_498._4_4_,iVar3);
        FUN_140031eb0(param_1,uVar1,uVar2,param_3 + 3);
        return 1;
      }
      memset(&local_468,0,0x418);
      local_468 = uVar1;
      local_464 = uVar2;
      local_460 = iVar3;
      memcpy(local_45c,param_3 + 3,(longlong)iVar3);
      local_498 = (void **)&local_468;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                (*(longlong **)(param_1 + 0x10),0xe,0x3e9);
      return 1;
    }
switchD_140037954_default:
    local_490 = 0x223;
    local_498 = (void **)0x1406e6960;
    log_InlineLogERROR("CChatKernel::ProcessMsg() idPacket:%u,nType:%d,nFrom:%d at %s,%d");
  }
  else {
    switch(param_2) {
    case 0x15f93:
      lVar5 = FUN_140042da0(*(undefined8 *)(param_1 + 0x18),*param_3);
      if (lVar5 != 0) {
        if (*(int *)(lVar5 + 0x18) == param_3[1]) {
          lVar7 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),param_3[1]);
          if (lVar7 != 0) {
            FUN_14003cfc0(lVar7,lVar5,param_3[2],param_3[3]);
            FUN_140045970(lVar5,param_3[1],param_3[2],param_3[3]);
          }
        }
        else {
          lVar7 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20));
          if (lVar7 != 0) {
            FUN_14003c880(lVar7,lVar5);
          }
          FUN_140045970(lVar5,param_3[1],param_3[2],param_3[3]);
          lVar7 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),param_3[1]);
          if (lVar7 != 0) {
            FUN_14003cf50(lVar7,lVar5);
          }
        }
      }
      break;
    case 0x15f94:
      lVar5 = FUN_140042da0(*(undefined8 *)(param_1 + 0x18),*param_3);
      if (lVar5 != 0) {
        FUN_1400463a0(lVar5,param_3);
      }
      break;
    case 0x15f95:
      FUN_140045430(*(undefined8 *)(param_1 + 0x18),*param_3,param_3[2],*(undefined2 *)(param_3 + 1)
                   );
      break;
    case 0x15f96:
      if (*(longlong *)(param_1 + 0x18) != 0) {
        FUN_140043070(*(longlong *)(param_1 + 0x18),*param_3,*(undefined8 *)(param_3 + 2),
                      *(undefined2 *)(param_3 + 1));
      }
      break;
    case 0x15f97:
      lVar5 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),*param_3);
      if (lVar5 == 0) {
        uVar1 = *param_3;
        local_480 = operator_new(0x48);
        if (local_480 == (void *)0x0) {
          lVar5 = 0;
        }
        else {
          lVar5 = FUN_14003f4e0(local_480,uVar1);
        }
        if (lVar5 != 0) {
          FUN_14003f690(lVar5,param_3[1],param_3[2]);
          FUN_140047b10(*(undefined8 *)(param_1 + 0x20),lVar5);
        }
      }
      break;
    case 0x15f98:
      local_480 = (void *)CONCAT44(local_480._4_4_,*param_3);
      puVar6 = (undefined4 *)FUN_140042e80(*(undefined8 *)(param_1 + 0x18));
      if (puVar6 != (undefined4 *)0x0) {
        lVar5 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),puVar6[6]);
        if (lVar5 != 0) {
          FUN_14003c880(lVar5,puVar6);
        }
        FUN_140044c90(*(undefined8 *)(param_1 + 0x18),*puVar6);
      }
      local_498 = &local_480;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                (*(longlong **)(param_1 + 0x10),2,0x4e23,0xea65);
      break;
    case 0x15f99:
      puVar8 = (undefined8 *)FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),*param_3);
      if (puVar8 != (undefined8 *)0x0) {
        FUN_140047790(*(undefined8 *)(param_1 + 0x20),puVar8);
        (**(code **)*puVar8)(puVar8,1);
      }
      break;
    case 0x15f9a:
      if (param_3 != (undefined4 *)0x0) {
        FUN_140036ec0(param_1,*param_3,param_3 + 2,param_3[1]);
      }
      break;
    case 0x15f9b:
      if (param_3 != (undefined4 *)0x0) {
        FUN_140036f90(param_1,*param_3,param_3[1],*(undefined2 *)(param_3 + 2));
      }
      break;
    case 0x15f9c:
      puVar6 = (undefined4 *)FUN_140042da0(*(undefined8 *)(param_1 + 0x18),*param_3);
      if (puVar6 != (undefined4 *)0x0) {
        lVar5 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),puVar6[6]);
        if (lVar5 != 0) {
          FUN_14003c880(lVar5,puVar6);
        }
        FUN_140044c90(*(undefined8 *)(param_1 + 0x18),*puVar6);
      }
      break;
    case 0x15f9d:
      lVar5 = FUN_140042da0(*(undefined8 *)(param_1 + 0x18),*param_3);
      if (lVar5 != 0) {
        lVar7 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),*(undefined4 *)(lVar5 + 0x18));
        if (lVar7 != 0) {
          FUN_14003c880(lVar7,lVar5);
        }
        FUN_140045990(lVar5);
      }
      break;
    case 0x15f9e:
      if ((param_3 != (undefined4 *)0x0) &&
         (lVar5 = FUN_140042da0(*(undefined8 *)(param_1 + 0x18),*param_3), lVar5 != 0)) {
        FUN_140045b10(lVar5,(longlong)param_3 + 6,*(undefined2 *)(param_3 + 1));
      }
      break;
    case 0x15f9f:
      FUN_140042400(*(undefined8 *)(param_1 + 0x18),*param_3,param_3[2],*(undefined2 *)(param_3 + 1)
                   );
      break;
    default:
      goto switchD_140037954_default;
    }
  }
  return 1;
}

// ==== CChatKernel::helper_140037d00  @140037d00  [medium:callgraph-r0]  (orig: FUN_140037d00)
void FUN_140037d00(undefined8 *param_1)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *pbVar1;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  
  this = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)param_1[3];
  if (this != (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
    pbVar1 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)param_1[4];
    for (; this != pbVar1; this = this + 0x28) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    }
    operator_delete((void *)param_1[3]);
  }
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  operator_delete((void *)*param_1);
  return;
}

// ==== CChatKernel::helper_140037d80  @140037d80  [medium:callgraph-r2]  (orig: FUN_140037d80)
void FUN_140037d80(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) / 0x28;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0x28) < uVar3) {
    FUN_140034ea0(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x28;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140037280(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CChatKernel::helper_140037f60  @140037f60  [medium:callgraph-r0]  (orig: FUN_140037f60)
undefined8 * FUN_140037f60(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140033f50(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x21) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CChatKernel::ctor_or_dtor  @140038090  [high:vtable-assign]  (orig: FUN_140038090)
undefined8 * FUN_140038090(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  *param_1 = IChatKernel::vftable;
  *param_1 = CChatKernel::vftable;
  puVar1 = param_1 + 10;
  plVar2 = operator_new(8);
  plVar3 = (longlong *)0x0;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)puVar1;
    plVar3 = plVar2;
  }
  *puVar1 = plVar3;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  FUN_140037f60(param_1 + 0x10);
  *(undefined4 *)(param_1 + 1) = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  *(undefined1 *)(param_1 + 8) = 1;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined1 *)((longlong)param_1 + 0x4c) = 0;
  FUN_140037e80(puVar1);
  FUN_140034470(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0x18) = 0;
  return param_1;
}

// ==== CChatKernel::ctor_or_dtor  @140038160  [high:vtable-assign]  (orig: FUN_140038160)
void FUN_140038160(undefined8 *param_1)

{
  *param_1 = CChatKernel::vftable;
  FUN_140045900();
  FUN_140047a20();
  if (param_1[5] != 0) {
    FUN_14004b640();
  }
  if (param_1[6] != 0) {
    FUN_140049f60();
  }
  if (param_1[7] != 0) {
    FUN_140040530();
  }
  FUN_1400358a0(param_1 + 0x10);
  operator_delete((void *)param_1[0x10]);
  FUN_140037d00(param_1 + 10);
  *param_1 = IChatKernel::vftable;
  return;
}

// ==== CChatKernel::helper_140038200  @140038200  [medium:callgraph-r1]  (orig: FUN_140038200)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140038200(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong *plVar3;
  char *pcVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  undefined1 auStack_568 [32];
  undefined8 local_548;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_540 [40];
  char local_518;
  undefined1 local_517 [255];
  char local_418;
  undefined1 local_417 [1022];
  undefined1 local_19;
  ulonglong local_18;
  
  local_548 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_568;
  plVar1 = (longlong *)InstanceGet();
  local_418 = '\0';
  memset(local_417,0,0x3ff);
  _snprintf(&local_418,0x400,"select keyword from cq_monitor_keyword");
  local_19 = 0;
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,&local_418,2);
  if (plVar1 != (longlong *)0x0) {
    uVar6 = 0;
    lVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
    if (lVar2 != 0) {
      do {
        (**(code **)(*plVar1 + 0x30))(plVar1);
        local_518 = '\0';
        memset(local_517,0,0xff);
        plVar3 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0);
        pcVar4 = (char *)(**(code **)(*plVar3 + 0x78))(plVar3);
        tq::SafeCopy(&local_518,pcVar4,0x100);
        _strlwr(&local_518);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_540,&local_518);
        FUN_140037d80(param_1 + 0x50,local_540);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_540);
        uVar6 = (ulonglong)((int)uVar6 + 1);
        uVar5 = (**(code **)(*plVar1 + 0x40))(plVar1);
      } while (uVar6 < uVar5);
    }
    (**(code **)*plVar1)(plVar1);
  }
  return;
}

// ==== CChatKernel::vfunc_0  @140039a00  [high:rtti-vtable]  (orig: FUN_140039a00)
void * FUN_140039a00(void *param_1,uint param_2)

{
  FUN_140038160();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CChatKernel::helper_140039a30  @140039a30  [medium:callgraph-r0]  (orig: FUN_140039a30)
void FUN_140039a30(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  
  plVar2 = (longlong *)FUN_140006ad0(0x1f41,1);
  if (plVar2 != (longlong *)0x0) {
    lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
    if (lVar3 == 0) {
                    /* WARNING: Could not recover jumptable at 0x000140039a6f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)*plVar2)();
      return;
    }
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    iVar1 = (**(code **)(*plVar4 + 0x48))(plVar4);
    if (iVar1 == 1) {
      *(undefined1 *)(param_1 + 0x4c) = 1;
      FUN_140038200(param_1);
    }
    (**(code **)*plVar2)(plVar2);
  }
  return;
}

// ==== CChatKernel::vfunc_1  @140039ab0  [high:rtti-vtable]  (orig: FUN_140039ab0)
undefined8 FUN_140039ab0(longlong param_1,longlong *param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined4 local_res10 [2];
  
  *(longlong **)(param_1 + 0x10) = param_2;
  uVar2 = (**(code **)(*param_2 + 8))(param_2);
  *(undefined4 *)(param_1 + 8) = uVar2;
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))();
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))(*(longlong **)(param_1 + 0x10),0x1e);
  DAT_140975aa0 = param_1;
  lVar3 = FUN_140045870();
  *(longlong *)(param_1 + 0x18) = lVar3;
  if (lVar3 == 0) {
    log_InlineLogERROR("Create m_pChatPlayerMgr error");
  }
  else {
    lVar3 = FUN_140047740();
    *(longlong *)(param_1 + 0x20) = lVar3;
    if (lVar3 == 0) {
      log_InlineLogERROR("Create m_pMapMgr error");
    }
    else if (*(int *)(param_1 + 8) == 8) {
      uVar4 = InstanceGet();
      lVar3 = FUN_14004b990(uVar4);
      *(longlong *)(param_1 + 0x28) = lVar3;
      if (lVar3 != 0) {
        lVar3 = FUN_14004a080();
        *(longlong *)(param_1 + 0x30) = lVar3;
        if ((lVar3 != 0) && (cVar1 = FUN_140049c90(lVar3), cVar1 != '\0')) {
          lVar3 = FUN_14003ffb0();
          *(longlong *)(param_1 + 0x38) = lVar3;
          if (lVar3 == 0) {
            log_InlineLogERROR("CChatKernel::Create. NULL == m_pGMTalkMgr");
            return 0;
          }
          cVar1 = FUN_140040550(lVar3);
          if (cVar1 != '\0') {
            plVar5 = (longlong *)FUN_140006ad0(0x1f44,1);
            if ((plVar5 != (longlong *)0x0) &&
               (lVar3 = (**(code **)(*plVar5 + 0x40))(plVar5), lVar3 == 1)) {
              plVar6 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,2);
              uVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
              *(undefined4 *)(param_1 + 0x48) = uVar2;
            }
            if (plVar5 != (longlong *)0x0) {
              (**(code **)*plVar5)(plVar5);
            }
            if (*(uint *)(param_1 + 0x48) < 500) {
              *(undefined4 *)(param_1 + 0x48) = 500;
            }
            FUN_140039a30(param_1);
            FUN_1400332a0(param_1);
            local_res10[0] = 1;
            (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                      (*(longlong **)(param_1 + 0x10),0xe,0x2734,0xea65,local_res10);
            (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                      (*(longlong **)(param_1 + 0x10),0xe,0x273c,0xea65,local_res10);
            return 1;
          }
          FUN_140040530(*(undefined8 *)(param_1 + 0x38));
          log_InlineLogERROR("CChatKernel::Create. m_pGMTalkMgr->Init() ");
          return 0;
        }
        log_InlineLogERROR(
                          "CChatKernel::Create. NULL == m_pLoginNoticMgr || false == m_pLoginNoticMgr->Init()"
                          );
      }
    }
  }
  return 0;
}

// ==== CChatKernel::helper_140039da0  @140039da0  [medium:callgraph-r2]  (orig: FUN_140039da0)
longlong FUN_140039da0(longlong param_1,ulonglong param_2)

{
  if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_1 + 0x18)) / 0x30) <= param_2
     ) {
    _invalid_parameter_noinfo();
  }
  return param_2 * 0x30 + *(longlong *)(param_1 + 0x18);
}

// ==== CChatKernel::helper_140039e30  @140039e30  [medium:callgraph-r2]  (orig: FUN_140039e30)
longlong FUN_140039e30(longlong param_1,ulonglong param_2)

{
  if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_1 + 0x18)) / 0x30) <= param_2
     ) {
    _invalid_parameter_noinfo();
  }
  return param_2 * 0x30 + *(longlong *)(param_1 + 0x18);
}

// ==== CChatKernel::helper_14003a1a0  @14003a1a0  [medium:callgraph-r3]  (orig: FUN_14003a1a0)
void FUN_14003a1a0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CChatKernel::helper_14003a8e0  @14003a8e0  [medium:callgraph-r1]  (orig: FUN_14003a8e0)
undefined8 FUN_14003a8e0(longlong param_1,int param_2,int param_3)

{
  undefined8 uVar1;
  
  param_2 = param_2 / 0x12;
  param_3 = param_3 / 0x12;
  if ((((-1 < param_2) && (param_2 < *(int *)(param_1 + 0xc))) && (-1 < param_3)) &&
     (param_3 < *(int *)(param_1 + 0x10))) {
    uVar1 = FUN_140039da0(param_1 + 0x18,(longlong)param_2);
    uVar1 = FUN_140039e30(uVar1,(longlong)param_3);
    return uVar1;
  }
  log_InlineLogERROR("CChatGameBlock::QueryBlock: map = %u, x=%d, y =%d is invalid");
  return 0;
}

// ==== CChatKernel::helper_14003abf0  @14003abf0  [medium:callgraph-r3]  (orig: FUN_14003abf0)
void FUN_14003abf0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x30)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x30);
  return;
}

// ==== CChatKernel::helper_14003c100  @14003c100  [medium:callgraph-r1]  (orig: FUN_14003c100)
void FUN_14003c100(longlong *param_1)

{
  rsize_t _DstSize;
  void *_Src;
  void *_Dst;
  longlong lVar1;
  
  _Src = (void *)param_1[4];
  if (_Src < (void *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  _Dst = (void *)param_1[3];
  if ((void *)param_1[4] < _Dst) {
    _invalid_parameter_noinfo();
  }
  if ((_Dst < (void *)param_1[3]) || ((void *)param_1[4] < _Dst)) {
    _invalid_parameter_noinfo();
  }
  lVar1 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar1 == 0) || (lVar1 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != _Src) {
    lVar1 = param_1[4] - (longlong)_Src >> 3;
    _DstSize = lVar1 * 8;
    if (0 < lVar1) {
      memmove_s(_Dst,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)_Dst);
  }
  return;
}

// ==== CChatKernel::helper_14003c1f0  @14003c1f0  [medium:callgraph-r3]  (orig: FUN_14003c1f0)
void FUN_14003c1f0(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140039f90();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_14003aa80(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_14003bef0(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_14003bef0(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14003b510(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CChatKernel::helper_14003c4a0  @14003c4a0  [medium:callgraph-r3]  (orig: FUN_14003c4a0)
undefined8 * FUN_14003c4a0(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uVar4 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  uVar3 = (longlong)(param_2[4] - param_2[3]) >> 3;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  if (uVar3 != 0) {
    if (0x1fffffffffffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_140039f90();
    }
    lVar2 = FUN_14003aa80(param_1 + 2,uVar3);
    param_1[3] = lVar2;
    param_1[4] = lVar2;
    param_1[5] = lVar2 + uVar3 * 8;
    uVar3 = param_2[4];
    if (uVar3 < (ulonglong)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    local_58 = (undefined4)*param_2;
    uStack_54 = (undefined4)((ulonglong)*param_2 >> 0x20);
    uStack_50 = (undefined4)uVar3;
    uStack_4c = (undefined4)(uVar3 >> 0x20);
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    uVar3 = param_2[3];
    if ((ulonglong)param_2[4] < uVar3) {
      _invalid_parameter_noinfo();
    }
    local_48 = (undefined4)*param_2;
    uStack_44 = (undefined4)((ulonglong)*param_2 >> 0x20);
    uStack_40 = (undefined4)uVar3;
    uStack_3c = (undefined4)(uVar3 >> 0x20);
    local_28 = local_48;
    uStack_24 = uStack_44;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    uVar4 = FUN_14003bf30(param_1,&local_28,&local_38,param_1[3],uVar4);
    param_1[4] = uVar4;
  }
  return param_1;
}

// ==== CChatKernel::helper_14003c5d0  @14003c5d0  [medium:callgraph-r3]  (orig: FUN_14003c5d0)
longlong FUN_14003c5d0(longlong param_1,longlong param_2)

{
  void *pvVar1;
  void *_Src;
  void *_Dst;
  char cVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  longlong lVar6;
  rsize_t _DstSize;
  ulonglong uVar7;
  
  if (param_1 != param_2) {
    _Src = *(void **)(param_2 + 0x18);
    uVar3 = *(longlong *)(param_2 + 0x20) - (longlong)_Src >> 3;
    if (uVar3 == 0) {
      FUN_14003c100();
      return param_1;
    }
    _Dst = *(void **)(param_1 + 0x18);
    uVar7 = *(longlong *)(param_1 + 0x20) - (longlong)_Dst >> 3;
    if (uVar3 <= uVar7) {
      lVar6 = *(longlong *)(param_2 + 0x20) - (longlong)_Src >> 3;
      if (0 < lVar6) {
        _DstSize = lVar6 << 3;
        memmove_s(_Dst,_DstSize,_Src,_DstSize);
      }
      *(longlong *)(param_1 + 0x20) =
           *(longlong *)(param_1 + 0x18) +
           (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3) * 8;
      return param_1;
    }
    if (_Dst == (void *)0x0) {
      uVar5 = 0;
    }
    else {
      uVar5 = *(longlong *)(param_1 + 0x28) - (longlong)_Dst >> 3;
    }
    if (uVar3 <= uVar5) {
      pvVar1 = (void *)((longlong)_Src + uVar7 * 8);
      FUN_14003b4a0(_Src,pvVar1,_Dst);
      uVar4 = FUN_14003b5e0(param_1,pvVar1,*(undefined8 *)(param_2 + 0x20),
                            *(undefined8 *)(param_1 + 0x20));
      *(undefined8 *)(param_1 + 0x20) = uVar4;
      return param_1;
    }
    if (_Dst != (void *)0x0) {
      operator_delete(_Dst);
    }
    cVar2 = FUN_14003ae90(param_1,*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3
                         );
    if (cVar2 != '\0') {
      uVar4 = FUN_14003b5e0(param_1,*(undefined8 *)(param_2 + 0x18),*(undefined8 *)(param_2 + 0x20),
                            *(undefined8 *)(param_1 + 0x18));
      *(undefined8 *)(param_1 + 0x20) = uVar4;
    }
  }
  return param_1;
}

// ==== CChatKernel::helper_14003c750  @14003c750  [medium:callgraph-r1]  (orig: FUN_14003c750)
void FUN_14003c750(longlong *param_1,int *param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  rsize_t _DstSize;
  undefined8 *_Dst;
  
  if (param_2 != (int *)0x0) {
    _Dst = (undefined8 *)param_1[3];
    if ((undefined8 *)param_1[4] < _Dst) {
      _invalid_parameter_noinfo();
    }
    plVar1 = (longlong *)*param_1;
    while( true ) {
      puVar2 = (undefined8 *)param_1[4];
      if (puVar2 < (undefined8 *)param_1[3]) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_1)) {
        _invalid_parameter_noinfo();
      }
      if (_Dst == puVar2) {
        return;
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      if (*(undefined8 **)(lVar3 + 0x20) <= _Dst) {
        _invalid_parameter_noinfo();
      }
      if (((int *)*_Dst != (int *)0x0) && (*(int *)*_Dst == *param_2)) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      if (*(undefined8 **)(lVar3 + 0x20) <= _Dst) {
        _invalid_parameter_noinfo();
      }
      _Dst = _Dst + 1;
    }
    lVar3 = param_1[4] - (longlong)(_Dst + 1) >> 3;
    if (0 < lVar3) {
      _DstSize = lVar3 << 3;
      memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
    }
    param_1[4] = param_1[4] + -8;
    if ((_Dst < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < _Dst)) {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CChatKernel::helper_14003c880  @14003c880  [medium:callgraph-r0]  (orig: FUN_14003c880)
void FUN_14003c880(longlong param_1,longlong param_2)

{
  longlong lVar1;
  
  if (param_2 != 0) {
    if (((*(int *)(param_2 + 0x1c) / 0x12 < *(int *)(param_1 + 0xc)) &&
        (*(int *)(param_2 + 0x20) / 0x12 < *(int *)(param_1 + 0x10))) &&
       (lVar1 = FUN_14003a8e0(param_1,*(int *)(param_2 + 0x1c),*(int *)(param_2 + 0x20)), lVar1 != 0
       )) {
      FUN_14003c750(lVar1,param_2);
    }
  }
  return;
}

// ==== CChatKernel::helper_14003c8f0  @14003c8f0  [medium:callgraph-r2]  (orig: FUN_14003c8f0)
longlong * FUN_14003c8f0(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_14003c1f0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14003c9e4;
  }
  _invalid_parameter_noinfo();
LAB_14003c9e4:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CChatKernel::helper_14003cb80  @14003cb80  [medium:callgraph-r1]  (orig: FUN_14003cb80)
void FUN_14003cb80(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_14003c8f0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CChatKernel::helper_14003cc30  @14003cc30  [medium:callgraph-r2]  (orig: FUN_14003cc30)
longlong FUN_14003cc30(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - param_1;
    do {
      FUN_14003c5d0(lVar1 + param_1,param_1);
      param_1 = param_1 + 0x30;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x30) * 0x30 + param_3;
}

// ==== CChatKernel::helper_14003cd00  @14003cd00  [medium:callgraph-r2]  (orig: FUN_14003cd00)
void FUN_14003cd00(undefined8 *param_1,undefined8 *param_2)

{
  for (; param_1 != param_2; param_1 = param_1 + 6) {
    if ((void *)param_1[3] != (void *)0x0) {
      operator_delete((void *)param_1[3]);
    }
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    operator_delete((void *)*param_1);
  }
  return;
}

// ==== CChatKernel::helper_14003cdc0  @14003cdc0  [medium:callgraph-r3]  (orig: FUN_14003cdc0)
longlong FUN_14003cdc0(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar2 = param_3 - param_2;
    do {
      param_2 = param_2 + -0x30;
      FUN_14003c5d0(lVar2 + param_2,param_2);
    } while (param_2 != param_1);
  }
  return param_3 + (lVar1 / 0x30) * -0x30;
}

// ==== CChatKernel::helper_14003cec0  @14003cec0  [medium:callgraph-r3]  (orig: FUN_14003cec0)
longlong FUN_14003cec0(longlong param_1,longlong param_2,longlong param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 0x30) {
    if (param_3 != 0) {
      FUN_14003c4a0(param_3,param_1);
    }
    param_3 = param_3 + 0x30;
  }
  return param_3;
}

// ==== CChatKernel::helper_14003cf50  @14003cf50  [medium:callgraph-r0]  (orig: FUN_14003cf50)
void FUN_14003cf50(longlong param_1,longlong param_2)

{
  longlong lVar1;
  longlong local_res10 [3];
  
  if (param_2 != 0) {
    if (((*(int *)(param_2 + 0x1c) / 0x12 < *(int *)(param_1 + 0xc)) &&
        (*(int *)(param_2 + 0x20) / 0x12 < *(int *)(param_1 + 0x10))) &&
       (lVar1 = FUN_14003a8e0(param_1,*(int *)(param_2 + 0x1c),*(int *)(param_2 + 0x20)), lVar1 != 0
       )) {
      local_res10[0] = param_2;
      FUN_14003cb80(lVar1,local_res10);
    }
  }
  return;
}

// ==== CChatKernel::helper_14003cfc0  @14003cfc0  [medium:callgraph-r0]  (orig: FUN_14003cfc0)
void FUN_14003cfc0(longlong param_1,longlong param_2,int param_3,int param_4)

{
  int iVar1;
  longlong lVar2;
  longlong local_res10;
  
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0x1c) / 0x12;
    if ((iVar1 != param_3 / 0x12) || (*(int *)(param_2 + 0x20) / 0x12 != param_4 / 0x12)) {
      if ((iVar1 < *(int *)(param_1 + 0xc)) &&
         ((*(int *)(param_2 + 0x20) / 0x12 < *(int *)(param_1 + 0x10) &&
          (lVar2 = FUN_14003a8e0(param_1,*(int *)(param_2 + 0x1c)), lVar2 != 0)))) {
        FUN_14003c750(lVar2,param_2);
      }
      if (((param_3 / 0x12 < *(int *)(param_1 + 0xc)) && (param_4 / 0x12 < *(int *)(param_1 + 0x10))
          ) && (lVar2 = FUN_14003a8e0(param_1,param_3,param_4), lVar2 != 0)) {
        local_res10 = param_2;
        FUN_14003cb80(lVar2,&local_res10);
      }
    }
  }
  return;
}

// ==== CChatKernel::helper_14003d420  @14003d420  [medium:callgraph-r3]  (orig: FUN_14003d420)
void FUN_14003d420(longlong param_1,longlong param_2,undefined8 param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != 0) {
      FUN_14003c4a0(param_1,param_3);
    }
    param_1 = param_1 + 0x30;
  }
  return;
}

// ==== CChatKernel::helper_14003de60  @14003de60  [medium:callgraph-r2]  (orig: FUN_14003de60)
void FUN_14003de60(ulonglong param_1,longlong param_2,ulonglong param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  undefined1 local_res8;
  void *local_68 [3];
  void *local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    lVar7 = *(longlong *)(param_1 + 0x28) - lVar4;
    lVar7 = lVar7 / 6 + (lVar7 >> 0x3f);
    uVar5 = (lVar7 >> 3) - (lVar7 >> 0x3f);
  }
  uVar6 = 0;
  if (param_3 != 0) {
    lVar4 = (*(longlong *)(param_1 + 0x20) - lVar4) / 0x30;
    if (0x555555555555555U - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14003a1a0();
    }
    uVar1 = lVar4 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar5 < uVar1) {
      if (uVar5 <= 0x555555555555555 - (uVar5 >> 1)) {
        uVar6 = uVar5 + (uVar5 >> 1);
      }
      if (uVar6 < uVar1) {
        uVar6 = uVar1;
      }
      lVar2 = FUN_14003abf0(param_1 + 0x10,uVar6);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18);
      lVar4 = lVar4 / 6 + (lVar4 >> 0x3f);
      lVar4 = (lVar4 >> 3) - (lVar4 >> 0x3f);
      FUN_14003d420(lVar4 * 0x30 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0,0,lVar4,lVar2);
      FUN_14003cec0(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_14003cec0(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar4 + param_3) * 0x30 + lVar2,param_1 + 0x10,local_res8,0,2);
      lVar4 = *(longlong *)(param_1 + 0x18);
      lVar7 = *(longlong *)(param_1 + 0x20);
      if (lVar4 != 0) {
        FUN_14003cd00(lVar4,*(undefined8 *)(param_1 + 0x20),param_1 + 0x10,param_1 & 0xff);
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar6 * 0x30 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar7 - lVar4) / 0x30) * 0x30 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30) <
             param_3) {
      FUN_14003c4a0(local_68,param_4);
      FUN_14003cec0(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x30,param_1 + 0x10,local_res8,0);
      FUN_14003d420(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30,
                    local_68,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x30;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (lVar7 = *(longlong *)(param_2 + 8); lVar7 != lVar4 + param_3 * -0x30;
          lVar7 = lVar7 + 0x30) {
        FUN_14003c5d0(lVar7,local_68);
      }
      if (local_50 != (void *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (void *)0x0;
      local_48 = 0;
      local_40 = 0;
      operator_delete(local_68[0]);
    }
    else {
      FUN_14003c4a0(local_68,param_4);
      lVar4 = *(longlong *)(param_1 + 0x20);
      lVar7 = lVar4 + param_3 * -0x30;
      uVar3 = FUN_14003cec0(lVar7,lVar4,lVar4,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14003cdc0(*(undefined8 *)(param_2 + 8),lVar7,lVar4,param_1 & 0xff,local_res8,0);
      lVar7 = *(longlong *)(param_2 + 8);
      lVar4 = lVar7 + param_3 * 0x30;
      for (; lVar7 != lVar4; lVar7 = lVar7 + 0x30) {
        FUN_14003c5d0(lVar7,local_68);
      }
      if (local_50 != (void *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (void *)0x0;
      local_48 = 0;
      local_40 = 0;
      operator_delete(local_68[0]);
    }
  }
  return;
}

// ==== CChatKernel::helper_14003e2a0  @14003e2a0  [medium:callgraph-r3]  (orig: FUN_14003e2a0)
longlong FUN_14003e2a0(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - param_1;
    do {
      FUN_14003daf0(lVar1 + param_1,param_1);
      param_1 = param_1 + 0x30;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x30) * 0x30 + param_3;
}

// ==== CChatKernel::helper_14003e3e0  @14003e3e0  [medium:callgraph-r1]  (orig: FUN_14003e3e0)
void FUN_14003e3e0(longlong *param_1,ulonglong param_2,undefined8 *param_3)

{
  ulonglong uVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined1 local_res18;
  longlong local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[4];
  uVar5 = param_1[3];
  uVar3 = (longlong)(uVar1 - uVar5) / 0x30;
  if (uVar3 < param_2) {
    if (uVar1 < uVar5) {
      _invalid_parameter_noinfo();
    }
    local_28 = *param_1;
    uStack_20 = uVar1;
    FUN_14003de60(param_1,&local_28,param_2 - (param_1[4] - param_1[3]) / 0x30,param_3);
    goto LAB_14003e585;
  }
  if (uVar3 <= param_2) goto LAB_14003e585;
  if (uVar1 < uVar5) {
    _invalid_parameter_noinfo();
  }
  uVar5 = param_1[3];
  if ((ulonglong)param_1[4] < uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = 0;
  }
  else {
    lVar4 = *plVar2;
  }
  uVar5 = uVar5 + param_2 * 0x30;
  if (*(ulonglong *)(lVar4 + 0x20) < uVar5) {
LAB_14003e4f9:
    _invalid_parameter_noinfo();
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if (uVar5 < *(ulonglong *)(lVar4 + 0x18)) goto LAB_14003e4f9;
  }
  if ((uVar5 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar5)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar5 != uVar1) {
    local_res18 = SUB81(param_3,0);
    lVar4 = FUN_14003cc30(uVar1,param_1[4],uVar5,(ulonglong)param_3 & 0xff,local_res18,0);
    FUN_14003cd00(lVar4,param_1[4],param_1 + 2,(ulonglong)param_3 & 0xff);
    param_1[4] = lVar4;
  }
LAB_14003e585:
  if ((void *)param_3[3] != (void *)0x0) {
    operator_delete((void *)param_3[3]);
  }
  param_3[3] = 0;
  param_3[4] = 0;
  param_3[5] = 0;
  operator_delete((void *)*param_3);
  return;
}

// ==== CChatKernel::helper_14003ee20  @14003ee20  [medium:callgraph-r3]  (orig: FUN_14003ee20)
void FUN_14003ee20(ulonglong param_1,longlong param_2,ulonglong param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  undefined1 local_res8;
  void *local_68 [2];
  undefined1 local_58 [8];
  void *local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    lVar7 = *(longlong *)(param_1 + 0x28) - lVar4;
    lVar7 = lVar7 / 6 + (lVar7 >> 0x3f);
    uVar5 = (lVar7 >> 3) - (lVar7 >> 0x3f);
  }
  uVar6 = 0;
  if (param_3 != 0) {
    lVar4 = (*(longlong *)(param_1 + 0x20) - lVar4) / 0x30;
    if (0x555555555555555U - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14003a060();
    }
    uVar1 = lVar4 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar5 < uVar1) {
      if (uVar5 <= 0x555555555555555 - (uVar5 >> 1)) {
        uVar6 = uVar5 + (uVar5 >> 1);
      }
      if (uVar6 < uVar1) {
        uVar6 = uVar1;
      }
      lVar2 = FUN_14003ab00(param_1 + 0x10,uVar6);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18);
      lVar4 = lVar4 / 6 + (lVar4 >> 0x3f);
      lVar4 = (lVar4 >> 3) - (lVar4 >> 0x3f);
      FUN_14003e810(lVar4 * 0x30 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0,0,lVar4,lVar2);
      FUN_14003e880(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_14003e880(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar4 + param_3) * 0x30 + lVar2,param_1 + 0x10,local_res8,0,2);
      lVar4 = *(longlong *)(param_1 + 0x18);
      lVar7 = *(longlong *)(param_1 + 0x20);
      if (lVar4 != 0) {
        FUN_14003e750(lVar4,*(undefined8 *)(param_1 + 0x20),param_1 + 0x10,param_1 & 0xff);
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar6 * 0x30 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar7 - lVar4) / 0x30) * 0x30 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30) <
             param_3) {
      FUN_14003d730(local_68,param_4);
      FUN_14003e880(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x30,param_1 + 0x10,local_res8,0);
      FUN_14003e810(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30,
                    local_68,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x30;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (lVar7 = *(longlong *)(param_2 + 8); lVar7 != lVar4 + param_3 * -0x30;
          lVar7 = lVar7 + 0x30) {
        FUN_14003daf0(lVar7,local_68);
      }
      if (local_50 != (void *)0x0) {
        FUN_14003cd00(local_50,local_48,local_58,param_1 & 0xff);
        operator_delete(local_50);
      }
      local_50 = (void *)0x0;
      local_48 = 0;
      local_40 = 0;
      operator_delete(local_68[0]);
    }
    else {
      FUN_14003d730(local_68,param_4);
      lVar4 = *(longlong *)(param_1 + 0x20);
      lVar7 = lVar4 + param_3 * -0x30;
      uVar3 = FUN_14003e880(lVar7,lVar4,lVar4,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14003ec60(*(undefined8 *)(param_2 + 8),lVar7,lVar4);
      lVar7 = *(longlong *)(param_2 + 8);
      lVar4 = lVar7 + param_3 * 0x30;
      for (; lVar7 != lVar4; lVar7 = lVar7 + 0x30) {
        FUN_14003daf0(lVar7,local_68);
      }
      if (local_50 != (void *)0x0) {
        FUN_14003cd00(local_50,local_48,local_58,param_1 & 0xff);
        operator_delete(local_50);
      }
      local_50 = (void *)0x0;
      local_48 = 0;
      local_40 = 0;
      operator_delete(local_68[0]);
    }
  }
  return;
}

// ==== CChatKernel::helper_14003f2d0  @14003f2d0  [medium:callgraph-r2]  (orig: FUN_14003f2d0)
void FUN_14003f2d0(longlong *param_1,ulonglong param_2,undefined8 *param_3)

{
  ulonglong uVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined1 local_res18;
  longlong local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[4];
  uVar5 = param_1[3];
  uVar3 = (longlong)(uVar1 - uVar5) / 0x30;
  if (uVar3 < param_2) {
    if (uVar1 < uVar5) {
      _invalid_parameter_noinfo();
    }
    local_28 = *param_1;
    uStack_20 = uVar1;
    FUN_14003ee20(param_1,&local_28,param_2 - (param_1[4] - param_1[3]) / 0x30,param_3);
    goto LAB_14003f475;
  }
  if (uVar3 <= param_2) goto LAB_14003f475;
  if (uVar1 < uVar5) {
    _invalid_parameter_noinfo();
  }
  uVar5 = param_1[3];
  if ((ulonglong)param_1[4] < uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = 0;
  }
  else {
    lVar4 = *plVar2;
  }
  uVar5 = uVar5 + param_2 * 0x30;
  if (*(ulonglong *)(lVar4 + 0x20) < uVar5) {
LAB_14003f3e9:
    _invalid_parameter_noinfo();
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if (uVar5 < *(ulonglong *)(lVar4 + 0x18)) goto LAB_14003f3e9;
  }
  if ((uVar5 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar5)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar5 != uVar1) {
    local_res18 = SUB81(param_3,0);
    lVar4 = FUN_14003e2a0(uVar1,param_1[4],uVar5,(ulonglong)param_3 & 0xff,local_res18,0);
    FUN_14003e750(lVar4,param_1[4],param_1 + 2,(ulonglong)param_3 & 0xff);
    param_1[4] = lVar4;
  }
LAB_14003f475:
  if (param_3[3] != 0) {
    FUN_14003cd00(param_3[3],param_3[4],param_3 + 2,(ulonglong)param_3 & 0xff);
    operator_delete((void *)param_3[3]);
  }
  param_3[3] = 0;
  param_3[4] = 0;
  param_3[5] = 0;
  operator_delete((void *)*param_3);
  return;
}

// ==== CChatKernel::helper_14003f5d0  @14003f5d0  [medium:callgraph-r1]  (orig: FUN_14003f5d0)
void FUN_14003f5d0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong *local_38 [3];
  undefined8 local_20;
  undefined8 local_18;
  undefined8 local_10;
  
  uVar2 = 0xfffffffffffffffe;
  plVar1 = operator_new(8);
  local_38[0] = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)local_38;
    local_38[0] = plVar1;
  }
  local_20 = 0;
  local_18 = 0;
  local_10 = 0;
  FUN_14003f2d0(param_1,param_2,local_38,param_4,uVar2,plVar1);
  return;
}

// ==== CChatKernel::helper_14003f690  @14003f690  [medium:callgraph-r0]  (orig: FUN_14003f690)
void FUN_14003f690(longlong param_1,int param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  int iVar2;
  longlong *plVar3;
  int iVar4;
  longlong lVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  int iVar8;
  longlong *local_78 [3];
  undefined8 local_60;
  undefined8 local_58;
  undefined8 local_50;
  ulonglong uVar9;
  
  iVar4 = (int)param_3;
  FUN_14003f5d0(param_1 + 0x18,(longlong)iVar4,param_3,param_4,0xfffffffffffffffe);
  uVar6 = 0;
  lVar5 = *(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30);
  iVar2 = (int)(lVar5 >> 0x3f);
  iVar8 = (int)(lVar5 / 0x30) + iVar2;
  uVar7 = uVar6;
  uVar9 = uVar6;
  if (iVar8 == iVar2 || iVar8 - iVar2 < 0) {
    *(int *)(param_1 + 0x10) = param_2;
    *(int *)(param_1 + 0xc) = iVar4;
  }
  else {
    do {
      plVar3 = (longlong *)0x0;
      iVar8 = (int)uVar9;
      if ((ulonglong)((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
          (ulonglong)(longlong)iVar8) {
        _invalid_parameter_noinfo();
      }
      lVar5 = *(longlong *)(param_1 + 0x30);
      plVar1 = operator_new(8);
      local_78[0] = plVar3;
      if (plVar1 != (longlong *)0x0) {
        *plVar1 = (longlong)local_78;
        local_78[0] = plVar1;
      }
      local_60 = 0;
      local_58 = 0;
      local_50 = 0;
      FUN_14003e3e0((longlong)iVar8 * 0x30 + lVar5,(longlong)param_2,local_78);
      while( true ) {
        if ((ulonglong)((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
            uVar7) {
          _invalid_parameter_noinfo();
        }
        iVar2 = (int)plVar3;
        if ((int)((*(longlong *)(uVar6 + 0x20 + *(longlong *)(param_1 + 0x30)) -
                  *(longlong *)(uVar6 + 0x18 + *(longlong *)(param_1 + 0x30))) / 0x30) <= iVar2)
        break;
        if ((ulonglong)((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
            uVar7) {
          _invalid_parameter_noinfo();
        }
        lVar5 = *(longlong *)(param_1 + 0x30);
        if ((ulonglong)
            ((*(longlong *)(uVar6 + 0x20 + lVar5) - *(longlong *)(uVar6 + 0x18 + lVar5)) / 0x30) <=
            (ulonglong)(longlong)iVar2) {
          _invalid_parameter_noinfo();
        }
        FUN_14003c100((longlong)iVar2 * 0x30 + *(longlong *)(uVar6 + 0x18 + lVar5));
        plVar3 = (longlong *)(ulonglong)(iVar2 + 1);
      }
      uVar6 = uVar6 + 0x30;
      uVar7 = uVar7 + 1;
      uVar9 = (ulonglong)(iVar8 + 1U);
    } while ((int)(iVar8 + 1U) <
             (int)((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30));
    *(int *)(param_1 + 0x10) = param_2;
    *(int *)(param_1 + 0xc) = iVar4;
  }
  return;
}

// ==== CChatKernel::helper_14003fa80  @14003fa80  [medium:callgraph-r1]  (orig: FUN_14003fa80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14003fa80(undefined4 param_1,undefined4 param_2,int param_3,void *param_4,uint param_5,
                  undefined4 param_6)

{
  longlong lVar1;
  ulonglong _Size;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined1 local_478 [8];
  undefined4 local_470;
  uint local_46c;
  undefined1 local_468 [1024];
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  ulonglong local_38;
  
  lVar1 = DAT_140975aa0;
  if (param_3 != 0) {
    local_488 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
    if (((DAT_140975aa0 != 0) && (param_4 != (void *)0x0)) &&
       (_Size = (ulonglong)param_5, (int)param_5 < 0x401)) {
      local_68 = param_1;
      local_64 = param_2;
      if (param_3 == 0x3ec) {
        FUN_1400409f0(local_478);
        local_60 = 0;
        local_470 = 0x3ec;
        local_46c = param_5;
        local_5c = param_6;
        memmove(local_468,param_4,_Size);
        FUN_140040d00(local_478,lVar1);
        FUN_140040a70(local_478);
      }
      else if (param_3 == 0x40d) {
        FUN_14004bdc0(local_478);
        local_60 = 0;
        local_470 = 0x40d;
        local_46c = param_5;
        local_5c = param_6;
        memmove(local_468,param_4,_Size);
        FUN_14004be70(local_478,lVar1);
        FUN_14004be10(local_478);
      }
      else if (param_3 == 0x42b) {
        FUN_14004baa0(local_478);
        local_60 = 0;
        local_470 = 0x42b;
        local_46c = param_5;
        local_5c = param_6;
        memmove(local_468,param_4,_Size);
        FUN_14004bc60(local_478,lVar1);
        FUN_14004baf0(local_478);
      }
    }
  }
  return;
}

// ==== CChatKernel::helper_140040210  @140040210  [medium:callgraph-r2]  (orig: FUN_140040210)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140040210(undefined8 param_1,int param_2,longlong param_3)

{
  undefined4 uVar1;
  ulong uVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined1 auStack_4e8 [32];
  undefined1 *local_4c8;
  uint local_4c0;
  uint local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1088];
  char local_38 [15];
  undefined1 local_29;
  ulonglong local_28;
  
  lVar3 = DAT_140975aa0;
  if (param_2 != 0) {
    local_488 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
    if (param_3 != 0) {
      if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
        local_4c8 = (undefined1 *)CONCAT44(local_4c8._4_4_,0x1f);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar3 = FUN_140042da0(*(undefined8 *)(lVar3 + 0x18),param_2);
      if (lVar3 == 0) {
        plVar6 = (longlong *)InstanceGet();
        plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,"cq_leaveword");
        if (plVar6 != (longlong *)0x0) {
          plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,1);
          (**(code **)(*plVar7 + 0xb8))(plVar7,param_2);
          plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,2);
          (**(code **)(*plVar7 + 0x80))(plVar7,&DAT_1406e87d0);
          plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
          (**(code **)(*plVar7 + 0x80))(plVar7,param_3);
          plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,5);
          (**(code **)(*plVar7 + 0xb0))(plVar7,0x334cd1);
          plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,6);
          (**(code **)(*plVar7 + 0xb0))(plVar7,2);
          uVar2 = tq::TimeGet(2);
          local_4c0 = (uVar2 % 1000000) / 10000;
          local_4b8 = (uVar2 % 10000) / 100;
          local_4b0 = uVar2 % 100;
          local_4a8 = 0;
          local_4c8 = (undefined1 *)CONCAT44(local_4c8._4_4_,(uVar2 % 100000000) / 1000000);
          _snprintf(local_38,0x10,"%04d%02d%02d%02d%02d%02d");
          local_29 = 0;
          plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,3);
          (**(code **)(*plVar7 + 0x80))(plVar7);
          (**(code **)(*plVar6 + 0x50))(plVar6,0);
          (**(code **)*plVar6)(plVar6,1);
        }
      }
      else {
        uVar4 = FUN_140031d40();
        lVar5 = FUN_140042da0(uVar4,param_2);
        if (lVar5 != 0) {
          uVar1 = *(undefined4 *)(lVar3 + 0xc);
          FUN_1400409f0(local_478);
          local_498 = 1;
          local_4a0 = 0;
          local_4a8 = 0x334cd1;
          local_4b0 = (uint)local_4b0._2_2_ << 0x10;
          local_4b8 = CONCAT22(local_4b8._2_2_,0x7de);
          local_4c0 = 0xffffff;
          local_4c8 = &DAT_1406dd892;
          FUN_140040ab0(local_478,&DAT_1406e87d0,lVar5 + 0x30,param_3);
          FUN_1400330d0(DAT_140975aa0,uVar1,local_478);
          FUN_140040a70(local_478);
        }
      }
    }
  }
  return;
}

// ==== CChatKernel::helper_140040530  @140040530  [medium:callgraph-r0]  (orig: FUN_140040530)
void FUN_140040530(undefined8 *param_1)

{
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CChatKernel::helper_140040550  @140040550  [medium:callgraph-r0]  (orig: FUN_140040550)
undefined8 FUN_140040550(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined4 uVar1;
  ulong uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  
  plVar3 = (longlong *)FUN_140006ad0(0x1fbdb,1,param_3,param_4,0xfffffffffffffffe);
  if (plVar3 != (longlong *)0x0) {
    lVar4 = (**(code **)(*plVar3 + 0x40))(plVar3);
    if (lVar4 != 0) {
      plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,2);
      uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
      *(undefined4 *)(param_1 + 0x10) = uVar1;
    }
  }
  if (plVar3 != (longlong *)0x0) {
    (**(code **)*plVar3)(plVar3);
  }
  if (*(int *)(param_1 + 0x10) != 0) {
    *(undefined4 *)(param_1 + 8) = 5;
    uVar2 = tq::TimeGet(0);
    *(uint *)(param_1 + 0xc) = uVar2 / 1000;
  }
  return 1;
}

// ==== CChatKernel::helper_140040600  @140040600  [medium:callgraph-r1]  (orig: FUN_140040600)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140040600(longlong param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 uVar9;
  undefined1 auStack_278 [32];
  int local_258;
  longlong *local_250;
  longlong local_248;
  longlong *local_240;
  undefined8 local_238;
  char local_228;
  undefined1 local_227 [510];
  undefined1 local_29;
  ulonglong local_28;
  
  local_238 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_278;
  local_228 = '\0';
  local_248 = param_1;
  memset(local_227,0,0x1ff);
  _snprintf(&local_228,0x200,"SELECT * FROM cq_talkfromgm where id > %d ");
  local_29 = 0;
  plVar5 = (longlong *)InstanceGet();
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,&local_228,2);
  if (plVar5 != (longlong *)0x0) {
    local_250 = plVar5;
    lVar6 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (lVar6 == 0) {
      (**(code **)*plVar5)(plVar5);
    }
    else {
      local_258 = 0;
      while (iVar1 = local_258, iVar2 = (**(code **)(*plVar5 + 0x40))(plVar5), iVar1 < iVar2) {
        (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)iVar1);
        plVar7 = (longlong *)(**(code **)(*plVar5 + 0x38))(plVar5);
        if (plVar7 != (longlong *)0x0) {
          local_240 = plVar7;
          plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
          uVar3 = (**(code **)(*plVar8 + 0x40))(plVar8);
          if (*(uint *)(param_1 + 0x14) < uVar3) {
            *(uint *)(param_1 + 0x14) = uVar3;
          }
          plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,1);
          uVar4 = (**(code **)(*plVar8 + 0x40))(plVar8);
          plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,2);
          uVar9 = (**(code **)(*plVar8 + 0x78))(plVar8);
          FUN_140040210(param_1,uVar4,uVar9);
          (**(code **)(*plVar7 + 0x40))(plVar7,0);
          (**(code **)*plVar7)(plVar7,1);
        }
        local_240 = (longlong *)0x0;
        local_258 = iVar1 + 1;
      }
      (**(code **)*plVar5)(plVar5);
    }
  }
  return 1;
}

// ==== CChatKernel::helper_1400407e0  @1400407e0  [medium:callgraph-r0]  (orig: FUN_1400407e0)
void FUN_1400407e0(longlong param_1)

{
  ulong uVar1;
  
  if (*(int *)(param_1 + 0x10) != 0) {
    uVar1 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0xc) + *(int *)(param_1 + 8)) <= uVar1 / 1000) {
      uVar1 = tq::TimeGet(0);
      *(uint *)(param_1 + 0xc) = uVar1 / 1000;
      FUN_140040600(param_1);
    }
  }
  return;
}

// ==== CChatKernel::helper_1400423a0  @1400423a0  [medium:callgraph-r0]  (orig: FUN_1400423a0)
longlong FUN_1400423a0(longlong param_1)

{
  return *(longlong *)(param_1 + 0x20) - *(longlong *)(param_1 + 0x18) >> 3;
}

// ==== CChatKernel::helper_140042400  @140042400  [medium:callgraph-r0]  (orig: FUN_140042400)
void FUN_140042400(longlong param_1,int param_2,undefined4 param_3,undefined2 param_4)

{
  longlong lVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  uint uVar4;
  ulonglong uVar5;
  
  if (param_2 != 0) {
    uVar3 = 0;
    uVar2 = *(longlong *)(param_1 + 0x20) - *(longlong *)(param_1 + 0x18) >> 3;
    uVar5 = uVar3;
    if (0 < (int)uVar2) {
      do {
        if ((-1 < (longlong)uVar3) && ((int)uVar5 < (int)uVar2)) {
          if (uVar2 <= uVar3) {
            _invalid_parameter_noinfo();
          }
          lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x18) + uVar3 * 8);
          if ((lVar1 != 0) && (param_2 == *(int *)(lVar1 + 0x10))) {
            FUN_1400462e0(lVar1,param_3,param_4);
          }
        }
        uVar4 = (int)uVar5 + 1;
        uVar5 = (ulonglong)uVar4;
        uVar3 = uVar3 + 1;
        uVar2 = *(longlong *)(param_1 + 0x20) - *(longlong *)(param_1 + 0x18) >> 3;
      } while ((int)uVar4 < (int)uVar2);
    }
  }
  return;
}

// ==== CChatKernel::helper_140042da0  @140042da0  [medium:callgraph-r0]  (orig: FUN_140042da0)
int * FUN_140042da0(longlong *param_1,int param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  int *piVar3;
  undefined8 *puVar4;
  longlong lVar5;
  
  if (param_2 == 0) {
    return (int *)0x0;
  }
  puVar4 = (undefined8 *)param_1[3];
  if ((undefined8 *)param_1[4] < puVar4) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (undefined8 *)param_1[4];
  plVar2 = (longlong *)*param_1;
  if (puVar1 < (undefined8 *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  while( true ) {
    if ((plVar2 == (longlong *)0x0) || (plVar2 != param_1)) {
      _invalid_parameter_noinfo();
    }
    if (puVar4 == puVar1) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    piVar3 = (int *)*puVar4;
    if ((piVar3 != (int *)0x0) && (param_2 == *piVar3)) {
      return piVar3;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    puVar4 = puVar4 + 1;
  }
  return (int *)0x0;
}

// ==== CChatKernel::helper_140043070  @140043070  [medium:callgraph-r0]  (orig: FUN_140043070)
void FUN_140043070(longlong param_1,int param_2,longlong param_3,short param_4)

{
  longlong lVar1;
  longlong lVar2;
  
  if ((param_2 != 0) && (lVar1 = FUN_140042da0(), lVar1 != 0)) {
    if (param_4 != 3) {
      FUN_140045a80(lVar1,param_3,param_4);
      return;
    }
    lVar2 = 0;
    if (param_3 == 1) {
      lVar2 = lVar1;
    }
    *(longlong *)(param_1 + 0x30) = lVar2;
  }
  return;
}

// ==== CChatKernel::helper_1400434a0  @1400434a0  [medium:callgraph-r1]  (orig: FUN_1400434a0)
void FUN_1400434a0(longlong *param_1,int param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  int *piVar4;
  longlong lVar5;
  rsize_t _DstSize;
  undefined8 *_Dst;
  
  _Dst = (undefined8 *)param_1[3];
  if ((undefined8 *)param_1[4] < _Dst) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_1;
  puVar2 = (undefined8 *)param_1[4];
  if (puVar2 < (undefined8 *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  plVar3 = (longlong *)*param_1;
  while( true ) {
    if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar3)) {
      _invalid_parameter_noinfo();
    }
    if (_Dst == puVar2) {
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= _Dst) {
      _invalid_parameter_noinfo();
    }
    piVar4 = (int *)*_Dst;
    if ((piVar4 != (int *)0x0) && (param_2 == *piVar4)) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= _Dst) {
      _invalid_parameter_noinfo();
    }
    _Dst = _Dst + 1;
  }
  FUN_140045ec0(piVar4);
  FUN_140045e00(piVar4);
  lVar5 = param_1[4] - (longlong)(_Dst + 1) >> 3;
  if (0 < lVar5) {
    _DstSize = lVar5 << 3;
    memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
  }
  param_1[4] = param_1[4] + -8;
  if ((_Dst < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < _Dst)) {
    _invalid_parameter_noinfo();
  }
  return;
}

// ==== CChatKernel::helper_140044400  @140044400  [medium:callgraph-r1]  (orig: FUN_140044400)
void FUN_140044400(longlong param_1,uint param_2,int param_3)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  int *piVar4;
  int *piVar5;
  undefined8 *puVar6;
  int *piVar7;
  undefined8 *puVar8;
  longlong lVar9;
  rsize_t _DstSize;
  undefined8 *puVar10;
  int *_Dst;
  longlong lVar11;
  longlong *plVar12;
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_38;
  int *piStack_30;
  
  plVar1 = (longlong *)(param_1 + 0x78);
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0xa8))[1];
  cVar2 = *(char *)((longlong)puVar10 + 0x51);
  puVar6 = *(undefined8 **)(param_1 + 0xa8);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar8 = (undefined8 *)puVar10[2];
      puVar10 = puVar6;
    }
    else {
      puVar8 = (undefined8 *)*puVar10;
    }
    puVar6 = puVar10;
    puVar10 = puVar8;
    cVar2 = *(char *)((longlong)puVar8 + 0x51);
  }
  puVar10 = *(undefined8 **)(param_1 + 0xa8);
  local_50 = puVar6;
  local_58 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar6 == puVar10) || (param_2 < *(uint *)(puVar6 + 3))) {
    plVar12 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0xa8);
    local_48 = *plVar1;
  }
  else {
    plVar12 = &local_58;
  }
  plVar3 = (longlong *)*plVar12;
  lVar11 = *(longlong *)(param_1 + 0xa8);
  local_38 = plVar3;
  piStack_30 = (int *)plVar12[1];
  if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  piVar7 = piStack_30;
  if (piStack_30 != (int *)lVar11) {
    lVar11 = 0;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar11;
    }
    else {
      lVar9 = *plVar3;
    }
    if (piVar7 == (int *)*(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    piVar4 = *(int **)((longlong)piVar7 + 0x40);
    if (piVar4 < *(int **)((longlong)piVar7 + 0x38)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar11;
    }
    else {
      lVar9 = *plVar3;
    }
    if (piVar7 == (int *)*(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    piVar5 = *(int **)((longlong)piVar7 + 0x38);
    if (*(int **)((longlong)piVar7 + 0x40) < piVar5) {
      _invalid_parameter_noinfo();
    }
    local_38 = *(longlong **)((longlong)piVar7 + 0x20);
    for (_Dst = piVar5; (_Dst != piVar4 && (*_Dst != param_3)); _Dst = _Dst + 1) {
    }
    piStack_30 = piVar5;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar11;
    }
    else {
      lVar9 = *plVar3;
    }
    if (piVar7 == (int *)*(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    piVar4 = *(int **)((longlong)piVar7 + 0x40);
    if (piVar4 < *(int **)((longlong)piVar7 + 0x38)) {
      _invalid_parameter_noinfo();
    }
    if ((local_38 == (longlong *)0x0) || (local_38 != *(longlong **)((longlong)piVar7 + 0x20))) {
      _invalid_parameter_noinfo();
    }
    if (_Dst != piVar4) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar11;
      }
      else {
        lVar9 = *plVar3;
      }
      if (piVar7 == (int *)*(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)((longlong)piVar7 + 0x40) - (longlong)(_Dst + 1) >> 2;
      if (0 < lVar9) {
        _DstSize = lVar9 << 2;
        memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
      }
      *(longlong *)((longlong)piVar7 + 0x40) = *(longlong *)((longlong)piVar7 + 0x40) + -4;
      if ((_Dst < *(int **)((longlong)piVar7 + 0x38)) || (*(int **)((longlong)piVar7 + 0x40) < _Dst)
         ) {
        _invalid_parameter_noinfo();
      }
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar11 = *plVar3;
    }
    if (piVar7 == (int *)*(longlong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((*(longlong *)((longlong)piVar7 + 0x40) - *(longlong *)((longlong)piVar7 + 0x38) &
        0xfffffffffffffffcU) == 0) {
      local_38 = (longlong *)*plVar12;
      piStack_30 = (int *)plVar12[1];
      FUN_140043c90(plVar1,&local_48,&local_38);
    }
  }
  return;
}

// ==== CChatKernel::helper_140044680  @140044680  [medium:callgraph-r1]  (orig: FUN_140044680)
void FUN_140044680(longlong param_1,uint param_2,int param_3)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  int *piVar4;
  int *piVar5;
  undefined8 *puVar6;
  int *piVar7;
  undefined8 *puVar8;
  longlong lVar9;
  rsize_t _DstSize;
  undefined8 *puVar10;
  int *_Dst;
  longlong lVar11;
  longlong *plVar12;
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_38;
  int *piStack_30;
  
  plVar1 = (longlong *)(param_1 + 0x38);
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x68))[1];
  cVar2 = *(char *)((longlong)puVar10 + 0x51);
  puVar6 = *(undefined8 **)(param_1 + 0x68);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar8 = (undefined8 *)puVar10[2];
      puVar10 = puVar6;
    }
    else {
      puVar8 = (undefined8 *)*puVar10;
    }
    puVar6 = puVar10;
    puVar10 = puVar8;
    cVar2 = *(char *)((longlong)puVar8 + 0x51);
  }
  puVar10 = *(undefined8 **)(param_1 + 0x68);
  local_50 = puVar6;
  local_58 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar6 == puVar10) || (param_2 < *(uint *)(puVar6 + 3))) {
    plVar12 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0x68);
    local_48 = *plVar1;
  }
  else {
    plVar12 = &local_58;
  }
  plVar3 = (longlong *)*plVar12;
  lVar11 = *(longlong *)(param_1 + 0x68);
  local_38 = plVar3;
  piStack_30 = (int *)plVar12[1];
  if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  piVar7 = piStack_30;
  if (piStack_30 != (int *)lVar11) {
    lVar11 = 0;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar11;
    }
    else {
      lVar9 = *plVar3;
    }
    if (piVar7 == (int *)*(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    piVar4 = *(int **)((longlong)piVar7 + 0x40);
    if (piVar4 < *(int **)((longlong)piVar7 + 0x38)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar11;
    }
    else {
      lVar9 = *plVar3;
    }
    if (piVar7 == (int *)*(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    piVar5 = *(int **)((longlong)piVar7 + 0x38);
    if (*(int **)((longlong)piVar7 + 0x40) < piVar5) {
      _invalid_parameter_noinfo();
    }
    local_38 = *(longlong **)((longlong)piVar7 + 0x20);
    for (_Dst = piVar5; (_Dst != piVar4 && (*_Dst != param_3)); _Dst = _Dst + 1) {
    }
    piStack_30 = piVar5;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar11;
    }
    else {
      lVar9 = *plVar3;
    }
    if (piVar7 == (int *)*(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    piVar4 = *(int **)((longlong)piVar7 + 0x40);
    if (piVar4 < *(int **)((longlong)piVar7 + 0x38)) {
      _invalid_parameter_noinfo();
    }
    if ((local_38 == (longlong *)0x0) || (local_38 != *(longlong **)((longlong)piVar7 + 0x20))) {
      _invalid_parameter_noinfo();
    }
    if (_Dst != piVar4) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar11;
      }
      else {
        lVar9 = *plVar3;
      }
      if (piVar7 == (int *)*(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)((longlong)piVar7 + 0x40) - (longlong)(_Dst + 1) >> 2;
      if (0 < lVar9) {
        _DstSize = lVar9 << 2;
        memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
      }
      *(longlong *)((longlong)piVar7 + 0x40) = *(longlong *)((longlong)piVar7 + 0x40) + -4;
      if ((_Dst < *(int **)((longlong)piVar7 + 0x38)) || (*(int **)((longlong)piVar7 + 0x40) < _Dst)
         ) {
        _invalid_parameter_noinfo();
      }
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar11 = *plVar3;
    }
    if (piVar7 == (int *)*(longlong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((*(longlong *)((longlong)piVar7 + 0x40) - *(longlong *)((longlong)piVar7 + 0x38) &
        0xfffffffffffffffcU) == 0) {
      local_38 = (longlong *)*plVar12;
      piStack_30 = (int *)plVar12[1];
      FUN_140043c90(plVar1,&local_48,&local_38);
    }
  }
  return;
}

// ==== CChatKernel::helper_140044900  @140044900  [medium:callgraph-r2]  (orig: FUN_140044900)
longlong * FUN_140044900(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x51) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x51) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_140044a5d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_140044a8c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x51) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x51) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x51);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x51);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x51);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x51);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x51) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x51) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_140044a5d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_140044080(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_140044a8c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CChatKernel::helper_140044c90  @140044c90  [medium:callgraph-r0]  (orig: FUN_140044c90)
void FUN_140044c90(longlong param_1,int param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140042da0();
  if (lVar1 != 0) {
    if (0 < *(int *)(lVar1 + 0x28)) {
      FUN_140044400(param_1,*(int *)(lVar1 + 0x28),*(undefined4 *)(lVar1 + 0xc));
    }
    if (*(int *)(lVar1 + 0x14) != 0) {
      FUN_140044680(param_1,*(int *)(lVar1 + 0x14),*(undefined4 *)(lVar1 + 0xc));
    }
    if ((*(int **)(param_1 + 0x30) != (int *)0x0) && (**(int **)(param_1 + 0x30) == param_2)) {
      *(undefined8 *)(param_1 + 0x30) = 0;
    }
    FUN_1400434a0(param_1,param_2);
  }
  return;
}

// ==== CChatKernel::helper_140044d10  @140044d10  [medium:callgraph-r1]  (orig: FUN_140044d10)
/* WARNING: Removing unreachable block (ram,0x000140044ead) */
/* WARNING: Removing unreachable block (ram,0x000140044e75) */
/* WARNING: Removing unreachable block (ram,0x000140044e95) */
/* WARNING: Removing unreachable block (ram,0x000140044ee2) */
/* WARNING: Removing unreachable block (ram,0x000140044ee7) */
/* WARNING: Removing unreachable block (ram,0x000140044ef2) */
/* WARNING: Removing unreachable block (ram,0x000140044ef7) */
/* WARNING: Removing unreachable block (ram,0x000140044efc) */
/* WARNING: Removing unreachable block (ram,0x000140044f02) */

void FUN_140044d10(longlong param_1,uint param_2,undefined4 param_3)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  void *pvVar5;
  longlong lVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined4 local_res18 [2];
  longlong *local_res20;
  longlong *local_d8 [3];
  void *local_c0;
  void *local_b8;
  undefined8 local_b0;
  longlong *local_a8;
  longlong lStack_a0;
  longlong local_88;
  undefined8 local_80;
  longlong local_78;
  undefined8 *local_70;
  uint local_68 [2];
  void *local_60 [3];
  void *local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined8 local_30;
  
  local_30 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(param_1 + 0x78);
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0xa8))[1];
  cVar2 = *(char *)((longlong)puVar9 + 0x51);
  puVar4 = *(undefined8 **)(param_1 + 0xa8);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar9[2];
      puVar9 = puVar4;
    }
    else {
      puVar7 = (undefined8 *)*puVar9;
    }
    puVar4 = puVar9;
    puVar9 = puVar7;
    cVar2 = *(char *)((longlong)puVar7 + 0x51);
  }
  local_70 = puVar4;
  local_78 = *plVar1;
  puVar9 = *(undefined8 **)(param_1 + 0xa8);
  local_res18[0] = param_3;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar9) || (param_2 < *(uint *)(puVar4 + 3))) {
    local_80 = *(undefined8 *)(param_1 + 0xa8);
    local_88 = *plVar1;
    plVar8 = &local_88;
  }
  else {
    plVar8 = &local_78;
  }
  plVar3 = (longlong *)*plVar8;
  lStack_a0 = plVar8[1];
  lVar10 = *(longlong *)(param_1 + 0xa8);
  local_a8 = plVar3;
  if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar6 = lStack_a0;
  if (lStack_a0 != lVar10) {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar3;
    }
    if (lVar6 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140037fe0(lVar6 + 0x20,local_res18);
    return;
  }
  local_res20 = operator_new(8);
  plVar8 = (longlong *)0x0;
  local_d8[0] = plVar8;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_d8;
    local_d8[0] = local_res20;
  }
  lStack_a0 = 0;
  local_b0 = 0;
  local_b8 = (void *)0x0;
  local_c0 = (void *)0x0;
  local_a8 = local_d8[0];
  FUN_140036c20(local_d8,&local_a8,1,local_res18);
  pvVar5 = local_c0;
  if (local_b8 < local_c0) {
    _invalid_parameter_noinfo();
  }
  plVar3 = local_d8[0];
  if (local_d8[0] == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar11 = plVar8;
  }
  else {
    plVar11 = (longlong *)*local_d8[0];
  }
  if (pvVar5 <= (void *)plVar11[4]) {
    if (plVar3 != (longlong *)0x0) {
      plVar8 = (longlong *)*plVar3;
    }
    if ((void *)plVar8[3] <= pvVar5) goto LAB_140044f7f;
  }
  _invalid_parameter_noinfo();
LAB_140044f7f:
  local_68[0] = param_2;
  FUN_140043260(local_60,local_d8);
  FUN_140044900(plVar1,&local_a8,local_68);
  if (local_48 != (void *)0x0) {
    operator_delete(local_48);
  }
  local_48 = (void *)0x0;
  local_40 = 0;
  local_38 = 0;
  operator_delete(local_60[0]);
  if (local_c0 != (void *)0x0) {
    operator_delete(local_c0);
  }
  local_c0 = (void *)0x0;
  local_b8 = (void *)0x0;
  local_b0 = 0;
  operator_delete(local_d8[0]);
  return;
}

// ==== CChatKernel::helper_140045040  @140045040  [medium:callgraph-r1]  (orig: FUN_140045040)
/* WARNING: Removing unreachable block (ram,0x0001400451dd) */
/* WARNING: Removing unreachable block (ram,0x0001400451a5) */
/* WARNING: Removing unreachable block (ram,0x0001400451c5) */
/* WARNING: Removing unreachable block (ram,0x000140045212) */
/* WARNING: Removing unreachable block (ram,0x000140045217) */
/* WARNING: Removing unreachable block (ram,0x000140045222) */
/* WARNING: Removing unreachable block (ram,0x000140045227) */
/* WARNING: Removing unreachable block (ram,0x00014004522c) */
/* WARNING: Removing unreachable block (ram,0x000140045232) */

void FUN_140045040(longlong param_1,uint param_2,undefined4 param_3)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  void *pvVar5;
  longlong lVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined4 local_res18 [2];
  longlong *local_res20;
  longlong *local_d8 [3];
  void *local_c0;
  void *local_b8;
  undefined8 local_b0;
  longlong *local_a8;
  longlong lStack_a0;
  longlong local_88;
  undefined8 local_80;
  longlong local_78;
  undefined8 *local_70;
  uint local_68 [2];
  void *local_60 [3];
  void *local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined8 local_30;
  
  local_30 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(param_1 + 0x38);
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x68))[1];
  cVar2 = *(char *)((longlong)puVar9 + 0x51);
  puVar4 = *(undefined8 **)(param_1 + 0x68);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar9[2];
      puVar9 = puVar4;
    }
    else {
      puVar7 = (undefined8 *)*puVar9;
    }
    puVar4 = puVar9;
    puVar9 = puVar7;
    cVar2 = *(char *)((longlong)puVar7 + 0x51);
  }
  local_70 = puVar4;
  local_78 = *plVar1;
  puVar9 = *(undefined8 **)(param_1 + 0x68);
  local_res18[0] = param_3;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar9) || (param_2 < *(uint *)(puVar4 + 3))) {
    local_80 = *(undefined8 *)(param_1 + 0x68);
    local_88 = *plVar1;
    plVar8 = &local_88;
  }
  else {
    plVar8 = &local_78;
  }
  plVar3 = (longlong *)*plVar8;
  lStack_a0 = plVar8[1];
  lVar10 = *(longlong *)(param_1 + 0x68);
  local_a8 = plVar3;
  if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar6 = lStack_a0;
  if (lStack_a0 != lVar10) {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar3;
    }
    if (lVar6 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140037fe0(lVar6 + 0x20,local_res18);
    return;
  }
  local_res20 = operator_new(8);
  plVar8 = (longlong *)0x0;
  local_d8[0] = plVar8;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_d8;
    local_d8[0] = local_res20;
  }
  lStack_a0 = 0;
  local_b0 = 0;
  local_b8 = (void *)0x0;
  local_c0 = (void *)0x0;
  local_a8 = local_d8[0];
  FUN_140036c20(local_d8,&local_a8,1,local_res18);
  pvVar5 = local_c0;
  if (local_b8 < local_c0) {
    _invalid_parameter_noinfo();
  }
  plVar3 = local_d8[0];
  if (local_d8[0] == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar11 = plVar8;
  }
  else {
    plVar11 = (longlong *)*local_d8[0];
  }
  if (pvVar5 <= (void *)plVar11[4]) {
    if (plVar3 != (longlong *)0x0) {
      plVar8 = (longlong *)*plVar3;
    }
    if ((void *)plVar8[3] <= pvVar5) goto LAB_1400452af;
  }
  _invalid_parameter_noinfo();
LAB_1400452af:
  local_68[0] = param_2;
  FUN_140043260(local_60,local_d8);
  FUN_140044900(plVar1,&local_a8,local_68);
  if (local_48 != (void *)0x0) {
    operator_delete(local_48);
  }
  local_48 = (void *)0x0;
  local_40 = 0;
  local_38 = 0;
  operator_delete(local_60[0]);
  if (local_c0 != (void *)0x0) {
    operator_delete(local_c0);
  }
  local_c0 = (void *)0x0;
  local_b8 = (void *)0x0;
  local_b0 = 0;
  operator_delete(local_d8[0]);
  return;
}

// ==== CChatKernel::helper_1400453e0  @1400453e0  [medium:callgraph-r0]  (orig: FUN_1400453e0)
void FUN_1400453e0(undefined8 param_1,longlong param_2)

{
  longlong local_res10 [3];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_14003cb80(param_1,local_res10);
    if (*(int *)(param_2 + 0x14) != 0) {
      FUN_140045040(param_1,*(int *)(param_2 + 0x14),*(undefined4 *)(param_2 + 0xc));
    }
  }
  return;
}

// ==== CChatKernel::helper_140045430  @140045430  [medium:callgraph-r0]  (orig: FUN_140045430)
void FUN_140045430(undefined8 param_1,int param_2,undefined4 param_3,short param_4)

{
  longlong lVar1;
  
  if ((param_2 != 0) && (lVar1 = FUN_140042da0(), lVar1 != 0)) {
    FUN_1400462e0(lVar1,param_3,param_4);
    if (param_4 == 2) {
      FUN_140045040(param_1,param_3,*(undefined4 *)(lVar1 + 0xc));
    }
    else if (param_4 == 3) {
      FUN_140044680(param_1,param_3,*(undefined4 *)(lVar1 + 0xc));
    }
    else if (param_4 == 6) {
      FUN_140044d10(param_1,param_3,*(undefined4 *)(lVar1 + 0xc));
    }
    else if (param_4 == 7) {
      FUN_140044400(param_1,param_3,*(undefined4 *)(lVar1 + 0xc));
    }
  }
  return;
}

// ==== CChatKernel::helper_140045550  @140045550  [medium:callgraph-r1]  (orig: FUN_140045550)
void FUN_140045550(longlong *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong local_58;
  undefined8 *puStack_50;
  longlong local_48;
  undefined8 *puStack_40;
  undefined1 local_38 [16];
  
  plVar4 = (longlong *)param_1[3];
  if ((longlong *)param_1[4] < plVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_1;
  plVar2 = (longlong *)param_1[4];
  if (plVar2 < (longlong *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  plVar3 = (longlong *)*param_1;
  while( true ) {
    if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar3)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar4) {
      _invalid_parameter_noinfo();
    }
    lVar5 = *plVar4;
    if (lVar5 != 0) {
      FUN_140045ec0(lVar5);
      FUN_140045e00(lVar5);
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar4) {
      _invalid_parameter_noinfo();
    }
    plVar4 = plVar4 + 1;
  }
  FUN_14003c100(param_1);
  plVar4 = param_1 + 0xf;
  puStack_50 = (undefined8 *)param_1[0x15];
  local_58 = *plVar4;
  puStack_40 = (undefined8 *)*puStack_50;
  local_48 = local_58;
  FUN_140044ab0(plVar4,local_38,&local_48,&local_58);
  operator_delete((void *)param_1[0x15]);
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  operator_delete((void *)*plVar4);
  plVar4 = param_1 + 7;
  puStack_40 = (undefined8 *)param_1[0xd];
  local_58 = *plVar4;
  puStack_50 = (undefined8 *)*puStack_40;
  local_48 = local_58;
  FUN_140044ab0(plVar4,local_38,&local_58,&local_48);
  operator_delete((void *)param_1[0xd]);
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  operator_delete((void *)*plVar4);
  if ((void *)param_1[3] != (void *)0x0) {
    operator_delete((void *)param_1[3]);
  }
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  operator_delete((void *)*param_1);
  return;
}

// ==== CChatKernel::helper_140045740  @140045740  [medium:callgraph-r2]  (orig: FUN_140045740)
undefined8 * FUN_140045740(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140042870(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x51) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CChatKernel::helper_1400457f0  @1400457f0  [medium:callgraph-r1]  (orig: FUN_1400457f0)
undefined8 * FUN_1400457f0(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar1 = operator_new(8);
  puVar2 = (void *)0x0;
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_1;
    puVar2 = puVar1;
  }
  *param_1 = puVar2;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  FUN_140045740(param_1 + 7);
  FUN_140045740(param_1 + 0xf);
  param_1[6] = 0;
  return param_1;
}

// ==== CChatKernel::helper_140045870  @140045870  [medium:callgraph-r0]  (orig: FUN_140045870)
void FUN_140045870(void)

{
  void *pvVar1;
  
  if (DAT_140975ab8 == 0) {
    pvVar1 = operator_new(0xb8);
    if (pvVar1 == (void *)0x0) {
      DAT_140975ab8 = 0;
    }
    else {
      DAT_140975ab8 = FUN_1400457f0(pvVar1);
    }
  }
  return;
}

// ==== CChatKernel::helper_140045900  @140045900  [medium:callgraph-r0]  (orig: FUN_140045900)
void FUN_140045900(void)

{
  void *pvVar1;
  
  pvVar1 = DAT_140975ab8;
  if (DAT_140975ab8 != (void *)0x0) {
    FUN_140045550(DAT_140975ab8);
    operator_delete(pvVar1);
    DAT_140975ab8 = (void *)0x0;
  }
  return;
}

// ==== CChatKernel::helper_140045970  @140045970  [medium:callgraph-r0]  (orig: FUN_140045970)
void FUN_140045970(longlong param_1,int param_2,int param_3,int param_4)

{
  if (((param_2 != 0) && (0 < param_3)) && (0 < param_4)) {
    *(int *)(param_1 + 0x18) = param_2;
    *(int *)(param_1 + 0x1c) = param_3;
    *(int *)(param_1 + 0x20) = param_4;
  }
  return;
}

// ==== CChatKernel::helper_140045990  @140045990  [medium:callgraph-r0]  (orig: FUN_140045990)
void FUN_140045990(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  return;
}

// ==== CChatKernel::helper_140045a80  @140045a80  [medium:callgraph-r1]  (orig: FUN_140045a80)
void FUN_140045a80(longlong param_1,longlong param_2,undefined2 param_3)

{
  undefined4 uVar1;
  
  uVar1 = (undefined4)param_2;
  switch(param_3) {
  case 0:
    *(bool *)(param_1 + 0x40) = param_2 == 1;
    return;
  case 1:
    *(undefined4 *)(param_1 + 0x24) = uVar1;
    return;
  case 2:
    *(short *)(param_1 + 0x4c) = (short)param_2;
    return;
  case 4:
    *(bool *)(param_1 + 0x41) = param_2 != 1;
    return;
  case 5:
    *(undefined4 *)(param_1 + 0x2c) = uVar1;
    return;
  case 6:
    *(bool *)(param_1 + 0x54) = param_2 != 0;
    return;
  case 7:
    *(short *)(param_1 + 0x5c) = (short)param_2;
    return;
  case 8:
    *(longlong *)(param_1 + 0x60) = param_2;
    return;
  case 9:
    *(undefined4 *)(param_1 + 0x68) = uVar1;
  }
  return;
}

// ==== CChatKernel::helper_140045b10  @140045b10  [medium:callgraph-r0]  (orig: FUN_140045b10)
void FUN_140045b10(longlong param_1,char *param_2,short param_3)

{
  if ((param_2 != (char *)0x0) && (param_3 == 100)) {
    strncpy((char *)(param_1 + 0x30),param_2,0xf);
    *(undefined1 *)(param_1 + 0x3f) = 0;
  }
  return;
}

// ==== CChatKernel::helper_140045e00  @140045e00  [medium:callgraph-r2]  (orig: FUN_140045e00)
void FUN_140045e00(void *param_1)

{
  if ((DAT_140975ac8 & 1) == 0) {
    DAT_140975ac8 = DAT_140975ac8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975ac0,"CChatPlayer");
    atexit((_func_5014 *)&LAB_1406d65b0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140045e55. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975ac0,param_1);
  return;
}

// ==== CChatKernel::helper_140045ec0  @140045ec0  [medium:callgraph-r2]  (orig: FUN_140045ec0)
void FUN_140045ec0(longlong param_1)

{
  if (*(void **)(param_1 + 0x88) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x88));
  }
  *(undefined8 *)(param_1 + 0x88) = 0;
  *(undefined8 *)(param_1 + 0x90) = 0;
  *(undefined8 *)(param_1 + 0x98) = 0;
  operator_delete(*(void **)(param_1 + 0x70));
  return;
}

// ==== CChatKernel::helper_140045f10  @140045f10  [medium:callgraph-r1]  (orig: FUN_140045f10)
undefined4 * FUN_140045f10(undefined4 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)0x0;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  *(undefined1 *)(param_1 + 0x10) = 1;
  *(undefined1 *)((longlong)param_1 + 0x41) = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  *(undefined2 *)(param_1 + 0x13) = 0;
  param_1[0x14] = 0;
  *(undefined1 *)(param_1 + 0x15) = 0;
  param_1[0x16] = 0;
  *(undefined2 *)(param_1 + 0x17) = 0;
  *(undefined8 *)(param_1 + 0x18) = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  puVar1 = operator_new(8);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_1 + 0x1c;
    puVar2 = puVar1;
  }
  *(undefined8 **)(param_1 + 0x1c) = puVar2;
  *(undefined8 *)(param_1 + 0x22) = 0;
  *(undefined8 *)(param_1 + 0x24) = 0;
  *(undefined8 *)(param_1 + 0x26) = 0;
  *(undefined8 *)(param_1 + 0xc) = 0;
  *(undefined8 *)(param_1 + 0xe) = 0;
  param_1[2] = 0xffffffff;
  return param_1;
}

// ==== CChatKernel::helper_140045fd0  @140045fd0  [medium:callgraph-r0]  (orig: FUN_140045fd0)
undefined4 * FUN_140045fd0(undefined4 *param_1)

{
  void *pvVar1;
  undefined4 *puVar2;
  
  if (param_1 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    if ((DAT_140975ac8 & 1) == 0) {
      DAT_140975ac8 = DAT_140975ac8 | 1;
      CMyHeap::CMyHeap((CMyHeap *)&DAT_140975ac0,"CChatPlayer");
      atexit((_func_5014 *)&LAB_1406d65b0);
    }
    pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140975ac0,0xa0);
    if (pvVar1 == (void *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      puVar2 = (undefined4 *)FUN_140045f10(pvVar1);
    }
    if (puVar2 != (undefined4 *)0x0) {
      *puVar2 = *param_1;
      puVar2[1] = param_1[1];
      puVar2[2] = param_1[2];
      puVar2[3] = param_1[3];
      puVar2[4] = param_1[4];
      puVar2[6] = param_1[0xb];
      puVar2[5] = param_1[5];
      puVar2[9] = (uint)*(ushort *)(param_1 + 10);
      *(undefined2 *)(puVar2 + 0x13) = *(undefined2 *)((longlong)param_1 + 0x2a);
      puVar2[7] = param_1[0xc];
      puVar2[8] = param_1[0xd];
      puVar2[0xb] = param_1[0xe];
      *(undefined1 *)((longlong)puVar2 + 0x41) = *(undefined1 *)(param_1 + 0xf);
      puVar2[0x14] = param_1[0x10];
      *(bool *)(puVar2 + 0x15) = param_1[0x11] != 0;
      puVar2[0x16] = param_1[0x12];
      puVar2[0x1b] = param_1[0x17];
      *(undefined2 *)(puVar2 + 0x17) = *(undefined2 *)(param_1 + 0x13);
      *(undefined8 *)(puVar2 + 0x18) = *(undefined8 *)(param_1 + 0x14);
      puVar2[0x1a] = param_1[0x16];
      strncpy((char *)(puVar2 + 0xc),(char *)(param_1 + 6),0xf);
    }
  }
  return puVar2;
}

// ==== CChatKernel::helper_1400461c0  @1400461c0  [medium:callgraph-r2]  (orig: FUN_1400461c0)
void FUN_1400461c0(longlong param_1,int param_2)

{
  int *piVar1;
  longlong lVar2;
  rsize_t _DstSize;
  int *_Dst;
  
  piVar1 = *(int **)(param_1 + 0x90);
  if (piVar1 < *(int **)(param_1 + 0x88)) {
    _invalid_parameter_noinfo();
  }
  _Dst = *(int **)(param_1 + 0x88);
  if (*(int **)(param_1 + 0x90) < _Dst) {
    _invalid_parameter_noinfo();
  }
  lVar2 = *(longlong *)(param_1 + 0x70);
  for (; (_Dst != piVar1 && (*_Dst != param_2)); _Dst = _Dst + 1) {
  }
  piVar1 = *(int **)(param_1 + 0x90);
  if (piVar1 < *(int **)(param_1 + 0x88)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar2 == 0) || (lVar2 != *(longlong *)(param_1 + 0x70))) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != piVar1) {
    lVar2 = *(longlong *)(param_1 + 0x90) - (longlong)(_Dst + 1) >> 2;
    if (0 < lVar2) {
      _DstSize = lVar2 << 2;
      memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
    }
    *(longlong *)(param_1 + 0x90) = *(longlong *)(param_1 + 0x90) + -4;
    if ((_Dst < *(int **)(param_1 + 0x88)) || (*(int **)(param_1 + 0x90) < _Dst)) {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CChatKernel::helper_1400462e0  @1400462e0  [medium:callgraph-r1]  (orig: FUN_1400462e0)
void FUN_1400462e0(longlong param_1,int param_2,undefined2 param_3)

{
  int local_res18 [4];
  
  switch(param_3) {
  case 0:
    *(int *)(param_1 + 0x10) = param_2;
    return;
  case 1:
    *(undefined4 *)(param_1 + 0x10) = 0;
    return;
  case 2:
    *(int *)(param_1 + 0x14) = param_2;
    return;
  case 3:
    *(undefined4 *)(param_1 + 0x14) = 0;
    return;
  case 4:
    if (param_2 != 0) {
      local_res18[0] = param_2;
      FUN_140037fe0(param_1 + 0x70,local_res18);
      return;
    }
    break;
  case 5:
    FUN_1400461c0();
    return;
  case 6:
    *(int *)(param_1 + 0x28) = param_2;
    return;
  case 7:
    *(undefined4 *)(param_1 + 0x28) = 0;
    return;
  case 8:
    *(int *)(param_1 + 0x58) = param_2;
    return;
  case 9:
    *(int *)(param_1 + 0x6c) = param_2;
  }
  return;
}

// ==== CChatKernel::helper_1400463a0  @1400463a0  [medium:callgraph-r0]  (orig: FUN_1400463a0)
void FUN_1400463a0(longlong param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = 1;
  piVar3 = param_2;
  while( true ) {
    piVar3 = piVar3 + 1;
    if (*(int *)(param_1 + 0x50) < 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      iVar1 = 0x32;
    }
    else {
      iVar1 = *(int *)(param_1 + 0x50);
      if (6 < *(int *)(param_1 + 0x50)) {
        iVar1 = 6;
      }
      iVar1 = *(int *)(&DAT_1406e92b8 + (longlong)iVar1 * 4);
    }
    if ((iVar1 + 1 <= iVar2) || (*piVar3 == 0)) break;
    FUN_140037fe0(param_1 + 0x70,param_2 + iVar2);
    iVar2 = iVar2 + 1;
  }
  return;
}

// ==== CChatKernel::helper_140047160  @140047160  [medium:callgraph-r1]  (orig: FUN_140047160)
undefined8 * FUN_140047160(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar1 = operator_new(8);
  puVar2 = (void *)0x0;
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_1;
    puVar2 = puVar1;
  }
  *param_1 = puVar2;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  return param_1;
}

// ==== CChatKernel::helper_1400471c0  @1400471c0  [medium:callgraph-r1]  (orig: FUN_1400471c0)
void FUN_1400471c0(longlong *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  longlong lVar5;
  
  plVar4 = (longlong *)param_1[3];
  if ((longlong *)param_1[4] < plVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_1;
  while( true ) {
    plVar2 = (longlong *)param_1[4];
    if (plVar2 < (longlong *)param_1[3]) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar4) {
      _invalid_parameter_noinfo();
    }
    puVar3 = (undefined8 *)*plVar4;
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar4) {
      _invalid_parameter_noinfo();
    }
    plVar4 = plVar4 + 1;
  }
  if ((void *)param_1[3] != (void *)0x0) {
    operator_delete((void *)param_1[3]);
  }
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  operator_delete((void *)*param_1);
  return;
}

// ==== CChatKernel::helper_1400472c0  @1400472c0  [medium:callgraph-r0]  (orig: FUN_1400472c0)
longlong FUN_1400472c0(longlong *param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  
  if (param_2 == 0) {
    return 0;
  }
  plVar3 = (longlong *)param_1[3];
  if ((longlong *)param_1[4] < plVar3) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_1;
  while( true ) {
    plVar2 = (longlong *)param_1[4];
    if (plVar2 < (longlong *)param_1[3]) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar2) {
      return 0;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(longlong **)(lVar4 + 0x20) <= plVar3) {
      _invalid_parameter_noinfo();
    }
    lVar4 = *plVar3;
    if ((lVar4 != 0) && (*(int *)(lVar4 + 8) == param_2)) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(longlong **)(lVar4 + 0x20) <= plVar3) {
      _invalid_parameter_noinfo();
    }
    plVar3 = plVar3 + 1;
  }
  return lVar4;
}

// ==== CChatKernel::helper_140047460  @140047460  [medium:callgraph-r3]  (orig: FUN_140047460)
void FUN_140047460(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140046560();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_1400469a0(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_140047120(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_140047120(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_140046d80(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CChatKernel::helper_140047740  @140047740  [medium:callgraph-r0]  (orig: FUN_140047740)
longlong FUN_140047740(void)

{
  void *pvVar1;
  
  if (DAT_140975ad0 == 0) {
    pvVar1 = operator_new(0x30);
    if (pvVar1 == (void *)0x0) {
      DAT_140975ad0 = 0;
    }
    else {
      DAT_140975ad0 = FUN_140047160(pvVar1);
    }
    if (DAT_140975ad0 != 0) {
      return DAT_140975ad0;
    }
  }
  return 0;
}

// ==== CChatKernel::helper_140047790  @140047790  [medium:callgraph-r0]  (orig: FUN_140047790)
void FUN_140047790(longlong *param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  rsize_t _DstSize;
  longlong *_Dst;
  
  if (param_2 != 0) {
    _Dst = (longlong *)param_1[3];
    if ((longlong *)param_1[4] < _Dst) {
      _invalid_parameter_noinfo();
    }
    plVar1 = (longlong *)*param_1;
    while( true ) {
      plVar2 = (longlong *)param_1[4];
      if (plVar2 < (longlong *)param_1[3]) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_1)) {
        _invalid_parameter_noinfo();
      }
      if (_Dst == plVar2) {
        return;
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      if (*(longlong **)(lVar3 + 0x20) <= _Dst) {
        _invalid_parameter_noinfo();
      }
      if ((*_Dst != 0) && (*(int *)(*_Dst + 8) == *(int *)(param_2 + 8))) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      if (*(longlong **)(lVar3 + 0x20) <= _Dst) {
        _invalid_parameter_noinfo();
      }
      _Dst = _Dst + 1;
    }
    lVar3 = param_1[4] - (longlong)(_Dst + 1) >> 3;
    if (0 < lVar3) {
      _DstSize = lVar3 << 3;
      memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
    }
    param_1[4] = param_1[4] + -8;
    if ((_Dst < (longlong *)param_1[3]) || ((longlong *)param_1[4] < _Dst)) {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CChatKernel::helper_1400478b0  @1400478b0  [medium:callgraph-r2]  (orig: FUN_1400478b0)
longlong * FUN_1400478b0(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140047460(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1400479a4;
  }
  _invalid_parameter_noinfo();
LAB_1400479a4:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CChatKernel::helper_140047a20  @140047a20  [medium:callgraph-r0]  (orig: FUN_140047a20)
void FUN_140047a20(void)

{
  void *pvVar1;
  
  pvVar1 = DAT_140975ad0;
  if (DAT_140975ad0 != (void *)0x0) {
    FUN_1400471c0(DAT_140975ad0);
    operator_delete(pvVar1);
    DAT_140975ad0 = (void *)0x0;
  }
  return;
}

// ==== CChatKernel::helper_140047a60  @140047a60  [medium:callgraph-r1]  (orig: FUN_140047a60)
void FUN_140047a60(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_1400478b0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CChatKernel::helper_140047b10  @140047b10  [medium:callgraph-r0]  (orig: FUN_140047b10)
void FUN_140047b10(undefined8 param_1,longlong param_2)

{
  longlong local_res10 [3];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140047a60(param_1,local_res10);
  }
  return;
}

// ==== CChatKernel::helper_140047d30  @140047d30  [medium:callgraph-r3]  (orig: FUN_140047d30)
void FUN_140047d30(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29d) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CChatKernel::helper_140048050  @140048050  [medium:callgraph-r3]  (orig: FUN_140048050)
void FUN_140048050(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29d) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CChatKernel::helper_1400480b0  @1400480b0  [medium:callgraph-r3]  (orig: FUN_1400480b0)
void FUN_1400480b0(longlong *param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)param_1[1];
  if (*(char *)((longlong)plVar2 + 0x29d) == '\0') {
    lVar3 = *plVar2;
    if (*(char *)(lVar3 + 0x29d) == '\0') {
      cVar1 = *(char *)(*(longlong *)(lVar3 + 0x10) + 0x29d);
      lVar4 = *(longlong *)(lVar3 + 0x10);
      while (cVar1 == '\0') {
        cVar1 = *(char *)(*(longlong *)(lVar4 + 0x10) + 0x29d);
        lVar3 = lVar4;
        lVar4 = *(longlong *)(lVar4 + 0x10);
      }
      param_1[1] = lVar3;
      return;
    }
    plVar2 = (longlong *)plVar2[1];
    cVar1 = *(char *)((longlong)plVar2 + 0x29d);
    while ((cVar1 == '\0' && (param_1[1] == *plVar2))) {
      param_1[1] = (longlong)plVar2;
      plVar2 = (longlong *)plVar2[1];
      cVar1 = *(char *)((longlong)plVar2 + 0x29d);
    }
    if (*(char *)(param_1[1] + 0x29d) == '\0') {
      param_1[1] = (longlong)plVar2;
      return;
    }
  }
  else {
    lVar3 = plVar2[2];
    param_1[1] = lVar3;
    if (*(char *)(lVar3 + 0x29d) == '\0') {
      return;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0001400480e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CChatKernel::helper_140048170  @140048170  [medium:callgraph-r3]  (orig: FUN_140048170)
void FUN_140048170(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29d) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29d) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29d);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29d);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29d);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29d);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140048197. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CChatKernel::helper_1400483a0  @1400483a0  [medium:callgraph-r3]  (orig: FUN_1400483a0)
void FUN_1400483a0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x2a0);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x29c) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29d) = 0;
  return;
}

// ==== CChatKernel::helper_1400484f0  @1400484f0  [medium:callgraph-r3]  (orig: FUN_1400484f0)
void FUN_1400484f0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29d);
  while (cVar1 == '\0') {
    FUN_1400484f0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29d);
  }
  return;
}

// ==== CChatKernel::helper_140048650  @140048650  [medium:callgraph-r3]  (orig: FUN_140048650)
undefined8 *
FUN_140048650(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x65c393e032e1c7 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140048410(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x29c);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x29c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x29c) = 1;
        *(undefined1 *)(lVar4 + 0x29c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x29c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29d) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x29c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x29c) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29d) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x29c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x29c) = 1;
        *(undefined1 *)(lVar4 + 0x29c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x29c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29d) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x29c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x29c) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29d) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x29c);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x29c) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CChatKernel::helper_140048a20  @140048a20  [medium:callgraph-r2]  (orig: FUN_140048a20)
undefined8 * FUN_140048a20(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x29d) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140048170(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x29d) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x29d) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x29d) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x29c);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x29c);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_140048c2b;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x29d) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x29d) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x29d);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x29d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x29d) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x29d);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x29d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_140048c2b:
  if (*(char *)((longlong)plVar5 + 0x29c) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x29c) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x29c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x29c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x29c) = 0;
            FUN_140048050(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x29d) == '\0') {
            if ((*(char *)(*plVar11 + 0x29c) != '\x01') || (*(char *)(plVar11[2] + 0x29c) != '\x01')
               ) {
              if (*(char *)(plVar11[2] + 0x29c) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x29c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x29c) = 0;
                FUN_140047d30(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x29c) =
                   *(undefined1 *)((longlong)plVar10 + 0x29c);
              *(undefined1 *)((longlong)plVar10 + 0x29c) = 1;
              *(undefined1 *)(plVar11[2] + 0x29c) = 1;
              FUN_140048050(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x29c) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x29c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x29c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x29c) = 0;
            FUN_140047d30(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x29d) == '\0') {
            if ((*(char *)(plVar11[2] + 0x29c) != '\x01') || (*(char *)(*plVar11 + 0x29c) != '\x01')
               ) {
              if (*(char *)(*plVar11 + 0x29c) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x29c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x29c) = 0;
                FUN_140048050(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x29c) =
                   *(undefined1 *)((longlong)plVar10 + 0x29c);
              *(undefined1 *)((longlong)plVar10 + 0x29c) = 1;
              *(undefined1 *)(*plVar11 + 0x29c) = 1;
              FUN_140047d30(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x29c) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x29c) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CChatKernel::helper_140048e70  @140048e70  [medium:callgraph-r2]  (orig: FUN_140048e70)
void FUN_140048e70(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29d);
  while (cVar1 == '\0') {
    FUN_1400484f0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29d);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CChatKernel::helper_140048fd0  @140048fd0  [medium:callgraph-r3]  (orig: FUN_140048fd0)
longlong * FUN_140048fd0(longlong *param_1,longlong *param_2,int *param_3)

{
  undefined8 *puVar1;
  longlong *plVar2;
  bool bVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  
  puVar4 = (undefined8 *)param_1[6];
  bVar3 = true;
  if (*(char *)((longlong)puVar4[1] + 0x29d) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      puVar4 = puVar1;
      bVar3 = *param_3 < *(int *)(puVar4 + 3);
      if (bVar3) {
        puVar1 = (undefined8 *)*puVar4;
      }
      else {
        puVar1 = (undefined8 *)puVar4[2];
      }
    } while (*(char *)((longlong)puVar1 + 0x29d) == '\0');
  }
  local_28 = *param_1;
  local_20 = puVar4;
  if (bVar3 == false) {
LAB_140049092:
    if (*param_3 <= *(int *)(local_20 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_28;
      goto LAB_1400490bc;
    }
  }
  else {
    puVar1 = *(undefined8 **)param_1[6];
    if (local_28 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar4 != puVar1) {
      FUN_1400480b0(&local_28);
      goto LAB_140049092;
    }
    bVar3 = true;
  }
  plVar2 = (longlong *)FUN_140048650(param_1,&local_28,bVar3,puVar4,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_20 = (undefined8 *)plVar2[1];
  *param_2 = *plVar2;
LAB_1400490bc:
  param_2[1] = (longlong)local_20;
  return param_2;
}

// ==== CChatKernel::helper_140049350  @140049350  [medium:callgraph-r2]  (orig: FUN_140049350)
undefined8 * FUN_140049350(longlong *param_1,undefined8 *param_2,longlong *param_3,int *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  int iVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_140048650(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(int *)(lVar3 + 0x18)) {
        FUN_140048650(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(int *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_140048650(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        iVar8 = *param_4;
        if (iVar8 < *(int *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          FUN_1400480b0(&local_38);
          iVar8 = *param_4;
          if ((int)local_30[3] < iVar8) {
            if (*(char *)(local_30[2] + 0x29d) != '\0') {
              FUN_140048650(param_1,param_2,0,local_30,param_4);
              return param_2;
            }
            FUN_140048650(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(int *)(param_3[1] + 0x18) < iVar8) {
          local_38 = *param_3;
          plVar4 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29d) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29d) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29d);
              plVar5 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar5 + 0x29d);
                plVar9 = plVar5;
                plVar5 = (longlong *)*plVar5;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29d);
              plVar6 = (longlong *)local_30[1];
              plVar5 = local_30;
              while ((plVar9 = plVar6, cVar1 == '\0' && (plVar5 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29d);
                plVar6 = (longlong *)plVar9[1];
                plVar5 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar4) || (*param_4 < (int)plVar9[3])) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29d) != '\0') {
              FUN_140048650(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_140048650(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar7 = (undefined8 *)FUN_140048fd0(param_1,&local_38,param_4);
    *param_2 = *puVar7;
    param_2[1] = puVar7[1];
  }
  return param_2;
}

// ==== CChatKernel::helper_1400495f0  @1400495f0  [medium:callgraph-r1]  (orig: FUN_1400495f0)
void FUN_1400495f0(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  longlong local_38;
  undefined8 *puStack_30;
  undefined1 local_28 [32];
  
  lVar2 = *param_1;
  puVar3 = (undefined8 *)param_1[6];
  puVar5 = (undefined8 *)*puVar3;
  lVar6 = lVar2;
  if (lVar2 == 0) {
    _invalid_parameter_noinfo();
  }
  puVar10 = (undefined8 *)param_1[6];
  if ((lVar2 == 0) || (lVar2 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  lVar7 = lVar6;
  puVar9 = puVar5;
  if (puVar3 == puVar10) {
    FUN_140048e70(param_1);
  }
  else {
    while( true ) {
      if ((lVar6 == 0) || (lVar6 != lVar2)) {
        _invalid_parameter_noinfo();
      }
      if (puVar5 == puVar3) break;
      lVar8 = lVar7;
      puVar10 = puVar9;
      if (lVar6 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar5 + 0x29d) == '\0') {
        puVar10 = (undefined8 *)puVar5[2];
        if (*(char *)((longlong)puVar10 + 0x29d) == '\0') {
          cVar1 = *(char *)((longlong)*puVar10 + 0x29d);
          puVar5 = puVar10;
          puVar4 = (undefined8 *)*puVar10;
          while (puVar10 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)*puVar4 + 0x29d);
            puVar5 = puVar4;
            puVar4 = (undefined8 *)*puVar4;
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar5[1] + 0x29d);
          puVar10 = (undefined8 *)puVar5[1];
          puVar4 = puVar5;
          while ((puVar5 = puVar10, puVar10 = puVar5, cVar1 == '\0' &&
                 (puVar4 == (undefined8 *)puVar5[2]))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29d);
            puVar10 = (undefined8 *)puVar5[1];
            puVar4 = puVar5;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_38 = lVar7;
      puStack_30 = puVar9;
      FUN_140048a20(param_1,local_28,&local_38,param_4,lVar8,puVar10);
      lVar7 = lVar8;
      puVar9 = puVar10;
    }
  }
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CChatKernel::helper_140049a00  @140049a00  [medium:callgraph-r1]  (orig: FUN_140049a00)
longlong FUN_140049a00(longlong *param_1,int *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *local_538;
  undefined8 *puStack_530;
  undefined1 local_528 [16];
  undefined1 local_518 [128];
  undefined1 local_498 [512];
  int local_298;
  undefined1 local_294 [652];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29d) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(int *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29d) == '\0');
  }
  plVar4 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar4 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar1) || (*param_2 < *(int *)(puVar3 + 3))) {
    local_538 = plVar4;
    puStack_530 = puVar3;
    memset(local_518,0,0x80);
    memset(local_498,0,0x200);
    local_298 = *param_2;
    memcpy(local_294,local_518,0x280);
    puVar3 = (undefined8 *)FUN_140049350(param_1,local_528,&local_538,&local_298);
    plVar4 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar4 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = 0;
  }
  else {
    lVar5 = *plVar4;
  }
  if (puVar3 == *(undefined8 **)(lVar5 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return (longlong)puVar3 + 0x1c;
}

// ==== CChatKernel::helper_140049c90  @140049c90  [medium:callgraph-r0]  (orig: FUN_140049c90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140049c90(longlong param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  void *_Dst;
  uint uVar5;
  undefined1 auStack_6e8 [32];
  int local_6c8 [2];
  undefined8 local_6c0;
  CIniFile local_6b8 [1024];
  char local_2b8 [128];
  char local_238 [512];
  char local_38 [16];
  ulonglong local_28;
  
  local_6c0 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_6e8;
  CIniFile::CIniFile(local_6b8,"ini//LoginNotice.ini","INFO");
  iVar1 = CIniFile::GetInt(local_6b8,"VERSION");
  *(int *)(param_1 + 0x40) = iVar1;
  iVar1 = CIniFile::GetInt(local_6b8,"COUNT");
  uVar5 = 0;
  if (0 < iVar1) {
    do {
      local_38[0] = '\0';
      local_38[1] = '\0';
      local_38[2] = '\0';
      local_38[3] = '\0';
      local_38[4] = '\0';
      local_38[5] = '\0';
      local_38[6] = '\0';
      local_38[7] = '\0';
      local_38[8] = '\0';
      local_38[9] = '\0';
      local_38[10] = '\0';
      local_38[0xb] = '\0';
      local_38[0xc] = '\0';
      local_38[0xd] = '\0';
      local_38[0xe] = '\0';
      local_38[0xf] = '\0';
      uVar5 = uVar5 + 1;
      _snprintf(local_38,0xf,"NOTICE%d",(ulonglong)uVar5);
      CIniFile::SetSection(local_6b8,local_38);
      memset(local_2b8,0,0x80);
      memset(local_238,0,0x200);
      iVar2 = CIniFile::GetInt(local_6b8,"METE");
      iVar3 = CIniFile::GetInt(local_6b8,"SYN");
      iVar4 = CIniFile::GetInt(local_6b8,"EMONEY");
      if (iVar2 == 99) {
        *(undefined1 *)(param_1 + 0x44) = 1;
        CIniFile::GetString(local_6b8,(char *)(param_1 + 0x45),"DISCRIB",0x7f);
        CIniFile::GetString(local_6b8,(char *)(param_1 + 0xc5),"HTTP",0x1ff);
      }
      else {
        CIniFile::GetString(local_6b8,local_2b8,"DISCRIB",0x7f);
        CIniFile::GetString(local_6b8,local_238,"HTTP",0x1ff);
        local_6c8[0] = (uint)(iVar4 != 0) + ((uint)(iVar3 != 0) + iVar2 * 10) * 10;
        _Dst = (void *)FUN_140049a00(param_1,local_6c8);
        memcpy(_Dst,local_2b8,0x280);
      }
    } while ((int)uVar5 < iVar1);
  }
  CIniFile::~CIniFile(local_6b8);
  return 1;
}

// ==== CChatKernel::helper_140049f60  @140049f60  [medium:callgraph-r0]  (orig: FUN_140049f60)
void FUN_140049f60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    FUN_1400495f0();
    operator_delete((void *)*param_1);
    operator_delete(param_1);
  }
  return;
}

// ==== CChatKernel::helper_140049fa0  @140049fa0  [medium:callgraph-r2]  (orig: FUN_140049fa0)
undefined8 * FUN_140049fa0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1400483a0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29d) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CChatKernel::helper_14004a020  @14004a020  [medium:callgraph-r1]  (orig: FUN_14004a020)
longlong FUN_14004a020(longlong param_1)

{
  FUN_140049fa0();
  memset((void *)(param_1 + 0x45),0,0x80);
  memset((void *)(param_1 + 0xc5),0,0x200);
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined1 *)(param_1 + 0x44) = 0;
  return param_1;
}

// ==== CChatKernel::helper_14004a080  @14004a080  [medium:callgraph-r0]  (orig: FUN_14004a080)
undefined8 FUN_14004a080(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  pvVar1 = operator_new(0x2c8);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_14004a020(pvVar1);
  }
  return uVar2;
}

// ==== CChatKernel::helper_14004a9b0  @14004a9b0  [medium:callgraph-r3]  (orig: FUN_14004a9b0)
void FUN_14004a9b0(undefined4 *param_1,longlong param_2,undefined4 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined4 *)0x0) {
      *param_1 = *param_3;
      param_1[1] = param_3[1];
      param_1[2] = param_3[2];
      param_1[3] = param_3[3];
      param_1[4] = param_3[4];
    }
    param_1 = param_1 + 5;
  }
  return;
}

// ==== CChatKernel::helper_14004b3a0  @14004b3a0  [medium:callgraph-r1]  (orig: FUN_14004b3a0)
undefined8 * FUN_14004b3a0(undefined8 *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar1 = operator_new(8);
  plVar3 = (longlong *)0x0;
  plVar2 = plVar3;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)param_1;
    plVar2 = plVar1;
  }
  *param_1 = plVar2;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  plVar2 = operator_new(8);
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 6);
    plVar3 = plVar2;
  }
  param_1[6] = plVar3;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  return param_1;
}

// ==== CChatKernel::helper_14004b430  @14004b430  [medium:callgraph-r1]  (orig: FUN_14004b430)
void FUN_14004b430(undefined8 *param_1)

{
  if ((void *)param_1[9] != (void *)0x0) {
    operator_delete((void *)param_1[9]);
  }
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  operator_delete((void *)param_1[6]);
  if ((void *)param_1[3] != (void *)0x0) {
    operator_delete((void *)param_1[3]);
  }
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  operator_delete((void *)*param_1);
  return;
}

// ==== CChatKernel::helper_14004b4e0  @14004b4e0  [medium:callgraph-r3]  (orig: FUN_14004b4e0)
longlong * FUN_14004b4e0(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[3];
  lVar4 = param_1[4] - uVar1;
  lVar2 = 0;
  lVar5 = lVar4 >> 0x3f;
  lVar3 = lVar2;
  if (lVar4 / 0x14 + lVar5 != lVar5) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) / 0x14;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_14004afc0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar2;
  }
  else {
    lVar5 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 0x14;
  if (uVar1 <= *(ulonglong *)(lVar5 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14004b604;
  }
  _invalid_parameter_noinfo();
LAB_14004b604:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CChatKernel::helper_14004b640  @14004b640  [medium:callgraph-r0]  (orig: FUN_14004b640)
void FUN_14004b640(void *param_1)

{
  if (param_1 != (void *)0x0) {
    FUN_14004b430();
    operator_delete(param_1);
  }
  return;
}

// ==== CChatKernel::helper_14004b670  @14004b670  [medium:callgraph-r2]  (orig: FUN_14004b670)
void FUN_14004b670(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) / 0x14;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0x14) < uVar3) {
    FUN_14004a9b0(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x14;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_14004b4e0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CChatKernel::helper_14004b770  @14004b770  [medium:callgraph-r1]  (orig: FUN_14004b770)
undefined8 FUN_14004b770(longlong param_1,longlong param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int yTop;
  int xLeft;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  int iVar13;
  undefined4 local_48;
  tagRECT local_44;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar5 = (longlong *)FUN_140006b90(0x3fc);
  if (plVar5 != (longlong *)0x0) {
    lVar6 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (lVar6 == 0) {
      (**(code **)*plVar5)(plVar5);
      return 1;
    }
    iVar13 = 0;
    iVar1 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (0 < iVar1) {
      do {
        (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)iVar13);
        plVar7 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,2);
        local_48 = (**(code **)(*plVar7 + 0x40))(plVar7);
        plVar7 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,4);
        plVar8 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,6);
        plVar9 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,3);
        plVar10 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,5);
        plVar11 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,4);
        plVar12 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,3);
        iVar1 = (**(code **)(*plVar7 + 0x48))(plVar7);
        iVar2 = (**(code **)(*plVar8 + 0x48))(plVar8);
        iVar3 = (**(code **)(*plVar10 + 0x48))(plVar10);
        iVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
        yTop = (**(code **)(*plVar11 + 0x48))(plVar11);
        xLeft = (**(code **)(*plVar12 + 0x48))(plVar12);
        SetRect(&local_44,xLeft,yTop,iVar3 + iVar4,iVar1 + iVar2);
        FUN_14004b670(param_1 + 0x30,&local_48);
        iVar13 = iVar13 + 1;
        iVar1 = (**(code **)(*plVar5 + 0x40))(plVar5);
      } while (iVar13 < iVar1);
    }
    (**(code **)*plVar5)(plVar5);
  }
  return 1;
}

// ==== CChatKernel::helper_14004b990  @14004b990  [medium:callgraph-r0]  (orig: FUN_14004b990)
void * FUN_14004b990(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  void *pvVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  pvVar2 = operator_new(0x60);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    pvVar2 = (void *)FUN_14004b3a0(pvVar2);
  }
  if (pvVar2 != (void *)0x0) {
    cVar1 = FUN_14004b770(pvVar2,param_1,param_3,param_4,uVar3);
    if (cVar1 != '\0') {
      return pvVar2;
    }
    FUN_14004b430(pvVar2);
    operator_delete(pvVar2);
  }
  return (void *)0x0;
}

