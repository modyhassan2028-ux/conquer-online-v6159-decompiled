// ==== CMsgHangUp::helper_140168960  @140168960  [medium:callgraph-r0]  (orig: FUN_140168960)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140168960(longlong param_1)

{
  char cVar1;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  cVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x220))(param_1 + 0x10);
  if (cVar1 != '\0') {
    *(undefined4 *)(param_1 + 0x10f8) = 1;
    FUN_1403b75b0(local_468);
    cVar1 = FUN_1403b76a0(local_468,1,0);
    if (cVar1 != '\0') {
      (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))(param_1 + 0x10,local_468);
    }
    FUN_1403b7630(local_468);
  }
  return;
}

// ==== CMsgHangUp::ctor_or_dtor  @1403b75b0  [high:vtable-assign]  (orig: FUN_1403b75b0)
undefined8 * FUN_1403b75b0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgHangUp::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x22),0x3ee,true);
  return param_1;
}

// ==== CMsgHangUp::ctor_or_dtor  @1403b7630  [high:vtable-assign]  (orig: FUN_1403b7630)
void FUN_1403b7630(undefined8 *param_1)

{
  *param_1 = CMsgHangUp::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgHangUp::vfunc_1  @1403b7670  [high:rtti-vtable]  (orig: FUN_1403b7670)
ulonglong FUN_1403b7670(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x42e);
}

// ==== CMsgHangUp::helper_1403b77f0  @1403b77f0  [medium:callgraph-r0]  (orig: FUN_1403b77f0)
uint FUN_1403b77f0(longlong param_1)

{
  longlong *plVar1;
  uint extraout_var;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
  (**(code **)(*plVar1 + 0x58))(plVar1);
  return extraout_var >> 0x13 & 1;
}

// ==== CMsgHangUp::ctor_or_dtor  @1403b7820  [high:vtable-assign]  (orig: FUN_1403b7820)
undefined8 * FUN_1403b7820(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgHangUp::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgHangUp::ctor_or_dtor  @1403b7880  [high:vtable-assign]  (orig: FUN_1403b7880)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403b7880(longlong param_1)

{
  short sVar1;
  char cVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined8 local_478;
  undefined **local_468 [134];
  CStringPacker local_38 [32];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (*(longlong *)(param_1 + 0x428) == 0) {
    local_488 = CONCAT44(local_488._4_4_,0x54);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msghangup.cpp"
                      );
  }
  else {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar3 + 0x90) == 0) {
      local_488 = CONCAT44(local_488._4_4_,0x130);
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
    }
    lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))
                      (*(longlong **)(lVar3 + 0x90),param_1);
    if (lVar3 == 0) {
      local_488 = CONCAT44(local_488._4_4_,0x57);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pUser",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msghangup.cpp"
                        );
    }
    else {
      sVar1 = **(short **)(param_1 + 0x428);
      if (sVar1 == 1) {
        uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        cVar2 = FUN_14008aff0(uVar4);
        if (cVar2 != '\0') {
          cVar2 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x2d8))(lVar3 + 0x10,1);
          if (cVar2 == '\0') {
            lVar5 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x160))(lVar3 + 0x10);
            if (lVar5 != 0) {
              cVar2 = FUN_1403b77f0(lVar5);
              if (cVar2 == '\0') {
                FUN_1401a9e70(lVar3,0);
                FUN_140168960(lVar3);
              }
            }
          }
        }
      }
      else if (sVar1 == 2) {
        FUN_1403b75b0(local_468);
        uVar4 = FUN_140167960(lVar3);
        local_488 = 0;
        cVar2 = FUN_1403b7700(local_468,2,&DAT_1406dd892,uVar4);
        if (cVar2 != '\0') {
          (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_468);
        }
        local_468[0] = CMsgHangUp::vftable;
        tq::CStringPacker::~CStringPacker(local_38);
        FUN_1402b55f0(local_468);
      }
      else if (sVar1 == 3) {
        FUN_1401aee10(lVar3,1);
        FUN_1401a9e70(lVar3,0);
      }
    }
  }
  return;
}

