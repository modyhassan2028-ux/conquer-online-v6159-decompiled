// ==== CMsgMonsterTransform::ctor_or_dtor  @1404579b0  [high:vtable-assign]  (orig: FUN_1404579b0)
undefined8 * FUN_1404579b0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMonsterTransform::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMonsterTransform::ctor_or_dtor  @140457a00  [high:vtable-assign]  (orig: FUN_140457a00)
void FUN_140457a00(undefined8 *param_1)

{
  *param_1 = CMsgMonsterTransform::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMonsterTransform::helper_140457a30  @140457a30  [medium:callgraph-r0]  (orig: FUN_140457a30)
undefined8 FUN_140457a30(longlong param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  FUN_1402b5600();
  puVar1 = *(undefined4 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 0xc) = 0x24;
  *(undefined4 *)(param_1 + 8) = 0x412;
  *puVar1 = *param_2;
  puVar1[1] = param_2[1];
  puVar1[2] = param_2[2];
  puVar1[3] = param_2[3];
  puVar1[4] = param_2[4];
  puVar1[5] = param_2[5];
  puVar1[6] = param_2[6];
  puVar1[7] = param_2[7];
  puVar1[8] = param_2[8];
  return 1;
}

// ==== CMsgMonsterTransform::vfunc_1  @140457aa0  [high:rtti-vtable]  (orig: FUN_140457aa0)
ulonglong FUN_140457aa0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x412);
}

// ==== CMsgMonsterTransform::ctor_or_dtor  @140457ad0  [high:vtable-assign]  (orig: FUN_140457ad0)
undefined8 * FUN_140457ad0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMonsterTransform::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgMonsterTransform::ctor_or_dtor  @140457b20  [high:vtable-assign]  (orig: FUN_140457b20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140457b20(longlong param_1)

{
  undefined4 *puVar1;
  char cVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  int iVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined8 uVar8;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  longlong local_4a8;
  longlong local_4a0;
  undefined4 local_498;
  undefined4 local_494;
  undefined4 local_490;
  undefined4 local_48c;
  undefined4 local_488;
  undefined2 local_484;
  undefined2 local_482;
  undefined2 local_480;
  undefined2 local_47e;
  undefined1 local_47c;
  undefined4 local_478;
  undefined1 local_474;
  undefined4 local_470;
  undefined4 local_46c;
  undefined4 local_468;
  undefined1 local_464;
  undefined4 local_45c;
  undefined8 local_458;
  undefined **local_448 [2];
  undefined1 local_438 [1048];
  undefined1 *local_20;
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  puVar1 = *(undefined4 **)(param_1 + 0x428);
  if (puVar1 == (undefined4 *)0x0) {
    uVar3 = 0;
  }
  else {
    lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar6 + 0x88) == 0) {
      local_4b8 = 0x12f;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar7 = (longlong *)
             (**(code **)(**(longlong **)(lVar6 + 0x88) + 0x20))
                       (*(longlong **)(lVar6 + 0x88),puVar1[4]);
    uVar3 = 0;
    if (plVar7 != (longlong *)0x0) {
      local_4a8 = 0;
      (**(code **)(*plVar7 + 0x298))(plVar7,0x1002,&local_4a8);
      if (local_4a8 == 0) {
        uVar3 = 0;
      }
      else {
        cVar2 = (**(code **)(*(longlong *)(local_4a8 + 0x10) + 0x220))();
        uVar3 = 0;
        if (cVar2 != '\0') {
          cVar2 = FUN_1403886d0(local_4a8);
          if (cVar2 == '\0') {
            local_498 = 0;
            memset(&local_494,0,0x3c);
            local_464 = 0;
            if (puVar1[6] == 0) {
              uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              plVar7 = (longlong *)FUN_1400876b0(uVar8);
              uVar4 = (**(code **)(*plVar7 + 0xb8))(plVar7);
              puVar1[6] = uVar4;
            }
            local_498 = puVar1[6];
            local_490 = puVar1[7];
            local_494 = puVar1[1];
            local_478 = 0;
            local_48c = 0;
            local_470 = 0;
            local_46c = 0;
            local_488 = 0;
            local_468 = 0;
            local_474 = 3;
            local_47c = 0;
            local_480 = 0;
            local_484 = *(undefined2 *)(puVar1 + 2);
            local_482 = *(undefined2 *)(puVar1 + 3);
            local_47e = *(undefined2 *)(puVar1 + 5);
            local_45c = *puVar1;
            uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            plVar7 = (longlong *)FUN_1400e1d30(uVar8);
            cVar2 = (**(code **)(*plVar7 + 0x18))(plVar7,&local_498);
            if (cVar2 != '\0') {
              uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              plVar7 = (longlong *)FUN_1400875f0(uVar8);
              plVar7 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,puVar1[6]);
              if (plVar7 == (longlong *)0x0) {
                return 0;
              }
              local_4a0 = 0;
              (**(code **)(*plVar7 + 0x298))(plVar7,0x1002,&local_4a0);
              if (local_4a0 == 0) {
                return 0;
              }
              FUN_1402ba1c0(local_448);
              local_448[0] = CMsgMonsterTransform::vftable;
              FUN_1402b5600(local_448);
              local_20 = local_438;
              iVar5 = FUN_140457a30(local_448,puVar1);
              if (iVar5 != 0) {
                (**(code **)(*(longlong *)(local_4a0 + 0x10) + 0x348))
                          ((longlong *)(local_4a0 + 0x10),local_448,0);
              }
              if (*(int *)(local_4a8 + 0x154) == 0) {
                (**(code **)(*(longlong *)(local_4a8 + 0x10) + 0x2c8))
                          ((longlong *)(local_4a8 + 0x10),8,1);
                FUN_14038e270(local_4a8,1);
              }
              local_448[0] = CMsgMonsterTransform::vftable;
              FUN_1402b55f0(local_448);
            }
            uVar3 = 1;
          }
          else {
            uVar3 = 0;
          }
        }
      }
    }
  }
  return uVar3;
}

// ==== CMsgMonsterTransform::vfunc_3  @140457e10  [high:rtti-vtable]  (orig: FUN_140457e10)
void FUN_140457e10(undefined8 param_1,longlong param_2)

{
  if (param_2 != 0) {
    FUN_140457b20();
  }
  return;
}

