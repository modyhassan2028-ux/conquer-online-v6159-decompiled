// ==== CMsgBattleEffect::ctor_or_dtor  @1403f0c40  [high:vtable-assign]  (orig: FUN_1403f0c40)
undefined8 * FUN_1403f0c40(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgBattleEffect::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgBattleEffect::ctor_or_dtor  @1403f0c90  [high:vtable-assign]  (orig: FUN_1403f0c90)
void FUN_1403f0c90(undefined8 *param_1)

{
  *param_1 = CMsgBattleEffect::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgBattleEffect::vfunc_1  @1403f0cc0  [high:rtti-vtable]  (orig: FUN_1403f0cc0)
ulonglong FUN_1403f0cc0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x408);
}

// ==== CMsgBattleEffect::ctor_or_dtor  @1403f0d30  [high:vtable-assign]  (orig: FUN_1403f0d30)
undefined8 * FUN_1403f0d30(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgBattleEffect::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

