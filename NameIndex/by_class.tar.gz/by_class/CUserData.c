// ==== CUserData::ctor_or_dtor  @140371420  [high:vtable-assign]  (orig: FUN_140371420)
void FUN_140371420(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  *param_1 = CUserData::vftable;
  puVar1 = (undefined8 *)param_1[0x46];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CUserData::helper_1403743a0  @1403743a0  [medium:callgraph-r0]  (orig: FUN_1403743a0)
void FUN_1403743a0(void *param_1)

{
  if ((DAT_140976150 & 1) == 0) {
    DAT_140976150 = DAT_140976150 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976148,"CUserData");
    atexit((_func_5014 *)&LAB_1406d6b20);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403743f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976148,param_1);
  return;
}

// ==== CUserData::ctor_or_dtor  @140374460  [high:vtable-assign]  (orig: FUN_140374460)
undefined8 * FUN_140374460(undefined8 *param_1,uint param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CUserData::vftable;
  puVar1 = (undefined8 *)param_1[0x46];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  if ((param_2 & 1) != 0) {
    FUN_1403743a0(param_1);
  }
  return param_1;
}

// ==== CUserData::ctor_or_dtor  @140375860  [high:vtable-assign]  (orig: FUN_140375860)
undefined8 * FUN_140375860(undefined8 *param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  *param_1 = CUserData::vftable;
  lVar1 = 5;
  lVar2 = 5;
  do {
    *(undefined4 *)((longlong)param_1 + lVar2 * 4 + 0xe8) = 0;
    lVar2 = lVar2 + -1;
  } while (-1 < lVar2);
  do {
    *(undefined4 *)((longlong)param_1 + lVar1 * 4 + 0x100) = 0;
    lVar1 = lVar1 + -1;
  } while (-1 < lVar1);
  memset(param_1 + 1,0,0x228);
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  *(undefined4 *)(param_1 + 0x4b) = 0;
  param_1[0x46] = 0;
  return param_1;
}

