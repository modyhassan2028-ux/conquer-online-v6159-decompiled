// ==== CMsgRoulette1ArgAction::helper_1401ff720  @1401ff720  [medium:callgraph-r1]  (orig: FUN_1401ff720)
bool FUN_1401ff720(undefined8 param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  longlong *plVar4;
  ulonglong uVar5;
  IStringManager *pIVar6;
  undefined8 uVar7;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  plVar1 = param_2 + 2;
  lVar3 = (**(code **)(param_2[2] + 0x160))(plVar1);
  if (lVar3 == 0) {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR("CRouletteMgr::CheckAgreeInviteCondition map point is null, idUser:%u.");
    return false;
  }
  plVar4 = *(longlong **)(*(longlong *)(lVar3 + 0x58) + 8);
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,4);
  uVar5 = (**(code **)(*plVar4 + 0x58))(plVar4);
  if ((uVar5 >> 0x14 & 1) != 0) {
    pIVar6 = theInstance();
    lVar3 = *plVar1;
    uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ROULETTE_CAN_NOT_AGREE_INVITE_BY_MAP");
    (**(code **)(lVar3 + 0x358))(plVar1,uVar7);
    return false;
  }
  cVar2 = (**(code **)(*plVar1 + 0x220))(plVar1);
  if (cVar2 == '\0') {
    pIVar6 = theInstance();
    lVar3 = *plVar1;
    uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_DIE");
    (**(code **)(lVar3 + 0x358))(plVar1,uVar7);
    return false;
  }
  cVar2 = (**(code **)(*plVar1 + 0x250))(plVar1);
  return cVar2 != '\0';
}

// ==== CMsgRoulette1ArgAction::helper_1401ff860  @1401ff860  [medium:callgraph-r0]  (orig: FUN_1401ff860)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401ff860(longlong param_1,longlong param_2,int param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined8 local_450;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  if (param_2 != 0) {
    local_450 = 0xfffffffffffffffe;
    local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
    if (param_3 != 0) {
      local_458 = 0;
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 8));
      plVar3 = (longlong *)FUN_1400875f0(uVar2);
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,param_3);
      if ((plVar3 != (longlong *)0x0) &&
         (cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_458), cVar1 != '\0')) {
        FUN_14040ac40(local_448);
        cVar1 = FUN_14040acf0(local_448,local_458);
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                    ((longlong *)(param_2 + 0x10),local_448);
        }
        FUN_14040ac90(local_448);
      }
    }
  }
  return;
}

// ==== CMsgRoulette1ArgAction::helper_140200b10  @140200b10  [medium:callgraph-r3]  (orig: FUN_140200b10)
undefined8 *
FUN_140200b10(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    *(undefined4 *)(puVar1 + 3) = *param_5;
    *(undefined4 *)((longlong)puVar1 + 0x1c) = param_5[1];
    *(undefined4 *)(puVar1 + 4) = param_5[2];
    *(undefined4 *)((longlong)puVar1 + 0x24) = param_5[3];
    *(undefined4 *)(puVar1 + 5) = param_5[4];
    *(undefined1 *)((longlong)puVar1 + 0x2c) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x2d) = 0;
  }
  return puVar1;
}

// ==== CMsgRoulette1ArgAction::helper_140201540  @140201540  [medium:callgraph-r2]  (orig: FUN_140201540)
undefined8 * FUN_140201540(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  uint uVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  
  puVar5 = (undefined8 *)param_1[6];
  puVar6 = puVar5;
  if (*(char *)((longlong)puVar5[1] + 0x2d) == '\0') {
    uVar1 = *param_3;
    puVar3 = (undefined8 *)puVar5[1];
    do {
      if ((*(uint *)(puVar3 + 3) < uVar1) ||
         ((*(uint *)(puVar3 + 3) <= uVar1 && (*(uint *)((longlong)puVar3 + 0x1c) < param_3[1])))) {
        puVar4 = (undefined8 *)puVar3[2];
      }
      else {
        if ((*(char *)((longlong)puVar6 + 0x2d) != '\0') &&
           ((uVar1 < *(uint *)(puVar3 + 3) ||
            ((uVar1 <= *(uint *)(puVar3 + 3) && (param_3[1] < *(uint *)((longlong)puVar3 + 0x1c)))))
           )) {
          puVar6 = puVar3;
        }
        puVar4 = (undefined8 *)*puVar3;
        puVar5 = puVar3;
      }
      puVar3 = puVar4;
    } while (*(char *)((longlong)puVar4 + 0x2d) == '\0');
  }
  if (*(char *)((longlong)puVar6 + 0x2d) == '\0') {
    puVar3 = (undefined8 *)*puVar6;
  }
  else {
    puVar3 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar3 + 0x2d) == '\0') {
    do {
      if ((*param_3 < *(uint *)(puVar3 + 3)) ||
         ((*param_3 <= *(uint *)(puVar3 + 3) && (param_3[1] < *(uint *)((longlong)puVar3 + 0x1c)))))
      {
        puVar4 = (undefined8 *)*puVar3;
        puVar6 = puVar3;
      }
      else {
        puVar4 = (undefined8 *)puVar3[2];
      }
      puVar3 = puVar4;
    } while (*(char *)((longlong)puVar4 + 0x2d) == '\0');
  }
  uVar2 = *param_1;
  *param_2 = uVar2;
  param_2[1] = puVar5;
  param_2[2] = uVar2;
  param_2[3] = puVar6;
  return param_2;
}

// ==== CMsgRoulette1ArgAction::helper_140202c80  @140202c80  [medium:callgraph-r2]  (orig: FUN_140202c80)
undefined8 *
FUN_140202c80(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xcccccccccccccca < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140200b10(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x2c);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x2c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x2d) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x2d) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x2c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x2d) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x2d) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x2c);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x2c) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgRoulette1ArgAction::helper_140203a00  @140203a00  [medium:callgraph-r1]  (orig: FUN_140203a00)
longlong * FUN_140203a00(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x2d) == '\0') {
    puVar6 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar6;
      if ((*param_3 < *(uint *)(puVar7 + 3)) ||
         ((*param_3 <= *(uint *)(puVar7 + 3) && (param_3[1] < *(uint *)((longlong)puVar7 + 0x1c)))))
      {
        puVar6 = (undefined8 *)*puVar7;
        bVar8 = true;
      }
      else {
        puVar6 = (undefined8 *)puVar7[2];
        bVar8 = false;
      }
    } while (*(char *)((longlong)puVar6 + 0x2d) == '\0');
  }
  lVar2 = *param_1;
  puVar6 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8) {
    puVar6 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar6) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x2d) == '\0') {
        puVar6 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar6 + 0x2d) == '\0') {
          cVar1 = *(char *)((longlong)puVar6[2] + 0x2d);
          puVar3 = (undefined8 *)puVar6[2];
          while (puVar4 = puVar6, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x2d);
            puVar6 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x2d);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar6 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar6))) {
            cVar1 = *(char *)((longlong)puVar6[1] + 0x2d);
            puVar4 = (undefined8 *)puVar6[1];
            puVar3 = puVar6;
            local_30 = puVar6;
          }
          puVar4 = puVar6;
          if (*(char *)((longlong)puVar3 + 0x2d) != '\0') {
            _invalid_parameter_noinfo();
            puVar6 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar6 = (undefined8 *)puVar7[2];
        puVar4 = puVar6;
        if (*(char *)((longlong)puVar6 + 0x2d) != '\0') {
          local_30 = puVar6;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_140203b3d;
    }
    bVar8 = true;
  }
  else {
LAB_140203b3d:
    local_30 = puVar4;
    if ((*param_3 <= *(uint *)(puVar6 + 3)) &&
       ((*param_3 < *(uint *)(puVar6 + 3) || (param_3[1] <= *(uint *)((longlong)puVar6 + 0x1c))))) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_140203b93;
    }
  }
  plVar5 = (longlong *)FUN_140202c80(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar5[1];
  *param_2 = *plVar5;
LAB_140203b93:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgRoulette1ArgAction::helper_140203f80  @140203f80  [medium:callgraph-r1]  (orig: FUN_140203f80)
longlong * FUN_140203f80(longlong *param_1,longlong *param_2,uint *param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar2 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar2[1] + 0x2d) == '\0') {
    puVar3 = (undefined8 *)puVar2[1];
    do {
      if ((*(uint *)(puVar3 + 3) < *param_3) ||
         ((*(uint *)(puVar3 + 3) <= *param_3 && (*(uint *)((longlong)puVar3 + 0x1c) < param_3[1]))))
      {
        puVar4 = (undefined8 *)puVar3[2];
      }
      else {
        puVar4 = (undefined8 *)*puVar3;
        puVar2 = puVar3;
      }
      puVar3 = puVar4;
    } while (*(char *)((longlong)puVar4 + 0x2d) == '\0');
  }
  puVar3 = (undefined8 *)param_1[6];
  local_20 = puVar2;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if (((puVar2 == puVar3) || (*param_3 < *(uint *)(puVar2 + 3))) ||
     ((*param_3 <= *(uint *)(puVar2 + 3) && (param_3[1] < *(uint *)((longlong)puVar2 + 0x1c))))) {
    plVar1 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar1 = &local_28;
  }
  *param_2 = *plVar1;
  param_2[1] = plVar1[1];
  return param_2;
}

// ==== CMsgRoulette1ArgAction::helper_140204e70  @140204e70  [medium:callgraph-r0]  (orig: FUN_140204e70)
void FUN_140204e70(longlong param_1,longlong *param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  IStringManager *pIVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 *puVar7;
  char cVar8;
  undefined4 local_res20 [2];
  undefined4 local_98 [2];
  undefined4 local_90;
  int iStack_8c;
  longlong local_88;
  longlong *local_80 [2];
  undefined8 local_70;
  longlong local_68 [3];
  undefined8 local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  if ((param_3 != 0) && (local_70 = 0xfffffffffffffffe, param_2 != (longlong *)0x0)) {
    cVar8 = '\0';
    local_res20[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_140050f20(param_1 + 0xd0,&local_90,local_res20);
    lVar6 = *(longlong *)(param_1 + 0x100);
    local_80[0] = *(longlong **)(param_1 + 0xd0);
    plVar5 = (longlong *)CONCAT44(iStack_8c,local_90);
    if ((plVar5 == (longlong *)0x0) || (plVar5 != local_80[0])) {
      _invalid_parameter_noinfo();
    }
    if (local_88 != lVar6) {
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar5;
      }
      if (local_88 == *(longlong *)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(int *)(local_88 + 0x1c) != param_3) {
        pIVar3 = theInstance();
        lVar6 = param_2[2];
        uVar4 = (*(code *)**(undefined8 **)pIVar3)(pIVar3,"STR_ROULETTE_ALREAD_JOIN_OTHER_TABLE");
        (**(code **)(lVar6 + 0x358))(param_2 + 2,uVar4);
        return;
      }
      cVar8 = '\x01';
    }
    local_98[0] = (**(code **)(*param_2 + 8))(param_2);
    lVar6 = *(longlong *)(param_1 + 0x140);
    lVar1 = *(longlong *)(param_1 + 0x110);
    local_68[0] = lVar1;
    plVar5 = (longlong *)FUN_140050f20((longlong *)(param_1 + 0x110),local_80,local_98);
    if ((*plVar5 == 0) || (*plVar5 != lVar1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar5[1] == lVar6) {
      lVar6 = (**(code **)(param_2[2] + 0x2a8))(param_2 + 2,param_3);
      if (lVar6 != 0) {
        lVar6 = FUN_1401ff5c0(param_1,param_3);
        if (lVar6 == 0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR(
                            "CRouletteMgr::JoinRoulette GetRoulette failed, idUser:%u, npc id:%u, at %s, %d."
                            );
        }
        else {
          cVar2 = FUN_140412720(lVar6,param_2,cVar8,0);
          if ((cVar2 != '\0') && (cVar8 == '\0')) {
            local_50 = 0;
            local_90 = (**(code **)(*param_2 + 8))(param_2);
            iStack_8c = param_3;
            puVar7 = (undefined8 *)FUN_1400507e0(param_1 + 0xd0,local_68,&local_90);
            local_50 = *puVar7;
            local_48 = puVar7[1];
            local_40 = puVar7[2];
            if ((char)local_40 == '\0') {
              (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR(
                                "CRouletteMgr::JoinRoulette m_mapRouletteUser insert failed, idUser:%u, idNpc:%u, at %s, %d."
                                );
            }
          }
        }
      }
    }
    else {
      pIVar3 = theInstance();
      lVar6 = param_2[2];
      uVar4 = (*(code *)**(undefined8 **)pIVar3)(pIVar3,"STR_ROULETTE_ALREAD_WITNESS_OTHER_TABLE");
      (**(code **)(lVar6 + 0x358))(param_2 + 2,uVar4);
    }
  }
  return;
}

// ==== CMsgRoulette1ArgAction::helper_140205f80  @140205f80  [medium:callgraph-r1]  (orig: FUN_140205f80)
bool FUN_140205f80(longlong param_1,longlong *param_2,int param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  uint uVar5;
  longlong *plVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong **pplVar10;
  longlong *plVar11;
  uint local_res10 [2];
  longlong *local_58;
  longlong *local_50;
  longlong *local_48;
  undefined8 local_40;
  longlong *local_38;
  longlong *local_30;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  uVar5 = (**(code **)(*param_2 + 8))(param_2);
  if (uVar5 == 0) {
    return false;
  }
  plVar1 = *(longlong **)(param_1 + 0x140);
  plVar2 = *(longlong **)(param_1 + 0x110);
  cVar4 = *(char *)(plVar1[1] + 0x21);
  plVar3 = plVar1;
  plVar11 = (longlong *)plVar1[1];
  while (cVar4 == '\0') {
    if (*(uint *)(plVar11 + 3) < uVar5) {
      plVar6 = (longlong *)plVar11[2];
      plVar11 = plVar3;
    }
    else {
      plVar6 = (longlong *)*plVar11;
    }
    plVar3 = plVar11;
    plVar11 = plVar6;
    cVar4 = *(char *)((longlong)plVar6 + 0x21);
  }
  local_50 = plVar3;
  local_58 = plVar2;
  local_res10[0] = uVar5;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((plVar3 == plVar1) || (uVar5 < *(uint *)(plVar3 + 3))) {
    pplVar10 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0x140);
    local_48 = *(longlong **)(param_1 + 0x110);
  }
  else {
    pplVar10 = &local_58;
  }
  local_38 = *pplVar10;
  local_30 = pplVar10[1];
  if ((local_38 == (longlong *)0x0) || (local_38 != plVar2)) {
    _invalid_parameter_noinfo();
  }
  if (local_30 == plVar1) {
    FUN_140050f20(param_1 + 0xd0,&local_38,local_res10);
    plVar2 = local_38;
    plVar1 = *(longlong **)(param_1 + 0x100);
    if ((local_38 == (longlong *)0x0) || (local_38 != *(longlong **)(param_1 + 0xd0))) {
      _invalid_parameter_noinfo();
    }
    plVar3 = local_30;
    if (local_30 == plVar1) {
      return true;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (plVar3 == *(longlong **)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (param_3 != *(int *)((longlong)plVar3 + 0x1c)) {
      pIVar7 = theInstance();
      lVar9 = param_2[2];
      uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ROULETTE_ALREAD_JOIN_OTHER_TABLE");
      (**(code **)(lVar9 + 0x358))(param_2 + 2,uVar8);
      return false;
    }
    lVar9 = FUN_1401ff5c0(param_1,param_3);
    if (lVar9 != 0) {
      cVar4 = FUN_14040f730(lVar9,uVar5);
      return cVar4 == '\0';
    }
    log_InlineLogERROR(
                      "CRouletteMgr::CheckUserWitness GetRoulette failed, idUser:%u, idNpc:%u, at %s, %d."
                      );
  }
  return false;
}

// ==== CMsgRoulette1ArgAction::helper_1402061e0  @1402061e0  [medium:callgraph-r0]  (orig: FUN_1402061e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402061e0(longlong param_1,longlong *param_2,int param_3)

{
  longlong lVar1;
  longlong *plVar2;
  longlong lVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  ulong uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  longlong *plVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  longlong *plVar13;
  longlong lVar14;
  ulonglong uVar15;
  longlong lVar16;
  undefined1 auStack_538 [32];
  undefined4 local_518;
  undefined8 local_510;
  longlong local_508;
  longlong local_500;
  undefined4 local_4f8;
  undefined4 uStack_4f4;
  uint local_4f0;
  undefined4 uStack_4ec;
  undefined4 local_4e8;
  int iStack_4e4;
  longlong *local_4e0;
  longlong *local_4d8;
  longlong *local_4c8;
  undefined8 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4ac;
  uint local_4a8;
  longlong *local_4a0 [3];
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_538;
  local_508 = param_1;
  local_4e0 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_518 = 0x343;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar5 = (**(code **)(*param_2 + 8))(param_2);
    if ((iVar5 != param_3) && (param_3 != 0)) {
      plVar10 = (longlong *)FUN_1401183a0();
      lVar1 = *plVar10;
      uVar6 = (**(code **)(*param_2 + 8))(param_2);
      cVar4 = (**(code **)(lVar1 + 0x170))(plVar10,uVar6,param_3);
      if (cVar4 != '\0') {
        uVar6 = (**(code **)(*param_2 + 8))(param_2);
        local_500 = CONCAT44(local_500._4_4_,uVar6);
        FUN_140050f20((longlong *)(param_1 + 0xd0),&local_4f8,&local_500);
        lVar1 = *(longlong *)(param_1 + 0x100);
        lVar16 = 0;
        local_4d8 = *(longlong **)(param_1 + 0xd0);
        plVar10 = (longlong *)CONCAT44(uStack_4f4,local_4f8);
        if ((plVar10 == (longlong *)0x0) || (plVar10 != local_4d8)) {
          _invalid_parameter_noinfo();
        }
        lVar3 = CONCAT44(uStack_4ec,local_4f0);
        if (lVar3 != lVar1) {
          local_4e8 = (**(code **)(*param_2 + 8))(param_2);
          lVar1 = local_508;
          iStack_4e4 = param_3;
          FUN_140203f80(local_508 + 0x90,&local_4f8,&local_4e8);
          local_500 = *(longlong *)(lVar1 + 0xc0);
          local_4c8 = *(longlong **)(lVar1 + 0x90);
          plVar2 = (longlong *)CONCAT44(uStack_4f4,local_4f8);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != local_4c8)) {
            _invalid_parameter_noinfo();
          }
          lVar1 = CONCAT44(uStack_4ec,local_4f0);
          if (lVar1 != local_500) {
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar14 = lVar16;
            }
            else {
              lVar14 = *plVar2;
            }
            if (lVar1 == *(longlong *)(lVar14 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar10 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar14 = lVar16;
            }
            else {
              lVar14 = *plVar10;
            }
            if (lVar3 == *(longlong *)(lVar14 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (*(int *)(lVar1 + 0x20) == *(int *)(lVar3 + 0x1c)) {
              pIVar11 = theInstance();
              lVar1 = param_2[2];
              uVar12 = (*(code *)**(undefined8 **)pIVar11)
                                 (pIVar11,"STR_ROULETTE_ALREADY_INVITED_PLAYER");
              (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar12);
              return;
            }
          }
          uVar12 = FUN_140008520(*(undefined4 *)(local_508 + 8));
          plVar13 = (longlong *)FUN_140087650(uVar12);
          plVar13 = (longlong *)(**(code **)(*plVar13 + 0x98))(plVar13,param_3);
          if (plVar13 == (longlong *)0x0) {
            pIVar11 = theInstance();
            lVar1 = param_2[2];
            uVar12 = (*(code *)**(undefined8 **)pIVar11)
                               (pIVar11,"STR_ROULETTE_INVITED_PLAYER_NOT_ONLINE");
            (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar12);
          }
          else {
            local_4d8 = plVar13 + 2;
            lVar14 = (**(code **)(*local_4d8 + 0x160))();
            if (lVar14 == 0) {
              (**(code **)(*plVar13 + 8))(plVar13);
              log_InlineLogERROR(
                                "CRouletteMgr::ProcessApplyInvite map point is null, target idUser:%u."
                                );
            }
            else {
              plVar13 = *(longlong **)(*(longlong *)(lVar14 + 0x58) + 8);
              plVar13 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,4);
              uVar15 = (**(code **)(*plVar13 + 0x58))(plVar13);
              if ((uVar15 >> 0x14 & 1) == 0) {
                if (plVar10 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar14 = lVar16;
                }
                else {
                  lVar14 = *plVar10;
                }
                if (lVar3 == *(longlong *)(lVar14 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                uVar6 = *(undefined4 *)(lVar3 + 0x1c);
                local_4c8 = (longlong *)FUN_1401ff5c0(local_508,uVar6);
                if (local_4c8 == (longlong *)0x0) {
                  (**(code **)(*param_2 + 8))(param_2);
                  local_518 = 0x380;
                  log_InlineLogERROR(
                                    "CRouletteMgr::ProcessApplyInvite GetRoulette failed, idUser:%u, idNpc:%u, at %s, %d."
                                    );
                }
                else {
                  local_500 = *(longlong *)(local_508 + 0xc0);
                  local_4a0[0] = *(longlong **)(local_508 + 0x90);
                  if ((plVar2 == (longlong *)0x0) || (plVar2 != local_4a0[0])) {
                    _invalid_parameter_noinfo();
                  }
                  if (lVar1 == local_500) {
                    local_4f0 = 0;
                    uStack_4f4 = *(undefined4 *)(local_508 + 0x1a0);
                    local_4f8 = uVar6;
                    uVar7 = tq::TimeGet(0);
                    local_4f0 = uVar7 / 1000;
                    local_4b8 = CONCAT44(iStack_4e4,local_4e8);
                    local_4b0 = local_4f8;
                    local_4ac = uStack_4f4;
                    local_4a8 = local_4f0;
                    FUN_140203a00(local_508 + 0x90,local_4a0,&local_4b8);
                  }
                  else {
                    if (plVar2 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar14 = lVar16;
                    }
                    else {
                      lVar14 = *plVar2;
                    }
                    if (lVar1 == *(longlong *)(lVar14 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    *(undefined4 *)(lVar1 + 0x20) = uVar6;
                    if (plVar2 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar14 = lVar16;
                    }
                    else {
                      lVar14 = *plVar2;
                    }
                    if (lVar1 == *(longlong *)(lVar14 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    *(undefined4 *)(lVar1 + 0x24) = *(undefined4 *)(local_508 + 0x1a0);
                    uVar7 = tq::TimeGet(0);
                    *(uint *)(lVar1 + 0x28) = uVar7 / 1000;
                  }
                  FUN_140413070(local_478);
                  if (plVar10 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  else {
                    lVar16 = *plVar10;
                  }
                  if (lVar3 == *(longlong *)(lVar16 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  uVar12 = (**(code **)(param_2[2] + 0x18))();
                  plVar10 = local_4c8;
                  uVar6 = FUN_14040b180(local_4c8);
                  uVar8 = FUN_14040b0f0(plVar10);
                  uVar9 = (**(code **)(*param_2 + 8))(param_2);
                  local_518 = uVar6;
                  local_510 = uVar12;
                  cVar4 = FUN_140413120(local_478,uVar9,*(undefined4 *)(lVar3 + 0x1c),uVar8);
                  if (cVar4 == '\0') {
                    log_InlineLogERROR(
                                      "CRouletteMgr::ProcessApplyInvite CMsgRouletteInvite create failed."
                                      );
                    FUN_1404130c0(local_478);
                  }
                  else {
                    (**(code **)(*local_4d8 + 0x350))(local_4d8,local_478);
                    FUN_1404130c0(local_478);
                  }
                }
              }
              else {
                pIVar11 = theInstance();
                lVar1 = param_2[2];
                uVar12 = (*(code *)**(undefined8 **)pIVar11)
                                   (pIVar11,"STR_ROULETTE_CAN_NOT_RECEIVE_INVITE");
                (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar12);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgRoulette1ArgAction::helper_1402068d0  @1402068d0  [medium:callgraph-r1]  (orig: FUN_1402068d0)
longlong FUN_1402068d0(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_140201540(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x2d) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x2d) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x2d);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x2d);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x2d);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x2d);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140204320(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMsgRoulette1ArgAction::helper_140207160  @140207160  [medium:callgraph-r0]  (orig: FUN_140207160)
void FUN_140207160(longlong param_1,longlong *param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  undefined4 local_res20;
  undefined4 local_res24;
  char local_40;
  undefined1 local_38 [32];
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar1 = FUN_140205f80();
    if (cVar1 != '\0') {
      lVar2 = (**(code **)(param_2[2] + 0x2a8))(param_2 + 2,param_3);
      if (lVar2 != 0) {
        lVar2 = FUN_1401ff5c0(param_1,param_3);
        if (lVar2 == 0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR(
                            "CRouletteMgr::ProcessAddWitness GetRoulette failed, idUser:%u, idNpc:%u, at %s, %d."
                            );
        }
        else {
          cVar1 = FUN_14040e800(lVar2,param_2);
          if (cVar1 != '\0') {
            local_res20 = (**(code **)(*param_2 + 8))(param_2);
            local_res24 = param_3;
            lVar2 = FUN_1400507e0(param_1 + 0x110,local_38,&local_res20);
            local_40 = (char)*(undefined8 *)(lVar2 + 0x10);
            if (local_40 == '\0') {
              (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR(
                                "CRouletteMgr::ProcessAddWitness m_mapWitnessUser insert failed, idUser:%u, idNpc:%u, at %s, %d."
                                );
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgRoulette1ArgAction::helper_1402074c0  @1402074c0  [medium:callgraph-r0]  (orig: FUN_1402074c0)
void FUN_1402074c0(longlong param_1,longlong *param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  char cVar3;
  ulong uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  IStringManager *pIVar8;
  undefined8 uVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong lVar12;
  undefined4 local_res20 [2];
  uint in_stack_ffffffffffffff68;
  undefined4 local_88 [2];
  undefined4 local_80;
  undefined4 local_7c;
  undefined8 local_78;
  longlong *local_70;
  longlong local_68;
  longlong *local_60;
  longlong *local_50;
  longlong *local_40 [3];
  
  local_78 = 0xfffffffffffffffe;
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_7c = (**(code **)(*param_2 + 8))(param_2);
    local_80 = param_3;
    FUN_140203f80(param_1 + 0x90,&local_70,&local_80);
    plVar1 = local_70;
    lVar11 = *(longlong *)(param_1 + 0xc0);
    lVar12 = 0;
    local_60 = *(longlong **)(param_1 + 0x90);
    if ((local_70 == (longlong *)0x0) || (local_70 != local_60)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = local_68;
    if (local_68 == lVar11) {
      pIVar8 = theInstance();
      lVar11 = param_2[2];
      uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_ROULETTE_INVITE_IS_TIMEOUT");
      (**(code **)(lVar11 + 0x358))(param_2 + 2,uVar9);
    }
    else {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = lVar12;
      }
      else {
        lVar11 = *plVar1;
      }
      if (lVar2 == *(longlong *)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar4 = tq::TimeGet(0);
      if (uVar4 / 1000 < (uint)(*(int *)(lVar2 + 0x28) + *(int *)(lVar2 + 0x24))) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar12;
        }
        else {
          lVar11 = *plVar1;
        }
        if (lVar2 == *(longlong *)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        iVar6 = *(int *)(lVar2 + 0x20);
        FUN_1402068d0(param_1 + 0x90,&local_80);
        uVar5 = (**(code **)(*param_2 + 8))(param_2);
        cVar3 = FUN_140204c30(param_1,uVar5);
        if (cVar3 != '\0') {
          local_res20[0] = (**(code **)(*param_2 + 8))(param_2);
          FUN_140050f20(param_1 + 0xd0,&local_70,local_res20);
          lVar11 = *(longlong *)(param_1 + 0x100);
          local_50 = *(longlong **)(param_1 + 0xd0);
          if ((local_70 == (longlong *)0x0) || (local_70 != local_50)) {
            _invalid_parameter_noinfo();
          }
          if (local_68 != lVar11) {
            if (local_70 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar11 = lVar12;
            }
            else {
              lVar11 = *local_70;
            }
            if (local_68 == *(longlong *)(lVar11 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (*(int *)(local_68 + 0x1c) == iVar6) {
              return;
            }
          }
          local_88[0] = (**(code **)(*param_2 + 8))(param_2);
          puVar10 = (undefined8 *)FUN_140050f20(param_1 + 0x110,local_40,local_88);
          plVar1 = (longlong *)*puVar10;
          local_68 = puVar10[1];
          lVar11 = *(longlong *)(param_1 + 0x140);
          local_40[0] = *(longlong **)(param_1 + 0x110);
          local_70 = plVar1;
          if ((plVar1 == (longlong *)0x0) || (plVar1 != local_40[0])) {
            _invalid_parameter_noinfo();
          }
          lVar2 = local_68;
          if (local_68 != lVar11) {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            else {
              lVar12 = *plVar1;
            }
            if (lVar2 == *(longlong *)(lVar12 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (*(int *)(lVar2 + 0x1c) == iVar6) {
              FUN_140205100(param_1,param_2);
              return;
            }
          }
        }
        lVar11 = FUN_1401ff5c0(param_1,iVar6);
        if (lVar11 == 0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR(
                            "CRouletteMgr::ProcessAgreeInvite GetRoulette failed, idUser:%u, idNpc:%u, at %s, %d."
                            );
        }
        else {
          cVar3 = FUN_1401ff720(param_1,param_2);
          if (cVar3 != '\0') {
            iVar6 = FUN_14040b300(lVar11);
            uVar5 = FUN_14040b360(lVar11);
            uVar7 = FUN_14040b2a0(lVar11);
            iVar6 = FUN_1401c55b0(param_2,uVar7,iVar6 + 5,uVar5,
                                  in_stack_ffffffffffffff68 & 0xffffff00);
            if (iVar6 != 0) {
              (**(code **)(*param_2 + 8))(param_2);
              FUN_14040b2a0(lVar11);
              log_InlineLogERROR(
                                "CRouletteMgr::ProcessAgreeInvite flymap failed, mapid:%u, pos:(%d, %d), idUser:%u."
                                );
            }
          }
        }
      }
      else {
        pIVar8 = theInstance();
        lVar11 = param_2[2];
        uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_ROULETTE_INVITE_IS_TIMEOUT");
        (**(code **)(lVar11 + 0x358))(param_2 + 2,uVar9);
        FUN_1402068d0(param_1 + 0x90,&local_80);
      }
    }
  }
  return;
}

// ==== CMsgRoulette1ArgAction::helper_140207890  @140207890  [medium:callgraph-r0]  (orig: FUN_140207890)
void FUN_140207890(longlong param_1,longlong *param_2,undefined4 param_3)

{
  undefined4 local_res8;
  undefined4 local_resc;
  
  local_res8 = param_3;
  local_resc = (**(code **)(*param_2 + 8))(param_2);
  FUN_1402068d0(param_1 + 0x90,&local_res8);
  return;
}

// ==== CMsgRoulette1ArgAction::helper_14040b0f0  @14040b0f0  [medium:callgraph-r1]  (orig: FUN_14040b0f0)
undefined8 FUN_14040b0f0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = *(longlong *)(param_1 + 0x198);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*(longlong *)(lVar1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014040b179. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(**(longlong **)(lVar1 + 0x60) + 0x10))(*(longlong **)(lVar1 + 0x60),0x12);
  return uVar2;
}

// ==== CMsgRoulette1ArgAction::helper_14040b180  @14040b180  [medium:callgraph-r1]  (orig: FUN_14040b180)
undefined8 FUN_14040b180(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = *(longlong *)(param_1 + 0x198);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*(longlong *)(lVar1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014040b209. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(**(longlong **)(lVar1 + 0x60) + 0x10))(*(longlong **)(lVar1 + 0x60),0x13);
  return uVar2;
}

// ==== CMsgRoulette1ArgAction::helper_14040b2a0  @14040b2a0  [medium:callgraph-r1]  (orig: FUN_14040b2a0)
undefined8 FUN_14040b2a0(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x198) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014040b2f2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x10) + 0x168))
                    (*(longlong *)(param_1 + 0x198) + 0x10);
  return uVar1;
}

// ==== CMsgRoulette1ArgAction::helper_14040b300  @14040b300  [medium:callgraph-r1]  (orig: FUN_14040b300)
undefined8 FUN_14040b300(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x198) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014040b352. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x10) + 0x40))
                    (*(longlong *)(param_1 + 0x198) + 0x10);
  return uVar1;
}

// ==== CMsgRoulette1ArgAction::helper_14040b360  @14040b360  [medium:callgraph-r1]  (orig: FUN_14040b360)
undefined8 FUN_14040b360(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x198) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014040b3b2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x10) + 0x48))
                    (*(longlong *)(param_1 + 0x198) + 0x10);
  return uVar1;
}

// ==== CMsgRoulette1ArgAction::helper_14040de40  @14040de40  [medium:callgraph-r2]  (orig: FUN_14040de40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14040de40(undefined4 *param_1,longlong *param_2,byte param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined1 uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong *plVar12;
  bool bVar13;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  byte local_4c8;
  undefined4 *local_4c0;
  longlong *local_4b8;
  longlong *local_4b0;
  longlong *local_4a8;
  longlong *local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  local_4c8 = param_3;
  local_4c0 = param_1;
  local_4b8 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_4d8 = CONCAT44(local_4d8._4_4_,0x243);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if ((param_3 < 5) || (param_3 == 99)) {
    FUN_1404dd7f0(local_478);
    if ((param_1[0x61] == 0) && ((param_1[0x5f] == 0 && (*(longlong *)(param_1 + 0x16) != 0)))) {
      uVar3 = 0x1e;
    }
    else {
      uVar3 = FUN_14016b120(param_1 + 0x60);
    }
    cVar4 = FUN_1404dd8a0(local_478,*param_1,param_3,uVar3);
    if (cVar4 != '\0') {
      plVar12 = (longlong *)**(undefined8 **)(param_1 + 0x14);
      plVar1 = *(longlong **)(param_1 + 8);
      local_4a8 = plVar1;
      do {
        while( true ) {
          while( true ) {
            plVar10 = *(longlong **)(param_1 + 0x14);
            local_498 = *(longlong **)(param_1 + 8);
            if ((plVar1 == (longlong *)0x0) || (plVar1 != local_498)) {
              _invalid_parameter_noinfo();
            }
            if (plVar12 == plVar10) {
              (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
              FUN_1404dd840(local_478);
              return;
            }
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar11 = 0;
            }
            else {
              lVar11 = *plVar1;
            }
            if (plVar12 == *(longlong **)(lVar11 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar12[4] != 0) {
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar11 = 0;
              }
              else {
                lVar11 = *plVar1;
              }
              if (plVar12 == *(longlong **)(lVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              if (*(char *)(plVar12[4] + 0x14) != '\x01') {
                uVar9 = FUN_140008520(param_1[100]);
                plVar10 = (longlong *)FUN_140087650(uVar9);
                if (plVar1 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar11 = 0;
                }
                else {
                  lVar11 = *plVar1;
                }
                if (plVar12 == *(longlong **)(lVar11 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                plVar10 = (longlong *)
                          (**(code **)(*plVar10 + 0x98))(plVar10,*(undefined4 *)plVar12[4]);
                if (plVar10 != (longlong *)0x0) {
                  iVar5 = (**(code **)(*param_2 + 8))(param_2);
                  iVar6 = (**(code **)(*plVar10 + 8))(plVar10);
                  if (iVar5 != iVar6) {
                    if (plVar1 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar11 = 0;
                    }
                    else {
                      lVar11 = *plVar1;
                    }
                    if (plVar12 == *(longlong **)(lVar11 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    uVar9 = (**(code **)(plVar10[2] + 0x18))(plVar10 + 2);
                    lVar11 = plVar12[4];
                    uVar7 = (**(code **)(plVar10[2] + 0x30))(plVar10 + 2);
                    uVar8 = (**(code **)(*plVar10 + 8))(plVar10);
                    local_4d8 = uVar9;
                    cVar4 = FUN_1404dd8e0(local_478,uVar8,uVar7,*(undefined1 *)(lVar11 + 0x15));
                    if (cVar4 == '\0') {
                      (**(code **)(*param_2 + 8))(param_2);
                      log_InlineLogERROR(
                                        "CRoulette::SendTableOtherPlayerInfo msg append failed, idUser:%u."
                                        );
                      FUN_1404dd840(local_478);
                      return;
                    }
                  }
                }
              }
            }
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)plVar12 + 0x29) == '\0') break;
            _invalid_parameter_noinfo();
            param_1 = local_4c0;
          }
          plVar10 = plVar12;
          plVar2 = (longlong *)plVar12[2];
          param_1 = local_4c0;
          if (*(char *)(plVar12[2] + 0x29) != '\0') break;
          do {
            plVar12 = plVar2;
            plVar2 = (longlong *)*plVar12;
            local_4b0 = plVar12;
          } while (*(char *)(*plVar12 + 0x29) == '\0');
        }
        do {
          plVar12 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x29) != '\0') break;
          bVar13 = plVar10 == (longlong *)plVar12[2];
          plVar10 = plVar12;
        } while (bVar13);
      } while( true );
    }
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR("CRoulette::SendTableOtherPlayerInfo msg create failed, idUser:%u.");
    FUN_1404dd840(local_478);
  }
  else {
    (**(code **)(*param_2 + 8))(param_2);
    local_4d8 = CONCAT44(local_4d8._4_4_,0x24a);
    log_InlineLogERROR(
                      "CRoulette::SendTableOtherPlayerInfo seat num is error, idUser:%u, seat num:%u, at %s, %d."
                      );
  }
  return;
}

// ==== CMsgRoulette1ArgAction::helper_14040e1f0  @14040e1f0  [medium:callgraph-r2]  (orig: FUN_14040e1f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14040e1f0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  ulonglong uVar9;
  bool bVar10;
  undefined1 auStack_4c8 [32];
  int local_4a8;
  longlong *local_4a0;
  longlong *local_498;
  undefined8 local_490;
  longlong *local_488;
  longlong *local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_490 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x50);
  plVar1 = *(longlong **)(param_1 + 0x20);
  local_4a0 = param_2;
  local_478 = plVar1;
  do {
    while( true ) {
      while( true ) {
        plVar6 = *(longlong **)(param_1 + 0x50);
        local_488 = *(longlong **)(param_1 + 0x20);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_488)) {
          _invalid_parameter_noinfo();
        }
        if (plVar5 == plVar6) {
          return;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar1;
        }
        if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (plVar5[4] != 0) {
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar1;
          }
          if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)(plVar5[4] + 0x14) != '\x01') {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar1;
            }
            if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            iVar4 = (**(code **)(*param_2 + 8))(param_2);
            if (*(int *)plVar5[4] != iVar4) {
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar7 = 0;
              }
              else {
                lVar7 = *plVar1;
              }
              if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              if (*(longlong *)(plVar5[4] + 0x38) - *(longlong *)(plVar5[4] + 0x30) >> 3 != 0) {
                FUN_1404dda80(local_468);
                if (plVar1 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar7 = 0;
                }
                else {
                  lVar7 = *plVar1;
                }
                if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                cVar3 = FUN_1404ddb30(local_468,*(undefined1 *)(plVar5[4] + 0x15));
                if (cVar3 == '\0') {
                  if (plVar1 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    lVar7 = 0;
                  }
                  else {
                    lVar7 = *plVar1;
                  }
                  if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  log_InlineLogERROR("CRoulette::SendTableWagerInfo msg create failed, seat num:%u."
                                    );
                  FUN_1404ddad0(local_468);
                }
                else {
                  local_4a8 = 0;
                  while( true ) {
                    iVar4 = local_4a8;
                    if (plVar1 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar7 = 0;
                    }
                    else {
                      lVar7 = *plVar1;
                    }
                    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    uVar9 = (ulonglong)iVar4;
                    if ((ulonglong)
                        (*(longlong *)(plVar5[4] + 0x38) - *(longlong *)(plVar5[4] + 0x30) >> 3) <=
                        uVar9) break;
                    if (plVar1 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar7 = 0;
                    }
                    else {
                      lVar7 = *plVar1;
                    }
                    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    lVar7 = plVar5[4];
                    if ((ulonglong)(*(longlong *)(lVar7 + 0x38) - *(longlong *)(lVar7 + 0x30) >> 3)
                        <= uVar9) {
                      _invalid_parameter_noinfo();
                    }
                    lVar7 = *(longlong *)(lVar7 + 0x30);
                    if (plVar1 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar8 = 0;
                    }
                    else {
                      lVar8 = *plVar1;
                    }
                    if (plVar5 == *(longlong **)(lVar8 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    lVar8 = plVar5[4];
                    if ((ulonglong)(*(longlong *)(lVar8 + 0x38) - *(longlong *)(lVar8 + 0x30) >> 3)
                        <= uVar9) {
                      _invalid_parameter_noinfo();
                    }
                    cVar3 = FUN_1404ddb80(local_468,
                                          *(undefined1 *)(*(longlong *)(lVar8 + 0x30) + uVar9 * 8),
                                          *(undefined4 *)(lVar7 + 4 + uVar9 * 8));
                    if (cVar3 == '\0') {
                      if (plVar1 == (longlong *)0x0) {
                        _invalid_parameter_noinfo();
                        lVar7 = 0;
                      }
                      else {
                        lVar7 = *plVar1;
                      }
                      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
                        _invalid_parameter_noinfo();
                      }
                      log_InlineLogERROR(
                                        "CRoulette::SendTableWagerInfo msg Append failed, vector size:%u."
                                        );
                    }
                    local_4a8 = iVar4 + 1;
                  }
                  cVar3 = FUN_1404ddc50(local_468);
                  param_2 = local_4a0;
                  if (cVar3 != '\0') {
                    (**(code **)(local_4a0[2] + 0x350))(local_4a0 + 2,local_468);
                  }
                  FUN_1404ddad0(local_468);
                }
              }
            }
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar6 = plVar5;
      plVar2 = (longlong *)plVar5[2];
      if (*(char *)(plVar5[2] + 0x29) != '\0') break;
      do {
        plVar5 = plVar2;
        plVar2 = (longlong *)*plVar5;
        local_498 = plVar5;
      } while (*(char *)(*plVar5 + 0x29) == '\0');
    }
    do {
      plVar5 = (longlong *)plVar6[1];
      if (*(char *)((longlong)plVar5 + 0x29) != '\0') break;
      bVar10 = plVar6 == (longlong *)plVar5[2];
      plVar6 = plVar5;
    } while (bVar10);
  } while( true );
}

// ==== CMsgRoulette1ArgAction::helper_14040e800  @14040e800  [medium:callgraph-r1]  (orig: FUN_14040e800)
undefined8 FUN_14040e800(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  IStringManager *pIVar4;
  undefined8 uVar5;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*(char *)(param_1 + 0x170) == '\0') {
    pIVar4 = theInstance();
    lVar1 = param_2[2];
    uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_ROULETTE_WITTNESS_FAILE_NOT_START");
    (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar5);
    return 0;
  }
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  cVar2 = FUN_1404dcbe0(*(undefined8 *)(param_1 + 0x188),uVar3);
  if (cVar2 == '\0') {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR("CRoulette::AddWitness m_pRouletteWitnessMgr->AddWitness failed, idUser:%u.")
    ;
    return 0;
  }
  FUN_14040de40(param_1,param_2,99);
  FUN_14040e1f0(param_1,param_2);
  return 1;
}

// ==== CMsgRoulette1ArgAction::helper_140413120  @140413120  [medium:callgraph-r1]  (orig: FUN_140413120)
undefined8
FUN_140413120(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined8 *param_6)

{
  longlong lVar1;
  undefined8 uVar2;
  
  *(undefined4 *)(param_1 + 0xc) = 0x20;
  *(undefined4 *)(param_1 + 8) = 0xaf6;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_5;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined8 *)(lVar1 + 0x10) = *param_6;
  uVar2 = param_6[1];
  *(undefined8 *)(lVar1 + 0x18) = uVar2;
  return CONCAT71((int7)((ulonglong)uVar2 >> 8),1);
}

// ==== CMsgRoulette1ArgAction::ctor_or_dtor  @1404131e0  [high:vtable-assign]  (orig: FUN_1404131e0)
undefined8 * FUN_1404131e0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRoulette1ArgAction::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRoulette1ArgAction::ctor_or_dtor  @140413230  [high:vtable-assign]  (orig: FUN_140413230)
void FUN_140413230(undefined8 *param_1)

{
  *param_1 = CMsgRoulette1ArgAction::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRoulette1ArgAction::vfunc_1  @140413260  [high:rtti-vtable]  (orig: FUN_140413260)
ulonglong FUN_140413260(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xaf5);
}

// ==== CMsgRoulette1ArgAction::ctor_or_dtor  @1404132c0  [high:vtable-assign]  (orig: FUN_1404132c0)
undefined8 * FUN_1404132c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRoulette1ArgAction::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgRoulette1ArgAction::vfunc_3  @140413310  [high:rtti-vtable]  (orig: FUN_140413310)
void FUN_140413310(longlong param_1)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  IStringManager *pIVar5;
  longlong lVar6;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x88))(plVar3,param_1);
    if (lVar4 != 0) {
      cVar1 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x220))(lVar4 + 0x10);
      if (((cVar1 == '\0') && (**(char **)(param_1 + 0x428) != '\x02')) &&
         (**(char **)(param_1 + 0x428) != '\x03')) {
        pIVar5 = theInstance();
        lVar6 = *(longlong *)(lVar4 + 0x10);
        uVar2 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_DIE");
        (**(code **)(lVar6 + 0x358))(lVar4 + 0x10,uVar2);
      }
      else {
        switch(**(undefined1 **)(param_1 + 0x428)) {
        case 0:
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x1d8) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x1d8);
          }
          FUN_140204e70(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
          break;
        case 1:
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x1d8) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x1d8);
          }
          FUN_1402061e0(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
          break;
        case 2:
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x1d8) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x1d8);
          }
          FUN_1402074c0(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
          break;
        case 3:
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x1d8) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x1d8);
          }
          FUN_140207890(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
          break;
        case 4:
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x1d8) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x1d8);
          }
          FUN_140207160(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
          break;
        case 5:
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x1d8) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x1d8);
          }
          FUN_1401ff860(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
        }
      }
    }
  }
  return;
}

// ==== CMsgRoulette1ArgAction::helper_1404dc910  @1404dc910  [medium:callgraph-r3]  (orig: FUN_1404dc910)
bool FUN_1404dc910(longlong param_1,uint param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x1d);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar6 + 3) < param_2) {
      puVar4 = (undefined8 *)puVar6[2];
      puVar6 = puVar3;
    }
    else {
      puVar4 = (undefined8 *)*puVar6;
    }
    puVar3 = puVar6;
    puVar6 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x1d);
  }
  puVar6 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar6) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar5 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar5 = &local_38;
  }
  local_18 = *plVar5;
  lVar2 = *(longlong *)(param_1 + 0x38);
  local_10 = plVar5[1];
  if ((local_18 == 0) || (local_18 != *(longlong *)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  return local_10 != lVar2;
}

// ==== CMsgRoulette1ArgAction::helper_1404dcbe0  @1404dcbe0  [medium:callgraph-r2]  (orig: FUN_1404dcbe0)
undefined1 FUN_1404dcbe0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 local_res10 [6];
  undefined1 local_28 [32];
  
  local_res10[0] = param_2;
  cVar1 = FUN_1404dc910();
  if (cVar1 != '\0') {
    return 0;
  }
  FUN_14000d480(param_1 + 8,local_28,local_res10);
  return 1;
}

// ==== CMsgRoulette1ArgAction::helper_1404dd8a0  @1404dd8a0  [medium:callgraph-r3]  (orig: FUN_1404dd8a0)
undefined8 FUN_1404dd8a0(longlong param_1,undefined4 param_2,undefined1 param_3,undefined1 param_4)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 0xc) = 7;
  *(undefined4 *)(param_1 + 8) = 0xaf8;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 5) = param_4;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined1 *)(lVar1 + 6) = 0;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgRoulette1ArgAction::helper_1404dd8e0  @1404dd8e0  [medium:callgraph-r3]  (orig: FUN_1404dd8e0)
ulonglong FUN_1404dd8e0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined1 param_4,
                       undefined8 *param_5)

{
  char *pcVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong extraout_RAX_01;
  longlong lVar3;
  
  if (0x3ff < (longlong)*(int *)(param_1 + 0xc) + 0x19U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  if (param_5 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_01 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x19;
  *(undefined4 *)((ulonglong)*(byte *)(lVar2 + 6) * 0x19 + 7 + lVar2) = param_2;
  *(undefined4 *)
   ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 6) * 0x19 + 0xb +
   *(longlong *)(param_1 + 0x428)) = param_3;
  *(undefined1 *)
   ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 6) * 0x19 + 0xf +
   *(longlong *)(param_1 + 0x428)) = param_4;
  lVar2 = *(longlong *)(param_1 + 0x428);
  lVar3 = (ulonglong)*(byte *)(lVar2 + 6) * 0x19;
  *(undefined8 *)(lVar3 + 0x10 + lVar2) = *param_5;
  *(undefined8 *)(lVar3 + 0x18 + lVar2) = param_5[1];
  lVar2 = *(longlong *)(param_1 + 0x428);
  pcVar1 = (char *)(lVar2 + 6);
  *pcVar1 = *pcVar1 + '\x01';
  return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
}

// ==== CMsgRoulette1ArgAction::helper_1404ddc50  @1404ddc50  [medium:callgraph-r3]  (orig: FUN_1404ddc50)
undefined8 FUN_1404ddc50(longlong param_1)

{
  return CONCAT71((int7)((ulonglong)*(longlong *)(param_1 + 0x428) >> 8),
                  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1));
}

