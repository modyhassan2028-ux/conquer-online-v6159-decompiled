// ==== CMsgTrainingVitalityInfo::ctor_or_dtor  @140477070  [high:vtable-assign]  (orig: FUN_140477070)
undefined8 * FUN_140477070(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTrainingVitalityInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTrainingVitalityInfo::ctor_or_dtor  @1404770c0  [high:vtable-assign]  (orig: FUN_1404770c0)
void FUN_1404770c0(undefined8 *param_1)

{
  *param_1 = CMsgTrainingVitalityInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTrainingVitalityInfo::vfunc_1  @1404770f0  [high:rtti-vtable]  (orig: FUN_1404770f0)
bool FUN_1404770f0(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9e6;
    }
  }
  return false;
}

// ==== CMsgTrainingVitalityInfo::vfunc_3  @1404772b0  [high:rtti-vtable]  (orig: FUN_1404772b0)
void FUN_1404772b0(void)

{
  return;
}

// ==== CMsgTrainingVitalityInfo::ctor_or_dtor  @1404772c0  [high:vtable-assign]  (orig: FUN_1404772c0)
undefined8 * FUN_1404772c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTrainingVitalityInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

