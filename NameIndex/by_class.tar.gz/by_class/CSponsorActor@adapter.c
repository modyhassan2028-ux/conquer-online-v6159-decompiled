// ==== CSponsorActor@adapter::helper_140595120  @140595120  [medium:callgraph-r0]  (orig: FUN_140595120)
longlong FUN_140595120(void)

{
  longlong *plVar1;
  
  if ((DAT_140977470 & 1) == 0) {
    DAT_140977470 = DAT_140977470 | 1;
    plVar1 = (longlong *)CurrentInstanceGet();
    DAT_140977468 = (**(code **)(*plVar1 + 0x20))(plVar1,0x19);
  }
  if (DAT_140977468 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return DAT_140977468;
}

// ==== CSponsorActor@adapter::helper_1405951a0  @1405951a0  [medium:callgraph-r0]  (orig: FUN_1405951a0)
longlong FUN_1405951a0(void)

{
  longlong *plVar1;
  
  if ((DAT_140977480 & 1) == 0) {
    DAT_140977480 = DAT_140977480 | 1;
    plVar1 = (longlong *)CurrentInstanceGet();
    DAT_140977478 = (**(code **)(*plVar1 + 0x20))(plVar1,0x18);
  }
  if (DAT_140977478 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return DAT_140977478;
}

// ==== CSponsorActor@adapter::vfunc_1  @140595270  [high:rtti-vtable]  (orig: FUN_140595270)
void FUN_140595270(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CSponsorActor@adapter::vfunc_0  @140595290  [high:rtti-vtable]  (orig: FUN_140595290)
undefined8 FUN_140595290(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405952b0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x60))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CSponsorActor@adapter::vfunc_9  @1405952c0  [high:rtti-vtable]  (orig: FUN_1405952c0)
bool FUN_1405952c0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CSponsorActor@adapter::vfunc_1  @1405952e0  [high:rtti-vtable]  (orig: FUN_1405952e0)
undefined8 FUN_1405952e0(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014059530c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x178))(plVar1,param_3,1);
    return uVar2;
  }
  return 0;
}

// ==== CSponsorActor@adapter::vfunc_8  @140595320  [high:rtti-vtable]  (orig: FUN_140595320)
undefined8 FUN_140595320(undefined8 param_1,undefined4 param_2,undefined4 param_3,short param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (param_4 == 1) {
    plVar1 = (longlong *)FUN_1405951a0();
                    /* WARNING: Could not recover jumptable at 0x000140595385. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x80))(plVar1,param_2,param_3);
    return uVar2;
  }
  if (param_4 != 2) {
    return 0;
  }
  plVar1 = (longlong *)FUN_140595120();
                    /* WARNING: Could not recover jumptable at 0x000140595364. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x88))(plVar1,param_2,param_3);
  return uVar2;
}

// ==== CSponsorActor@adapter::vfunc_6  @140595390  [high:rtti-vtable]  (orig: FUN_140595390)
void FUN_140595390(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140595120();
                    /* WARNING: Could not recover jumptable at 0x0001405953b9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x70))(plVar1,param_2,param_3);
  return;
}

// ==== CSponsorActor@adapter::vfunc_5  @1405953c0  [high:rtti-vtable]  (orig: FUN_1405953c0)
void FUN_1405953c0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140595120();
                    /* WARNING: Could not recover jumptable at 0x0001405953e9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x78))(plVar1,param_2,param_3);
  return;
}

// ==== CSponsorActor@adapter::vfunc_7  @1405953f0  [high:rtti-vtable]  (orig: FUN_1405953f0)
undefined1
FUN_1405953f0(undefined8 param_1,undefined4 param_2,undefined4 param_3,short param_4,int param_5)

{
  undefined1 uVar1;
  tm *ptVar2;
  longlong *plVar3;
  __time32_t local_res20 [2];
  
  if (param_4 == 1) {
    plVar3 = (longlong *)FUN_1405951a0();
                    /* WARNING: Could not recover jumptable at 0x00014059549b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(*plVar3 + 0x78))(plVar3,param_2,param_3,param_5);
    return uVar1;
  }
  if (param_4 == 2) {
    local_res20[0] = 0;
    _time32(local_res20);
    ptVar2 = _localtime32(local_res20);
    if (ptVar2 != (tm *)0x0) {
      if ((ptVar2->tm_year * 100 + 0x2e631 + ptVar2->tm_mon) * 100 + ptVar2->tm_mday == param_5) {
        plVar3 = (longlong *)FUN_140595120();
        uVar1 = (**(code **)(*plVar3 + 0x68))(plVar3,param_2,param_3);
        return uVar1;
      }
    }
  }
  return 0;
}

// ==== CSponsorActor@adapter::vfunc_3  @1405954a0  [high:rtti-vtable]  (orig: FUN_1405954a0)
undefined8 FUN_1405954a0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405954c2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CSponsorActor@adapter::vfunc_4  @1405954d0  [high:rtti-vtable]  (orig: FUN_1405954d0)
void FUN_1405954d0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x0001405954ea. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x290))(plVar1,param_2);
  return;
}

// ==== CSponsorActor@adapter::vfunc_10  @140595500  [high:rtti-vtable]  (orig: FUN_140595500)
undefined8 FUN_140595500(undefined8 param_1,int param_2,int param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if ((param_2 != 0) && (param_3 < 4)) {
    plVar1 = (longlong *)FUN_140595120();
                    /* WARNING: Could not recover jumptable at 0x000140595532. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x80))(plVar1,param_2,param_3);
    return uVar2;
  }
  return 0;
}

// ==== CSponsorActor@adapter::vfunc_11  @140595550  [high:rtti-vtable]  (orig: FUN_140595550)
void FUN_140595550(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
                  undefined4 param_5)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1405951a0();
  (**(code **)(*plVar1 + 0x88))(plVar1,param_2,param_3,param_4,param_5);
  return;
}

// ==== CSponsorActor@adapter::vfunc_14  @1405955a0  [high:rtti-vtable]  (orig: FUN_1405955a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405955a0(longlong param_1,undefined4 param_2,longlong param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  if (param_3 != 0) {
    local_498 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      plVar5 = (longlong *)FUN_1400e1de0();
      local_4d0 = 0;
      local_4d8 = CONCAT44(local_4d8._4_4_,5);
      (**(code **)(*plVar5 + 8))(plVar5,"SYSTEM",param_2,param_3);
    }
    else {
      FUN_14015b240(local_488);
      plVar5 = (longlong *)(lVar3 + 0x10);
      uVar1 = (**(code **)(*plVar5 + 0x30))(plVar5);
      uVar4 = (**(code **)(*plVar5 + 0x18))(plVar5);
      local_4a8 = 1;
      local_4b0 = 0;
      local_4c0 = 0;
      local_4c8 = 0x7d1;
      local_4d0 = 0xffff00;
      local_4d8 = 0;
      local_4b8 = uVar1;
      iVar2 = FUN_14015b300(local_488,"SYSTEM",uVar4,param_3);
      if (iVar2 != 0) {
        (**(code **)(*plVar5 + 0x350))(plVar5,local_488);
      }
      FUN_14015b2c0(local_488);
    }
  }
  return;
}

// ==== CSponsorActor@adapter::vfunc_0  @1405956d0  [high:rtti-vtable]  (orig: FUN_1405956d0)
void FUN_1405956d0(longlong param_1)

{
  FUN_140595730(param_1 + -8);
  return;
}

// ==== CSponsorActor@adapter::helper_140595730  @140595730  [medium:callgraph-r0]  (orig: FUN_140595730)
undefined8 * FUN_140595730(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CSponsorActor::vftable;
  param_1[1] = adapter::CSponsorActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CSponsorActor@adapter::vfunc_2  @140595780  [high:rtti-vtable]  (orig: FUN_140595780)
byte FUN_140595780(longlong param_1,undefined8 param_2,longlong param_3)

{
  byte bVar1;
  byte bVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong lVar7;
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar3 != (longlong *)0x0) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar4 + 0xb0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar6 = *(undefined8 *)(lVar4 + 0xb0);
    lVar4 = (**(code **)(*plVar3 + 0x60))(plVar3);
    lVar5 = FUN_140006cc0(uVar6);
    if (lVar5 < lVar4 + param_3) {
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar6 = FUN_1400d6610(uVar6);
      lVar4 = FUN_140006cc0(uVar6);
      lVar5 = (**(code **)(*plVar3 + 0x60))(plVar3);
      bVar1 = FUN_140171280(plVar3,(param_3 - lVar4) + lVar5,0);
      lVar4 = *plVar3;
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar6 = FUN_1400d6610(uVar6);
      lVar5 = FUN_140006cc0(uVar6);
      lVar7 = (**(code **)(*plVar3 + 0x60))(plVar3);
      bVar2 = (**(code **)(lVar4 + 0x180))(plVar3,lVar5 - lVar7,1);
      bVar2 = bVar2 & bVar1;
    }
    else {
      bVar2 = (**(code **)(*plVar3 + 0x180))(plVar3,param_3,1);
    }
    return bVar2;
  }
  return 0;
}

// ==== CSponsorActor@adapter::vfunc_12  @1405958e0  [high:rtti-vtable]  (orig: FUN_1405958e0)
void FUN_1405958e0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140313fc0(lVar1,param_2,param_3,param_4);
  return;
}

// ==== CSponsorActor@adapter::vfunc_13  @140595960  [high:rtti-vtable]  (orig: FUN_140595960)
void FUN_140595960(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CSponsorActor@adapter::vfunc_16  @140595b60  [high:rtti-vtable]  (orig: FUN_140595b60)
void FUN_140595b60(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006cc0(*(undefined8 *)(lVar1 + 0xb0));
  return;
}

