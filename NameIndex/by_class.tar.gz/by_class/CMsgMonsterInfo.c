// ==== CMsgMonsterInfo::ctor_or_dtor  @14044f280  [high:vtable-assign]  (orig: FUN_14044f280)
undefined8 * FUN_14044f280(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMonsterInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMonsterInfo::ctor_or_dtor  @14044f2d0  [high:vtable-assign]  (orig: FUN_14044f2d0)
void FUN_14044f2d0(undefined8 *param_1)

{
  *param_1 = CMsgMonsterInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMonsterInfo::vfunc_1  @14044f440  [high:rtti-vtable]  (orig: FUN_14044f440)
undefined8 FUN_14044f440(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgMonsterInfo::ctor_or_dtor  @14044f470  [high:vtable-assign]  (orig: FUN_14044f470)
undefined8 * FUN_14044f470(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMonsterInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgMonsterInfo::vfunc_3  @14044f4c0  [high:rtti-vtable]  (orig: FUN_14044f4c0)
void FUN_14044f4c0(longlong param_1,longlong param_2)

{
  undefined4 *puVar1;
  longlong lVar2;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined2 local_34;
  undefined2 local_32;
  undefined2 local_30;
  undefined2 local_2e;
  undefined1 local_2c;
  undefined4 local_28;
  undefined1 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_c;
  
  if (param_2 != 0) {
    memset(&local_48,0,0x40);
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    local_48 = *puVar1;
    local_30 = *(undefined2 *)(puVar1 + 6);
    local_2e = *(undefined2 *)((longlong)puVar1 + 0x1a);
    local_44 = puVar1[1];
    local_34 = *(undefined2 *)(puVar1 + 5);
    local_32 = *(undefined2 *)((longlong)puVar1 + 0x16);
    local_40 = puVar1[2];
    local_3c = puVar1[3];
    local_2c = *(undefined1 *)(puVar1 + 7);
    local_38 = puVar1[4];
    local_28 = puVar1[8];
    local_20 = puVar1[9];
    local_1c = puVar1[10];
    local_24 = *(undefined1 *)(puVar1 + 0xb);
    local_c = puVar1[0xd];
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar2 + 0xa0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    (**(code **)(**(longlong **)(lVar2 + 0xa0) + 0x18))(*(longlong **)(lVar2 + 0xa0),&local_48);
  }
  return;
}

