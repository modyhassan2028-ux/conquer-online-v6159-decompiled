// ==== CChangeServerSocketThread::vfunc_2  @14002eff0  [high:rtti-vtable]  (orig: FUN_14002eff0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14002eff0(longlong param_1)

{
  char cVar1;
  uint uVar2;
  longlong lVar3;
  char *pcVar4;
  undefined1 auStack_858 [32];
  char *local_838;
  undefined8 local_828;
  CIniFile local_818 [1024];
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_828 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_858;
  CIniFile::CIniFile(local_818,"shell.ini","AccountServer");
  CIniFile::GetString(local_818,(char *)(param_1 + 0x5c),"SERVERNAME",0x10);
  local_418[0] = '\0';
  memset(local_418 + 1,0,0x3ff);
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x40) + 8))();
  _snprintf(local_418,0x3ff,"#%u: CChangeServerSocketThread running.",(ulonglong)uVar2);
  local_19 = 0;
  lVar3 = -1;
  pcVar4 = local_418;
  do {
    if (lVar3 == 0) break;
    lVar3 = lVar3 + -1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  local_838 = local_418;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
            (*(longlong **)(param_1 + 0x40),0,0x9c41,~(uint)lVar3);
  CIniFile::~CIniFile(local_818);
  return;
}

// ==== CChangeServerSocketThread::helper_14002f100  @14002f100  [medium:callgraph-r2]  (orig: FUN_14002f100)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14002f100(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined1 auStack_c8 [32];
  undefined4 *local_a8;
  undefined8 local_a0;
  undefined4 local_98;
  undefined8 *local_90;
  undefined8 local_88;
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined8 local_6c;
  undefined8 local_64;
  undefined8 local_5c;
  undefined8 local_54;
  undefined8 local_4c;
  undefined8 local_44;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_24;
  ulonglong local_18;
  
  local_88 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_c8;
  local_78 = *(undefined4 *)(param_2 + 4);
  local_74 = *(undefined4 *)(param_2 + 8);
  local_70 = *(undefined4 *)(param_2 + 0xc);
  uVar1 = *(undefined4 *)(param_2 + 0x40);
  local_38 = *(undefined4 *)(param_2 + 0x44);
  local_34 = *(undefined4 *)(param_2 + 0x48);
  local_6c = *(undefined8 *)(param_2 + 0x10);
  local_64 = *(undefined8 *)(param_2 + 0x18);
  local_5c = *(undefined8 *)(param_2 + 0x20);
  local_54 = *(undefined8 *)(param_2 + 0x28);
  local_4c = *(undefined8 *)(param_2 + 0x30);
  local_44 = *(undefined8 *)(param_2 + 0x38);
  local_a8 = &local_78;
  local_3c = uVar1;
  local_24 = uVar1;
  cVar2 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
                    (*(longlong **)(param_1 + 0x40),0xe,0x273f,0x48);
  if (cVar2 == '\0') {
    local_a0 = Ordinal_12(uVar1);
    local_90 = &local_5c;
    local_98 = local_38;
    local_a8 = (undefined4 *)CONCAT44(local_a8._4_4_,local_70);
    tq::MyLogSave("gmlog/ChangeServer",
                  "receive change server message and send to msgport failure, action:%u, iduser:%u, idacount:%u, ip:%s Result[%d] InServer[%s]"
                 );
  }
  else {
    local_a0 = Ordinal_12(uVar1);
    local_90 = &local_5c;
    local_98 = local_38;
    local_a8 = (undefined4 *)CONCAT44(local_a8._4_4_,local_70);
    tq::MyLogSave("gmlog/ChangeServer",
                  "receive change server message and send to msgport succeed, action:%u, iduser:%u, idacount:%u, ip:%s Result[%d] InServer[%s]"
                 );
  }
  return;
}

// ==== CChangeServerSocketThread::helper_14002f260  @14002f260  [medium:callgraph-r2]  (orig: FUN_14002f260)
void FUN_14002f260(longlong param_1,longlong param_2)

{
  int iVar1;
  undefined4 local_res18;
  undefined4 local_res1c;
  undefined4 local_res20;
  undefined4 local_res24;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined8 local_18;
  
  local_18 = 0xfffffffffffffffe;
  iVar1 = *(int *)(param_2 + 4);
  if (iVar1 == 0) {
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5c88);
  }
  else if (iVar1 == 1) {
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5c68);
  }
  else if (iVar1 == 2) {
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5c48);
  }
  else if (iVar1 == 3) {
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5c28);
  }
  else if (iVar1 == 4) {
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5c10);
  }
  else if (iVar1 == 6) {
    local_res18 = 0;
    local_res1c = 1;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0xe,0x2740,8,&local_res18);
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5c00);
  }
  else if (iVar1 == 5) {
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5be8);
  }
  else if (iVar1 == 7) {
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5bd0);
    local_res20 = 1;
    local_res24 = 1;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0xe,0x2740,8,&local_res20);
  }
  else if (iVar1 == 8) {
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5bb0);
    local_28 = 2;
    local_24 = *(undefined4 *)(param_2 + 0x18);
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0xe,0x2740,8,&local_28);
  }
  else if (iVar1 == 9) {
    tq::MyLogSave("gmlog/ChangeServer",&DAT_1406e5b90);
    local_20 = 3;
    local_1c = *(undefined4 *)(param_2 + 0x18);
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0xe,0x2740,8,&local_20);
  }
  return;
}

// ==== CChangeServerSocketThread::helper_14002f480  @14002f480  [medium:callgraph-r1]  (orig: FUN_14002f480)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14002f480(longlong param_1,void *param_2,int param_3)

{
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined1 local_444 [1052];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  memset((void *)((longlong)&local_448 + 1),0,0x417);
  local_448 = param_3;
  memcpy(local_444,param_2,(longlong)param_3);
  local_458 = &local_448;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
            (*(longlong **)(param_1 + 0x40),1,0x7571,0x418);
  return;
}

// ==== CChangeServerSocketThread::helper_14002f510  @14002f510  [medium:callgraph-r1]  (orig: FUN_14002f510)
void FUN_14002f510(undefined8 param_1,longlong param_2)

{
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (*(short *)(param_2 + 2) == 2) {
    FUN_14002f100();
    return;
  }
  if (*(short *)(param_2 + 2) == 1) {
    FUN_14002f260();
  }
  return;
}

// ==== CChangeServerSocketThread::helper_14002f6f0  @14002f6f0  [medium:callgraph-r3]  (orig: FUN_14002f6f0)
void FUN_14002f6f0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x65) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CChangeServerSocketThread::helper_14002f810  @14002f810  [medium:callgraph-r3]  (orig: FUN_14002f810)
void FUN_14002f810(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x65) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x65) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x65);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x65);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x65);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x65);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014002f834. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CChangeServerSocketThread::helper_14002fa70  @14002fa70  [medium:callgraph-r1]  (orig: FUN_14002fa70)
void FUN_14002fa70(longlong param_1,char param_2)

{
  undefined4 local_res8;
  undefined4 local_resc;
  
  if ((*(char *)(param_1 + 0x48) != param_2) || (*(char *)(param_1 + 0x49) == '\0')) {
    *(char *)(param_1 + 0x48) = param_2;
    if (param_2 != '\0') {
      tq::MyLogSave("gmlog/ChangeServer","Connect to change server OK.");
      FUN_14002f480(param_1,param_1 + 0x54,*(undefined2 *)(param_1 + 0x54));
      *(undefined1 *)(param_1 + 0x49) = 1;
      return;
    }
    tq::MyLogSave("gmlog/ChangeServer","Change server connection broken.");
    local_res8 = 0;
    local_resc = 0;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0xe,0x2740,8,&local_res8);
    *(undefined1 *)(param_1 + 0x49) = 1;
  }
  return;
}

// ==== CChangeServerSocketThread::helper_14002fb10  @14002fb10  [medium:callgraph-r3]  (orig: FUN_14002fb10)
void FUN_14002fb10(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x65) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CChangeServerSocketThread::vfunc_4  @14002fd20  [high:rtti-vtable]  (orig: FUN_14002fd20)
bool FUN_14002fd20(CThreadBase *param_1,bool param_2)

{
  bool bVar1;
  ulong uVar2;
  
  bVar1 = CThreadBase::CreateThread(param_1,"ChangeServerThread",param_2);
  if (!bVar1) {
    return bVar1;
  }
  *(undefined4 *)(param_1 + 0x4c) = 0x14;
  uVar2 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x50) = uVar2 / 1000;
  return true;
}

// ==== CChangeServerSocketThread::vfunc_1  @14002fd70  [high:rtti-vtable]  (orig: FUN_14002fd70)
void FUN_14002fd70(longlong param_1)

{
  undefined4 local_res8;
  undefined4 local_resc;
  
  if ((*(char *)(param_1 + 0x48) != '\0') || (*(char *)(param_1 + 0x49) == '\0')) {
    *(undefined1 *)(param_1 + 0x48) = 0;
    tq::MyLogSave("gmlog/ChangeServer","Change server connection broken.");
    local_res8 = 0;
    local_resc = 0;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0xe,0x2740,8,&local_res8);
    *(undefined1 *)(param_1 + 0x49) = 1;
  }
                    /* WARNING: Could not recover jumptable at 0x00014002fddc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
  return;
}

// ==== CChangeServerSocketThread::helper_14002fde0  @14002fde0  [medium:callgraph-r0]  (orig: FUN_14002fde0)
void FUN_14002fde0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  ulong uVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  if (*(char *)(param_1 + 0x48) != '\0') {
    uVar1 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0x50) + *(int *)(param_1 + 0x4c)) <= uVar1 / 1000) {
      uVar1 = tq::TimeGet(0);
      *(uint *)(param_1 + 0x50) = uVar1 / 1000;
      FUN_14002f480(param_1,(undefined2 *)(param_1 + 0x54),*(undefined2 *)(param_1 + 0x54),param_4,
                    uVar2);
    }
  }
  return;
}

// ==== CChangeServerSocketThread::helper_14002feb0  @14002feb0  [medium:callgraph-r1]  (orig: FUN_14002feb0)
void FUN_14002feb0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x65);
  while (cVar1 == '\0') {
    FUN_14002feb0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x65);
  }
  return;
}

// ==== CChangeServerSocketThread::helper_14002fff0  @14002fff0  [medium:callgraph-r1]  (orig: FUN_14002fff0)
void FUN_14002fff0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x68);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 100) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x65) = 0;
  return;
}

// ==== CChangeServerSocketThread::helper_140030090  @140030090  [medium:callgraph-r0]  (orig: FUN_140030090)
void FUN_140030090(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x65);
  while (cVar1 == '\0') {
    FUN_14002feb0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x65);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CChangeServerSocketThread::helper_1400302f0  @1400302f0  [medium:callgraph-r3]  (orig: FUN_1400302f0)
undefined8 *
FUN_1400302f0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x35e50d79435e50b < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14002ff20(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 100);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 100) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 100) = 1;
        *(undefined1 *)(lVar4 + 100) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 100) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x65) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 100) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 100) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x65) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 100) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 100) = 1;
        *(undefined1 *)(lVar4 + 100) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 100) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x65) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 100) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 100) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x65) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 100);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 100) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CChangeServerSocketThread::helper_140030680  @140030680  [medium:callgraph-r2]  (orig: FUN_140030680)
longlong * FUN_140030680(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x65) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x65) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1400307dd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14003080c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x65) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x65) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x65);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x65);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x65);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x65);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x65) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x65) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1400307dd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1400302f0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14003080c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CChangeServerSocketThread::helper_140030830  @140030830  [medium:callgraph-r2]  (orig: FUN_140030830)
undefined8 * FUN_140030830(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x65) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14002f810(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x65) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x65) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x65) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 100);
        puVar2 = (undefined1 *)((longlong)plVar10 + 100);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_140030a1c;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x65) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x65) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x65);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x65);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x65) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x65);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x65);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_140030a1c:
  if (*(char *)((longlong)plVar5 + 100) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 100) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 100) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 100) = 1;
            *(undefined1 *)((longlong)plVar10 + 100) = 0;
            FUN_14002fb10(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x65) == '\0') {
            if ((*(char *)(*plVar11 + 100) != '\x01') || (*(char *)(plVar11[2] + 100) != '\x01')) {
              if (*(char *)(plVar11[2] + 100) == '\x01') {
                *(undefined1 *)(*plVar11 + 100) = 1;
                *(undefined1 *)((longlong)plVar11 + 100) = 0;
                FUN_14002f6f0(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 100) = *(undefined1 *)((longlong)plVar10 + 100);
              *(undefined1 *)((longlong)plVar10 + 100) = 1;
              *(undefined1 *)(plVar11[2] + 100) = 1;
              FUN_14002fb10(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 100) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 100) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 100) = 1;
            *(undefined1 *)((longlong)plVar10 + 100) = 0;
            FUN_14002f6f0(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x65) == '\0') {
            if ((*(char *)(plVar11[2] + 100) != '\x01') || (*(char *)(*plVar11 + 100) != '\x01')) {
              if (*(char *)(*plVar11 + 100) == '\x01') {
                *(undefined1 *)(plVar11[2] + 100) = 1;
                *(undefined1 *)((longlong)plVar11 + 100) = 0;
                FUN_14002fb10(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 100) = *(undefined1 *)((longlong)plVar10 + 100);
              *(undefined1 *)((longlong)plVar10 + 100) = 1;
              *(undefined1 *)(*plVar11 + 100) = 1;
              FUN_14002f6f0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 100) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 100) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CChangeServerSocketThread::helper_140030bf0  @140030bf0  [medium:callgraph-r2]  (orig: FUN_140030bf0)
longlong * FUN_140030bf0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x65) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x65) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CChangeServerSocketThread::helper_140030ce0  @140030ce0  [medium:callgraph-r1]  (orig: FUN_140030ce0)
longlong * FUN_140030ce0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140030090(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x65) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x65) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x65);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x65);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x65);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x65);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140030830(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CChangeServerSocketThread::helper_140030ee0  @140030ee0  [medium:callgraph-r1]  (orig: FUN_140030ee0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140030ee0(longlong param_1,void *param_2)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong lVar5;
  undefined1 auStack_108 [32];
  undefined4 local_e8;
  undefined8 local_e0;
  undefined4 local_d8;
  longlong local_d0;
  longlong *local_c8;
  longlong lStack_c0;
  longlong *local_b8;
  undefined8 local_a8;
  undefined4 local_a0;
  undefined1 local_9c [76];
  undefined1 local_50 [4];
  undefined4 local_4c;
  ulonglong local_38;
  
  local_a8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_108;
  if (param_2 == (void *)0x0) {
    log_InlineLogERROR(
                      "CChangeServerSocketThread::OnRecUserChangeServerInfo. NULL == pMsgChangeServerClient"
                      );
    uVar3 = 0;
  }
  else if (*(int *)((longlong)param_2 + 4) == 0) {
    log_InlineLogERROR(
                      "CChangeServerSocketThread::OnRecUserChangeServerInfo. ID_NONE == pMsgChangeServerClient->idUser"
                      );
    uVar3 = 0;
  }
  else {
    plVar1 = (longlong *)(param_1 + 0x70);
    FUN_140030bf0(plVar1,&local_c8,(longlong)param_2 + 4);
    lVar5 = *(longlong *)(param_1 + 0xa0);
    lVar4 = 0;
    local_b8 = (longlong *)*plVar1;
    if ((local_b8 == (longlong *)0x0) || (local_b8 != local_c8)) {
      _invalid_parameter_noinfo();
    }
    if (lVar5 != lStack_c0) {
      if (local_c8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = lVar4;
      }
      else {
        lVar5 = *local_c8;
      }
      if (lStack_c0 == *(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar2 = *(undefined4 *)(lStack_c0 + 0x58);
      local_4c = uVar2;
      if (local_c8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = lVar4;
      }
      else {
        lVar5 = *local_c8;
      }
      if (lStack_c0 == *(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (local_c8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = lVar4;
      }
      else {
        lVar5 = *local_c8;
      }
      if (lStack_c0 == *(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (local_c8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = lVar4;
      }
      else {
        lVar5 = *local_c8;
      }
      if (lStack_c0 == *(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (local_c8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = lVar4;
      }
      else {
        lVar5 = *local_c8;
      }
      if (lStack_c0 == *(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (local_c8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar4 = *local_c8;
      }
      if (lStack_c0 == *(longlong *)(lVar4 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      local_e0 = Ordinal_12(uVar2);
      local_d8 = *(undefined4 *)(lStack_c0 + 0x5c);
      local_e8 = *(undefined4 *)(lStack_c0 + 0x24);
      local_d0 = lStack_c0 + 0x38;
      tq::MyLogSave("gmlog/ChangeServer",
                    "exist User Change Server Info,action:%u, iduser:%u, idacount:%u, ip:%s Result[%d] InServer[%s]"
                   );
      FUN_140030830(plVar1,local_50,&local_c8);
    }
    local_a0 = *(undefined4 *)((longlong)param_2 + 4);
    memcpy(local_9c,param_2,0x48);
    FUN_140030680(plVar1,local_50,&local_a0);
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CChangeServerSocketThread::helper_140031130  @140031130  [medium:callgraph-r1]  (orig: FUN_140031130)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140031130(longlong param_1,longlong param_2)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined1 auStack_1a8 [32];
  undefined4 local_188;
  undefined8 local_180;
  undefined4 local_178;
  undefined1 *local_170;
  longlong *local_168;
  longlong lStack_160;
  longlong *local_158 [2];
  undefined8 local_148;
  undefined2 local_138;
  undefined2 local_136;
  undefined4 local_134;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_f8;
  undefined4 local_f4;
  undefined4 local_f0;
  undefined1 local_e8 [4];
  undefined4 local_e4;
  undefined4 local_e0;
  undefined1 local_cc [32];
  undefined4 local_ac;
  undefined4 local_a8;
  undefined2 local_98;
  undefined2 local_96;
  undefined4 local_94;
  undefined4 local_90;
  undefined4 local_8c;
  undefined8 local_88;
  undefined8 local_80;
  undefined8 local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined8 local_60;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_44;
  ulonglong local_38;
  
  local_148 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_1a8;
  if (param_2 == 0) {
    log_InlineLogERROR(
                      "CChangeServerSocketThread::OnRecUserFinishLogout. NULL == pMsgChangeServerClient"
                      );
    uVar2 = 0;
  }
  else if (*(int *)(param_2 + 4) == 0) {
    log_InlineLogERROR(
                      "CChangeServerSocketThread::OnRecUserFinishLogout. ID_NONE == pMsgChangeServerClient->idUser"
                      );
    uVar2 = 0;
  }
  else {
    FUN_140030bf0(param_1 + 0x70,&local_168,param_2 + 4);
    lVar3 = *(longlong *)(param_1 + 0xa0);
    local_158[0] = *(longlong **)(param_1 + 0x70);
    if ((local_158[0] == (longlong *)0x0) || (local_158[0] != local_168)) {
      _invalid_parameter_noinfo();
    }
    if (lVar3 == lStack_160) {
      log_InlineLogERROR(
                        "CChangeServerSocketThread::OnRecUserFinishLogout. idUser[%u] not found change server info"
                        );
      local_98 = 0x4c;
      local_96 = 2;
      local_58 = 0;
      local_54 = 0;
      local_50 = 0;
      local_88 = 0;
      local_80 = 0;
      local_78 = 0;
      local_70 = 0;
      local_68 = 0;
      local_60 = 0;
      local_94 = 3;
      local_90 = *(undefined4 *)(param_2 + 4);
      local_8c = *(undefined4 *)(param_2 + 8);
      FUN_14002f100(param_1,&local_98);
      uVar2 = 0;
    }
    else {
      if (local_168 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar3 = 0;
      }
      else {
        lVar3 = *local_168;
      }
      if (lStack_160 == *(longlong *)(lVar3 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      memcpy(local_e8,(void *)(lStack_160 + 0x1c),0x48);
      FUN_140030830(param_1 + 0x70,local_158,&local_168);
      local_138 = 0x4c;
      local_136 = 2;
      local_f0 = 0;
      local_134 = 1;
      local_130 = local_e4;
      local_12c = local_e0;
      local_f8 = local_ac;
      local_f4 = local_a8;
      local_44 = local_ac;
      cVar1 = FUN_14002f480(param_1,&local_138);
      if (cVar1 == '\0') {
        local_180 = Ordinal_12(local_ac);
        local_170 = local_cc;
        local_178 = local_a8;
        local_188 = local_e0;
        tq::MyLogSave("gmlog/ChangeServer",
                      "send client message to change server failure, action:%u, iduser:%u, idacount:%u, ip:%s Result[%d] InServer[%s]"
                     );
        local_134 = 3;
        FUN_14002f100(param_1,&local_138);
        uVar2 = 0;
      }
      else {
        local_180 = Ordinal_12(local_ac);
        local_170 = local_cc;
        local_178 = local_a8;
        local_188 = local_e0;
        tq::MyLogSave("gmlog/ChangeServer",
                      "send client message to change server succeed,action:%u, iduser:%u, idacount:%u, ip:%s Result[%d] InServer[%s]"
                     );
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

// ==== CChangeServerSocketThread::helper_140031500  @140031500  [medium:callgraph-r0]  (orig: FUN_140031500)
void FUN_140031500(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140030ce0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CChangeServerSocketThread::helper_1400315c0  @1400315c0  [medium:callgraph-r0]  (orig: FUN_1400315c0)
undefined8 FUN_1400315c0(undefined8 param_1,int param_2,int *param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  if (param_3 == (int *)0x0) {
    log_InlineLogERROR("CChangeServerSocketThread::ProcessMsg. buf is NULL");
    uVar1 = 0;
  }
  else {
    if (param_2 == 0x11174) {
      FUN_14002f510(param_1,param_3 + 1,param_3,param_4,0xfffffffffffffffe);
    }
    else if (param_2 == 0x16761) {
      if (*param_3 == 1) {
        FUN_140030ee0(param_1,param_3);
      }
      else if (*param_3 == 2) {
        FUN_140031130(param_1,param_3);
      }
      else {
        log_InlineLogERROR("CChangeServerSocketThread::ProcessMsg. Case[%d] not found");
      }
    }
    else if (param_2 == 0x16763) {
      FUN_14002fa70(param_1,*param_3 == 1);
    }
    else {
      log_InlineLogERROR("CChangeServerSocketThread::ProcessMsg. idPacket[%u] is Error");
    }
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CChangeServerSocketThread::ctor_or_dtor  @140031740  [high:vtable-assign]  (orig: FUN_140031740)
void FUN_140031740(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CChangeServerSocketThread::vftable;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
  FUN_140031500(param_1 + 0x70);
  operator_delete(*(void **)(param_1 + 0x70));
                    /* WARNING: Could not recover jumptable at 0x000140031798. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CChangeServerSocketThread::vfunc_3  @1400317a0  [high:rtti-vtable]  (orig: FUN_1400317a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400317a0(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  int iVar3;
  undefined1 auStack_498 [32];
  undefined1 *local_478;
  undefined4 *local_470;
  char local_468;
  ulong local_464;
  undefined4 local_460;
  undefined4 local_45c;
  undefined4 local_458;
  longlong local_450;
  undefined8 local_448;
  undefined1 local_438 [1056];
  ulonglong local_18;
  
  local_448 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  local_450 = param_1;
  if ((DAT_140975a98 & 1) == 0) {
    DAT_140975a98 = DAT_140975a98 | 1;
    DAT_140975a94 = tq::TimeGet(0);
  }
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x58))
                    (*(longlong **)(param_1 + 0x40),DAT_140949a18);
  uVar2 = tq::TimeGet(0);
  local_464 = uVar2;
  if (cVar1 == '\0') {
    FUN_14002fde0(param_1,uVar2);
    if (uVar2 - DAT_140975a94 < 0x2711) {
      DAT_140975a94 = DAT_140975a94 + 2000;
    }
    else {
      log_InlineLogWARNING("resync CChangeServerSocketThread::OnTimer cumulative deviation %dms");
      DAT_140975a94 = uVar2;
    }
  }
  else {
    while( true ) {
      local_470 = &local_460;
      local_478 = local_438;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x48))
                        (*(longlong **)(param_1 + 0x40),0xffffffff,0xffffffff,0x418);
      if (cVar1 == '\0') break;
      local_468 = 1;
      local_478 = (undefined1 *)CONCAT44(local_478._4_4_,local_460);
      local_468 = FUN_1400315c0(param_1,local_45c,local_438,local_458);
      if (local_468 == '\0') {
        log_InlineLogERROR(
                          "CChangeServerSocketThread::OnProcess ProcessMsg returned error with packet:%d, port:%d"
                          );
      }
    }
  }
  uVar2 = tq::TimeGet(0);
  iVar3 = uVar2 - DAT_140975a94;
  if (iVar3 < 2000) {
    DAT_140949a18 = 2000 - iVar3;
  }
  else {
    DAT_140949a18 = 0;
  }
  return CONCAT71((uint7)(uint3)((uint)iVar3 >> 8),1);
}

// ==== CChangeServerSocketThread::helper_140031940  @140031940  [medium:callgraph-r0]  (orig: FUN_140031940)
undefined8 * FUN_140031940(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14002fff0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x65) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CChangeServerSocketThread::ctor_or_dtor  @1400319c0  [high:vtable-assign]  (orig: FUN_1400319c0)
CThreadBase * FUN_1400319c0(CThreadBase *param_1,undefined8 param_2)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CChangeServerSocketThread::vftable;
  *(undefined8 *)(param_1 + 0x40) = param_2;
  param_1[0x48] = (CThreadBase)0x0;
  param_1[0x49] = (CThreadBase)0x0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined2 *)(param_1 + 0x54) = 0x1c;
  *(undefined2 *)(param_1 + 0x56) = 1;
  *(undefined4 *)(param_1 + 0x58) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined8 *)(param_1 + 0x5c) = 0;
  *(undefined8 *)(param_1 + 100) = 0;
  FUN_140031940(param_1 + 0x70);
  if (*(longlong *)(param_1 + 0x40) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pMsgPort",
                       "f:\\version\\cqserver-78.0.11-1204\\changeserversocket\\changeserversocketthread.cpp"
                       ,0x17);
  }
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x38))();
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x40))(*(longlong **)(param_1 + 0x40),1);
  FUN_140030090(param_1 + 0x70);
  return param_1;
}

// ==== CChangeServerSocketThread::ctor_or_dtor  @140031aa0  [high:vtable-assign]  (orig: FUN_140031aa0)
CThreadBase * FUN_140031aa0(CThreadBase *param_1,uint param_2)

{
  *(undefined ***)param_1 = CChangeServerSocketThread::vftable;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
  FUN_140031500(param_1 + 0x70);
  operator_delete(*(void **)(param_1 + 0x70));
  CThreadBase::~CThreadBase(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

