// ==== CNpcLink::helper_14039e380  @14039e380  [medium:callgraph-r0]  (orig: FUN_14039e380)
void FUN_14039e380(void *param_1)

{
  if ((DAT_1409761d0 & 1) == 0) {
    DAT_1409761d0 = DAT_1409761d0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761c8,"CNpcLink");
    atexit((_func_5014 *)&LAB_1406d6ba0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014039e3d5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409761c8,param_1);
  return;
}

// ==== CNpcLink::ctor_or_dtor  @14039e440  [high:vtable-assign]  (orig: FUN_14039e440)
undefined8 * FUN_14039e440(undefined8 *param_1,byte param_2)

{
  *param_1 = CNpcLink::vftable;
  if ((param_2 & 1) != 0) {
    FUN_14039e380();
  }
  return param_1;
}

// ==== CNpcLink::ctor_or_dtor  @14039e470  [high:vtable-assign]  (orig: FUN_14039e470)
undefined8 * FUN_14039e470(undefined4 param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  
  if ((DAT_1409761d0 & 1) == 0) {
    DAT_1409761d0 = DAT_1409761d0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761c8,"CNpcLink");
    atexit((_func_5014 *)&LAB_1406d6ba0);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_1409761c8,0x20);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CNpcLink::vftable;
    puVar1[2] = 0;
    puVar1[3] = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",&DAT_140760370,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npclink.cpp",
                       0x21);
    puVar1 = (undefined8 *)0x0;
  }
  else {
    puVar1[2] = param_2;
    *(undefined4 *)(puVar1 + 1) = param_1;
    puVar1[3] = 0;
  }
  return puVar1;
}

