// ==== CUserLoginThread::ctor_or_dtor  @14002e3d0  [high:vtable-assign]  (orig: FUN_14002e3d0)
CThreadBase * FUN_14002e3d0(CThreadBase *param_1,undefined8 param_2)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CUserLoginThread::vftable;
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = param_2;
  return param_1;
}

// ==== CUserLoginThread::ctor_or_dtor  @14002e420  [high:vtable-assign]  (orig: FUN_14002e420)
void FUN_14002e420(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CUserLoginThread::vftable;
                    /* WARNING: Could not recover jumptable at 0x00014002e440. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CUserLoginThread::vfunc_1  @14002e4b0  [high:rtti-vtable]  (orig: FUN_14002e4b0)
void FUN_14002e4b0(longlong param_1)

{
  if (*(longlong **)(param_1 + 0x40) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x20))();
  }
  *(undefined8 *)(param_1 + 0x40) = 0;
  return;
}

// ==== CUserLoginThread::vfunc_2  @14002e4e0  [high:rtti-vtable]  (orig: FUN_14002e4e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14002e4e0(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  (**(code **)(**(longlong **)(param_1 + 0x48) + 8))();
  _snprintf(local_418,0x400,"#%u: user login thread is up and running");
  lVar2 = -1;
  local_19 = 0;
  pcVar3 = local_418;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  local_428 = local_418;
  (**(code **)(**(longlong **)(param_1 + 0x48) + 0x50))
            (*(longlong **)(param_1 + 0x48),0,0x9c41,~(uint)lVar2);
  return;
}

// ==== CUserLoginThread::vfunc_3  @14002e580  [high:rtti-vtable]  (orig: FUN_14002e580)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14002e580(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  undefined1 auStack_4c8 [32];
  undefined1 *local_4a8;
  undefined4 *local_4a0;
  char local_498;
  ulong local_494;
  undefined4 local_490;
  uint local_48c;
  undefined4 local_488;
  longlong local_480;
  CTickAnalyst local_478 [24];
  undefined8 local_460;
  CTickAnalyst local_458 [32];
  undefined1 local_438 [1056];
  ulonglong local_18;
  
  local_460 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_480 = param_1;
  if ((DAT_140975a88 & 1) == 0) {
    DAT_140975a88 = DAT_140975a88 | 1;
    DAT_140975a84 = tq::TimeGet(0);
  }
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x58))
                    (*(longlong **)(param_1 + 0x48),DAT_1409499a8);
  CTickAnalyst::CTickAnalyst(local_458,0x20);
  uVar2 = tq::TimeGet(0);
  local_494 = uVar2;
  if (cVar1 == '\0') {
    CTickAnalyst::CTickAnalyst(local_478,0x22);
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x18))(*(longlong **)(param_1 + 0x40),uVar2);
    CTickAnalyst::~CTickAnalyst(local_478);
    if (uVar2 - DAT_140975a84 < 0x2711) {
      DAT_140975a84 = DAT_140975a84 + 2000;
    }
    else {
      log_InlineLogWARNING("resync CUserKernel::OnTimer cumulative deviation %dms");
      DAT_140975a84 = uVar2;
    }
  }
  else {
    while( true ) {
      local_4a0 = &local_490;
      local_4a8 = local_438;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x48))
                        (*(longlong **)(param_1 + 0x48),0xffffffff,0xffffffff,0x418);
      if (cVar1 == '\0') break;
      local_498 = 1;
      CTickAnalyst::CTickAnalyst(local_478,0x21);
      local_4a8 = (undefined1 *)CONCAT44(local_4a8._4_4_,local_490);
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x10))
                        (*(longlong **)(param_1 + 0x40),local_48c,local_438,local_488);
      local_498 = cVar1;
      CTickAnalyst::~CTickAnalyst(local_478);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CUserLoginThread::OnProcess ProcessMsg returned error with packet:%d, port:%d"
                           ,(ulonglong)local_48c);
      }
    }
  }
  uVar2 = tq::TimeGet(0);
  if ((int)(uVar2 - DAT_140975a84) < 2000) {
    DAT_1409499a8 = 2000 - (uVar2 - DAT_140975a84);
  }
  else {
    DAT_1409499a8 = 0;
  }
  CTickAnalyst::~CTickAnalyst(local_458);
  return 1;
}

// ==== CUserLoginThread::ctor_or_dtor  @14002e790  [high:vtable-assign]  (orig: FUN_14002e790)
CThreadBase * FUN_14002e790(CThreadBase *param_1,uint param_2)

{
  *(undefined ***)param_1 = CUserLoginThread::vftable;
  CThreadBase::~CThreadBase(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

