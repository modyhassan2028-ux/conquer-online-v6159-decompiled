// ==== CLuaScriptMgr::helper_140013e90  @140013e90  [medium:callgraph-r2]  (orig: FUN_140013e90)
void FUN_140013e90(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x41) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x41) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x41);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x41);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x41);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x41);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140013eb4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CLuaScriptMgr::helper_140014c50  @140014c50  [medium:callgraph-r2]  (orig: FUN_140014c50)
void FUN_140014c50(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x41) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CLuaScriptMgr::helper_140014cb0  @140014cb0  [medium:callgraph-r2]  (orig: FUN_140014cb0)
void FUN_140014cb0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x41) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CLuaScriptMgr::helper_140017010  @140017010  [medium:callgraph-r1]  (orig: FUN_140017010)
undefined8 * FUN_140017010(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x41) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140013e90(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x41) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x41) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x41) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 8;
        plVar8 = plVar8 + 8;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1400171fc;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x41) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x41) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x41);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x41);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x41) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x41);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x41);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1400171fc:
  if ((char)plVar2[8] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[8] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[8] == '\0') {
            *(undefined1 *)(plVar9 + 8) = 1;
            *(undefined1 *)(plVar8 + 8) = 0;
            FUN_140014c50(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x41) == '\0') {
            if ((*(char *)(*plVar9 + 0x40) != '\x01') || (*(char *)(plVar9[2] + 0x40) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x40) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x40) = 1;
                *(undefined1 *)(plVar9 + 8) = 0;
                FUN_140014cb0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 8) = (char)plVar8[8];
              *(undefined1 *)(plVar8 + 8) = 1;
              *(undefined1 *)(plVar9[2] + 0x40) = 1;
              FUN_140014c50(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 8) = 0;
          }
        }
        else {
          if ((char)plVar9[8] == '\0') {
            *(undefined1 *)(plVar9 + 8) = 1;
            *(undefined1 *)(plVar8 + 8) = 0;
            FUN_140014cb0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x41) == '\0') {
            if ((*(char *)(plVar9[2] + 0x40) != '\x01') || (*(char *)(*plVar9 + 0x40) != '\x01')) {
              if (*(char *)(*plVar9 + 0x40) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x40) = 1;
                *(undefined1 *)(plVar9 + 8) = 0;
                FUN_140014c50(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 8) = (char)plVar8[8];
              *(undefined1 *)(plVar8 + 8) = 1;
              *(undefined1 *)(*plVar9 + 0x40) = 1;
              FUN_140014cb0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 8) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 8) = 1;
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(plVar2 + 3));
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CLuaScriptMgr::helper_140017de0  @140017de0  [medium:callgraph-r0]  (orig: FUN_140017de0)
longlong * FUN_140017de0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140016c20(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x41) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x41) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x41);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x41);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x41);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x41);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140017010(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CLuaScriptMgr::helper_140117b50  @140117b50  [medium:callgraph-r0]  (orig: FUN_140117b50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140117b50(longlong param_1,
                  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                  *param_2)

{
  undefined1 auStack_48 [32];
  undefined8 local_28;
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *local_20;
  ulonglong local_18;
  
  local_28 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_48;
  local_20 = param_2;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 0xa38),
             param_2);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)param_2);
  return;
}

// ==== CLuaScriptMgr::helper_14011e600  @14011e600  [medium:callgraph-r2]  (orig: FUN_14011e600)
void FUN_14011e600(uint *param_1,uint *param_2,uint *param_3)

{
  uint *puVar1;
  uint uVar2;
  longlong lVar3;
  uint *puVar4;
  uint *puVar5;
  
  lVar3 = (longlong)param_3 - (longlong)param_1 >> 2;
  if (lVar3 < 0x29) {
    uVar2 = *param_2;
    if ((uVar2 < *param_1) && (param_2 != param_1)) {
      *param_2 = *param_1;
      *param_1 = uVar2;
    }
    uVar2 = *param_3;
    if ((uVar2 < *param_2) && (param_3 != param_2)) {
      *param_3 = *param_2;
      *param_2 = uVar2;
    }
    uVar2 = *param_2;
    if ((uVar2 < *param_1) && (param_2 != param_1)) {
      *param_2 = *param_1;
      *param_1 = uVar2;
    }
  }
  else {
    lVar3 = lVar3 + 1;
    lVar3 = (longlong)(lVar3 + (ulonglong)((uint)(lVar3 >> 0x3f) & 7)) >> 3;
    uVar2 = param_1[lVar3];
    puVar1 = param_1 + lVar3;
    puVar5 = param_1 + lVar3 * 2;
    if ((uVar2 < *param_1) && (puVar1 != param_1)) {
      *puVar1 = *param_1;
      *param_1 = uVar2;
    }
    uVar2 = *puVar5;
    if ((uVar2 < *puVar1) && (puVar5 != puVar1)) {
      *puVar5 = *puVar1;
      *puVar1 = uVar2;
    }
    uVar2 = *puVar1;
    if ((uVar2 < *param_1) && (puVar1 != param_1)) {
      *puVar1 = *param_1;
      *param_1 = uVar2;
    }
    uVar2 = *param_2;
    puVar5 = param_2 + lVar3;
    puVar4 = param_2 + -lVar3;
    if ((uVar2 < *puVar4) && (param_2 != puVar4)) {
      *param_2 = *puVar4;
      *puVar4 = uVar2;
    }
    uVar2 = *puVar5;
    if ((uVar2 < *param_2) && (puVar5 != param_2)) {
      *puVar5 = *param_2;
      *param_2 = uVar2;
    }
    uVar2 = *param_2;
    if ((uVar2 < *puVar4) && (param_2 != puVar4)) {
      *param_2 = *puVar4;
      *puVar4 = uVar2;
    }
    puVar5 = param_3 + -lVar3;
    puVar4 = param_3 + lVar3 * -2;
    uVar2 = *puVar5;
    if ((uVar2 < *puVar4) && (puVar5 != puVar4)) {
      *puVar5 = *puVar4;
      *puVar4 = uVar2;
    }
    uVar2 = *param_3;
    if ((uVar2 < *puVar5) && (param_3 != puVar5)) {
      *param_3 = *puVar5;
      *puVar5 = uVar2;
    }
    uVar2 = *puVar5;
    if ((uVar2 < *puVar4) && (puVar5 != puVar4)) {
      *puVar5 = *puVar4;
      *puVar4 = uVar2;
    }
    uVar2 = *param_2;
    if ((uVar2 < *puVar1) && (param_2 != puVar1)) {
      *param_2 = *puVar1;
      *puVar1 = uVar2;
    }
    uVar2 = *puVar5;
    if ((uVar2 < *param_2) && (puVar5 != param_2)) {
      *puVar5 = *param_2;
      *param_2 = uVar2;
    }
    uVar2 = *param_2;
    if ((uVar2 < *puVar1) && (param_2 != puVar1)) {
      *param_2 = *puVar1;
      *puVar1 = uVar2;
      return;
    }
  }
  return;
}

// ==== CLuaScriptMgr::helper_14011e7b0  @14011e7b0  [medium:callgraph-r1]  (orig: FUN_14011e7b0)
void FUN_14011e7b0(longlong param_1,longlong param_2)

{
  longlong lVar1;
  uint uVar2;
  uint uVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  
  lVar7 = param_2 - param_1 >> 2;
  lVar4 = lVar7 - (param_2 - param_1 >> 0x3f) >> 1;
  if (0 < lVar4) {
    lVar6 = lVar4 * 2 + 2;
    do {
      uVar2 = *(uint *)(param_1 + -4 + lVar4 * 4);
      lVar4 = lVar4 + -1;
      lVar6 = lVar6 + -2;
      lVar1 = lVar4;
      for (lVar5 = lVar6; lVar5 < lVar7; lVar5 = lVar5 * 2 + 2) {
        if (*(uint *)(param_1 + lVar5 * 4) < *(uint *)(param_1 + -4 + lVar5 * 4)) {
          lVar5 = lVar5 + -1;
        }
        *(undefined4 *)(param_1 + lVar1 * 4) = *(undefined4 *)(param_1 + lVar5 * 4);
        lVar1 = lVar5;
      }
      if (lVar5 == lVar7) {
        *(undefined4 *)(param_1 + lVar1 * 4) = *(undefined4 *)(param_1 + -4 + lVar7 * 4);
        lVar1 = lVar7 + -1;
      }
      while (lVar4 < lVar1) {
        lVar5 = (lVar1 + -1) / 2;
        uVar3 = *(uint *)(param_1 + lVar5 * 4);
        if (uVar2 <= uVar3) break;
        *(uint *)(param_1 + lVar1 * 4) = uVar3;
        lVar1 = lVar5;
      }
      *(uint *)(param_1 + lVar1 * 4) = uVar2;
    } while (0 < lVar4);
  }
  return;
}

// ==== CLuaScriptMgr::helper_14011e890  @14011e890  [medium:callgraph-r1]  (orig: FUN_14011e890)
void FUN_14011e890(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  longlong lVar4;
  uint *puVar5;
  
  if ((param_1 != param_2) && (puVar5 = param_1 + 1, puVar5 != param_2)) {
    do {
      uVar1 = *puVar5;
      if (uVar1 < *param_1) {
        lVar4 = (longlong)puVar5 - (longlong)param_1 >> 2;
        if (0 < lVar4) {
          memmove_s(puVar5 + (1 - lVar4),lVar4 * 4,param_1,lVar4 * 4);
        }
        *param_1 = uVar1;
      }
      else {
        uVar2 = puVar5[-1];
        puVar3 = puVar5;
        while (uVar1 < uVar2) {
          *puVar3 = uVar2;
          uVar2 = puVar3[-2];
          puVar3 = puVar3 + -1;
        }
        *puVar3 = uVar1;
      }
      puVar5 = puVar5 + 1;
    } while (puVar5 != param_2);
  }
  return;
}

// ==== CLuaScriptMgr::helper_14011ed60  @14011ed60  [medium:callgraph-r1]  (orig: FUN_14011ed60)
ulonglong * FUN_14011ed60(ulonglong *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  
  puVar6 = param_2 + (((longlong)param_3 - (longlong)param_2 >> 2) -
                      ((longlong)param_3 - (longlong)param_2 >> 0x3f) >> 1);
  FUN_14011e600(param_2,puVar6,param_3 + -1);
  puVar7 = puVar6 + 1;
  while (puVar9 = puVar6, param_2 < puVar9) {
    uVar1 = puVar9[-1];
    uVar2 = *puVar9;
    if ((uVar2 >= uVar1 && uVar2 != uVar1) || (puVar6 = puVar9 + -1, uVar2 < uVar1)) break;
  }
  puVar6 = puVar7;
  puVar4 = puVar9;
  if (puVar7 < param_3) {
    uVar1 = *puVar9;
    do {
      uVar2 = *puVar7;
      puVar6 = puVar7;
      if ((uVar1 >= uVar2 && uVar1 != uVar2) || (uVar1 < uVar2)) break;
      puVar7 = puVar7 + 1;
      puVar6 = puVar7;
    } while (puVar7 < param_3);
  }
joined_r0x00014011edeb:
  do {
    puVar3 = puVar6;
    puVar6 = puVar9;
    puVar5 = puVar4;
    if (param_3 <= puVar3) {
joined_r0x00014011ee1b:
      for (; param_2 < puVar9; puVar9 = puVar9 + -1) {
        puVar6 = puVar6 + -1;
        uVar1 = *puVar6;
        if (*puVar5 <= uVar1) {
          if (*puVar5 < uVar1) break;
          puVar5 = puVar5 + -1;
          if (puVar5 != puVar6) {
            uVar2 = *puVar5;
            *puVar5 = uVar1;
            *puVar6 = uVar2;
          }
        }
      }
      if (puVar9 == param_2) {
        if (puVar3 == param_3) {
          *param_1 = (ulonglong)puVar5;
          param_1[1] = (ulonglong)puVar7;
          return param_1;
        }
        if ((puVar7 != puVar3) && (puVar5 != puVar7)) {
          uVar1 = *puVar5;
          *puVar5 = *puVar7;
          *puVar7 = uVar1;
        }
        puVar7 = puVar7 + 1;
        puVar6 = puVar3 + 1;
        puVar4 = puVar5 + 1;
        if (puVar5 != puVar3) {
          uVar1 = *puVar5;
          *puVar5 = *puVar3;
          *puVar3 = uVar1;
        }
      }
      else {
        puVar9 = puVar9 + -1;
        if (puVar3 == param_3) {
          puVar4 = puVar5 + -1;
          if (puVar9 != puVar4) {
            uVar1 = *puVar9;
            *puVar9 = *puVar4;
            *puVar4 = uVar1;
          }
          puVar7 = puVar7 + -1;
          puVar6 = puVar3;
          if (puVar4 != puVar7) {
            uVar1 = *puVar4;
            *puVar4 = *puVar7;
            *puVar7 = uVar1;
          }
        }
        else {
          if (puVar3 != puVar9) {
            uVar1 = *puVar3;
            *puVar3 = *puVar9;
            *puVar9 = uVar1;
          }
          puVar6 = puVar3 + 1;
          puVar4 = puVar5;
        }
      }
      goto joined_r0x00014011edeb;
    }
    uVar1 = *puVar3;
    puVar8 = puVar7;
    if (uVar1 <= *puVar4) {
      if (uVar1 < *puVar4) goto joined_r0x00014011ee1b;
      puVar8 = puVar7 + 1;
      if (puVar7 != puVar3) {
        uVar2 = *puVar7;
        *puVar7 = uVar1;
        *puVar3 = uVar2;
      }
    }
    puVar6 = puVar3 + 1;
    puVar7 = puVar8;
  } while( true );
}

// ==== CLuaScriptMgr::helper_140126fb0  @140126fb0  [medium:callgraph-r1]  (orig: FUN_140126fb0)
void FUN_140126fb0(undefined4 *param_1,longlong param_2)

{
  uint uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  bool bVar6;
  
  param_2 = param_2 - (longlong)param_1;
  do {
    if (param_2 >> 2 < 2) {
      return;
    }
    uVar1 = *(uint *)((longlong)param_1 + param_2 + -4);
    lVar4 = param_2 + -4 >> 2;
    lVar2 = 2;
    lVar3 = 0;
    bVar6 = lVar4 == 2;
    *(undefined4 *)((longlong)param_1 + param_2 + -4) = *param_1;
    lVar5 = lVar3;
    if (2 < lVar4) {
      do {
        lVar3 = lVar2;
        if ((uint)param_1[lVar2] < (uint)param_1[lVar2 + -1]) {
          lVar3 = lVar2 + -1;
        }
        param_1[lVar5] = param_1[lVar3];
        lVar2 = lVar3 * 2 + 2;
        bVar6 = lVar2 == lVar4;
        lVar5 = lVar3;
      } while (lVar2 < lVar4);
    }
    if (bVar6) {
      param_1[lVar3] = param_1[lVar4 + -1];
      lVar3 = lVar4 + -1;
    }
    while (0 < lVar3) {
      lVar2 = (lVar3 + -1) / 2;
      if (uVar1 <= (uint)param_1[lVar2]) break;
      param_1[lVar3] = param_1[lVar2];
      lVar3 = lVar2;
    }
    param_2 = param_2 + -4;
    param_1[lVar3] = uVar1;
  } while( true );
}

// ==== CLuaScriptMgr::helper_14013b610  @14013b610  [medium:callgraph-r0]  (orig: FUN_14013b610)
void FUN_14013b610(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong local_18;
  longlong local_10;
  
  lVar1 = param_2 - param_1;
  do {
    lVar1 = lVar1 >> 2;
    if (lVar1 < 0x21) {
LAB_14013b6ca:
      if (1 < lVar1) {
        FUN_14011e890(param_1,param_2,0);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < lVar1) {
        if (4 < (longlong)(param_2 - param_1 & 0xfffffffffffffffcU)) {
          FUN_14011e7b0(param_1,param_2,0,0);
        }
        FUN_140126fb0(param_1,param_2);
        return;
      }
      goto LAB_14013b6ca;
    }
    FUN_14011ed60(&local_18,param_1,param_2);
    lVar1 = local_10;
    param_3 = param_3 / 2 + (param_3 / 2) / 2;
    if ((longlong)(local_18 - param_1 & 0xfffffffffffffffcU) <
        (longlong)(param_2 - local_10 & 0xfffffffffffffffcU)) {
      FUN_14013b610(param_1);
      param_1 = lVar1;
    }
    else {
      FUN_14013b610(local_10,param_2);
      param_2 = local_18;
    }
    lVar1 = param_2 - param_1;
  } while( true );
}

// ==== CLuaScriptMgr::helper_14027b310  @14027b310  [medium:callgraph-r2]  (orig: FUN_14027b310)
void FUN_14027b310(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CLuaScriptMgr::helper_14027b960  @14027b960  [medium:callgraph-r2]  (orig: FUN_14027b960)
void FUN_14027b960(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014027b984. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CLuaScriptMgr::helper_14027c760  @14027c760  [medium:callgraph-r0]  (orig: FUN_14027c760)
void FUN_14027c760(void *param_1)

{
  if ((DAT_140975f38 & 1) == 0) {
    DAT_140975f38 = DAT_140975f38 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975f30,"CLuaScriptMgr");
    atexit((_func_5014 *)&LAB_1406d69b0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014027c7b5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975f30,param_1);
  return;
}

// ==== CLuaScriptMgr::helper_14027cf70  @14027cf70  [medium:callgraph-r2]  (orig: FUN_14027cf70)
void FUN_14027cf70(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CLuaScriptMgr::helper_14027d4a0  @14027d4a0  [medium:callgraph-r2]  (orig: FUN_14027d4a0)
void FUN_14027d4a0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14027d4a0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CLuaScriptMgr::helper_14027d500  @14027d500  [medium:callgraph-r2]  (orig: FUN_14027d500)
void FUN_14027d500(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x51) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CLuaScriptMgr::helper_14027d560  @14027d560  [medium:callgraph-r2]  (orig: FUN_14027d560)
void FUN_14027d560(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x51) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CLuaScriptMgr::helper_14027d880  @14027d880  [medium:callgraph-r2]  (orig: FUN_14027d880)
void FUN_14027d880(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x51) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x51) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x51);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x51);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x51);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x51);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014027d8a4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CLuaScriptMgr::helper_14027e520  @14027e520  [medium:callgraph-r1]  (orig: FUN_14027e520)
void FUN_14027e520(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14027d4a0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CLuaScriptMgr::helper_14027e860  @14027e860  [medium:callgraph-r1]  (orig: FUN_14027e860)
void FUN_14027e860(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CLuaScriptMgr::helper_14027e950  @14027e950  [medium:callgraph-r1]  (orig: FUN_14027e950)
void FUN_14027e950(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x58);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 10) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x51) = 0;
  return;
}

// ==== CLuaScriptMgr::helper_140280030  @140280030  [medium:callgraph-r1]  (orig: FUN_140280030)
undefined8 * FUN_140280030(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x51) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14027d880(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x51) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x51) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x51) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 10;
        plVar8 = plVar8 + 10;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14028021c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x51) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x51) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x51);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x51);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x51) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x51);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x51);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14028021c:
  if ((char)plVar2[10] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[10] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[10] == '\0') {
            *(undefined1 *)(plVar9 + 10) = 1;
            *(undefined1 *)(plVar8 + 10) = 0;
            FUN_14027d500(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x51) == '\0') {
            if ((*(char *)(*plVar9 + 0x50) != '\x01') || (*(char *)(plVar9[2] + 0x50) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x50) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x50) = 1;
                *(undefined1 *)(plVar9 + 10) = 0;
                FUN_14027d560(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 10) = (char)plVar8[10];
              *(undefined1 *)(plVar8 + 10) = 1;
              *(undefined1 *)(plVar9[2] + 0x50) = 1;
              FUN_14027d500(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 10) = 0;
          }
        }
        else {
          if ((char)plVar9[10] == '\0') {
            *(undefined1 *)(plVar9 + 10) = 1;
            *(undefined1 *)(plVar8 + 10) = 0;
            FUN_14027d560(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x51) == '\0') {
            if ((*(char *)(plVar9[2] + 0x50) != '\x01') || (*(char *)(*plVar9 + 0x50) != '\x01')) {
              if (*(char *)(*plVar9 + 0x50) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x50) = 1;
                *(undefined1 *)(plVar9 + 10) = 0;
                FUN_14027d500(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 10) = (char)plVar8[10];
              *(undefined1 *)(plVar8 + 10) = 1;
              *(undefined1 *)(*plVar9 + 0x50) = 1;
              FUN_14027d560(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 10) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 10) = 1;
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(plVar2 + 3));
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CLuaScriptMgr::helper_140281940  @140281940  [medium:callgraph-r1]  (orig: FUN_140281940)
undefined8 * FUN_140281940(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14027b960(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_140281b2c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_140281b2c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14027cf70(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14027b310(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_14027cf70(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14027b310(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14027cf70(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_14027b310(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CLuaScriptMgr::helper_1402824b0  @1402824b0  [medium:callgraph-r0]  (orig: FUN_1402824b0)
longlong * FUN_1402824b0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14027e520(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140281940(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CLuaScriptMgr::helper_140282e60  @140282e60  [medium:callgraph-r0]  (orig: FUN_140282e60)
longlong * FUN_140282e60(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140280fc0(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x51) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x51) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x51);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x51);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x51);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x51);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140280030(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CLuaScriptMgr::helper_140284640  @140284640  [medium:callgraph-r0]  (orig: FUN_140284640)
undefined8 * FUN_140284640(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14027e860(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CLuaScriptMgr::ctor_or_dtor  @140284cf0  [high:vtable-assign]  (orig: FUN_140284cf0)
void FUN_140284cf0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 local_48;
  undefined8 *puStack_40;
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined1 local_28 [16];
  
  *param_1 = CLuaScriptMgr::vftable;
  if (param_1[1] != 0) {
    (*(code *)**(undefined8 **)param_1[1])
              ((undefined8 *)param_1[1],param_2,param_3,param_4,0xfffffffffffffffe);
    param_1[1] = 0;
  }
  puVar1 = param_1 + 0x1b;
  puStack_40 = (undefined8 *)param_1[0x21];
  local_48 = *puVar1;
  puStack_30 = (undefined8 *)*puStack_40;
  local_38 = local_48;
  FUN_140282e60(puVar1,local_28,&local_38,&local_48);
  operator_delete((void *)param_1[0x21]);
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  operator_delete((void *)*puVar1);
  puVar1 = param_1 + 0x13;
  puStack_30 = (undefined8 *)param_1[0x19];
  local_48 = *puVar1;
  puStack_40 = (undefined8 *)*puStack_30;
  local_38 = local_48;
  FUN_140017de0(puVar1,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[0x19]);
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  operator_delete((void *)*puVar1);
  puVar1 = param_1 + 0xb;
  puStack_30 = (undefined8 *)param_1[0x11];
  local_48 = *puVar1;
  puStack_40 = (undefined8 *)*puStack_30;
  local_38 = local_48;
  FUN_1402824b0(puVar1,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[0x11]);
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  operator_delete((void *)*puVar1);
  lVar3 = param_1[8];
  if (lVar3 != 0) {
    lVar2 = param_1[9];
    for (; lVar3 != lVar2; lVar3 = lVar3 + 0x30) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
                ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(lVar3 + 8));
    }
    operator_delete((void *)param_1[8]);
  }
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  operator_delete((void *)param_1[5]);
  return;
}

// ==== CLuaScriptMgr::helper_140284f40  @140284f40  [medium:callgraph-r0]  (orig: FUN_140284f40)
undefined8 * FUN_140284f40(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14027e950(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x51) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CLuaScriptMgr::ctor_or_dtor  @1402852b0  [high:vtable-assign]  (orig: FUN_1402852b0)
undefined8 * FUN_1402852b0(undefined8 *param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = CLuaScriptMgr::vftable;
  plVar2 = (longlong *)0x0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  param_1[4] = &DAT_1406dd892;
  *(undefined4 *)(param_1 + 3) = 0;
  plVar1 = operator_new(8);
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 5);
    plVar2 = plVar1;
  }
  param_1[5] = plVar2;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  FUN_140284640(param_1 + 0xb);
  FUN_140019420(param_1 + 0x13);
  FUN_140284f40(param_1 + 0x1b);
  *(undefined4 *)(param_1 + 0x23) = param_2;
  param_1[1] = 0;
  return param_1;
}

// ==== CLuaScriptMgr::vfunc_0  @140285370  [high:rtti-vtable]  (orig: FUN_140285370)
undefined8 FUN_140285370(undefined8 param_1,uint param_2)

{
  FUN_140284cf0();
  if ((param_2 & 1) != 0) {
    FUN_14027c760(param_1);
  }
  return param_1;
}

// ==== CLuaScriptMgr::helper_1402bd090  @1402bd090  [medium:callgraph-r0]  (orig: FUN_1402bd090)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402bd090(longlong *param_1,int param_2,char param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if ((param_1[0xc] == 0) || ((char)param_1[0xd] == '\0')) {
    local_468 = 0x148;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*(longlong *)param_1[0xc] + 0x60))((longlong *)param_1[0xc],5,param_2);
  }
  if (param_3 != '\0') {
    FUN_14039e680(local_448);
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    iVar3 = FUN_14039e700(local_448,uVar2,0xb,(longlong)param_2);
    if (iVar3 == 0) {
      local_468 = 0x1ff;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_448,0);
    }
    FUN_14039e6d0(local_448);
  }
  cVar1 = (**(code **)(*param_1 + 0x88))(param_1);
  if (cVar1 != '\0') {
    lVar4 = (**(code **)(*param_1 + 0x90))(param_1);
    if (lVar4 != 0) {
      FUN_14046a430(lVar4,param_2);
    }
  }
  return;
}

// ==== CLuaScriptMgr::helper_1402c70d0  @1402c70d0  [medium:callgraph-r2]  (orig: FUN_1402c70d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1402c70d0(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined1 auStack_4e8 [32];
  ulonglong local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined8 local_4a8;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  lVar4 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
  if (*(longlong *)(lVar4 + 0x98) == 0) {
    local_4c8 = CONCAT44(local_4c8._4_4_,0x131);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar5 = (**(code **)(**(longlong **)(lVar4 + 0x98) + 0x60))(*(longlong **)(lVar4 + 0x98),param_5);
  if (uVar5 == 0) {
    log_InlineLogERROR(
                      "CGameMap::AddTerrainObj GetTerrainNpcFileName failed, item type:%u at %s, %d."
                      );
    uVar6 = 0;
  }
  else {
    local_4c8 = uVar5;
    cVar1 = (**(code **)(*(longlong *)param_1[0xc] + 0x68))
                      ((longlong *)param_1[0xc],param_2,param_3,param_4);
    if (cVar1 == '\0') {
      uVar6 = 0;
    }
    else {
      FUN_140362560(local_498);
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      local_4b0 = 0;
      local_4c0 = 0xcb;
      local_4c8 = local_4c8 & 0xffffffffffff0000;
      local_4b8 = param_2;
      iVar3 = FUN_140362620(local_498,uVar2,param_3,param_4);
      if (iVar3 == 0) {
        local_4c8 = CONCAT44(local_4c8._4_4_,0x71e);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar7 = (longlong *)FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
        (**(code **)(*plVar7 + 0x30))(plVar7,param_5,local_498);
      }
      FUN_1403625e0(local_498);
      uVar6 = 1;
    }
  }
  return uVar6;
}

// ==== CLuaScriptMgr::helper_14046a430  @14046a430  [medium:callgraph-r1]  (orig: FUN_14046a430)
void FUN_14046a430(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong *)(param_1 + 0x10) == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    if (*(int *)(param_1 + 0x18) != 0) {
      *(undefined4 *)(param_1 + 0x18) = 0;
      uVar4 = (**(code **)(**(longlong **)(param_1 + 8) + 8))();
      FUN_1402c7270(*(undefined8 *)(param_1 + 0x10),uVar4);
    }
    plVar2 = *(longlong **)(param_1 + 8);
    plVar1 = plVar2 + 2;
    uVar4 = (**(code **)(*plVar1 + 0x48))(plVar1);
    uVar5 = (**(code **)(*plVar1 + 0x40))(plVar1);
    uVar6 = (**(code **)(*plVar2 + 8))(plVar2);
    cVar3 = FUN_1402c70d0(*(undefined8 *)(param_1 + 0x10),uVar6,uVar5,uVar4,param_2);
    if (cVar3 != '\0') {
      *(undefined4 *)(param_1 + 0x18) = 1;
      return;
    }
  }
  return;
}

// ==== CLuaScriptMgr::Npc_SetInt  @1404e10c0  [high:log-string]  (orig: FUN_1404e10c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404e10c0(longlong param_1,int param_2,int param_3,int param_4,undefined1 param_5)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  longlong *local_468;
  undefined8 local_460;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_460 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_2 == 0) {
    log_InlineLogLuaERROR("%s %d, the idNpc is 0.");
  }
  else {
    local_468 = (longlong *)0x0;
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x118));
    if (*(longlong *)(lVar4 + 0x88) == 0) {
      local_478 = 0x12f;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(lVar4 + 0x88) + 0x20))
                       (*(longlong **)(lVar4 + 0x88),param_2);
    if ((plVar5 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1040,&local_468), cVar1 != '\0')) {
      if ((char)local_468[0xd] == '\0') {
        log_InlineLogLuaERROR("CLuaScriptMgr::Npc_SetInt(), NPC(%u) is not DynaNpc");
        return 0;
      }
      switch(param_3 + -0x7d3) {
      case 0:
        FUN_1400922d0(local_468,1,param_4,param_5);
        break;
      case 1:
        FUN_1400922d0(local_468,2,param_4,param_5);
        break;
      case 3:
        FUN_1402bd090(local_468,param_4,0x140000001);
        break;
      case 7:
        FUN_1400922d0(local_468,0x12,param_4,param_5);
        break;
      case 8:
        FUN_1400922d0(local_468,0x13,param_4,param_5);
        break;
      case 9:
        FUN_1400922d0(local_468,0x14,param_4,param_5);
        break;
      case 10:
        FUN_1400922d0(local_468,0x15,param_4,param_5);
        break;
      case 0xc:
        FUN_1400922d0(local_468,0x19,param_4,param_5);
        FUN_14039e680(local_458);
        uVar2 = (**(code **)(*local_468 + 8))();
        iVar3 = FUN_14039e700(local_458,uVar2,1,(longlong)param_4);
        if (iVar3 == 0) {
          local_478 = 0x193;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(local_468[2] + 0x348))(local_468 + 2,local_458,0);
        }
        FUN_14039e6d0(local_458);
        break;
      case 0xd:
        FUN_1400922d0(local_468,0x18,param_4,param_5);
        FUN_14039e680(local_458);
        uVar2 = (**(code **)(*local_468 + 8))();
        iVar3 = FUN_14039e700(local_458,uVar2,0,(longlong)param_4);
        if (iVar3 == 0) {
          local_478 = 0x18b;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(local_468[2] + 0x348))(local_468 + 2,local_458,0);
        }
        FUN_14039e6d0(local_458);
      }
      return 1;
    }
  }
  return 0;
}

// ==== CLuaScriptMgr::Npc_RequestLayByItem  @1404e17c0  [high:log-string]  (orig: FUN_1404e17c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1404e17c0(longlong param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_6)

{
  int iVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_4a8;
  undefined8 local_4a0;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_498 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_4a0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  local_470 = param_6;
  if (param_2 == 0) {
    log_InlineLogLuaERROR("%s %d, the idUser is 0.","CLuaScriptMgr::RequestLayNpcByItem",0x205);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_6);
    uVar3 = 0;
  }
  else {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x118));
    if (*(longlong *)(lVar2 + 0x90) == 0) {
      local_4b8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
    }
    lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))
                      (*(longlong **)(lVar2 + 0x90),param_2);
    if (lVar2 == 0) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_6);
      uVar3 = 0;
    }
    else if (*(longlong *)(param_6 + 0x18) == 0) {
      log_InlineLogLuaERROR("CLuaScriptMgr::Npc_RequestLayByItem(), call func is null");
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_6);
      uVar3 = 0;
    }
    else {
      local_4a8 = local_498;
      uVar3 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              basic_string<char,std::char_traits<char>,std::allocator<char>_>
                        (local_498,
                         (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                          *)param_6);
      FUN_140117b50(lVar2,uVar3);
      *(undefined4 *)(lVar2 + 0xa34) = 0;
      FUN_14037d4a0(local_468);
      local_4b8 = param_5;
      iVar1 = FUN_14037d520(local_468,5,param_3,param_4);
      if (iVar1 == 0) {
        local_4b8 = 0x215;
        log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                           "msg.Create(EVENT_LAYNPC, nRegion, nType, nLookFace)",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\luascript\\scriptfunction.cpp"
                          );
      }
      else {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_468);
      }
      FUN_14037d4f0(local_468);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_6);
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CLuaScriptMgr::Mouse_DeleteChosen  @1404e39e0  [high:log-string]  (orig: FUN_1404e39e0)
undefined8 FUN_1404e39e0(longlong param_1,int param_2)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong local_res18 [2];
  
  if (param_2 == 0) {
    log_InlineLogLuaERROR("%s %d, the idUser is 0.");
    return 0;
  }
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x118));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2);
  if (((lVar3 == 0) || (*(char *)(lVar3 + 0x968) != '\x03')) || (*(int *)(lVar3 + 0x970) == 0)) {
    return 0;
  }
  if ((*(int *)(lVar3 + 0x974) != 1) && (*(int *)(lVar3 + 0x974) != 2)) {
    return 0;
  }
  uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x118));
  plVar5 = (longlong *)FUN_1400875f0(uVar4);
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,*(undefined4 *)(lVar3 + 0x970));
  if (plVar5 == (longlong *)0x0) {
    return 0;
  }
  if (*(int *)(lVar3 + 0x974) == 1) {
    local_res18[0] = 0;
    cVar1 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1040,local_res18);
    if (cVar1 == '\0') {
      return 0;
    }
    if (*(char *)(local_res18[0] + 0x68) == '\0') {
      return 0;
    }
    if (*(int *)(local_res18[0] + 0xb4) != 0) {
      return 1;
    }
    cVar1 = FUN_1402bf900();
    if (cVar1 == '\0') {
      return 0;
    }
  }
  else {
    if (*(int *)(lVar3 + 0x974) != 2) {
      log_InlineLogLuaERROR("CLuaScriptMgr::Mouse_DeleteChosen(), ObjType(%u) error");
      return 0;
    }
    local_res18[0] = 0;
    cVar1 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1002,local_res18);
    if (cVar1 == '\0') {
      return 0;
    }
    if (*(int *)(local_res18[0] + 0x154) != 0) {
      return 1;
    }
    iVar2 = (**(code **)(*(longlong *)(local_res18[0] + 0x10) + 0x78))(local_res18[0] + 0x10);
    if (iVar2 == 0) {
      return 1;
    }
    FUN_14038e270(local_res18[0],1);
  }
  FUN_140165b50(lVar3);
  FUN_140165a10(lVar3);
  return 1;
}

// ==== CLuaScriptMgr::ChangeNpcPos  @1404f5c70  [high:log-string]  (orig: FUN_1404f5c70)
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_1404f5c70(longlong param_1,char *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  undefined8 uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  char *pcVar8;
  uint uVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong *plVar12;
  undefined4 *puVar13;
  ulonglong uVar14;
  uint *puVar15;
  int local_res10;
  longlong local_198;
  longlong *local_190 [3];
  undefined4 *local_178;
  undefined4 *local_170;
  undefined8 local_168;
  longlong local_160;
  undefined8 local_158;
  uint local_148 [66];
  
  local_158 = 0xfffffffffffffffe;
  plVar12 = (longlong *)0x0;
  uVar14 = 0;
  local_148[0] = 0;
  memset(local_148 + 1,0,0xfc);
  plVar10 = plVar12;
  uVar9 = 0;
  if (*param_2 != '\0') {
    while (uVar9 + 1 < 10000 || uVar9 == 9999) {
      if (0x40 < (longlong)plVar10) {
        log_InlineLogLuaERROR(&DAT_1407942f8,uVar14);
        return 0;
      }
      iVar4 = isdigit((int)*param_2);
      if (iVar4 != 0) {
        local_148[(longlong)plVar10] = *param_2 + -0x30 + local_148[(longlong)plVar10] * 10;
      }
      pcVar8 = param_2 + 1;
      if (*pcVar8 == ' ') {
        pcVar8 = param_2 + 2;
        uVar14 = (ulonglong)((int)uVar14 + 1);
        plVar10 = (longlong *)((longlong)plVar10 + 1);
        if ((*pcVar8 == ' ') || (iVar4 = isdigit((int)*pcVar8), iVar4 == 0)) goto LAB_1404f5d72;
      }
      param_2 = pcVar8;
      uVar9 = uVar9 + 1;
      if (*pcVar8 == '\0') goto LAB_1404f5d72;
    }
    log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","unLoopCount",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\luascript\\scriptfunction.cpp"
                      );
  }
LAB_1404f5d72:
  iVar4 = (int)uVar14 + 1;
  if (iVar4 < 4) {
    log_InlineLogLuaERROR(&DAT_1407942f8,iVar4);
    uVar5 = 0;
  }
  else {
    uVar6 = (ulonglong)local_148[0];
    if ((local_148[0] == 0) || ((int)local_148[1] < 1)) {
      log_InlineLogLuaERROR(&DAT_1407941e0,uVar6,local_148[1]);
      uVar5 = 0;
    }
    else {
      plVar10 = operator_new(8);
      if (plVar10 != (longlong *)0x0) {
        *plVar10 = (longlong)local_190;
        plVar12 = plVar10;
      }
      local_178 = (undefined4 *)0x0;
      local_170 = (undefined4 *)0x0;
      local_168 = 0;
      local_190[0] = plVar12;
      FUN_140036640(local_190);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x118));
      plVar12 = (longlong *)FUN_1400875f0(uVar5);
      (**(code **)(*plVar12 + 200))(plVar12,uVar6,local_148[1],local_190);
      if (((longlong)local_170 - (longlong)local_178 & 0xfffffffffffffffcU) == 0) {
        log_InlineLogLuaERROR(&DAT_1407942b0,uVar6,local_148[1]);
        if (local_178 != (undefined4 *)0x0) {
          operator_delete(local_178);
        }
        local_178 = (undefined4 *)0x0;
        local_170 = (undefined4 *)0x0;
        local_168 = 0;
        operator_delete(local_190[0]);
        uVar5 = 0;
      }
      else {
        uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x118));
        plVar12 = (longlong *)FUN_1400876b0(uVar5);
        local_160 = (**(code **)(*plVar12 + 0x10))(plVar12,uVar6,1);
        puVar13 = local_170;
        if (local_160 == 0) {
          log_InlineLogLuaERROR(&DAT_140794280,uVar6);
          if (local_178 != (undefined4 *)0x0) {
            operator_delete(local_178);
          }
          local_178 = (undefined4 *)0x0;
          local_170 = (undefined4 *)0x0;
          local_168 = 0;
          operator_delete(local_190[0]);
          uVar5 = 0;
        }
        else {
          if (local_170 < local_178) {
            _invalid_parameter_noinfo();
          }
          puVar2 = local_178;
          plVar12 = local_190[0];
          if (local_170 < local_178) {
            _invalid_parameter_noinfo();
          }
          if ((plVar12 == (longlong *)0x0) || (plVar12 != local_190[0])) {
            _invalid_parameter_noinfo();
          }
          FUN_14013b610(puVar2,puVar13,(longlong)puVar13 - (longlong)puVar2 >> 2);
          puVar13 = local_178;
          if (local_170 < local_178) {
            _invalid_parameter_noinfo();
          }
          plVar12 = local_190[0];
          iVar4 = 2;
          local_res10 = 2;
          puVar15 = local_148 + 2;
          while( true ) {
            puVar2 = local_170;
            if (local_170 < local_178) {
              _invalid_parameter_noinfo();
            }
            if ((plVar12 == (longlong *)0x0) || (plVar12 != local_190[0])) {
              _invalid_parameter_noinfo();
            }
            if (puVar13 == puVar2) break;
            local_198 = 0;
            uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x118));
            plVar10 = (longlong *)FUN_1400875f0(uVar5);
            if (plVar12 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar11 = 0;
            }
            else {
              lVar11 = *plVar12;
            }
            if (*(undefined4 **)(lVar11 + 0x20) <= puVar13) {
              _invalid_parameter_noinfo();
            }
            plVar10 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,*puVar13);
            if ((plVar10 != (longlong *)0x0) &&
               (cVar3 = (**(code **)(*plVar10 + 0x298))(plVar10,0x1040,&local_198), cVar3 != '\0'))
            {
              if ((int)uVar14 + -1 < iVar4) break;
              uVar9 = puVar15[1];
              uVar1 = *puVar15;
              cVar3 = FUN_1402c3cc0(local_160,uVar1,uVar9);
              if (cVar3 == '\0') {
                log_InlineLogLuaERROR
                          ("CLuaScriptMgr::ChangeNpcPos(), Invalid Point(idMap = %u, x = %d, y = %d)"
                           ,uVar6,uVar1,(ulonglong)uVar9);
              }
              else {
                FUN_1400872b0(local_198,8);
                FUN_1400872b0(local_198,9);
                if ((*(longlong *)(local_198 + 0x60) == 0) || (*(char *)(local_198 + 0x68) == '\0'))
                {
                  log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pData && IsDynaNpc()",
                                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h"
                                    );
                }
                else {
                  (**(code **)(**(longlong **)(local_198 + 0x60) + 0x60))
                            (*(longlong **)(local_198 + 0x60),8,uVar1);
                }
                if ((*(longlong *)(local_198 + 0x60) == 0) || (*(char *)(local_198 + 0x68) == '\0'))
                {
                  log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pData && IsDynaNpc()",
                                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h"
                                    );
                }
                else {
                  (**(code **)(**(longlong **)(local_198 + 0x60) + 0x60))
                            (*(longlong **)(local_198 + 0x60),9,uVar9);
                }
                FUN_1402bf7a0(local_198,uVar6,uVar1,uVar9);
                (**(code **)(*(longlong *)(local_198 + 0x10) + 0x338))();
                FUN_1400872b0(local_198,8);
                FUN_1400872b0(local_198,9);
                FUN_140117cc0(local_198,3);
                uVar6 = FUN_1400872b0(local_198,1);
                uVar7 = FUN_1400872b0(local_198,0);
                tq::MyLogSave("gmlog/ActionNpcChangePos",
                              "npc change position:NpcID:%u, OwnerID:%u, NpcName: %s, OldPosX:%d, OldPosY:%d, NewPosX:%d, NewPosY:%d"
                              ,uVar7 & 0xffffffff,uVar6 & 0xffffffff);
                uVar6 = (ulonglong)local_148[0];
              }
              iVar4 = local_res10 + 2;
              puVar15 = puVar15 + 2;
              local_res10 = iVar4;
            }
            if (plVar12 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar11 = 0;
            }
            else {
              lVar11 = *plVar12;
            }
            if (*(undefined4 **)(lVar11 + 0x20) <= puVar13) {
              _invalid_parameter_noinfo();
            }
            puVar13 = puVar13 + 1;
          }
          if (local_178 != (undefined4 *)0x0) {
            operator_delete(local_178);
          }
          local_178 = (undefined4 *)0x0;
          local_170 = (undefined4 *)0x0;
          local_168 = 0;
          operator_delete(local_190[0]);
          uVar5 = 1;
        }
      }
    }
  }
  return uVar5;
}

