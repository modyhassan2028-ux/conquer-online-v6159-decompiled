// ==== CItemOSLimitMgr::helper_140258830  @140258830  [medium:callgraph-r0]  (orig: FUN_140258830)
undefined8 FUN_140258830(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  undefined4 local_res18 [2];
  longlong *local_res20;
  undefined8 uVar6;
  undefined1 local_40 [32];
  
  uVar6 = 0xfffffffffffffffe;
  plVar1 = (longlong *)InstanceGet();
  plVar1 = (longlong *)
           (**(code **)(*plVar1 + 0x10))(plVar1,"SELECT * FROM cq_item_os_limit",1,*plVar1,uVar6);
  local_res20 = plVar1;
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR("CItemOSLimitMgr::Create pRes is null, sql:%s, at %s, %u.");
    uVar6 = 0;
  }
  else {
    iVar5 = 0;
    while( true ) {
      uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
      if (uVar2 <= (ulonglong)(longlong)iVar5) break;
      (**(code **)(*plVar1 + 0x30))(plVar1,(longlong)iVar5);
      plVar3 = (longlong *)(**(code **)(*plVar1 + 0x38))(plVar1);
      if (plVar3 != (longlong *)0x0) {
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,1);
        local_res18[0] = (**(code **)(*plVar4 + 0x40))(plVar4);
        FUN_14000d480(param_1 + 0x10,local_40,local_res18);
        (**(code **)*plVar3)(plVar3,1);
      }
      iVar5 = iVar5 + 1;
    }
    (**(code **)*plVar1)(plVar1);
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CItemOSLimitMgr::ctor_or_dtor  @140258950  [high:vtable-assign]  (orig: FUN_140258950)
void FUN_140258950(undefined8 *param_1)

{
  *param_1 = CItemOSLimitMgr::vftable;
  param_1 = param_1 + 2;
  FUN_14000a7b0(param_1);
  FUN_14000c310(param_1);
  operator_delete((void *)*param_1);
  return;
}

// ==== CItemOSLimitMgr::ctor_or_dtor  @1402589a0  [high:vtable-assign]  (orig: FUN_1402589a0)
undefined8 * FUN_1402589a0(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CItemOSLimitMgr::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_14000ef40(param_1 + 2);
  FUN_14000a7b0(param_1 + 2);
  return param_1;
}

// ==== CItemOSLimitMgr::ctor_or_dtor  @1402589f0  [high:vtable-assign]  (orig: FUN_1402589f0)
undefined8 * FUN_1402589f0(undefined8 *param_1,uint param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CItemOSLimitMgr::vftable;
  puVar1 = param_1 + 2;
  FUN_14000a7b0(puVar1);
  FUN_14000c310(puVar1);
  operator_delete((void *)*puVar1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CItemOSLimitMgr::ctor_or_dtor  @140258a70  [high:vtable-assign]  (orig: FUN_140258a70)
undefined8 *
FUN_140258a70(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar2 = operator_new(0x50);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CItemOSLimitMgr::vftable;
    *(undefined4 *)(puVar2 + 1) = param_1;
    FUN_14000ef40(puVar2 + 2);
    FUN_14000a7b0(puVar2 + 2);
  }
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_140258830(puVar2);
    if (cVar1 == '\0') {
      (**(code **)*puVar2)(puVar2,1,param_3,param_4,uVar3);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

