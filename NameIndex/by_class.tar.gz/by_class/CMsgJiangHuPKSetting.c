// ==== CMsgJiangHuPKSetting::helper_140167970  @140167970  [medium:callgraph-r0]  (orig: FUN_140167970)
void FUN_140167970(longlong param_1,undefined8 param_2)

{
  FUN_1403740d0(param_1 + 0xe78,param_2,0);
  return;
}

// ==== CMsgJiangHuPKSetting::helper_1403740d0  @1403740d0  [medium:callgraph-r1]  (orig: FUN_1403740d0)
void FUN_1403740d0(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x1ec) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"pk_setting");
    (**(code **)(*plVar1 + 0xb8))(plVar1,*(undefined4 *)(param_1 + 0x1ec));
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CMsgJiangHuPKSetting::ctor_or_dtor  @140459ad0  [high:vtable-assign]  (orig: FUN_140459ad0)
undefined8 * FUN_140459ad0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgJiangHuPKSetting::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgJiangHuPKSetting::ctor_or_dtor  @140459b20  [high:vtable-assign]  (orig: FUN_140459b20)
void FUN_140459b20(undefined8 *param_1)

{
  *param_1 = CMsgJiangHuPKSetting::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgJiangHuPKSetting::vfunc_1  @140459b50  [high:rtti-vtable]  (orig: FUN_140459b50)
bool FUN_140459b50(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xa90;
    }
  }
  return false;
}

// ==== CMsgJiangHuPKSetting::ctor_or_dtor  @140459b90  [high:vtable-assign]  (orig: FUN_140459b90)
undefined8 * FUN_140459b90(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgJiangHuPKSetting::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgJiangHuPKSetting::vfunc_3  @140459be0  [high:rtti-vtable]  (orig: FUN_140459be0)
void FUN_140459be0(longlong param_1)

{
  int iVar1;
  int iVar2;
  longlong lVar3;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar3 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))
                      (*(longlong **)(lVar3 + 0x90),param_1);
    if (lVar3 != 0) {
      iVar1 = **(int **)(param_1 + 0x428);
      iVar2 = FUN_140167980(lVar3);
      if (iVar2 != iVar1) {
        FUN_140167970(lVar3,iVar1);
      }
    }
  }
  return;
}

