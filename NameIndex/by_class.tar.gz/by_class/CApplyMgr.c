// ==== CApplyMgr::helper_140278b40  @140278b40  [medium:callgraph-r1]  (orig: FUN_140278b40)
void FUN_140278b40(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x2c) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x2d) = 0;
  return;
}

// ==== CApplyMgr::helper_140279b30  @140279b30  [medium:callgraph-r1]  (orig: FUN_140279b30)
longlong * FUN_140279b30(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140278cb0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x2d) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x2d) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x2d);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x2d);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x2d);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x2d);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140279680(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CApplyMgr::helper_140279ce0  @140279ce0  [medium:callgraph-r0]  (orig: FUN_140279ce0)
void FUN_140279ce0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140279b30((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CApplyMgr::ctor_or_dtor  @14027aaa0  [high:vtable-assign]  (orig: FUN_14027aaa0)
void FUN_14027aaa0(undefined8 *param_1)

{
  *param_1 = CApplyMgr::vftable;
  FUN_140279ce0(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_140279ce0(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CApplyMgr::ctor_or_dtor  @14027abc0  [high:vtable-assign]  (orig: FUN_14027abc0)
undefined8 * FUN_14027abc0(undefined8 *param_1,uint param_2)

{
  *param_1 = CApplyMgr::vftable;
  FUN_140279ce0(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_140279ce0(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CApplyMgr::helper_14027ac50  @14027ac50  [medium:callgraph-r0]  (orig: FUN_14027ac50)
undefined8 * FUN_14027ac50(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140278b40(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x2d) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CApplyMgr::ctor_or_dtor  @14027acd0  [high:vtable-assign]  (orig: FUN_14027acd0)
undefined8 * FUN_14027acd0(undefined8 *param_1)

{
  *param_1 = CApplyMgr::vftable;
  FUN_14027ac50(param_1 + 1);
  FUN_14027ac50(param_1 + 9);
  *(undefined4 *)(param_1 + 0x11) = 0;
  *(undefined4 *)((longlong)param_1 + 0x8c) = 0;
  return param_1;
}

// ==== CApplyMgr::ctor_or_dtor  @14027ad20  [high:vtable-assign]  (orig: FUN_14027ad20)
undefined8 * FUN_14027ad20(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x90);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CApplyMgr::vftable;
    FUN_14027ac50(puVar1 + 1);
    FUN_14027ac50(puVar1 + 9);
    *(undefined4 *)(puVar1 + 0x11) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x8c) = 0;
  }
  return puVar1;
}

