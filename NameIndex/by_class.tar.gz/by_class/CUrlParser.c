// ==== CUrlParser::ctor_or_dtor  @140329c60  [high:vtable-assign]  (orig: FUN_140329c60)
undefined8 * FUN_140329c60(undefined8 *param_1)

{
  *param_1 = CUrlParser::vftable;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((longlong)param_1 + 0x40c) = 0;
  memset((void *)((longlong)param_1 + 0xc),0,0x400);
  memset(param_1 + 0x82,0,0x400);
  memset(param_1 + 0x102,0,0x400);
  return param_1;
}

// ==== CUrlParser::ctor_or_dtor  @140329cc0  [high:vtable-assign]  (orig: FUN_140329cc0)
void FUN_140329cc0(undefined8 *param_1)

{
  *param_1 = CUrlParser::vftable;
  return;
}

// ==== CUrlParser::ctor_or_dtor  @140329e90  [high:vtable-assign]  (orig: FUN_140329e90)
undefined8 * FUN_140329e90(undefined8 *param_1,byte param_2)

{
  *param_1 = CUrlParser::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

