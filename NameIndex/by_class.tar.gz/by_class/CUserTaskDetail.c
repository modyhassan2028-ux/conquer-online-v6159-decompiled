// ==== CUserTaskDetail::helper_1403b9c60  @1403b9c60  [medium:callgraph-r0]  (orig: FUN_1403b9c60)
void FUN_1403b9c60(void *param_1)

{
  if ((DAT_140976290 & 1) == 0) {
    DAT_140976290 = DAT_140976290 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976288,"CUserTaskDetail");
    atexit((_func_5014 *)&LAB_1406d6c60);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403b9cb5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976288,param_1);
  return;
}

// ==== CUserTaskDetail::helper_1403ba020  @1403ba020  [medium:callgraph-r1]  (orig: FUN_1403ba020)
void FUN_1403ba020(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1403ba020(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CUserTaskDetail::helper_1403ba1f0  @1403ba1f0  [medium:callgraph-r0]  (orig: FUN_1403ba1f0)
void FUN_1403ba1f0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1403ba020(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CUserTaskDetail::helper_1403bb8d0  @1403bb8d0  [medium:callgraph-r0]  (orig: FUN_1403bb8d0)
void FUN_1403bb8d0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1403bb2f0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CUserTaskDetail::ctor_or_dtor  @1403bbfc0  [high:vtable-assign]  (orig: FUN_1403bbfc0)
void FUN_1403bbfc0(undefined8 *param_1)

{
  *param_1 = CUserTaskDetail::vftable;
  FUN_1403bb8d0(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CUserTaskDetail::helper_1403bc000  @1403bc000  [medium:callgraph-r0]  (orig: FUN_1403bc000)
undefined8 * FUN_1403bc000(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1403ba0c0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CUserTaskDetail::ctor_or_dtor  @1403bc080  [high:vtable-assign]  (orig: FUN_1403bc080)
undefined8 * FUN_1403bc080(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CUserTaskDetail::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_1403bc000(param_1 + 2);
  *(undefined4 *)(param_1 + 10) = 0;
  FUN_1403ba1f0(param_1 + 2);
  return param_1;
}

// ==== CUserTaskDetail::ctor_or_dtor  @1403bc0e0  [high:vtable-assign]  (orig: FUN_1403bc0e0)
undefined8 * FUN_1403bc0e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CUserTaskDetail::vftable;
  FUN_1403bb8d0(param_1 + 2);
  operator_delete((void *)param_1[2]);
  if ((param_2 & 1) != 0) {
    FUN_1403b9c60(param_1);
  }
  return param_1;
}

// ==== CUserTaskDetail::ctor_or_dtor  @1403bc150  [high:vtable-assign]  (orig: FUN_1403bc150)
undefined8 * FUN_1403bc150(undefined4 param_1)

{
  undefined8 *puVar1;
  
  if ((DAT_140976290 & 1) == 0) {
    DAT_140976290 = DAT_140976290 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976288,"CUserTaskDetail");
    atexit((_func_5014 *)&LAB_1406d6c60);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976288,0x58);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CUserTaskDetail::vftable;
    *(undefined4 *)(puVar1 + 1) = param_1;
    FUN_1403bc000(puVar1 + 2);
    *(undefined4 *)(puVar1 + 10) = 0;
    FUN_1403ba1f0(puVar1 + 2);
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pUserTaskDetail",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usertaskdetail.cpp"
                       ,0x109);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

