// ==== CTexasHoldEm::helper_140214de0  @140214de0  [medium:callgraph-r0]  (orig: FUN_140214de0)
ulonglong FUN_140214de0(longlong param_1,uint param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  ulonglong extraout_RAX;
  ulonglong uVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  ulonglong local_10;
  
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0xd0))[1];
  cVar1 = *(char *)((longlong)puVar10 + 0x2d);
  puVar5 = *(undefined8 **)(param_1 + 0xd0);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar10[2];
      puVar10 = puVar5;
    }
    else {
      puVar7 = (undefined8 *)*puVar10;
    }
    puVar5 = puVar10;
    puVar10 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x2d);
  }
  puVar10 = *(undefined8 **)(param_1 + 0xd0);
  local_30 = puVar5;
  local_38 = *(longlong *)(param_1 + 0xa0);
  if (*(longlong *)(param_1 + 0xa0) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar10) || (param_2 < *(uint *)(puVar5 + 3))) {
    plVar9 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xd0);
    local_28 = *(longlong *)(param_1 + 0xa0);
  }
  else {
    plVar9 = &local_38;
  }
  plVar3 = (longlong *)*plVar9;
  uVar4 = *(ulonglong *)(param_1 + 0xd0);
  local_18 = plVar3;
  uVar8 = plVar9[1];
  local_10 = uVar8;
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0xa0))) {
    _invalid_parameter_noinfo();
    uVar8 = extraout_RAX;
  }
  uVar6 = local_10;
  if (local_10 == uVar4) {
    uVar8 = uVar8 & 0xffffffffffffff00;
  }
  else {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = 0;
    }
    else {
      lVar11 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *param_3 = *(undefined4 *)(uVar6 + 0x1c);
    param_3[1] = *(undefined4 *)(uVar6 + 0x20);
    param_3[2] = *(undefined4 *)(uVar6 + 0x24);
    uVar2 = *(undefined4 *)(uVar6 + 0x28);
    param_3[3] = uVar2;
    uVar8 = CONCAT71((uint7)(uint3)((uint)uVar2 >> 8),1);
  }
  return uVar8;
}

// ==== CTexasHoldEm::Create  @1403bfef0  [high:log-string]  (orig: FUN_1403bfef0)
undefined8 FUN_1403bfef0(longlong param_1,longlong *param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  longlong lVar4;
  char *_Str;
  char *pcVar5;
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
  _Str = (char *)0x0;
  pcVar5 = *(char **)(lVar4 + 0x110);
  if (*(char **)(lVar4 + 0x110) == (char *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    pcVar5 = _Str;
  }
  *(char **)(param_1 + 0x220) = pcVar5;
  if ((pcVar5 == (char *)0x0) || (param_2 == (longlong *)0x0)) {
    return 0;
  }
  *(longlong **)(param_1 + 0x218) = param_2;
  uVar1 = (**(code **)(*param_2 + 8))(param_2);
  *(undefined4 *)(param_1 + 0x210) = uVar1;
  iVar3 = 0;
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar2 = iVar3;
  }
  else {
    iVar2 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x12);
  }
  *(int *)(param_1 + 0x1b4) = iVar2;
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar2 = iVar3;
  }
  else {
    iVar2 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x13);
  }
  *(uint *)(param_1 + 0x1b8) = (uint)(iVar2 != 0);
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar2 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x14);
    if (iVar2 != 0) {
      if (param_2[0xc] == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        iVar2 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x14);
        if (iVar2 == 1) goto LAB_1403c0043;
      }
      FUN_1400872b0(param_2,0x14);
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogERROR("CTexasHoldEm::Create(). NpcOwner[%u] TexaMoneyType[%d] not Found");
      return 0;
    }
  }
LAB_1403c0043:
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar3 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x14);
  }
  *(int *)(param_1 + 0x1bc) = iVar3;
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar3 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x15);
    if (0 < iVar3) {
      uVar1 = FUN_1400872b0(param_2,0x15);
      *(undefined4 *)(param_1 + 0x1c0) = uVar1;
    }
  }
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    _Str = (char *)(**(code **)(*(longlong *)param_2[0xc] + 0x18))((longlong *)param_2[0xc],0x16);
  }
  iVar3 = atoi(_Str);
  if (7 < iVar3 - 2U) {
    if (iVar3 != 0) {
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogERROR("CTexasHoldEm::Create(). NpcOwner[%u] MinCard[%d] not in [2, 9]");
    }
    return 1;
  }
  *(char *)(param_1 + 0x1c4) = (char)iVar3;
  return 1;
}

// ==== CTexasHoldEm::Create  @1403c0230  [high:log-string]  (orig: FUN_1403c0230)
undefined8 FUN_1403c0230(longlong param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 uVar3;
  int local_18;
  int local_14;
  int local_10;
  undefined4 local_c;
  
  *(int *)(param_1 + 0x210) = param_2;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_18 = 0;
    local_14 = 0;
    local_10 = 0;
    local_c = 0;
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
    lVar2 = *(longlong *)(lVar2 + 0x108);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar2 = 0;
    }
    cVar1 = FUN_140214de0(lVar2,param_3,&local_18);
    if (cVar1 != '\0') {
      *(undefined4 *)(param_1 + 0x290) = param_3;
      if ((((local_14 != 0) && (local_14 != 1)) || ((local_18 != 0 && (local_18 != 1)))) ||
         (local_10 < 1)) {
        log_InlineLogERROR("CTexasHoldEm::Create. TexasNpc[%u] ConfigID[%u]");
        return 0;
      }
      uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
      lVar2 = FUN_1401600a0(uVar3);
      *(longlong *)(param_1 + 0x220) = lVar2;
      if (lVar2 != 0) {
        *(int *)(param_1 + 0x1b4) = param_2;
        *(int *)(param_1 + 0x1b8) = local_14;
        *(int *)(param_1 + 0x1bc) = local_18;
        *(int *)(param_1 + 0x1c0) = local_10;
        if ((byte)((char)local_c - 2U) < 8) {
          *(char *)(param_1 + 0x1c4) = (char)local_c;
          return 1;
        }
        if ((char)local_c != '\0') {
          log_InlineLogERROR(
                            "CTexasHoldEm::Create(). TexasNpc[%u] ConfigID[%u] MinCard[%d] not in [2, 9]"
                            );
        }
        return 1;
      }
    }
  }
  return 0;
}

