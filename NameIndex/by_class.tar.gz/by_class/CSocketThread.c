// ==== CSocketThread::ctor_or_dtor  @14002bb50  [high:vtable-assign]  (orig: FUN_14002bb50)
CThreadBase * FUN_14002bb50(CThreadBase *param_1,undefined8 param_2,undefined8 param_3)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CSocketThread::vftable;
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = param_2;
  *(undefined8 *)(param_1 + 0x50) = param_3;
  return param_1;
}

// ==== CSocketThread::ctor_or_dtor  @14002bbb0  [high:vtable-assign]  (orig: FUN_14002bbb0)
void FUN_14002bbb0(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CSocketThread::vftable;
                    /* WARNING: Could not recover jumptable at 0x00014002bbd0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CSocketThread::vfunc_4  @14002bbe0  [high:rtti-vtable]  (orig: FUN_14002bbe0)
undefined4 FUN_14002bbe0(CThreadBase *param_1,bool param_2)

{
  bool bVar1;
  char cVar2;
  longlong *plVar3;
  
  bVar1 = CThreadBase::CreateThread(param_1,"SocketThread",param_2);
  if (bVar1) {
    plVar3 = (longlong *)FUN_1404ff780();
    *(longlong **)(param_1 + 0x40) = plVar3;
    cVar2 = (**(code **)(*plVar3 + 8))
                      (plVar3,*(undefined8 *)(param_1 + 0x48),*(undefined8 *)(param_1 + 0x50));
    if (cVar2 != '\0') {
      return 1;
    }
    MessageBoxA((HWND)0x0,"CSocketThread::CreateThread failed","Conquer Online Server",0x10);
  }
  return 0;
}

// ==== CSocketThread::vfunc_1  @14002bc50  [high:rtti-vtable]  (orig: FUN_14002bc50)
void FUN_14002bc50(longlong param_1)

{
  if (*(longlong **)(param_1 + 0x40) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x28))();
  }
  *(undefined8 *)(param_1 + 0x40) = 0;
  return;
}

// ==== CSocketThread::vfunc_2  @14002bc80  [high:rtti-vtable]  (orig: FUN_14002bc80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14002bc80(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1024];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_418[0] = '\0';
  memset(local_418 + 1,0,0x3ff);
  (**(code **)(**(longlong **)(param_1 + 0x48) + 8))();
  _snprintf(local_418,0x3ff,"#%u: socket thread is up and running");
  lVar2 = -1;
  pcVar3 = local_418;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  local_428 = local_418;
  (**(code **)(**(longlong **)(param_1 + 0x48) + 0x50))
            (*(longlong **)(param_1 + 0x48),0,0x9c41,~(uint)lVar2);
  return;
}

// ==== CSocketThread::vfunc_3  @14002bd30  [high:rtti-vtable]  (orig: FUN_14002bd30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14002bd30(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  ulong uVar3;
  undefined1 auStack_4e8 [32];
  undefined1 *local_4c8;
  undefined4 *local_4c0;
  char local_4b8;
  char local_4b7;
  ulong local_4b4;
  longlong local_4b0;
  int local_4a8;
  undefined4 local_4a0 [4];
  undefined8 local_490;
  CTickAnalyst local_488 [24];
  CTickAnalyst local_470 [24];
  CTickAnalyst local_458 [32];
  undefined1 local_438 [1056];
  ulonglong local_18;
  
  local_490 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  local_4b0 = param_1;
  if ((DAT_1409759d0 & 1) == 0) {
    DAT_1409759d0 = DAT_1409759d0 | 1;
    DAT_1409759cc = tq::TimeGet(0);
  }
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x58))
                    (*(longlong **)(param_1 + 0x48),s___AVCSocketThread___140949888._20_4_);
  local_4b7 = cVar1;
  CTickAnalyst::CTickAnalyst(local_470,0x23);
  uVar2 = tq::TimeGet(0);
  local_4b4 = uVar2;
  if (cVar1 == '\0') {
    CTickAnalyst::CTickAnalyst(local_488,0x2a);
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x20))(*(longlong **)(param_1 + 0x40),uVar2);
    CTickAnalyst::~CTickAnalyst(local_488);
    if (uVar2 - DAT_1409759cc < 0x2711) {
      DAT_1409759cc = DAT_1409759cc + 0x4c;
    }
    else {
      log_InlineLogWARNING("resync CSocketKernel::OnTimer cumulative deviation %dms");
      DAT_1409759cc = uVar2;
    }
  }
  else {
    while( true ) {
      local_4c0 = local_4a0;
      local_4c8 = local_438;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x48))
                        (*(longlong **)(param_1 + 0x48),0xffffffff,0xffffffff,0x418);
      if (cVar1 == '\0') break;
      local_4b8 = 1;
      CTickAnalyst::CTickAnalyst(local_458,0x24);
      local_4c8 = (undefined1 *)CONCAT44(local_4c8._4_4_,local_4a0[0]);
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x10))();
      local_4b8 = cVar1;
      CTickAnalyst::~CTickAnalyst(local_458);
      if (cVar1 == '\0') {
        log_InlineLogERROR(
                          "CSocketThread::OnProcess ProcessMsg returned error with packet:%d, port:%d"
                          );
      }
    }
  }
  uVar3 = tq::TimeGet(0);
  local_4b0 = CONCAT44(local_4b0._4_4_,uVar3);
  local_4a8 = uVar3 - uVar2;
  LOCK();
  DAT_14097569c = DAT_14097569c + local_4a8;
  UNLOCK();
  LOCK();
  DAT_1409756a0 = DAT_1409756a0 + 1;
  UNLOCK();
  if (DAT_140975698 < local_4a8) {
    DAT_140975698 = local_4a8;
  }
  if ((int)(uVar3 - DAT_1409759cc) < 0x4c) {
    s___AVCSocketThread___140949888._20_4_ = 0x4c - (uVar3 - DAT_1409759cc);
  }
  else {
    s___AVCSocketThread___140949888[0x14] = '\0';
    s___AVCSocketThread___140949888[0x15] = '\0';
    s___AVCSocketThread___140949888[0x16] = '\0';
    s___AVCSocketThread___140949888[0x17] = '\0';
  }
  CTickAnalyst::~CTickAnalyst(local_470);
  return 1;
}

// ==== CSocketThread::ctor_or_dtor  @14002bf80  [high:vtable-assign]  (orig: FUN_14002bf80)
CThreadBase * FUN_14002bf80(CThreadBase *param_1,uint param_2)

{
  *(undefined ***)param_1 = CSocketThread::vftable;
  CThreadBase::~CThreadBase(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CSocketThread::helper_1404ff780  @1404ff780  [medium:callgraph-r0]  (orig: FUN_1404ff780)
undefined8 FUN_1404ff780(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  pvVar1 = operator_new(0x218);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1404ff630(pvVar1);
  }
  return uVar2;
}

