// ==== CWeaponSkillUp::helper_140067c60  @140067c60  [medium:callgraph-r2]  (orig: FUN_140067c60)
void FUN_140067c60(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x21) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CWeaponSkillUp::helper_1400680f0  @1400680f0  [medium:callgraph-r2]  (orig: FUN_1400680f0)
void FUN_1400680f0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x21) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x21) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x21);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x21);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x21);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x21);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140068114. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CWeaponSkillUp::helper_140069ba0  @140069ba0  [medium:callgraph-r2]  (orig: FUN_140069ba0)
void FUN_140069ba0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x21) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CWeaponSkillUp::helper_14006a700  @14006a700  [medium:callgraph-r2]  (orig: FUN_14006a700)
void FUN_14006a700(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x21);
  while (cVar1 == '\0') {
    FUN_14006a700(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x21);
  }
  return;
}

// ==== CWeaponSkillUp::helper_14006b180  @14006b180  [medium:callgraph-r1]  (orig: FUN_14006b180)
undefined8 * FUN_14006b180(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x21) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1400680f0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x21) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 4;
        plVar8 = plVar8 + 4;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14006b36c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x21);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x21);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14006b36c:
  if ((char)plVar2[4] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[4] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_140069ba0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(*plVar9 + 0x20) != '\x01') || (*(char *)(plVar9[2] + 0x20) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x20) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_140067c60(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(plVar9[2] + 0x20) = 1;
              FUN_140069ba0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        else {
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_140067c60(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(plVar9[2] + 0x20) != '\x01') || (*(char *)(*plVar9 + 0x20) != '\x01')) {
              if (*(char *)(*plVar9 + 0x20) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_140069ba0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(*plVar9 + 0x20) = 1;
              FUN_140067c60(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 4) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CWeaponSkillUp::helper_14006b540  @14006b540  [medium:callgraph-r1]  (orig: FUN_14006b540)
void FUN_14006b540(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x21);
  while (cVar1 == '\0') {
    FUN_14006a700(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x21);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CWeaponSkillUp::helper_14006d2a0  @14006d2a0  [medium:callgraph-r0]  (orig: FUN_14006d2a0)
longlong * FUN_14006d2a0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14006b540(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x21) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x21);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x21);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x21);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x21);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14006b180(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CWeaponSkillUp::helper_1404c7330  @1404c7330  [medium:callgraph-r0]  (orig: FUN_1404c7330)
void FUN_1404c7330(void *param_1)

{
  if ((DAT_140976508 & 1) == 0) {
    DAT_140976508 = DAT_140976508 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976500,"CWeaponSkillUp");
    atexit((_func_5014 *)&LAB_1406d6f10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404c7385. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976500,param_1);
  return;
}

// ==== CWeaponSkillUp::helper_1404c74a0  @1404c74a0  [medium:callgraph-r2]  (orig: FUN_1404c74a0)
void FUN_1404c74a0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x61) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CWeaponSkillUp::helper_1404c7500  @1404c7500  [medium:callgraph-r2]  (orig: FUN_1404c7500)
void FUN_1404c7500(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x61) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CWeaponSkillUp::helper_1404c7570  @1404c7570  [medium:callgraph-r2]  (orig: FUN_1404c7570)
void FUN_1404c7570(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x61) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x61) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x61);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x61);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x61);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x61);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001404c7594. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CWeaponSkillUp::helper_1404c7870  @1404c7870  [medium:callgraph-r1]  (orig: FUN_1404c7870)
void FUN_1404c7870(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x68);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 0xc) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x61) = 0;
  return;
}

// ==== CWeaponSkillUp::helper_1404c89b0  @1404c89b0  [medium:callgraph-r1]  (orig: FUN_1404c89b0)
undefined8 * FUN_1404c89b0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong local_b8;
  undefined8 uStack_b0;
  longlong local_a8;
  undefined8 *puStack_a0;
  undefined8 local_98;
  undefined **local_90 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_78 [40];
  undefined1 local_50 [16];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  local_98 = 0xfffffffffffffffe;
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x61) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_90);
    local_90[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_78,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_90[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_90,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1404c7570(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x61) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0xc;
        plVar8 = plVar8 + 0xc;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1404c8b9d;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x61);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x61);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x61);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x61);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1404c8b9d:
  if ((char)plVar2[0xc] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0xc] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0xc] == '\0') {
            *(undefined1 *)(plVar9 + 0xc) = 1;
            *(undefined1 *)(plVar8 + 0xc) = 0;
            FUN_1404c74a0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
            if ((*(char *)(*plVar9 + 0x60) != '\x01') || (*(char *)(plVar9[2] + 0x60) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x60) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x60) = 1;
                *(undefined1 *)(plVar9 + 0xc) = 0;
                FUN_1404c7500(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0xc) = (char)plVar8[0xc];
              *(undefined1 *)(plVar8 + 0xc) = 1;
              *(undefined1 *)(plVar9[2] + 0x60) = 1;
              FUN_1404c74a0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xc) = 0;
          }
        }
        else {
          if ((char)plVar9[0xc] == '\0') {
            *(undefined1 *)(plVar9 + 0xc) = 1;
            *(undefined1 *)(plVar8 + 0xc) = 0;
            FUN_1404c7500(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
            if ((*(char *)(plVar9[2] + 0x60) != '\x01') || (*(char *)(*plVar9 + 0x60) != '\x01')) {
              if (*(char *)(*plVar9 + 0x60) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x60) = 1;
                *(undefined1 *)(plVar9 + 0xc) = 0;
                FUN_1404c74a0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0xc) = (char)plVar8[0xc];
              *(undefined1 *)(plVar8 + 0xc) = 1;
              *(undefined1 *)(*plVar9 + 0x60) = 1;
              FUN_1404c7500(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xc) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0xc) = 1;
  }
  plVar9 = plVar2 + 4;
  puStack_a0 = (undefined8 *)plVar2[10];
  local_b8 = *plVar9;
  uStack_b0 = *puStack_a0;
  local_a8 = local_b8;
  FUN_14002da30(plVar9,local_50,&local_b8,&local_a8);
  operator_delete((void *)plVar2[10]);
  plVar2[10] = 0;
  plVar2[0xb] = 0;
  operator_delete((void *)*plVar9);
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CWeaponSkillUp::helper_1404c8df0  @1404c8df0  [medium:callgraph-r0]  (orig: FUN_1404c8df0)
void FUN_1404c8df0(undefined8 param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined1 local_18 [16];
  
  uVar5 = 0xfffffffffffffffe;
  cVar2 = *(char *)((longlong)param_2 + 0x61);
  while (cVar2 == '\0') {
    FUN_1404c8df0(param_1,param_2[2]);
    plVar3 = (longlong *)*param_2;
    plVar1 = param_2 + 4;
    puVar4 = (undefined8 *)param_2[10];
    local_58 = (undefined4)*plVar1;
    uStack_54 = (undefined4)((ulonglong)*plVar1 >> 0x20);
    uStack_50 = SUB84(puVar4,0);
    uStack_4c = (undefined4)((ulonglong)puVar4 >> 0x20);
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    uStack_40 = (undefined4)*puVar4;
    uStack_3c = (undefined4)((ulonglong)*puVar4 >> 0x20);
    local_28 = local_58;
    uStack_24 = uStack_54;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    FUN_14002da30(plVar1,local_18,&local_28,&local_38,uVar5);
    operator_delete((void *)param_2[10]);
    param_2[10] = 0;
    param_2[0xb] = 0;
    operator_delete((void *)*plVar1);
    operator_delete(param_2);
    param_2 = plVar3;
    cVar2 = *(char *)((longlong)plVar3 + 0x61);
  }
  return;
}

// ==== CWeaponSkillUp::helper_1404c9750  @1404c9750  [medium:callgraph-r0]  (orig: FUN_1404c9750)
longlong * FUN_1404c9750(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1404c8df0(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x61) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x61) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x61);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x61);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x61);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x61);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1404c89b0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CWeaponSkillUp::ctor_or_dtor  @1404ca140  [high:vtable-assign]  (orig: FUN_1404ca140)
void FUN_1404ca140(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  char cVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong lVar11;
  longlong *local_58;
  longlong *plStack_50;
  longlong *local_48;
  longlong *plStack_40;
  undefined1 local_38 [16];
  
  *param_1 = CWeaponSkillUp::vftable;
  plVar9 = *(longlong **)param_1[7];
  plVar4 = (longlong *)param_1[1];
  lVar11 = 0;
  local_48 = plVar4;
  plStack_40 = plVar9;
  while( true ) {
    plVar8 = (longlong *)param_1[7];
    if ((plVar4 == (longlong *)0x0) || (plVar4 != (longlong *)param_1[1])) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar8) break;
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = lVar11;
    }
    else {
      lVar10 = *plVar4;
    }
    if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar8 = *(longlong **)plVar9[10];
    plVar5 = (longlong *)plVar9[4];
    local_58 = plVar5;
    plStack_50 = plVar8;
    while( true ) {
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = lVar11;
      }
      else {
        lVar10 = *plVar4;
      }
      if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar6 = (longlong *)plVar9[10];
      if ((plVar5 == (longlong *)0x0) || (plVar5 != (longlong *)plVar9[4])) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == plVar6) break;
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = lVar11;
      }
      else {
        lVar10 = *plVar5;
      }
      if (plVar8 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar8[4] != 0) {
        (*(code *)**(undefined8 **)plVar8[4])((undefined8 *)plVar8[4],1);
        plVar8[4] = 0;
      }
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        plVar6 = (longlong *)plVar8[2];
        if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
          cVar3 = *(char *)(*plVar6 + 0x29);
          plVar8 = plVar6;
          plVar6 = (longlong *)*plVar6;
          while (plStack_50 = plVar8, cVar3 == '\0') {
            cVar3 = *(char *)(*plVar6 + 0x29);
            plVar8 = plVar6;
            plVar6 = (longlong *)*plVar6;
          }
        }
        else {
          cVar3 = *(char *)(plVar8[1] + 0x29);
          plVar7 = (longlong *)plVar8[1];
          plVar6 = plVar8;
          while ((plVar8 = plVar7, plStack_50 = plVar8, cVar3 == '\0' &&
                 (plVar6 == (longlong *)plVar8[2]))) {
            cVar3 = *(char *)(plVar8[1] + 0x29);
            plVar7 = (longlong *)plVar8[1];
            plVar6 = plVar8;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = lVar11;
    }
    else {
      lVar10 = *plVar4;
    }
    if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    cVar3 = *(char *)((longlong)*(longlong **)(plVar9[10] + 8) + 0x29);
    plVar8 = *(longlong **)(plVar9[10] + 8);
    while (cVar3 == '\0') {
      FUN_14002ca30(plVar9 + 4,plVar8[2]);
      plVar5 = (longlong *)*plVar8;
      operator_delete(plVar8);
      plVar8 = plVar5;
      cVar3 = *(char *)((longlong)plVar5 + 0x29);
    }
    *(longlong *)(plVar9[10] + 8) = plVar9[10];
    plVar9[0xb] = 0;
    *(longlong *)plVar9[10] = plVar9[10];
    *(longlong *)(plVar9[10] + 0x10) = plVar9[10];
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
      plVar8 = (longlong *)plVar9[2];
      if (*(char *)((longlong)plVar8 + 0x61) == '\0') {
        cVar3 = *(char *)(*plVar8 + 0x61);
        plVar9 = plVar8;
        plVar8 = (longlong *)*plVar8;
        while (plStack_40 = plVar9, cVar3 == '\0') {
          cVar3 = *(char *)(*plVar8 + 0x61);
          plVar9 = plVar8;
          plVar8 = (longlong *)*plVar8;
        }
      }
      else {
        cVar3 = *(char *)(plVar9[1] + 0x61);
        plVar5 = (longlong *)plVar9[1];
        plVar8 = plVar9;
        while ((plVar9 = plVar5, plStack_40 = plVar9, cVar3 == '\0' &&
               (plVar8 == (longlong *)plVar9[2]))) {
          cVar3 = *(char *)(plVar9[1] + 0x61);
          plVar5 = (longlong *)plVar9[1];
          plVar8 = plVar9;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  puVar1 = param_1 + 1;
  FUN_1404c8df0(puVar1,*(undefined8 *)(param_1[7] + 8));
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  puVar2 = param_1 + 9;
  plStack_40 = (longlong *)param_1[0xf];
  local_58 = (longlong *)*puVar2;
  plStack_50 = (longlong *)*plStack_40;
  local_48 = local_58;
  FUN_14006d2a0(puVar2,local_38,&local_58,&local_48);
  operator_delete((void *)param_1[0xf]);
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  operator_delete((void *)*puVar2);
  plStack_40 = (longlong *)param_1[7];
  local_58 = (longlong *)*puVar1;
  plStack_50 = (longlong *)*plStack_40;
  local_48 = local_58;
  FUN_1404c9750(puVar1,local_38,&local_58,&local_48);
  operator_delete((void *)param_1[7]);
  param_1[7] = 0;
  param_1[8] = 0;
  operator_delete((void *)*puVar1);
  return;
}

// ==== CWeaponSkillUp::helper_1404ca500  @1404ca500  [medium:callgraph-r0]  (orig: FUN_1404ca500)
undefined8 * FUN_1404ca500(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1404c7870(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x61) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CWeaponSkillUp::ctor_or_dtor  @1404ca580  [high:vtable-assign]  (orig: FUN_1404ca580)
undefined8 * FUN_1404ca580(undefined8 *param_1)

{
  *param_1 = CWeaponSkillUp::vftable;
  FUN_1404ca500(param_1 + 1);
  FUN_140072180(param_1 + 9);
  return param_1;
}

// ==== CWeaponSkillUp::vfunc_0  @1404ca5c0  [high:rtti-vtable]  (orig: FUN_1404ca5c0)
undefined8 FUN_1404ca5c0(undefined8 param_1,uint param_2)

{
  FUN_1404ca140();
  if ((param_2 & 1) != 0) {
    FUN_1404c7330(param_1);
  }
  return param_1;
}

