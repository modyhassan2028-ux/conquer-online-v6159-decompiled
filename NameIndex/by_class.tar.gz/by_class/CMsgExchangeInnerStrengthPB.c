// ==== CMsgExchangeInnerStrengthPB::helper_140577620  @140577620  [medium:callgraph-r0]  (orig: FUN_140577620)
void FUN_140577620(longlong param_1,
                  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                  *param_2)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  undefined8 uVar1;
  
  *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 2;
  if (*(longlong *)(param_1 + 0x38) == DAT_140977388) {
    this = operator_new(0x28);
    if (this == (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
      uVar1 = 0;
    }
    else {
      uVar1 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    }
    *(undefined8 *)(param_1 + 0x38) = uVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x000140577681. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::assign
            (*(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)(param_1 + 0x38),
             param_2);
  return;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_3  @140577790  [high:rtti-vtable]  (orig: FUN_140577790)
void FUN_140577790(longlong param_1)

{
  if ((((*(uint *)(param_1 + 0x30) & 3) != 0) &&
      (*(undefined4 *)(param_1 + 0x40) = 0, (*(uint *)(param_1 + 0x30) >> 1 & 1) != 0)) &&
     (*(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)(param_1 + 0x38) !=
      (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)DAT_140977388)) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::clear
              (*(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)(param_1 + 0x38)
              );
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
                    /* WARNING: Could not recover jumptable at 0x0001405777ce. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::clear
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8));
  return;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_9  @1405777e0  [high:rtti-vtable]  (orig: FUN_1405777e0)
void FUN_1405777e0(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  if ((*(byte *)(param_1 + 0x30) & 1) != 0) {
    FUN_1405c8ee0(1,*(undefined4 *)(param_1 + 0x40),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 1 & 1) != 0) {
    FUN_1405c9580(2,*(undefined8 *)(param_1 + 0x38),param_2);
  }
  if (*(ulonglong *)(param_1 + 0x28) < 0x10) {
    lVar1 = param_1 + 0x10;
  }
  else {
    lVar1 = *(longlong *)(param_1 + 0x10);
  }
  FUN_14055a240(param_2,lVar1,*(ulonglong *)(param_1 + 0x20) & 0xffffffff);
  return;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_8  @140577850  [high:rtti-vtable]  (orig: FUN_140577850)
int FUN_140577850(longlong param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = 0;
  if (*(char *)(param_1 + 0x30) != '\0') {
    iVar3 = 1;
    if ((*(byte *)(param_1 + 0x30) & 1) != 0) {
      if (*(uint *)(param_1 + 0x40) < 0x80) {
        iVar4 = 1;
      }
      else {
        iVar4 = FUN_14055a8a0();
      }
      iVar4 = iVar4 + 1;
    }
    if ((*(uint *)(param_1 + 0x30) >> 1 & 1) != 0) {
      lVar1 = *(longlong *)(param_1 + 0x38);
      uVar2 = *(ulonglong *)(lVar1 + 0x18);
      if (0x7f < (uint)uVar2) {
        iVar3 = FUN_14055a8a0(uVar2 & 0xffffffff);
      }
      iVar4 = iVar4 + 1 + *(int *)(lVar1 + 0x18) + iVar3;
    }
  }
  iVar4 = iVar4 + *(int *)(param_1 + 0x20);
  *(int *)(param_1 + 0x34) = iVar4;
  return iVar4;
}

// ==== CMsgExchangeInnerStrengthPB::helper_1405778e0  @1405778e0  [medium:callgraph-r0]  (orig: FUN_1405778e0)
void FUN_1405778e0(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 local_res8 [8];
  undefined1 local_48 [64];
  
  if (param_2 == param_1) {
    local_res8[0] = 0;
    uVar2 = FUN_140556890(local_48,3,
                          "f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgexchangeinnerstrength.pb.cc"
                          ,0xf9,0,0xfffffffffffffffe);
    uVar2 = FUN_1405564f0(uVar2,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(local_res8,uVar2);
    FUN_140556900(local_48);
  }
  if (*(char *)(param_2 + 0x30) != '\0') {
    if ((*(byte *)(param_2 + 0x30) & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x40);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
      *(undefined4 *)(param_1 + 0x40) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 1 & 1) != 0) {
      FUN_140577620(param_1,*(undefined8 *)(param_2 + 0x38));
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0001405779ae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_4  @140577a00  [high:rtti-vtable]  (orig: FUN_140577a00)
undefined1 FUN_140577a00(void)

{
  return 1;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_1  @140577a10  [high:rtti-vtable]  (orig: FUN_140577a10)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_140577a10(undefined8 param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (param_2,"CMsgExchangeInnerStrengthPB");
  return param_2;
}

// ==== CMsgExchangeInnerStrengthPB::ctor_or_dtor  @140577a70  [high:vtable-assign]  (orig: FUN_140577a70)
undefined8 * FUN_140577a70(undefined8 *param_1)

{
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CMsgExchangeInnerStrengthPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140574260();
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_1[7] = DAT_140977388;
  *(undefined4 *)(param_1 + 6) = 0;
  return param_1;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_11  @140577ad0  [high:rtti-vtable]  (orig: FUN_140577ad0)
undefined4 FUN_140577ad0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x34);
}

// ==== CMsgExchangeInnerStrengthPB::ctor_or_dtor  @140577ae0  [high:vtable-assign]  (orig: FUN_140577ae0)
undefined8 *
FUN_140577ae0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CMsgExchangeInnerStrengthPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140574260();
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_1[7] = DAT_140977388;
  *(undefined4 *)(param_1 + 6) = 0;
  FUN_1405778e0(param_1,param_2,param_3,param_4,uVar1);
  return param_1;
}

// ==== CMsgExchangeInnerStrengthPB::ctor_or_dtor  @140577b60  [high:vtable-assign]  (orig: FUN_140577b60)
void FUN_140577b60(undefined8 *param_1)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  
  *param_1 = CMsgExchangeInnerStrengthPB::vftable;
  this = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)param_1[7];
  if ((this != DAT_140977388) &&
     (this != (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0)) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    operator_delete(this);
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140554130(param_1);
  return;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_2  @140577bd0  [high:rtti-vtable]  (orig: FUN_140577bd0)
undefined8 FUN_140577bd0(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  pvVar1 = operator_new(0x48);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_140577a70(pvVar1);
  }
  return uVar2;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_0  @140577d40  [high:rtti-vtable]  (orig: FUN_140577d40)
void * FUN_140577d40(void *param_1,uint param_2)

{
  FUN_140577b60();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_7  @140577da0  [high:rtti-vtable]  (orig: FUN_140577da0)
undefined8 FUN_140577da0(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  byte bVar1;
  byte *pbVar2;
  char *pcVar3;
  int iVar4;
  char cVar5;
  uint uVar6;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  undefined8 uVar7;
  ulonglong uVar8;
  undefined1 local_40 [16];
  undefined1 local_30 [40];
  
  FUN_14055c020(local_40,param_1 + 8,param_3,param_4,0xfffffffffffffffe);
  FUN_14055a0b0(local_30,local_40);
LAB_140577de0:
  while ((pbVar2 = *(byte **)(param_2 + 8), *(byte **)(param_2 + 0x10) <= pbVar2 ||
         (bVar1 = *pbVar2, (char)bVar1 < '\x01'))) {
    uVar6 = FUN_140559720(param_2);
    uVar8 = (ulonglong)uVar6;
    *(uint *)(param_2 + 0x20) = uVar6;
    if (uVar6 - 1 < 0x7f) goto LAB_140577e1d;
LAB_140577efd:
    if (((int)uVar8 == 0) || (((byte)uVar8 & 7) == 4)) goto LAB_140577f45;
    cVar5 = FUN_1405c88b0(param_2,uVar8,local_30);
    if (cVar5 == '\0') {
LAB_140577f2c:
      FUN_14055a130(local_30);
      FUN_14055c070(local_40);
      return 0;
    }
  }
  uVar8 = (ulonglong)bVar1;
  *(uint *)(param_2 + 0x20) = (uint)bVar1;
  *(byte **)(param_2 + 8) = pbVar2 + 1;
LAB_140577e1d:
  iVar4 = (int)(uVar8 >> 3);
  if (iVar4 == 1) {
    if ((int)uVar8 != 8) goto LAB_140577efd;
    if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
       (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
      *(uint *)(param_1 + 0x40) = (uint)bVar1;
      *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
    }
    else {
      cVar5 = FUN_1405595b0(param_2);
      if (cVar5 == '\0') goto LAB_140577f2c;
    }
    *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
    pcVar3 = *(char **)(param_2 + 8);
    if ((*(char **)(param_2 + 0x10) <= pcVar3) || (*pcVar3 != '\x12')) goto LAB_140577de0;
    *(char **)(param_2 + 8) = pcVar3 + 1;
  }
  else if ((iVar4 != 2) || ((int)uVar8 != 0x12)) goto LAB_140577efd;
  *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 2;
  if (*(longlong *)(param_1 + 0x38) == DAT_140977388) {
    this = operator_new(0x28);
    if (this == (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    }
    *(undefined8 *)(param_1 + 0x38) = uVar7;
  }
  cVar5 = FUN_1405c9b40(param_2,*(undefined8 *)(param_1 + 0x38));
  if (cVar5 == '\0') goto LAB_140577f2c;
  if ((*(longlong *)(param_2 + 8) == *(longlong *)(param_2 + 0x10)) &&
     ((*(int *)(param_2 + 0x2c) != 0 || (*(int *)(param_2 + 0x18) == *(int *)(param_2 + 0x28))))) {
    *(undefined4 *)(param_2 + 0x20) = 0;
    *(undefined1 *)(param_2 + 0x24) = 1;
LAB_140577f45:
    FUN_14055a130(local_30);
    FUN_14055c070(local_40);
    return 1;
  }
  goto LAB_140577de0;
}

// ==== CMsgExchangeInnerStrengthPB::vfunc_6  @140577f70  [high:rtti-vtable]  (orig: thunk_FUN_1405778e0)
void thunk_FUN_1405778e0(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 auStackX_8 [8];
  undefined1 auStack_48 [64];
  
  if (param_2 == param_1) {
    auStackX_8[0] = 0;
    uVar2 = FUN_140556890(auStack_48,3,
                          "f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgexchangeinnerstrength.pb.cc"
                          ,0xf9,0,0xfffffffffffffffe);
    uVar2 = FUN_1405564f0(uVar2,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(auStackX_8,uVar2);
    FUN_140556900(auStack_48);
  }
  if (*(char *)(param_2 + 0x30) != '\0') {
    if ((*(byte *)(param_2 + 0x30) & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x40);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
      *(undefined4 *)(param_1 + 0x40) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 1 & 1) != 0) {
      FUN_140577620(param_1,*(undefined8 *)(param_2 + 0x38));
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0001405779ae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

