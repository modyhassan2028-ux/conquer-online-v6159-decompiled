// ==== CMsgTrainingVitalityProtect::helper_1402e72c0  @1402e72c0  [medium:callgraph-r0]  (orig: FUN_1402e72c0)
void FUN_1402e72c0(longlong param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  uint uVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  if (param_2 != (longlong *)0x0) {
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
    cVar1 = *(char *)((longlong)puVar7 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x78);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar7 + 3) < uVar5) {
        puVar8 = (undefined8 *)puVar7[2];
        puVar7 = puVar3;
      }
      else {
        puVar8 = (undefined8 *)*puVar7;
      }
      puVar3 = puVar7;
      puVar7 = puVar8;
      cVar1 = *(char *)((longlong)puVar8 + 0x29);
    }
    puVar7 = *(undefined8 **)(param_1 + 0x78);
    local_30 = puVar3;
    local_38 = *(longlong *)(param_1 + 0x48);
    if (*(longlong *)(param_1 + 0x48) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar7) || (uVar5 < *(uint *)(puVar3 + 3))) {
      plVar6 = &local_28;
      local_20 = *(undefined8 *)(param_1 + 0x78);
      local_28 = *(longlong *)(param_1 + 0x48);
    }
    else {
      plVar6 = &local_38;
    }
    plVar2 = (longlong *)*plVar6;
    lVar9 = *(longlong *)(param_1 + 0x78);
    local_18 = plVar2;
    local_10 = plVar6[1];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    lVar4 = local_10;
    if (local_10 != lVar9) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)(lVar4 + 0x20);
      if (lVar9 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_14047c1b0(lVar9,param_2);
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::helper_1402e7420  @1402e7420  [medium:callgraph-r0]  (orig: FUN_1402e7420)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1402e7420(longlong param_1,longlong *param_2,byte param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong lVar8;
  ulonglong uVar9;
  undefined8 *puVar10;
  longlong *plVar11;
  undefined8 *puVar12;
  longlong lVar13;
  longlong *local_68;
  longlong local_60;
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  undefined8 local_30;
  
  if (param_2 != (longlong *)0x0) {
    local_30 = 0xfffffffffffffffe;
    uVar5 = FUN_1401649c0(param_2);
    if (*(uint *)(param_1 + 0xb0) <= uVar5) {
      uVar5 = (**(code **)(*param_2 + 8))(param_2);
      puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
      cVar4 = *(char *)((longlong)puVar12 + 0x29);
      puVar2 = *(undefined8 **)(param_1 + 0x38);
      while (cVar4 == '\0') {
        if (*(uint *)(puVar12 + 3) < uVar5) {
          puVar10 = (undefined8 *)puVar12[2];
          puVar12 = puVar2;
        }
        else {
          puVar10 = (undefined8 *)*puVar12;
        }
        puVar2 = puVar12;
        puVar12 = puVar10;
        cVar4 = *(char *)((longlong)puVar10 + 0x29);
      }
      local_50 = puVar2;
      local_58 = *(longlong *)(param_1 + 8);
      puVar12 = *(undefined8 **)(param_1 + 0x38);
      if (*(longlong *)(param_1 + 8) == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar2 == puVar12) || (uVar5 < *(uint *)(puVar2 + 3))) {
        local_40 = *(undefined8 *)(param_1 + 0x38);
        local_48 = *(longlong *)(param_1 + 8);
        plVar11 = &local_48;
      }
      else {
        plVar11 = &local_58;
      }
      plVar1 = (longlong *)*plVar11;
      local_60 = plVar11[1];
      lVar8 = *(longlong *)(param_1 + 0x38);
      local_68 = plVar1;
      if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
        _invalid_parameter_noinfo();
      }
      lVar3 = local_60;
      if (local_60 != lVar8) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar8 = 0;
        }
        else {
          lVar8 = *plVar1;
        }
        lVar13 = 0;
        if (lVar3 == *(longlong *)(lVar8 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar8 = *(longlong *)(lVar3 + 0x20);
        if ((lVar8 != 0) && (cVar4 = FUN_140477c00(lVar8,param_3), cVar4 != '\0')) {
          cVar4 = FUN_140338940(param_2,0x2ddbb0,0x2ddbb0,1);
          if (cVar4 == '\0') {
            uVar5 = FUN_140166bf0(param_2);
            if (uVar5 < *(uint *)(param_1 + 0xb8)) {
              return;
            }
            FUN_140166c00(param_2,uVar5 - *(uint *)(param_1 + 0xb8),1);
          }
          else {
            cVar4 = FUN_140350360(param_2,0x2ddbb0,0x2ddbb0,1);
            if (cVar4 == '\0') {
              return;
            }
          }
          uVar6 = FUN_140477350(lVar8,param_3,1);
          FUN_140477350(lVar8,param_3,2);
          FUN_140477350(lVar8,param_3,3);
          FUN_140477350(lVar8,param_3,4);
          uVar7 = (**(code **)(*param_2 + 8))(param_2);
          local_58 = CONCAT44(local_58._4_4_,uVar7);
          FUN_1402e5ee0(param_1 + 0x48,&local_68,&local_58);
          plVar11 = local_68;
          local_58 = *(longlong *)(param_1 + 0x78);
          if ((local_68 == (longlong *)0x0) || (local_68 != *(longlong **)(param_1 + 0x48))) {
            _invalid_parameter_noinfo();
          }
          lVar8 = local_60;
          if (local_60 == local_58) {
            uVar7 = (**(code **)(*param_2 + 8))(param_2);
            lVar8 = FUN_14047dc70(*(undefined4 *)(param_1 + 0x88),uVar7);
            if (lVar8 == 0) {
              log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pUserFateProtect",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\trainingvitality\\trainingvitalitymgr.cpp"
                                );
              return;
            }
            cVar4 = FUN_14047cbc0(lVar8,param_2,param_3,uVar6);
            if (cVar4 == '\0') {
              FUN_14047c830(lVar8);
              return;
            }
            uVar6 = (**(code **)(*param_2 + 8))(param_2);
            local_68 = (longlong *)CONCAT44(local_68._4_4_,uVar6);
            local_60 = lVar8;
            FUN_1402e5970(param_1 + 0x48,&local_48,&local_68);
          }
          else {
            if (plVar11 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            else {
              lVar13 = *plVar11;
            }
            if (lVar8 == *(longlong *)(lVar13 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            lVar8 = *(longlong *)(lVar8 + 0x20);
            if (lVar8 == 0) {
              log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pUserFateProtect",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\trainingvitality\\trainingvitalitymgr.cpp"
                                );
              return;
            }
            cVar4 = FUN_14047cbc0(lVar8,param_2,param_3,uVar6);
            if (cVar4 == '\0') {
              return;
            }
          }
          uVar9 = (**(code **)(*param_2 + 8))(param_2);
          tq::MyLogSave("gmlog/TrainingVitality",
                        "Protect User Fate Attrib. UserID(%u) FateNo(%u), AttribAndValue1(%u),AttribAndValue2(%u),AttribAndValue3(%u),AttribAndValue4(%u), CostItemNum(%u)"
                        ,uVar9 & 0xffffffff,(ulonglong)param_3);
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::helper_1402e7880  @1402e7880  [medium:callgraph-r0]  (orig: FUN_1402e7880)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402e7880(longlong param_1,longlong *param_2,undefined1 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  longlong lVar4;
  char cVar5;
  uint uVar6;
  longlong lVar7;
  __time64_t _Var8;
  undefined8 *puVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  longlong lVar12;
  undefined1 auStack_508 [32];
  undefined4 *local_4e8;
  undefined4 *local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d0;
  undefined4 local_4c8;
  undefined4 local_4c4;
  undefined4 local_4c0;
  undefined4 local_4bc;
  undefined4 local_4b8 [2];
  longlong *local_4b0;
  longlong local_4a8;
  longlong local_4a0;
  undefined8 local_498;
  longlong local_490;
  undefined8 *local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_480 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
    uVar6 = (**(code **)(*param_2 + 8))(param_2);
    puVar11 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar5 = *(char *)((longlong)puVar11 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x38);
    while (cVar5 == '\0') {
      if (*(uint *)(puVar11 + 3) < uVar6) {
        puVar9 = (undefined8 *)puVar11[2];
        puVar11 = puVar3;
      }
      else {
        puVar9 = (undefined8 *)*puVar11;
      }
      puVar3 = puVar11;
      puVar11 = puVar9;
      cVar5 = *(char *)((longlong)puVar9 + 0x29);
    }
    local_488 = puVar3;
    local_490 = *(longlong *)(param_1 + 8);
    puVar11 = *(undefined8 **)(param_1 + 0x38);
    if (*(longlong *)(param_1 + 8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar11) || (uVar6 < *(uint *)(puVar3 + 3))) {
      local_498 = *(undefined8 *)(param_1 + 0x38);
      local_4a0 = *(longlong *)(param_1 + 8);
      plVar10 = &local_4a0;
    }
    else {
      plVar10 = &local_490;
    }
    plVar1 = (longlong *)*plVar10;
    local_4a8 = plVar10[1];
    lVar12 = *(longlong *)(param_1 + 0x38);
    local_4b0 = plVar1;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    lVar2 = local_4a8;
    if (local_4a8 != lVar12) {
      lVar12 = 0;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar12;
      }
      else {
        lVar7 = *plVar1;
      }
      if (lVar2 == *(longlong *)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar2 = *(longlong *)(lVar2 + 0x20);
      if (lVar2 != 0) {
        local_4b8[0] = (**(code **)(*param_2 + 8))(param_2);
        FUN_1402e5ee0(param_1 + 0x48,&local_4b0,local_4b8);
        plVar10 = local_4b0;
        lVar7 = *(longlong *)(param_1 + 0x78);
        if ((local_4b0 == (longlong *)0x0) || (local_4b0 != *(longlong **)(param_1 + 0x48))) {
          _invalid_parameter_noinfo();
        }
        lVar4 = local_4a8;
        if (local_4a8 != lVar7) {
          if (plVar10 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar12 = *plVar10;
          }
          if (lVar4 == *(longlong *)(lVar12 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar12 = *(longlong *)(lVar4 + 0x20);
          if (lVar12 == 0) {
            local_4e8 = (undefined4 *)CONCAT44(local_4e8._4_4_,0x693);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            cVar5 = FUN_14047d1f0(lVar12,param_3);
            if (((cVar5 != '\0') && (lVar7 = FUN_14047ca90(lVar12,param_3), lVar7 != -1)) &&
               (_Var8 = _time64((__time64_t *)0x0), _Var8 < lVar7)) {
              local_4bc = 0;
              local_4c4 = 0;
              local_4c8 = 0;
              local_4c0 = 0;
              local_4e0 = &local_4c0;
              local_4e8 = &local_4c8;
              cVar5 = FUN_14047d9d0(lVar12,param_3,&local_4bc,&local_4c4);
              if (cVar5 != '\0') {
                local_4e0 = (undefined4 *)CONCAT44(local_4e0._4_4_,local_4c0);
                local_4e8 = (undefined4 *)CONCAT44(local_4e8._4_4_,local_4c8);
                FUN_140477740(lVar2,param_3,local_4bc,local_4c4);
                FUN_1402e6f70(param_1,param_2,param_3);
                FUN_140450dc0(local_478);
                cVar5 = FUN_140450e80(local_478,param_3,4);
                if (cVar5 != '\0') {
                  (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
                }
                (**(code **)(*param_2 + 8))(param_2);
                local_4d0 = local_4c0;
                local_4d8 = local_4c8;
                local_4e0 = (undefined4 *)CONCAT44(local_4e0._4_4_,local_4c4);
                local_4e8 = (undefined4 *)CONCAT44(local_4e8._4_4_,local_4bc);
                tq::MyLogSave("gmlog/TrainingVitality",
                              "Recover User Fate Attrib. UserID(%u) FateNo(%u), AttribAndValue1(%u),AttribAndValue2(%u),AttribAndValue3(%u),AttribAndValue4(%u)"
                             );
                FUN_140450e10(local_478);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::helper_1402e7bd0  @1402e7bd0  [medium:callgraph-r0]  (orig: FUN_1402e7bd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1402e7bd0(longlong param_1,longlong *param_2,undefined1 param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  longlong lVar6;
  __time64_t _Var7;
  undefined8 *puVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong lVar12;
  double dVar13;
  undefined1 auStack_4f8 [32];
  longlong local_4d8;
  int local_4d0;
  undefined4 local_4c8;
  uint local_4c0;
  longlong local_4b8;
  undefined8 local_4b0;
  longlong *local_4a8;
  longlong local_4a0;
  longlong local_498;
  undefined8 *local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_488 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
    uVar4 = (**(code **)(*param_2 + 8))(param_2);
    puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
    cVar3 = *(char *)((longlong)puVar10 + 0x29);
    puVar2 = *(undefined8 **)(param_1 + 0x78);
    while (cVar3 == '\0') {
      if (*(uint *)(puVar10 + 3) < uVar4) {
        puVar8 = (undefined8 *)puVar10[2];
        puVar10 = puVar2;
      }
      else {
        puVar8 = (undefined8 *)*puVar10;
      }
      puVar2 = puVar10;
      puVar10 = puVar8;
      cVar3 = *(char *)((longlong)puVar8 + 0x29);
    }
    local_490 = puVar2;
    local_498 = *(longlong *)(param_1 + 0x48);
    puVar10 = *(undefined8 **)(param_1 + 0x78);
    if (*(longlong *)(param_1 + 0x48) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar2 == puVar10) || (uVar4 < *(uint *)(puVar2 + 3))) {
      local_4b0 = *(undefined8 *)(param_1 + 0x78);
      local_4b8 = *(longlong *)(param_1 + 0x48);
      plVar9 = &local_4b8;
    }
    else {
      plVar9 = &local_498;
    }
    plVar1 = (longlong *)*plVar9;
    local_4a8 = plVar1;
    local_4a0 = plVar9[1];
    lVar11 = *(longlong *)(param_1 + 0x78);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    lVar6 = local_4a0;
    if (local_4a0 != lVar11) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar1;
      }
      if (lVar6 == *(longlong *)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar11 = *(longlong *)(lVar6 + 0x20);
      if (lVar11 == 0) {
        local_4d8 = CONCAT44(local_4d8._4_4_,0x6c7);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        cVar3 = FUN_14047d1f0(lVar11,param_3);
        if ((cVar3 != '\0') && (lVar6 = FUN_14047ca90(lVar11,param_3), lVar6 != -1)) {
          _Var7 = _time64((__time64_t *)0x0);
          lVar12 = _Var7 - lVar6;
          if (_Var7 - lVar6 < 1) {
            lVar12 = 0;
          }
          if (*(uint *)(param_1 + 0xb4) != 0) {
            uVar4 = *(uint *)(param_1 + 0xb8);
            dVar13 = ceil((((double)uVar4 / (double)*(uint *)(param_1 + 0xb4)) / _DAT_140727618) *
                          ((double)lVar12 / _DAT_140727618));
            uVar4 = uVar4 + (int)(longlong)dVar13;
            uVar5 = *(uint *)(param_1 + 0xbc);
            if ((uVar5 < uVar4) && (uVar5 != 0)) {
              uVar4 = uVar5;
            }
            uVar5 = FUN_140166bf0(param_2);
            if (uVar4 <= uVar5) {
              FUN_140166c00(param_2,uVar5 - uVar4,1);
              cVar3 = FUN_14047d4a0(lVar11,param_3,*(undefined4 *)(param_1 + 0xb4));
              if (cVar3 != '\0') {
                FUN_140450dc0(local_478);
                cVar3 = FUN_140450e80(local_478,param_3,6);
                if (cVar3 != '\0') {
                  (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
                }
                FUN_140450e10(local_478);
              }
              (**(code **)(*param_2 + 8))(param_2);
              local_4c8 = *(undefined4 *)(param_1 + 0xb8);
              local_4d8 = lVar12;
              local_4d0 = (int)(longlong)dVar13;
              local_4c0 = uVar4;
              tq::MyLogSave("gmlog/TrainingVitality",
                            "User Protect Renewal. UserID(%u) FateNo(%u) ArrearsTime(%I64) ArrearsCost(%u) ProtectCost(%u) TotalCost(%u)"
                           );
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::helper_1402e82e0  @1402e82e0  [medium:callgraph-r0]  (orig: FUN_1402e82e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402e82e0(longlong param_1,longlong *param_2,undefined1 param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  longlong local_4a8;
  undefined8 local_4a0;
  longlong *local_498;
  longlong local_490;
  longlong local_488;
  undefined8 *local_480;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_2 != (longlong *)0x0) {
    local_478 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
    cVar4 = *(char *)((longlong)puVar8 + 0x29);
    puVar2 = *(undefined8 **)(param_1 + 0x78);
    while (cVar4 == '\0') {
      if (*(uint *)(puVar8 + 3) < uVar5) {
        puVar6 = (undefined8 *)puVar8[2];
        puVar8 = puVar2;
      }
      else {
        puVar6 = (undefined8 *)*puVar8;
      }
      puVar2 = puVar8;
      puVar8 = puVar6;
      cVar4 = *(char *)((longlong)puVar6 + 0x29);
    }
    local_480 = puVar2;
    local_488 = *(longlong *)(param_1 + 0x48);
    puVar8 = *(undefined8 **)(param_1 + 0x78);
    if (*(longlong *)(param_1 + 0x48) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar2 == puVar8) || (uVar5 < *(uint *)(puVar2 + 3))) {
      local_4a0 = *(undefined8 *)(param_1 + 0x78);
      local_4a8 = *(longlong *)(param_1 + 0x48);
      plVar7 = &local_4a8;
    }
    else {
      plVar7 = &local_488;
    }
    plVar1 = (longlong *)*plVar7;
    local_498 = plVar1;
    local_490 = plVar7[1];
    lVar9 = *(longlong *)(param_1 + 0x78);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_490;
    if (local_490 != lVar9) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar1;
      }
      if (lVar3 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)(lVar3 + 0x20);
      if (lVar9 == 0) {
        local_4b8 = 0x760;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        cVar4 = FUN_14047d1f0(lVar9,param_3);
        if ((cVar4 != '\0') && (cVar4 = FUN_14047d650(lVar9,param_3), cVar4 != '\0')) {
          FUN_140450dc0(local_468);
          cVar4 = FUN_140450e80(local_468,param_3,10);
          if (cVar4 != '\0') {
            (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_468);
          }
          (**(code **)(*param_2 + 8))(param_2);
          tq::MyLogSave("gmlog/TrainingVitality","Delete User Protect Fate. UserID(%u) FateNo(%u)");
          FUN_140450e10(local_468);
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::helper_1402e84f0  @1402e84f0  [medium:callgraph-r0]  (orig: FUN_1402e84f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402e84f0(longlong param_1,longlong *param_2,undefined1 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  longlong lVar4;
  char cVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  undefined8 *puVar13;
  longlong lVar14;
  longlong lVar15;
  undefined1 auStack_4f8 [32];
  undefined4 local_4d8;
  undefined4 local_4d0;
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined4 local_4b8 [2];
  longlong *local_4b0;
  longlong local_4a8;
  longlong local_4a0;
  undefined8 *local_498;
  longlong local_490;
  undefined8 local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_480 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
    uVar6 = (**(code **)(*param_2 + 8))(param_2);
    puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
    cVar5 = *(char *)((longlong)puVar13 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x78);
    while (cVar5 == '\0') {
      if (*(uint *)(puVar13 + 3) < uVar6) {
        puVar11 = (undefined8 *)puVar13[2];
        puVar13 = puVar3;
      }
      else {
        puVar11 = (undefined8 *)*puVar13;
      }
      puVar3 = puVar13;
      puVar13 = puVar11;
      cVar5 = *(char *)((longlong)puVar11 + 0x29);
    }
    local_498 = puVar3;
    local_4a0 = *(longlong *)(param_1 + 0x48);
    puVar13 = *(undefined8 **)(param_1 + 0x78);
    if (*(longlong *)(param_1 + 0x48) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar13) || (uVar6 < *(uint *)(puVar3 + 3))) {
      local_488 = *(undefined8 *)(param_1 + 0x78);
      local_490 = *(longlong *)(param_1 + 0x48);
      plVar12 = &local_490;
    }
    else {
      plVar12 = &local_4a0;
    }
    plVar1 = (longlong *)*plVar12;
    local_4a8 = plVar12[1];
    lVar15 = *(longlong *)(param_1 + 0x78);
    local_4b0 = plVar1;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    lVar2 = local_4a8;
    if (local_4a8 != lVar15) {
      lVar15 = 0;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar14 = lVar15;
      }
      else {
        lVar14 = *plVar1;
      }
      if (lVar2 == *(longlong *)(lVar14 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar2 = *(longlong *)(lVar2 + 0x20);
      if (lVar2 == 0) {
        local_4d8 = 0x780;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        cVar5 = FUN_14047d1f0(lVar2,param_3);
        if (cVar5 != '\0') {
          local_4b8[0] = (**(code **)(*param_2 + 8))(param_2);
          FUN_1402e58a0(param_1 + 8,&local_4b0,local_4b8);
          plVar12 = local_4b0;
          lVar14 = *(longlong *)(param_1 + 0x38);
          if ((local_4b0 == (longlong *)0x0) || (local_4b0 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          lVar4 = local_4a8;
          if (local_4a8 != lVar14) {
            if (plVar12 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            else {
              lVar15 = *plVar12;
            }
            if (lVar4 == *(longlong *)(lVar15 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            lVar15 = *(longlong *)(lVar4 + 0x20);
            if ((lVar15 != 0) && (cVar5 = FUN_140477c00(lVar15,param_3), cVar5 != '\0')) {
              uVar7 = FUN_140477350(lVar15,param_3,1);
              uVar8 = FUN_140477350(lVar15,param_3,2);
              uVar9 = FUN_140477350(lVar15,param_3,3);
              uVar10 = FUN_140477350(lVar15,param_3,4);
              local_4d8 = uVar9;
              local_4d0 = uVar10;
              cVar5 = FUN_14047d7b0(lVar2,param_3,uVar7,uVar8);
              if (cVar5 != '\0') {
                FUN_140450dc0(local_478);
                cVar5 = FUN_140450e80(local_478,param_3,0xc);
                if (cVar5 != '\0') {
                  (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
                }
                (**(code **)(*param_2 + 8))(param_2);
                local_4d8 = uVar7;
                local_4d0 = uVar8;
                local_4c8 = uVar9;
                local_4c0 = uVar10;
                tq::MyLogSave("gmlog/TrainingVitality",
                              "Update User Protect Fate. UserID(%u) FateNo(%u) FateAttribAndValue1(%u)FateAttribAndValue2(%u) FateAttribAndValue3(%u) FateAttribAndValue4(%u)"
                             );
                FUN_140450e10(local_478);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::helper_1402e8800  @1402e8800  [medium:callgraph-r0]  (orig: FUN_1402e8800)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402e8800(longlong param_1,longlong *param_2,undefined1 param_3)

{
  longlong *plVar1;
  bool bVar2;
  undefined8 *puVar3;
  longlong lVar4;
  char cVar5;
  uint uVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  undefined4 uVar10;
  longlong lVar11;
  undefined2 uVar12;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  uint local_4c0;
  longlong local_4b8;
  undefined8 local_4b0;
  longlong *local_4a8;
  longlong local_4a0;
  longlong local_498;
  undefined8 *local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_488 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
    uVar6 = (**(code **)(*param_2 + 8))(param_2);
    puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
    cVar5 = *(char *)((longlong)puVar9 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x78);
    while (cVar5 == '\0') {
      if (*(uint *)(puVar9 + 3) < uVar6) {
        puVar7 = (undefined8 *)puVar9[2];
        puVar9 = puVar3;
      }
      else {
        puVar7 = (undefined8 *)*puVar9;
      }
      puVar3 = puVar9;
      puVar9 = puVar7;
      cVar5 = *(char *)((longlong)puVar7 + 0x29);
    }
    local_490 = puVar3;
    local_498 = *(longlong *)(param_1 + 0x48);
    puVar9 = *(undefined8 **)(param_1 + 0x78);
    if (*(longlong *)(param_1 + 0x48) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar9) || (uVar6 < *(uint *)(puVar3 + 3))) {
      local_4b0 = *(undefined8 *)(param_1 + 0x78);
      local_4b8 = *(longlong *)(param_1 + 0x48);
      plVar8 = &local_4b8;
    }
    else {
      plVar8 = &local_498;
    }
    plVar1 = (longlong *)*plVar8;
    local_4a8 = plVar1;
    local_4a0 = plVar8[1];
    lVar11 = *(longlong *)(param_1 + 0x78);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    lVar4 = local_4a0;
    if (local_4a0 != lVar11) {
      lVar11 = 0;
      uVar10 = 0;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar11 = *plVar1;
      }
      if (lVar4 == *(longlong *)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar11 = *(longlong *)(lVar4 + 0x20);
      if (lVar11 == 0) {
        local_4c8 = 0x7b5;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        cVar5 = FUN_14047d1f0(lVar11,param_3);
        if (cVar5 != '\0') {
          bVar2 = false;
          local_4c0 = local_4c0 & 0xffffff00;
          local_4c8 = 1;
          cVar5 = FUN_140338940(param_2,0x2ddbb0,0x2ddbb0,1);
          if (cVar5 == '\0') {
            uVar6 = FUN_140166bf0(param_2);
            if (uVar6 < *(uint *)(param_1 + 0xb8)) {
              return;
            }
            FUN_140166c00(param_2,uVar6 - *(uint *)(param_1 + 0xb8),1);
          }
          else {
            local_4c0 = local_4c0 & 0xffffff00;
            local_4c8 = 1;
            cVar5 = FUN_140350360(param_2,0x2ddbb0,0x2ddbb0,1);
            if (cVar5 == '\0') {
              return;
            }
            bVar2 = true;
            uVar10 = 1;
          }
          uVar12 = 0xe;
          if (bVar2) {
            uVar12 = 0x10;
          }
          cVar5 = FUN_14047d2d0(lVar11,param_3,*(undefined4 *)(param_1 + 0xb4));
          if (cVar5 != '\0') {
            FUN_140450dc0(local_478);
            cVar5 = FUN_140450e80(local_478,param_3,uVar12);
            if (cVar5 != '\0') {
              (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
            }
            FUN_140450e10(local_478);
          }
          (**(code **)(*param_2 + 8))(param_2);
          local_4c8 = *(undefined4 *)(param_1 + 0xb4);
          local_4c0 = uVar10;
          tq::MyLogSave("gmlog/TrainingVitality",
                        "User Fate Protect Delay. UserID(%u) FateNo(%u) Delay Hours(%u) itemNum(%u)"
                       );
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::ctor_or_dtor  @140450dc0  [high:vtable-assign]  (orig: FUN_140450dc0)
undefined8 * FUN_140450dc0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTrainingVitalityProtect::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTrainingVitalityProtect::ctor_or_dtor  @140450e10  [high:vtable-assign]  (orig: FUN_140450e10)
void FUN_140450e10(undefined8 *param_1)

{
  *param_1 = CMsgTrainingVitalityProtect::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTrainingVitalityProtect::vfunc_1  @140450e40  [high:rtti-vtable]  (orig: FUN_140450e40)
bool FUN_140450e40(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9e8;
    }
  }
  return false;
}

// ==== CMsgTrainingVitalityProtect::ctor_or_dtor  @140450ef0  [high:vtable-assign]  (orig: FUN_140450ef0)
undefined8 * FUN_140450ef0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTrainingVitalityProtect::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTrainingVitalityProtect::vfunc_3  @140450f40  [high:rtti-vtable]  (orig: FUN_140450f40)
void FUN_140450f40(longlong param_1)

{
  longlong lVar1;
  undefined2 *puVar2;
  char cVar3;
  longlong lVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x88))
                      (*(longlong **)(lVar4 + 0x90),param_1);
    if (lVar4 != 0) {
      cVar3 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x220))(lVar4 + 0x10);
      if (cVar3 == '\0') {
        pIVar5 = theInstance();
        lVar1 = *(longlong *)(lVar4 + 0x10);
        uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_DIE");
                    /* WARNING: Could not recover jumptable at 0x00014045100b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(lVar1 + 0x358))(lVar4 + 0x10,uVar6);
        return;
      }
      puVar2 = *(undefined2 **)(param_1 + 0x428);
      switch(*puVar2) {
      case 0:
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087ab0(uVar6);
        FUN_1402e72c0(uVar6,lVar4);
        return;
      case 1:
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087ab0(uVar6);
        FUN_1402e7420(uVar6,lVar4,*(undefined1 *)(puVar2 + 1));
        return;
      case 3:
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087ab0(uVar6);
        FUN_1402e7880(uVar6,lVar4,*(undefined1 *)(puVar2 + 1));
        return;
      case 5:
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087ab0(uVar6);
        FUN_1402e7bd0(uVar6,lVar4,*(undefined1 *)(puVar2 + 1));
        return;
      case 7:
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087ab0(uVar6);
        FUN_1402e7ec0(uVar6,lVar4,*(undefined1 *)(puVar2 + 1));
        return;
      case 9:
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087ab0(uVar6);
        FUN_1402e82e0(uVar6,lVar4,*(undefined1 *)(puVar2 + 1));
        return;
      case 0xb:
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087ab0(uVar6);
        FUN_1402e84f0(uVar6,lVar4,*(undefined1 *)(puVar2 + 1));
        return;
      case 0xd:
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087ab0(uVar6);
        FUN_1402e8800(uVar6,lVar4,*(undefined1 *)(puVar2 + 1));
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::helper_140477350  @140477350  [medium:callgraph-r1]  (orig: FUN_140477350)
undefined4 FUN_140477350(longlong param_1,char param_2,char param_3)

{
  undefined4 uVar1;
  longlong *plVar2;
  
  if (*(longlong *)(param_1 + 0x20) == 0) {
    return 0;
  }
  if (param_2 == '\x01') {
    if (param_3 == '\x01') {
      uVar1 = 2;
    }
    else if (param_3 == '\x02') {
      uVar1 = 3;
    }
    else if (param_3 == '\x03') {
      uVar1 = 4;
    }
    else {
      if (param_3 != '\x04') {
        return 0;
      }
      uVar1 = 5;
    }
  }
  else if (param_2 == '\x02') {
    if (param_3 == '\x01') {
      uVar1 = 6;
    }
    else if (param_3 == '\x02') {
      uVar1 = 7;
    }
    else if (param_3 == '\x03') {
      uVar1 = 8;
    }
    else {
      if (param_3 != '\x04') {
        return 0;
      }
      uVar1 = 9;
    }
  }
  else if (param_2 == '\x03') {
    if (param_3 == '\x01') {
      uVar1 = 10;
    }
    else if (param_3 == '\x02') {
      uVar1 = 0xb;
    }
    else if (param_3 == '\x03') {
      uVar1 = 0xc;
    }
    else {
      if (param_3 != '\x04') {
        return 0;
      }
      uVar1 = 0xd;
    }
  }
  else {
    if (param_2 != '\x04') {
      return 0;
    }
    if (param_3 == '\x01') {
      uVar1 = 0xe;
    }
    else if (param_3 == '\x02') {
      uVar1 = 0xf;
    }
    else if (param_3 == '\x03') {
      uVar1 = 0x10;
    }
    else {
      if (param_3 != '\x04') {
        return 0;
      }
      uVar1 = 0x11;
    }
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                     (*(longlong **)(param_1 + 0x20),uVar1);
  uVar1 = (**(code **)(*plVar2 + 0x50))(plVar2);
  return uVar1;
}

// ==== CMsgTrainingVitalityProtect::helper_14047c1b0  @14047c1b0  [medium:callgraph-r1]  (orig: FUN_14047c1b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14047c1b0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  char cVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong lVar16;
  longlong *plVar17;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  longlong local_498;
  longlong local_490;
  longlong *local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != 0) {
    local_480 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
    local_498 = param_1;
    local_490 = param_2;
    FUN_1404f6350(local_478);
    cVar2 = FUN_1404f6410(local_478);
    if (cVar2 == '\0') {
      FUN_1404f63a0(local_478);
    }
    else {
      plVar17 = (longlong *)**(undefined8 **)(param_1 + 0x40);
      plVar1 = *(longlong **)(param_1 + 0x10);
      while( true ) {
        plVar15 = *(longlong **)(param_1 + 0x40);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x10))) {
          _invalid_parameter_noinfo();
        }
        if (plVar17 == plVar15) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar16 = 0;
        }
        else {
          lVar16 = *plVar1;
        }
        if (plVar17 == *(longlong **)(lVar16 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar15 = (longlong *)plVar17[4];
        local_488 = plVar15;
        if (plVar15 != (longlong *)0x0) {
          plVar10 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,3);
          plVar11 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,7);
          plVar12 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,6);
          plVar13 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,5);
          plVar14 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,4);
          plVar15 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,2);
          uVar4 = (**(code **)(*plVar10 + 0x50))(plVar10);
          uVar5 = (**(code **)(*plVar11 + 0x50))(plVar11);
          uVar6 = (**(code **)(*plVar12 + 0x50))(plVar12);
          uVar7 = (**(code **)(*plVar13 + 0x50))(plVar13);
          uVar8 = (**(code **)(*plVar14 + 0x50))(plVar14);
          uVar3 = (**(code **)(*plVar15 + 0x20))(plVar15);
          local_4b8 = uVar6;
          local_4b0 = uVar5;
          local_4a8 = uVar4;
          cVar2 = FUN_1404f6460(local_478,uVar3,uVar8,uVar7);
          param_1 = local_498;
          if (cVar2 == '\0') {
            (**(code **)(*(longlong *)(local_490 + 0x10) + 0x350))
                      ((longlong *)(local_490 + 0x10),local_478);
            FUN_1404f6510(local_478);
            plVar15 = local_488;
            plVar10 = (longlong *)(**(code **)(*local_488 + 0x10))(local_488,3);
            plVar11 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,7);
            plVar12 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,6);
            plVar13 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,5);
            plVar14 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,4);
            plVar15 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,2);
            uVar4 = (**(code **)(*plVar10 + 0x50))(plVar10);
            uVar5 = (**(code **)(*plVar11 + 0x50))(plVar11);
            uVar6 = (**(code **)(*plVar12 + 0x50))(plVar12);
            uVar7 = (**(code **)(*plVar13 + 0x50))(plVar13);
            uVar8 = (**(code **)(*plVar14 + 0x50))(plVar14);
            uVar3 = (**(code **)(*plVar15 + 0x20))(plVar15);
            local_4b8 = uVar6;
            local_4b0 = uVar5;
            local_4a8 = uVar4;
            FUN_1404f6460(local_478,uVar3,uVar8,uVar7);
            param_1 = local_498;
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar17 + 0x29) == '\0') {
          plVar15 = (longlong *)plVar17[2];
          if (*(char *)((longlong)plVar15 + 0x29) == '\0') {
            cVar2 = *(char *)(*plVar15 + 0x29);
            plVar17 = plVar15;
            plVar15 = (longlong *)*plVar15;
            while (cVar2 == '\0') {
              cVar2 = *(char *)(*plVar15 + 0x29);
              plVar17 = plVar15;
              plVar15 = (longlong *)*plVar15;
            }
          }
          else {
            cVar2 = *(char *)(plVar17[1] + 0x29);
            plVar10 = (longlong *)plVar17[1];
            plVar15 = plVar17;
            while ((plVar17 = plVar10, cVar2 == '\0' && (plVar15 == (longlong *)plVar17[2]))) {
              cVar2 = *(char *)(plVar17[1] + 0x29);
              plVar10 = (longlong *)plVar17[1];
              plVar15 = plVar17;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      iVar9 = FUN_1404f6530(local_478);
      if (iVar9 != 0) {
        (**(code **)(*(longlong *)(local_490 + 0x10) + 0x350))
                  ((longlong *)(local_490 + 0x10),local_478);
      }
      FUN_1404f63a0(local_478);
    }
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::helper_14047d650  @14047d650  [medium:callgraph-r1]  (orig: FUN_14047d650)
undefined1 FUN_14047d650(longlong param_1,byte param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  char cVar5;
  undefined1 uVar6;
  undefined8 *puVar7;
  longlong **pplVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong *local_28;
  undefined8 *local_20;
  longlong *local_18;
  longlong *plStack_10;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar5 = *(char *)((longlong)puVar9 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x40);
  while (cVar5 == '\0') {
    if (*(byte *)(puVar9 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar9[2];
      puVar9 = puVar4;
    }
    else {
      puVar7 = (undefined8 *)*puVar9;
    }
    puVar4 = puVar9;
    puVar9 = puVar7;
    cVar5 = *(char *)((longlong)puVar7 + 0x29);
  }
  local_20 = puVar4;
  local_28 = *(longlong **)(param_1 + 0x10);
  puVar9 = *(undefined8 **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x10) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar9) || (param_2 < *(byte *)(puVar4 + 3))) {
    plStack_10 = (longlong *)*(undefined8 *)(param_1 + 0x40);
    local_18 = *(longlong **)(param_1 + 0x10);
    pplVar8 = &local_18;
  }
  else {
    pplVar8 = &local_28;
  }
  plVar1 = *pplVar8;
  plVar2 = pplVar8[1];
  plVar3 = *(longlong **)(param_1 + 0x40);
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  if (plVar2 == plVar3) {
    uVar6 = 0;
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (plVar2 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = (longlong *)plVar2[4];
    if (plVar3 == (longlong *)0x0) {
      uVar6 = 0;
    }
    else {
      cVar5 = (**(code **)(*plVar3 + 0x40))(plVar3,0);
      uVar6 = 0;
      if (cVar5 != '\0') {
        (**(code **)*plVar3)(plVar3,1);
        local_18 = plVar1;
        plStack_10 = plVar2;
        FUN_140154780(param_1 + 0x10,&local_28,&local_18);
        uVar6 = 1;
      }
    }
  }
  return uVar6;
}

// ==== CMsgTrainingVitalityProtect::helper_14047d7b0  @14047d7b0  [medium:callgraph-r1]  (orig: FUN_14047d7b0)
ulonglong FUN_14047d7b0(longlong param_1,byte param_2,int param_3,int param_4,int param_5,
                       int param_6)

{
  char cVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  int iVar4;
  undefined8 *puVar5;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong extraout_RAX_01;
  longlong *plVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  ulonglong local_20;
  
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar10 + 0x29);
  puVar2 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar10 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar10[2];
      puVar10 = puVar2;
    }
    else {
      puVar5 = (undefined8 *)*puVar10;
    }
    puVar2 = puVar10;
    puVar10 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar10 = *(undefined8 **)(param_1 + 0x40);
  local_40 = puVar2;
  local_48 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar10) || (param_2 < *(byte *)(puVar2 + 3))) {
    plVar9 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x40);
    local_38 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar9 = &local_48;
  }
  plVar6 = (longlong *)*plVar9;
  uVar8 = *(ulonglong *)(param_1 + 0x40);
  local_28 = plVar6;
  uVar7 = plVar9[1];
  local_20 = uVar7;
  if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
    uVar7 = extraout_RAX;
  }
  uVar3 = local_20;
  if (local_20 != uVar8) {
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = 0;
      uVar7 = extraout_RAX_00;
    }
    else {
      lVar11 = *plVar6;
    }
    if (uVar3 == *(ulonglong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
      uVar7 = extraout_RAX_01;
    }
    plVar9 = *(longlong **)(uVar3 + 0x20);
    if (plVar9 != (longlong *)0x0) {
      plVar6 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,4);
      iVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
      if (iVar4 == param_3) {
        plVar6 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,5);
        iVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
        if (iVar4 == param_4) {
          plVar6 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,6);
          iVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
          if (iVar4 == param_5) {
            plVar6 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,7);
            uVar7 = (**(code **)(*plVar6 + 0x50))(plVar6);
            if ((int)uVar7 == param_6) goto LAB_14047d87c;
          }
        }
      }
      plVar6 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,4);
      (**(code **)(*plVar6 + 0xa8))(plVar6,param_3);
      plVar6 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,5);
      (**(code **)(*plVar6 + 0xa8))(plVar6,param_4);
      plVar6 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,6);
      (**(code **)(*plVar6 + 0xa8))(plVar6,param_5);
      plVar6 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,7);
      (**(code **)(*plVar6 + 0xa8))(plVar6,param_6);
      uVar8 = (**(code **)(*plVar9 + 0x38))(plVar9,0);
      return uVar8;
    }
  }
LAB_14047d87c:
  return uVar7 & 0xffffffffffffff00;
}

// ==== CMsgTrainingVitalityProtect::helper_14047d9d0  @14047d9d0  [medium:callgraph-r1]  (orig: FUN_14047d9d0)
undefined8
FUN_14047d9d0(longlong param_1,byte param_2,undefined4 *param_3,undefined4 *param_4,
             undefined4 *param_5,undefined4 *param_6)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar2 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar2;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar2 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_40 = puVar2;
  local_48 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar8) || (param_2 < *(byte *)(puVar2 + 3))) {
    plVar7 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x40);
    local_38 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_48;
  }
  plVar6 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_28 = plVar6;
  local_20 = plVar7[1];
  if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_20;
  if (local_20 != lVar9) {
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar6;
    }
    if (lVar3 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = *(longlong **)(lVar3 + 0x20);
    if (plVar7 != (longlong *)0x0) {
      plVar6 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
      uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
      *param_3 = uVar4;
      plVar6 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,5);
      uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
      *param_4 = uVar4;
      plVar6 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,6);
      uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
      *param_5 = uVar4;
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,7);
      uVar4 = (**(code **)(*plVar7 + 0x50))(plVar7);
      *param_6 = uVar4;
      return 1;
    }
  }
  return 0;
}

// ==== CMsgTrainingVitalityProtect::helper_1404f6410  @1404f6410  [medium:callgraph-r2]  (orig: FUN_1404f6410)
ulonglong FUN_1404f6410(longlong param_1)

{
  undefined4 *puVar1;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  puVar1 = *(undefined4 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 8) = 0x9e9;
  *(undefined4 *)(param_1 + 0xc) = 4;
  *puVar1 = 0;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMsgTrainingVitalityProtect::helper_1404f6460  @1404f6460  [medium:callgraph-r2]  (orig: FUN_1404f6460)
ulonglong FUN_1404f6460(longlong param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  uint *puVar1;
  int *piVar2;
  ulonglong in_RAX;
  
  puVar1 = *(uint **)(param_1 + 0x428);
  if (puVar1 != (uint *)0x0) {
    in_RAX = (longlong)*(int *)(param_1 + 0xc) + 0x15;
    if (in_RAX < 0x3fc) {
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x15;
      *(undefined1 *)((ulonglong)*puVar1 * 0x15 + 4 + (longlong)puVar1) = param_2;
      *(undefined4 *)
       ((ulonglong)**(uint **)(param_1 + 0x428) * 0x15 + 9 + (longlong)*(uint **)(param_1 + 0x428))
           = param_3;
      *(undefined4 *)
       ((ulonglong)**(uint **)(param_1 + 0x428) * 0x15 + 0xd + (longlong)*(uint **)(param_1 + 0x428)
       ) = param_4;
      *(undefined4 *)
       ((ulonglong)**(uint **)(param_1 + 0x428) * 0x15 + 0x11 +
       (longlong)*(uint **)(param_1 + 0x428)) = param_5;
      *(undefined4 *)
       (((ulonglong)**(uint **)(param_1 + 0x428) + 1) * 0x15 + (longlong)*(uint **)(param_1 + 0x428)
       ) = param_6;
      *(undefined4 *)
       ((ulonglong)**(uint **)(param_1 + 0x428) * 0x15 + 5 + (longlong)*(uint **)(param_1 + 0x428))
           = param_7;
      piVar2 = *(int **)(param_1 + 0x428);
      *piVar2 = *piVar2 + 1;
      return CONCAT71((int7)((ulonglong)piVar2 >> 8),1);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgTrainingVitalityProtect::helper_1404f6510  @1404f6510  [medium:callgraph-r2]  (orig: FUN_1404f6510)
void FUN_1404f6510(longlong param_1)

{
  if (*(undefined4 **)(param_1 + 0x428) != (undefined4 *)0x0) {
    *(undefined4 *)(param_1 + 0xc) = 4;
    **(undefined4 **)(param_1 + 0x428) = 0;
  }
  return;
}

// ==== CMsgTrainingVitalityProtect::helper_1404f6530  @1404f6530  [medium:callgraph-r2]  (orig: FUN_1404f6530)
undefined4 FUN_1404f6530(longlong param_1)

{
  if (*(undefined4 **)(param_1 + 0x428) == (undefined4 *)0x0) {
    return 0;
  }
  return **(undefined4 **)(param_1 + 0x428);
}

