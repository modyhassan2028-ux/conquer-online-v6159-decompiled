// ==== COSMsgTalk::ctor_or_dtor  @140461620  [high:vtable-assign]  (orig: FUN_140461620)
undefined8 * FUN_140461620(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = COSMsgTalk::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x2d),0x3e1,true);
  return param_1;
}

// ==== COSMsgTalk::ctor_or_dtor  @1404616a0  [high:vtable-assign]  (orig: FUN_1404616a0)
void FUN_1404616a0(undefined8 *param_1)

{
  *param_1 = COSMsgTalk::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== COSMsgTalk::vfunc_1  @1404618b0  [high:rtti-vtable]  (orig: FUN_1404618b0)
undefined8 FUN_1404618b0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== COSMsgTalk::ctor_or_dtor  @1404618e0  [high:vtable-assign]  (orig: FUN_1404618e0)
undefined8 * FUN_1404618e0(undefined8 *param_1,uint param_2)

{
  *param_1 = COSMsgTalk::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== COSMsgTalk::vfunc_3  @140461940  [high:rtti-vtable]  (orig: FUN_140461940)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140461940(longlong param_1)

{
  char cVar1;
  short sVar2;
  uint uVar3;
  undefined4 *puVar4;
  longlong lVar5;
  char cVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  ulong uVar10;
  undefined8 uVar11;
  longlong *plVar12;
  longlong *plVar13;
  char *pcVar14;
  IStringManager *pIVar15;
  longlong *plVar16;
  longlong lVar17;
  ulonglong uVar18;
  undefined1 auStack_5d8 [32];
  char *local_5b8;
  undefined2 local_5a8;
  undefined2 local_5a6;
  undefined8 local_5a0;
  undefined **local_598 [130];
  char local_188 [336];
  ulonglong local_38;
  
  local_5a0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_5d8;
  local_188[0] = '\0';
  local_188[1] = '\0';
  local_188[2] = '\0';
  local_188[3] = '\0';
  local_188[4] = '\0';
  local_188[5] = '\0';
  local_188[6] = '\0';
  local_188[7] = '\0';
  local_188[8] = '\0';
  local_188[9] = '\0';
  local_188[10] = '\0';
  local_188[0xb] = '\0';
  local_188[0xc] = '\0';
  local_188[0xd] = '\0';
  local_188[0xe] = '\0';
  local_188[0xf] = 0;
  local_188[0x10] = 0;
  local_188[0x11] = '\0';
  local_188[0x12] = '\0';
  local_188[0x13] = '\0';
  local_188[0x14] = '\0';
  local_188[0x15] = '\0';
  local_188[0x16] = '\0';
  local_188[0x17] = '\0';
  local_188[0x18] = '\0';
  local_188[0x19] = '\0';
  local_188[0x1a] = '\0';
  local_188[0x1b] = '\0';
  local_188[0x1c] = '\0';
  local_188[0x1d] = '\0';
  local_188[0x1e] = '\0';
  local_188[0x1f] = 0;
  local_188[0x20] = 0;
  local_188[0x21] = '\0';
  local_188[0x22] = '\0';
  local_188[0x23] = '\0';
  local_188[0x24] = '\0';
  local_188[0x25] = '\0';
  local_188[0x26] = '\0';
  local_188[0x27] = '\0';
  local_188[0x28] = '\0';
  local_188[0x29] = '\0';
  local_188[0x2a] = '\0';
  local_188[0x2b] = '\0';
  local_188[0x2c] = '\0';
  local_188[0x2d] = '\0';
  local_188[0x2e] = '\0';
  local_188[0x2f] = 0;
  local_188[0x50] = 0;
  memset(local_188 + 0x51,0,0xff);
  local_188[0x30] = 0;
  local_188[0x31] = '\0';
  local_188[0x32] = '\0';
  local_188[0x33] = '\0';
  local_188[0x34] = '\0';
  local_188[0x35] = '\0';
  local_188[0x36] = '\0';
  local_188[0x37] = '\0';
  local_188[0x38] = '\0';
  local_188[0x39] = '\0';
  local_188[0x3a] = '\0';
  local_188[0x3b] = '\0';
  local_188[0x3c] = '\0';
  local_188[0x3d] = '\0';
  local_188[0x3e] = '\0';
  local_188[0x3f] = 0;
  local_188[0x40] = 0;
  local_188[0x41] = '\0';
  local_188[0x42] = '\0';
  local_188[0x43] = '\0';
  local_188[0x44] = '\0';
  local_188[0x45] = '\0';
  local_188[0x46] = '\0';
  local_188[0x47] = '\0';
  local_188[0x48] = '\0';
  local_188[0x49] = '\0';
  local_188[0x4a] = '\0';
  local_188[0x4b] = '\0';
  local_188[0x4c] = '\0';
  local_188[0x4d] = '\0';
  local_188[0x4e] = '\0';
  local_188[0x4f] = 0;
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_188,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),1,local_188 + 0x10,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),2,local_188 + 0x20,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),3,local_188 + 0x50,0x100);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),4,local_188 + 0x30,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),5,local_188 + 0x40,0x10);
  uVar18 = 0xffffffffffffffff;
  pcVar14 = local_188 + 0x50;
  do {
    if (uVar18 == 0) break;
    uVar18 = uVar18 - 1;
    cVar6 = *pcVar14;
    pcVar14 = pcVar14 + 1;
  } while (cVar6 != '\0');
  if (~uVar18 - 1 < 0x100) {
    sVar2 = *(short *)(*(longlong *)(param_1 + 0x428) + 8);
    if ((sVar2 == 0x961) || (sVar2 == 0x962)) {
      plVar12 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      (**(code **)(*plVar12 + 0x68))(plVar12,param_1,0xffffffff);
    }
    else {
      uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar12 = (longlong *)FUN_140087650(uVar11);
      plVar12 = (longlong *)(**(code **)(*plVar12 + 0x98))(plVar12,*(undefined4 *)(param_1 + 0x420))
      ;
      if (plVar12 != (longlong *)0x0) {
        plVar13 = (longlong *)FUN_1400e1e60();
        lVar5 = plVar12[0x1e2];
        lVar17 = *plVar13;
        puVar4 = *(undefined4 **)(param_1 + 0x428);
        uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
        (**(code **)(lVar17 + 0x108))(plVar13,uVar7,(int)lVar5,*puVar4);
        pcVar14 = (char *)(**(code **)(plVar12[2] + 0x18))(plVar12 + 2);
        lVar17 = -(longlong)pcVar14;
        do {
          cVar6 = *pcVar14;
          cVar1 = pcVar14[(longlong)(local_188 + lVar17)];
          if (cVar6 != cVar1) break;
          pcVar14 = pcVar14 + 1;
        } while (cVar1 != '\0');
        if ((cVar6 == cVar1) ||
           (cVar6 = (**(code **)(plVar12[2] + 0x230))(plVar12 + 2), cVar6 != '\0')) {
          cVar6 = (**(code **)(plVar12[2] + 0x228))(plVar12 + 2);
          if (cVar6 == '\0') {
            pIVar15 = theInstance();
            lVar17 = plVar12[2];
            uVar11 = (*(code *)**(undefined8 **)pIVar15)(pIVar15,"STR_CAN_NOT_TALK");
            (**(code **)(lVar17 + 0x358))(plVar12 + 2,uVar11);
          }
          else {
            cVar6 = FUN_1401765e0(plVar12,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8));
            if ((cVar6 == '\0') && ((int)plVar12[0x1f8] != 1)) {
              cVar6 = (**(code **)(plVar12[2] + 0x230))(plVar12 + 2);
              if (cVar6 != '\0') {
                local_5b8 = local_188 + 0x50;
                tq::GmLogSave("gm","-TALK %s->%s: %s",local_188,local_188 + 0x10);
              }
              uVar3 = *(uint *)(*(longlong *)(param_1 + 0x428) + 0x10);
              if ((uVar3 < 1000000) || (2000000 < uVar3)) {
                cVar6 = (**(code **)(plVar12[2] + 0x220))(plVar12 + 2);
                if (cVar6 == '\0') {
                  sVar2 = *(short *)(*(longlong *)(param_1 + 0x428) + 8);
                  if (sVar2 == 0x7d3) {
                    plVar13 = (longlong *)FUN_140118320();
                    if (plVar13 != (longlong *)0x0) {
                      lVar17 = *plVar13;
                      uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                      iVar8 = (**(code **)(lVar17 + 0x28))(plVar13,uVar7);
                      if (iVar8 != 0) {
                        lVar17 = *plVar13;
                        uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                        (**(code **)(lVar17 + 0x90))(plVar13,iVar8,param_1,uVar7);
                      }
                    }
                  }
                  else if (sVar2 == 0x7d4) {
                    plVar13 = (longlong *)FUN_140087ed0();
                    lVar17 = *plVar13;
                    uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                    (**(code **)(lVar17 + 0x30))(plVar13,uVar7,param_1);
                  }
                  else if (sVar2 == 0x7d6) {
                    plVar13 = (longlong *)CurrentInstanceGet();
                    plVar13 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,8);
                    if (plVar13 != (longlong *)0x0) {
                      lVar17 = *plVar13;
                      uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                      iVar8 = (**(code **)(lVar17 + 0x128))(plVar13,uVar7);
                      if (iVar8 != 0) {
                        local_598[0] = tq::CMsg::vftable;
                        tq::CMsg::Init((CMsg *)local_598);
                        local_5a6 = (undefined2)*(undefined4 *)(param_1 + 8);
                        local_5a8 = (undefined2)*(undefined4 *)(param_1 + 0xc);
                        tq::CMsg::Create((CMsg *)local_598,(MsgHead *)&local_5a8,
                                         (char *)(param_1 + 0x10));
                        lVar17 = *plVar13;
                        uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                        (**(code **)(lVar17 + 0x140))(plVar13,iVar8,local_598,uVar7);
                      }
                    }
                  }
                  else if (sVar2 == 0x7d9) {
                    plVar13 = (longlong *)FUN_1401183a0();
                    lVar17 = *plVar13;
                    uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                    (**(code **)(lVar17 + 0x178))(plVar13,uVar7,param_1);
                  }
                  else if (sVar2 == 0x7e9) {
                    plVar13 = (longlong *)FUN_140087ed0();
                    lVar17 = *plVar13;
                    uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                    (**(code **)(lVar17 + 0x38))(plVar13,uVar7,param_1);
                  }
                  else {
                    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = 0x7dd;
                    (**(code **)(plVar12[2] + 0x348))(plVar12 + 2,param_1,0);
                  }
                }
                else {
                  switch(*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8)) {
                  case 0x7d1:
                    uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                    plVar13 = (longlong *)FUN_140087650(uVar11);
                    plVar13 = (longlong *)(**(code **)(*plVar13 + 0x90))(plVar13,local_188 + 0x10,0)
                    ;
                    if (plVar13 == (longlong *)0x0) {
                      iVar8 = 0;
                      plVar13 = (longlong *)FUN_1401183a0();
                      lVar17 = *plVar13;
                      uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                      lVar17 = (**(code **)(lVar17 + 0x148))(plVar13,uVar7);
                      if (lVar17 != 0) {
                        do {
                          plVar13 = (longlong *)FUN_1401183a0();
                          lVar17 = *plVar13;
                          uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                          pcVar14 = (char *)(**(code **)(lVar17 + 0x160))(plVar13,uVar7,iVar8);
                          lVar17 = 0x10 - (longlong)pcVar14;
                          do {
                            cVar6 = *pcVar14;
                            cVar1 = pcVar14[(longlong)(local_188 + lVar17)];
                            if (cVar6 != cVar1) break;
                            pcVar14 = pcVar14 + 1;
                          } while (cVar1 != '\0');
                          if (cVar6 == cVar1) goto LAB_140462126;
                          iVar8 = iVar8 + 1;
                          plVar13 = (longlong *)FUN_1401183a0();
                          lVar17 = *plVar13;
                          uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                          uVar18 = (**(code **)(lVar17 + 0x148))(plVar13,uVar7);
                        } while ((ulonglong)(longlong)iVar8 < uVar18);
                      }
                      plVar13 = (longlong *)FUN_1400e1de0();
                      lVar17 = *plVar13;
                      uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                      (**(code **)(lVar17 + 0x40))(plVar13,uVar7,local_188 + 0x10);
LAB_140462126:
                      plVar13 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                      (**(code **)(*plVar13 + 0x90))
                                (plVar13,param_1,local_188 + 0x10,
                                 *(undefined4 *)((longlong)plVar12 + 0x122c));
                    }
                    else {
                      iVar8 = (**(code **)(plVar12[2] + 0x168))(plVar12 + 2);
                      if (iVar8 == 0x40c) {
                        if (DAT_140975c38 != 0) {
                          (**(code **)(*(longlong *)(DAT_140975c38 + 0x10) + 0x350))
                                    ((longlong *)(DAT_140975c38 + 0x10),param_1);
                        }
                      }
                      else if (iVar8 == 0x1772) {
                        plVar16 = (longlong *)FUN_1401183a0();
                        lVar17 = *plVar16;
                        uVar7 = (**(code **)(*plVar13 + 8))(plVar13);
                        uVar9 = (**(code **)(*plVar12 + 8))(plVar12);
                        cVar6 = (**(code **)(lVar17 + 0x170))(plVar16,uVar9,uVar7);
                        if (cVar6 == '\0') {
                          return;
                        }
                      }
                      uVar7 = (**(code **)(plVar12[2] + 0x30))(plVar12 + 2);
                      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = uVar7;
                      (**(code **)(plVar13[2] + 0x350))(plVar13 + 2,param_1);
                    }
                    break;
                  case 0x7d3:
                    plVar13 = (longlong *)FUN_140118320();
                    if (plVar13 != (longlong *)0x0) {
                      lVar17 = *plVar13;
                      uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                      iVar8 = (**(code **)(lVar17 + 0x28))(plVar13,uVar7);
                      if (iVar8 != 0) {
                        lVar17 = *plVar13;
                        uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                        (**(code **)(lVar17 + 0x90))(plVar13,iVar8,param_1,uVar7);
                      }
                    }
                    break;
                  case 0x7d4:
                    plVar13 = (longlong *)FUN_140087ed0();
                    lVar17 = *plVar13;
                    uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                    (**(code **)(lVar17 + 0x30))(plVar13,uVar7,param_1);
                    break;
                  case 0x7d6:
                    plVar13 = (longlong *)CurrentInstanceGet();
                    plVar13 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,8);
                    if (plVar13 != (longlong *)0x0) {
                      lVar17 = *plVar13;
                      uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                      iVar8 = (**(code **)(lVar17 + 0x128))(plVar13,uVar7);
                      if (iVar8 != 0) {
                        local_598[0] = tq::CMsg::vftable;
                        tq::CMsg::Init((CMsg *)local_598);
                        local_5a6 = (undefined2)*(undefined4 *)(param_1 + 8);
                        local_5a8 = (undefined2)*(undefined4 *)(param_1 + 0xc);
                        tq::CMsg::Create((CMsg *)local_598,(MsgHead *)&local_5a8,
                                         (char *)(param_1 + 0x10));
                        lVar17 = *plVar13;
                        uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                        (**(code **)(lVar17 + 0x140))(plVar13,iVar8,local_598,uVar7);
                      }
                    }
                    break;
                  case 0x7d9:
                    plVar13 = (longlong *)FUN_1401183a0();
                    lVar17 = *plVar13;
                    uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                    (**(code **)(lVar17 + 0x178))(plVar13,uVar7,param_1);
                    break;
                  case 0x7da:
                    cVar6 = (**(code **)(plVar12[2] + 0x230))(plVar12 + 2);
                    if (cVar6 != '\0') {
                      plVar12 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                      (**(code **)(*plVar12 + 0x68))(plVar12,param_1,0xffffffff);
                    }
                    break;
                  case 0x7de:
                    uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                    plVar12 = (longlong *)FUN_140087650(uVar11);
                    lVar17 = (**(code **)(*plVar12 + 0x88))(plVar12,param_1);
                    if (lVar17 != 0) {
                      cVar6 = (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x230))();
                      if (cVar6 == '\0') {
                        uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                        plVar12 = (longlong *)FUN_140087650(uVar11);
                        lVar17 = (**(code **)(*plVar12 + 0xc0))(plVar12);
                        if (lVar17 == 0) {
                          plVar12 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                          (**(code **)(*plVar12 + 0x98))(plVar12,param_1,&DAT_1406dd892);
                        }
                        else {
                          (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x350))
                                    ((longlong *)(lVar17 + 0x10),param_1);
                        }
                      }
                      else {
                        uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                        plVar12 = (longlong *)FUN_140087650(uVar11);
                        lVar17 = (**(code **)(*plVar12 + 0x90))(plVar12,local_188 + 0x10,0);
                        if (lVar17 == 0) {
                          plVar12 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                          (**(code **)(*plVar12 + 0x90))(plVar12,param_1,local_188 + 0x10,0);
                        }
                        else {
                          (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x350))
                                    ((longlong *)(lVar17 + 0x10),param_1);
                        }
                      }
                    }
                    break;
                  case 0x7e5:
                    cVar6 = FUN_140165590(plVar12);
                    if (cVar6 != '\0') {
                      uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                      lVar17 = FUN_1400875f0(uVar11);
                      if (lVar17 == 0) {
                        local_5b8 = (char *)CONCAT44(local_5b8._4_4_,0x225);
                        log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pRoleManager",
                                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\osmsgtalk.cpp"
                                          );
                      }
                      else {
                        plVar13 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                        (**(code **)(*plVar13 + 0x68))
                                  (plVar13,param_1,*(undefined4 *)((longlong)plVar12 + 0x122c));
                        uVar10 = tq::TimeGet(0);
                        FUN_140165670(plVar12,uVar10);
                      }
                    }
                    break;
                  case 0x7e9:
                    plVar13 = (longlong *)FUN_140087ed0();
                    lVar17 = *plVar13;
                    uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                    (**(code **)(lVar17 + 0x38))(plVar13,uVar7,param_1);
                    break;
                  case 0x838:
                    iVar8 = FUN_140166ec0(plVar12);
                    if (iVar8 != 0) {
                      iVar8 = tq::TalkStrCheck(local_188 + 0x50,0);
                      if (iVar8 == 0) {
                        pIVar15 = theInstance();
                        lVar17 = plVar12[2];
                        uVar11 = (*(code *)**(undefined8 **)pIVar15)(pIVar15,"STR_INVALID_MSG");
                        (**(code **)(lVar17 + 0x358))(plVar12 + 2,uVar11);
                      }
                      else {
                        plVar13 = (longlong *)FUN_1400f8360();
                        lVar17 = *plVar13;
                        uVar7 = FUN_140166ec0(plVar12);
                        (**(code **)(lVar17 + 0x48))(plVar13,uVar7,local_188 + 0x50);
                      }
                    }
                    break;
                  case 0x83e:
                    iVar8 = tq::TalkStrCheck(local_188 + 0x50,1);
                    if (iVar8 == 0) {
                      pIVar15 = theInstance();
                      lVar17 = plVar12[2];
                      uVar11 = (*(code *)**(undefined8 **)pIVar15)(pIVar15,"STR_INVALID_CHARACTER");
                      (**(code **)(lVar17 + 0x358))(plVar12 + 2,uVar11);
                    }
                    else {
                      plVar13 = (longlong *)FUN_1400e1de0();
                      lVar17 = *plVar13;
                      uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                      (**(code **)(lVar17 + 0x38))(plVar13,uVar7,local_188 + 0x10,local_188 + 0x50);
                    }
                    break;
                  case 0x899:
                    uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                    plVar12 = (longlong *)FUN_140087650(uVar11);
                    plVar12 = (longlong *)(**(code **)(*plVar12 + 0x88))(plVar12,param_1);
                    if (plVar12 != (longlong *)0x0) {
                      plVar13 = plVar12 + 2;
                      iVar8 = (**(code **)(*plVar13 + 0x70))(plVar13);
                      if (iVar8 < DAT_140949794) {
                        pIVar15 = theInstance();
                        lVar17 = *plVar13;
                        uVar11 = (*(code *)**(undefined8 **)pIVar15)(pIVar15,"STR_LOW_LEVEL");
                        (**(code **)(lVar17 + 0x358))(plVar13,uVar11);
                      }
                      else {
                        iVar8 = tq::TalkStrCheck(local_188 + 0x50,1);
                        if (iVar8 == 0) {
                          pIVar15 = theInstance();
                          lVar17 = *plVar13;
                          uVar11 = (*(code *)**(undefined8 **)pIVar15)
                                             (pIVar15,"STR_INVALID_CHARACTER");
                          (**(code **)(lVar17 + 0x358))(plVar13,uVar11);
                        }
                        else {
                          uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                          uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                          uVar11 = FUN_14015b100(uVar11);
                          FUN_14010b370(uVar11,uVar7,local_188,local_188 + 0x50);
                        }
                      }
                    }
                    break;
                  case 0x89a:
                    uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                    plVar12 = (longlong *)FUN_140087650(uVar11);
                    plVar12 = (longlong *)(**(code **)(*plVar12 + 0x88))(plVar12,param_1);
                    if (plVar12 != (longlong *)0x0) {
                      plVar13 = plVar12 + 2;
                      iVar8 = (**(code **)(*plVar13 + 0x70))(plVar13);
                      if (iVar8 < DAT_140949794) {
                        pIVar15 = theInstance();
                        lVar17 = *plVar13;
                        uVar11 = (*(code *)**(undefined8 **)pIVar15)(pIVar15,"STR_LOW_LEVEL");
                        (**(code **)(lVar17 + 0x358))(plVar13,uVar11);
                      }
                      else {
                        iVar8 = tq::TalkStrCheck(local_188 + 0x50,1);
                        if (iVar8 == 0) {
                          pIVar15 = theInstance();
                          lVar17 = *plVar13;
                          uVar11 = (*(code *)**(undefined8 **)pIVar15)
                                             (pIVar15,"STR_INVALID_CHARACTER");
                          (**(code **)(lVar17 + 0x358))(plVar13,uVar11);
                        }
                        else {
                          uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                          uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                          uVar11 = FUN_14015b150(uVar11);
                          FUN_14010b370(uVar11,uVar7,local_188,local_188 + 0x50);
                        }
                      }
                    }
                    break;
                  case 0x89b:
                    uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                    plVar12 = (longlong *)FUN_140087650(uVar11);
                    plVar12 = (longlong *)(**(code **)(*plVar12 + 0x88))(plVar12,param_1);
                    if (plVar12 != (longlong *)0x0) {
                      plVar13 = plVar12 + 2;
                      iVar8 = (**(code **)(*plVar13 + 0x70))(plVar13);
                      if (iVar8 < DAT_140949794) {
                        pIVar15 = theInstance();
                        lVar17 = *plVar13;
                        uVar11 = (*(code *)**(undefined8 **)pIVar15)(pIVar15,"STR_LOW_LEVEL");
                        (**(code **)(lVar17 + 0x358))(plVar13,uVar11);
                      }
                      else {
                        iVar8 = tq::TalkStrCheck(local_188 + 0x50,1);
                        if (iVar8 == 0) {
                          pIVar15 = theInstance();
                          lVar17 = *plVar13;
                          uVar11 = (*(code *)**(undefined8 **)pIVar15)
                                             (pIVar15,"STR_INVALID_CHARACTER");
                          (**(code **)(lVar17 + 0x358))(plVar13,uVar11);
                        }
                        else {
                          uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                          uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                          uVar11 = FUN_14015b1a0(uVar11);
                          FUN_14010b370(uVar11,uVar7,local_188,local_188 + 0x50);
                        }
                      }
                    }
                    break;
                  case 0x89c:
                    uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                    plVar12 = (longlong *)FUN_140087650(uVar11);
                    plVar12 = (longlong *)(**(code **)(*plVar12 + 0x88))(plVar12,param_1);
                    if (plVar12 != (longlong *)0x0) {
                      iVar8 = (**(code **)(plVar12[2] + 0x70))(plVar12 + 2);
                      if (iVar8 < DAT_140949794) {
                        pIVar15 = theInstance();
                        lVar17 = plVar12[2];
                        uVar11 = (*(code *)**(undefined8 **)pIVar15)(pIVar15,"STR_LOW_LEVEL");
                        (**(code **)(lVar17 + 0x358))(plVar12 + 2,uVar11);
                      }
                      else {
                        iVar8 = tq::TalkStrCheck(local_188 + 0x50,1);
                        if (iVar8 == 0) {
                          pIVar15 = theInstance();
                          lVar17 = plVar12[2];
                          uVar11 = (*(code *)**(undefined8 **)pIVar15)
                                             (pIVar15,"STR_INVALID_CHARACTER");
                          (**(code **)(lVar17 + 0x358))(plVar12 + 2,uVar11);
                        }
                        else {
                          plVar13 = (longlong *)FUN_140087ed0();
                          lVar17 = *plVar13;
                          uVar7 = (**(code **)(plVar12[2] + 0x170))(plVar12 + 2);
                          lVar17 = (**(code **)(lVar17 + 0x48))(plVar13,uVar7);
                          if (lVar17 != 0) {
                            uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                            FUN_14010b370(lVar17,uVar7,local_188,local_188 + 0x50);
                          }
                        }
                      }
                    }
                    break;
                  case 0x89d:
                    uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                    plVar12 = (longlong *)FUN_140087650(uVar11);
                    plVar12 = (longlong *)(**(code **)(*plVar12 + 0x88))(plVar12,param_1);
                    if (plVar12 != (longlong *)0x0) {
                      plVar13 = plVar12 + 2;
                      iVar8 = (**(code **)(*plVar13 + 0x70))(plVar13);
                      if (iVar8 < DAT_140949794) {
                        pIVar15 = theInstance();
                        lVar17 = *plVar13;
                        uVar11 = (*(code *)**(undefined8 **)pIVar15)(pIVar15,"STR_LOW_LEVEL");
                        (**(code **)(lVar17 + 0x358))(plVar13,uVar11);
                      }
                      else {
                        iVar8 = tq::TalkStrCheck(local_188 + 0x50,1);
                        if (iVar8 == 0) {
                          pIVar15 = theInstance();
                          lVar17 = *plVar13;
                          uVar11 = (*(code *)**(undefined8 **)pIVar15)
                                             (pIVar15,"STR_INVALID_CHARACTER");
                          (**(code **)(lVar17 + 0x358))(plVar13,uVar11);
                        }
                        else {
                          uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                          uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                          uVar11 = FUN_14015b1f0(uVar11);
                          FUN_14010b370(uVar11,uVar7,local_188,local_188 + 0x50);
                        }
                      }
                    }
                    break;
                  case 0x89e:
                    local_5b8 = (char *)CONCAT44(local_5b8._4_4_,0x1fd);
                    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","!\"_TXTATR_MSG_OTHER\"",
                                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\osmsgtalk.cpp"
                                      );
                  }
                }
              }
              else if (DAT_140975c38 != 0) {
                (**(code **)(*(longlong *)(DAT_140975c38 + 0x10) + 0x350))
                          ((longlong *)(DAT_140975c38 + 0x10),param_1);
              }
            }
          }
        }
        else {
          uVar11 = (**(code **)(plVar12[2] + 0x18))(plVar12 + 2);
          tq::GmLogSave("gm",&DAT_1406e8b68,uVar11,local_188);
        }
      }
    }
  }
  else {
    local_5b8 = (char *)CONCAT44(local_5b8._4_4_,100);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","strlen(szWords) <= 255",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\osmsgtalk.cpp"
                      );
  }
  return;
}

