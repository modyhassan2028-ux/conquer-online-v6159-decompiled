// ==== CRijndael::ctor_or_dtor  @140501160  [high:vtable-assign]  (orig: FUN_140501160)
undefined8 * FUN_140501160(undefined8 *param_1)

{
  *(undefined1 *)(param_1 + 1) = 0;
  *param_1 = CRijndael::vftable;
  return param_1;
}

// ==== CRijndael::ctor_or_dtor  @140501180  [high:vtable-assign]  (orig: FUN_140501180)
void FUN_140501180(undefined8 *param_1)

{
  *param_1 = CRijndael::vftable;
  return;
}

// ==== CRijndael::ctor_or_dtor  @140502b10  [high:vtable-assign]  (orig: FUN_140502b10)
undefined8 * FUN_140502b10(undefined8 *param_1,byte param_2)

{
  *param_1 = CRijndael::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

