// ==== CActivityTask::helper_1404de580  @1404de580  [medium:callgraph-r0]  (orig: FUN_1404de580)
void FUN_1404de580(__uint64 param_1)

{
  if ((DAT_140976538 & 1) == 0) {
    DAT_140976538 = DAT_140976538 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976530,"CActivityTask");
    atexit((_func_5014 *)&LAB_1406d6f40);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404de5d5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976530,param_1);
  return;
}

// ==== CActivityTask::helper_1404de5e0  @1404de5e0  [medium:callgraph-r0]  (orig: FUN_1404de5e0)
void FUN_1404de5e0(void *param_1)

{
  if ((DAT_140976538 & 1) == 0) {
    DAT_140976538 = DAT_140976538 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976530,"CActivityTask");
    atexit((_func_5014 *)&LAB_1406d6f40);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404de635. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976530,param_1);
  return;
}

// ==== CActivityTask::ctor_or_dtor  @1404de6d0  [high:vtable-assign]  (orig: FUN_1404de6d0)
undefined8 * FUN_1404de6d0(undefined8 *param_1,byte param_2)

{
  *param_1 = CActivityTask::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1404de5e0();
  }
  return param_1;
}

// ==== CActivityTask::helper_1404de9e0  @1404de9e0  [medium:callgraph-r0]  (orig: FUN_1404de9e0)
undefined8 FUN_1404de9e0(longlong param_1,int param_2)

{
  char cVar1;
  int iVar2;
  ulong uVar3;
  longlong *plVar4;
  __time64_t _Var5;
  
  plVar4 = *(longlong **)(param_1 + 0x10);
  if (plVar4 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,3);
  cVar1 = (**(code **)(*plVar4 + 0x20))(plVar4);
  if (cVar1 == '\x02') {
    iVar2 = tq::RandGet(1000);
    *(int *)(param_1 + 0x18) = (iVar2 + 1) * 500;
    uVar3 = tq::TimeGet(0);
    *(ulong *)(param_1 + 0x1c) = uVar3;
    _Var5 = _time64((__time64_t *)0x0);
    *(int *)(param_1 + 0x20) = (int)_Var5;
    if (param_2 != 0) {
      *(int *)(param_1 + 0x20) = param_2;
    }
  }
  return 1;
}

// ==== CActivityTask::ctor_or_dtor  @1404debc0  [high:vtable-assign]  (orig: FUN_1404debc0)
undefined8 * FUN_1404debc0(undefined4 param_1,longlong param_2,longlong param_3,undefined4 param_4)

{
  char cVar1;
  undefined8 *puVar2;
  
  if ((param_2 == 0) || (param_3 == 0)) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    puVar2 = (undefined8 *)FUN_1404de580(0x28);
    if (puVar2 == (undefined8 *)0x0) {
      puVar2 = (undefined8 *)0x0;
    }
    else {
      *puVar2 = CActivityTask::vftable;
      puVar2[1] = param_2;
      puVar2[2] = param_3;
      *(undefined4 *)(puVar2 + 3) = 0;
      *(undefined4 *)((longlong)puVar2 + 0x1c) = 0;
      *(undefined4 *)(puVar2 + 4) = 0;
      *(undefined4 *)((longlong)puVar2 + 0x24) = param_1;
    }
    if (puVar2 == (undefined8 *)0x0) {
      puVar2 = (undefined8 *)0x0;
    }
    else {
      cVar1 = FUN_1404de9e0(puVar2,param_4);
      if (cVar1 == '\0') {
        if (puVar2[1] != 0) {
          (*(code *)**(undefined8 **)puVar2[1])((undefined8 *)puVar2[1],0);
          puVar2[1] = 0;
        }
        (**(code **)*puVar2)(puVar2,1);
        puVar2 = (undefined8 *)0x0;
      }
    }
  }
  return puVar2;
}

