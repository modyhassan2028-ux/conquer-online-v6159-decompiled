// ==== CUserTrainingVitality::helper_1404785f0  @1404785f0  [medium:callgraph-r0]  (orig: FUN_1404785f0)
void FUN_1404785f0(__uint64 param_1)

{
  if ((DAT_140976498 & 1) == 0) {
    DAT_140976498 = DAT_140976498 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976490,"CUserTrainingVitality");
    atexit((_func_5014 *)&LAB_1406d6ea0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140478645. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976490,param_1);
  return;
}

// ==== CUserTrainingVitality::helper_140478650  @140478650  [medium:callgraph-r0]  (orig: FUN_140478650)
void FUN_140478650(void *param_1)

{
  if ((DAT_140976498 & 1) == 0) {
    DAT_140976498 = DAT_140976498 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976490,"CUserTrainingVitality");
    atexit((_func_5014 *)&LAB_1406d6ea0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404786a5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976490,param_1);
  return;
}

// ==== CUserTrainingVitality::ctor_or_dtor  @140478710  [high:vtable-assign]  (orig: FUN_140478710)
undefined8 * FUN_140478710(undefined8 *param_1,byte param_2)

{
  *param_1 = CUserTrainingVitality::vftable;
  if ((param_2 & 1) != 0) {
    FUN_140478650();
  }
  return param_1;
}

// ==== CUserTrainingVitality::ctor_or_dtor  @140478740  [high:vtable-assign]  (orig: FUN_140478740)
undefined8 * FUN_140478740(undefined4 param_1,longlong param_2,longlong param_3)

{
  undefined8 *puVar1;
  
  if ((param_2 == 0) || (param_3 == 0)) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    puVar1 = (undefined8 *)FUN_1404785f0(0x38);
    if (puVar1 == (undefined8 *)0x0) {
      puVar1 = (undefined8 *)0x0;
    }
    else {
      *puVar1 = CUserTrainingVitality::vftable;
      *(undefined4 *)(puVar1 + 1) = param_1;
      puVar1[2] = param_2;
      puVar1[3] = param_3;
      puVar1[4] = 0;
      puVar1[5] = 0;
      *(undefined1 *)(puVar1 + 6) = 0;
    }
    if (puVar1 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      puVar1 = (undefined8 *)0x0;
    }
  }
  return puVar1;
}

