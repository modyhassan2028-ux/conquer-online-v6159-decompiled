// ==== CConnectUser::helper_1400735f0  @1400735f0  [medium:callgraph-r0]  (orig: FUN_1400735f0)
void FUN_1400735f0(void *param_1)

{
  if ((DAT_140975b28 & 1) == 0) {
    DAT_140975b28 = DAT_140975b28 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975b20,"CConnectUser");
    atexit((_func_5014 *)&LAB_1406d65e0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140073645. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975b20,param_1);
  return;
}

// ==== CConnectUser::ctor_or_dtor  @1400736b0  [high:vtable-assign]  (orig: FUN_1400736b0)
undefined8 * FUN_1400736b0(undefined8 *param_1)

{
  *param_1 = CConnectUser::vftable;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0xf) = 0;
  *(undefined4 *)((longlong)param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  return param_1;
}

// ==== CConnectUser::ctor_or_dtor  @140073710  [high:vtable-assign]  (orig: FUN_140073710)
undefined8 * FUN_140073710(undefined8 *param_1,byte param_2)

{
  *param_1 = CConnectUser::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1400735f0();
  }
  return param_1;
}

