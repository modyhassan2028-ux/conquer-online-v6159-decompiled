// ==== CStorageActor@adapter::helper_1400ffd10  @1400ffd10  [medium:callgraph-r0]  (orig: FUN_1400ffd10)
longlong * FUN_1400ffd10(undefined4 param_1)

{
  uint uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x70))(plVar3,param_1);
  uVar1 = 0;
  if (lVar2 != 0) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),0x2f);
    uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  }
  plVar3 = (longlong *)(ulonglong)uVar1;
  if ((int)uVar1 < 0) {
    plVar3 = (longlong *)0x0;
  }
  return plVar3;
}

// ==== CStorageActor@adapter::helper_1400ffdf0  @1400ffdf0  [medium:callgraph-r0]  (orig: FUN_1400ffdf0)
ulonglong FUN_1400ffdf0(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  
  plVar6 = *(longlong **)(param_1 + 0x50);
  if (plVar6 == (longlong *)0x0) {
    plVar6 = *(longlong **)(param_1 + 0x58);
  }
  if (plVar6 != (longlong *)0x0) {
    uVar1 = (**(code **)(*plVar6 + 0x30))(plVar6,3);
    plVar4 = (longlong *)FUN_140087d40();
    lVar5 = (**(code **)(*plVar4 + 0x70))(plVar4,uVar1);
    if (lVar5 != 0) {
      plVar4 = (longlong *)
               (**(code **)(**(longlong **)(lVar5 + 8) + 0x10))(*(longlong **)(lVar5 + 8),4);
      iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
      plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
      plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,4);
      iVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
      if ((iVar3 < iVar2) && (plVar6 != *(longlong **)(param_1 + 0x58))) {
        plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
        plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,0x2f);
        iVar2 = (**(code **)(*plVar6 + 0x48))(plVar6);
      }
      else {
        plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
        plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,0x2f);
        iVar3 = (**(code **)(*plVar6 + 0x48))(plVar6);
        plVar6 = (longlong *)
                 (**(code **)(**(longlong **)(lVar5 + 8) + 0x10))(*(longlong **)(lVar5 + 8),0x2f);
        iVar2 = (**(code **)(*plVar6 + 0x48))(plVar6);
        iVar2 = iVar2 + iVar3;
      }
      goto LAB_1400fff01;
    }
  }
  plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,0x2f);
  iVar2 = (**(code **)(*plVar6 + 0x48))(plVar6);
LAB_1400fff01:
  if (iVar2 < 0) {
    uVar7 = 0;
  }
  else {
    plVar6 = *(longlong **)(param_1 + 0x50);
    if (plVar6 == (longlong *)0x0) {
      plVar6 = *(longlong **)(param_1 + 0x58);
    }
    if (plVar6 != (longlong *)0x0) {
      uVar1 = (**(code **)(*plVar6 + 0x30))(plVar6,3);
      plVar4 = (longlong *)FUN_140087d40();
      lVar5 = (**(code **)(*plVar4 + 0x70))(plVar4,uVar1);
      if (lVar5 != 0) {
        plVar4 = (longlong *)
                 (**(code **)(**(longlong **)(lVar5 + 8) + 0x10))(*(longlong **)(lVar5 + 8),4);
        iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
        plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
        plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,4);
        iVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
        if ((iVar2 <= iVar3) || (plVar6 == *(longlong **)(param_1 + 0x58))) {
          plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
          plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,0x2f);
          iVar2 = (**(code **)(*plVar6 + 0x48))(plVar6);
          plVar6 = (longlong *)
                   (**(code **)(**(longlong **)(lVar5 + 8) + 0x10))(*(longlong **)(lVar5 + 8),0x2f);
          iVar3 = (**(code **)(*plVar6 + 0x48))(plVar6);
          return (ulonglong)(uint)(iVar3 + iVar2);
        }
      }
    }
    plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,0x2f);
    uVar7 = (**(code **)(*plVar6 + 0x48))(plVar6);
  }
  return uVar7;
}

// ==== CStorageActor@adapter::helper_140102910  @140102910  [medium:callgraph-r0]  (orig: FUN_140102910)
bool FUN_140102910(longlong param_1,int param_2,short param_3)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  int iVar4;
  
  cVar1 = FUN_140102870();
  if (cVar1 != '\0') {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1)
    ;
    iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
    if (iVar2 == param_2) {
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                         (*(longlong **)(param_1 + 0x10),0x1a);
      iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
      iVar4 = 0;
      if (-1 < iVar2) {
        plVar3 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                           (*(longlong **)(param_1 + 0x10),0x1a);
        iVar4 = (**(code **)(*plVar3 + 0x48))(plVar3);
      }
      iVar2 = FUN_1400ffdf0(param_1);
      if (iVar4 < iVar2) {
        plVar3 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                           (*(longlong **)(param_1 + 0x10),0x16);
        iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
        if (iVar2 == 0) {
          return param_3 == 0;
        }
        return param_3 != 0;
      }
    }
  }
  return false;
}

// ==== CStorageActor@adapter::helper_140105d40  @140105d40  [medium:callgraph-r0]  (orig: FUN_140105d40)
void FUN_140105d40(longlong *param_1,undefined4 param_2,char param_3)

{
  char cVar1;
  uint uVar2;
  longlong *plVar3;
  
  uVar2 = (**(code **)(*param_1 + 8))();
  if ((4099999999 < uVar2) && (*(int *)((longlong)param_1 + 100) != 0)) {
    cVar1 = FUN_140103cd0(param_1);
    param_3 = cVar1 == '\0';
  }
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x1a);
  (**(code **)(*plVar3 + 0xb0))(plVar3,param_2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  if ((uVar2 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
    if (param_3 != '\0') {
      (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
    }
  }
  else {
    cVar1 = FUN_1401032b0(param_1,0x1a);
    if (cVar1 != '\0') {
      if (param_3 != '\0') {
        FUN_1401033b0(param_1);
        *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
        return;
      }
      *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
      return;
    }
  }
  return;
}

// ==== CStorageActor@adapter::helper_14017b450  @14017b450  [medium:callgraph-r0]  (orig: FUN_14017b450)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14017b450(longlong *param_1,int param_2,undefined1 param_3)

{
  longlong lVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined7 uVar8;
  undefined8 uVar6;
  IStringManager *pIVar7;
  undefined1 auStack_488 [32];
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (param_2 == 0) {
    uVar8 = (undefined7)(local_28 >> 8);
  }
  else {
    iVar3 = FUN_140374150(param_1 + 0x1cf);
    uVar6 = FUN_140008520((int)param_1[0x246]);
    uVar4 = FUN_14008afc0(uVar6);
    uVar2 = param_2 + iVar3;
    if (uVar4 < (uint)(param_2 + iVar3)) {
      uVar2 = uVar4;
    }
    FUN_140374160(param_1 + 0x1cf,uVar2,param_3);
    FUN_14039e680(local_458);
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    iVar3 = FUN_14039e700(local_458,uVar5,0x4f,uVar2);
    if (iVar3 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_458);
    }
    pIVar7 = theInstance();
    lVar1 = param_1[2];
    uVar6 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_CHEST_PACKAGE_SIZE");
    (**(code **)(lVar1 + 0x358))(param_1 + 2,uVar6,uVar2);
    uVar6 = FUN_14039e6d0(local_458);
    uVar8 = (undefined7)((ulonglong)uVar6 >> 8);
  }
  return CONCAT71(uVar8,1);
}

// ==== CStorageActor@adapter::helper_14020c770  @14020c770  [medium:callgraph-r0]  (orig: FUN_14020c770)
bool FUN_14020c770(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar2 == 0) {
    return false;
  }
  iVar1 = FUN_1400fda10(lVar2,1,1);
  return iVar1 == 0xaffbc;
}

// ==== CStorageActor@adapter::helper_14020d990  @14020d990  [medium:callgraph-r2]  (orig: FUN_14020d990)
undefined8 * FUN_14020d990(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CStorageActor@adapter::helper_14020e4e0  @14020e4e0  [medium:callgraph-r1]  (orig: FUN_14020e4e0)
longlong FUN_14020e4e0(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_14020d990(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_14020df70(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CStorageActor@adapter::helper_14020eb80  @14020eb80  [medium:callgraph-r0]  (orig: FUN_14020eb80)
undefined1 FUN_14020eb80(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined1 uVar1;
  longlong lVar2;
  undefined4 local_res10 [2];
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  local_res10[0] = param_2;
  lVar2 = FUN_14020ea80();
  uVar1 = (undefined1)lVar2;
  if (lVar2 != 0) {
    FUN_140415f80(lVar2);
    FUN_140413d80(lVar2);
    FUN_14020e4e0(param_1 + 0x10,local_res10,param_3,param_4,uVar3);
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CStorageActor@adapter::helper_14020ec50  @14020ec50  [medium:callgraph-r0]  (orig: FUN_14020ec50)
undefined1 FUN_14020ec50(void)

{
  longlong lVar1;
  
  lVar1 = FUN_14020ea80();
  if (lVar1 == 0) {
    return 0;
  }
  FUN_1404140b0(lVar1);
  return 1;
}

// ==== CStorageActor@adapter::helper_14032bb40  @14032bb40  [medium:callgraph-r0]  (orig: FUN_14032bb40)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14032bb40(longlong *param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4,
                  char param_5)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  char *pcVar5;
  
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar4 = (longlong *)0x0;
  }
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x60))(plVar4,param_2);
  if (plVar4 != (longlong *)0x0) {
    iVar2 = FUN_1400fda10(plVar4,0xc,1);
    cVar1 = FUN_140104440(plVar4);
    if ((cVar1 != '\0') || (0 < iVar2)) {
      FUN_1400fda10(plVar4,5,1);
      FUN_1400fda10(plVar4,4,1);
      FUN_1400fda10(plVar4,1,1);
      (**(code **)(*plVar4 + 8))(plVar4);
      (**(code **)(*param_1 + 8))();
      uVar3 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      pcVar5 = "";
      if (param_5 != '\0') {
        pcVar5 = "Error: ";
      }
      tq::MyLogSave("gmlog/pick_item",
                    "%s%s(%u)[%u] pick item to %s:[id=%u, type=%u], user_pro=%d, addtion_level=%d, dur=%d, max_dur=%d, accumulate=%d"
                    ,pcVar5,uVar3);
    }
  }
  return;
}

// ==== CStorageActor@adapter::helper_140371790  @140371790  [medium:callgraph-r0]  (orig: FUN_140371790)
void FUN_140371790(longlong param_1,longlong param_2,int param_3)

{
  longlong *plVar1;
  
  if (-1 < param_2) {
    *(longlong *)(param_1 + 0x48) = param_2;
    plVar1 = *(longlong **)(param_1 + 0x230);
    if (plVar1 != (longlong *)0x0) {
      plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"money_saved");
      (**(code **)(*plVar1 + 0xa0))(plVar1,param_2);
      if (param_3 != 0) {
        (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
      }
    }
  }
  return;
}

// ==== CStorageActor@adapter::helper_140374160  @140374160  [medium:callgraph-r1]  (orig: FUN_140374160)
void FUN_140374160(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x204) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"chestpackage_size");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CStorageActor@adapter::helper_1404140b0  @1404140b0  [medium:callgraph-r1]  (orig: FUN_1404140b0)
undefined8 FUN_1404140b0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  plVar2 = *(longlong **)(param_1 + 8);
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = (longlong *)plVar5[4];
    if (plVar3 != (longlong *)0x0) {
      (**(code **)(*plVar3 + 0x40))(plVar3,0);
      (**(code **)*plVar3)(plVar3);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar5 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar4 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar4 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x38) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1400784f0((longlong *)(param_1 + 8),plVar2[2]);
    plVar5 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar5;
    cVar1 = *(char *)((longlong)plVar5 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_1 + 0x38);
  lVar6 = *(longlong *)(param_1 + 0x38);
  *(longlong *)(lVar6 + 0x10) = lVar6;
  return CONCAT71((int7)((ulonglong)lVar6 >> 8),1);
}

// ==== CStorageActor@adapter::vfunc_1  @1405a1770  [high:rtti-vtable]  (orig: FUN_1405a1770)
void FUN_1405a1770(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CStorageActor@adapter::vfunc_0  @1405a17e0  [high:rtti-vtable]  (orig: FUN_1405a17e0)
undefined8 FUN_1405a17e0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a1831. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x68))(plVar1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_3  @1405a1840  [high:rtti-vtable]  (orig: FUN_1405a1840)
ulonglong FUN_1405a1840(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a18b1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x178))(plVar1,param_3,param_4);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_4  @1405a18c0  [high:rtti-vtable]  (orig: FUN_1405a18c0)
undefined8 FUN_1405a18c0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1401649c0(lVar1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_5  @1405a1920  [high:rtti-vtable]  (orig: FUN_1405a1920)
undefined8 FUN_1405a1920(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 1;
  }
  uVar2 = FUN_140178570(lVar1,1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_6  @1405a1980  [high:rtti-vtable]  (orig: FUN_1405a1980)
undefined8 FUN_1405a1980(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a19d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_7  @1405a19e0  [high:rtti-vtable]  (orig: FUN_1405a19e0)
undefined8 FUN_1405a19e0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a1a31. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0xc0))(plVar1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_9  @1405a1a40  [high:rtti-vtable]  (orig: FUN_1405a1a40)
ulonglong FUN_1405a1a40(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140332fe0(lVar1,param_3);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_11  @1405a1aa0  [high:rtti-vtable]  (orig: FUN_1405a1aa0)
uint FUN_1405a1aa0(undefined8 param_1,undefined4 param_2)

{
  uint uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar2 != 0) {
    uVar1 = FUN_1400fda10(lVar2,0x6e,1);
    return ~uVar1 & 1;
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_12  @1405a1b10  [high:rtti-vtable]  (orig: FUN_1405a1b10)
undefined8 FUN_1405a1b10(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400ffbe0(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_13  @1405a1b80  [high:rtti-vtable]  (orig: FUN_1405a1b80)
undefined8 FUN_1405a1b80(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400fdb80(lVar1,param_3,1);
    return uVar2;
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_14  @1405a1c00  [high:rtti-vtable]  (orig: FUN_1405a1c00)
undefined8
FUN_1405a1c00(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined1 param_5)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 != 0) {
    FUN_140104140(lVar1,param_3,param_4,param_5);
    return 1;
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_15  @1405a1ca0  [high:rtti-vtable]  (orig: FUN_1405a1ca0)
undefined1 * FUN_1405a1ca0(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined1 *puVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    puVar2 = (undefined1 *)FUN_140100430(lVar1,0x65);
    return puVar2;
  }
  return &DAT_1406dd892;
}

// ==== CStorageActor@adapter::vfunc_16  @1405a1d10  [high:rtti-vtable]  (orig: FUN_1405a1d10)
undefined8 FUN_1405a1d10(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_140104440(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_17  @1405a1d80  [high:rtti-vtable]  (orig: FUN_1405a1d80)
void FUN_1405a1d80(undefined8 param_1,undefined4 param_2)

{
  FUN_1400ff940(param_2);
  return;
}

// ==== CStorageActor@adapter::vfunc_18  @1405a1d90  [high:rtti-vtable]  (orig: FUN_1405a1d90)
undefined8 FUN_1405a1d90(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140337d00(lVar1,param_3);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_19  @1405a1df0  [high:rtti-vtable]  (orig: FUN_1405a1df0)
ulonglong FUN_1405a1df0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_1403380a0(lVar1,param_3);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_20  @1405a1e50  [high:rtti-vtable]  (orig: FUN_1405a1e50)
undefined8 FUN_1405a1e50(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400ff650(lVar1,param_3);
    return uVar2;
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_21  @1405a1ed0  [high:rtti-vtable]  (orig: FUN_1405a1ed0)
undefined8
FUN_1405a1ed0(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 != 0) {
    FUN_140104960(lVar1,param_3,param_4);
    return 1;
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_23  @1405a1f60  [high:rtti-vtable]  (orig: FUN_1405a1f60)
void FUN_1405a1f60(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  uint in_stack_ffffffffffffffe8;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_14032bb40(lVar1,param_3,0,param_4,in_stack_ffffffffffffffe8 & 0xffffff00);
  return;
}

// ==== CStorageActor@adapter::vfunc_25  @1405a1fe0  [high:rtti-vtable]  (orig: FUN_1405a1fe0)
undefined8 FUN_1405a1fe0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  uint in_stack_ffffffffffffffe8;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    plVar3 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      in_stack_ffffffffffffffe8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = (longlong *)0x0;
    }
    iVar1 = (**(code **)(*plVar3 + 0x150))(plVar3,param_3);
    if ((iVar1 == 2) || (iVar1 == 3)) {
      plVar3 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        in_stack_ffffffffffffffe8 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar3 = (longlong *)0x0;
      }
      (**(code **)(*plVar3 + 0x160))(plVar3,param_3);
    }
    FUN_1403368a0(lVar2,param_3,1,0,in_stack_ffffffffffffffe8 & 0xffffff00);
    return 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CStorageActor@adapter::vfunc_26  @1405a2100  [high:rtti-vtable]  (orig: FUN_1405a2100)
ulonglong FUN_1405a2100(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  longlong lVar4;
  ulonglong extraout_RAX;
  undefined8 uVar5;
  ulonglong uVar6;
  undefined8 local_res8;
  
  lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(lVar4 + 0x10);
  local_res8 = 0;
  uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
  uVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
  uVar5 = (**(code **)(*plVar1 + 0x160))(plVar1);
  uVar6 = FUN_1402c84c0(uVar5,uVar3,uVar2,0x1040,param_3,&local_res8);
  return uVar6;
}

// ==== CStorageActor@adapter::vfunc_30  @1405a21d0  [high:rtti-vtable]  (orig: FUN_1405a21d0)
undefined8 FUN_1405a21d0(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar2 != 0) {
    iVar1 = FUN_1400fda10(lVar2,1,1);
    if (((iVar1 != 0x10c8e3) && (iVar1 = FUN_1400fda10(lVar2,1,1), iVar1 != 0x10c8e6)) &&
       (iVar1 = FUN_1400fda10(lVar2,1,1), iVar1 != 0x10c8e9)) {
      return 0;
    }
    return 1;
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_35  @1405a2290  [high:rtti-vtable]  (orig: FUN_1405a2290)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

char FUN_1405a2290(longlong param_1,undefined4 param_2,int param_3,undefined4 param_4,
                  undefined4 param_5)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    return '\0';
  }
  FUN_1403f2320(local_468);
  cVar1 = '\0';
  if (param_3 == 3) {
    local_488 = param_5;
    cVar1 = FUN_1403f23d0(local_468,3,param_4,0);
  }
  else {
    if (param_3 != 4) {
      local_488 = param_5;
      log_InlineLogERROR("CStorageActor::SendEquipLock, User[%u], Action[%d], Item[%u], Date[%u]");
      goto LAB_1405a236b;
    }
    local_488 = 0;
    cVar1 = FUN_1403f23d0(local_468,4,param_2,0);
  }
  if (cVar1 != '\0') {
    (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_468);
  }
LAB_1405a236b:
  FUN_1403f2370(local_468);
  return cVar1;
}

// ==== CStorageActor@adapter::vfunc_36  @1405a23a0  [high:rtti-vtable]  (orig: FUN_1405a23a0)
void FUN_1405a23a0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  
  if (param_3 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x358))((longlong *)(lVar1 + 0x10),param_3);
  }
  return;
}

// ==== CStorageActor@adapter::vfunc_38  @1405a2410  [high:rtti-vtable]  (orig: FUN_1405a2410)
ulonglong FUN_1405a2410(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140164440(lVar1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_39  @1405a2470  [high:rtti-vtable]  (orig: FUN_1405a2470)
undefined8 FUN_1405a2470(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a24c1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_41  @1405a24d0  [high:rtti-vtable]  (orig: FUN_1405a24d0)
undefined1 FUN_1405a24d0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0x51c);
}

// ==== CStorageActor@adapter::vfunc_42  @1405a2530  [high:rtti-vtable]  (orig: FUN_1405a2530)
undefined1 * FUN_1405a2530(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a2588. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CStorageActor@adapter::vfunc_44  @1405a2590  [high:rtti-vtable]  (orig: FUN_1405a2590)
void FUN_1405a2590(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a25e9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xc0))(plVar1,param_2,param_3);
  return;
}

// ==== CStorageActor@adapter::vfunc_48  @1405a25f0  [high:rtti-vtable]  (orig: FUN_1405a25f0)
void FUN_1405a25f0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a263a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x150))(plVar1,param_2);
  return;
}

// ==== CStorageActor@adapter::vfunc_49  @1405a2650  [high:rtti-vtable]  (orig: FUN_1405a2650)
void FUN_1405a2650(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a26a0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x30))(plVar1,param_2,1,0);
  return;
}

// ==== CStorageActor@adapter::vfunc_50  @1405a26b0  [high:rtti-vtable]  (orig: FUN_1405a26b0)
void FUN_1405a26b0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_3);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1400fe700(lVar2,uVar1,param_4);
  return;
}

// ==== CStorageActor@adapter::vfunc_51  @1405a2780  [high:rtti-vtable]  (orig: FUN_1405a2780)
undefined8 FUN_1405a2780(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_14032d640(lVar1,param_3);
  return 1;
}

// ==== CStorageActor@adapter::vfunc_52  @1405a27e0  [high:rtti-vtable]  (orig: FUN_1405a27e0)
bool FUN_1405a27e0(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = FUN_1400fda10(lVar2,0x17,1);
  return iVar1 != 0;
}

// ==== CStorageActor@adapter::vfunc_53  @1405a2890  [high:rtti-vtable]  (orig: FUN_1405a2890)
ulonglong FUN_1405a2890(longlong param_1,int param_2,int param_3)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  ulonglong in_RAX;
  longlong lVar4;
  ulonglong extraout_RAX;
  longlong *plVar5;
  longlong lVar6;
  ulonglong uVar7;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar4 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar7 = extraout_RAX;
    }
    else {
      plVar5 = (longlong *)FUN_140087d40();
      lVar6 = (**(code **)(*plVar5 + 0x60))(plVar5,param_3);
      uVar7 = 0;
      if (lVar6 != 0) {
        uVar1 = FUN_1400fda10(lVar6,0x16,1);
        uVar2 = FUN_140100000(lVar6);
        uVar3 = FUN_1400fda10(lVar6,1,1);
        uVar7 = FUN_140339ec0(lVar4,uVar3,uVar2,uVar1,1);
        return uVar7;
      }
    }
    return uVar7 & 0xffffffffffffff00;
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CStorageActor@adapter::vfunc_54  @1405a2990  [high:rtti-vtable]  (orig: FUN_1405a2990)
ulonglong FUN_1405a2990(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140102870(lVar1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_55  @1405a2a20  [high:rtti-vtable]  (orig: FUN_1405a2a20)
void FUN_1405a2a20(undefined8 param_1,undefined4 param_2)

{
  FUN_140102780(param_2);
  return;
}

// ==== CStorageActor@adapter::vfunc_56  @1405a2a30  [high:rtti-vtable]  (orig: FUN_1405a2a30)
undefined8 FUN_1405a2a30(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1400ffda0(lVar1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_57  @1405a2ac0  [high:rtti-vtable]  (orig: FUN_1405a2ac0)
void FUN_1405a2ac0(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined1 param_4)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140105d40(lVar1,param_3,param_4);
  return;
}

// ==== CStorageActor@adapter::vfunc_58  @1405a2b80  [high:rtti-vtable]  (orig: FUN_1405a2b80)
undefined8 FUN_1405a2b80(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1400ffdf0(lVar1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_59  @1405a2c10  [high:rtti-vtable]  (orig: FUN_1405a2c10)
void FUN_1405a2c10(undefined8 param_1,undefined4 param_2)

{
  FUN_1400ffd10(param_2);
  return;
}

// ==== CStorageActor@adapter::vfunc_60  @1405a2c20  [high:rtti-vtable]  (orig: FUN_1405a2c20)
ulonglong FUN_1405a2c20(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4)

{
  longlong lVar1;
  ulonglong uVar2;
  ulonglong extraout_RAX;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_140102910(lVar1,param_3,param_4);
    return uVar2;
  }
  log_InlineLogERROR(
                    "CStorageActor::IsAccumulateWith pItem is NULL, idItem:%u, idItemType:%u, idUser:%u, type:%d."
                    );
  return extraout_RAX & 0xffffffffffffff00;
}

// ==== CStorageActor@adapter::vfunc_61  @1405a2cd0  [high:rtti-vtable]  (orig: FUN_1405a2cd0)
undefined8
FUN_1405a2cd0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
             undefined2 param_5,undefined1 param_6,undefined1 param_7)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_14033f6b0(lVar1,param_3,param_4,param_5,param_6,param_7,0);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_62  @1405a2d70  [high:rtti-vtable]  (orig: FUN_1405a2d70)
uint FUN_1405a2d70(undefined8 param_1,undefined4 param_2)

{
  uint uVar1;
  
  uVar1 = FUN_1400ff680(param_2);
  if (uVar1 == 9) {
    uVar1 = FUN_1400fecd0(param_2);
    if (uVar1 == 0) {
      return 1;
    }
  }
  return uVar1 & 0xffffff00;
}

// ==== CStorageActor@adapter::vfunc_63  @1405a2da0  [high:rtti-vtable]  (orig: FUN_1405a2da0)
void FUN_1405a2da0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_3);
  if ((lVar1 != 0) && (lVar2 != 0)) {
    FUN_14019a030(lVar1,param_3,0,0);
  }
  return;
}

// ==== CStorageActor@adapter::vfunc_27  @1405a2e30  [high:rtti-vtable]  (orig: FUN_1405a2e30)
void FUN_1405a2e30(undefined8 param_1,int param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  if (param_2 != 0) {
    plVar1 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar1 = (longlong *)0x0;
    }
    (**(code **)(*plVar1 + 0x58))(plVar1,param_2,param_3);
  }
  return;
}

// ==== CStorageActor@adapter::vfunc_69  @1405a2ea0  [high:rtti-vtable]  (orig: FUN_1405a2ea0)
void FUN_1405a2ea0(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a2ef9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x50))(plVar1,param_2,param_3);
  return;
}

// ==== CStorageActor@adapter::vfunc_46  @1405a2f00  [high:rtti-vtable]  (orig: FUN_1405a2f00)
undefined8 FUN_1405a2f00(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140168bc0(lVar1);
  return uVar2;
}

// ==== CStorageActor@adapter::vfunc_70  @1405a2f60  [high:rtti-vtable]  (orig: FUN_1405a2f60)
ulonglong FUN_1405a2f60(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_14017b450(lVar1,param_3,1);
  return uVar2;
}

// ==== CStorageActor@adapter::helper_1405a3020  @1405a3020  [medium:callgraph-r1]  (orig: FUN_1405a3020)
void FUN_1405a3020(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CStorageActor@adapter::vfunc_0  @1405a3330  [high:rtti-vtable]  (orig: FUN_1405a3330)
void FUN_1405a3330(longlong param_1)

{
  FUN_1405a3390(param_1 + -8);
  return;
}

// ==== CStorageActor@adapter::helper_1405a3390  @1405a3390  [medium:callgraph-r0]  (orig: FUN_1405a3390)
undefined8 * FUN_1405a3390(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CStorageActor::vftable;
  param_1[1] = adapter::CStorageActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CStorageActor@adapter::vfunc_1  @1405a33e0  [high:rtti-vtable]  (orig: FUN_1405a33e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405a33e0(longlong param_1,undefined8 param_2,longlong param_3,char param_4)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong lVar7;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (param_3 < 1) {
    uVar6 = 0;
  }
  else {
    plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (plVar3 == (longlong *)0x0) {
      local_488 = 0x39;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar6 = 0;
    }
    else {
      lVar4 = (**(code **)(*plVar3 + 0x60))(plVar3);
      if (lVar4 < param_3) {
        uVar6 = 0;
      }
      else {
        lVar5 = (**(code **)(*plVar3 + 0x60))(plVar3);
        lVar4 = (**(code **)(*plVar3 + 0x68))(plVar3);
        lVar4 = param_3 + lVar4;
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        uVar6 = FUN_1400d6610(uVar6);
        lVar7 = FUN_140006cc0(uVar6);
        if ((lVar7 < lVar4) || (lVar4 < 0)) {
          uVar6 = 0;
        }
        else {
          FUN_140371720(plVar3 + 0x1cf,lVar5 - param_3,0);
          FUN_140371790(plVar3 + 0x1cf,lVar4,0);
          if (param_4 != '\0') {
            FUN_14039e680(local_468);
            uVar1 = (**(code **)(*plVar3 + 8))(plVar3);
            iVar2 = FUN_14039e700(local_468,uVar1,4,lVar5 - param_3);
            if (iVar2 != 0) {
              uVar6 = (**(code **)(*plVar3 + 0x68))(plVar3);
              FUN_14039e9a0(local_468,9,uVar6);
              (**(code **)(plVar3[2] + 0x350))(plVar3 + 2,local_468);
            }
            FUN_14039e6d0(local_468);
          }
          uVar6 = 1;
        }
      }
    }
  }
  return uVar6;
}

// ==== CStorageActor@adapter::vfunc_2  @1405a3590  [high:rtti-vtable]  (orig: FUN_1405a3590)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405a3590(longlong *param_1,undefined4 param_2,longlong param_3,char param_4)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_3 < 1) {
    uVar6 = 0;
  }
  else {
    plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x98))();
    if (plVar3 == (longlong *)0x0) {
      local_498 = 0x65;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar6 = 0;
    }
    else {
      lVar4 = (**(code **)(*plVar3 + 0x68))(plVar3);
      if (lVar4 < param_3) {
        pIVar5 = theInstance();
        lVar4 = *param_1;
        uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_NOT_SO_MUCH_MONEY");
        (**(code **)(lVar4 + 0x120))(param_1,param_2,uVar6);
        uVar6 = 0;
      }
      else {
        lVar4 = (**(code **)(*plVar3 + 0x60))(plVar3);
        lVar4 = param_3 + lVar4;
        lVar7 = (**(code **)(*plVar3 + 0x68))(plVar3);
        uVar6 = FUN_140008520((int)param_1[3]);
        uVar6 = FUN_1400d6610(uVar6);
        lVar8 = FUN_140006cc0(uVar6);
        if ((lVar8 < lVar4) || (lVar4 < 0)) {
          pIVar5 = theInstance();
          lVar4 = *param_1;
          uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_EXCEED_BAG_MONEY_LIMIT");
          (**(code **)(lVar4 + 0x120))(param_1,param_2,uVar6);
          uVar6 = 0;
        }
        else {
          FUN_140371720(plVar3 + 0x1cf,lVar4,0);
          FUN_140371790(plVar3 + 0x1cf,lVar7 - param_3,0);
          if (param_4 != '\0') {
            FUN_14039e680(local_478);
            uVar1 = (**(code **)(*plVar3 + 8))(plVar3);
            iVar2 = FUN_14039e700(local_478,uVar1,4,lVar4);
            if (iVar2 != 0) {
              uVar6 = (**(code **)(*plVar3 + 0x68))(plVar3);
              FUN_14039e9a0(local_478,9,uVar6);
              (**(code **)(plVar3[2] + 0x350))(plVar3 + 2,local_478);
            }
            FUN_14039e6d0(local_478);
          }
          uVar6 = 1;
        }
      }
    }
  }
  return uVar6;
}

// ==== CStorageActor@adapter::vfunc_8  @1405a3780  [high:rtti-vtable]  (orig: FUN_1405a3780)
void FUN_1405a3780(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008abf0(uVar1);
  return;
}

// ==== CStorageActor@adapter::vfunc_10  @1405a37a0  [high:rtti-vtable]  (orig: FUN_1405a37a0)
undefined1 FUN_1405a37a0(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = (longlong *)0x0;
  }
  lVar3 = (**(code **)(*plVar4 + 0x60))(plVar4,param_3);
  if (lVar3 != 0) {
    uVar1 = FUN_1400fda10(lVar3,1,1);
    iVar2 = FUN_1400ff680(uVar1);
    if (iVar2 == 9) {
      uVar1 = FUN_1400fda10(lVar3,1,1);
      iVar2 = FUN_1400fecd0(uVar1);
      if (iVar2 == 10000) {
        return 1;
      }
    }
    return 0;
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_22  @1405a3850  [high:rtti-vtable]  (orig: FUN_1405a3850)
void FUN_1405a3850(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1403141e0(lVar1,param_2,param_3,param_4);
  return;
}

// ==== CStorageActor@adapter::vfunc_24  @1405a38d0  [high:rtti-vtable]  (orig: FUN_1405a38d0)
char FUN_1405a38d0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  char cVar2;
  int iVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  
  lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar4 != 0) {
    plVar7 = (longlong *)0x0;
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = plVar7;
    }
    iVar3 = (**(code **)(*plVar6 + 0x150))(plVar6,param_3);
    if ((iVar3 == 2) || (iVar3 == 3)) {
      plVar6 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar6 = plVar7;
      }
      (**(code **)(*plVar6 + 0x158))(plVar6,param_3);
    }
    cVar1 = FUN_140340de0(lVar4,param_3,1);
    if (cVar1 != '\0') {
      lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      plVar6 = *(longlong **)(lVar4 + 0x128);
      if (plVar6 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar6 = plVar7;
      }
      cVar2 = FUN_14020c770(plVar6,param_3);
      if (cVar2 != '\0') {
        uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        uVar5 = FUN_140117f70(uVar5);
        FUN_14020f360(uVar5,param_3);
      }
    }
    return cVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return '\0';
}

// ==== CStorageActor@adapter::vfunc_28  @1405a3a70  [high:rtti-vtable]  (orig: FUN_1405a3a70)
ulonglong FUN_1405a3a70(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong *local_res8;
  
  local_res8 = (longlong *)0x0;
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x20))(*(longlong **)(lVar1 + 0x88),param_2)
  ;
  uVar3 = 0;
  if (plVar2 != (longlong *)0x0) {
    uVar3 = (**(code **)(*plVar2 + 0x298))(plVar2,0x1040,&local_res8);
    if ((char)uVar3 != '\0') {
      uVar3 = (**(code **)(*local_res8 + 0x70))();
      return uVar3;
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CStorageActor@adapter::vfunc_29  @1405a3b20  [high:rtti-vtable]  (orig: FUN_1405a3b20)
ulonglong FUN_1405a3b20(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong *local_res8;
  
  local_res8 = (longlong *)0x0;
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x20))(*(longlong **)(lVar1 + 0x88),param_2)
  ;
  uVar3 = 0;
  if (plVar2 != (longlong *)0x0) {
    uVar3 = (**(code **)(*plVar2 + 0x298))(plVar2,0x1040,&local_res8);
    if ((char)uVar3 != '\0') {
      uVar3 = (**(code **)(*local_res8 + 0x78))();
      return uVar3;
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CStorageActor@adapter::vfunc_31  @1405a3bd0  [high:rtti-vtable]  (orig: FUN_1405a3bd0)
void FUN_1405a3bd0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong local_res8;
  
  local_res8 = 0;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x88) + 0x20))(*(longlong **)(lVar3 + 0x88),param_2)
  ;
  if (plVar4 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1040,&local_res8);
    if (cVar1 != '\0') {
      iVar2 = (**(code **)(**(longlong **)(local_res8 + 0x60) + 0x10))
                        (*(longlong **)(local_res8 + 0x60),4);
      if (iVar2 == 0x14) {
        FUN_1402bda30(local_res8);
      }
    }
  }
  return;
}

// ==== CStorageActor@adapter::vfunc_32  @1405a3c90  [high:rtti-vtable]  (orig: FUN_1405a3c90)
longlong FUN_1405a3c90(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong local_res8;
  
  local_res8 = 0;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x88) + 0x20))(*(longlong **)(lVar3 + 0x88),param_2)
  ;
  if (plVar4 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1040,&local_res8);
    if ((cVar1 != '\0') && (*(char *)(local_res8 + 0x68) == '\0')) {
      iVar2 = FUN_1400872b0(local_res8,param_3);
      return (longlong)iVar2;
    }
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_33  @1405a3d50  [high:rtti-vtable]  (orig: FUN_1405a3d50)
longlong FUN_1405a3d50(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong local_res8;
  
  local_res8 = 0;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x88) + 0x20))(*(longlong **)(lVar3 + 0x88),param_2)
  ;
  if (plVar4 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1040,&local_res8);
    if ((cVar1 != '\0') && (*(char *)(local_res8 + 0x68) != '\0')) {
      iVar2 = FUN_1400872b0(local_res8,param_3);
      return (longlong)iVar2;
    }
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_34  @1405a3e10  [high:rtti-vtable]  (orig: FUN_1405a3e10)
void FUN_1405a3e10(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CStorageActor@adapter::vfunc_37  @1405a3ee0  [high:rtti-vtable]  (orig: FUN_1405a3ee0)
ulonglong FUN_1405a3ee0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 local_res8;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  uVar4 = 0;
  if (lVar1 != 0) {
    local_res8 = 0;
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar2 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))
                       (*(longlong **)(lVar2 + 0x88),param_3);
    uVar4 = 0;
    if ((plVar3 != (longlong *)0x0) &&
       (uVar4 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8), (char)uVar4 != '\0')) {
      uVar4 = FUN_1402be0d0(local_res8,lVar1,param_4);
      return uVar4;
    }
  }
  return uVar4 & 0xffffffffffffff00;
}

// ==== CStorageActor@adapter::vfunc_40  @1405a3fc0  [high:rtti-vtable]  (orig: FUN_1405a3fc0)
undefined8 FUN_1405a3fc0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong local_res8;
  
  local_res8 = 0;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if ((cVar1 != '\0') && (*(char *)(local_res8 + 0x68) != '\0')) {
      uVar4 = FUN_140087360();
      return uVar4;
    }
  }
  return 0;
}

// ==== CStorageActor@adapter::vfunc_45  @1405a4070  [high:rtti-vtable]  (orig: FUN_1405a4070)
bool FUN_1405a4070(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return true;
  }
  return 0x27 < (ulonglong)(*(longlong *)(lVar1 + 0xc28) - *(longlong *)(lVar1 + 0xc20) >> 2);
}

// ==== CStorageActor@adapter::vfunc_65  @1405a40e0  [high:rtti-vtable]  (orig: FUN_1405a40e0)
void FUN_1405a40e0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x128);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_14020c770(lVar1,param_2);
  return;
}

// ==== CStorageActor@adapter::vfunc_66  @1405a4140  [high:rtti-vtable]  (orig: FUN_1405a4140)
void FUN_1405a4140(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x128);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_14020f360(lVar1,param_2);
  return;
}

// ==== CStorageActor@adapter::vfunc_67  @1405a41a0  [high:rtti-vtable]  (orig: FUN_1405a41a0)
void FUN_1405a41a0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x128);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_14020eb80(lVar1,param_2);
  return;
}

// ==== CStorageActor@adapter::vfunc_68  @1405a4200  [high:rtti-vtable]  (orig: FUN_1405a4200)
void FUN_1405a4200(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x128);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_14020ec50(lVar1,param_2);
  return;
}

// ==== CStorageActor@adapter::vfunc_47  @1405a4260  [high:rtti-vtable]  (orig: FUN_1405a4260)
void FUN_1405a4260(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008afc0(uVar1);
  return;
}

// ==== CStorageActor@adapter::vfunc_71  @1405a4280  [high:rtti-vtable]  (orig: FUN_1405a4280)
void FUN_1405a4280(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006cc0(*(undefined8 *)(lVar1 + 0xb0));
  return;
}

// ==== CStorageActor@adapter::helper_1405a42f0  @1405a42f0  [medium:callgraph-r1]  (orig: FUN_1405a42f0)
void FUN_1405a42f0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x38)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x38);
  return;
}

// ==== CStorageActor@adapter::helper_1405a43d0  @1405a43d0  [medium:callgraph-r3]  (orig: FUN_1405a43d0)
longlong FUN_1405a43d0(void *param_1,void *param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = (longlong)param_2 - (longlong)param_1;
  if (param_1 != param_2) {
    lVar2 = param_3 - (longlong)param_2;
    do {
      param_2 = (void *)((longlong)param_2 + -0x38);
      memcpy((void *)(lVar2 + (longlong)param_2),param_2,0x38);
    } while (param_2 != param_1);
  }
  return param_3 + (lVar1 / 0x38) * -0x38;
}

// ==== CStorageActor@adapter::helper_1405a4470  @1405a4470  [medium:callgraph-r1]  (orig: FUN_1405a4470)
void * FUN_1405a4470(void *param_1,void *param_2,void *param_3)

{
  for (; param_1 != param_2; param_1 = (void *)((longlong)param_1 + 0x38)) {
    if (param_3 != (void *)0x0) {
      memcpy(param_3,param_1,0x38);
    }
    param_3 = (void *)((longlong)param_3 + 0x38);
  }
  return param_3;
}

// ==== CStorageActor@adapter::helper_1405a4640  @1405a4640  [medium:callgraph-r1]  (orig: FUN_1405a4640)
void FUN_1405a4640(void *param_1,longlong param_2,void *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (void *)0x0) {
      memcpy(param_1,param_3,0x38);
    }
    param_1 = (void *)((longlong)param_1 + 0x38);
  }
  return;
}

// ==== CStorageActor@adapter::vfunc_64  @1405a4920  [high:rtti-vtable]  (orig: FUN_1405a4920)
void FUN_1405a4920(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                  char param_5,int param_6)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *local_58 [3];
  longlong *local_40;
  longlong *local_38;
  undefined8 local_30;
  
  lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  plVar5 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = (longlong *)0x0;
  }
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x60))(plVar5,param_3);
  if ((lVar4 == 0) || (plVar5 == (longlong *)0x0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_58[0] = operator_new(8);
    if (local_58[0] == (longlong *)0x0) {
      local_58[0] = (longlong *)0x0;
    }
    else {
      *local_58[0] = (longlong)local_58;
    }
    local_40 = (longlong *)0x0;
    local_38 = (longlong *)0x0;
    local_30 = 0;
    FUN_140109210(plVar5,local_58);
    plVar6 = local_40;
    if (0 < (int)((longlong)local_38 - (longlong)local_40 >> 3)) {
      plVar2 = local_58[0];
      if (local_38 < local_40) {
        _invalid_parameter_noinfo();
        plVar2 = local_58[0];
      }
      while( true ) {
        plVar1 = local_38;
        if (local_38 < local_40) {
          _invalid_parameter_noinfo();
        }
        if ((plVar2 == (longlong *)0x0) || (plVar2 != local_58[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar6 == plVar1) break;
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar2;
        }
        if (*(longlong **)(lVar7 + 0x20) <= plVar6) {
          _invalid_parameter_noinfo();
        }
        plVar1 = (longlong *)*plVar6;
        if (plVar1 != (longlong *)0x0) {
          (**(code **)(*plVar1 + 0x38))(plVar1,2);
          if (param_6 == 0) {
            (**(code **)(*plVar1 + 0x38))(plVar1,9);
          }
          else if (param_6 == 10) {
            (**(code **)(*plVar1 + 0x38))(plVar1,9);
          }
          else if (param_6 == 0x14) {
            (**(code **)(*plVar1 + 0x38))(plVar1,9);
          }
          else if (param_6 == 0x1e) {
            (**(code **)(*plVar1 + 0x38))(plVar1,9);
          }
          else if (param_6 == 0x28) {
            (**(code **)(*plVar1 + 0x38))(plVar1,9);
          }
          else {
            log_InlineLogERROR(&DAT_1407afba0);
          }
          (**(code **)(*plVar1 + 0x50))(plVar1);
        }
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar2;
        }
        if (*(longlong **)(lVar7 + 0x20) <= plVar6) {
          _invalid_parameter_noinfo();
        }
        plVar6 = plVar6 + 1;
      }
      FUN_14019a030(lVar4,param_3,0,0);
      plVar6 = DAT_140975b60;
      if (param_5 == '\0') {
        lVar4 = FUN_140100070(plVar5);
        if ((lVar4 != 0) || (lVar4 = FUN_140100290(plVar5), lVar4 != 0)) {
          plVar6 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          lVar4 = *plVar6;
          uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
          (**(code **)(lVar4 + 0x178))(plVar6,uVar3);
        }
      }
      else {
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar4 = *plVar6;
        uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        (**(code **)(lVar4 + 0x180))(plVar6,uVar3);
      }
    }
    if (local_40 != (longlong *)0x0) {
      operator_delete(local_40);
    }
    local_40 = (longlong *)0x0;
    local_38 = (longlong *)0x0;
    local_30 = 0;
    operator_delete(local_58[0]);
  }
  return;
}

// ==== CStorageActor@adapter::helper_1405a4d70  @1405a4d70  [medium:callgraph-r0]  (orig: FUN_1405a4d70)
void FUN_1405a4d70(longlong param_1,ulonglong param_2)

{
  ulonglong uVar1;
  void *pvVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined1 local_res10;
  
  if (0x492492492492492 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_1405a3020();
  }
  if (*(longlong *)(param_1 + 0x18) == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = (*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x18)) / 0x38;
  }
  if (uVar5 < param_2) {
    lVar4 = FUN_1405a42f0(param_1 + 0x10,param_2);
    uVar5 = *(ulonglong *)(param_1 + 0x20);
    if (uVar5 < *(ulonglong *)(param_1 + 0x18)) {
      _invalid_parameter_noinfo();
    }
    uVar1 = *(ulonglong *)(param_1 + 0x18);
    if (*(ulonglong *)(param_1 + 0x20) < uVar1) {
      _invalid_parameter_noinfo();
    }
    local_res10 = (undefined1)lVar4;
    FUN_1405a4470(uVar1,uVar5,lVar4,param_1 + 0x10,local_res10,0);
    pvVar2 = *(void **)(param_1 + 0x18);
    lVar3 = *(longlong *)(param_1 + 0x20);
    if (pvVar2 != (void *)0x0) {
      operator_delete(pvVar2);
    }
    *(ulonglong *)(param_1 + 0x28) = param_2 * 0x38 + lVar4;
    *(longlong *)(param_1 + 0x20) = ((lVar3 - (longlong)pvVar2) / 0x38) * 0x38 + lVar4;
    *(longlong *)(param_1 + 0x18) = lVar4;
  }
  return;
}

// ==== CStorageActor@adapter::helper_1405a4f00  @1405a4f00  [medium:callgraph-r2]  (orig: FUN_1405a4f00)
void FUN_1405a4f00(longlong param_1,longlong param_2,ulonglong param_3,void *param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  void *pvVar5;
  longlong lVar6;
  void *pvVar7;
  undefined1 local_res8;
  undefined1 local_68 [64];
  
  lVar6 = *(longlong *)(param_1 + 0x18);
  if (lVar6 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = (*(longlong *)(param_1 + 0x28) - lVar6) / 0x38;
  }
  if (param_3 != 0) {
    lVar2 = *(longlong *)(param_1 + 0x20);
    lVar6 = (lVar2 - lVar6) / 0x38;
    if (0x492492492492492U - lVar6 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1405a3020();
    }
    uVar1 = lVar6 + param_3;
    if (uVar4 < uVar1) {
      if (0x492492492492492 - (uVar4 >> 1) < uVar4) {
        uVar4 = 0;
      }
      else {
        uVar4 = uVar4 + (uVar4 >> 1);
      }
      if (uVar4 < uVar1) {
        uVar4 = uVar1;
      }
      lVar2 = FUN_1405a42f0(param_1 + 0x10,uVar4);
      lVar6 = (*(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18)) / 0x38;
      local_res8 = (undefined1)lVar2;
      FUN_1405a4640(lVar6 * 0x38 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_1405a4470(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_1405a4470(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar6 + param_3) * 0x38 + lVar2,param_1 + 0x10,local_res8,0,2);
      pvVar5 = *(void **)(param_1 + 0x18);
      lVar6 = *(longlong *)(param_1 + 0x20);
      if (pvVar5 != (void *)0x0) {
        operator_delete(pvVar5);
      }
      *(ulonglong *)(param_1 + 0x28) = uVar4 * 0x38 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar6 - (longlong)pvVar5) / 0x38) * 0x38 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)((lVar2 - *(longlong *)(param_2 + 8)) / 0x38) < param_3) {
      memcpy(local_68,param_4,0x38);
      FUN_1405a4470(*(longlong *)(param_2 + 8),lVar2,*(longlong *)(param_2 + 8) + param_3 * 0x38,
                    param_1 + 0x10,local_res8,0);
      FUN_1405a4640(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x38,
                    local_68,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x38;
      lVar6 = *(longlong *)(param_1 + 0x20);
      for (pvVar5 = *(void **)(param_2 + 8); pvVar5 != (void *)(lVar6 + param_3 * -0x38);
          pvVar5 = (void *)((longlong)pvVar5 + 0x38)) {
        memcpy(pvVar5,local_68,0x38);
      }
    }
    else {
      memcpy(local_68,param_4,0x38);
      lVar6 = lVar2 + param_3 * -0x38;
      uVar3 = FUN_1405a4470(lVar6,lVar2,lVar2,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_1405a43d0(*(undefined8 *)(param_2 + 8),lVar6,lVar2,local_res8,local_res8,0);
      pvVar5 = *(void **)(param_2 + 8);
      pvVar7 = (void *)(param_3 * 0x38 + (longlong)pvVar5);
      for (; pvVar5 != pvVar7; pvVar5 = (void *)((longlong)pvVar5 + 0x38)) {
        memcpy(pvVar5,local_68,0x38);
      }
    }
  }
  return;
}

// ==== CStorageActor@adapter::helper_1405a52a0  @1405a52a0  [medium:callgraph-r1]  (orig: FUN_1405a52a0)
longlong * FUN_1405a52a0(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar3 = param_1[3];
  lVar4 = param_1[4] - uVar3;
  lVar1 = 0;
  lVar5 = lVar4 >> 0x3f;
  lVar2 = lVar1;
  if (lVar4 / 0x38 + lVar5 != lVar5) {
    if ((ulonglong)param_1[4] < uVar3) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = (longlong)(param_3[1] - uVar3) / 0x38;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1405a4f00(param_1,&local_28,1,param_4);
  uVar3 = param_1[3];
  if ((ulonglong)param_1[4] < uVar3) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar3;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar1;
  }
  else {
    lVar5 = *param_1;
  }
  uVar3 = lVar2 * 0x38 + uVar3;
  if (uVar3 <= *(ulonglong *)(lVar5 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar1 = *param_1;
    }
    if (*(ulonglong *)(lVar1 + 0x18) <= uVar3) goto LAB_1405a53c2;
  }
  _invalid_parameter_noinfo();
LAB_1405a53c2:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar3;
  return param_2;
}

// ==== CStorageActor@adapter::helper_1405a5400  @1405a5400  [medium:callgraph-r0]  (orig: FUN_1405a5400)
void FUN_1405a5400(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) / 0x38;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0x38) < uVar3) {
    FUN_1405a4640(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x38;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_1405a52a0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CStorageActor@adapter::vfunc_43  @1405a5500  [high:rtti-vtable]  (orig: FUN_1405a5500)
/* WARNING: Removing unreachable block (ram,0x0001405a559c) */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8
FUN_1405a5500(undefined8 param_1,uint param_2,int param_3,int param_4,undefined8 param_5,
             undefined8 param_6)

{
  longlong lVar1;
  longlong *plVar2;
  char cVar3;
  byte bVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *local_c8 [3];
  longlong *local_b0;
  longlong *local_a8;
  undefined8 local_a0;
  undefined4 local_98;
  undefined4 local_94;
  undefined1 local_90;
  undefined1 local_8f;
  undefined1 local_8e;
  uint local_8c;
  undefined1 local_88;
  undefined1 local_87;
  undefined1 local_86;
  undefined1 local_85;
  undefined2 local_84;
  undefined2 local_82;
  undefined2 local_80;
  undefined1 local_7e;
  undefined1 local_7d;
  undefined4 local_7c;
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  undefined2 local_68;
  undefined2 local_66;
  undefined2 local_64;
  longlong *local_60;
  longlong *local_50;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  if ((param_2 == 0) || (param_3 == 0)) {
    log_InlineLogERROR(
                      "CStorageActor::GetStorageItem idOwner or idPlayer is 0, idOwner:%u, idPlayer:%u, nPosition:%d."
                      );
    uVar6 = 0;
  }
  else {
    local_60 = operator_new(8);
    if (local_60 == (longlong *)0x0) {
      local_c8[0] = (longlong *)0x0;
    }
    else {
      *local_60 = (longlong)local_c8;
      local_c8[0] = local_60;
    }
    plVar9 = (longlong *)0x0;
    local_b0 = (longlong *)0x0;
    local_a8 = (longlong *)0x0;
    local_a0 = 0;
    local_50 = local_60;
    if (param_4 == 0xca) {
      local_b0 = (longlong *)0x0;
      local_a8 = (longlong *)0x0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      uVar6 = 0;
    }
    else {
      plVar8 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        plVar8 = plVar9;
      }
      (**(code **)(*plVar8 + 0x48))(plVar8,param_2,param_4,param_3);
      FUN_1405a4d70(param_6);
      plVar8 = local_b0;
      local_60 = (longlong *)0x0;
      if (local_a8 < local_b0) {
        _invalid_parameter_noinfo();
      }
      plVar2 = local_c8[0];
      local_60 = local_c8[0];
      while( true ) {
        plVar10 = local_a8;
        local_50 = (longlong *)0x0;
        if (local_a8 < local_b0) {
          _invalid_parameter_noinfo();
        }
        local_50 = local_c8[0];
        if ((plVar2 == (longlong *)0x0) || (plVar2 != local_c8[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar8 == plVar10) break;
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar10 = plVar9;
        }
        else {
          plVar10 = (longlong *)*plVar2;
        }
        if ((longlong *)plVar10[4] <= plVar8) {
          _invalid_parameter_noinfo();
        }
        plVar10 = (longlong *)*plVar8;
        if (plVar10 != (longlong *)0x0) {
          cVar3 = FUN_1400ffcb0(plVar10);
          if (cVar3 == '\0') {
            uVar7 = (**(code **)(*plVar10 + 8))(plVar10);
            tq::GmLogSave("invalid_item",
                          "invalid item:[%u] found in user:[idOwner = %u][position=%d]",
                          uVar7 & 0xffffffff,(ulonglong)param_2);
            plVar11 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                );
              plVar11 = plVar9;
            }
            lVar1 = *plVar11;
            uVar5 = (**(code **)(*plVar10 + 8))(plVar10);
            (**(code **)(lVar1 + 0x58))(plVar11,uVar5,0);
          }
          else {
            memset(&local_98,0,0x38);
            local_98 = (**(code **)(*plVar10 + 8))(plVar10);
            local_94 = FUN_1400fda10(plVar10,1,1);
            local_90 = FUN_1400fda10(plVar10,6,1);
            local_8f = FUN_1400fda10(plVar10,8,1);
            local_8e = FUN_1400fda10(plVar10,9,1);
            bVar4 = FUN_1400fda10(plVar10,10,1);
            local_8c = (uint)bVar4;
            local_88 = FUN_1400fda10(plVar10,0xb,1);
            local_87 = FUN_1400fda10(plVar10,0xc,1);
            local_86 = FUN_1400fda10(plVar10,0xe,1);
            local_85 = FUN_1400fda10(plVar10,0x16,1);
            local_84 = FUN_1400fda10(plVar10,0xf,1);
            local_82 = FUN_1400fda10(plVar10,0x10,1);
            local_80 = FUN_1400fda10(plVar10,0x12,1);
            local_7e = FUN_1400fda10(plVar10,0x13,1);
            local_7d = FUN_1400fda10(plVar10,0x14,1);
            local_7c = FUN_1400fda10(plVar10,0xd,1);
            local_78 = FUN_1400fda10(plVar10,0x15,1);
            local_74 = FUN_1400fda10(plVar10,0x17,1);
            local_70 = FUN_1400fe380(plVar10);
            local_6c = FUN_1400fda10(plVar10,0x19,1);
            local_68 = FUN_1400fda10(plVar10,0x1a,1);
            local_66 = FUN_1400fda10(plVar10,4,1);
            local_64 = FUN_1400fda10(plVar10,0x93,1);
            FUN_1405a5400(param_6);
          }
        }
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar10 = plVar9;
        }
        else {
          plVar10 = (longlong *)*plVar2;
        }
        if ((longlong *)plVar10[4] <= plVar8) {
          _invalid_parameter_noinfo();
        }
        plVar8 = plVar8 + 1;
      }
      if (local_b0 != (longlong *)0x0) {
        operator_delete(local_b0);
      }
      local_b0 = (longlong *)0x0;
      local_a8 = (longlong *)0x0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      uVar6 = 1;
    }
  }
  return uVar6;
}

