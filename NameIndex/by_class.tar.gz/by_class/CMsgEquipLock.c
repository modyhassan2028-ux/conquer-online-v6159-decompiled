// ==== CMsgEquipLock::helper_14032fe60  @14032fe60  [medium:callgraph-r0]  (orig: FUN_14032fe60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14032fe60(longlong *param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  ulonglong uVar3;
  undefined7 uVar4;
  undefined1 auStack_898 [32];
  uint local_878;
  undefined4 local_870;
  undefined4 local_868;
  undefined8 local_860;
  undefined8 local_858;
  undefined1 local_848 [1072];
  char local_418;
  undefined1 local_417 [1022];
  undefined1 local_19;
  ulonglong local_18;
  
  if (param_2 != 0) {
    local_858 = 0xfffffffffffffffe;
    local_18 = DAT_1409707c0 ^ (ulonglong)auStack_898;
    local_418 = '\0';
    memset(local_417,0,0x3ff);
    local_870 = (**(code **)(*param_1 + 8))(param_1);
    local_860 = 0;
    local_868 = 3;
    local_878 = param_2;
    _snprintf(&local_418,0x400,
              "UPDATE cq_item SET SpecialFlag = %u WHERE id = %u AND player_id = %u AND (SpecialFlag = %u OR SpecialFlag = %u) LIMIT 1"
             );
    local_19 = 0;
    FUN_140008520((int)param_1[0x246]);
    plVar2 = (longlong *)InstanceGet();
    (**(code **)(*plVar2 + 0x30))(plVar2,&local_418,1);
    (**(code **)(*param_1 + 8))(param_1);
    local_878 = 1;
    tq::MyLogSave("gmlog/EquipmentLockStatus",
                  "item id:%u owner id:%u lock status:%d lock by CUser::LockOtherItem");
    uVar3 = (ulonglong)param_2;
    _snprintf(&local_418,0x400,"DELETE FROM ghostcontract WHERE Item_id = %u LIMIT 1");
    local_19 = 0;
    FUN_140008520((int)param_1[0x246]);
    plVar2 = (longlong *)InstanceGet();
    uVar4 = (undefined7)(uVar3 >> 8);
    (**(code **)(*plVar2 + 0x30))(plVar2,&local_418,1);
    FUN_1403f2320(local_848);
    local_878 = 0;
    cVar1 = FUN_1403f23d0(local_848,0,param_2,CONCAT71(uVar4,1));
    if (cVar1 != '\0') {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_848);
    }
    FUN_1403f2370(local_848);
  }
  return;
}

// ==== CMsgEquipLock::helper_140337e30  @140337e30  [medium:callgraph-r0]  (orig: FUN_140337e30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140337e30(longlong param_1,undefined4 param_2)

{
  char cVar1;
  undefined1 auStack_488 [32];
  int local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  local_468 = FUN_140337d00();
  if (local_468 != 0) {
    FUN_1403f2320(local_448);
    cVar1 = FUN_1403f23d0(local_448,2,param_2,3);
    if (cVar1 != '\0') {
      (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_448);
    }
    FUN_1403f2370(local_448);
  }
  return;
}

// ==== CMsgEquipLock::helper_140359050  @140359050  [medium:callgraph-r0]  (orig: FUN_140359050)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140359050(longlong param_1,int param_2,int param_3,undefined4 param_4)

{
  char cVar1;
  ulong uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  longlong *plVar6;
  longlong *plVar7;
  int *piVar8;
  ulonglong uVar9;
  undefined7 uVar10;
  undefined1 auStack_8a8 [32];
  int local_888;
  int local_880;
  undefined4 local_878 [2];
  undefined8 local_870;
  undefined1 local_868 [1072];
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_870 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_8a8;
  if (param_2 == 0) {
    local_888 = 0x13e2;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_888 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x60))(plVar6,param_2);
    if (plVar6 != (longlong *)0x0) {
      FUN_1403f2320(local_868);
      if (param_3 == 1) {
        cVar1 = FUN_1400ff650(plVar6);
        if (cVar1 != '\0') {
          local_438 = '\0';
          memset(local_437,0,0x3ff);
          (**(code **)(*plVar6 + 8))(plVar6);
          _snprintf(&local_438,0x400,"DELETE FROM ghostcontract WHERE Item_id = %u LIMIT 1");
          local_39 = 0;
          FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
          plVar7 = (longlong *)InstanceGet();
          (**(code **)(*plVar7 + 0x30))(plVar7,&local_438,1);
        }
        FUN_140104960(plVar6,1,param_4);
        uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
        local_888 = 0;
        cVar1 = FUN_1403f23d0(local_868,0,uVar4,1);
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))
                    ((longlong *)(param_1 + 0x10),local_868);
        }
      }
      else if (param_3 == 3) {
        FUN_140104960(plVar6,3,param_4);
        uVar2 = tq::TimeGet(3);
        iVar3 = tq::DateStampPass(uVar2 + 19000000,5);
        local_438 = '\0';
        memset(local_437,0,0x3ff);
        uVar4 = FUN_1400fda10(plVar6,2,1);
        uVar5 = (**(code **)(*plVar6 + 8))(plVar6);
        uVar9 = (ulonglong)uVar5;
        local_888 = uVar4;
        local_880 = iVar3;
        _snprintf(&local_438,0x400,
                  "INSERT INTO GhostContract SET Item_id = %u, owner_id = %u, timeout = %u");
        local_39 = 0;
        FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
        plVar7 = (longlong *)InstanceGet();
        uVar10 = (undefined7)(uVar9 >> 8);
        (**(code **)(*plVar7 + 0x30))(plVar7,&local_438,1);
        local_878[0] = (**(code **)(*plVar6 + 8))(plVar6);
        piVar8 = (int *)FUN_140358f20(param_1 + 0xde8,local_878);
        *piVar8 = iVar3;
        uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
        local_888 = iVar3;
        cVar1 = FUN_1403f23d0(local_868,1,uVar4,CONCAT71(uVar10,3));
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))
                    ((longlong *)(param_1 + 0x10),local_868);
        }
      }
      FUN_1403f2370(local_868);
    }
  }
  return;
}

// ==== CMsgEquipLock::ctor_or_dtor  @1403f2320  [high:vtable-assign]  (orig: FUN_1403f2320)
undefined8 * FUN_1403f2320(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgEquipLock::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgEquipLock::ctor_or_dtor  @1403f2370  [high:vtable-assign]  (orig: FUN_1403f2370)
void FUN_1403f2370(undefined8 *param_1)

{
  *param_1 = CMsgEquipLock::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgEquipLock::vfunc_1  @1403f23a0  [high:rtti-vtable]  (orig: FUN_1403f23a0)
ulonglong FUN_1403f23a0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x800);
}

// ==== CMsgEquipLock::ctor_or_dtor  @1403f2450  [high:vtable-assign]  (orig: FUN_1403f2450)
undefined8 * FUN_1403f2450(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgEquipLock::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgEquipLock::ctor_or_dtor  @1403f24a0  [high:vtable-assign]  (orig: FUN_1403f24a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403f24a0(longlong param_1)

{
  undefined4 *puVar1;
  bool bVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  IStringManager *pIVar12;
  char *_Format;
  longlong *plVar13;
  longlong *plVar14;
  undefined1 auStack_4c8 [32];
  undefined1 *local_4a8;
  undefined8 local_498;
  undefined1 local_490 [56];
  undefined8 local_458;
  undefined4 local_450;
  undefined4 local_44c;
  int local_448 [251];
  undefined1 local_59;
  int *local_30;
  ulonglong local_28;
  
  local_498 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar9 + 0x90) == 0) {
    local_4a8 = (undefined1 *)CONCAT44(local_4a8._4_4_,0x130);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar10 = (longlong *)
            (**(code **)(**(longlong **)(lVar9 + 0x90) + 0x88))
                      (*(longlong **)(lVar9 + 0x90),param_1);
  if (plVar10 == (longlong *)0x0) {
    return;
  }
  plVar11 = (longlong *)0x0;
  cVar3 = FUN_140332fe0(plVar10,**(undefined4 **)(param_1 + 0x428));
  if ((cVar3 != '\0') ||
     (cVar3 = FUN_140333220(plVar10,**(undefined4 **)(param_1 + 0x428)), cVar3 != '\0')) {
    plVar13 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_4a8 = (undefined1 *)CONCAT44(local_4a8._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar13 = plVar11;
    }
    plVar11 = (longlong *)(**(code **)(*plVar13 + 0x60))(plVar13,**(undefined4 **)(param_1 + 0x428))
    ;
  }
  bVar2 = false;
  if (plVar11 == (longlong *)0x0) {
    plVar11 = (longlong *)CurrentInstanceGet();
    if ((plVar11 != (longlong *)0x0) &&
       (plVar11 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,0x12),
       plVar11 != (longlong *)0x0)) {
      lVar9 = *plVar11;
      puVar1 = *(undefined4 **)(param_1 + 0x428);
      uVar4 = (**(code **)(*plVar10 + 8))(plVar10);
      cVar3 = (**(code **)(lVar9 + 0x40))(plVar11,uVar4,*puVar1,0);
      if (cVar3 != '\0') {
        plVar11 = (longlong *)FUN_140087d40();
        plVar11 = (longlong *)
                  (**(code **)(*plVar11 + 0x60))(plVar11,**(undefined4 **)(param_1 + 0x428));
        bVar2 = true;
        if (plVar11 != (longlong *)0x0) goto LAB_1403f2662;
      }
    }
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    if (*(char *)(puVar1 + 1) == '\0') {
      FUN_14032fe60(plVar10,*puVar1);
    }
    else if (*(char *)(puVar1 + 1) == '\x02') {
      FUN_140337e30(plVar10,*puVar1);
    }
  }
  else {
LAB_1403f2662:
    uVar4 = FUN_1400fda10(plVar11,1,1);
    cVar3 = FUN_1400ff940(uVar4);
    if (cVar3 == '\0') {
      uVar4 = FUN_1400fda10(plVar11,1,1);
      iVar5 = FUN_1400ff680(uVar4);
      if (iVar5 != 0x14) {
        uVar4 = FUN_1400fda10(plVar11,1,1);
        iVar5 = FUN_1400ff680(uVar4);
        if (iVar5 != 10) {
          uVar4 = FUN_1400fda10(plVar11,1,1);
          iVar5 = FUN_1400ff680(uVar4);
          if (iVar5 != 0xb) {
            uVar4 = FUN_1400fda10(plVar11,1,1);
            iVar5 = FUN_1400ff680(uVar4);
            if (iVar5 != 0xe) {
              return;
            }
          }
        }
      }
    }
    cVar3 = *(char *)(*(longlong *)(param_1 + 0x428) + 4);
    if (cVar3 == '\0') {
      cVar3 = FUN_1400ff650(plVar11,2);
      if (((cVar3 != '\0') || (cVar3 = FUN_1400ff650(plVar11,1), cVar3 == '\0')) &&
         (cVar3 = FUN_1400ffc20(plVar11), cVar3 == '\0')) {
        uVar4 = (**(code **)(*plVar11 + 8))(plVar11);
        FUN_140359050(plVar10,uVar4,1);
      }
    }
    else if (cVar3 == '\x01') {
      cVar3 = FUN_1400ff650(plVar11,1);
      if (cVar3 == '\0') {
        cVar3 = FUN_1400ff650(plVar11);
        if (cVar3 != '\0') {
          local_458 = (undefined **)((ulonglong)local_458 & 0xffffffffffffff00);
          memset((void *)((longlong)&local_458 + 1),0,0x3ff);
          pIVar12 = theInstance();
          FUN_140100430(plVar11,0x65);
          _Format = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_UNLOCKSTATUS");
          _snprintf((char *)&local_458,0x400,_Format);
          local_59 = 0;
          (**(code **)(plVar10[2] + 0x358))(plVar10 + 2,&local_458);
        }
      }
      else if (*(char *)((longlong)plVar10 + 0x51c) != '\0') {
        uVar4 = (**(code **)(*plVar11 + 8))(plVar11);
        FUN_140359050(plVar10,uVar4,3);
      }
    }
    else if ((cVar3 == '\x02') &&
            ((cVar3 = FUN_1400ff650(plVar11,2), cVar3 != '\0' ||
             (cVar3 = FUN_1400ff650(plVar11,1), cVar3 != '\0')))) {
      FUN_1402ba1c0(&local_458);
      local_458 = CMsgEquipLock::vftable;
      FUN_1402b5600(&local_458);
      local_30 = local_448;
      uVar4 = (**(code **)(*plVar11 + 8))(plVar11);
      iVar5 = FUN_140337d00(plVar10,uVar4);
      iVar6 = (**(code **)(*plVar11 + 8))(plVar11);
      if (iVar6 == 0) {
        local_4a8 = (undefined1 *)CONCAT44(local_4a8._4_4_,0x2c);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        local_450 = 0x800;
        local_44c = 0xc;
        *local_30 = iVar6;
        *(undefined1 *)(local_30 + 1) = 2;
        *(undefined1 *)((longlong)local_30 + 5) = 3;
        local_30[2] = iVar5;
        (**(code **)(plVar10[2] + 0x350))(plVar10 + 2,&local_458);
      }
      local_458 = CMsgEquipLock::vftable;
      FUN_1402b55f0(&local_458);
    }
    if (((plVar11 != (longlong *)0x0) && (bVar2)) &&
       ((plVar13 = (longlong *)CurrentInstanceGet(), plVar13 != (longlong *)0x0 &&
        (plVar13 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,0x12),
        plVar13 != (longlong *)0x0)))) {
      plVar14 = (longlong *)FUN_140087d40();
      lVar9 = *plVar14;
      uVar4 = (**(code **)(*plVar11 + 8))(plVar11);
      cVar3 = (**(code **)(lVar9 + 0xc0))(plVar14,uVar4,local_490);
      if (cVar3 == '\0') {
        local_4a8 = (undefined1 *)CONCAT44(local_4a8._4_4_,0xaf);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        lVar9 = *plVar13;
        uVar4 = (**(code **)(*plVar11 + 8))(plVar11);
        uVar7 = FUN_1400fda10(plVar11,2,1);
        uVar8 = (**(code **)(*plVar10 + 8))(plVar10);
        local_4a8 = local_490;
        (**(code **)(lVar9 + 0x88))(plVar13,uVar8,uVar7,uVar4);
      }
    }
  }
  return;
}

