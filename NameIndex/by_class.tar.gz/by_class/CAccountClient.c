// ==== CAccountClient::ctor_or_dtor  @140503610  [high:vtable-assign]  (orig: FUN_140503610)
undefined8 * FUN_140503610(undefined8 *param_1)

{
  FUN_140506e80();
  *param_1 = CAccountClient::vftable;
  return param_1;
}

// ==== CAccountClient::ctor_or_dtor  @140503640  [high:vtable-assign]  (orig: FUN_140503640)
void FUN_140503640(undefined8 *param_1)

{
  *param_1 = CAccountClient::vftable;
  FUN_1405061c0();
  return;
}

// ==== CAccountClient::vfunc_1  @140503670  [high:rtti-vtable]  (orig: FUN_140503670)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140503670(longlong *param_1,longlong param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  undefined1 auStack_458 [32];
  undefined8 local_438;
  CIniFile local_428 [1024];
  undefined8 local_28;
  undefined2 local_20;
  undefined4 local_1e;
  undefined2 local_1a;
  ulonglong local_18;
  
  local_438 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  if ((param_2 == 0) || (param_3 != 3)) {
    uVar3 = 0;
  }
  else {
    param_1[0x208] = param_2;
    *(undefined4 *)(param_1 + 0x207) = 3;
    CIniFile::CIniFile(local_428,"shell.ini","AccountServer");
    local_28 = DAT_1406e8af0;
    local_20 = DAT_1406e8af8;
    local_1e = 0;
    local_1a = 0;
    CIniFile::GetString(local_428,(char *)&local_28,"ACCOUNT_IP",0x10);
    iVar2 = CIniFile::GetInt(local_428,"ACCOUNT_PORT");
    if (iVar2 == 0) {
      log_InlineLogERROR(&DAT_14079ad48,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\accountclient.cpp",
                         0x27);
      CIniFile::~CIniFile(local_428);
      uVar3 = 0;
    }
    else {
      cVar1 = (**(code **)(*param_1 + 0x40))(param_1,&local_28,iVar2);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CClientSocket::Create, AccountServer client socket Open error.");
        CIniFile::~CIniFile(local_428);
        uVar3 = 1;
      }
      else {
        CIniFile::~CIniFile(local_428);
        uVar3 = 1;
      }
    }
  }
  return uVar3;
}

// ==== CAccountClient::vfunc_2  @1405037c0  [high:rtti-vtable]  (orig: FUN_1405037c0)
void FUN_1405037c0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CAccountClient::vfunc_3  @1405037e0  [high:rtti-vtable]  (orig: FUN_1405037e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1405037e0(longlong *param_1)

{
  ushort uVar1;
  char cVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  longlong *plVar4;
  int iVar5;
  int iVar6;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined1 local_444 [1052];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  if (param_1[0x208] == 0) {
    local_458 = (undefined4 *)CONCAT44(local_458._4_4_,0x3a);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX;
  }
  else {
    uVar3 = (ulonglong)*(uint *)(param_1 + 0x105);
    if (0 < (int)*(uint *)(param_1 + 0x105)) {
      iVar5 = 0;
      iVar6 = 0;
      do {
        if ((int)uVar3 < 4) break;
        uVar1 = *(ushort *)(param_1 + 5);
        if ((int)uVar3 < (int)(uint)uVar1) break;
        memset((void *)((longlong)&local_448 + 1),0,0x417);
        local_448 = (uint)uVar1;
        memcpy(local_444,param_1 + 5,(ulonglong)uVar1);
        plVar4 = (longlong *)FUN_1404f7270(param_1[0x208]);
        local_458 = &local_448;
        (**(code **)(*plVar4 + 0x50))(plVar4,2,0x4e34,0x418);
        cVar2 = (**(code **)(*param_1 + 0x58))(param_1,(ulonglong)uVar1,0);
        if (cVar2 == '\0') break;
        uVar3 = (ulonglong)*(uint *)(param_1 + 0x105);
        iVar5 = iVar5 + 1;
        iVar6 = iVar6 + (uint)uVar1;
      } while (0 < (int)*(uint *)(param_1 + 0x105));
      LOCK();
      uVar3 = (ulonglong)DAT_14097575c;
      UNLOCK();
      LOCK();
      DAT_1409757b4 = DAT_1409757b4 + iVar5;
      UNLOCK();
      LOCK();
      DAT_1409757b0 = DAT_1409757b0 + iVar6;
      UNLOCK();
      DAT_14097575c = DAT_14097575c + iVar5;
    }
  }
  return uVar3;
}

// ==== CAccountClient::ctor_or_dtor  @140503960  [high:vtable-assign]  (orig: FUN_140503960)
undefined8 * FUN_140503960(undefined8 *param_1,uint param_2)

{
  *param_1 = CAccountClient::vftable;
  FUN_1405061c0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CAccountClient::vfunc_4  @1405039b0  [high:rtti-vtable]  (orig: FUN_1405039b0)
void FUN_1405039b0(longlong *param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  char *pcVar4;
  
  cVar1 = (**(code **)(*param_1 + 0x48))();
  if ((cVar1 == '\0') && (*(int *)((longlong)param_1 + 0x1054) != 0)) {
    cVar1 = FUN_1400149a0(param_1 + 0x20a);
    if (cVar1 != '\0') {
      plVar2 = (longlong *)FUN_1404f7270();
      lVar3 = -1;
      pcVar4 = "Connect to account server again...";
      do {
        if (lVar3 == 0) break;
        lVar3 = lVar3 + -1;
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
      (**(code **)(*plVar2 + 0x50))
                (plVar2,0,0x9c41,~(uint)lVar3,"Connect to account server again...");
      (**(code **)(*param_1 + 0x38))(param_1);
    }
  }
  return;
}

