// ==== CSlotMgr::helper_14024f440  @14024f440  [medium:callgraph-r0]  (orig: FUN_14024f440)
undefined1 FUN_14024f440(longlong param_1)

{
  char cVar1;
  undefined1 uVar2;
  longlong lVar3;
  
  lVar3 = FUN_1404243f0(*(undefined4 *)(param_1 + 8));
  uVar2 = (undefined1)lVar3;
  *(longlong *)(param_1 + 0x10) = lVar3;
  if (lVar3 != 0) {
    cVar1 = FUN_140423d50(lVar3);
    uVar2 = 0;
    if (cVar1 != '\0') {
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CSlotMgr::helper_140250010  @140250010  [medium:callgraph-r3]  (orig: FUN_140250010)
void FUN_140250010(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x31) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x31) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x31);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x31);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x31);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x31);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140250034. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CSlotMgr::helper_140251260  @140251260  [medium:callgraph-r3]  (orig: FUN_140251260)
void FUN_140251260(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x45) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CSlotMgr::helper_1402512c0  @1402512c0  [medium:callgraph-r3]  (orig: FUN_1402512c0)
void FUN_1402512c0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x45) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CSlotMgr::helper_140251380  @140251380  [medium:callgraph-r3]  (orig: FUN_140251380)
void FUN_140251380(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x31) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CSlotMgr::helper_1402513e0  @1402513e0  [medium:callgraph-r3]  (orig: FUN_1402513e0)
void FUN_1402513e0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x31) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CSlotMgr::helper_1402514f0  @1402514f0  [medium:callgraph-r3]  (orig: FUN_1402514f0)
void FUN_1402514f0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x45) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x45) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x45);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x45);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x45);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x45);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140251514. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CSlotMgr::helper_140251d10  @140251d10  [medium:callgraph-r2]  (orig: FUN_140251d10)
void FUN_140251d10(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x45);
  while (cVar1 == '\0') {
    FUN_140251d10(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x45);
  }
  return;
}

// ==== CSlotMgr::helper_140252290  @140252290  [medium:callgraph-r1]  (orig: FUN_140252290)
void FUN_140252290(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x48);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x44) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x45) = 0;
  return;
}

// ==== CSlotMgr::helper_1402522f0  @1402522f0  [medium:callgraph-r1]  (orig: FUN_1402522f0)
void FUN_1402522f0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x38);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 6) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x31) = 0;
  return;
}

// ==== CSlotMgr::helper_140252410  @140252410  [medium:callgraph-r3]  (orig: FUN_140252410)
void FUN_140252410(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x31);
  while (cVar1 == '\0') {
    FUN_140252410(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x31);
  }
  return;
}

// ==== CSlotMgr::helper_140252670  @140252670  [medium:callgraph-r1]  (orig: FUN_140252670)
void FUN_140252670(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x45);
  while (cVar1 == '\0') {
    FUN_140251d10(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x45);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CSlotMgr::helper_1402529f0  @1402529f0  [medium:callgraph-r2]  (orig: FUN_1402529f0)
undefined8 * FUN_1402529f0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x45) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402514f0(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x45) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x45) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x45) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x44);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x44);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_140252bdc;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x45) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x45) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x45);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x45);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x45) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x45);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x45);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_140252bdc:
  if (*(char *)((longlong)plVar5 + 0x44) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x44) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x44) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x44) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x44) = 0;
            FUN_140251260(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x45) == '\0') {
            if ((*(char *)(*plVar11 + 0x44) != '\x01') || (*(char *)(plVar11[2] + 0x44) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x44) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x44) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x44) = 0;
                FUN_1402512c0(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x44) = *(undefined1 *)((longlong)plVar10 + 0x44);
              *(undefined1 *)((longlong)plVar10 + 0x44) = 1;
              *(undefined1 *)(plVar11[2] + 0x44) = 1;
              FUN_140251260(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x44) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x44) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x44) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x44) = 0;
            FUN_1402512c0(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x45) == '\0') {
            if ((*(char *)(plVar11[2] + 0x44) != '\x01') || (*(char *)(*plVar11 + 0x44) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x44) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x44) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x44) = 0;
                FUN_140251260(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x44) = *(undefined1 *)((longlong)plVar10 + 0x44);
              *(undefined1 *)((longlong)plVar10 + 0x44) = 1;
              *(undefined1 *)(*plVar11 + 0x44) = 1;
              FUN_1402512c0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x44) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x44) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CSlotMgr::helper_140252fa0  @140252fa0  [medium:callgraph-r2]  (orig: FUN_140252fa0)
undefined8 * FUN_140252fa0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x31) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140250010(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x31) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x31) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 6;
        plVar8 = plVar8 + 6;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14025318c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x31);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x31);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x31);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x31);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14025318c:
  if ((char)plVar2[6] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[6] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[6] == '\0') {
            *(undefined1 *)(plVar9 + 6) = 1;
            *(undefined1 *)(plVar8 + 6) = 0;
            FUN_140251380(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x31) == '\0') {
            if ((*(char *)(*plVar9 + 0x30) != '\x01') || (*(char *)(plVar9[2] + 0x30) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x30) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x30) = 1;
                *(undefined1 *)(plVar9 + 6) = 0;
                FUN_1402513e0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 6) = (char)plVar8[6];
              *(undefined1 *)(plVar8 + 6) = 1;
              *(undefined1 *)(plVar9[2] + 0x30) = 1;
              FUN_140251380(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 6) = 0;
          }
        }
        else {
          if ((char)plVar9[6] == '\0') {
            *(undefined1 *)(plVar9 + 6) = 1;
            *(undefined1 *)(plVar8 + 6) = 0;
            FUN_1402513e0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x31) == '\0') {
            if ((*(char *)(plVar9[2] + 0x30) != '\x01') || (*(char *)(*plVar9 + 0x30) != '\x01')) {
              if (*(char *)(*plVar9 + 0x30) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x30) = 1;
                *(undefined1 *)(plVar9 + 6) = 0;
                FUN_140251380(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 6) = (char)plVar8[6];
              *(undefined1 *)(plVar8 + 6) = 1;
              *(undefined1 *)(*plVar9 + 0x30) = 1;
              FUN_1402513e0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 6) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 6) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CSlotMgr::helper_140253360  @140253360  [medium:callgraph-r2]  (orig: FUN_140253360)
void FUN_140253360(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x31);
  while (cVar1 == '\0') {
    FUN_140252410(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x31);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CSlotMgr::helper_140253a70  @140253a70  [medium:callgraph-r0]  (orig: FUN_140253a70)
void FUN_140253a70(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  FUN_140252670(param_1 + 3);
  if (param_1[2] != 0) {
    FUN_140424000(param_1[2]);
    param_1[2] = 0;
  }
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1,param_3,param_4,uVar1);
  }
  return;
}

// ==== CSlotMgr::helper_140253cb0  @140253cb0  [medium:callgraph-r1]  (orig: FUN_140253cb0)
longlong * FUN_140253cb0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140252670(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x45) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x45) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x45);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x45);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x45);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x45);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402529f0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CSlotMgr::helper_140254200  @140254200  [medium:callgraph-r0]  (orig: FUN_140254200)
void FUN_140254200(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140253cb0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CSlotMgr::helper_140254a00  @140254a00  [medium:callgraph-r1]  (orig: FUN_140254a00)
longlong * FUN_140254a00(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140253360(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x31) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x31) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x31);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x31);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x31);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x31);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140252fa0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CSlotMgr::helper_140255890  @140255890  [medium:callgraph-r0]  (orig: FUN_140255890)
void FUN_140255890(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140254a00((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CSlotMgr::ctor_or_dtor  @140256f00  [high:vtable-assign]  (orig: FUN_140256f00)
void FUN_140256f00(undefined8 *param_1)

{
  *param_1 = CSlotMgr::vftable;
  FUN_140255890(param_1 + 0xb);
  operator_delete((void *)param_1[0xb]);
  FUN_140254200(param_1 + 3);
  operator_delete((void *)param_1[3]);
  return;
}

// ==== CSlotMgr::helper_140257660  @140257660  [medium:callgraph-r0]  (orig: FUN_140257660)
undefined8 * FUN_140257660(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140252290(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x45) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CSlotMgr::helper_1402576e0  @1402576e0  [medium:callgraph-r0]  (orig: FUN_1402576e0)
undefined8 * FUN_1402576e0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402522f0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x31) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CSlotMgr::ctor_or_dtor  @140257940  [high:vtable-assign]  (orig: FUN_140257940)
undefined8 * FUN_140257940(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CSlotMgr::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  param_1[2] = 0;
  FUN_140257660(param_1 + 3);
  FUN_1402576e0(param_1 + 0xb);
  return param_1;
}

// ==== CSlotMgr::ctor_or_dtor  @140257990  [high:vtable-assign]  (orig: FUN_140257990)
undefined8 * FUN_140257990(undefined8 *param_1,uint param_2)

{
  *param_1 = CSlotMgr::vftable;
  FUN_140255890(param_1 + 0xb);
  operator_delete((void *)param_1[0xb]);
  FUN_140254200(param_1 + 3);
  operator_delete((void *)param_1[3]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CSlotMgr::ctor_or_dtor  @140257a20  [high:vtable-assign]  (orig: FUN_140257a20)
undefined8 * FUN_140257a20(undefined4 param_1)

{
  char cVar1;
  undefined8 *puVar2;
  
  puVar2 = operator_new(0x98);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CSlotMgr::vftable;
    *(undefined4 *)(puVar2 + 1) = param_1;
    puVar2[2] = 0;
    FUN_140257660(puVar2 + 3);
    FUN_1402576e0(puVar2 + 0xb);
  }
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_14024f440(puVar2);
    if (cVar1 == '\0') {
      FUN_140253a70(puVar2);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

// ==== CSlotMgr::helper_140423650  @140423650  [medium:callgraph-r2]  (orig: FUN_140423650)
void FUN_140423650(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  int iVar10;
  undefined1 local_res8 [4];
  int local_resc;
  undefined1 local_48 [32];
  
  plVar2 = *(longlong **)(param_1 + 0x10);
  plVar7 = (longlong *)**(undefined8 **)(param_1 + 0x40);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar7;
          plVar7 = *(longlong **)(param_1 + 0x40);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
            _invalid_parameter_noinfo();
          }
          if (plVar6 == plVar7) {
            return;
          }
          iVar10 = 0;
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = 0;
          }
          else {
            lVar8 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar8 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar8 = plVar6[3];
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar9 = 0;
          }
          else {
            lVar9 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar9 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          plVar7 = (longlong *)plVar6[7];
          if ((longlong *)plVar6[8] < plVar7) {
            _invalid_parameter_noinfo();
          }
          plVar5 = (longlong *)plVar6[4];
          while( true ) {
            plVar4 = (longlong *)plVar6[8];
            if (plVar4 < (longlong *)plVar6[7]) {
              _invalid_parameter_noinfo();
            }
            if ((plVar5 == (longlong *)0x0) || (plVar5 != (longlong *)plVar6[4])) {
              _invalid_parameter_noinfo();
            }
            if (plVar7 == plVar4) break;
            if (plVar5 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar9 = 0;
            }
            else {
              lVar9 = *plVar5;
            }
            if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
              _invalid_parameter_noinfo();
            }
            plVar4 = (longlong *)*plVar7;
            if (plVar4 != (longlong *)0x0) {
              plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,3);
              iVar3 = (**(code **)(*plVar4 + 0x50))(plVar4);
              iVar10 = iVar10 + iVar3;
            }
            if (plVar5 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar9 = 0;
            }
            else {
              lVar9 = *plVar5;
            }
            if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
              _invalid_parameter_noinfo();
            }
            plVar7 = plVar7 + 1;
          }
          local_res8[0] = (char)lVar8;
          local_resc = iVar10;
          FUN_1401e2440(param_1 + 0x50,local_48,local_res8);
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x51) == '\0') break;
          _invalid_parameter_noinfo();
          plVar7 = plVar6;
        }
        plVar7 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar7 + 0x51) != '\0') break;
        cVar1 = *(char *)(*plVar7 + 0x51);
        plVar6 = (longlong *)*plVar7;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x51);
          plVar7 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar7 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar7 + 0x51) != '\0');
    do {
      plVar5 = plVar7;
      plVar7 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar7 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar7 + 0x51) == '\0');
  } while( true );
}

// ==== CSlotMgr::helper_140423d50  @140423d50  [medium:callgraph-r1]  (orig: FUN_140423d50)
undefined8 FUN_140423d50(longlong param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined1 uVar3;
  int iVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  int iVar9;
  undefined1 local_res10 [8];
  longlong *local_res18;
  void **local_res20;
  longlong *local_d0 [3];
  void *local_b8;
  undefined8 local_b0;
  undefined8 local_a8;
  longlong *local_a0;
  longlong local_98;
  longlong *local_90 [3];
  undefined1 local_78 [8];
  void *local_70 [3];
  void *local_58;
  undefined8 local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  plVar5 = (longlong *)InstanceGet();
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"SELECT * FROM cq_slot_winning_rule",1);
  uVar7 = 0;
  if (plVar5 != (longlong *)0x0) {
    lVar6 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (lVar6 == 0) {
      tq::MyLogSave("gmlog/slot",
                    "error-->CSlotWinningRule::Create. cq_slot_winning_rule record count is 0!");
      (**(code **)*plVar5)(plVar5);
      uVar7 = 0;
    }
    else {
      for (iVar9 = 0; iVar4 = (**(code **)(*plVar5 + 0x40))(plVar5), iVar9 < iVar4;
          iVar9 = iVar9 + 1) {
        (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)iVar9);
        local_res18 = (longlong *)(**(code **)(*plVar5 + 0x38))(plVar5);
        if (local_res18 != (longlong *)0x0) {
          plVar8 = (longlong *)(**(code **)(*local_res18 + 0x10))(local_res18,1);
          uVar3 = (**(code **)(*plVar8 + 0x20))(plVar8);
          puVar1 = (undefined8 *)(param_1 + 0x10);
          local_res10[0] = uVar3;
          FUN_1403f4d90(puVar1,&local_a0,local_res10);
          plVar8 = local_a0;
          lVar6 = *(longlong *)(param_1 + 0x40);
          local_90[0] = (longlong *)*puVar1;
          if ((local_a0 == (longlong *)0x0) || (local_a0 != local_90[0])) {
            _invalid_parameter_noinfo();
          }
          lVar2 = local_98;
          if (local_98 == lVar6) {
            local_res20 = operator_new(8);
            if (local_res20 == (void **)0x0) {
              local_d0[0] = (longlong *)0x0;
            }
            else {
              *local_res20 = local_d0;
              local_d0[0] = (longlong *)local_res20;
            }
            local_b8 = (void *)0x0;
            local_b0 = 0;
            local_a8 = 0;
            local_90[0] = (longlong *)local_res20;
            FUN_140019370(local_d0,&local_res18);
            local_78[0] = uVar3;
            FUN_140267b90(local_70,local_d0);
            FUN_1403f6580(puVar1,local_90,local_78);
            local_res20 = local_70;
            if (local_58 != (void *)0x0) {
              operator_delete(local_58);
            }
            local_58 = (void *)0x0;
            local_50 = 0;
            local_48 = 0;
            operator_delete(local_70[0]);
            if (local_b8 != (void *)0x0) {
              operator_delete(local_b8);
            }
            local_b8 = (void *)0x0;
            local_b0 = 0;
            local_a8 = 0;
            operator_delete(local_d0[0]);
          }
          else {
            if (plVar8 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar6 = 0;
            }
            else {
              lVar6 = *plVar8;
            }
            if (lVar2 == *(longlong *)(lVar6 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            FUN_140019370(lVar2 + 0x20,&local_res18);
          }
        }
      }
      (**(code **)*plVar5)(plVar5);
      FUN_140423650(param_1);
      uVar7 = 1;
    }
  }
  return uVar7;
}

// ==== CSlotMgr::helper_140424000  @140424000  [medium:callgraph-r1]  (orig: FUN_140424000)
void FUN_140424000(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  
  uVar10 = 0xfffffffffffffffe;
  plVar8 = *(longlong **)param_1[8];
  plVar2 = (longlong *)param_1[2];
  plVar11 = plVar2;
  plVar12 = plVar8;
  while( true ) {
    plVar3 = (longlong *)param_1[8];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[2])) {
      _invalid_parameter_noinfo();
    }
    if (plVar8 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = plVar8 + 4;
    plVar7 = (longlong *)plVar8[7];
    if ((longlong *)plVar8[8] < plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar4 = (longlong *)*plVar3;
    while( true ) {
      plVar5 = (longlong *)plVar8[8];
      if (plVar5 < (longlong *)plVar8[7]) {
        _invalid_parameter_noinfo();
      }
      if ((plVar4 == (longlong *)0x0) || (plVar4 != (longlong *)*plVar3)) {
        _invalid_parameter_noinfo();
      }
      if (plVar7 == plVar5) break;
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar4;
      }
      if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
        _invalid_parameter_noinfo();
      }
      puVar6 = (undefined8 *)*plVar7;
      if (puVar6 != (undefined8 *)0x0) {
        (**(code **)*puVar6)(puVar6,1);
      }
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar4;
      }
      if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
        _invalid_parameter_noinfo();
      }
      plVar7 = plVar7 + 1;
    }
    FUN_1400179f0(plVar3);
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar8 + 0x51) == '\0') {
      plVar12 = (longlong *)plVar8[2];
      if (*(char *)((longlong)plVar12 + 0x51) == '\0') {
        cVar1 = *(char *)(*plVar12 + 0x51);
        plVar8 = plVar12;
        plVar3 = (longlong *)*plVar12;
        while (plVar12 = plVar8, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x51);
          plVar8 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar8[1] + 0x51);
        plVar12 = (longlong *)plVar8[1];
        plVar3 = plVar8;
        while ((plVar8 = plVar12, plVar12 = plVar8, cVar1 == '\0' &&
               (plVar3 == (longlong *)plVar8[2]))) {
          cVar1 = *(char *)(plVar8[1] + 0x51);
          plVar12 = (longlong *)plVar8[1];
          plVar3 = plVar8;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  FUN_1403f6730(param_1 + 2,*(undefined8 *)(param_1[8] + 8),param_3,param_4,uVar10,plVar11,plVar12);
  *(undefined8 *)(param_1[8] + 8) = param_1[8];
  param_1[9] = 0;
  *(undefined8 *)param_1[8] = param_1[8];
  *(undefined8 *)(param_1[8] + 0x10) = param_1[8];
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[0x10] + 8) + 0x21);
  plVar8 = *(longlong **)(param_1[0x10] + 8);
  while (cVar1 == '\0') {
    FUN_1401dd110(param_1 + 10,plVar8[2]);
    plVar2 = (longlong *)*plVar8;
    operator_delete(plVar8);
    plVar8 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x21);
  }
  *(undefined8 *)(param_1[0x10] + 8) = param_1[0x10];
  param_1[0x11] = 0;
  *(undefined8 *)param_1[0x10] = param_1[0x10];
  *(undefined8 *)(param_1[0x10] + 0x10) = param_1[0x10];
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

