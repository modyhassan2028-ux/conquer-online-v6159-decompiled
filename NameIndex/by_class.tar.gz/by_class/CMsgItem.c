// ==== CMsgItem::ctor_or_dtor  @1400f83e0  [high:vtable-assign]  (orig: FUN_1400f83e0)
undefined8 * FUN_1400f83e0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgItem::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgItem::ctor_or_dtor  @1400f8430  [high:vtable-assign]  (orig: FUN_1400f8430)
void FUN_1400f8430(undefined8 *param_1)

{
  *param_1 = CMsgItem::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgItem::vfunc_1  @1400f8460  [high:rtti-vtable]  (orig: FUN_1400f8460)
ulonglong FUN_1400f8460(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3f1);
}

// ==== CMsgItem::helper_1400f8750  @1400f8750  [medium:callgraph-r0]  (orig: FUN_1400f8750)
ulonglong FUN_1400f8750(longlong param_1,undefined4 param_2)

{
  int *piVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  
  if (0x3fb < (longlong)*(int *)(param_1 + 0xc) + 4U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x5b;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x57 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 0x16) * 4) = param_2;
  lVar2 = *(longlong *)(param_1 + 0x428);
  piVar1 = (int *)(lVar2 + 0x16);
  *piVar1 = *piVar1 + 1;
  return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
}

// ==== CMsgItem::ctor_or_dtor  @1400f88c0  [high:vtable-assign]  (orig: FUN_1400f88c0)
undefined8 * FUN_1400f88c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgItem::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgItem::vfunc_3  @1400f8910  [high:rtti-vtable]  (orig: FUN_1400f8910)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400f8910(longlong param_1)

{
  undefined4 *puVar1;
  char cVar2;
  undefined1 uVar3;
  byte bVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  longlong lVar14;
  longlong *plVar15;
  longlong *plVar16;
  IStringManager *pIVar17;
  undefined8 uVar18;
  longlong lVar19;
  ulonglong uVar20;
  longlong *plVar21;
  undefined1 auStack_8f8 [32];
  undefined8 local_8d8;
  int local_8d0;
  undefined4 local_8c8;
  undefined4 local_8c0;
  int local_8b8;
  uint local_8b4;
  longlong local_8b0;
  undefined8 local_8a8;
  undefined1 local_898 [1072];
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_8a8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_8f8;
  local_8b0 = param_1;
  lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar14 + 0x90) == 0) {
    local_8d8 = CONCAT44(local_8d8._4_4_,0x130);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar15 = (longlong *)
            (**(code **)(**(longlong **)(lVar14 + 0x90) + 0x88))
                      (*(longlong **)(lVar14 + 0x90),param_1);
  if (plVar15 == (longlong *)0x0) {
    return;
  }
  plVar16 = (longlong *)FUN_1400e1e60();
  lVar19 = plVar15[0x1e2];
  lVar14 = *plVar16;
  puVar1 = *(undefined4 **)(param_1 + 0x428);
  uVar5 = (**(code **)(*plVar15 + 8))(plVar15);
  (**(code **)(lVar14 + 0x108))(plVar16,uVar5,(int)lVar19,*puVar1);
  cVar2 = (**(code **)(plVar15[2] + 0x220))(plVar15 + 2);
  if (cVar2 == '\0') {
    pIVar17 = theInstance();
    lVar14 = plVar15[2];
    uVar18 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_DIE");
    (**(code **)(lVar14 + 0x358))(plVar15 + 2,uVar18);
    return;
  }
  cVar2 = (**(code **)(plVar15[2] + 0x2d8))(plVar15 + 2,0x33);
  if (cVar2 != '\0') {
    return;
  }
  cVar2 = FUN_140167b70(plVar15);
  plVar16 = DAT_140975b60;
  if (cVar2 != '\0') {
    switch(*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10)) {
    case 4:
    case 6:
    case 0x25:
    case 0x29:
    case 0x2c:
    case 0x2d:
      break;
    default:
      goto switchD_1400f8a7a_caseD_5;
    }
  }
  lVar14 = *(longlong *)(param_1 + 0x428);
  switch(*(undefined2 *)(lVar14 + 0x10)) {
  case 1:
    local_8d0 = (uint)local_8d0._1_3_ << 8;
    local_8d8 = CONCAT44(local_8d8._4_4_,*(undefined4 *)(lVar14 + 0x16));
    FUN_140341c50(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined4 *)(lVar14 + 8),
                  *(undefined1 *)(lVar14 + 0x1e));
    break;
  case 2:
    uVar12 = (**(code **)(*plVar15 + 8))(plVar15);
    lVar14 = *(longlong *)(param_1 + 0x428);
    FUN_14033acb0(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined4 *)(lVar14 + 8),
                  uVar12 ^ *(uint *)(lVar14 + 0x12));
    break;
  case 3:
    iVar13 = (**(code **)(plVar15[2] + 0x158))
                       (plVar15 + 2,*(undefined2 *)(lVar14 + 10),*(undefined2 *)(lVar14 + 8));
    if (iVar13 < 0x1c) {
      cVar2 = FUN_140332fe0(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      plVar16 = DAT_140975b60;
      if (cVar2 != '\0') {
        if (DAT_140975b60 == (longlong *)0x0) {
          local_8d8 = CONCAT44(local_8d8._4_4_,0x3c0);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar14 = (**(code **)(*plVar16 + 0x60))
                           (plVar16,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        if (lVar14 != 0) {
          uVar18 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          cVar2 = FUN_14008a710(uVar18);
          if (cVar2 == '\0') {
            cVar2 = FUN_1400ffac0(lVar14);
            if (cVar2 == '\0') {
              lVar14 = *(longlong *)(param_1 + 0x428);
              local_8d8 = local_8d8 & 0xffffffffffffff00;
              FUN_14033cfa0(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined2 *)(lVar14 + 10),
                            *(undefined2 *)(lVar14 + 8));
            }
            else {
              pIVar17 = theInstance();
              lVar14 = plVar15[2];
              uVar18 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_NOT_DISCARDABLE");
              (**(code **)(lVar14 + 0x358))(plVar15 + 2,uVar18);
            }
          }
          else {
            local_8d8 = local_8d8 & 0xffffffffffffff00;
            FUN_14033a6a0(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),1);
          }
        }
      }
    }
    else {
      plVar16 = (longlong *)FUN_1400e1e60();
      lVar14 = *plVar16;
      uVar5 = (**(code **)(*plVar15 + 8))(plVar15);
      local_8c0 = 0;
      local_8c8 = 0;
      local_8d0 = 0;
      local_8d8 = local_8d8 & 0xffffffff00000000;
      (**(code **)(lVar14 + 0x28))(plVar16,uVar5,9,1);
      plVar16 = (longlong *)FUN_1400e1e60();
      lVar14 = *plVar16;
      iVar13 = tq::RandGet(0xb4);
      uVar5 = (**(code **)(*plVar15 + 8))(plVar15);
      (**(code **)(lVar14 + 0x38))(plVar16,uVar5,iVar13 + 0x3c,&DAT_140707988);
    }
    break;
  case 4:
    if ((char)plVar15[0x259] == '\0') {
      cVar2 = FUN_14034e2b0(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined4 *)(lVar14 + 8),1);
      if (cVar2 == '\0') {
        pIVar17 = theInstance();
        lVar14 = plVar15[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_UNABLE_USE_ITEM");
        (**(code **)(lVar14 + 0x358))(plVar15 + 2,uVar18);
      }
      else {
        cVar2 = FUN_14032b480(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        plVar16 = DAT_140975b60;
        if (cVar2 != '\0') {
          if (DAT_140975b60 == (longlong *)0x0) {
            local_8d8 = CONCAT44(local_8d8._4_4_,0x3c0);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          lVar14 = (**(code **)(*plVar16 + 0x60))
                             (plVar16,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          if (lVar14 != 0) {
            FUN_14036fe70(local_898);
            iVar13 = FUN_1403702e0(local_898,plVar15);
            if (iVar13 != 0) {
              (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_898);
            }
            FUN_14036fec0(local_898);
          }
        }
      }
    }
    break;
  case 5:
    plVar16 = (longlong *)FUN_1400e1e60();
    lVar14 = *plVar16;
    iVar13 = tq::RandGet(0x78);
    uVar5 = (**(code **)(*plVar15 + 8))(plVar15);
    (**(code **)(lVar14 + 0x40))(plVar16,uVar5,iVar13 + 0x3c,0x6b);
    break;
  case 6:
    if ((char)plVar15[0x259] == '\0') {
      cVar2 = FUN_14034ec60(plVar15,*(undefined4 *)(lVar14 + 8),1,0);
      if (cVar2 == '\0') {
        pIVar17 = theInstance();
        lVar14 = plVar15[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_YOUR_BAG_FULL");
        (**(code **)(lVar14 + 0x358))(plVar15 + 2,uVar18);
      }
      else {
        cVar2 = FUN_140167b70(plVar15);
        plVar16 = DAT_140975b60;
        if (cVar2 != '\0') {
          if (DAT_140975b60 == (longlong *)0x0) {
            local_8d8 = CONCAT44(local_8d8._4_4_,0x3c0);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar16 = (longlong *)
                    (**(code **)(*plVar16 + 0x60))
                              (plVar16,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          if (plVar16 == (longlong *)0x0) {
            return;
          }
          cVar2 = FUN_140103280(plVar16);
          if ((cVar2 != '\0') && (iVar13 = FUN_140100c20(plVar16), iVar13 != 0)) {
            FUN_14036ee80(local_898);
            lVar14 = *(longlong *)(param_1 + 0x428);
            uVar5 = FUN_1400fda10(plVar16,1,1);
            uVar6 = FUN_140100c20(plVar16);
            uVar7 = (**(code **)(*plVar16 + 8))(plVar16);
            uVar8 = (**(code **)(*plVar15 + 0x38))(plVar15);
            uVar9 = (**(code **)(*plVar15 + 8))(plVar15);
            local_8c0 = *(undefined4 *)(lVar14 + 8);
            local_8d8 = CONCAT44(local_8d8._4_4_,uVar7);
            local_8d0 = uVar6;
            local_8c8 = uVar5;
            cVar2 = FUN_14036ef90(local_898,6,uVar9,uVar8);
            if (cVar2 != '\0') {
              (**(code **)(*plVar15 + 0x138))(plVar15,local_898,4);
            }
            FUN_14036eed0(local_898);
          }
        }
        FUN_14036fe70(local_468);
        iVar13 = FUN_1403702e0(local_468,plVar15);
        if (iVar13 != 0) {
          (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_468);
        }
        FUN_14036fec0(local_468);
      }
    }
    break;
  case 7:
    cVar2 = FUN_140343420(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined4 *)(lVar14 + 8));
    if (cVar2 == '\0') {
      pIVar17 = theInstance();
      lVar14 = plVar15[2];
      uVar18 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_YOUR_BAG_FULL");
      (**(code **)(lVar14 + 0x358))(plVar15 + 2,uVar18);
    }
    break;
  case 0xe:
    cVar2 = FUN_1403569b0(plVar15,*(undefined4 *)(lVar14 + 4),1,0);
    if (cVar2 == '\0') {
      pIVar17 = theInstance();
      lVar14 = plVar15[2];
      uVar18 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_REPAIR_FAILED");
      (**(code **)(lVar14 + 0x358))(plVar15 + 2,uVar18);
    }
    break;
  case 0xf:
    FUN_14032b840(plVar15,CONCAT71((int7)((ulonglong)lVar14 >> 8),1));
    break;
  case 0x10:
    FUN_140333330(plVar15,*(undefined4 *)(lVar14 + 4),1);
    break;
  case 0x15:
    plVar16 = (longlong *)FUN_1400f8360();
    lVar14 = *plVar16;
    lVar19 = *(longlong *)(param_1 + 0x428);
    uVar5 = (**(code **)(*plVar15 + 8))(plVar15);
    iVar13 = (**(code **)(lVar14 + 0x60))(plVar16,uVar5,*(undefined4 *)(lVar19 + 8));
    if (iVar13 != 0) {
      plVar16 = (longlong *)FUN_1400f8360();
      lVar14 = *plVar16;
      uVar5 = (**(code **)(*plVar15 + 8))(plVar15);
      (**(code **)(lVar14 + 0x40))(plVar16,iVar13,uVar5);
    }
    break;
  case 0x16:
    iVar13 = FUN_140166ec0(plVar15);
    if (iVar13 != 0) {
      plVar16 = (longlong *)FUN_1400f8360();
      lVar14 = *plVar16;
      lVar19 = *(longlong *)(param_1 + 0x428);
      uVar5 = FUN_140166ec0(plVar15);
      local_8d8 = local_8d8 & 0xffffffff00000000;
      cVar2 = (**(code **)(lVar14 + 0x28))
                        (plVar16,uVar5,*(undefined4 *)(lVar19 + 4),*(undefined8 *)(lVar19 + 8));
      if (cVar2 != '\0') {
        (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,param_1);
      }
    }
    break;
  case 0x17:
    iVar13 = FUN_140166ec0(plVar15);
    if (iVar13 != 0) {
      plVar16 = (longlong *)FUN_1400f8360();
      lVar14 = *plVar16;
      lVar19 = *(longlong *)(param_1 + 0x428);
      uVar5 = FUN_140166ec0(plVar15);
      (**(code **)(lVar14 + 0x30))(plVar16,uVar5,*(undefined4 *)(lVar19 + 4));
    }
    break;
  case 0x18:
    plVar16 = (longlong *)FUN_1400f8360();
    lVar14 = *plVar16;
    lVar19 = *(longlong *)(param_1 + 0x428);
    uVar5 = (**(code **)(*plVar15 + 8))(plVar15);
    iVar13 = (**(code **)(lVar14 + 0x60))(plVar16,uVar5,*(undefined4 *)(lVar19 + 8));
    if (iVar13 != 0) {
      plVar16 = (longlong *)FUN_1400f8360();
      lVar14 = *plVar16;
      lVar19 = *(longlong *)(param_1 + 0x428);
      uVar5 = (**(code **)(*plVar15 + 8))(plVar15);
      (**(code **)(lVar14 + 0x38))(plVar16,iVar13,uVar5,*(undefined4 *)(lVar19 + 4));
    }
    break;
  case 0x1c:
    FUN_140348ec0(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined4 *)(lVar14 + 8));
    break;
  case 0x1d:
    iVar13 = FUN_140166ec0(plVar15);
    if (iVar13 != 0) {
      plVar16 = (longlong *)FUN_1400f8360();
      lVar14 = *plVar16;
      lVar19 = *(longlong *)(param_1 + 0x428);
      uVar5 = FUN_140166ec0(plVar15);
      local_8d8 = CONCAT44(local_8d8._4_4_,*(undefined4 *)(lVar19 + 8));
      cVar2 = (**(code **)(lVar14 + 0x28))(plVar16,uVar5,*(undefined4 *)(lVar19 + 4),0);
      if (cVar2 != '\0') {
        (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,param_1);
      }
    }
    break;
  case 0x23:
    if ((*(int *)(lVar14 + 0x16) == 0) ||
       ((ulonglong)(*(int *)(lVar14 + 0x16) - 1) * 4 + 0x5b < 0x3fd)) {
      FUN_140347de0(plVar15,*(undefined4 *)(lVar14 + 4),lVar14 + 0x57,*(undefined4 *)(lVar14 + 0x16)
                   );
    }
    break;
  case 0x24:
    FUN_1403349f0(plVar15,*(undefined4 *)(lVar14 + 4));
    break;
  case 0x25:
    iVar13 = 0;
    local_8b8 = 0;
    cVar2 = FUN_140167b70(plVar15);
    if (cVar2 == '\0') {
      cVar2 = *(char *)((longlong)plVar15 + 0x51c);
    }
    else {
      plVar16 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_8d8 = CONCAT44(local_8d8._4_4_,0x3c0);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar16 = (longlong *)0x0;
      }
      lVar14 = (**(code **)(*plVar16 + 0x60))
                         (plVar16,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (lVar14 == 0) {
        return;
      }
      lVar19 = (**(code **)(plVar15[2] + 0x160))(plVar15 + 2);
      if (lVar19 == 0) {
        return;
      }
      lVar19 = (**(code **)(plVar15[2] + 0x160))(plVar15 + 2);
      plVar16 = *(longlong **)(*(longlong *)(lVar19 + 0x58) + 8);
      plVar16 = (longlong *)(**(code **)(*plVar16 + 0x10))(plVar16,4);
      uVar20 = (**(code **)(*plVar16 + 0x58))(plVar16);
      if ((uVar20 >> 0x1f & 1) == 0) {
        return;
      }
      cVar2 = FUN_140100c40(lVar14);
    }
    if (cVar2 != '\0') {
      iVar10 = *(int *)(*(longlong *)(param_1 + 0x428) + 8);
      if (iVar10 != 0) {
        lVar14 = (longlong)(int)(iVar10 - 1U & 7);
        iVar13 = *(int *)(&DAT_1407075a8 + lVar14 * 4);
        local_8b8 = *(int *)(&DAT_1407075c8 + lVar14 * 4);
      }
      iVar10 = (**(code **)(plVar15[2] + 0x40))(plVar15 + 2);
      iVar11 = (**(code **)(plVar15[2] + 0x48))(plVar15 + 2);
      iVar11 = iVar11 + local_8b8;
      cVar2 = FUN_140332fe0(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (cVar2 != '\0') {
        plVar16 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_8d8 = CONCAT44(local_8d8._4_4_,0x3c0);
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar16 = (longlong *)0x0;
        }
        lVar14 = (**(code **)(*plVar16 + 0x60))
                           (plVar16,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        if (lVar14 != 0) {
          uVar18 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          cVar2 = FUN_14008a710(uVar18);
          if (cVar2 == '\0') {
            cVar2 = FUN_1400ffac0(lVar14);
            if (cVar2 == '\0') {
              local_8d8 = local_8d8 & 0xffffffffffffff00;
              FUN_14033cfa0(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                            iVar13 + iVar10,iVar11);
            }
            else {
              pIVar17 = theInstance();
              lVar14 = plVar15[2];
              uVar18 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_NOT_DISCARDABLE");
              (**(code **)(lVar14 + 0x358))(plVar15 + 2,uVar18);
            }
          }
          else {
            local_8d8 = local_8d8 & 0xffffffffffffff00;
            FUN_14033a6a0(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),1);
          }
        }
      }
    }
    break;
  case 0x27:
    FUN_1400f83e0(local_898);
    cVar2 = FUN_1403536b0(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                          *(int *)(*(longlong *)(param_1 + 0x428) + 8) == 1);
    if (cVar2 == '\0') {
      local_8d8 = (ulonglong)local_8d8._4_4_ << 0x20;
      iVar13 = FUN_1400f8490(local_898,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),0x27,0);
      if (iVar13 == 0) {
        local_8d8 = CONCAT44(local_8d8._4_4_,0x1c1);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_898);
      }
    }
    else {
      local_8d8 = (ulonglong)local_8d8._4_4_ << 0x20;
      iVar13 = FUN_1400f8490(local_898,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),0x27,1);
      if (iVar13 == 0) {
        local_8d8 = CONCAT44(local_8d8._4_4_,0x1ba);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_898);
      }
    }
    FUN_1400f8430(local_898);
    break;
  case 0x28:
    FUN_1400f83e0(local_898);
    iVar13 = *(int *)(*(longlong *)(param_1 + 0x428) + 0x16);
    if ((iVar13 == 0) || ((ulonglong)(iVar13 - 1) * 4 + 0x5b < 0x3fd)) {
      lVar14 = *(longlong *)(param_1 + 0x428);
      cVar2 = FUN_140349540(plVar15,*(undefined4 *)(lVar14 + 4),lVar14 + 0x57,
                            *(undefined4 *)(lVar14 + 0x16));
      if (cVar2 == '\0') {
        local_8d8 = (ulonglong)local_8d8._4_4_ << 0x20;
        iVar13 = FUN_1400f8490(local_898,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),0x28,0)
        ;
        if (iVar13 == 0) {
          local_8d8 = CONCAT44(local_8d8._4_4_,0x1f5);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_898);
        }
      }
      else {
        local_8d8 = (ulonglong)local_8d8._4_4_ << 0x20;
        iVar13 = FUN_1400f8490(local_898,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),0x28,1)
        ;
        if (iVar13 == 0) {
          local_8d8 = CONCAT44(local_8d8._4_4_,0x1ee);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_898);
        }
      }
      FUN_1400f8430(local_898);
    }
    else {
      FUN_1400f8430(local_898);
    }
    break;
  case 0x29:
    if (DAT_140975b60 == (longlong *)0x0) {
      local_8d8 = CONCAT44(local_8d8._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar14 = (**(code **)(*plVar16 + 0x60))
                       (plVar16,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if ((lVar14 != 0) &&
       (cVar2 = FUN_140332fe0(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4)),
       cVar2 != '\0')) {
      FUN_14032daf0(plVar15,lVar14);
    }
    break;
  case 0x2b:
    plVar16 = (longlong *)0x0;
    cVar2 = FUN_140332fe0(plVar15,*(undefined4 *)(lVar14 + 4));
    if ((cVar2 != '\0') ||
       (cVar2 = FUN_140333220(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4)),
       cVar2 != '\0')) {
      plVar21 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_8d8 = CONCAT44(local_8d8._4_4_,0x3c0);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar21 = plVar16;
      }
      plVar16 = (longlong *)
                (**(code **)(*plVar21 + 0x60))
                          (plVar21,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    }
    FUN_1400f83e0(local_898);
    iVar13 = *(int *)(*(longlong *)(param_1 + 0x428) + 0x16);
    if ((iVar13 != 0) && (0x3fc < (ulonglong)(iVar13 - 1) * 4 + 0x5b)) {
      FUN_1400f8430(local_898);
      return;
    }
    if (plVar16 == (longlong *)0x0) {
LAB_1400f99e5:
      lVar14 = *(longlong *)(param_1 + 0x428);
      uVar12 = FUN_140354140(plVar15,*(undefined4 *)(lVar14 + 4),lVar14 + 0x57,
                             *(undefined4 *)(lVar14 + 0x16));
    }
    else {
      uVar5 = FUN_1400fda10(plVar16,1,1);
      iVar13 = FUN_1400ff680(uVar5);
      if (iVar13 != 4) {
        uVar5 = FUN_1400fda10(plVar16,1,1);
        iVar13 = FUN_1400ff680(uVar5);
        if (iVar13 != 5) goto LAB_1400f99e5;
      }
      lVar14 = *(longlong *)(param_1 + 0x428);
      bVar4 = FUN_140349970(plVar15,*(undefined4 *)(lVar14 + 4),lVar14 + 0x57,
                            *(undefined4 *)(lVar14 + 0x16));
      uVar12 = (uint)bVar4;
    }
    local_8d8 = local_8d8 & 0xffffffff00000000;
    iVar13 = FUN_1400f8490(local_898,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),0x2b,uVar12
                          );
    if (iVar13 == 0) {
      local_8d8 = CONCAT44(local_8d8._4_4_,0x226);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_898);
    }
    FUN_1400f8430(local_898);
    break;
  case 0x2c:
    FUN_140354ed0(plVar15,1);
    FUN_14036fe70(local_468);
    iVar13 = FUN_1403702e0(local_468,plVar15);
    if (iVar13 != 0) {
      (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_468);
    }
    FUN_14036fec0(local_468);
    break;
  case 0x2d:
    FUN_140354800(plVar15);
    FUN_14036fe70(local_468);
    iVar13 = FUN_1403702e0(local_468,plVar15);
    if (iVar13 != 0) {
      (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_468);
    }
    FUN_14036fec0(local_468);
    break;
  case 0x30:
    FUN_14033bde0(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined4 *)(lVar14 + 8));
    break;
  case 0x31:
    cVar2 = FUN_14034a390(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined4 *)(lVar14 + 8));
    if (cVar2 == '\0') {
      pIVar17 = theInstance();
      lVar14 = plVar15[2];
      uVar18 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_BAG_FULL");
      (**(code **)(lVar14 + 0x358))(plVar15 + 2,uVar18);
    }
    break;
  case 0x32:
    FUN_1403402b0(plVar15,*(undefined4 *)(lVar14 + 4));
    break;
  case 0x33:
    FUN_1400f83e0(local_898);
    iVar13 = *(int *)(*(longlong *)(param_1 + 0x428) + 0x16);
    if ((iVar13 == 0) || ((ulonglong)(iVar13 - 1) * 4 + 0x5b < 0x3fd)) {
      uVar3 = FUN_140353d90(plVar15,*(longlong *)(param_1 + 0x428) + 0x57,
                            *(longlong *)(param_1 + 0x428) + 0x16);
      local_8d8 = local_8d8 & 0xffffffff00000000;
      iVar13 = FUN_1400f8490(local_898,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),0x33,
                             uVar3);
      if (iVar13 == 0) {
        local_8d8 = CONCAT44(local_8d8._4_4_,0x1d5);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        local_8b4 = 0;
        while (uVar12 = local_8b4, local_8b4 < *(uint *)(*(longlong *)(param_1 + 0x428) + 0x16)) {
          FUN_1400f8750(local_898,
                        *(undefined4 *)
                         (*(longlong *)(param_1 + 0x428) + 0x57 + (ulonglong)local_8b4 * 4));
          local_8b4 = uVar12 + 1;
        }
        (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_898);
      }
      FUN_1400f8430(local_898);
    }
    else {
      FUN_1400f8430(local_898);
    }
    break;
  case 0x34:
    FUN_14033a0a0(plVar15,*(undefined4 *)(lVar14 + 4));
    break;
  case 0x35:
    local_8d8 = lVar14 + 0x57;
    local_8d0 = *(undefined4 *)(lVar14 + 0x16);
    FUN_140342d10(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined4 *)(lVar14 + 8),
                  *(undefined1 *)(lVar14 + 0x1e));
    break;
  case 0x36:
    FUN_1400f83e0(local_468);
    cVar2 = FUN_1403337e0(plVar15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                          *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1e));
    if (cVar2 != '\0') {
      local_8d8 = local_8d8 & 0xffffffff00000000;
      iVar13 = FUN_1400f8490(local_468,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),0x36,
                             cVar2);
      if (iVar13 != 0) {
        (**(code **)(plVar15[2] + 0x350))(plVar15 + 2,local_468);
      }
    }
    FUN_1400f8430(local_468);
    break;
  case 0x37:
    local_8d0 = CONCAT31(local_8d0._1_3_,1);
    local_8d8 = CONCAT44(local_8d8._4_4_,*(undefined4 *)(lVar14 + 0x16));
    FUN_140341c50(plVar15,*(undefined4 *)(lVar14 + 4),*(undefined4 *)(lVar14 + 8),
                  *(undefined1 *)(lVar14 + 0x1e));
    break;
  case 0x38:
    cVar2 = FUN_140340c20(plVar15,*(undefined4 *)(lVar14 + 4));
    if (cVar2 == '\0') {
      pIVar17 = theInstance();
      lVar14 = plVar15[2];
      uVar18 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_UNABLE_USE_ITEM");
      (**(code **)(lVar14 + 0x358))(plVar15 + 2,uVar18);
    }
  }
switchD_1400f8a7a_caseD_5:
  return;
}

// ==== CMsgItem::helper_1400fe520  @1400fe520  [medium:callgraph-r1]  (orig: FUN_1400fe520)
longlong FUN_1400fe520(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  tm *ptVar3;
  __time32_t local_res8 [2];
  
  local_res8[0] = 0;
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                     (*(longlong **)(param_1 + 0x10),0x19);
  iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  if (iVar1 == 0) {
    if (*(longlong *)(param_1 + 0x18) == 0) {
      return 0;
    }
    plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,0x27);
    iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
    if (iVar1 == 0) {
      return 0;
    }
  }
  _time32(local_res8);
  local_res8[0] = local_res8[0] + 0x1e + iVar1 * 0x3c;
  ptVar3 = _localtime32(local_res8);
  if (ptVar3 == (tm *)0x0) {
    return 0;
  }
  return (longlong)
         (((((ptVar3->tm_year % 100) * 100 + 1 + ptVar3->tm_mon) * 100 + ptVar3->tm_mday) * 100 +
          ptVar3->tm_hour) * 100 + ptVar3->tm_min);
}

// ==== CMsgItem::helper_1400fe9d0  @1400fe9d0  [medium:callgraph-r1]  (orig: FUN_1400fe9d0)
void FUN_1400fe9d0(longlong param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int nNumber;
  longlong *plVar4;
  
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  iVar1 = (**(code **)(*plVar4 + 0x48))(plVar4);
  iVar1 = iVar1 % 10;
  if (iVar1 == 6) {
    iVar1 = 0xb;
  }
  else if (iVar1 == 7) {
    iVar1 = 0xc;
  }
  else if (iVar1 == 8) {
    iVar1 = 0xd;
  }
  else if (iVar1 == 9) {
    iVar1 = 0xf;
  }
  else {
    iVar1 = 10;
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),5);
  iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4);
  iVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
  if ((iVar2 / 100 - iVar3 / 100) + 1 < 0) {
    iVar2 = 0;
  }
  else {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),5)
    ;
    iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4)
    ;
    iVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    iVar2 = (iVar2 / 100 - iVar3 / 100) + 1;
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),5);
  iVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
  nNumber = FUN_1400fda10(param_1,0x70,1);
  iVar2 = MulDiv(nNumber,iVar2 * 3,(iVar3 / 100) * 4 + 4);
                    /* WARNING: Could not recover jumptable at 0x0001400feb90. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  MulDiv(iVar2,iVar1,10);
  return;
}

// ==== CMsgItem::helper_1400feba0  @1400feba0  [medium:callgraph-r1]  (orig: FUN_1400feba0)
int FUN_1400feba0(longlong param_1)

{
  int iVar1;
  int nNumerator;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),5);
  iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  if (iVar1 != 0) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),5)
    ;
    iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
    if (0 < iVar1) {
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                         (*(longlong **)(param_1 + 0x10),4);
      nNumerator = (**(code **)(*plVar3 + 0x48))(plVar3);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                         (*(longlong **)(param_1 + 0x10),5);
      iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
      if (iVar1 < nNumerator) {
        plVar3 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                           (*(longlong **)(param_1 + 0x10),5);
        nNumerator = (**(code **)(*plVar3 + 0x48))(plVar3);
      }
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                         (*(longlong **)(param_1 + 0x10),5);
      iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
      iVar2 = FUN_1400fda10(param_1,0x70,1);
                    /* WARNING: Could not recover jumptable at 0x0001400fecbf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar1 = MulDiv(iVar2 / 3,nNumerator,iVar1);
      return iVar1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMsgItem::helper_1400ffac0  @1400ffac0  [medium:callgraph-r0]  (orig: FUN_1400ffac0)
bool FUN_1400ffac0(longlong *param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  uint uVar3;
  longlong *plVar4;
  
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = (longlong *)0x0;
  }
  lVar1 = *plVar4;
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  uVar3 = (**(code **)(lVar1 + 200))(plVar4,uVar2);
  return 0x563 < uVar3;
}

// ==== CMsgItem::helper_140100d90  @140100d90  [medium:callgraph-r1]  (orig: FUN_140100d90)
uint FUN_140100d90(undefined4 param_1)

{
  uint uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x70))(plVar3,param_1);
  if (lVar2 != 0) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),10);
    uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
    return CONCAT31((uint3)(uVar1 >> 0xe),(char)(uVar1 >> 6)) & 0xffffff01;
  }
  return 0;
}

// ==== CMsgItem::helper_140103af0  @140103af0  [medium:callgraph-r1]  (orig: FUN_140103af0)
undefined8 FUN_140103af0(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  longlong *plVar4;
  
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar4 + 0x48))(plVar4);
  iVar2 = FUN_1400ff680(uVar1);
  if (iVar2 == 9) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1)
    ;
    uVar1 = (**(code **)(*plVar4 + 0x48))(plVar4);
    iVar2 = FUN_1400fecd0(uVar1);
    if (iVar2 == 20000) {
      return 1;
    }
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
  if (1199999 < uVar3) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1)
    ;
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    if (uVar3 < 0x124f83) {
      return 1;
    }
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
  if (2999999 < uVar3) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1)
    ;
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    if (uVar3 < 4000000) {
      return 1;
    }
  }
  return 0;
}

// ==== CMsgItem::helper_140103d80  @140103d80  [medium:callgraph-r1]  (orig: FUN_140103d80)
undefined8 FUN_140103d80(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  iVar2 = FUN_1400ff680(uVar1);
  if (iVar2 == 0) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1)
    ;
    uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
    iVar2 = FUN_1400fecd0(uVar1);
    if (iVar2 < 70000) {
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                         (*(longlong **)(param_1 + 0x10),5);
      iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
      if (1 < iVar2) {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CMsgItem::helper_140105800  @140105800  [medium:callgraph-r1]  (orig: FUN_140105800)
undefined8 FUN_140105800(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  ulonglong uVar4;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  iVar2 = FUN_1400ff680(uVar1);
  if (iVar2 == 9) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1)
    ;
    uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
    iVar2 = FUN_1400fecd0(uVar1);
    if (iVar2 == 80000) {
      return 0;
    }
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                     (*(longlong **)(param_1 + 0x10),0x12);
  iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  if (iVar2 == 0) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                       (*(longlong **)(param_1 + 0x10),0x13);
    uVar4 = (**(code **)(*plVar3 + 0x48))(plVar3);
    if ((uVar4 & 2) == 0) {
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                         (*(longlong **)(param_1 + 0x10),0x13);
      uVar4 = (**(code **)(*plVar3 + 0x48))(plVar3);
      if ((uVar4 & 1) == 0) {
        plVar3 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                           (*(longlong **)(param_1 + 0x10),0x17);
        iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
        if (iVar2 == 0) {
          return 1;
        }
      }
    }
  }
  return 0;
}

// ==== CMsgItem::helper_140105ae0  @140105ae0  [medium:callgraph-r1]  (orig: FUN_140105ae0)
int FUN_140105ae0(longlong param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  longlong *plVar4;
  int iVar5;
  
  iVar5 = 0;
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
  iVar2 = iVar2 % 10;
  if (iVar2 == 6) {
    iVar5 = 5;
  }
  else if (iVar2 == 7) {
    iVar5 = 10;
  }
  else if (iVar2 == 8) {
    iVar5 = 0x28;
  }
  else if (iVar2 == 9) {
    iVar5 = 1000;
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),8);
  iVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
  if ((iVar3 != 0) && (7 < iVar2)) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),9)
    ;
    iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    if (iVar2 == 0) {
      cVar1 = FUN_1400f8840(param_1);
      if (cVar1 == '\0') {
        iVar5 = iVar5 + 2000;
      }
      else {
        iVar5 = iVar5 + 0xa0;
      }
    }
    else {
      cVar1 = FUN_1400f8840(param_1);
      if (cVar1 == '\0') {
        iVar5 = iVar5 + 8000;
      }
      else {
        iVar5 = iVar5 + 0x3c0;
      }
    }
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),0xc)
  ;
  iVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
  iVar2 = 0;
  if ((-1 < iVar3) && (iVar2 = iVar3, 0xc < iVar3)) {
    iVar2 = 0xc;
  }
  return (&DAT_140708b00)[iVar2] + iVar5;
}

// ==== CMsgItem::helper_140106240  @140106240  [medium:callgraph-r1]  (orig: FUN_140106240)
undefined8 FUN_140106240(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong *plVar4;
  
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
  iVar3 = FUN_1400ff680(uVar2);
  if (iVar3 == 0) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1)
    ;
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    iVar3 = FUN_1400fecd0(uVar2);
    if (iVar3 < 70000) {
      return 0;
    }
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
  iVar3 = FUN_1400ff680(uVar2);
  if (iVar3 != 9) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1)
    ;
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    iVar3 = FUN_1400ff680(uVar2);
    if ((iVar3 != -1) && (cVar1 = FUN_140103af0(param_1), cVar1 == '\0')) {
      plVar4 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                         (*(longlong **)(param_1 + 0x10),5);
      iVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
      if (99 < iVar3) {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CMsgItem::helper_1401081b0  @1401081b0  [medium:callgraph-r2]  (orig: FUN_1401081b0)
longlong * FUN_1401081b0(longlong param_1)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined4 local_78 [28];
  
  plVar4 = (longlong *)FUN_140103820(*(undefined4 *)(param_1 + 0x3c));
  if (plVar4 != (longlong *)0x0) {
    FUN_140101cb0(param_1,local_78);
    local_78[0] = 0;
    cVar2 = FUN_140107480(plVar4,*(undefined4 *)(param_1 + 100),local_78,1,0);
    if (cVar2 == '\0') {
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = (longlong *)0x0;
      }
      lVar1 = *plVar5;
      uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
      (**(code **)(lVar1 + 0x58))(plVar5,uVar3,10);
      plVar4 = (longlong *)0x0;
    }
    return plVar4;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return (longlong *)0x0;
}

// ==== CMsgItem::helper_140108390  @140108390  [medium:callgraph-r1]  (orig: FUN_140108390)
longlong * FUN_140108390(longlong *param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  longlong *plVar5;
  longlong *plVar6;
  
  plVar5 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
  uVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
  iVar3 = FUN_1400ff680(uVar2);
  if (iVar3 == 0) {
    plVar5 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
    uVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
    iVar3 = FUN_1400fecd0(uVar2);
    if (iVar3 < 70000) {
      plVar5 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],5);
      iVar3 = (**(code **)(*plVar5 + 0x48))(plVar5);
      if (1 < iVar3) {
        plVar5 = (longlong *)FUN_1401081b0(param_1);
        if (plVar5 != (longlong *)0x0) {
          plVar6 = (longlong *)
                   (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],4);
          iVar3 = (**(code **)(*plVar6 + 0x48))(plVar6);
          if (param_2 < iVar3) {
            plVar6 = (longlong *)
                     (**(code **)(*(longlong *)plVar5[2] + 0x10))((longlong *)plVar5[2],4);
            (**(code **)(*plVar6 + 0xb0))(plVar6,param_2);
            uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
            if (((4099999999 < uVar4) && (*(int *)((longlong)plVar5 + 100) != 0)) &&
               (cVar1 = FUN_1401032b0(plVar5,4), cVar1 != '\0')) {
              *(undefined1 *)((longlong)plVar5 + 0x6d) = 1;
            }
            plVar6 = (longlong *)
                     (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],4);
            (**(code **)(*plVar6 + 0xb0))(plVar6,iVar3 - param_2);
            uVar4 = (**(code **)(*param_1 + 8))(param_1);
            if (((4099999999 < uVar4) && (*(int *)((longlong)param_1 + 100) != 0)) &&
               (cVar1 = FUN_1401032b0(param_1,4), cVar1 != '\0')) {
              *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
            }
          }
          else {
            plVar5 = (longlong *)0x0;
          }
          return plVar5;
        }
        log_InlineLogERROR(&DAT_1406d9c10);
        return (longlong *)0x0;
      }
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return (longlong *)0x0;
}

// ==== CMsgItem::helper_140168d50  @140168d50  [medium:callgraph-r1]  (orig: FUN_140168d50)
undefined8 FUN_140168d50(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x12e8) != 0) {
    uVar1 = FUN_1403b7ae0(*(longlong *)(param_1 + 0x12e8),2);
    return uVar1;
  }
  return 0;
}

// ==== CMsgItem::helper_140168d70  @140168d70  [medium:callgraph-r1]  (orig: FUN_140168d70)
undefined1 FUN_140168d70(longlong param_1,undefined4 param_2)

{
  undefined1 uVar1;
  
  if (*(longlong *)(param_1 + 0x12e8) != 0) {
    uVar1 = FUN_1403b7b40(*(longlong *)(param_1 + 0x12e8),2,param_2);
    return uVar1;
  }
  return 0;
}

// ==== CMsgItem::helper_14016c9e0  @14016c9e0  [medium:callgraph-r1]  (orig: FUN_14016c9e0)
undefined4 FUN_14016c9e0(undefined8 param_1)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar1 = FUN_1400fda10(param_1,0x6e,1);
  if ((uVar1 & 4) != 0) {
    return 1;
  }
  uVar2 = FUN_1400fda10(param_1,1,1);
  iVar3 = FUN_1400ff680(uVar2);
  if (iVar3 == 9) {
    uVar2 = FUN_1400fda10(param_1,1,1);
    iVar3 = FUN_1400fecd0(uVar2);
    if (iVar3 == 90000) {
      return 1;
    }
  }
  return 0;
}

// ==== CMsgItem::helper_14020ebe0  @14020ebe0  [medium:callgraph-r1]  (orig: FUN_14020ebe0)
undefined1 FUN_14020ebe0(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined1 uVar1;
  longlong lVar2;
  undefined4 local_res10 [2];
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  local_res10[0] = param_2;
  lVar2 = FUN_14020ea80();
  uVar1 = (undefined1)lVar2;
  if (lVar2 != 0) {
    FUN_1404140b0(lVar2);
    FUN_140415f80(lVar2);
    FUN_140413d80(lVar2);
    FUN_14020e4e0(param_1 + 0x10,local_res10,param_3,param_4,uVar3);
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CMsgItem::helper_1402bcb40  @1402bcb40  [medium:callgraph-r2]  (orig: FUN_1402bcb40)
undefined8 FUN_1402bcb40(longlong param_1)

{
  int iVar1;
  
  if (*(longlong *)(param_1 + 0x60) != 0) {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),2);
    if (iVar1 != 2) {
      return 0;
    }
    if (*(longlong *)(param_1 + 0x60) != 0) {
      iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))
                        (*(longlong **)(param_1 + 0x60),1);
      if (iVar1 == 0) {
        return 0;
      }
      return 1;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMsgItem::helper_14032b280  @14032b280  [medium:callgraph-r1]  (orig: FUN_14032b280)
longlong FUN_14032b280(void)

{
  longlong lVar1;
  
  lVar1 = DAT_140975be8;
  if (DAT_140975be8 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMsgItem::helper_14032b5c0  @14032b5c0  [medium:callgraph-r1]  (orig: FUN_14032b5c0)
void FUN_14032b5c0(longlong *param_1,undefined2 param_2)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)CurrentInstanceGet();
  if ((plVar3 != (longlong *)0x0) &&
     (plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,0x10), plVar3 != (longlong *)0x0)) {
    lVar1 = *plVar3;
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar1 + 0x20))(plVar3,uVar2,param_2);
  }
  return;
}

// ==== CMsgItem::helper_14032b630  @14032b630  [medium:callgraph-r1]  (orig: FUN_14032b630)
ulonglong FUN_14032b630(longlong param_1,longlong param_2)

{
  ushort uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  undefined4 uVar10;
  ulonglong in_RAX;
  ulonglong uVar11;
  uint uVar12;
  
  if (param_2 == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  uVar12 = *(byte *)(param_1 + 0xeee) / 10;
  uVar3 = FUN_1400fda10(param_2,0x67,1);
  uVar4 = FUN_1400fda10(param_2,0x68,1);
  uVar5 = FUN_1400fda10(param_2,0x6a,1);
  uVar6 = FUN_1400fda10(param_2,0x6b,1);
  uVar7 = FUN_1400fda10(param_2,0x6c,1);
  uVar8 = FUN_1400fda10(param_2,0x6d,1);
  iVar9 = FUN_1400fda10(param_2,0x66,1);
  if (iVar9 != 0) {
    iVar9 = FUN_1400fda10(param_2,0x66,1);
    uVar2 = (iVar9 % 1000) / 10;
    uVar11 = FUN_1400fda10(param_2,0x68,1);
    if (uVar2 == 0x13) {
      if (uVar12 < 10) {
joined_r0x00014032b7ab:
        if (0x46 < (int)uVar11) goto LAB_14032b77d;
      }
    }
    else if (uVar2 != uVar12) goto joined_r0x00014032b7ab;
  }
  uVar10 = FUN_1400fda10(param_2,1,1);
  uVar11 = FUN_140162250(param_1,uVar10);
  if ((((uVar3 <= (uint)uVar11) &&
       (uVar11 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10),
       uVar4 <= (uint)uVar11)) &&
      (uVar11 = (ulonglong)*(ushort *)(param_1 + 0xed8), uVar5 <= *(ushort *)(param_1 + 0xed8))) &&
     ((uVar11 = (ulonglong)*(ushort *)(param_1 + 0xedc), uVar6 <= *(ushort *)(param_1 + 0xedc) &&
      (uVar11 = (ulonglong)*(ushort *)(param_1 + 0xede), uVar7 <= *(ushort *)(param_1 + 0xede))))) {
    uVar1 = *(ushort *)(param_1 + 0xee0);
    uVar11 = (ulonglong)uVar1;
    if (uVar8 <= uVar1) {
      return CONCAT71((uint7)(byte)(uVar1 >> 8),1);
    }
  }
LAB_14032b77d:
  return uVar11 & 0xffffffffffffff00;
}

// ==== CMsgItem::helper_14032b840  @14032b840  [medium:callgraph-r0]  (orig: FUN_14032b840)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14032b840(longlong *param_1,char param_2)

{
  longlong *plVar1;
  char cVar2;
  undefined1 uVar3;
  uint uVar4;
  undefined4 uVar5;
  longlong lVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  uVar4 = FUN_1401649c0();
  if (uVar4 < 2) {
    uVar3 = 0;
  }
  else {
    iVar10 = 0;
    iVar9 = 1;
    iVar8 = 1;
    do {
      plVar1 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_478 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar7 = iVar8;
      if ((0x14 < iVar8) && (iVar8 < 0x1e)) {
        iVar7 = iVar8 % 10;
      }
      if (iVar7 - 1U < 0x13) {
        uVar5 = *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0xd94);
      }
      else {
        local_478 = 0x285;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar5 = 0;
      }
      lVar6 = (**(code **)(*plVar1 + 0x60))(plVar1,uVar5);
      if (lVar6 != 0) {
        cVar2 = FUN_140106d70(lVar6);
        if (cVar2 != '\0') {
          iVar7 = FUN_1400fda10(lVar6,4,1);
          if (0 < iVar7) {
            cVar2 = FUN_14032b630(param_1,lVar6);
            if (cVar2 != '\0') {
              iVar7 = FUN_1400fe9d0(lVar6);
              iVar10 = iVar10 + iVar7;
            }
          }
        }
      }
      iVar8 = iVar8 + 1;
    } while (iVar8 < 0x14);
    cVar2 = (**(code **)(*param_1 + 0x178))(param_1,iVar10,1);
    uVar3 = 0;
    if (cVar2 != '\0') {
      do {
        plVar1 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_478 = 0x3c0;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        iVar8 = iVar9;
        if ((0x14 < iVar9) && (iVar9 < 0x1e)) {
          iVar8 = iVar9 % 10;
        }
        if (iVar8 - 1U < 0x13) {
          uVar5 = *(undefined4 *)((longlong)param_1 + (longlong)iVar8 * 4 + 0xd94);
        }
        else {
          local_478 = 0x285;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar5 = 0;
        }
        lVar6 = (**(code **)(*plVar1 + 0x60))(plVar1,uVar5);
        if (lVar6 != 0) {
          cVar2 = FUN_140106d70(lVar6);
          if (cVar2 != '\0') {
            iVar8 = FUN_1400fda10(lVar6,4,1);
            if (0 < iVar8) {
              cVar2 = FUN_14032b630(param_1,lVar6);
              if (cVar2 != '\0') {
                uVar5 = FUN_1400fda10(lVar6,5,1);
                FUN_140104140(lVar6,4,uVar5);
              }
            }
          }
        }
        iVar9 = iVar9 + 1;
      } while (iVar9 < 0x14);
      if (param_2 != '\0') {
        FUN_1400f83e0(local_458);
        local_478 = 0;
        iVar8 = FUN_1400f8490(local_458,0,0xf,0xff);
        if (iVar8 != 0) {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_458);
        }
        FUN_1400f8430(local_458);
      }
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CMsgItem::helper_14032bd40  @14032bd40  [medium:callgraph-r1]  (orig: FUN_14032bd40)
int FUN_14032bd40(longlong param_1,int param_2,char param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  longlong lVar6;
  IStringManager *pIVar7;
  longlong *plVar8;
  undefined8 uVar9;
  char *pcVar10;
  
  if (param_2 == 0) {
    return 0;
  }
  plVar8 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar8 = (longlong *)0x0;
  }
  lVar6 = (**(code **)(*plVar8 + 0x60))(plVar8,param_2);
  if (lVar6 != 0) {
    uVar2 = FUN_1400fda10(lVar6,1,1);
    cVar1 = FUN_1400ff940(uVar2);
    if (cVar1 != '\0') {
      iVar3 = FUN_1400fda10(lVar6,5,1);
      iVar4 = FUN_1400fda10(lVar6,4,1);
      if (iVar4 / 100 < iVar3 / 100) {
        if (param_3 == '\0') {
          return 0;
        }
        pIVar7 = theInstance();
        pcVar10 = "STR_REPAIR_THEN_IMPROVE";
      }
      else {
        iVar3 = FUN_1401011d0(lVar6);
        if (iVar3 - 3U < 6) {
          uVar5 = FUN_1400fda10(lVar6,1,1);
          if (iVar3 < 5) {
            uVar5 = (uVar5 / 10) * 10 + 5;
          }
          plVar8 = (longlong *)FUN_140087d40();
          lVar6 = (**(code **)(*plVar8 + 0x70))(plVar8,uVar5 + 1);
          if (lVar6 != 0) {
            return uVar5 + 1;
          }
          if (param_3 == '\0') {
            return 0;
          }
          pIVar7 = theInstance();
          pcVar10 = "STR_CONNOT_IMPROVE";
        }
        else {
          if (param_3 == '\0') {
            return 0;
          }
          pIVar7 = theInstance();
          pcVar10 = "STR_SUPERIOR_ALREADY";
        }
      }
      lVar6 = *(longlong *)(param_1 + 0x10);
      uVar9 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,pcVar10);
      (**(code **)(lVar6 + 0x358))(param_1 + 0x10,uVar9);
    }
  }
  return 0;
}

// ==== CMsgItem::helper_14032ccc0  @14032ccc0  [medium:callgraph-r1]  (orig: FUN_14032ccc0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14032ccc0(longlong *param_1,undefined4 *param_2)

{
  ulonglong uVar1;
  
  if (param_2 == (undefined4 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","idTypes",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                      );
  }
  else {
    tq::TimeStampGet();
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    tq::MyLogSave("gmlog/ComposeBlackGem",
                  "user id:%u,org gem type:%u, org gem count:%u,org gem type:%u, org gem count:%u,org gem type:%u, org gem count:%u,org gem type:%u, org gem count:%u,org gem type:%u, org gem count:%u,org gem type:%u, org gem count:%u,org gem type:%u, org gem count:%u,new gem type:%u, new gem count:%u,ComposeTime: %u"
                  ,uVar1 & 0xffffffff,*param_2);
  }
  return;
}

// ==== CMsgItem::helper_14032daf0  @14032daf0  [medium:callgraph-r0]  (orig: FUN_14032daf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_14032daf0(longlong param_1,longlong *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_2 == (longlong *)0x0) {
    local_478 = 0x3854;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    (**(code **)(*param_2 + 8))(param_2);
    plVar5 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_478 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = *plVar5;
    uVar1 = FUN_1400fda10(param_2,1,1);
    lVar4 = (**(code **)(lVar4 + 0x70))(plVar5,uVar1);
    uVar1 = 0;
    if (lVar4 != 0) {
      iVar2 = FUN_1400fda10(param_2,0x19,1);
      if (iVar2 == 0) {
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar4 + 8) + 0x10))(*(longlong **)(lVar4 + 8),0x27);
        iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
        if (iVar2 == 0) {
          return 0;
        }
      }
      lVar4 = FUN_1400fdb80(param_2,0x18,1);
      if (lVar4 == 0) {
        uVar6 = FUN_1400fe520(param_2);
        FUN_140106830(param_2,0x18,uVar6,1);
        plVar5 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_478 = 0x3c0;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar4 = *plVar5;
        uVar1 = (**(code **)(*param_2 + 8))(param_2);
        (**(code **)(lVar4 + 0x158))(plVar5,uVar1);
        FUN_1400fe700(param_2,param_1,1);
        FUN_1400f83e0(local_458);
        uVar1 = FUN_1400fe380(param_2);
        uVar3 = (**(code **)(*param_2 + 8))(param_2);
        local_478 = 0;
        iVar2 = FUN_1400f8490(local_458,uVar3,0x29,uVar1);
        if (iVar2 != 0) {
          (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))
                    ((longlong *)(param_1 + 0x10),local_458);
        }
        FUN_1400f8430(local_458);
        uVar1 = 1;
      }
      else {
        uVar1 = 0;
      }
    }
  }
  return uVar1;
}

// ==== CMsgItem::helper_14032ec70  @14032ec70  [medium:callgraph-r1]  (orig: FUN_14032ec70)
uint FUN_14032ec70(undefined8 param_1)

{
  undefined4 uVar1;
  uint uVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  uVar2 = FUN_1400ff680(uVar1);
  if (uVar2 == 0) {
    uVar1 = FUN_1400fda10(param_1,1,1);
    uVar2 = FUN_1400fecd0(uVar1);
    if (uVar2 == 60000) {
      return 0xea01;
    }
  }
  return uVar2 & 0xffffff00;
}

// ==== CMsgItem::helper_140330470  @140330470  [medium:callgraph-r1]  (orig: FUN_140330470)
undefined8 FUN_140330470(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong lVar8;
  uint uVar9;
  
  plVar7 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar7 = (longlong *)0x0;
  }
  lVar6 = (**(code **)(*plVar7 + 0x60))(plVar7,param_2);
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  iVar2 = FUN_1400fda10(lVar6,2,1);
  iVar3 = (**(code **)(*param_1 + 8))(param_1);
  if (iVar2 != iVar3) {
    return 0;
  }
  uVar4 = FUN_1400fda10(lVar6,1,1);
  if (uVar4 == 0x1d5ff) {
    return 0;
  }
  uVar9 = uVar4 / 10;
  if (uVar4 % 10 == 0) {
    return 0;
  }
  uVar5 = FUN_1400fda10(lVar6,1,1);
  iVar2 = FUN_1400ff680(uVar5);
  if (iVar2 != 6) {
    uVar5 = FUN_1400fda10(lVar6,1,1);
    iVar2 = FUN_1400ff680(uVar5);
    if (iVar2 != 1) {
      uVar5 = FUN_1400fda10(lVar6,1,1);
      iVar2 = FUN_1400ff680(uVar5);
      if (iVar2 != 3) {
        uVar5 = FUN_1400fda10(lVar6,1,1);
        iVar2 = FUN_1400ff680(uVar5);
        if (iVar2 != 7) {
          uVar5 = FUN_1400fda10(lVar6,1,1);
          iVar2 = FUN_1400ff680(uVar5);
          if (iVar2 != 8) {
            uVar5 = FUN_1400fda10(lVar6,1,1);
            iVar2 = FUN_1400ff680(uVar5);
            if ((iVar2 != 2) && (cVar1 = FUN_1400f8840(lVar6), cVar1 == '\0')) {
              return 0;
            }
            iVar2 = uVar4 + (2 - uVar9 % 100) * 10;
            goto LAB_14033067f;
          }
        }
        iVar2 = uVar4 + (1 - uVar9 % 100) * 10;
        goto LAB_14033067f;
      }
    }
  }
  iVar2 = uVar4 + (uVar9 % 100) * -10;
LAB_14033067f:
  plVar7 = (longlong *)FUN_140087d40();
  lVar8 = (**(code **)(*plVar7 + 0x70))(plVar7,iVar2);
  if (lVar8 != 0) {
    cVar1 = FUN_140106b20(lVar6,iVar2);
    if (cVar1 != '\0') {
      FUN_140104080(lVar6,1);
      FUN_14032d7e0(param_1,lVar6);
      return 1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMsgItem::helper_140332c00  @140332c00  [medium:callgraph-r2]  (orig: FUN_140332c00)
void FUN_140332c00(void *param_1,longlong param_2,void *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (void *)0x0) {
      memcpy(param_1,param_3,0x28);
    }
    param_1 = (void *)((longlong)param_1 + 0x28);
  }
  return;
}

// ==== CMsgItem::helper_140333330  @140333330  [medium:callgraph-r0]  (orig: FUN_140333330)
undefined8 FUN_140333330(longlong *param_1,int param_2,char param_3)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  longlong *plVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lVar7;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar7 = 0;
    plVar4 = param_1 + 0x1b3;
    do {
      if ((int)*plVar4 == param_2) goto LAB_1403333ae;
      lVar7 = lVar7 + 1;
      plVar4 = (longlong *)((longlong)plVar4 + 4);
    } while (lVar7 < 0x13);
    cVar1 = FUN_140332fe0(param_1);
    if (cVar1 != '\0') {
LAB_1403333ae:
      plVar4 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar4 = (longlong *)0x0;
      }
      lVar7 = (**(code **)(*plVar4 + 0x60))(plVar4,param_2);
      if (lVar7 != 0) {
        uVar5 = FUN_1400fda10(lVar7,6,1);
        if ((uVar5 & 1) != 0) {
          iVar2 = FUN_1400fda10(lVar7,0x70,1);
          iVar2 = MulDiv(iVar2,10,100);
          if (iVar2 != 0) {
            lVar6 = (**(code **)(*param_1 + 0x60))(param_1);
            if (lVar6 < iVar2) {
              return 0;
            }
            (**(code **)(*param_1 + 0x178))(param_1,(longlong)iVar2,1);
          }
          uVar3 = FUN_1400fda10(lVar7,6,1);
          FUN_140104140(lVar7,6,uVar3 & 0xfffffffe);
          if (param_3 != '\0') {
            plVar4 = (longlong *)FUN_140087d40();
            (**(code **)(*plVar4 + 0x130))(plVar4,param_1,lVar7,1,0,0);
          }
          return 1;
        }
      }
    }
  }
  return 0;
}

// ==== CMsgItem::helper_1403337e0  @1403337e0  [medium:callgraph-r0]  (orig: FUN_1403337e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1403337e0(longlong *param_1,undefined4 param_2,char param_3)

{
  char cVar1;
  char cVar2;
  undefined1 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  longlong lVar7;
  IStringManager *pIVar8;
  undefined8 uVar9;
  longlong *plVar10;
  undefined1 auStack_4c8 [32];
  ulonglong local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined8 local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if ((param_3 == '\x01') || (param_3 == '\x02')) {
    plVar10 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_4a8 = CONCAT44(local_4a8._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar10 = (longlong *)0x0;
    }
    lVar7 = (**(code **)(*plVar10 + 0x60))(plVar10,param_2);
    if (lVar7 == 0) {
      local_4a8 = CONCAT44(local_4a8._4_4_,0x1947);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = 0;
    }
    else {
      cVar1 = FUN_140333220(param_1,param_2);
      if ((cVar1 == '\0') && (cVar2 = FUN_140332fe0(param_1,param_2), cVar2 == '\0')) {
        return 0;
      }
      if (param_3 != '\x01') {
        if (param_3 != '\x02') {
          return 0;
        }
        cVar2 = FUN_1400ffbe0(lVar7);
        if (cVar2 == '\0') {
          return 0;
        }
      }
      iVar4 = FUN_1400fee00(lVar7);
      if (iVar4 < 1) {
        uVar3 = 0;
      }
      else {
        iVar4 = FUN_1400fda10(lVar7,5,1);
        iVar5 = FUN_1400fda10(lVar7,4,1);
        if (iVar4 / 100 == iVar5 / 100) {
          if (param_3 == '\x01') {
            if (*(int *)((longlong)param_1 + 0xfa4) < 0x36) {
              pIVar8 = theInstance();
              lVar7 = param_1[2];
              uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_NOT_SO_MUCH_EMONEY");
              (**(code **)(lVar7 + 0x358))(param_1 + 2,uVar9);
              return 0;
            }
          }
          else {
            if (param_3 != '\x02') {
              log_InlineLogERROR("Invalid moneytype:%d at %s, %d");
              return 0;
            }
            iVar4 = FUN_140371860(param_1 + 0x1cf);
            if (iVar4 < 0x36) {
              pIVar8 = theInstance();
              lVar7 = param_1[2];
              uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_NOT_SO_MUCH_EMONEY");
              (**(code **)(lVar7 + 0x358))(param_1 + 2,uVar9);
              return 0;
            }
          }
          cVar2 = FUN_140330470(param_1,param_2);
          uVar3 = 0;
          if (cVar2 != '\0') {
            plVar10 = (longlong *)FUN_140087d40();
            local_4a0 = 0;
            local_4a8 = local_4a8 & 0xffffffff00000000;
            (**(code **)(*plVar10 + 0x130))(plVar10,param_1,lVar7,3);
            if (cVar1 != '\0') {
              FUN_14036fe70(local_478);
              iVar4 = FUN_1403702e0(local_478,param_1);
              if (iVar4 != 0) {
                (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
              }
              FUN_14036fec0(local_478);
            }
            if (param_3 == '\x01') {
              local_4a8 = 0;
              cVar1 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,0xffffffffffffffca,1);
              if (cVar1 == '\0') {
                local_4a8 = CONCAT44(local_4a8._4_4_,0x199d);
                log_InlineLogERROR(&DAT_1406d9c10);
                return 0;
              }
              uVar6 = (**(code **)(*param_1 + 8))(param_1);
              local_4a8._0_4_ = 0x36;
              FUN_1401742b0(param_1,0x22,uVar6);
              lVar7 = param_1[0x1e2];
              (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              (**(code **)(*param_1 + 8))(param_1);
              local_490 = 0;
              local_498 = 0x90;
              local_4a0 = 0x90;
              local_4a8 = CONCAT44(local_4a8._4_4_,(int)lVar7);
              tq::MyLogSave("gmlog/emoneybuy","%u\t%s\t%u\t%d\t%d\t%d\t");
            }
            else {
              if (param_3 != '\x02') {
                log_InlineLogERROR("Invalid moneytype:%d at %s, %d");
                return 0;
              }
              local_4a8 = 0;
              cVar1 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x2d,0xffffffffffffffca,1);
              if (cVar1 == '\0') {
                local_4a8 = CONCAT44(local_4a8._4_4_,0x19a9);
                log_InlineLogERROR(&DAT_1406d9c10);
                return 0;
              }
              uVar6 = (**(code **)(*param_1 + 8))(param_1);
              local_4a8._0_4_ = 0x36;
              FUN_140174470(param_1,0x22,uVar6);
              lVar7 = param_1[0x1e2];
              (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              (**(code **)(*param_1 + 8))(param_1);
              local_490 = 0;
              local_498 = 0x90;
              local_4a0 = 0x90;
              local_4a8 = CONCAT44(local_4a8._4_4_,(int)lVar7);
              tq::MyLogSave("gmlog/emoneybuy","%u\t%s\t%u\t%d\t%d\t%d\t");
            }
            uVar3 = 1;
          }
        }
        else {
          uVar3 = 0;
        }
      }
    }
  }
  else {
    uVar3 = 0;
  }
  return uVar3;
}

// ==== CMsgItem::helper_1403349f0  @1403349f0  [medium:callgraph-r0]  (orig: FUN_1403349f0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_1403349f0(longlong *param_1,int param_2)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  longlong *plVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  longlong *plVar9;
  
  if ((*(char *)((longlong)param_1 + 0x51c) == '\0') || (param_2 == 0)) {
    return 0;
  }
  cVar2 = FUN_140332fe0();
  if (cVar2 == '\0') {
LAB_140334a52:
    plVar6 = (longlong *)FUN_140087d40();
    lVar1 = *plVar6;
    uVar3 = FUN_14032b4b0(param_1,10);
    plVar6 = (longlong *)(**(code **)(lVar1 + 0x60))(plVar6,uVar3);
    if ((plVar6 == (longlong *)0x0) ||
       (iVar4 = (**(code **)(*plVar6 + 8))(plVar6), iVar4 != param_2)) {
      plVar6 = (longlong *)FUN_140087d40();
      lVar1 = *plVar6;
      uVar3 = FUN_14032b4b0(param_1,0xb);
      plVar6 = (longlong *)(**(code **)(lVar1 + 0x60))(plVar6,uVar3);
      if ((plVar6 == (longlong *)0x0) ||
         (iVar4 = (**(code **)(*plVar6 + 8))(plVar6), iVar4 != param_2)) {
        plVar6 = (longlong *)FUN_140087d40();
        lVar1 = *plVar6;
        uVar3 = FUN_14032b4b0(param_1,0x13);
        plVar6 = (longlong *)(**(code **)(lVar1 + 0x60))(plVar6,uVar3);
        if (plVar6 == (longlong *)0x0) {
          return 0;
        }
        iVar4 = (**(code **)(*plVar6 + 8))(plVar6);
        if (iVar4 != param_2) {
          return 0;
        }
      }
    }
  }
  else {
    plVar6 = (longlong *)FUN_140087d40();
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x60))(plVar6,param_2);
    if (plVar6 == (longlong *)0x0) goto LAB_140334a52;
  }
  uVar3 = FUN_1400fda10(plVar6,1,1);
  iVar4 = FUN_1400ff680(uVar3);
  if ((iVar4 != 0x15) && (plVar6 != (longlong *)0x0)) {
    uVar3 = FUN_1400fda10(plVar6,1,1);
    iVar4 = FUN_1400ff680(uVar3);
    if (iVar4 != 0xc) {
      uVar3 = FUN_1400fda10(plVar6,1,1);
      iVar4 = FUN_1400ff680(uVar3);
      if (iVar4 != 0xd) {
        uVar3 = FUN_1400fda10(plVar6,1,1);
        iVar4 = FUN_1400ff680(uVar3);
        if (iVar4 != 0x16) {
          return 0;
        }
      }
    }
    iVar4 = FUN_1400fda10(plVar6,9,1);
    if (iVar4 == 0) {
      uVar7 = FUN_140008520((int)param_1[0x246]);
      cVar2 = FUN_14008abf0(uVar7);
      if ((cVar2 == '\0') || (cVar2 = FUN_140103310(plVar6), cVar2 == '\0')) {
        iVar4 = FUN_1400fda10(plVar6,0xd,1);
        iVar5 = FUN_1400fda10(plVar6,8,1);
        if (iVar5 == 0) {
          if (0x95f < iVar4) {
            iVar4 = ((8000 - iVar4) * 7) / 10;
            if (iVar4 < 1) {
              iVar4 = 1;
            }
            cVar2 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,(longlong)-iVar4,1);
            if (cVar2 != '\0') {
              FUN_140104140(plVar6,8,0xff);
              FUN_140104140(plVar6,0xd,0);
              uVar3 = (**(code **)(*param_1 + 8))(param_1);
              FUN_1401742b0(param_1,0xc,uVar3);
              uVar7 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              uVar8 = (**(code **)(*param_1 + 8))(param_1);
              tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t700\t702\t%d\t%d\t1\t",
                            uVar8 & 0xffffffff,uVar7);
              FUN_140170e90(param_1,0x28b9);
            }
LAB_140334dea:
            FUN_140194390(param_1);
            plVar9 = (longlong *)FUN_140087d40();
            (**(code **)(*plVar9 + 0x130))(plVar9,param_1,plVar6,3);
            uVar7 = FUN_140008520((int)param_1[0x246]);
            uVar7 = FUN_140087c40(uVar7);
            FUN_140261810(uVar7,param_1,0xd);
            return 1;
          }
        }
        else if (5999 < iVar4) {
          iVar4 = ((20000 - iVar4) * 7) / 10;
          if (iVar4 < 1) {
            iVar4 = 1;
          }
          cVar2 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,(longlong)-iVar4,1);
          if (cVar2 != '\0') {
            FUN_140104140(plVar6,9,0xff);
            FUN_140104140(plVar6,0xd,0);
            uVar3 = (**(code **)(*param_1 + 8))(param_1);
            FUN_1401742b0(param_1,0xc,uVar3);
            uVar7 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
            uVar8 = (**(code **)(*param_1 + 8))(param_1);
            tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t700\t703\t%d\t%d\t1\t",uVar8 & 0xffffffff,
                          uVar7);
            FUN_140170e90(param_1,0x28ba);
          }
          goto LAB_140334dea;
        }
      }
    }
  }
  return 0;
}

// ==== CMsgItem::helper_140337470  @140337470  [medium:callgraph-r3]  (orig: FUN_140337470)
void FUN_140337470(longlong param_1,longlong param_2,ulonglong param_3,void *param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  void *pvVar5;
  longlong lVar6;
  void *pvVar7;
  undefined1 local_res8;
  undefined1 local_58 [48];
  
  lVar6 = *(longlong *)(param_1 + 0x18);
  if (lVar6 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = (*(longlong *)(param_1 + 0x28) - lVar6) / 0x28;
  }
  if (param_3 != 0) {
    lVar2 = *(longlong *)(param_1 + 0x20);
    lVar6 = (lVar2 - lVar6) / 0x28;
    if (0x666666666666666U - lVar6 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14032e780();
    }
    uVar1 = lVar6 + param_3;
    if (uVar4 < uVar1) {
      if (0x666666666666666 - (uVar4 >> 1) < uVar4) {
        uVar4 = 0;
      }
      else {
        uVar4 = uVar4 + (uVar4 >> 1);
      }
      if (uVar4 < uVar1) {
        uVar4 = uVar1;
      }
      lVar2 = FUN_1403320e0(param_1 + 0x10,uVar4);
      lVar6 = (*(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18)) / 0x28;
      local_res8 = (undefined1)lVar2;
      FUN_140332c00(lVar2 + lVar6 * 0x28,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_140332270(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_140332270(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    lVar2 + (lVar6 + param_3) * 0x28,param_1 + 0x10,local_res8,0,2);
      pvVar5 = *(void **)(param_1 + 0x18);
      lVar6 = *(longlong *)(param_1 + 0x20);
      if (pvVar5 != (void *)0x0) {
        operator_delete(pvVar5);
      }
      *(ulonglong *)(param_1 + 0x28) = lVar2 + uVar4 * 0x28;
      *(ulonglong *)(param_1 + 0x20) = lVar2 + (param_3 + (lVar6 - (longlong)pvVar5) / 0x28) * 0x28;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)((lVar2 - *(longlong *)(param_2 + 8)) / 0x28) < param_3) {
      memcpy(local_58,param_4,0x28);
      FUN_140332270(*(longlong *)(param_2 + 8),lVar2,*(longlong *)(param_2 + 8) + param_3 * 0x28,
                    param_1 + 0x10,local_res8,0);
      FUN_140332c00(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x28,
                    local_58,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x28;
      lVar6 = *(longlong *)(param_1 + 0x20);
      for (pvVar5 = *(void **)(param_2 + 8); pvVar5 != (void *)(lVar6 + param_3 * -0x28);
          pvVar5 = (void *)((longlong)pvVar5 + 0x28)) {
        memcpy(pvVar5,local_58,0x28);
      }
    }
    else {
      memcpy(local_58,param_4,0x28);
      lVar6 = lVar2 + param_3 * -0x28;
      uVar3 = FUN_140332270(lVar6,lVar2,lVar2,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_1403322e0(*(undefined8 *)(param_2 + 8),lVar6,lVar2,local_res8,local_res8,0);
      pvVar5 = *(void **)(param_2 + 8);
      pvVar7 = (void *)(param_3 * 0x28 + (longlong)pvVar5);
      for (; pvVar5 != pvVar7; pvVar5 = (void *)((longlong)pvVar5 + 0x28)) {
        memcpy(pvVar5,local_58,0x28);
      }
    }
  }
  return;
}

// ==== CMsgItem::helper_14033a0a0  @14033a0a0  [medium:callgraph-r0]  (orig: FUN_14033a0a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14033a0a0(longlong param_1,int param_2)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  IStringManager *pIVar4;
  undefined8 uVar5;
  longlong *plVar6;
  undefined1 auStack_8b8 [32];
  undefined4 local_898;
  undefined8 local_888;
  undefined1 local_878 [1072];
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  if (param_2 != 0) {
    local_888 = 0xfffffffffffffffe;
    local_18 = DAT_1409707c0 ^ (ulonglong)auStack_8b8;
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_898 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    lVar3 = (**(code **)(*plVar6 + 0x60))(plVar6,param_2);
    if (lVar3 == 0) {
      pIVar4 = theInstance();
      lVar3 = *(longlong *)(param_1 + 0x10);
      uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_NOT_FIND_ITEMINFO");
      (**(code **)(lVar3 + 0x358))(param_1 + 0x10,uVar5);
    }
    else {
      FUN_140458720(local_448);
      local_898 = 0;
      iVar2 = FUN_1404587d0(local_448,lVar3,9);
      if (iVar2 != 0) {
        (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_448)
        ;
      }
      FUN_14019a030(param_1,param_2,0,0);
      cVar1 = FUN_1400ff650(lVar3,2);
      if ((cVar1 != '\0') || (cVar1 = FUN_1400ff650(lVar3,1), cVar1 != '\0')) {
        FUN_1403f2320(local_878);
        local_898 = FUN_140337d00(param_1,param_2);
        cVar1 = FUN_1403f23d0(local_878,2,param_2,3);
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))
                    ((longlong *)(param_1 + 0x10),local_878);
        }
        FUN_1403f2370(local_878);
      }
      FUN_140458770(local_448);
    }
  }
  return;
}

// ==== CMsgItem::helper_14033a540  @14033a540  [medium:callgraph-r2]  (orig: FUN_14033a540)
longlong * FUN_14033a540(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[3];
  lVar4 = param_1[4] - uVar1;
  lVar2 = 0;
  lVar5 = lVar4 >> 0x3f;
  lVar3 = lVar2;
  if (lVar4 / 0x28 + lVar5 != lVar5) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) / 0x28;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140337470(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar2;
  }
  else {
    lVar5 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 0x28;
  if (uVar1 <= *(ulonglong *)(lVar5 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14033a664;
  }
  _invalid_parameter_noinfo();
LAB_14033a664:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMsgItem::helper_14033acb0  @14033acb0  [medium:callgraph-r0]  (orig: FUN_14033acb0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14033acb0(longlong *param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  char cVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  undefined8 uVar8;
  IStringManager *pIVar9;
  ulonglong uVar10;
  longlong lVar11;
  longlong *plVar12;
  undefined8 uVar13;
  longlong *local_60;
  
  plVar1 = param_1 + 2;
  uVar4 = (**(code **)(*plVar1 + 0x48))(plVar1);
  uVar5 = (**(code **)(*plVar1 + 0x40))(plVar1);
  uVar8 = (**(code **)(*plVar1 + 0x160))(plVar1);
  cVar2 = FUN_1402c84c0(uVar8,uVar5,uVar4,0x1040);
  if ((cVar2 != '\0') &&
     ((cVar2 = (**(code **)(*local_60 + 0x50))(), cVar2 != '\0' ||
      (iVar6 = (**(code **)(*(longlong *)local_60[0xc] + 0x10))((longlong *)local_60[0xc],4),
      iVar6 == 0x20)))) {
    cVar2 = FUN_140332fe0(param_1,param_3);
    if (cVar2 != '\0') {
      plVar12 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        plVar12 = (longlong *)0x0;
      }
      plVar12 = (longlong *)(**(code **)(*plVar12 + 0x60))(plVar12,param_3);
      if (plVar12 != (longlong *)0x0) {
        cVar2 = FUN_140105800(plVar12);
        if (cVar2 != '\0') {
          uVar4 = (**(code **)(*plVar12 + 8))(plVar12);
          cVar2 = FUN_1403380a0(param_1,uVar4);
          if (cVar2 == '\0') {
            uVar8 = (**(code **)(*local_60 + 0x58))();
            cVar2 = FUN_14046b340(uVar8);
            if (cVar2 != '\0') {
              return;
            }
            cVar2 = FUN_1401036f0(plVar12);
            if ((cVar2 != '\0') && (cVar2 = FUN_140100c60(plVar12), cVar2 == '\0')) {
              pIVar9 = theInstance();
              lVar11 = *plVar1;
              uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_CHEST_NOT_EMPYT");
              (**(code **)(lVar11 + 0x358))(plVar1,uVar8);
              return;
            }
            cVar2 = FUN_140104440(plVar12);
            if (cVar2 != '\0') {
              FUN_1400fda10(plVar12,0xc,1);
              FUN_1400fda10(plVar12,0xf,1);
              FUN_1400fda10(plVar12,0xe,1);
              FUN_1400fda10(plVar12,9,1);
              FUN_1400fda10(plVar12,8,1);
              FUN_1400feba0(plVar12);
              FUN_1400fda10(plVar12,5,1);
              FUN_1400fda10(plVar12,4,1);
              FUN_1400fda10(plVar12,1,1);
              (**(code **)(*plVar12 + 8))(plVar12);
              uVar10 = (**(code **)(*param_1 + 8))();
              uVar8 = (**(code **)(*plVar1 + 0x18))();
              tq::MyLogSave("gmlog/sell_item",
                            "%s(%u) sell item:[id=%u, type=%u], dur=%d, max_dur=%d, price=%d, addition_level=%d, gem1=%d, gme2=%d, redue_dmg=%d, add_life=%d"
                            ,uVar8,uVar10 & 0xffffffff);
            }
            iVar6 = FUN_1400feba0(plVar12);
            iVar7 = FUN_1400ffdf0(plVar12);
            if (1 < iVar7) {
              iVar7 = FUN_1400ffda0(plVar12);
              iVar6 = iVar6 * iVar7;
            }
            uVar4 = FUN_1400fda10(plVar12,1,1);
            cVar2 = FUN_1400ff940(uVar4);
            if ((cVar2 != '\0') && (iVar7 = FUN_1400fda10(plVar12,4,1), iVar7 == 0)) {
              iVar6 = 0;
            }
            uVar8 = 0;
            lVar11 = FUN_140008520((int)param_1[0x246]);
            if (*(longlong *)(lVar11 + 0x128) == 0) {
              log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pSuperFlagMgr",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                );
              uVar13 = uVar8;
            }
            else {
              uVar13 = *(undefined8 *)(lVar11 + 0x128);
            }
            cVar2 = FUN_14020c700(uVar13,plVar12);
            if (cVar2 != '\0') {
              lVar11 = FUN_140008520((int)param_1[0x246]);
              if (*(longlong *)(lVar11 + 0x128) == 0) {
                log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pSuperFlagMgr",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                  );
              }
              else {
                uVar8 = *(undefined8 *)(lVar11 + 0x128);
              }
              FUN_14020ebe0(uVar8,param_3);
            }
            cVar2 = FUN_1400ffbe0(plVar12);
            cVar3 = FUN_14033a6a0(param_1,param_3,1,0);
            if (cVar3 == '\0') {
              pIVar9 = theInstance();
              lVar11 = *plVar1;
              uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_ITEM_INEXIST");
              (**(code **)(lVar11 + 0x358))(plVar1,uVar8);
              return;
            }
            if ((cVar2 == '\0') &&
               (cVar2 = (**(code **)(*param_1 + 0x180))(param_1,iVar6,1), cVar2 == '\0')) {
              pIVar9 = theInstance();
              lVar11 = *plVar1;
              uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_MONEYBAG_FULL");
              (**(code **)(lVar11 + 0x358))(plVar1,uVar8);
            }
            FUN_1401642f0(param_1);
            return;
          }
        }
        pIVar9 = theInstance();
        lVar11 = *plVar1;
        uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_NOT_SALEABLE");
        (**(code **)(lVar11 + 0x358))(plVar1,uVar8);
        return;
      }
    }
    pIVar9 = theInstance();
    lVar11 = *plVar1;
    uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_ITEM_NOT_FOUND");
    (**(code **)(lVar11 + 0x358))(plVar1,uVar8);
  }
  return;
}

// ==== CMsgItem::helper_14033bde0  @14033bde0  [medium:callgraph-r0]  (orig: FUN_14033bde0)
undefined1 FUN_14033bde0(undefined8 param_1,int param_2,int param_3)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  uint in_stack_ffffffffffffffb8;
  
  if (param_2 == param_3) {
    return 0;
  }
  plVar10 = (longlong *)0x0;
  cVar1 = FUN_140332fe0();
  if ((cVar1 != '\0') && (cVar1 = FUN_140332fe0(param_1,param_3), cVar1 != '\0')) {
    plVar9 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      in_stack_ffffffffffffffb8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar9 = plVar10;
    }
    plVar7 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,param_2);
    plVar9 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      in_stack_ffffffffffffffb8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar9 = plVar10;
    }
    lVar8 = (**(code **)(*plVar9 + 0x60))(plVar9,param_3);
    if ((plVar7 != (longlong *)0x0) && (lVar8 != 0)) {
      uVar3 = FUN_1400fda10(lVar8,1,1);
      uVar2 = FUN_1400fda10(lVar8,0x16,1);
      cVar1 = FUN_140102910(plVar7,uVar3,uVar2);
      if (cVar1 != '\0') {
        uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
        cVar1 = FUN_14032d730(param_1,uVar3);
        if (cVar1 == '\0') {
          uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
          cVar1 = FUN_1403380a0(param_1,uVar3);
          if (cVar1 == '\0') {
            iVar4 = FUN_1400ffdf0(plVar7);
            iVar5 = FUN_1400ffda0(lVar8);
            iVar6 = FUN_1400ffda0(plVar7);
            iVar5 = iVar5 + iVar6;
            if (iVar4 < iVar5) {
              FUN_140105d40(plVar7,iVar4,0);
              FUN_140105d40(lVar8,iVar5 - iVar4,0);
              plVar9 = DAT_140975b60;
              if (DAT_140975b60 == (longlong *)0x0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                plVar9 = plVar10;
              }
              (**(code **)(*plVar9 + 0x130))(plVar9,param_1,lVar8,3,0,0);
            }
            else {
              cVar1 = FUN_14033a6a0(param_1,param_3,1,0,in_stack_ffffffffffffffb8 & 0xffffff00);
              if (cVar1 == '\0') {
                return 0;
              }
              FUN_140105d40(plVar7,iVar5,0);
            }
            plVar9 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar9 = plVar10;
            }
            (**(code **)(*plVar9 + 0x130))(plVar9,param_1,plVar7,3,0,0);
            return 1;
          }
        }
      }
      uVar3 = FUN_1400fda10(plVar7,1,1);
      cVar1 = FUN_140102710(uVar3);
      if (cVar1 != '\0') {
        uVar3 = FUN_1400fda10(plVar7,1,1);
        iVar4 = FUN_1400ff680(uVar3);
        if (iVar4 == 0) {
          uVar3 = FUN_1400fda10(plVar7,1,1);
          iVar4 = FUN_1400fecd0(uVar3);
          if (iVar4 == 50000) goto LAB_14033c0fb;
        }
        log_InlineLogERROR(&DAT_1406d9c10);
      }
LAB_14033c0fb:
      uVar3 = FUN_1400fda10(plVar7,1,1);
      iVar4 = FUN_1400ff680(uVar3);
      if (iVar4 == 9) {
        uVar3 = FUN_1400fda10(plVar7,1,1);
        iVar4 = FUN_1400fecd0(uVar3);
        if (iVar4 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMsgItem::helper_14033c3e0  @14033c3e0  [medium:callgraph-r1]  (orig: FUN_14033c3e0)
void FUN_14033c3e0(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) / 0x28;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0x28) < uVar3) {
    FUN_140332c00(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x28;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_14033a540(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMsgItem::helper_14033cfa0  @14033cfa0  [medium:callgraph-r0]  (orig: FUN_14033cfa0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */

undefined1
FUN_14033cfa0(longlong *param_1,uint param_2,undefined4 param_3,undefined4 param_4,char param_5)

{
  char cVar1;
  byte bVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  __time32_t _Var6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  int iVar12;
  longlong *plVar13;
  longlong lVar14;
  longlong lVar15;
  undefined8 uVar16;
  longlong *plVar17;
  ulonglong uVar18;
  longlong *plVar19;
  IStringManager *pIVar20;
  longlong *plVar21;
  longlong *plVar22;
  longlong *plVar23;
  undefined1 auStack_668 [32];
  undefined8 *local_648;
  undefined4 local_640;
  undefined4 local_638;
  undefined4 local_630;
  undefined4 local_628;
  undefined4 local_620;
  undefined4 local_618;
  undefined4 local_610;
  undefined4 local_608;
  undefined4 local_600;
  undefined4 local_5f8;
  undefined4 local_5f0;
  char local_5e8;
  uint local_5e4;
  byte local_5e0;
  undefined8 local_5d8;
  undefined4 local_5d0;
  undefined4 local_5cc;
  undefined4 local_5c8;
  undefined4 local_5c4;
  undefined4 local_5c0;
  undefined4 local_5bc;
  longlong *local_5b8;
  longlong *local_5b0;
  longlong *local_5a8 [3];
  longlong *local_590;
  longlong *local_588;
  undefined8 local_580;
  longlong *local_578;
  uint local_570;
  longlong *local_568 [3];
  void *local_550;
  undefined8 local_548;
  undefined8 local_540;
  undefined1 local_538 [12];
  undefined4 local_52c;
  undefined4 local_528;
  undefined4 local_524;
  undefined4 local_520;
  int local_51c;
  undefined4 local_518;
  longlong *local_510;
  longlong *local_508;
  undefined8 local_500;
  undefined8 local_4f8;
  undefined8 local_4e8 [11];
  int local_490;
  int local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_4f8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_668;
  plVar21 = param_1 + 2;
  local_5e4 = param_2;
  local_5d0 = param_4;
  local_5c0 = param_3;
  local_5b8 = plVar21;
  local_578 = param_1;
  local_570 = param_2;
  local_510 = param_1;
  plVar13 = (longlong *)(**(code **)(*plVar21 + 0x160))(plVar21);
  local_508 = plVar13;
  if (plVar13 == (longlong *)0x0) {
    local_648 = (undefined8 *)CONCAT44(local_648._4_4_,0xeed);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  cVar1 = FUN_140167b70(param_1);
  if (cVar1 != '\0') {
    plVar19 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_648 = (undefined8 *)CONCAT44(local_648._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar19 = (longlong *)0x0;
    }
    lVar14 = (**(code **)(*plVar19 + 0x60))(plVar19,param_2);
    if (lVar14 == 0) {
      local_648 = (undefined8 *)CONCAT44(local_648._4_4_,0xef3);
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    lVar15 = (**(code **)(*plVar21 + 0x160))(plVar21);
    if (lVar15 == 0) {
      return 0;
    }
    uVar16 = (**(code **)(*plVar21 + 0x160))(plVar21);
    cVar1 = FUN_1400f8890(uVar16);
    if (cVar1 == '\0') {
      return 0;
    }
    cVar1 = FUN_140100c40(lVar14);
    if (cVar1 == '\0') {
      return 0;
    }
  }
  plVar19 = (longlong *)0x0;
  uVar16 = FUN_140008520((int)param_1[0x246]);
  cVar1 = FUN_14008a710(uVar16);
  if (cVar1 != '\0') {
    plVar17 = (longlong *)FUN_140087d40();
    lVar14 = (**(code **)(*plVar17 + 0x60))(plVar17,param_2);
    if (lVar14 == 0) {
      return 0;
    }
    cVar1 = FUN_14016c9e0(lVar14);
    if ((cVar1 == '\0') && (uVar3 = FUN_1400fda10(lVar14,0x6e,1), (uVar3 >> 5 & 1) == 0)) {
      return 0;
    }
  }
  cVar1 = FUN_14011dbb0(plVar13);
  if (cVar1 != '\0') {
LAB_14033e438:
    pIVar20 = theInstance();
    lVar14 = *plVar21;
    uVar16 = (*(code *)**(undefined8 **)pIVar20)(pIVar20,"STR_MAP_FORBIDDROPITEM");
    (**(code **)(lVar14 + 0x358))(plVar21,uVar16);
    return 0;
  }
  plVar17 = (longlong *)
            (**(code **)(**(longlong **)(plVar13[0xb] + 8) + 0x10))
                      (*(longlong **)(plVar13[0xb] + 8),4);
  uVar18 = (**(code **)(*plVar17 + 0x58))(plVar17);
  uVar5 = local_5d0;
  if ((uVar18 >> 0x29 & 1) != 0) goto LAB_14033e438;
  cVar1 = FUN_1402c99b0(plVar13,param_3,local_5d0);
  if (cVar1 == '\0') {
    return 0;
  }
  local_500 = 0;
  local_648 = &local_500;
  cVar1 = FUN_1402c8370(plVar13,param_3,uVar5,0x1080);
  if (cVar1 != '\0') {
    return 0;
  }
  local_5e8 = '\0';
  local_5d8 = operator_new(8);
  local_5a8[0] = plVar19;
  if (local_5d8 != (longlong *)0x0) {
    *local_5d8 = (longlong)local_5a8;
    local_5a8[0] = local_5d8;
  }
  local_590 = (longlong *)0x0;
  local_588 = (longlong *)0x0;
  local_580 = 0;
  local_5b0 = local_5d8;
  local_5d8 = operator_new(8);
  local_568[0] = plVar19;
  if (local_5d8 != (longlong *)0x0) {
    *local_5d8 = (longlong)local_568;
    local_568[0] = local_5d8;
  }
  local_550 = (void *)0x0;
  local_548 = 0;
  local_540 = 0;
  local_5c4 = 0;
  local_5b0 = local_5d8;
  cVar1 = FUN_140333220(param_1,param_2);
  if (cVar1 == '\0') {
LAB_14033d9db:
    cVar1 = FUN_140332fe0(param_1,param_2);
    if (cVar1 == '\0') goto LAB_14033e3bc;
    plVar19 = (longlong *)FUN_140087d40();
    plVar19 = (longlong *)(**(code **)(*plVar19 + 0x60))(plVar19,param_2);
    local_5d8 = plVar19;
    if (plVar19 == (longlong *)0x0) goto LAB_14033e3bc;
    cVar1 = FUN_1401036f0(plVar19);
    if ((cVar1 != '\0') && (cVar1 = FUN_140100c60(plVar19), cVar1 == '\0')) {
      pIVar20 = theInstance();
      lVar14 = *plVar21;
      uVar16 = (*(code *)**(undefined8 **)pIVar20)(pIVar20,"STR_CHEST_NOT_EMPYT");
      (**(code **)(lVar14 + 0x358))(plVar21,uVar16);
      if (local_550 != (void *)0x0) {
        operator_delete(local_550);
      }
      local_550 = (void *)0x0;
      local_548 = 0;
      local_540 = 0;
      operator_delete(local_568[0]);
      if (local_590 != (longlong *)0x0) {
        operator_delete(local_590);
      }
      local_590 = (longlong *)0x0;
      local_588 = (longlong *)0x0;
      local_580 = 0;
      operator_delete(local_5a8[0]);
      return 0;
    }
    uVar5 = (**(code **)(*plVar19 + 8))(plVar19);
    bVar2 = FUN_1403380a0(param_1,uVar5);
    uVar18 = (ulonglong)bVar2;
    local_5e0 = bVar2;
    cVar1 = FUN_140104440(plVar19);
    if ((((cVar1 != '\0') && (cVar1 = FUN_1400ffc20(plVar19), cVar1 == '\0')) &&
        (cVar1 = FUN_1400ff650(plVar19,2), cVar1 == '\0')) &&
       (((cVar1 = FUN_1400ff650(plVar19,1), cVar1 == '\0' &&
         (iVar4 = FUN_1400fda10(plVar19,0x17,1), iVar4 == 0)) && (bVar2 == 0)))) {
      uVar5 = (**(code **)(*plVar13 + 8))(plVar13);
      local_5b0 = (longlong *)CONCAT44(local_5b0._4_4_,uVar5);
      local_5c8 = FUN_1400fda10(plVar19,0xf,1);
      local_5bc = FUN_1400fda10(plVar19,0xe,1);
      local_5cc = FUN_1400fda10(plVar19,9,1);
      uVar5 = FUN_1400fda10(plVar19,8,1);
      uVar7 = FUN_1400fda10(plVar19,0xc,1);
      uVar8 = FUN_1400fda10(plVar19,5,1);
      uVar9 = FUN_1400fda10(plVar19,4,1);
      uVar10 = FUN_1400fda10(plVar19,1,1);
      uVar11 = (**(code **)(*plVar19 + 8))(plVar19);
      (**(code **)(*local_578 + 8))();
      (**(code **)(*local_5b8 + 0x18))();
      local_5f0 = local_5d0;
      local_5f8 = local_5c0;
      local_600 = local_5b0._0_4_;
      local_608 = local_5c8;
      local_610 = local_5bc;
      local_618 = local_5cc;
      local_648 = (undefined8 *)CONCAT44(local_648._4_4_,uVar11);
      local_640 = uVar10;
      local_638 = uVar9;
      local_630 = uVar8;
      local_628 = uVar7;
      local_620 = uVar5;
      tq::MyLogSave("gmlog/drop_item",
                    "%s(%u) drop item:[id=%u, type=%u], dur=%d, max_dur=%d, addition_level:%d, gem1=%d, gem2=%d, redue_dmg=%d, add_life=%d, map_id=%u, pos_x=%d, pos_y=%d"
                   );
      uVar18 = (ulonglong)CONCAT31((int3)((uint)uVar11 >> 8),local_5e0);
      plVar19 = local_5d8;
      param_1 = local_578;
      plVar21 = local_5b8;
      param_2 = local_5e4;
    }
    lVar14 = 0;
    cVar1 = FUN_140105800(plVar19);
    if ((cVar1 == '\0') || ((char)uVar18 != '\0')) {
      pIVar20 = theInstance();
      lVar14 = *plVar21;
      uVar16 = (*(code *)**(undefined8 **)pIVar20)(pIVar20,"STR_NOT_DISCARDABLE");
      (**(code **)(lVar14 + 0x358))(plVar21,uVar16);
      if (local_550 != (void *)0x0) {
        operator_delete(local_550);
      }
      local_550 = (void *)0x0;
      local_548 = 0;
      local_540 = 0;
      operator_delete(local_568[0]);
      if (local_590 != (longlong *)0x0) {
        operator_delete(local_590);
      }
      local_590 = (longlong *)0x0;
      local_588 = (longlong *)0x0;
      local_580 = 0;
      operator_delete(local_5a8[0]);
      return 0;
    }
    FUN_140101cb0(plVar19,local_4e8);
    cVar1 = FUN_1400ffbe0(plVar19);
    if (((cVar1 == '\0') && (bVar2 = FUN_1400fda10(plVar19,0x6e,1), ((bVar2 ^ 0xff) & 1) != 0)) &&
       (iVar4 = FUN_1400fda10(plVar19,0x17,1), iVar4 == 0)) {
      uVar16 = FUN_140008520((int)param_1[0x246]);
      uVar16 = FUN_140117f70(uVar16);
      cVar1 = FUN_14020c700(uVar16,plVar19);
      if ((cVar1 != '\0') || (uVar3 = FUN_1400fda10(plVar19,0x6e,1), (uVar3 >> 4 & 1) != 0))
      goto LAB_14033ddb9;
      local_5e4 = (uint)CONCAT71((int7)(uVar18 >> 8),1);
      plVar13 = (longlong *)FUN_140087d40();
      iVar4 = (**(code **)(*plVar13 + 0x148))(plVar13,plVar19);
      if ((iVar4 == 2) || (iVar4 == 3)) {
        local_5e4 = CONCAT31(local_5e4._1_3_,local_490 != 0);
      }
    }
    else {
LAB_14033ddb9:
      local_5e4 = local_5e4 & 0xffffff00;
    }
    iVar4 = FUN_1400fda10(plVar19,1,1);
    if (iVar4 != 0x109a00) {
      uVar5 = FUN_1400fda10(plVar19,1,1);
      cVar1 = FUN_1400ff940(uVar5);
      if (((cVar1 == '\0') ||
          ((iVar4 = FUN_1400fda10(plVar19,8,1), iVar4 == 0 &&
           (iVar4 = FUN_1400fda10(plVar19,9,1), iVar4 == 0)))) &&
         (cVar1 = FUN_140103bd0(plVar19), cVar1 != '\0')) {
        FUN_1400fda10(plVar19,1,1);
      }
    }
    if (((param_5 != '\0') && (cVar1 = FUN_140102870(plVar19), cVar1 != '\0')) &&
       (iVar4 = FUN_1400ffda0(plVar19), 1 < iVar4)) {
      iVar4 = FUN_1400ffda0(plVar19);
      iVar12 = tq::RandGet(iVar4);
      iVar12 = iVar12 + 1;
      if (iVar12 < iVar4) {
        local_488 = iVar12;
        FUN_140105d40(plVar19,iVar4 - iVar12,0);
        plVar13 = (longlong *)FUN_140087d40();
        local_640 = 0;
        local_648 = (undefined8 *)((ulonglong)local_648 & 0xffffffff00000000);
        (**(code **)(*plVar13 + 0x130))(plVar13,param_1,plVar19,3);
        cVar1 = (char)local_5e4;
        goto LAB_14033e1a4;
      }
    }
    lVar15 = FUN_140100070(plVar19);
    if (((lVar15 != 0) || (lVar15 = FUN_140100080(plVar19), lVar15 != 0)) ||
       ((lVar15 = FUN_140100290(plVar19), lVar15 != 0 ||
        (lVar15 = FUN_1401002a0(plVar19), lVar15 != 0)))) {
      local_5c4 = FUN_140100360(plVar19);
      local_5e8 = '\x01';
      FUN_140109210(plVar19,local_5a8);
      plVar19 = local_590;
      plVar13 = local_5a8[0];
      if (local_588 < local_590) {
        _invalid_parameter_noinfo();
        plVar13 = local_5a8[0];
      }
      while( true ) {
        plVar17 = local_588;
        if (local_588 < local_590) {
          _invalid_parameter_noinfo();
        }
        if ((plVar13 == (longlong *)0x0) || (plVar13 != local_5a8[0])) {
          _invalid_parameter_noinfo();
        }
        plVar22 = local_5d8;
        if (plVar19 == plVar17) break;
        if (plVar13 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar15 = lVar14;
        }
        else {
          lVar15 = *plVar13;
        }
        if (*(longlong **)(lVar15 + 0x20) <= plVar19) {
          _invalid_parameter_noinfo();
        }
        if (*plVar19 != 0) {
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar15 = lVar14;
          }
          else {
            lVar15 = *plVar13;
          }
          if (*(longlong **)(lVar15 + 0x20) <= plVar19) {
            _invalid_parameter_noinfo();
          }
          local_528 = (**(code **)(*(longlong *)*plVar19 + 0x30))((longlong *)*plVar19,4);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar15 = lVar14;
          }
          else {
            lVar15 = *plVar13;
          }
          if (*(longlong **)(lVar15 + 0x20) <= plVar19) {
            _invalid_parameter_noinfo();
          }
          local_524 = (**(code **)(*(longlong *)*plVar19 + 0x30))((longlong *)*plVar19,5);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar15 = lVar14;
          }
          else {
            lVar15 = *plVar13;
          }
          if (*(longlong **)(lVar15 + 0x20) <= plVar19) {
            _invalid_parameter_noinfo();
          }
          local_520 = (**(code **)(*(longlong *)*plVar19 + 0x30))((longlong *)*plVar19,6);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar15 = lVar14;
          }
          else {
            lVar15 = *plVar13;
          }
          if (*(longlong **)(lVar15 + 0x20) <= plVar19) {
            _invalid_parameter_noinfo();
          }
          local_52c = (**(code **)(*(longlong *)*plVar19 + 0x30))((longlong *)*plVar19,3);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar15 = lVar14;
          }
          else {
            lVar15 = *plVar13;
          }
          if (*(longlong **)(lVar15 + 0x20) <= plVar19) {
            _invalid_parameter_noinfo();
          }
          local_518 = (**(code **)(*(longlong *)*plVar19 + 0x30))((longlong *)*plVar19,8);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar15 = lVar14;
          }
          else {
            lVar15 = *plVar13;
          }
          if (*(longlong **)(lVar15 + 0x20) <= plVar19) {
            _invalid_parameter_noinfo();
          }
          iVar4 = (**(code **)(*(longlong *)*plVar19 + 0x30))((longlong *)*plVar19,7);
          if (iVar4 == 0) {
            local_51c = 0;
          }
          else {
            if (plVar13 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar15 = lVar14;
            }
            else {
              lVar15 = *plVar13;
            }
            if (*(longlong **)(lVar15 + 0x20) <= plVar19) {
              _invalid_parameter_noinfo();
            }
            iVar4 = (**(code **)(*(longlong *)*plVar19 + 0x30))((longlong *)*plVar19,7);
            _Var6 = _time32((__time32_t *)0x0);
            local_51c = iVar4 - _Var6;
            if (local_51c == 0) goto LAB_14033e13c;
          }
          FUN_14033c3e0(local_568,local_538);
        }
LAB_14033e13c:
        if (plVar13 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar15 = lVar14;
        }
        else {
          lVar15 = *plVar13;
        }
        if (*(longlong **)(lVar15 + 0x20) <= plVar19) {
          _invalid_parameter_noinfo();
        }
        plVar19 = plVar19 + 1;
      }
      FUN_140100090(local_5d8,2);
      FUN_140100210(plVar22,2);
    }
    cVar1 = (char)local_5e4;
    local_648 = (undefined8 *)CONCAT71(local_648._1_7_,cVar1);
    FUN_14033a6a0(param_1,param_2,1,0);
  }
  else {
    plVar17 = (longlong *)FUN_140087d40();
    plVar17 = (longlong *)(**(code **)(*plVar17 + 0x60))(plVar17,param_2);
    local_5d8 = plVar17;
    if (((((plVar17 == (longlong *)0x0) ||
          (uVar3 = (**(code **)(*plVar17 + 8))(plVar17), uVar3 != param_2)) ||
         (cVar1 = FUN_1400ffc20(plVar17), cVar1 != '\0')) ||
        ((cVar1 = FUN_1400ff650(plVar17,2), cVar1 != '\0' ||
         (cVar1 = FUN_1400ff650(plVar17,1), cVar1 != '\0')))) ||
       (iVar4 = FUN_1400fda10(plVar17,0x17,1), iVar4 != 0)) goto LAB_14033d9db;
    uVar5 = (**(code **)(*plVar17 + 8))(plVar17);
    cVar1 = FUN_1403380a0(param_1,uVar5);
    if (cVar1 != '\0') goto LAB_14033d9db;
    uVar3 = FUN_1400fda10(plVar17,7,1);
    plVar22 = (longlong *)(ulonglong)uVar3;
    local_5e4 = uVar3;
    FUN_1400f83e0(local_478);
    uVar5 = (**(code **)(*plVar17 + 8))(plVar17);
    local_648 = (undefined8 *)((ulonglong)local_648 & 0xffffffff00000000);
    iVar4 = FUN_1400f8490(local_478,uVar5,0x12,uVar3);
    if (iVar4 != 0) {
      (**(code **)(*plVar21 + 0x350))(plVar21,local_478);
    }
    FUN_14019e880(param_1 + 0x19f,&local_5e4);
    FUN_140338b40(param_1);
    lVar14 = FUN_140100070(plVar17);
    if ((((lVar14 != 0) || (lVar14 = FUN_140100080(plVar17), lVar14 != 0)) ||
        (lVar14 = FUN_140100290(plVar17), lVar14 != 0)) ||
       (lVar14 = FUN_1401002a0(plVar17), lVar14 != 0)) {
      local_5c4 = FUN_140100360(plVar17);
      local_5e8 = '\x01';
      FUN_140109210(plVar17,local_5a8);
      plVar23 = local_590;
      plVar13 = local_5a8[0];
      if (local_588 < local_590) {
        _invalid_parameter_noinfo();
        plVar13 = local_5a8[0];
      }
      while( true ) {
        plVar22 = local_588;
        if (local_588 < local_590) {
          _invalid_parameter_noinfo();
        }
        if ((plVar13 == (longlong *)0x0) || (plVar13 != local_5a8[0])) {
          _invalid_parameter_noinfo();
        }
        plVar17 = local_5d8;
        if (plVar23 == plVar22) break;
        if (plVar13 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar17 = plVar19;
        }
        else {
          plVar17 = (longlong *)*plVar13;
        }
        if ((longlong *)plVar17[4] <= plVar23) {
          _invalid_parameter_noinfo();
        }
        if (*plVar23 != 0) {
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar17 = plVar19;
          }
          else {
            plVar17 = (longlong *)*plVar13;
          }
          if ((longlong *)plVar17[4] <= plVar23) {
            _invalid_parameter_noinfo();
          }
          local_528 = (**(code **)(*(longlong *)*plVar23 + 0x30))((longlong *)*plVar23,4);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar17 = plVar19;
          }
          else {
            plVar17 = (longlong *)*plVar13;
          }
          if ((longlong *)plVar17[4] <= plVar23) {
            _invalid_parameter_noinfo();
          }
          local_524 = (**(code **)(*(longlong *)*plVar23 + 0x30))((longlong *)*plVar23,5);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar17 = plVar19;
          }
          else {
            plVar17 = (longlong *)*plVar13;
          }
          if ((longlong *)plVar17[4] <= plVar23) {
            _invalid_parameter_noinfo();
          }
          local_520 = (**(code **)(*(longlong *)*plVar23 + 0x30))((longlong *)*plVar23,6);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar17 = plVar19;
          }
          else {
            plVar17 = (longlong *)*plVar13;
          }
          if ((longlong *)plVar17[4] <= plVar23) {
            _invalid_parameter_noinfo();
          }
          local_52c = (**(code **)(*(longlong *)*plVar23 + 0x30))((longlong *)*plVar23,3);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar17 = plVar19;
          }
          else {
            plVar17 = (longlong *)*plVar13;
          }
          if ((longlong *)plVar17[4] <= plVar23) {
            _invalid_parameter_noinfo();
          }
          local_518 = (**(code **)(*(longlong *)*plVar23 + 0x30))((longlong *)*plVar23,8);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar17 = plVar19;
          }
          else {
            plVar17 = (longlong *)*plVar13;
          }
          if ((longlong *)plVar17[4] <= plVar23) {
            _invalid_parameter_noinfo();
          }
          iVar4 = (**(code **)(*(longlong *)*plVar23 + 0x30))((longlong *)*plVar23,7);
          if (iVar4 == 0) {
            local_51c = 0;
          }
          else {
            if (plVar13 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar17 = plVar19;
            }
            else {
              plVar17 = (longlong *)*plVar13;
            }
            if ((longlong *)plVar17[4] <= plVar23) {
              _invalid_parameter_noinfo();
            }
            iVar4 = (**(code **)(*(longlong *)*plVar23 + 0x30))((longlong *)*plVar23,7);
            _Var6 = _time32((__time32_t *)0x0);
            local_51c = iVar4 - _Var6;
            if (local_51c == 0) goto LAB_14033d67c;
          }
          FUN_14033c3e0(local_568,local_538);
        }
LAB_14033d67c:
        if (plVar13 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar17 = plVar19;
        }
        else {
          plVar17 = (longlong *)*plVar13;
        }
        if ((longlong *)plVar17[4] <= plVar23) {
          _invalid_parameter_noinfo();
        }
        plVar23 = plVar23 + 1;
      }
      FUN_140100090(local_5d8,2);
      FUN_140100210(plVar17,2);
      plVar13 = local_508;
    }
    FUN_140101cb0(plVar17,local_4e8);
    cVar1 = FUN_1400ffbe0(plVar17);
    if (((cVar1 == '\0') && (bVar2 = FUN_1400fda10(plVar17,0x6e,1), ((bVar2 ^ 0xff) & 1) != 0)) &&
       (iVar4 = FUN_1400fda10(plVar17,0x17,1), iVar4 == 0)) {
      uVar16 = FUN_140008520((int)param_1[0x246]);
      uVar16 = FUN_140117f70(uVar16);
      cVar1 = FUN_14020c700(uVar16,plVar17);
      if ((cVar1 != '\0') || (uVar3 = FUN_1400fda10(plVar17,0x6e,1), (uVar3 >> 4 & 1) != 0))
      goto LAB_14033d795;
      local_5e4 = (uint)CONCAT71((int7)((ulonglong)plVar22 >> 8),1);
      plVar19 = (longlong *)FUN_140087d40();
      iVar4 = (**(code **)(*plVar19 + 0x148))(plVar19,plVar17);
      if ((iVar4 == 2) || (iVar4 == 3)) {
        local_5e4 = (uint)(local_490 != 0);
      }
    }
    else {
LAB_14033d795:
      local_5e4 = local_5e4 & 0xffffff00;
    }
    cVar1 = FUN_140104440(plVar17);
    if (cVar1 != '\0') {
      local_5cc = (**(code **)(*plVar13 + 8))(plVar13);
      local_5bc = FUN_1400fda10(plVar17,0xf,1);
      local_5c8 = FUN_1400fda10(plVar17,0xe,1);
      uVar5 = FUN_1400fda10(plVar17,9,1);
      local_5b0 = (longlong *)CONCAT44(local_5b0._4_4_,uVar5);
      uVar5 = FUN_1400fda10(plVar17,8,1);
      uVar7 = FUN_1400fda10(plVar17,0xc,1);
      uVar8 = FUN_1400fda10(plVar17,5,1);
      uVar9 = FUN_1400fda10(plVar17,4,1);
      uVar10 = FUN_1400fda10(plVar17,1,1);
      uVar11 = (**(code **)(*plVar17 + 8))(plVar17);
      (**(code **)(*local_578 + 8))();
      (**(code **)(*local_5b8 + 0x18))();
      local_5f0 = local_5d0;
      local_5f8 = local_5c0;
      local_600 = local_5cc;
      local_608 = local_5bc;
      local_610 = local_5c8;
      local_618 = local_5b0._0_4_;
      local_648 = (undefined8 *)CONCAT44(local_648._4_4_,uVar11);
      local_640 = uVar10;
      local_638 = uVar9;
      local_630 = uVar8;
      local_628 = uVar7;
      local_620 = uVar5;
      tq::MyLogSave("gmlog/drop_item",
                    "%s(%u) drop equip:[id=%u, type=%u], dur=%d, max_dur=%d, addition_level:%d, gem1=%d, gem2=%d, redue_dmg=%d, add_life=%d, map_id=%u, pos_x=%d, pos_y=%d"
                   );
      plVar17 = local_5d8;
      param_1 = local_578;
      plVar21 = local_5b8;
    }
    iVar4 = FUN_1400fda10(plVar17,1,1);
    if (iVar4 != 0x109a00) {
      uVar5 = FUN_1400fda10(plVar17,1,1);
      cVar1 = FUN_1400ff940(uVar5);
      if (((cVar1 == '\0') ||
          ((iVar4 = FUN_1400fda10(plVar17,8,1), iVar4 == 0 &&
           (iVar4 = FUN_1400fda10(plVar17,9,1), iVar4 == 0)))) &&
         (cVar1 = FUN_140103bd0(plVar17), cVar1 != '\0')) {
        FUN_1400fda10(plVar17,1,1);
      }
    }
    plVar13 = (longlong *)FUN_140087d40();
    lVar14 = *plVar13;
    uVar5 = (**(code **)(*local_5d8 + 8))();
    cVar1 = (char)local_5e4;
    (**(code **)(lVar14 + 0x30))(plVar13,uVar5,1,local_5e4 & 0xff);
    FUN_140194390(param_1);
    FUN_1400f8430(local_478);
  }
LAB_14033e1a4:
  if (cVar1 != '\0') {
    local_5d8 = (longlong *)CONCAT44(local_5d0,local_5c0);
    plVar13 = (longlong *)FUN_140117c30();
    local_5b8 = plVar13;
    if (plVar13 != (longlong *)0x0) {
      uVar16 = FUN_140008520((int)param_1[0x246]);
      plVar19 = (longlong *)FUN_1400876b0(uVar16);
      uVar5 = (**(code **)(*plVar19 + 0x58))(plVar19);
      local_638 = local_5c4;
      local_640 = 0;
      local_648 = local_4e8;
      cVar1 = FUN_14037cda0(plVar13,uVar5,local_508,local_5d8);
      if (cVar1 == '\0') {
        local_648 = (undefined8 *)CONCAT44(local_648._4_4_,0x1033);
        log_InlineLogERROR(&DAT_1406d9c10);
        pIVar20 = theInstance();
        lVar14 = *plVar21;
        uVar16 = (*(code *)**(undefined8 **)pIVar20)(pIVar20,"STR_MAKE_ITEM_FAILED");
        (**(code **)(lVar14 + 0x358))(plVar21,uVar16,(int)plVar13[4]);
        (**(code **)(plVar13[2] + 8))();
        uVar16 = FUN_140008520((int)param_1[0x246]);
        uVar16 = FUN_1400fd800(uVar16);
        FUN_14028e470(uVar16,(undefined4)local_4e8[0]);
      }
      else {
        if (local_5e8 != '\0') {
          FUN_14037d3f0(plVar13,local_568);
        }
        uVar16 = FUN_140008520((int)param_1[0x246]);
        plVar21 = (longlong *)FUN_1400876b0(uVar16);
        plVar21 = (longlong *)(**(code **)(*plVar21 + 0x50))(plVar21);
        (**(code **)(*plVar21 + 0x20))(plVar21,plVar13);
      }
    }
  }
LAB_14033e3bc:
  FUN_1401642f0(param_1);
  if (local_550 != (void *)0x0) {
    operator_delete(local_550);
  }
  local_550 = (void *)0x0;
  local_548 = 0;
  local_540 = 0;
  operator_delete(local_568[0]);
  if (local_590 != (longlong *)0x0) {
    operator_delete(local_590);
  }
  local_590 = (longlong *)0x0;
  local_588 = (longlong *)0x0;
  local_580 = 0;
  operator_delete(local_5a8[0]);
  return 1;
}

// ==== CMsgItem::helper_14033f010  @14033f010  [medium:callgraph-r1]  (orig: FUN_14033f010)
undefined8 FUN_14033f010(undefined8 param_1,longlong param_2,uint param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined8 uVar5;
  longlong lVar6;
  int *piVar7;
  longlong *plVar8;
  int iVar9;
  longlong lVar10;
  longlong *local_res10 [2];
  longlong *local_res20;
  longlong *local_a8;
  undefined8 *puStack_a0;
  longlong *local_98;
  undefined8 *puStack_90;
  undefined1 local_88 [16];
  longlong *local_78 [6];
  undefined8 *local_48;
  ulonglong local_40;
  
  if (param_2 == 0) {
    uVar5 = 0;
  }
  else if ((int)param_3 < 7) {
    uVar5 = 0;
  }
  else {
    iVar9 = 0;
    local_res10[0] = operator_new(8);
    if (local_res10[0] == (longlong *)0x0) {
      local_78[0] = (longlong *)0x0;
    }
    else {
      *local_res10[0] = (longlong)local_78;
      local_78[0] = local_res10[0];
    }
    local_res20 = local_res10[0];
    local_48 = (undefined8 *)FUN_140099ce0(local_78);
    *(undefined1 *)((longlong)local_48 + 0x21) = 1;
    local_48[1] = local_48;
    *local_48 = local_48;
    local_48[2] = local_48;
    local_40 = 0;
    lVar10 = 0;
    if (0 < (int)param_3) {
      do {
        cVar1 = FUN_140332fe0(param_1,*(undefined4 *)(param_2 + lVar10 * 4));
        if (cVar1 == '\0') {
LAB_14033f4ea:
          puStack_a0 = (undefined8 *)*local_48;
          local_98 = local_78[0];
          puStack_90 = local_48;
          local_a8 = local_78[0];
          FUN_1400a4100(local_78,local_88,&local_a8,&local_98);
          operator_delete(local_48);
          local_48 = (undefined8 *)0x0;
          local_40 = 0;
          operator_delete(local_78[0]);
          return 0;
        }
        plVar8 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar8 = (longlong *)0x0;
        }
        lVar6 = (**(code **)(*plVar8 + 0x60))(plVar8,*(undefined4 *)(param_2 + lVar10 * 4));
        if (lVar6 == 0) goto LAB_14033f4ea;
        uVar2 = FUN_1400fda10(lVar6,1,1);
        iVar3 = FUN_1400ff680(uVar2);
        if (iVar3 != 9) goto LAB_14033f4ea;
        uVar2 = FUN_1400fda10(lVar6,1,1);
        iVar3 = FUN_1400fecd0(uVar2);
        if (iVar3 != 0) goto LAB_14033f4ea;
        uVar4 = FUN_1400fda10(lVar6,1,1);
        iVar3 = FUN_1400fda10(lVar6,0x16,1);
        if (iVar3 != 0) {
          iVar9 = iVar9 + 1;
        }
        if (uVar4 % 10 != 2) {
          puStack_a0 = (undefined8 *)*local_48;
          local_98 = local_78[0];
          puStack_90 = local_48;
          local_a8 = local_78[0];
          FUN_1400a4100(local_78,local_88,&local_a8,&local_98);
          operator_delete(local_48);
          local_48 = (undefined8 *)0x0;
          local_40 = 0;
          operator_delete(local_78[0]);
          return 0;
        }
        cVar1 = FUN_140338940(param_1,uVar4,uVar4,1,1,0);
        if (cVar1 == '\0') {
          puStack_a0 = (undefined8 *)*local_48;
          local_98 = local_78[0];
          puStack_90 = local_48;
          local_a8 = local_78[0];
          FUN_1400a4100(local_78,local_88,&local_a8,&local_98);
          operator_delete(local_48);
          local_48 = (undefined8 *)0x0;
          local_40 = 0;
          operator_delete(local_78[0]);
          return 0;
        }
        uVar4 = (uVar4 / 10) % 10;
        local_res10[0] = (longlong *)CONCAT44(local_res10[0]._4_4_,uVar4);
        if (6 < uVar4) {
          puStack_a0 = (undefined8 *)*local_48;
          local_98 = local_78[0];
          puStack_90 = local_48;
          local_a8 = local_78[0];
          FUN_1400a4100(local_78,local_88,&local_a8,&local_98);
          operator_delete(local_48);
          local_48 = (undefined8 *)0x0;
          local_40 = 0;
          operator_delete(local_78[0]);
          return 0;
        }
        piVar7 = (int *)FUN_14033a2d0(local_78,local_res10);
        if (*piVar7 != 0) {
          puStack_a0 = (undefined8 *)*local_48;
          local_98 = local_78[0];
          puStack_90 = local_48;
          local_a8 = local_78[0];
          FUN_1400a4100(local_78,local_88,&local_a8,&local_98);
          operator_delete(local_48);
          local_48 = (undefined8 *)0x0;
          local_40 = 0;
          operator_delete(local_78[0]);
          return 0;
        }
        piVar7 = (int *)FUN_14033a2d0(local_78,local_res10);
        *piVar7 = *piVar7 + 1;
        lVar10 = lVar10 + 1;
      } while (lVar10 < (int)param_3);
      if ((iVar9 != 7) && (iVar9 != 0)) {
        puStack_90 = (undefined8 *)*local_48;
        local_a8 = local_78[0];
        puStack_a0 = local_48;
        local_98 = local_78[0];
        FUN_1400a4100(local_78,local_88,&local_98,&local_a8);
        operator_delete(local_48);
        local_48 = (undefined8 *)0x0;
        local_40 = 0;
        operator_delete(local_78[0]);
        return 0;
      }
    }
    if (local_40 == param_3) {
      puStack_a0 = (undefined8 *)*local_48;
      local_98 = local_78[0];
      puStack_90 = local_48;
      local_a8 = local_78[0];
      FUN_1400a4100(local_78,local_88,&local_a8,&local_98);
      operator_delete(local_48);
      local_48 = (undefined8 *)0x0;
      local_40 = 0;
      operator_delete(local_78[0]);
      uVar5 = 1;
    }
    else {
      puStack_a0 = (undefined8 *)*local_48;
      local_98 = local_78[0];
      puStack_90 = local_48;
      local_a8 = local_78[0];
      FUN_1400a4100(local_78,local_88,&local_a8,&local_98);
      operator_delete(local_48);
      local_48 = (undefined8 *)0x0;
      local_40 = 0;
      operator_delete(local_78[0]);
      uVar5 = 0;
    }
  }
  return uVar5;
}

// ==== CMsgItem::helper_1403402b0  @1403402b0  [medium:callgraph-r0]  (orig: FUN_1403402b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403402b0(longlong *param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  ulong uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong lVar11;
  rsize_t _DstSize;
  int *_Dst;
  undefined1 auStack_4f8 [32];
  undefined4 *local_4d8;
  undefined4 *local_4d0;
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4a8;
  undefined4 local_4a4;
  undefined4 local_4a0;
  undefined4 local_49c;
  longlong local_498;
  int *piStack_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  cVar3 = FUN_140333160();
  if (cVar3 != '\0') {
    plVar9 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_4d8 = (undefined4 *)CONCAT44(local_4d8._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar9 = (longlong *)0x0;
    }
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,param_2);
    if (plVar9 != (longlong *)0x0) {
      iVar4 = FUN_1400fda10(plVar9,2,1);
      iVar5 = (**(code **)(*param_1 + 8))(param_1);
      if ((iVar4 == iVar5) && ((param_1[0x185] - param_1[0x184] >> 2) + 1U < 0x29)) {
        local_4a8 = 0;
        local_4a0 = 0;
        local_4a4 = 0;
        FUN_140104140(plVar9,7,0,1);
        iVar4 = (**(code **)(*plVar9 + 8))(plVar9);
        piVar1 = (int *)param_1[0x197];
        if (piVar1 < (int *)param_1[0x196]) {
          _invalid_parameter_noinfo();
        }
        piVar2 = (int *)param_1[0x196];
        if ((int *)param_1[0x197] < piVar2) {
          _invalid_parameter_noinfo();
        }
        local_498 = param_1[0x193];
        for (_Dst = piVar2; (_Dst != piVar1 && (*_Dst != iVar4)); _Dst = _Dst + 1) {
        }
        piVar1 = (int *)param_1[0x197];
        piStack_490 = piVar2;
        if (piVar1 < (int *)param_1[0x196]) {
          _invalid_parameter_noinfo();
        }
        if ((local_498 == 0) || (local_498 != param_1[0x193])) {
          _invalid_parameter_noinfo();
        }
        if (_Dst != piVar1) {
          lVar11 = param_1[0x197] - (longlong)(_Dst + 1) >> 2;
          if (0 < lVar11) {
            _DstSize = lVar11 << 2;
            memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
          }
          param_1[0x197] = param_1[0x197] + -4;
          if ((_Dst < (int *)param_1[0x196]) || ((int *)param_1[0x197] < _Dst)) {
            _invalid_parameter_noinfo();
          }
        }
        lVar11 = FUN_140100070(plVar9);
        if ((lVar11 != 0) || (lVar11 = FUN_140100290(plVar9), lVar11 != 0)) {
          plVar10 = (longlong *)FUN_140087d40();
          lVar11 = *plVar10;
          uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
          (**(code **)(lVar11 + 0x178))(plVar10,uVar6);
        }
        local_49c = (**(code **)(*plVar9 + 8))(plVar9);
        FUN_140037fe0(param_1 + 0x181,&local_49c);
        plVar10 = (longlong *)FUN_1400e1de0();
        lVar11 = *plVar10;
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        local_4d0 = &local_4a4;
        local_4d8 = &local_4a0;
        (**(code **)(lVar11 + 0x18))(plVar10,uVar6,param_2,&local_4a8);
        FUN_1400f83e0(local_478);
        uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
        local_4d8 = (undefined4 *)((ulonglong)local_4d8 & 0xffffffff00000000);
        iVar4 = FUN_1400f8490(local_478,uVar6,0x32,local_4a8);
        if (iVar4 != 0) {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
        }
        uVar6 = FUN_1400fda10(plVar9,0xd,1);
        uVar7 = (**(code **)(*plVar9 + 8))(plVar9);
        uVar8 = tq::TimeGet(2);
        (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        local_4c0 = local_4a4;
        local_4d0 = (undefined4 *)CONCAT44(local_4d0._4_4_,local_4a0);
        local_4d8 = (undefined4 *)CONCAT44(local_4d8._4_4_,uVar8);
        local_4c8 = uVar7;
        local_4b8 = uVar6;
        tq::MyLogSave("gmlog/GiveBack_Opt_VirGM",
                      "CN[%u]: get item [name=%s], Time[%u], optType[%d], Item[id=%u, itemtype/money=%d, data=%d]"
                     );
        FUN_1400f8430(local_478);
      }
    }
  }
  return;
}

// ==== CMsgItem::helper_140340c20  @140340c20  [medium:callgraph-r0]  (orig: FUN_140340c20)
undefined8 FUN_140340c20(longlong *param_1,int param_2)

{
  longlong lVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  longlong *plVar7;
  IStringManager *pIVar8;
  undefined8 uVar9;
  undefined4 uVar10;
  
  if ((char)param_1[0x259] == '\0') {
    cVar2 = FUN_140167b70();
    if ((cVar2 == '\0') && (param_2 != 0)) {
      cVar2 = FUN_140332fe0(param_1,param_2);
      if (cVar2 != '\0') {
        plVar7 = (longlong *)FUN_140087d40();
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x60))(plVar7,param_2);
        if (plVar7 != (longlong *)0x0) {
          cVar2 = FUN_1401036f0(plVar7);
          if (cVar2 != '\0') {
            cVar2 = FUN_140100c60(plVar7);
            if (cVar2 == '\0') {
              pIVar8 = theInstance();
              lVar1 = param_1[2];
              uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_CHEST_NOT_EMPYT");
              (**(code **)(lVar1 + 0x358))(param_1 + 2,uVar9);
            }
            else {
              uVar9 = FUN_140008520((int)param_1[0x246]);
              uVar3 = FUN_14008afc0(uVar9);
              uVar4 = FUN_140168bc0(param_1);
              if (uVar4 < uVar3) {
                iVar5 = FUN_1400fdb80(plVar7,1,1);
                if (iVar5 == 0x10c8e6) {
                  uVar10 = 6;
                }
                else if (iVar5 == 0x10c8e9) {
                  uVar10 = 0xc;
                }
                else {
                  uVar10 = 3;
                }
                uVar6 = (**(code **)(*plVar7 + 8))(plVar7);
                cVar2 = FUN_140340190(param_1,uVar6,1,1);
                if (cVar2 == '\0') {
                  (**(code **)(*plVar7 + 8))(plVar7);
                  (**(code **)(*param_1 + 8))(param_1);
                  log_InlineLogERROR(&DAT_140753858);
                  uVar9 = 0;
                }
                else {
                  plVar7 = (longlong *)FUN_1400fd850();
                  lVar1 = *plVar7;
                  uVar6 = (**(code **)(*param_1 + 8))(param_1);
                  cVar2 = (**(code **)(lVar1 + 0xa0))(plVar7,uVar6,uVar10);
                  if (cVar2 == '\0') {
                    (**(code **)(*param_1 + 8))(param_1);
                    log_InlineLogERROR(
                                      "CUser[%u]::UseChest AddChestPackSize failed, ExpendMultiItem idType[%d]"
                                      );
                  }
                  FUN_1401642f0(param_1);
                  uVar9 = 1;
                }
                return uVar9;
              }
            }
          }
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMsgItem::helper_1403412f0  @1403412f0  [medium:callgraph-r1]  (orig: FUN_1403412f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1403412f0(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  longlong *plVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  longlong *plVar12;
  longlong lVar13;
  longlong lVar14;
  uint uVar15;
  uint uVar16;
  longlong *plVar17;
  undefined1 auStack_d48 [32];
  undefined8 local_d28;
  char local_d18 [8];
  undefined8 local_d10;
  undefined1 local_d08 [1072];
  undefined1 local_8d8 [1072];
  undefined1 local_4a8 [1104];
  ulonglong local_58;
  
  local_d10 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_d48;
  cVar1 = FUN_140332fe0();
  if (cVar1 != '\0') {
    plVar17 = (longlong *)0x0;
    plVar9 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_d28 = CONCAT44(local_d28._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar9 = plVar17;
    }
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,param_2);
    if (plVar9 != (longlong *)0x0) {
      plVar12 = param_1 + 2;
      cVar1 = (**(code **)(*plVar12 + 0x220))(plVar12);
      if (cVar1 == '\0') {
        return 0;
      }
      iVar3 = (**(code **)(*plVar12 + 0x70))(plVar12);
      if (DAT_14094da38 <= iVar3) {
        return 0;
      }
      cVar1 = FUN_140178c90(param_1);
      if (cVar1 != '\0') {
        pIVar10 = theInstance();
        lVar13 = *plVar12;
        uVar11 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_ITEM_DISABLE_AT_NO_EXP_MAP");
        (**(code **)(lVar13 + 0x358))(plVar12,uVar11);
        return 0;
      }
      iVar3 = FUN_140175470(param_1);
      if ((iVar3 != 0) && (iVar3 = FUN_140164ee0(param_1), iVar3 == 0)) {
        return 0;
      }
      iVar3 = 600;
      iVar4 = tq::DateStamp(0);
      uVar16 = iVar4 % 10000;
      if (uVar16 == *(uint *)((longlong)param_1 + 0xf3c) / 10) {
        uVar15 = *(uint *)((longlong)param_1 + 0xf3c) % 10;
        if (8 < uVar15) {
          return 0;
        }
        FUN_140372770(param_1 + 0x1cf,uVar15 + 1 + uVar16 * 10,1);
      }
      else {
        FUN_140372770(param_1 + 0x1cf,uVar16 * 10,1);
      }
      FUN_14039e680(local_d08);
      uVar6 = *(undefined4 *)((longlong)param_1 + 0xf3c);
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      iVar4 = FUN_14039e700(local_d08,uVar5,0x80,uVar6);
      if (iVar4 != 0) {
        (**(code **)(*plVar12 + 0x350))(plVar12,local_d08);
      }
      uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
      cVar1 = FUN_140340190(param_1,uVar6,1,1);
      if (cVar1 == '\0') {
        local_d28 = CONCAT44(local_d28._4_4_,0x99d);
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_14039e6d0(local_d08);
        return 0;
      }
      FUN_1401642f0(param_1);
      iVar4 = (**(code **)(*plVar12 + 0x70))(plVar12);
      uVar11 = FUN_140118150();
      plVar9 = (longlong *)FUN_14014de60(uVar11,0,iVar4);
      if (plVar9 == (longlong *)0x0) {
        FUN_14039e6d0(local_d08);
        return 0;
      }
      plVar12 = (longlong *)(**(code **)(*(longlong *)plVar9[1] + 0x10))((longlong *)plVar9[1],1);
      lVar13 = (**(code **)(*plVar12 + 0x58))(plVar12);
      if (lVar13 < 1) {
        lVar13 = 1;
      }
      else {
        plVar12 = (longlong *)(**(code **)(*(longlong *)plVar9[1] + 0x10))((longlong *)plVar9[1],1);
        lVar13 = (**(code **)(*plVar12 + 0x58))(plVar12);
      }
      iVar7 = (**(code **)(*plVar9 + 0x10))(plVar9,2);
      lVar14 = (**(code **)(*param_1 + 0xa0))(param_1);
      iVar8 = FUN_140175470(param_1);
      if (iVar8 != 0) {
        iVar3 = FUN_140164ee0(param_1);
        iVar3 = (iVar3 * 600) / 100;
      }
      iVar7 = (int)(((double)lVar14 * (double)iVar7) / (double)lVar13) + iVar3;
      if (iVar4 < DAT_14094da38) {
        do {
          uVar11 = FUN_140118150();
          plVar12 = (longlong *)FUN_14014de60(uVar11,0,iVar4);
          if ((plVar12 == (longlong *)0x0) ||
             (iVar8 = (**(code **)(*plVar12 + 0x10))(plVar12,2), plVar9 = plVar12, iVar7 < iVar8))
          break;
          iVar8 = (**(code **)(*plVar12 + 0x10))(plVar12,2);
          iVar7 = iVar7 - iVar8;
          plVar17 = (longlong *)(ulonglong)((int)plVar17 + 1);
          iVar4 = iVar4 + 1;
        } while (iVar4 < DAT_14094da38);
      }
      plVar12 = param_1 + 2;
      local_d18[0] = '\0';
      if (0 < (int)plVar17) {
        (**(code **)(*param_1 + 200))(param_1,plVar17,local_d18);
        cVar1 = (**(code **)(*param_1 + 0x118))(param_1);
        if (cVar1 == '\0') {
          local_d28 = 0;
          (**(code **)(*plVar12 + 0x2e0))(plVar12,10,(longlong)((int)plVar17 * 3),1);
        }
        else {
          (**(code **)(*param_1 + 0xd0))(param_1,plVar17);
        }
        uVar6 = (**(code **)(*plVar12 + 0x80))(plVar12);
        FUN_1401a6420(param_1,0,uVar6,1);
        (**(code **)(*param_1 + 0xd8))(param_1);
      }
      iVar4 = (**(code **)(*plVar9 + 0x10))(plVar9,2);
      if (iVar4 < 1) {
        iVar4 = 1;
      }
      else {
        iVar4 = (**(code **)(*plVar9 + 0x10))(plVar9,2);
      }
      plVar9 = (longlong *)(**(code **)(*(longlong *)plVar9[1] + 0x10))((longlong *)plVar9[1],1);
      lVar13 = (**(code **)(*plVar9 + 0x58))(plVar9);
      lVar13 = (longlong)(((double)lVar13 * (double)iVar7) / (double)iVar4);
      if ((local_d18[0] == '\0') ||
         (lVar14 = (**(code **)(*param_1 + 0xa0))(param_1), lVar14 < lVar13)) {
        FUN_1401a6420(param_1,5,lVar13);
      }
      *(int *)(param_1 + 0x238) = (int)param_1[0x238] + iVar3;
      FUN_140161610(param_1,1);
      iVar3 = FUN_140163420(param_1);
      FUN_140163430(param_1,iVar3 + 10,0);
      FUN_14039e680(local_8d8);
      uVar2 = FUN_140163420(param_1);
      uVar6 = (**(code **)(*param_1 + 8))(param_1);
      iVar3 = FUN_14039e700(local_8d8,uVar6,0x29,uVar2);
      if (iVar3 != 0) {
        (**(code **)(*plVar12 + 0x350))(plVar12,local_8d8);
      }
      FUN_14039ed70(local_4a8);
      iVar3 = FUN_14039eef0(local_4a8,plVar12,0,0);
      if (iVar3 != 0) {
        (**(code **)(*plVar12 + 0x348))(plVar12,local_4a8,0);
      }
      FUN_14039edf0(local_4a8);
      FUN_14039e6d0(local_8d8);
      FUN_14039e6d0(local_d08);
      return 1;
    }
  }
  return 0;
}

// ==== CMsgItem::helper_140341c50  @140341c50  [medium:callgraph-r0]  (orig: FUN_140341c50)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140341c50(longlong *param_1,undefined4 param_2,undefined4 param_3,byte param_4,int param_5,
                  char param_6)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong *plVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  ulonglong uVar13;
  char *pcVar14;
  int iVar15;
  bool bVar16;
  int local_res8;
  longlong *local_68;
  int local_60;
  int local_5c;
  uint local_58;
  int local_54;
  int local_50;
  uint local_4c;
  int local_48;
  uint local_44;
  longlong local_40;
  longlong local_38;
  
  bVar16 = false;
  local_68 = (longlong *)0x0;
  uVar2 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
  uVar3 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
  uVar8 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
  cVar1 = FUN_1402c84c0(uVar8,uVar3,uVar2,0x1040);
  if (cVar1 == '\0') {
    lVar9 = FUN_140008520((int)param_1[0x246]);
    if (*(longlong *)(lVar9 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pRoleManager",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
    }
    plVar10 = (longlong *)
              (**(code **)(**(longlong **)(lVar9 + 0x88) + 0x20))
                        (*(longlong **)(lVar9 + 0x88),param_2);
    if (plVar10 == (longlong *)0x0) {
      return;
    }
    (**(code **)(*plVar10 + 0x298))(plVar10,0x1040,&local_68);
    if (local_68 == (longlong *)0x0) {
      return;
    }
    bVar16 = true;
  }
  cVar1 = (**(code **)(*local_68 + 0x50))();
  if ((cVar1 == '\0') &&
     (iVar4 = (**(code **)(*(longlong *)local_68[0xc] + 0x10))((longlong *)local_68[0xc],4),
     iVar4 != 0x20)) {
    return;
  }
  lVar9 = (**(code **)(*local_68 + 0x58))();
  if (lVar9 == 0) {
    return;
  }
  uVar8 = (**(code **)(*local_68 + 0x58))();
  cVar1 = FUN_14046add0(uVar8);
  if (cVar1 == '\0') {
    return;
  }
  lVar9 = (**(code **)(*local_68 + 0x58))();
  lVar9 = (**(code **)(**(longlong **)(lVar9 + 8) + 0x30))(*(longlong **)(lVar9 + 8),param_3);
  local_40 = lVar9;
  if (lVar9 == 0) {
    pIVar11 = theInstance();
    pcVar14 = "STR_GOOD_NOT_EXISTS";
    goto LAB_140341ded;
  }
  if (param_5 < 1) {
    param_5 = 1;
  }
  local_58 = 0;
  local_4c = 0;
  local_50 = 0;
  local_54 = 0;
  uVar8 = (**(code **)(*local_68 + 0x58))();
  cVar1 = FUN_14046c8a0(uVar8,param_3,&local_50);
  if (cVar1 == '\0') {
    uVar8 = (**(code **)(*local_68 + 0x58))();
    cVar1 = FUN_14046c750(uVar8,param_3,&local_58,&local_4c);
    if (cVar1 == '\0') {
      uVar8 = (**(code **)(*local_68 + 0x58))();
      cVar1 = FUN_14046c9d0(uVar8,param_3,&local_54);
      if (cVar1 == '\0') {
        uVar8 = (**(code **)(*local_68 + 0x58))();
        cVar1 = FUN_14046c650(uVar8,param_3);
        if (cVar1 == '\0') {
          if (bVar16) {
            return;
          }
          plVar10 = (longlong *)
                    (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))(*(longlong **)(lVar9 + 8),0xc);
          uVar2 = (**(code **)(*plVar10 + 0x48))(plVar10);
          plVar10 = (longlong *)FUN_140087ed0();
          lVar9 = *plVar10;
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          uVar3 = (**(code **)(lVar9 + 0xf8))(plVar10,uVar3);
          uVar6 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
          uVar8 = (**(code **)(*local_68 + 0x58))();
          iVar4 = FUN_14046a590(uVar8,uVar2,uVar6,uVar3);
          lVar9 = (**(code **)(*param_1 + 0x60))(param_1);
          if (lVar9 < iVar4 * param_5) {
LAB_14034267a:
            pIVar11 = theInstance();
            pcVar14 = "STR_NOT_SO_MUCH_MONEY";
            goto LAB_140341ded;
          }
          iVar15 = FUN_140339ba0(param_1,param_3,param_5,0);
          if ((iVar15 < 1) ||
             ((ulonglong)((param_1[0x185] - param_1[0x184] >> 2) + (longlong)iVar15) < 0x29)) {
            plVar10 = (longlong *)FUN_140087d40();
            lVar9 = *plVar10;
            uVar2 = FUN_140340e50(param_1,param_3,0,1);
            (**(code **)(lVar9 + 0x60))(plVar10,uVar2);
            cVar1 = (**(code **)(*param_1 + 0x178))(param_1,(longlong)(iVar4 * param_5),1);
            if (cVar1 == '\0') {
              log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT",
                                 "SpendMoney(nPrice * nCount, SYNCHRO_TRUE)",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                                );
            }
            FUN_1401642f0(param_1);
            return;
          }
        }
        else {
          if ((param_4 != 1) && (param_4 != 2)) {
            pcVar14 = "ucMoneytype == 1 || ucMoneytype == 2";
            goto LAB_140341e69;
          }
          plVar10 = (longlong *)
                    (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))(*(longlong **)(lVar9 + 8),0x25)
          ;
          iVar4 = (**(code **)(*plVar10 + 0x48))(plVar10);
          if (iVar4 < 0) {
            return;
          }
          plVar10 = (longlong *)
                    (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))(*(longlong **)(lVar9 + 8),0x25)
          ;
          iVar4 = (**(code **)(*plVar10 + 0x48))(plVar10);
          if (iVar4 < 1) {
            return;
          }
          local_res8 = 0;
          local_60 = iVar4;
          if (param_5 < 1) {
            log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","nCount >= 1",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                              );
          }
          local_44 = (uint)(param_4 == 2);
          iVar15 = FUN_140339ba0(param_1,param_3,param_5,param_4 == 2);
          if ((iVar15 < 1) ||
             ((ulonglong)((param_1[0x185] - param_1[0x184] >> 2) + (longlong)iVar15) < 0x29)) {
            if (*(char *)((longlong)param_1 + 0x51c) == '\0') {
              return;
            }
            if (param_4 == 1) {
              bVar16 = SBORROW4(*(int *)((longlong)param_1 + 0xfa4),iVar4 * param_5);
              iVar15 = *(int *)((longlong)param_1 + 0xfa4) - iVar4 * param_5;
            }
            else {
              if (param_4 != 2) {
                uVar8 = 0xd0f;
                goto LAB_140342cd4;
              }
              plVar10 = (longlong *)
                        (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))
                                  (*(longlong **)(lVar9 + 8),0x26);
              local_res8 = (**(code **)(*plVar10 + 0x48))(plVar10);
              if (local_res8 < 1) {
                return;
              }
              iVar15 = FUN_140371860(param_1 + 0x1cf);
              bVar16 = SBORROW4(iVar15,local_res8 * param_5);
              iVar15 = iVar15 - local_res8 * param_5;
            }
            if (bVar16 == iVar15 < 0) {
              iVar15 = 0;
              local_5c = 0;
              cVar1 = FUN_140102780(param_3);
              if (cVar1 == '\0') {
                local_48 = 0;
                if (param_5 < 1) {
                  return;
                }
                do {
                  if (param_4 == 1) {
                    bVar16 = SBORROW4(*(int *)((longlong)param_1 + 0xfa4),iVar4);
                    iVar7 = *(int *)((longlong)param_1 + 0xfa4) - iVar4;
                  }
                  else {
                    if (param_4 != 2) {
                      uVar8 = 0xd29;
                      goto LAB_140342cd4;
                    }
                    iVar7 = FUN_140371860(param_1 + 0x1cf);
                    bVar16 = SBORROW4(iVar7,local_res8);
                    iVar7 = iVar7 - local_res8;
                  }
                  if (bVar16 != iVar7 < 0) break;
                  plVar10 = (longlong *)FUN_140087d40();
                  lVar9 = *plVar10;
                  uVar2 = FUN_140340e50(param_1,param_3,local_44 & 0xffff,1);
                  lVar9 = (**(code **)(lVar9 + 0x60))(plVar10,uVar2);
                  local_38 = lVar9;
                  iVar15 = local_5c;
                  if (lVar9 != 0) {
                    if (param_4 == 1) {
                      cVar1 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,(longlong)-iVar4,1)
                      ;
                      if (cVar1 == '\0') {
                        pcVar14 = "AddAttrib(_USERATTRIB_EMONEY, -nPrice, SYNCHRO_TRUE)";
                        goto LAB_140341e69;
                      }
                      FUN_1401642f0(param_1);
                      uVar2 = (**(code **)(*param_1 + 8))(param_1);
                      FUN_1401742b0(param_1,10,uVar2);
                      uVar5 = FUN_1400fda10(lVar9,0x6e,1);
                      if ((uVar5 >> 6 & 1) == 0) {
                        uVar8 = FUN_140008520((int)param_1[0x246]);
                        uVar8 = FUN_14001b600(uVar8);
                        FUN_1400d2660(uVar8,param_1,4,iVar4);
                      }
                      (**(code **)(*local_68 + 8))();
                      uVar8 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                      uVar13 = (**(code **)(*param_1 + 8))(param_1);
                      uVar13 = uVar13 & 0xffffffff;
                      if (param_6 == '\0') {
                        pcVar14 = "gmlog/emoney_buy";
                      }
                      else {
                        pcVar14 = "gmlog/shopping_guide";
                      }
                    }
                    else {
                      if (param_4 != 2) {
                        uVar8 = 0xd68;
                        goto LAB_140342cd4;
                      }
                      cVar1 = (**(code **)(param_1[2] + 0x2e0))
                                        (param_1 + 2,0x2d,(longlong)-local_res8,1);
                      if (cVar1 == '\0') {
                        pcVar14 = "AddAttrib(_USERATTRIB_EMONEY_MONO, -nPriceMono, SYNCHRO_TRUE)";
                        goto LAB_140341e69;
                      }
                      FUN_1401642f0(param_1);
                      uVar2 = (**(code **)(*param_1 + 8))(param_1);
                      FUN_140174470(param_1,10,uVar2);
                      (**(code **)(*local_68 + 8))();
                      uVar8 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                      uVar13 = (**(code **)(*param_1 + 8))(param_1);
                      uVar13 = uVar13 & 0xffffffff;
                      pcVar14 = "gmlog/shopping_guide_mono";
                      if (param_6 == '\0') {
                        pcVar14 = "gmlog/emoney_mono_buy";
                      }
                    }
                    tq::MyLogSave(pcVar14,"%u\t%s\t%u\t%u\t%u\t%u\t%u\t%d\t",uVar13,uVar8);
                    lVar9 = local_38;
                    iVar15 = local_5c + 1;
                    local_5c = iVar15;
                    uVar2 = FUN_1400fda10(local_38,1,1);
                    iVar4 = FUN_1400ff680(uVar2);
                    if ((iVar4 == 0xb) ||
                       (cVar1 = FUN_14032ef10(lVar9), iVar4 = local_60, cVar1 != '\0')) {
                      pIVar11 = theInstance();
                      lVar9 = param_1[2];
                      uVar8 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_BUY_COAT_OK");
                      (**(code **)(lVar9 + 0x358))(param_1 + 2,uVar8);
                      iVar4 = local_60;
                    }
                  }
                  local_48 = local_48 + 1;
                } while (local_48 < param_5);
              }
              else {
                FUN_140340e50(param_1,param_3,local_44 & 0xffff,1);
                if (param_4 == 1) {
                  cVar1 = (**(code **)(param_1[2] + 0x2e0))
                                    (param_1 + 2,0x1d,(longlong)-(iVar4 * param_5),1);
                  if (cVar1 == '\0') {
                    pcVar14 = "AddAttrib(_USERATTRIB_EMONEY, -nTotalPrice, SYNCHRO_TRUE)";
                    goto LAB_140341e69;
                  }
                  FUN_1401642f0(param_1);
                  uVar2 = (**(code **)(*param_1 + 8))(param_1);
                  FUN_1401742b0(param_1,10,uVar2);
                  cVar1 = FUN_140100d90(param_3);
                  if (cVar1 == '\0') {
                    uVar8 = FUN_140008520((int)param_1[0x246]);
                    uVar8 = FUN_14001b600(uVar8);
                    FUN_1400d2660(uVar8,param_1,4,iVar4 * param_5);
                  }
                  (**(code **)(*local_68 + 8))();
                  if (param_6 == '\0') {
                    uVar8 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                    uVar13 = (**(code **)(*param_1 + 8))(param_1);
                    pcVar14 = "gmlog/emoney_buy";
                    uVar13 = uVar13 & 0xffffffff;
                  }
                  else {
                    uVar8 = (**(code **)(param_1[2] + 0x18))();
                    uVar13 = (**(code **)(*param_1 + 8))(param_1);
                    pcVar14 = "gmlog/shopping_guide";
                    uVar13 = uVar13 & 0xffffffff;
                  }
                }
                else {
                  if (param_4 != 2) {
                    uVar8 = 0xdb1;
LAB_140342cd4:
                    log_InlineLogERROR("Invalid moneytype:%d at %s, %d",(ulonglong)param_4,
                                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                                       ,uVar8);
                    return;
                  }
                  cVar1 = (**(code **)(param_1[2] + 0x2e0))
                                    (param_1 + 2,0x2d,(longlong)-(local_res8 * param_5),1);
                  if (cVar1 == '\0') {
                    pcVar14 = "AddAttrib(_USERATTRIB_EMONEY_MONO, -nTotalPrice, SYNCHRO_TRUE)";
                    goto LAB_140341e69;
                  }
                  FUN_1401642f0(param_1);
                  uVar2 = (**(code **)(*param_1 + 8))(param_1);
                  FUN_140174470(param_1,10,uVar2);
                  (**(code **)(*local_68 + 8))();
                  if (param_6 == '\0') {
                    uVar8 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                    uVar13 = (**(code **)(*param_1 + 8))(param_1);
                    pcVar14 = "gmlog/emoney_mono_buy";
                  }
                  else {
                    uVar8 = (**(code **)(param_1[2] + 0x18))();
                    uVar13 = (**(code **)(*param_1 + 8))(param_1);
                    pcVar14 = "gmlog/shopping_guide_mono";
                  }
                  uVar13 = uVar13 & 0xffffffff;
                }
                tq::MyLogSave(pcVar14,"%u\t%s\t%u\t%u\t%u\t%u\t%u\t%d\t",uVar13,uVar8);
                local_5c = param_5;
                iVar15 = param_5;
              }
              if (iVar15 < 1) {
                return;
              }
              pIVar11 = theInstance();
              plVar10 = (longlong *)
                        (**(code **)(**(longlong **)(local_40 + 8) + 0x10))
                                  (*(longlong **)(local_40 + 8),1);
              uVar12 = (**(code **)(*plVar10 + 0x78))(plVar10);
              lVar9 = param_1[2];
              uVar8 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_BUY_ITEM");
              param_5 = local_5c;
              goto LAB_140342402;
            }
            goto LAB_14034267a;
          }
        }
      }
      else {
        if (param_5 < 1) goto LAB_140341e62;
        if (param_1[0x25d] == 0) {
          pcVar14 = "m_pGoldLeaguePoint";
          goto LAB_140341e69;
        }
        if (local_54 < 1) {
          log_InlineLogERROR("nGoldenLeaguePrice price invalid! itemtype:%u");
          return;
        }
        iVar4 = FUN_140339ba0(param_1,param_3,param_5,0);
        if ((iVar4 < 1) ||
           ((ulonglong)((param_1[0x185] - param_1[0x184] >> 2) + (longlong)iVar4) < 0x29)) {
          uVar5 = FUN_140168d50(param_1);
          if ((uint)(local_54 * param_5) <= uVar5) {
            cVar1 = FUN_140168d70(param_1,uVar5 - local_54 * param_5);
            if (cVar1 != '\0') {
              FUN_140168ce0(param_1);
              plVar10 = (longlong *)FUN_140087d40();
              lVar9 = *plVar10;
              uVar2 = FUN_140340e50(param_1,param_3,1,1);
              (**(code **)(lVar9 + 0x60))(plVar10,uVar2);
              tq::MyLogSave("gmlog/point_buy","%u\t%u\t%lu\t%u\t%u\t%u\t%u\t%d\t",0,0);
              lVar9 = local_40;
            }
            pIVar11 = theInstance();
            plVar10 = (longlong *)
                      (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))(*(longlong **)(lVar9 + 8),1);
            uVar12 = (**(code **)(*plVar10 + 0x78))(plVar10);
            lVar9 = param_1[2];
            uVar8 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_BUY_ITEM");
            goto LAB_140342402;
          }
          pIVar11 = theInstance();
          pcVar14 = "STR_GOLDEN_LEAGUE_POINT_NOT_ENOUTH";
          goto LAB_140341ded;
        }
      }
    }
    else {
      plVar10 = (longlong *)CurrentInstanceGet();
      if (plVar10 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pRoot",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                          );
        return;
      }
      plVar10 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,4);
      if (plVar10 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pArenicProvider",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                          );
        return;
      }
      lVar9 = *plVar10;
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      uVar5 = (**(code **)(lVar9 + 0x20))(plVar10,uVar2);
      if ((0 < (int)local_4c) && ((uVar5 == 0 || (local_4c < uVar5)))) {
        pIVar11 = theInstance();
        pcVar14 = "STR_LESS_ATHLETE_RANK";
        goto LAB_140341ded;
      }
      iVar4 = FUN_140339ba0(param_1,param_3,param_5,1);
      if ((iVar4 < 1) ||
         ((ulonglong)((param_1[0x185] - param_1[0x184] >> 2) + (longlong)iVar4) < 0x29)) {
        uVar5 = FUN_1403737d0(param_1 + 0x1cf);
        if (uVar5 < local_58) {
          pIVar11 = theInstance();
          pcVar14 = "STR_HONOR_NOT_ENOUTH";
        }
        else {
          lVar9 = *plVar10;
          iVar4 = FUN_1403737d0(param_1 + 0x1cf);
          iVar4 = iVar4 - local_58;
          uVar2 = (**(code **)(*param_1 + 8))(param_1);
          (**(code **)(lVar9 + 0xe8))(plVar10,uVar2,iVar4);
          iVar4 = FUN_1403737d0(param_1 + 0x1cf);
          FUN_140177500(param_1,iVar4 - local_58,1);
          lVar9 = *plVar10;
          uVar2 = (**(code **)(*param_1 + 8))(param_1);
          (**(code **)(lVar9 + 0x78))(plVar10,uVar2);
          plVar10 = (longlong *)CurrentInstanceGet();
          plVar10 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,0x22);
          if (plVar10 != (longlong *)0x0) {
            lVar9 = *plVar10;
            uVar2 = (**(code **)(*param_1 + 8))(param_1);
            (**(code **)(lVar9 + 0x98))(plVar10,uVar2);
          }
          plVar10 = (longlong *)FUN_140087d40();
          lVar9 = *plVar10;
          uVar2 = FUN_140340e50(param_1,param_3,1,1);
          lVar9 = (**(code **)(lVar9 + 0x60))(plVar10,uVar2);
          if (lVar9 != 0) {
            FUN_1401642f0(param_1);
            plVar10 = (longlong *)FUN_140087d40();
            (**(code **)(*plVar10 + 0x130))(plVar10,param_1,lVar9,3);
            tq::MyLogSave("gmlog/point_buy","%u\t%u\t%lu\t%u\t%u\t%u\t%u\t%d\t",0,0);
            return;
          }
          pIVar11 = theInstance();
          pcVar14 = "STR_YOUR_BAG_FULL";
        }
        goto LAB_140341ded;
      }
    }
  }
  else {
    if (param_5 < 1) {
LAB_140341e62:
      pcVar14 = "nCount > 0";
LAB_140341e69:
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK",pcVar14,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                        );
      return;
    }
    if (local_50 < 1) {
      log_InlineLogERROR("Riding price invalid! itemtype:%u");
      return;
    }
    iVar4 = FUN_140339ba0(param_1,param_3,param_5,0);
    if ((iVar4 < 1) ||
       ((ulonglong)((param_1[0x185] - param_1[0x184] >> 2) + (longlong)iVar4) < 0x29)) {
      iVar15 = local_50 * param_5;
      iVar4 = (**(code **)(*param_1 + 0x70))(param_1);
      if (iVar4 < iVar15) {
        pIVar11 = theInstance();
        pcVar14 = "STR_RIDING_POINT_NOT_ENOUTH";
        goto LAB_140341ded;
      }
      cVar1 = FUN_140162b60(param_1,-iVar15);
      if (cVar1 != '\0') {
        plVar10 = (longlong *)FUN_140087d40();
        lVar9 = *plVar10;
        uVar2 = FUN_140340e50(param_1,param_3,0,1);
        (**(code **)(lVar9 + 0x60))(plVar10,uVar2);
        tq::MyLogSave("gmlog/point_buy","%u\t%u\t%lu\t%u\t%u\t%u\t%u\t%d\t",0,0);
        lVar9 = local_40;
      }
      pIVar11 = theInstance();
      plVar10 = (longlong *)
                (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))(*(longlong **)(lVar9 + 8),1);
      uVar12 = (**(code **)(*plVar10 + 0x78))(plVar10);
      lVar9 = param_1[2];
      uVar8 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_BUY_ITEM");
LAB_140342402:
      (**(code **)(lVar9 + 0x358))(param_1 + 2,uVar8,param_5,uVar12);
      return;
    }
  }
  pIVar11 = theInstance();
  pcVar14 = "STR_FULLBAG_NO_MORE";
LAB_140341ded:
  lVar9 = param_1[2];
  uVar8 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,pcVar14);
  (**(code **)(lVar9 + 0x358))(param_1 + 2,uVar8);
  return;
}

// ==== CMsgItem::helper_140342d10  @140342d10  [medium:callgraph-r0]  (orig: FUN_140342d10)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140342d10(longlong *param_1,undefined4 param_2,undefined4 param_3,byte param_4,
                  longlong param_5,int param_6)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong lVar9;
  IStringManager *pIVar10;
  longlong lVar11;
  ulonglong uVar12;
  longlong lVar13;
  bool bVar14;
  longlong *local_30;
  
  if (param_5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pidItem",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                      );
    return;
  }
  if ((param_4 != 1) && (param_4 != 2)) {
    return;
  }
  if (3 < param_6 - 1U && param_6 != 5) {
    return;
  }
  if ((param_4 == 1) && (*(char *)((longlong)param_1 + 0x51c) == '\0')) {
    return;
  }
  local_30 = (longlong *)0x0;
  uVar7 = FUN_140008520((int)param_1[0x246]);
  plVar8 = (longlong *)FUN_1400875f0(uVar7);
  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,param_2);
  if (plVar8 == (longlong *)0x0) {
    return;
  }
  (**(code **)(*plVar8 + 0x298))(plVar8,0x1040,&local_30);
  if (local_30 == (longlong *)0x0) {
    return;
  }
  cVar2 = (**(code **)(*local_30 + 0x50))();
  if ((cVar2 == '\0') &&
     (iVar3 = (**(code **)(*(longlong *)local_30[0xc] + 0x10))((longlong *)local_30[0xc],4),
     iVar3 != 0x20)) {
    return;
  }
  lVar9 = (**(code **)(*local_30 + 0x58))();
  if (lVar9 == 0) {
    return;
  }
  uVar7 = (**(code **)(*local_30 + 0x58))();
  cVar2 = FUN_14046add0(uVar7);
  if (cVar2 == '\0') {
    return;
  }
  lVar9 = (**(code **)(*local_30 + 0x58))();
  lVar9 = (**(code **)(**(longlong **)(lVar9 + 8) + 0x30))(*(longlong **)(lVar9 + 8),param_3);
  if (lVar9 == 0) {
    pIVar10 = theInstance();
    lVar9 = param_1[2];
    uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_GOOD_NOT_EXISTS");
    (**(code **)(lVar9 + 0x358))(param_1 + 2,uVar7);
    return;
  }
  iVar3 = 0;
  lVar13 = 0;
  if (0 < (longlong)param_6) {
    do {
      uVar5 = *(undefined4 *)(param_5 + lVar13 * 4);
      cVar2 = FUN_140332fe0(param_1,uVar5);
      if (cVar2 == '\0') {
        return;
      }
      plVar8 = (longlong *)FUN_140087d40();
      lVar11 = (**(code **)(*plVar8 + 0x60))(plVar8,uVar5);
      if (lVar11 == 0) {
        return;
      }
      cVar2 = FUN_1400ffc20(lVar11);
      if (cVar2 != '\0') {
        return;
      }
      plVar8 = (longlong *)FUN_140087d40();
      iVar4 = (**(code **)(*plVar8 + 0x148))(plVar8,lVar11);
      if (iVar4 != 0) {
        return;
      }
      cVar2 = FUN_1400ffbe0(lVar11);
      if (cVar2 != '\0') {
        return;
      }
      cVar2 = FUN_1400ff650(lVar11,2);
      if (cVar2 != '\0') {
        return;
      }
      cVar2 = FUN_1400ff650(lVar11,1);
      if (cVar2 != '\0') {
        return;
      }
      plVar8 = (longlong *)FUN_14032b280();
      lVar1 = *plVar8;
      uVar5 = FUN_1400fda10(lVar11,1,1);
      plVar8 = (longlong *)(**(code **)(lVar1 + 0x38))(plVar8,uVar5);
      if (plVar8 == (longlong *)0x0) {
        return;
      }
      iVar4 = (**(code **)(*plVar8 + 0x10))(plVar8,1);
      lVar13 = lVar13 + 1;
      iVar3 = iVar3 + iVar4;
    } while (lVar13 < param_6);
  }
  plVar8 = (longlong *)
           (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))(*(longlong **)(lVar9 + 8),0x25);
  iVar6 = (**(code **)(*plVar8 + 0x48))();
  iVar4 = 0;
  if (0 < iVar6 - iVar3) {
    iVar4 = iVar6 - iVar3;
  }
  if (param_4 == 1) {
    bVar14 = SBORROW4(*(int *)((longlong)param_1 + 0xfa4),iVar4);
    iVar3 = *(int *)((longlong)param_1 + 0xfa4) - iVar4;
LAB_140343033:
    if (bVar14 != iVar3 < 0) {
      pIVar10 = theInstance();
      lVar9 = param_1[2];
      uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_NOT_SO_MUCH_EMONEY");
      (**(code **)(lVar9 + 0x358))(param_1 + 2,uVar7);
      return;
    }
    lVar9 = 0;
    if (0 < (longlong)param_6) {
      do {
        uVar5 = *(undefined4 *)(param_5 + lVar9 * 4);
        plVar8 = (longlong *)FUN_140087d40();
        lVar13 = (**(code **)(*plVar8 + 0x60))(plVar8,uVar5);
        if (lVar13 == 0) {
          return;
        }
        FUN_1400fda10(lVar13,1,1);
        cVar2 = FUN_14033a6a0(param_1,uVar5,1,0);
        if (cVar2 == '\0') {
          return;
        }
        (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar12 = (**(code **)(*param_1 + 8))(param_1);
        tq::MyLogSave("gmlog/emoney_exchange_buy","exchange item %u\t%s\t%u\t%u\t%u\t",
                      uVar12 & 0xffffffff);
        lVar9 = lVar9 + 1;
      } while (lVar9 < param_6);
    }
    plVar8 = (longlong *)FUN_140087d40();
    lVar9 = *plVar8;
    uVar5 = FUN_140340e50(param_1,param_3,param_4 == 2,1);
    lVar9 = (**(code **)(lVar9 + 0x60))(plVar8,uVar5);
    if (lVar9 == 0) {
      return;
    }
    if (param_4 == 1) {
      plVar8 = param_1 + 2;
      cVar2 = (**(code **)(param_1[2] + 0x2e0))(plVar8,0x1d,(longlong)-iVar4,1);
      if (cVar2 == '\0') {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECK",
                           "AddAttrib(_USERATTRIB_EMONEY, -nNeedEmoney, SYNCHRO_TRUE)",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                          );
        return;
      }
      FUN_1401642f0(param_1);
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      FUN_1401742b0(param_1,0x21,uVar5);
      (**(code **)(*local_30 + 8))();
      uVar7 = (**(code **)(*plVar8 + 0x18))(plVar8);
      uVar12 = (**(code **)(*param_1 + 8))(param_1);
      tq::MyLogSave("gmlog/emoney_exchange_buy","%u\t%s\t%u\t%u\t%u\t%u\t",uVar12 & 0xffffffff,uVar7
                   );
      plVar8 = (longlong *)FUN_140087d40();
      (**(code **)(*plVar8 + 0x130))(plVar8,param_1,lVar9,3);
    }
    else {
      if (param_4 != 2) {
        uVar7 = 0xe82;
        goto LAB_1403433d8;
      }
      plVar8 = param_1 + 2;
      cVar2 = (**(code **)(param_1[2] + 0x2e0))(plVar8,0x2d,(longlong)-iVar4,1);
      if (cVar2 == '\0') {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECK",
                           "AddAttrib(_USERATTRIB_EMONEY_MONO, -nNeedEmoney, SYNCHRO_TRUE)",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                          );
        return;
      }
      FUN_1401642f0(param_1);
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      FUN_140174470(param_1,0x21,uVar5);
      (**(code **)(*local_30 + 8))();
      uVar7 = (**(code **)(*plVar8 + 0x18))(plVar8);
      uVar12 = (**(code **)(*param_1 + 8))(param_1);
      tq::MyLogSave("gmlog/emoneyMono_exchange_buy","%u\t%s\t%u\t%u\t%u\t%u\t",uVar12 & 0xffffffff,
                    uVar7);
      plVar8 = (longlong *)FUN_140087d40();
      (**(code **)(*plVar8 + 0x130))(plVar8,param_1,lVar9,3);
    }
    pIVar10 = theInstance();
    lVar9 = param_1[2];
    uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_EXCHANGE_BUY_OK");
    (**(code **)(lVar9 + 0x358))(param_1 + 2,uVar7);
  }
  else {
    if (param_4 == 2) {
      plVar8 = (longlong *)
               (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))(*(longlong **)(lVar9 + 8),0x26);
      iVar6 = (**(code **)(*plVar8 + 0x48))(plVar8);
      iVar4 = 0;
      if (0 < iVar6 - iVar3) {
        iVar4 = iVar6 - iVar3;
      }
      iVar3 = FUN_140371860(param_1 + 0x1cf);
      bVar14 = SBORROW4(iVar3,iVar4);
      iVar3 = iVar3 - iVar4;
      goto LAB_140343033;
    }
    uVar7 = 0xe43;
LAB_1403433d8:
    log_InlineLogERROR("Invalid moneytype:%d at %s, %d",(ulonglong)param_4,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                       ,uVar7);
  }
  return;
}

// ==== CMsgItem::helper_140343420  @140343420  [medium:callgraph-r0]  (orig: FUN_140343420)
undefined8 FUN_140343420(longlong param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  
  if ((ulonglong)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) < 0x28) {
    cVar1 = FUN_140332fe0();
    if (cVar1 != '\0') {
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = (longlong *)0x0;
      }
      lVar4 = (**(code **)(*plVar5 + 0x60))(plVar5,param_2);
      if (lVar4 != 0) {
        cVar1 = FUN_140103d80(lVar4);
        if (cVar1 != '\0') {
          iVar2 = FUN_1400fda10(lVar4,4,1);
          if (param_3 < iVar2) {
            plVar5 = (longlong *)FUN_140108390(lVar4,param_3);
            if (plVar5 != (longlong *)0x0) {
              uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
              FUN_140340de0(param_1,uVar3,0,1);
              return 1;
            }
            log_InlineLogERROR(&DAT_1406d9c10);
          }
        }
      }
    }
  }
  return 0;
}

// ==== CMsgItem::helper_140347de0  @140347de0  [medium:callgraph-r0]  (orig: FUN_140347de0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined1 * FUN_140347de0(longlong *param_1,int param_2,undefined4 *param_3,int param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 uVar8;
  ulonglong uVar9;
  uint uVar10;
  longlong lVar11;
  int *piVar12;
  int iVar13;
  int local_b8;
  undefined1 local_a8 [112];
  
  if (((param_2 == 0) || (param_3 == (undefined4 *)0x0)) || (param_4 < 1)) {
    return &stack0x00000000;
  }
  cVar1 = FUN_140332fe0();
  if (cVar1 != '\0') {
    plVar6 = (longlong *)FUN_140087d40();
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x60))(plVar6,param_2);
    if (plVar6 != (longlong *)0x0) goto LAB_140347f0a;
  }
  plVar6 = (longlong *)FUN_140087d40();
  lVar11 = *plVar6;
  uVar2 = FUN_14032b4b0(param_1,10);
  plVar6 = (longlong *)(**(code **)(lVar11 + 0x60))(plVar6,uVar2);
  if ((plVar6 == (longlong *)0x0) || (iVar3 = (**(code **)(*plVar6 + 8))(plVar6), iVar3 != param_2))
  {
    plVar6 = (longlong *)FUN_140087d40();
    lVar11 = *plVar6;
    uVar2 = FUN_14032b4b0(param_1,0xb);
    plVar6 = (longlong *)(**(code **)(lVar11 + 0x60))(plVar6,uVar2);
    if ((plVar6 == (longlong *)0x0) ||
       (iVar3 = (**(code **)(*plVar6 + 8))(plVar6), iVar3 != param_2)) {
      plVar6 = (longlong *)FUN_140087d40();
      lVar11 = *plVar6;
      uVar2 = FUN_14032b4b0(param_1,0x13);
      plVar6 = (longlong *)(**(code **)(lVar11 + 0x60))(plVar6,uVar2);
      if (plVar6 == (longlong *)0x0) {
        return (undefined1 *)0x0;
      }
      iVar3 = (**(code **)(*plVar6 + 8))(plVar6);
      if (iVar3 != param_2) {
        return (undefined1 *)0x0;
      }
    }
  }
LAB_140347f0a:
  uVar2 = FUN_1400fda10(plVar6,1,1);
  iVar3 = FUN_1400ff680(uVar2);
  if ((iVar3 != 0x15) && (plVar6 != (longlong *)0x0)) {
    uVar2 = FUN_1400fda10(plVar6,1,1);
    iVar3 = FUN_1400ff680(uVar2);
    if (iVar3 != 0xc) {
      uVar2 = FUN_1400fda10(plVar6,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 != 0xd) {
        uVar2 = FUN_1400fda10(plVar6,1,1);
        iVar3 = FUN_1400ff680(uVar2);
        if (iVar3 != 0x16) {
          return (undefined1 *)0x0;
        }
      }
    }
    iVar3 = FUN_1400fda10(plVar6,9,1);
    if (iVar3 == 0) {
      lVar11 = 0;
      if (0 < param_4) {
        do {
          cVar1 = FUN_140332fe0(param_1,param_3[lVar11]);
          if (cVar1 == '\0') {
            return (undefined1 *)0x0;
          }
          plVar7 = (longlong *)FUN_140087d40();
          plVar7 = (longlong *)(**(code **)(*plVar7 + 0x60))(plVar7,param_3[lVar11]);
          if (plVar7 == (longlong *)0x0) {
            return (undefined1 *)0x0;
          }
          iVar3 = FUN_1401011d0(plVar7);
          if (iVar3 < 6) {
            return (undefined1 *)0x0;
          }
          cVar1 = FUN_1400ffbe0(plVar7);
          if ((cVar1 != '\0') && (cVar1 = FUN_1400ffbe0(plVar6), cVar1 == '\0')) {
            return (undefined1 *)0x0;
          }
          cVar1 = FUN_1400ffc20(plVar7);
          if (cVar1 != '\0') {
            return (undefined1 *)0x0;
          }
          cVar1 = FUN_1400ff650(plVar7,2);
          if (cVar1 != '\0') {
            return (undefined1 *)0x0;
          }
          cVar1 = FUN_1400ff650(plVar7,1);
          if (cVar1 != '\0') {
            return (undefined1 *)0x0;
          }
          uVar2 = (**(code **)(*plVar7 + 8))(plVar7);
          cVar1 = FUN_1403380a0(param_1,uVar2);
          if (cVar1 != '\0') {
            return (undefined1 *)0x0;
          }
          uVar10 = 0;
          piVar12 = &DAT_140754b90;
          while (iVar3 = FUN_1400fed80(plVar7), iVar3 != *piVar12) {
            uVar10 = uVar10 + 1;
            piVar12 = piVar12 + 1;
            if (0x3a < uVar10) {
              return (undefined1 *)0x0;
            }
          }
          iVar3 = FUN_140105ae0(plVar7);
          if (iVar3 < 1) {
            return (undefined1 *)0x0;
          }
          lVar11 = lVar11 + 1;
        } while (lVar11 < param_4);
      }
      iVar13 = 0;
      iVar3 = FUN_1400fda10(plVar6,8,1);
      iVar4 = FUN_1400fda10(plVar6,0xd,1);
      local_b8 = 0;
      if (0 < param_4) {
        do {
          plVar7 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                              );
            plVar7 = (longlong *)0x0;
          }
          lVar11 = (**(code **)(*plVar7 + 0x60))(plVar7,*param_3);
          if (lVar11 == 0) {
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pItemAcc",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                              );
            return (undefined1 *)0x0;
          }
          FUN_140101cb0(lVar11,local_a8);
          iVar5 = FUN_140105ae0(lVar11);
          iVar13 = iVar13 + iVar5;
          cVar1 = FUN_140340190(param_1,*param_3,1,1);
          if (cVar1 == '\0') {
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","ExpendMultiItem(idItems[i], 1, true)",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                              );
            return (undefined1 *)0x0;
          }
          FUN_1400fda10(plVar6,1,1);
          (**(code **)(*plVar6 + 8))(plVar6);
          uVar8 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
          uVar9 = (**(code **)(*param_1 + 8))(param_1);
          tq::MyLogSave("gmlog/treasure",
                        "user id: %u, name: %s, account id: %u, [%u(%u)(addition_level=%d)(gem1=%d)(gem2=%d)(redue_dmg=%u)(add_life=%u) Score[%d]] is composed to the [%u(%u) Score[%d]] as a minor item.Index[%d]"
                        ,uVar9 & 0xffffffff,uVar8);
          if (iVar3 == 0) {
            if (7999 < iVar13 + iVar4) break;
          }
          else if (19999 < iVar13 + iVar4) break;
          param_3 = param_3 + 1;
          local_b8 = local_b8 + 1;
        } while (local_b8 < param_4);
      }
      iVar13 = iVar13 + iVar4;
      iVar3 = FUN_1400fda10(plVar6,8,1);
      if (iVar3 == 0) {
        if (iVar13 < 8000) {
          FUN_140104140(plVar6,0xd,iVar13,1);
        }
        else {
          FUN_140104140(plVar6,8,0xff,1);
          if (0 < iVar4) {
            FUN_140104140(plVar6,0xd,0,1);
          }
          FUN_140170e90(param_1,0x28b9);
        }
      }
      else if (iVar13 < 20000) {
        FUN_140104140(plVar6,0xd,iVar13,1);
      }
      else {
        FUN_140104140(plVar6,9,0xff,1);
        if (0 < iVar4) {
          FUN_140104140(plVar6,0xd,0,1);
        }
        FUN_140170e90(param_1,0x28ba);
      }
      FUN_1400fda10(plVar6,0xd,1);
      FUN_1400fda10(plVar6,1,1);
      (**(code **)(*plVar6 + 8))(plVar6);
      uVar8 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      uVar9 = (**(code **)(*param_1 + 8))(param_1);
      tq::MyLogSave("gmlog/treasure",
                    "user id: %u, name: %s, account id: %u, the [%u(%u) data[%u]] compose score[%d] success."
                    ,uVar9 & 0xffffffff,uVar8);
      FUN_140194390(param_1);
      plVar7 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        plVar7 = (longlong *)0x0;
      }
      (**(code **)(*plVar7 + 0x130))(plVar7,param_1,plVar6,3);
      lVar11 = FUN_140008520((int)param_1[0x246]);
      lVar11 = *(longlong *)(lVar11 + 0x1f8);
      if (lVar11 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pActivityMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        lVar11 = 0;
      }
      FUN_140261810(lVar11,param_1,0xd);
      return (undefined1 *)0x1;
    }
  }
  return (undefined1 *)0x0;
}

// ==== CMsgItem::helper_140348ec0  @140348ec0  [medium:callgraph-r0]  (orig: FUN_140348ec0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140348ec0(longlong *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  int iVar9;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined4 local_4a0;
  int local_498;
  int local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  cVar1 = FUN_140332fe0();
  if ((cVar1 != '\0') || (cVar1 = FUN_140333220(param_1,param_2), cVar1 != '\0')) {
    plVar7 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_4a8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar7 = (longlong *)0x0;
    }
    lVar5 = (**(code **)(*plVar7 + 0x60))(plVar7,param_2);
    if (lVar5 != 0) {
      uVar2 = FUN_1400fda10(lVar5,1,1);
      cVar1 = FUN_1400ff940(uVar2);
      if (cVar1 == '\0') {
        (**(code **)(param_1[2] + 0x358))(param_1 + 2,"target item is not equipment.");
        return 0;
      }
      uVar2 = FUN_1400fda10(lVar5,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 != 0xc) {
        uVar2 = FUN_1400fda10(lVar5,1,1);
        iVar3 = FUN_1400ff680(uVar2);
        if (iVar3 != 0xd) {
          uVar2 = FUN_1400fda10(lVar5,1,1);
          iVar3 = FUN_1400ff680(uVar2);
          if (iVar3 != 0x15) {
            uVar2 = FUN_1400fda10(lVar5,1,1);
            iVar3 = FUN_1400ff680(uVar2);
            if (iVar3 != 0x16) {
              uVar2 = FUN_1400fda10(lVar5,1,1);
              iVar3 = FUN_1400ff680(uVar2);
              if (iVar3 == 0xe) {
                return 0;
              }
              cVar1 = FUN_14032ef10(lVar5);
              if (cVar1 != '\0') {
                return 0;
              }
              uVar6 = FUN_140008520((int)param_1[0x246]);
              cVar1 = FUN_14008abf0(uVar6);
              if ((cVar1 != '\0') && (cVar1 = FUN_140103310(lVar5), cVar1 != '\0')) {
                return 0;
              }
              cVar1 = FUN_140332fe0(param_1,param_3);
              if (cVar1 != '\0') {
                plVar7 = (longlong *)FUN_140087d40();
                lVar8 = (**(code **)(*plVar7 + 0x60))(plVar7,param_3);
                if (lVar8 != 0) {
                  cVar1 = FUN_140103bd0(lVar8);
                  if (cVar1 == '\0') {
                    (**(code **)(param_1[2] + 0x358))(param_1 + 2,"assistance item is not gem!");
                    return 0;
                  }
                  cVar1 = FUN_1400ffbe0(lVar8);
                  if ((cVar1 != '\0') && (cVar1 = FUN_1400ffbe0(lVar5), cVar1 == '\0')) {
                    return 0;
                  }
                  iVar3 = FUN_1400fda10(lVar8,1,1);
                  iVar9 = (iVar3 / 10) % 10;
                  iVar3 = FUN_1400fda10(lVar8,1,1);
                  iVar3 = iVar3 % 10;
                  iVar4 = FUN_1400fda10(lVar8,1,1);
                  if ((0xaaec4 < iVar4) && ((iVar4 < 0xaaec8 || (iVar4 - 0xaaed9U < 3)))) {
                    iVar9 = 1;
                  }
                  iVar4 = 0;
                  switch(iVar9) {
                  case 0:
                    if (iVar3 == 1) {
                      iVar4 = tq::RandGet(0x3b);
                      iVar4 = iVar4 + 1;
                    }
                    else if (iVar3 == 2) {
                      iVar4 = tq::RandGet(0x32);
                      iVar4 = iVar4 + 0x3c;
                    }
                    else {
                      iVar4 = tq::RandGet(0x3c);
                      iVar4 = iVar4 + 0xaa;
                    }
                    break;
                  case 1:
                    if (iVar3 == 1) {
                      iVar4 = tq::RandGet(0x3b);
                      iVar4 = iVar4 + 1;
                    }
                    else if (iVar3 == 2) {
                      iVar4 = tq::RandGet(0x3c);
                      iVar4 = iVar4 + 100;
                    }
                    else {
                      iVar4 = tq::RandGet(0x38);
                      iVar4 = iVar4 + 200;
                    }
                    break;
                  case 2:
                    if (iVar3 == 1) {
                      iVar4 = tq::RandGet(0x3b);
                      iVar4 = iVar4 + 1;
                    }
                    else if (iVar3 == 2) {
                      iVar4 = tq::RandGet(0x32);
                      iVar4 = iVar4 + 0x28;
                    }
                    else {
                      iVar4 = tq::RandGet(0x3c);
                      iVar4 = iVar4 + 0x5a;
                    }
                    break;
                  case 3:
                    if (iVar3 == 1) {
                      iVar4 = tq::RandGet(0x3b);
                      iVar4 = iVar4 + 1;
                    }
                    else if (iVar3 == 2) {
                      iVar4 = tq::RandGet(0x32);
                      iVar4 = iVar4 + 0x50;
                    }
                    else {
                      iVar4 = tq::RandGet(0x3c);
                      iVar4 = iVar4 + 0xaa;
                    }
                    break;
                  case 4:
                    if (iVar3 == 1) {
                      iVar4 = tq::RandGet(0x3b);
                      iVar4 = iVar4 + 1;
                    }
                    else if (iVar3 == 2) {
                      iVar4 = tq::RandGet(0x32);
                      iVar4 = iVar4 + 0x28;
                    }
                    else {
                      iVar4 = tq::RandGet(0x32);
                      iVar4 = iVar4 + 0x46;
                    }
                    break;
                  case 5:
                    if (iVar3 == 1) {
                      iVar4 = tq::RandGet(0x3b);
                      iVar4 = iVar4 + 1;
                    }
                    else if (iVar3 == 2) {
                      iVar4 = tq::RandGet(0x32);
                      iVar4 = iVar4 + 0x3c;
                    }
                    else {
                      iVar4 = tq::RandGet(0x3c);
                      iVar4 = iVar4 + 0x8c;
                    }
                    break;
                  case 6:
                    if (iVar3 == 1) {
                      iVar4 = tq::RandGet(0x3b);
                      iVar4 = iVar4 + 1;
                    }
                    else if (iVar3 == 2) {
                      iVar4 = tq::RandGet(0x32);
                      iVar4 = iVar4 + 0x3c;
                    }
                    else {
                      iVar4 = tq::RandGet(0x3c);
                      iVar4 = iVar4 + 0x8c;
                    }
                    break;
                  case 7:
                    if (iVar3 == 1) {
                      iVar4 = tq::RandGet(0x3b);
                      iVar4 = iVar4 + 1;
                    }
                    else if (iVar3 == 2) {
                      iVar4 = tq::RandGet(0x32);
                      iVar4 = iVar4 + 0x28;
                    }
                    else {
                      iVar4 = tq::RandGet(0x3c);
                      iVar4 = iVar4 + 0xaa;
                    }
                  }
                  cVar1 = FUN_140340190(param_1,param_3,1,1);
                  if (cVar1 == '\0') {
                    return 0;
                  }
                  FUN_1400f83e0(local_478);
                  local_4a8 = 0;
                  iVar3 = FUN_1400f8490(local_478,param_2,0x1c,iVar4);
                  if (iVar3 != 0) {
                    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
                  }
                  iVar3 = FUN_1400fda10(lVar5,0xf,1);
                  if (iVar3 < iVar4) {
                    FUN_140104140(lVar5,0xf,iVar4);
                    FUN_140104080(lVar5,1);
                    plVar7 = (longlong *)FUN_140087d40();
                    local_4a0 = 0;
                    local_4a8 = 0;
                    (**(code **)(*plVar7 + 0x130))(plVar7,param_1,lVar5,3);
                  }
                  (**(code **)(*param_1 + 8))(param_1);
                  (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                  local_4a8 = param_2;
                  local_4a0 = param_3;
                  local_498 = iVar4;
                  local_490 = iVar3;
                  tq::MyLogSave("gmlog/enhance.log",
                                "%s(%u) enhance item(%u) cost gem(%u) get %u with org(%u)");
                  uVar6 = FUN_140008520((int)param_1[0x246]);
                  uVar6 = FUN_140087c40(uVar6);
                  FUN_140261810(uVar6,param_1,0xd);
                  FUN_1400f8430(local_478);
                  return 1;
                }
              }
              (**(code **)(param_1[2] + 0x358))(param_1 + 2,"assistance item not found!");
              return 0;
            }
          }
        }
      }
      return 0;
    }
  }
  (**(code **)(param_1[2] + 0x358))(param_1 + 2,"target item not found!");
  return 0;
}

// ==== CMsgItem::helper_140349540  @140349540  [medium:callgraph-r0]  (orig: FUN_140349540)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140349540(longlong *param_1,int param_2,longlong param_3,int param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong lVar10;
  undefined4 local_res10;
  
  lVar10 = (longlong)param_4;
  if (param_2 != 0) {
    lVar4 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    if (lVar4 != 0) {
      cVar1 = FUN_140332fe0(param_1,param_2);
      if ((cVar1 != '\0') || (cVar1 = FUN_140333220(param_1,param_2), cVar1 != '\0')) {
        plVar8 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          plVar8 = (longlong *)0x0;
        }
        lVar4 = (**(code **)(*plVar8 + 0x60))(plVar8,param_2);
        if (((lVar4 != 0) && (cVar1 = FUN_1400ffc20(lVar4), cVar1 == '\0')) &&
           (cVar1 = FUN_140106d70(lVar4), cVar1 == '\0')) {
          uVar2 = FUN_1400fda10(lVar4,1,1);
          iVar3 = FUN_1400ff680(uVar2);
          if (0 < iVar3) {
            uVar2 = FUN_1400fda10(lVar4,1,1);
            iVar3 = FUN_1400ff680(uVar2);
            if (((iVar3 < 9) && (iVar3 = FUN_1400ff9e0(lVar4), iVar3 != 0x26b)) &&
               (iVar3 = FUN_1400fda10(lVar4,0xe,1), iVar3 < 7)) {
              uVar5 = FUN_140008520((int)param_1[0x246]);
              cVar1 = FUN_14008abf0(uVar5);
              if ((cVar1 == '\0') || (cVar1 = FUN_140103310(lVar4), cVar1 == '\0')) {
                iVar3 = FUN_1400fda10(lVar4,0xe,1);
                if (iVar3 == 0) {
                  iVar3 = 5;
                  local_res10 = 1;
                }
                else {
                  iVar3 = FUN_1400fda10(lVar4,0xe,1);
                  if (iVar3 == 1) {
                    local_res10 = 3;
                    iVar3 = 1;
                  }
                  else {
                    iVar3 = FUN_1400fda10(lVar4,0xe,1);
                    if (iVar3 == 3) {
                      local_res10 = 5;
                      iVar3 = 3;
                    }
                    else {
                      iVar3 = FUN_1400fda10(lVar4,0xe,1);
                      if (iVar3 != 5) {
                        return 0;
                      }
                      local_res10 = 7;
                      iVar3 = 5;
                    }
                  }
                }
                if (param_4 == iVar3) {
                  lVar9 = 0;
                  if (0 < param_4) {
                    do {
                      cVar1 = FUN_140332fe0(param_1,*(undefined4 *)(param_3 + lVar9 * 4));
                      if (cVar1 == '\0') {
                        return 0;
                      }
                      plVar8 = (longlong *)FUN_140087d40();
                      lVar6 = (**(code **)(*plVar8 + 0x60))
                                        (plVar8,*(undefined4 *)(param_3 + lVar9 * 4));
                      if (lVar6 == 0) {
                        return 0;
                      }
                      iVar3 = FUN_1400fda10(lVar6,1,1);
                      if (iVar3 != 0xaaea9) {
                        return 0;
                      }
                      cVar1 = FUN_1400ffc20(lVar6);
                      if (cVar1 != '\0') {
                        return 0;
                      }
                      cVar1 = FUN_1400ffbe0(lVar6);
                      if ((cVar1 != '\0') && (cVar1 = FUN_1400ffbe0(lVar4), cVar1 == '\0')) {
                        return 0;
                      }
                      lVar9 = lVar9 + 1;
                    } while (lVar9 < lVar10);
                  }
                  lVar9 = 0;
                  if (0 < lVar10) {
                    do {
                      cVar1 = FUN_140332fe0(param_1,*(undefined4 *)(param_3 + lVar9 * 4));
                      if (cVar1 != '\0') {
                        plVar8 = (longlong *)FUN_140087d40();
                        plVar8 = (longlong *)
                                 (**(code **)(*plVar8 + 0x60))
                                           (plVar8,*(undefined4 *)(param_3 + lVar9 * 4));
                        if ((plVar8 != (longlong *)0x0) &&
                           (cVar1 = FUN_140104440(plVar8), cVar1 != '\0')) {
                          FUN_1400fda10(plVar8,1,1);
                          (**(code **)(*plVar8 + 8))(plVar8);
                          uVar7 = (**(code **)(*param_1 + 8))(param_1);
                          uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                          tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                                        "User:%s[%u] CUser::MakeReduceDmg consume nonsuch item %u[type=%u]"
                                        ,uVar5,uVar7 & 0xffffffff);
                        }
                      }
                      cVar1 = FUN_140340190(param_1,*(undefined4 *)(param_3 + lVar9 * 4),1,1);
                      if (cVar1 == '\0') {
                        return 0;
                      }
                      lVar9 = lVar9 + 1;
                    } while (lVar9 < lVar10);
                  }
                  FUN_140104140(lVar4,0xe,local_res10,1);
                  plVar8 = (longlong *)FUN_140087d40();
                  (**(code **)(*plVar8 + 0x130))(plVar8,param_1,lVar4,3);
                  uVar5 = FUN_140008520((int)param_1[0x246]);
                  uVar5 = FUN_140087c40(uVar5);
                  FUN_140261810(uVar5,param_1,0xd);
                  return 1;
                }
              }
            }
          }
        }
      }
      return 0;
    }
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pGameMap",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                      );
  }
  return 0;
}

// ==== CMsgItem::helper_140349970  @140349970  [medium:callgraph-r0]  (orig: FUN_140349970)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140349970(longlong *param_1,int param_2,longlong param_3,int param_4)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined1 local_98 [36];
  int local_74;
  int local_70;
  
  if ((param_2 == 0) || ((param_4 != 5 && (param_4 != 1)))) {
    return 0;
  }
  cVar1 = FUN_140332fe0();
  if ((cVar1 != '\0') || (cVar1 = FUN_140333220(param_1,param_2), cVar1 != '\0')) {
    plVar8 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      plVar8 = (longlong *)0x0;
    }
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))(plVar8,param_2);
    if ((((plVar8 != (longlong *)0x0) && (cVar1 = FUN_1400f8840(plVar8), cVar1 != '\0')) &&
        (iVar2 = FUN_1400ff9e0(plVar8), iVar2 != 0x26b)) &&
       ((cVar1 = FUN_140106d70(plVar8), cVar1 == '\0' &&
        (cVar1 = FUN_1400ffc20(plVar8), cVar1 == '\0')))) {
      uVar3 = FUN_140008520((int)param_1[0x246]);
      cVar1 = FUN_14008abf0(uVar3);
      if (((cVar1 == '\0') || (cVar1 = FUN_140103310(plVar8), cVar1 == '\0')) &&
         (FUN_140101cb0(plVar8,local_98), local_70 == 0)) {
        if (local_74 == 0) {
          if (param_4 != 1) {
            return 0;
          }
        }
        else if (param_4 != 5) {
          return 0;
        }
        lVar9 = 0;
        if (0 < param_4) {
          do {
            cVar1 = FUN_140332fe0(param_1,*(undefined4 *)(param_3 + lVar9 * 4));
            if (cVar1 == '\0') {
              return 0;
            }
            plVar4 = (longlong *)FUN_140087d40();
            lVar5 = (**(code **)(*plVar4 + 0x60))(plVar4,*(undefined4 *)(param_3 + lVar9 * 4));
            if (lVar5 == 0) {
              return 0;
            }
            iVar2 = FUN_1400fda10(lVar5,1,1);
            if (iVar2 != 0x109a00) {
              return 0;
            }
            cVar1 = FUN_1400ffc20(lVar5);
            if (cVar1 != '\0') {
              return 0;
            }
            cVar1 = FUN_1400ffbe0(lVar5);
            if ((cVar1 != '\0') && (cVar1 = FUN_1400ffbe0(plVar8), cVar1 == '\0')) {
              return 0;
            }
            lVar9 = lVar9 + 1;
          } while (lVar9 < param_4);
        }
        lVar9 = 0;
        if (0 < param_4) {
          do {
            cVar1 = FUN_140332fe0(param_1,*(undefined4 *)(param_3 + lVar9 * 4));
            if (cVar1 != '\0') {
              plVar4 = (longlong *)FUN_140087d40();
              plVar4 = (longlong *)
                       (**(code **)(*plVar4 + 0x60))(plVar4,*(undefined4 *)(param_3 + lVar9 * 4));
              if ((plVar4 != (longlong *)0x0) && (cVar1 = FUN_140104440(plVar4), cVar1 != '\0')) {
                FUN_1400fda10(plVar4,1,1);
                (**(code **)(*plVar4 + 8))(plVar4);
                uVar6 = (**(code **)(*param_1 + 8))(param_1);
                uVar3 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                              "User:%s[%u] CUser::MakeWeaponHole consume nonsuch item %u[type=%u]",
                              uVar3,uVar6 & 0xffffffff);
              }
            }
            cVar1 = FUN_140340190(param_1,*(undefined4 *)(param_3 + lVar9 * 4),1,1);
            if (cVar1 == '\0') {
              return 0;
            }
            lVar9 = lVar9 + 1;
          } while (lVar9 < param_4);
        }
        if (local_74 == 0) {
          FUN_140104140(plVar8,8,0xff,1);
          uVar3 = 0x28b9;
        }
        else {
          FUN_140104140(plVar8,9,0xff,1);
          uVar3 = 0x28ba;
        }
        FUN_140170e90(param_1,uVar3);
        plVar4 = (longlong *)FUN_140087d40();
        (**(code **)(*plVar4 + 0x130))(plVar4,param_1,plVar8,3);
        (**(code **)(*plVar8 + 8))(plVar8);
        uVar6 = FUN_1400fda10(plVar8,1,1);
        uVar7 = (**(code **)(*param_1 + 8))(param_1);
        tq::MyLogSave("gmlog/MakeItemHole",
                      "MakeWeaponHole user id:%u, weapon item type:%u, weapon id:%u hole:%d\t\t\t\tconsume item type:%u consume item count:%d"
                      ,uVar7 & 0xffffffff,uVar6 & 0xffffffff);
        uVar3 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t%d\t%d\t%d\t%d\t1\t",uVar6 & 0xffffffff,uVar3)
        ;
        uVar3 = FUN_140008520((int)param_1[0x246]);
        uVar3 = FUN_140087c40(uVar3);
        FUN_140261810(uVar3,param_1,0xd);
        return 1;
      }
    }
  }
  return 0;
}

// ==== CMsgItem::helper_14034a390  @14034a390  [medium:callgraph-r0]  (orig: FUN_14034a390)
undefined1 FUN_14034a390(longlong *param_1,undefined4 param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  uint in_stack_ffffffffffffffc0;
  
  if (((0 < param_3) && ((ulonglong)(param_1[0x185] - param_1[0x184] >> 2) < 0x28)) &&
     (cVar2 = FUN_140332fe0(), cVar2 != '\0')) {
    plVar8 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar8 = (longlong *)0x0;
    }
    lVar7 = (**(code **)(*plVar8 + 0x60))(plVar8,param_2);
    if (lVar7 != 0) {
      cVar2 = FUN_140102870(lVar7);
      if (cVar2 == '\0') {
        return 0;
      }
      iVar3 = FUN_1400ffda0(lVar7);
      if (0 < iVar3 - param_3) {
        uVar4 = FUN_1400fda10(lVar7,1,1);
        plVar8 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar1 = *plVar8;
        uVar5 = FUN_140167b40(param_1);
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        plVar8 = (longlong *)
                 (**(code **)(lVar1 + 0x18))
                           (plVar8,uVar4,uVar6,0,uVar5,in_stack_ffffffffffffffc0 & 0xffffff00);
        if (plVar8 != (longlong *)0x0) {
          FUN_140105d40(lVar7,iVar3 - param_3,0);
          plVar9 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar9 = (longlong *)0x0;
          }
          (**(code **)(*plVar9 + 0x130))(plVar9,param_1,lVar7,3,0,0);
          FUN_140105d40(plVar8,param_3,0);
          uVar4 = FUN_1400fda10(lVar7,0x12,1);
          FUN_140104140(plVar8,0x12,uVar4);
          uVar4 = FUN_1400fda10(lVar7,0x16,1);
          FUN_140104140(plVar8,0x16,uVar4);
          uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
          FUN_140340de0(param_1,uVar4,1,0);
          FUN_140104080(plVar8,1);
          return 1;
        }
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMsgItem::helper_14034e2b0  @14034e2b0  [medium:callgraph-r0]  (orig: FUN_14034e2b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14034e2b0(longlong *param_1,int param_2,int param_3,undefined1 param_4)

{
  longlong lVar1;
  char cVar2;
  undefined1 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  longlong *plVar13;
  undefined8 uVar14;
  undefined1 auStack_4d8 [32];
  undefined8 local_4b8;
  undefined8 local_4b0;
  undefined4 local_4a8;
  int local_4a0;
  int local_498;
  int local_494;
  longlong *local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (param_2 == 0) {
    return 0;
  }
  local_498 = param_3;
  local_490 = param_1;
  cVar2 = FUN_14032f520();
  if (cVar2 == '\0') {
    return 0;
  }
  cVar2 = FUN_140332fe0(param_1,param_2);
  if (cVar2 == '\0') {
    return 0;
  }
  plVar13 = (longlong *)FUN_140087d40();
  plVar13 = (longlong *)(**(code **)(*plVar13 + 0x60))(plVar13,param_2);
  if (plVar13 == (longlong *)0x0) {
    return 0;
  }
  cVar2 = FUN_1400ffc20(plVar13);
  if (cVar2 != '\0') {
    return 0;
  }
  iVar4 = FUN_1400fda10(plVar13,1,1);
  if (iVar4 == 0xb0af4) {
    uVar3 = FUN_1403412f0(param_1,param_2);
    return uVar3;
  }
  cVar2 = FUN_140103af0(plVar13);
  if (cVar2 != '\0') {
    iVar4 = FUN_1400fda10(plVar13,1,1);
    if (iVar4 == 1200000) {
      FUN_14032b5c0(param_1,0x48);
    }
    else if (iVar4 == 0x124f81) {
      FUN_14032b5c0(param_1,0xa8);
    }
    else if (iVar4 == 0x124f82) {
      FUN_14032b5c0(param_1,0x2d0);
    }
    uVar5 = (**(code **)(*plVar13 + 8))(plVar13);
    *(undefined4 *)(param_1 + 0x14c) = uVar5;
    uVar5 = (**(code **)(*plVar13 + 8))(plVar13);
    uVar6 = FUN_1400fda10(plVar13,0x71,1);
    uVar14 = FUN_140008520((int)param_1[0x246]);
    uVar14 = FUN_140087730(uVar14);
    local_4b0 = 0;
    local_4b8 = CONCAT44(local_4b8._4_4_,uVar5);
    FUN_140145f60(uVar14,uVar6,param_1,0);
    return 1;
  }
  cVar2 = FUN_14032ec70(plVar13);
  if (cVar2 != '\0') {
    iVar4 = FUN_140100000(plVar13);
    if (iVar4 < 1) {
      uVar5 = (**(code **)(*plVar13 + 8))(plVar13);
      local_4b8 = local_4b8 & 0xffffffffffffff00;
      cVar2 = FUN_14033a6a0(param_1,uVar5,1,0);
      if (cVar2 == '\0') {
        local_4b8 = CONCAT44(local_4b8._4_4_,0xa5f);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      return 0;
    }
    iVar4 = FUN_1400fda10(plVar13,0x71,1);
    uVar5 = (**(code **)(*plVar13 + 8))(plVar13);
    cVar2 = FUN_140340190(param_1,uVar5,1,1);
    if (cVar2 != '\0') {
      if (iVar4 != 0) {
        *(undefined4 *)(param_1 + 0x14c) = 0;
        uVar14 = FUN_140008520((int)param_1[0x246]);
        uVar14 = FUN_140087730(uVar14);
        local_4b0 = 0;
        local_4b8 = (ulonglong)local_4b8._4_4_ << 0x20;
        FUN_140145f60(uVar14,iVar4,param_1,0);
      }
      return 1;
    }
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogWARNING("CUser[%u]::UseItem ExpendMultiItem[%u] failed");
    return 0;
  }
  uVar5 = FUN_1400fda10(plVar13,1,1);
  cVar2 = FUN_140102710(uVar5);
  if (cVar2 != '\0') {
    uVar5 = (**(code **)(*plVar13 + 8))(plVar13);
    cVar2 = FUN_14034aa60(param_1,uVar5,param_3,param_4);
    if (cVar2 == '\0') {
      return 0;
    }
    cVar2 = FUN_140103280(plVar13);
    if ((cVar2 != '\0') && (iVar4 = FUN_140100c20(plVar13), iVar4 != 0)) {
      FUN_14036ee80(local_478);
      uVar5 = FUN_1400fda10(plVar13,1,1);
      uVar6 = FUN_140100c20(plVar13);
      uVar7 = (**(code **)(*plVar13 + 8))(plVar13);
      uVar8 = (**(code **)(*param_1 + 0x38))(param_1);
      uVar9 = (**(code **)(*param_1 + 8))(param_1);
      local_4a0 = local_498;
      local_4b0 = CONCAT44(local_4b0._4_4_,uVar6);
      local_4b8 = CONCAT44(local_4b8._4_4_,uVar7);
      local_4a8 = uVar5;
      cVar2 = FUN_14036ef90(local_478,5,uVar9,uVar8);
      if (cVar2 != '\0') {
        (**(code **)(*param_1 + 0x138))(param_1,local_478,4);
      }
      FUN_14036eed0(local_478);
    }
    return 1;
  }
  cVar2 = FUN_140103cd0(plVar13);
  if (cVar2 == '\0') {
    return 0;
  }
  iVar4 = FUN_1400fda10(plVar13,1,1);
  cVar2 = (**(code **)(*param_1 + 0x128))(param_1);
  if (((cVar2 == '\0') && (iVar4 != 0xf4e02)) && (iVar4 != 0xf4e0c)) {
    if (iVar4 != 0xf4e16) {
      if (iVar4 != 0xf51ea) {
        return 0;
      }
      goto LAB_14034e6a0;
    }
  }
  else {
LAB_14034e6a0:
    if (iVar4 != 0xf4e16) {
      iVar12 = FUN_1400fda10(plVar13,4,1);
      if (iVar12 == 0) {
        local_494 = 0;
      }
      else {
        local_494 = FUN_1400fda10(plVar13,0x77,1);
      }
      iVar12 = local_494;
      local_498 = FUN_1400fda10(plVar13,0x78,1);
      if (0 < iVar12) {
        uVar10 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
        uVar11 = (**(code **)(param_1[2] + 0x78))(param_1 + 2);
        iVar12 = local_494;
        if (uVar10 <= uVar11) {
          return 0;
        }
      }
      if (0 < local_498) {
        uVar10 = (**(code **)(*param_1 + 0x88))(param_1);
        uVar11 = (**(code **)(*param_1 + 0x80))(param_1);
        if (uVar10 <= uVar11) {
          return 0;
        }
      }
      uVar5 = (**(code **)(*plVar13 + 8))(plVar13);
      cVar2 = FUN_140340190(param_1,uVar5,1,1);
      if (cVar2 == '\0') {
        (**(code **)(*param_1 + 8))(param_1);
        (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        local_4b8 = CONCAT44(local_4b8._4_4_,iVar4);
        log_InlineLogERROR(
                          "CUser::UseItem ExpendMultiItem, user(%s,%u) failed in eat item(%u), itemtype: %d"
                          );
        return 0;
      }
      if (iVar12 < 1) {
        if (iVar12 < 0) {
          local_4b8 = 0;
          (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0,(longlong)iVar12,1);
          (**(code **)(*param_1 + 0xd8))(param_1);
        }
      }
      else {
        local_4b8 = 0;
        (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0,(longlong)iVar12,1);
        (**(code **)(*param_1 + 0xd8))(param_1);
        plVar13 = (longlong *)FUN_1400e1e60();
        lVar1 = *plVar13;
        uVar5 = (**(code **)(*param_1 + 8))(param_1);
        cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,1);
        if (cVar2 == '\0') {
          plVar13 = (longlong *)FUN_1400e1e60();
          lVar1 = *plVar13;
          uVar5 = (**(code **)(*param_1 + 8))(param_1);
          cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,2);
          if (cVar2 == '\0') goto LAB_14034eb4b;
        }
        plVar13 = (longlong *)FUN_1400e1e60();
        lVar1 = *plVar13;
        uVar5 = (**(code **)(*param_1 + 8))(param_1);
        cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,3);
        if ((cVar2 != '\0') && (iVar4 = tq::RandGet(3), iVar4 == 0)) {
          plVar13 = (longlong *)FUN_1400e1e60();
          lVar1 = *plVar13;
          uVar5 = (**(code **)(*param_1 + 8))(param_1);
          (**(code **)(lVar1 + 0x58))(plVar13,uVar5,3);
        }
      }
LAB_14034eb4b:
      if (local_498 != 0) {
        local_4b8 = 0;
        (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,2,(longlong)local_498,1);
        plVar13 = (longlong *)FUN_1400e1e60();
        lVar1 = *plVar13;
        uVar5 = (**(code **)(*param_1 + 8))(param_1);
        cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,1);
        if (cVar2 == '\0') {
          plVar13 = (longlong *)FUN_1400e1e60();
          lVar1 = *plVar13;
          uVar5 = (**(code **)(*param_1 + 8))(param_1);
          cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,2);
          if (cVar2 == '\0') goto LAB_14034ec25;
        }
        plVar13 = (longlong *)FUN_1400e1e60();
        lVar1 = *plVar13;
        uVar5 = (**(code **)(*param_1 + 8))(param_1);
        cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,4);
        if ((cVar2 != '\0') && (iVar4 = tq::RandGet(3), iVar4 == 0)) {
          plVar13 = (longlong *)FUN_1400e1e60();
          lVar1 = *plVar13;
          uVar5 = (**(code **)(*param_1 + 8))(param_1);
          (**(code **)(lVar1 + 0x58))(plVar13,uVar5,4);
        }
      }
      goto LAB_14034ec25;
    }
  }
  uVar10 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
  uVar11 = (**(code **)(param_1[2] + 0x78))(param_1 + 2);
  if (uVar10 <= uVar11) {
    uVar10 = (**(code **)(*param_1 + 0x88))(param_1);
    uVar11 = (**(code **)(*param_1 + 0x80))(param_1);
    if (uVar10 <= uVar11) {
      return 0;
    }
  }
  uVar5 = (**(code **)(*plVar13 + 8))(plVar13);
  cVar2 = FUN_140340190(param_1,uVar5,1,1);
  if (cVar2 == '\0') {
    (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(param_1[2] + 0x18))(param_1 + 2);
    local_4b8 = CONCAT44(local_4b8._4_4_,iVar4);
    log_InlineLogERROR(
                      "CUser::UseItem ExpendMultiItem, user(%s,%u) failed in eat item(%u), itemtype: %d"
                      );
    return 0;
  }
  uVar10 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
  uVar11 = (**(code **)(param_1[2] + 0x78))(param_1 + 2);
  if (uVar11 < uVar10) {
    uVar5 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
    FUN_1401a6420(param_1,0,uVar5,1);
    (**(code **)(*param_1 + 0xd8))(param_1);
    plVar13 = (longlong *)FUN_1400e1e60();
    lVar1 = *plVar13;
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,1);
    if (cVar2 == '\0') {
      plVar13 = (longlong *)FUN_1400e1e60();
      lVar1 = *plVar13;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,2);
      if (cVar2 == '\0') goto LAB_14034e843;
    }
    plVar13 = (longlong *)FUN_1400e1e60();
    lVar1 = *plVar13;
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,3);
    if ((cVar2 != '\0') && (iVar4 = tq::RandGet(3), iVar4 == 0)) {
      plVar13 = (longlong *)FUN_1400e1e60();
      lVar1 = *plVar13;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar1 + 0x58))(plVar13,uVar5,3);
    }
  }
LAB_14034e843:
  uVar10 = (**(code **)(*param_1 + 0x88))(param_1);
  uVar11 = (**(code **)(*param_1 + 0x80))(param_1);
  if (uVar11 < uVar10) {
    uVar5 = (**(code **)(*param_1 + 0x88))(param_1);
    FUN_1401a6420(param_1,2,uVar5,1);
    plVar13 = (longlong *)FUN_1400e1e60();
    lVar1 = *plVar13;
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,1);
    if (cVar2 == '\0') {
      plVar13 = (longlong *)FUN_1400e1e60();
      lVar1 = *plVar13;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,2);
      if (cVar2 == '\0') goto LAB_14034ec25;
    }
    plVar13 = (longlong *)FUN_1400e1e60();
    lVar1 = *plVar13;
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    cVar2 = (**(code **)(lVar1 + 0x20))(plVar13,uVar5,4);
    if ((cVar2 != '\0') && (iVar4 = tq::RandGet(3), iVar4 == 0)) {
      plVar13 = (longlong *)FUN_1400e1e60();
      lVar1 = *plVar13;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar1 + 0x58))(plVar13,uVar5,4);
    }
  }
LAB_14034ec25:
  FUN_1401642f0(param_1);
  return 1;
}

// ==== CMsgItem::helper_1403536b0  @1403536b0  [medium:callgraph-r0]  (orig: FUN_1403536b0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_1403536b0(longlong *param_1,uint param_2,char param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  undefined8 uVar8;
  uint uVar9;
  
  if (param_2 == 0) {
    return 0;
  }
  plVar6 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar6 = (longlong *)0x0;
  }
  lVar4 = *plVar6;
  uVar2 = FUN_14032f080(param_1,param_2);
  lVar4 = (**(code **)(lVar4 + 0x60))(plVar6,uVar2);
  if (lVar4 != 0) {
    uVar2 = FUN_1400fda10(lVar4,1,1);
    iVar3 = FUN_1400ff680(uVar2);
    if (iVar3 == 9) {
      uVar2 = FUN_1400fda10(lVar4,1,1);
      iVar3 = FUN_1400fecd0(uVar2);
      if (iVar3 == 0) {
        uVar9 = param_2 % 10;
        if ((uVar9 != 3) && (cVar1 = FUN_140338940(param_1,param_2,param_2,0xf), cVar1 != '\0')) {
          if (uVar9 == 1) {
            lVar4 = 10000;
          }
          else {
            if (uVar9 != 2) {
              return 0;
            }
            lVar4 = 800000;
            if ((param_2 / 10) % 10 == 7) {
              lVar4 = 1000000;
            }
          }
          lVar5 = (**(code **)(*param_1 + 0x60))(param_1);
          if (((lVar4 <= lVar5) &&
              (cVar1 = (**(code **)(*param_1 + 0x178))(param_1,lVar4,1), cVar1 != '\0')) &&
             (cVar1 = FUN_140344e80(param_1,param_2,param_2,0xf), cVar1 != '\0')) {
            plVar6 = (longlong *)FUN_140087d40();
            lVar4 = *plVar6;
            uVar2 = FUN_14034a8d0(param_1,param_2 + 1,param_3 != '\0',0);
            lVar4 = (**(code **)(lVar4 + 0x60))(plVar6,uVar2);
            if (lVar4 != 0) {
              plVar6 = (longlong *)FUN_140087d40();
              (**(code **)(*plVar6 + 0x130))(plVar6,param_1,lVar4,1);
              uVar7 = (**(code **)(*param_1 + 8))(param_1);
              tq::MyLogSave("gmlog/ComposeGem",
                            "user id:%u, org gem type:%u, org gem count:%d, new gem type:%u monopoly=%d"
                            ,uVar7 & 0xffffffff,(ulonglong)param_2);
              switch((param_2 / 10) % 100) {
              case 0:
                break;
              case 1:
                break;
              case 2:
                break;
              case 3:
                break;
              case 4:
                break;
              case 5:
                break;
              case 6:
                break;
              case 7:
                break;
              case 10:
                break;
              case 0xc:
              }
              uVar8 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              uVar7 = (**(code **)(*param_1 + 8))(param_1);
              tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t%d\t%d\t%d\t%d\t1\t",uVar7 & 0xffffffff,
                            uVar8);
              uVar8 = FUN_140008520((int)param_1[0x246]);
              uVar8 = FUN_140087c40(uVar8);
              FUN_140261810(uVar8,param_1,0xd);
              return 1;
            }
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pItem",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                              );
            return 0;
          }
        }
        return 0;
      }
    }
  }
  return 0;
}

// ==== CMsgItem::helper_140353bb0  @140353bb0  [medium:callgraph-r1]  (orig: FUN_140353bb0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140353bb0(longlong *param_1,undefined4 param_2,char param_3)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  longlong *plVar4;
  undefined8 uVar5;
  ulonglong uVar6;
  longlong *plVar7;
  undefined2 uVar8;
  
  uVar8 = 0;
  if (param_3 != '\0') {
    uVar8 = 3;
  }
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar4 = (longlong *)0x0;
  }
  lVar1 = *plVar4;
  uVar3 = FUN_14034a8d0(param_1,param_2,uVar8,0);
  plVar4 = (longlong *)(**(code **)(lVar1 + 0x60))(plVar4,uVar3);
  if (plVar4 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",&DAT_14075575c,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                      );
  }
  else {
    uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
    uVar6 = (**(code **)(*param_1 + 8))(param_1);
    tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t%d\t%d\t%d\t%d\t1\t",uVar6 & 0xffffffff,uVar5);
    plVar7 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      plVar7 = (longlong *)0x0;
    }
    cVar2 = (**(code **)(*plVar7 + 0x130))(plVar7,param_1,plVar4,1);
    if (cVar2 != '\0') {
      uVar5 = (**(code **)(*plVar4 + 8))(plVar4);
      return uVar5;
    }
  }
  return 0;
}

// ==== CMsgItem::helper_140353d90  @140353d90  [medium:callgraph-r0]  (orig: FUN_140353d90)
undefined8 FUN_140353d90(longlong *param_1,int *param_2,uint *param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  int *piVar6;
  ulonglong uVar7;
  uint uVar8;
  ulonglong uVar9;
  undefined4 local_res10;
  int local_58 [4];
  undefined4 local_48 [8];
  
  if (param_2 == (int *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*param_3 != 7) {
    return 0;
  }
  cVar1 = FUN_14033f010(param_1,param_2,7);
  if (cVar1 == '\0') {
    return 0;
  }
  lVar4 = (**(code **)(*param_1 + 0x60))(param_1);
  if (lVar4 < 100000) {
    return 0;
  }
  cVar1 = (**(code **)(*param_1 + 0x178))(param_1,100000,1);
  if (cVar1 == '\0') {
    return 0;
  }
  uVar9 = 0;
  local_res10 = 0;
  local_48[1] = 0;
  local_48[0] = 0;
  local_48[2] = 0;
  local_48[3] = 0;
  local_48[4] = 0;
  local_48[5] = 0;
  local_48[6] = 0;
  if (*param_3 != 0) {
    piVar6 = param_2;
    uVar7 = uVar9;
    do {
      cVar1 = FUN_140332fe0(param_1,*piVar6);
      if (cVar1 == '\0') {
LAB_140353fb0:
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
      plVar5 = (longlong *)FUN_140087d40();
      lVar4 = (**(code **)(*plVar5 + 0x60))(plVar5,*piVar6);
      if (lVar4 == 0) goto LAB_140353fb0;
      cVar1 = FUN_140103bd0(lVar4);
      if (cVar1 == '\0') {
        *(undefined4 *)(((longlong)local_48 - (longlong)param_2) + (longlong)piVar6) = 0;
      }
      uVar2 = FUN_1400fda10(lVar4,1,1);
      *(undefined4 *)(((longlong)local_48 - (longlong)param_2) + (longlong)piVar6) = uVar2;
      iVar3 = FUN_1400fda10(lVar4,0x16,1);
      if (iVar3 != 0) {
        local_res10 = 1;
      }
      cVar1 = FUN_140340190(param_1,*piVar6,1,1);
      if (cVar1 == '\0') {
        return 0;
      }
      uVar8 = (int)uVar7 + 1;
      uVar7 = (ulonglong)uVar8;
      piVar6 = piVar6 + 1;
    } while (uVar8 < *param_3);
  }
  iVar3 = tq::RandGet(1000);
  local_58[0] = 0;
  local_58[1] = 0;
  local_58[2] = 0;
  if (iVar3 < 0x3d3) {
    uVar8 = (0x2a6 < iVar3) + 2;
    *param_3 = uVar8;
    if (uVar8 != 0) {
      piVar6 = local_58;
      uVar7 = uVar9;
      do {
        iVar3 = FUN_140353bb0(param_1,0xaaea8,local_res10);
        *piVar6 = iVar3;
        if (iVar3 == 0) {
          FUN_14032ccc0(param_1,local_48,*param_3,uVar7,0xaaea8);
          *param_3 = (uint)uVar7;
          return 0;
        }
        uVar8 = (uint)uVar7 + 1;
        uVar7 = (ulonglong)uVar8;
        piVar6 = piVar6 + 1;
      } while (uVar8 < *param_3);
    }
    FUN_14032ccc0(param_1,local_48,*param_3,*param_3,0xaaea8);
    *param_2 = local_58[0];
    param_2[1] = local_58[1];
    param_2[2] = local_58[2];
    lVar4 = FUN_140008520((int)param_1[0x246]);
    uVar7 = *(ulonglong *)(lVar4 + 0x1f8);
    if (uVar7 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar7 = uVar9;
    }
    FUN_140261810(uVar7,param_1,0xd);
  }
  else {
    local_58[0] = FUN_140353bb0(param_1,0xaaea9,local_res10);
    if (local_58[0] == 0) {
      *param_3 = 0;
      FUN_14032ccc0(param_1,local_48,0,0,0xaaea9);
      *param_2 = local_58[0];
      param_2[1] = local_58[1];
      param_2[2] = local_58[2];
      return 0;
    }
    *param_3 = 1;
    FUN_14032ccc0(param_1,local_48,1,1,0xaaea9);
    *param_2 = local_58[0];
    param_2[1] = local_58[1];
    param_2[2] = local_58[2];
  }
  return 1;
}

// ==== CMsgItem::helper_140354140  @140354140  [medium:callgraph-r0]  (orig: FUN_140354140)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140354140(longlong *param_1,int param_2,longlong param_3,int param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  longlong *plVar11;
  int local_res10;
  undefined4 local_b8;
  undefined1 local_a8 [36];
  int local_84;
  int local_80;
  
  if ((param_2 == 0) || (((param_4 != 0xc && (param_4 != 1)) && (param_4 != 7)))) {
    return 0;
  }
  cVar1 = FUN_140332fe0();
  if ((cVar1 != '\0') || (cVar1 = FUN_140333220(param_1,param_2), cVar1 != '\0')) {
    plVar11 = (longlong *)0x0;
    plVar5 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      plVar5 = plVar11;
    }
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x60))(plVar5,param_2);
    if (plVar5 != (longlong *)0x0) {
      uVar2 = FUN_1400fda10(plVar5,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 != 1) {
        uVar2 = FUN_1400fda10(plVar5,1,1);
        iVar3 = FUN_1400ff680(uVar2);
        if (iVar3 != 2) {
          uVar2 = FUN_1400fda10(plVar5,1,1);
          iVar3 = FUN_1400ff680(uVar2);
          if (iVar3 != 3) {
            uVar2 = FUN_1400fda10(plVar5,1,1);
            iVar3 = FUN_1400ff680(uVar2);
            if (iVar3 != 6) {
              uVar2 = FUN_1400fda10(plVar5,1,1);
              iVar3 = FUN_1400ff680(uVar2);
              if (iVar3 != 7) {
                uVar2 = FUN_1400fda10(plVar5,1,1);
                iVar3 = FUN_1400ff680(uVar2);
                if (iVar3 != 8) {
                  return 0;
                }
              }
            }
          }
        }
      }
      cVar1 = FUN_140106d70(plVar5);
      if ((cVar1 == '\0') && (cVar1 = FUN_1400ffc20(plVar5), cVar1 == '\0')) {
        uVar6 = FUN_140008520((int)param_1[0x246]);
        cVar1 = FUN_14008abf0(uVar6);
        if ((cVar1 == '\0') || (cVar1 = FUN_140103310(plVar5), cVar1 == '\0')) {
          local_b8 = 0;
          FUN_140101cb0(plVar5,local_a8);
          if (local_80 == 0) {
            if (local_84 == 0) {
              iVar3 = 0x109a00;
              local_res10 = 0x109a00;
              if (param_4 != 0xc) {
                return 0;
              }
            }
            else if (param_4 == 1) {
              iVar3 = 0x124f85;
              local_res10 = 0x124f85;
            }
            else {
              if (param_4 != 7) {
                return 0;
              }
              iVar3 = 0x124f86;
              local_res10 = 0x124f86;
            }
            if (0 < param_4) {
              do {
                cVar1 = FUN_140332fe0(param_1,*(undefined4 *)(param_3 + (longlong)plVar11 * 4));
                if (cVar1 == '\0') {
                  return 0;
                }
                plVar7 = (longlong *)FUN_140087d40();
                lVar8 = (**(code **)(*plVar7 + 0x60))
                                  (plVar7,*(undefined4 *)(param_3 + (longlong)plVar11 * 4));
                if (lVar8 == 0) {
                  return 0;
                }
                iVar4 = FUN_1400fda10(lVar8,1,1);
                if (iVar4 != iVar3) {
                  return 0;
                }
                cVar1 = FUN_1400ffc20(lVar8);
                if (cVar1 != '\0') {
                  return 0;
                }
                cVar1 = FUN_1400ffbe0(lVar8);
                if ((cVar1 != '\0') && (cVar1 = FUN_1400ffbe0(plVar5), cVar1 == '\0')) {
                  return 0;
                }
                cVar1 = FUN_1400ffbe0(lVar8);
                if (cVar1 != '\0') {
                  local_b8 = 1;
                }
                plVar11 = (longlong *)((longlong)plVar11 + 1);
              } while ((longlong)plVar11 < (longlong)param_4);
            }
            lVar8 = 0;
            if (0 < param_4) {
              do {
                cVar1 = FUN_140332fe0(param_1,*(undefined4 *)(param_3 + lVar8 * 4));
                if (cVar1 != '\0') {
                  plVar11 = (longlong *)FUN_140087d40();
                  plVar11 = (longlong *)
                            (**(code **)(*plVar11 + 0x60))
                                      (plVar11,*(undefined4 *)(param_3 + lVar8 * 4));
                  if ((plVar11 != (longlong *)0x0) &&
                     (cVar1 = FUN_140104440(plVar11), cVar1 != '\0')) {
                    FUN_1400fda10(plVar11,1,1);
                    (**(code **)(*plVar11 + 8))(plVar11);
                    uVar9 = (**(code **)(*param_1 + 8))(param_1);
                    uVar6 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                    tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                                  "User:%s[%u] CUser::MakeWeaponHole consume nonsuch item %u[type=%u]"
                                  ,uVar6,uVar9 & 0xffffffff);
                  }
                }
                cVar1 = FUN_140340190(param_1,*(undefined4 *)(param_3 + lVar8 * 4),1,1);
                if (cVar1 == '\0') {
                  log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",
                                     "this->ExpendMultiItem(idItems[i], 1, SYNCHRO_TRUE)",
                                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                                    );
                  return 0;
                }
                lVar8 = lVar8 + 1;
              } while (lVar8 < param_4);
            }
            if (local_84 == 0) {
              FUN_140104140(plVar5,8,0xff,1);
              FUN_140170e90(param_1,0x28b9);
            }
            else {
              if (param_4 == 1) {
                if (local_res10 != 0x124f85) {
                  return 0;
                }
                iVar3 = tq::RandGet(10);
                if (0 < iVar3) {
                  plVar11 = (longlong *)FUN_140087d40();
                  lVar8 = *plVar11;
                  uVar2 = FUN_14034a8d0(param_1,0x124f86,local_b8,1);
                  lVar8 = (**(code **)(lVar8 + 0x60))(plVar11,uVar2);
                  if (lVar8 == 0) {
                    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pItemStarDrill",
                                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                                      );
                    return 0;
                  }
                  (**(code **)(*plVar5 + 8))(plVar5);
                  uVar9 = FUN_1400fda10(plVar5,1,1);
                  uVar10 = (**(code **)(*param_1 + 8))(param_1);
                  tq::MyLogSave("gmlog/MakeItemHole",
                                "MakeEquipmentHole fail user id:%u, equipment item type:%u, equipment id:%u\t\t\t\t\tconsume item type:%u consume item count:%d add item type:%u"
                                ,uVar10 & 0xffffffff,uVar9 & 0xffffffff);
                  uVar6 = FUN_140008520((int)param_1[0x246]);
                  uVar6 = FUN_140087c40(uVar6);
                  FUN_140261810(uVar6,param_1,0xd);
                  return 0xffffffff;
                }
              }
              else {
                if (param_4 != 7) {
                  return 0;
                }
                if (local_res10 != 0x124f86) {
                  return 0;
                }
              }
              FUN_140104140(plVar5,9,0xff,1);
              FUN_140170e90(param_1,0x28ba);
            }
            plVar11 = (longlong *)FUN_140087d40();
            (**(code **)(*plVar11 + 0x130))(plVar11,param_1,plVar5,3);
            (**(code **)(*plVar5 + 8))(plVar5);
            uVar9 = FUN_1400fda10(plVar5,1,1);
            uVar10 = (**(code **)(*param_1 + 8))(param_1);
            tq::MyLogSave("gmlog/MakeItemHole",
                          "MakeEquipmentHole user id:%u, equipment item type:%u, equipment id:%u hole:%d\t\tconsume item type:%u consume item count:%d"
                          ,uVar10 & 0xffffffff,uVar9 & 0xffffffff);
            uVar6 = (**(code **)(param_1[2] + 0x18))();
            uVar9 = (**(code **)(*param_1 + 8))(param_1);
            tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t%d\t%d\t%d\t%d\t1\t",uVar9 & 0xffffffff,
                          uVar6);
            uVar6 = FUN_140008520((int)param_1[0x246]);
            uVar6 = FUN_140087c40(uVar6);
            FUN_140261810(uVar6,param_1,0xd);
            return 1;
          }
        }
      }
    }
  }
  return 0;
}

// ==== CMsgItem::helper_1403569b0  @1403569b0  [medium:callgraph-r0]  (orig: FUN_1403569b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1403569b0(longlong *param_1,int param_2,char param_3,char param_4)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 uVar8;
  longlong *plVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  longlong *plVar12;
  longlong lVar13;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  int *local_4b0;
  undefined1 local_4a8;
  int local_498 [2];
  undefined8 local_490;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_490 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  cVar1 = FUN_140332fe0();
  if (cVar1 != '\0') {
    plVar9 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_4b8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar9 = (longlong *)0x0;
    }
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,param_2);
    if (plVar9 != (longlong *)0x0) {
LAB_140356a85:
      uVar2 = FUN_1400fda10(plVar9,0x87,1);
      if ((uVar2 & 1) != 0) {
        return 0;
      }
      cVar1 = FUN_140106240(plVar9);
      if (cVar1 != '\0') {
        iVar3 = FUN_1400fda10(plVar9,5,1);
        iVar4 = FUN_1400fda10(plVar9,4,1);
        if (iVar4 < iVar3) {
          iVar3 = FUN_1400fe9d0(plVar9);
          if (iVar3 < 0) {
            return 0;
          }
          iVar4 = FUN_1400fda10(plVar9,4,1);
          if (iVar4 == 0) {
            local_4a8 = 0;
            local_4b0 = local_498;
            local_4b8 = 1;
            local_498[0] = iVar4;
            cVar1 = FUN_140344e80(param_1,0x109a01,0x109a01,5);
            if (cVar1 == '\0') {
              pIVar10 = theInstance();
              lVar13 = param_1[2];
              uVar11 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_NOSSTAR_REPAIR");
              (**(code **)(lVar13 + 0x358))(param_1 + 2,uVar11);
              return 0;
            }
          }
          else {
            iVar4 = FUN_1400fda10(plVar9,5,1);
            iVar5 = FUN_1400fda10(plVar9,4,1);
            if (iVar4 - iVar5 < 1) {
              return 1;
            }
            if ((0 < iVar3) &&
               (cVar1 = (**(code **)(*param_1 + 0x178))(param_1,(longlong)iVar3,1), cVar1 == '\0'))
            {
              return 0;
            }
          }
          uVar6 = FUN_1400fda10(plVar9,1,1);
          uVar6 = FUN_1400ff680(uVar6);
          switch(uVar6) {
          case 1:
          case 2:
          case 3:
          case 6:
          case 8:
            iVar4 = FUN_1400fda10(plVar9,4,1);
            if (iVar4 < 0x96) {
              iVar4 = FUN_1400fda10(plVar9,4,1);
              iVar5 = FUN_1400fda10(plVar9,5,1);
              iVar4 = (iVar5 * ((iVar4 * 2) / 3)) / 0x96;
              iVar5 = FUN_1400fda10(plVar9,5,1);
              if (iVar5 / 5 < iVar4) {
                iVar4 = FUN_1400fda10(plVar9,5,1);
                iVar4 = iVar4 / 5;
              }
              iVar7 = FUN_1400fda10(plVar9,5,1);
              iVar5 = iVar7 - iVar4;
              if (iVar7 - iVar4 < 100) {
                iVar5 = 100;
              }
              FUN_140104140(plVar9,5,iVar5,0);
            }
            break;
          case 4:
          case 5:
          case 7:
            iVar4 = FUN_1400fda10(plVar9,4,1);
            if (iVar4 < 0xbe) {
              iVar4 = FUN_1400fda10(plVar9,4,1);
              iVar5 = FUN_1400fda10(plVar9,5,1);
              iVar4 = (iVar5 * ((iVar4 * 2) / 3)) / 0xbe;
              iVar5 = FUN_1400fda10(plVar9,5,1);
              if (iVar5 / 5 < iVar4) {
                iVar4 = FUN_1400fda10(plVar9,5,1);
                iVar4 = iVar4 / 5;
              }
              iVar7 = FUN_1400fda10(plVar9,5,1);
              iVar5 = iVar7 - iVar4;
              if (iVar7 - iVar4 < 100) {
                iVar5 = 100;
              }
              FUN_140104140(plVar9,5,iVar5,0);
            }
            break;
          default:
            uVar6 = FUN_1400fda10(plVar9,1,1);
            FUN_1400ff680(uVar6);
            uVar6 = FUN_1400fda10(plVar9,0x87,1);
            FUN_1400fda10(plVar9,1,1);
            (**(code **)(*plVar9 + 8))(plVar9);
            local_4b8 = uVar6;
            log_InlineLogDBERROR
                      (
                      "Can not repair item!, iditem[%lu], itemtype[%lu]. table cq_itemtype sort[%d] is can\'t repaired, but the Repair_mode[%d] is able to repair!"
                      );
            return 0;
          case 0xc:
          case 0xd:
          case 0x15:
          case 0x16:
            break;
          }
          uVar6 = FUN_1400fda10(plVar9,5,1);
          FUN_140104140(plVar9,4,uVar6,1);
          if (*(int *)((longlong)param_1 + 0xb2c) != 0) {
            uVar6 = FUN_1400fda10(plVar9,1,1);
            cVar1 = FUN_1400ff940(uVar6);
            if ((cVar1 != '\0') && (iVar4 = FUN_1401011d0(plVar9), iVar4 < 7)) {
              iVar4 = FUN_1401011d0(plVar9);
              if (iVar4 < 6) {
                iVar3 = MulDiv(iVar3,1000,300000);
              }
              else {
                iVar4 = MulDiv(iVar3,1000,800000);
                if (iVar4 < 1) {
                  iVar3 = 1;
                }
                else {
                  iVar3 = MulDiv(iVar3,1000,800000);
                }
              }
              iVar4 = tq::RandGet(1000);
              if (iVar4 < iVar3) {
                uVar6 = FUN_1400fda10(plVar9,1,1);
                uVar8 = (**(code **)(*plVar9 + 8))(plVar9);
                iVar3 = FUN_14032bd40(param_1,uVar8,0);
                if (iVar3 != 0) {
                  cVar1 = FUN_140106b20(plVar9,iVar3);
                  if (cVar1 == '\0') {
                    local_4b8 = 0x1176;
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  else {
                    (**(code **)(*plVar9 + 8))(plVar9);
                    (**(code **)(*param_1 + 8))(param_1);
                    local_4b0 = (int *)CONCAT44(local_4b0._4_4_,iVar3);
                    local_4b8 = uVar6;
                    tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                                  "User[%u] up quality Item[%u] from [%u] to [%u] while repair");
                    FUN_140104080(plVar9,1);
                    pIVar10 = theInstance();
                    lVar13 = *param_1;
                    uVar11 = (*(code *)**(undefined8 **)pIVar10)
                                       (pIVar10,"STR_LUCK_REPAIR_UPQUALITY");
                    (**(code **)(lVar13 + 0x150))(param_1,0x7d5,uVar11);
                    FUN_14037dfb0(local_488);
                    uVar6 = (**(code **)(*param_1 + 8))(param_1);
                    iVar3 = FUN_14037e0a0(local_488,10,"LuckyGuy",uVar6);
                    if (iVar3 == 0) {
                      local_4b8 = 0x1184;
                      log_InlineLogERROR(&DAT_1406d9c10);
                    }
                    else {
                      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_488);
                    }
                    FUN_14037e030(local_488);
                  }
                }
              }
            }
          }
          if (param_3 != '\0') {
            plVar12 = (longlong *)FUN_140087d40();
            local_4b0 = (int *)((ulonglong)local_4b0 & 0xffffffff00000000);
            local_4b8 = 0;
            (**(code **)(*plVar12 + 0x130))(plVar12,param_1,plVar9,3);
          }
          return 1;
        }
      }
      return 0;
    }
  }
  if (param_4 != '\0') {
    lVar13 = 0;
    plVar9 = param_1 + 0x1b3;
    do {
      if ((int)*plVar9 == param_2) {
        plVar9 = (longlong *)FUN_140087d40();
        plVar9 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,param_2);
        if (plVar9 == (longlong *)0x0) {
          return 0;
        }
        goto LAB_140356a85;
      }
      lVar13 = lVar13 + 1;
      plVar9 = (longlong *)((longlong)plVar9 + 4);
    } while (lVar13 < 0x13);
  }
  return 0;
}

// ==== CMsgItem::helper_140372770  @140372770  [medium:callgraph-r2]  (orig: FUN_140372770)
void FUN_140372770(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0xc4) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"exp_ball_usage");
    (**(code **)(*plVar1 + 200))(plVar1,*(undefined2 *)(param_1 + 0xc4));
    if (param_3 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CMsgItem::helper_14037d3f0  @14037d3f0  [medium:callgraph-r1]  (orig: FUN_14037d3f0)
undefined1 FUN_14037d3f0(longlong param_1)

{
  FUN_14033c200(param_1 + 0xb0);
  return 1;
}

// ==== CMsgItem::helper_1403b7ae0  @1403b7ae0  [medium:callgraph-r2]  (orig: FUN_1403b7ae0)
undefined8 FUN_1403b7ae0(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) != 0) {
    if (param_2 < 4) {
      plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x0001403b7b35. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
      return uVar2;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMsgItem::helper_14046a590  @14046a590  [medium:callgraph-r1]  (orig: FUN_14046a590)
int FUN_14046a590(longlong param_1,int param_2,int param_3)

{
  int iVar1;
  
  iVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x110) + 0x10) + 0x170))
                    (*(longlong *)(param_1 + 0x110) + 0x10);
  if ((iVar1 != 0) && (param_3 == iVar1)) {
                    /* WARNING: Could not recover jumptable at 0x00014046a5d1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    iVar1 = MulDiv(param_2,0x5a,100);
    return iVar1;
  }
  return param_2;
}

// ==== CMsgItem::helper_14046add0  @14046add0  [medium:callgraph-r1]  (orig: FUN_14046add0)
undefined8 FUN_14046add0(longlong param_1)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  
  cVar1 = FUN_1402bcb40(*(undefined8 *)(param_1 + 0x110));
  if (cVar1 != '\0') {
    lVar3 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x110) + 0x10) + 0x160))
                      (*(longlong *)(param_1 + 0x110) + 0x10);
    iVar2 = (**(code **)(**(longlong **)(lVar3 + 0x58) + 0x10))(*(longlong **)(lVar3 + 0x58),0x10);
    if (iVar2 == 2) {
      iVar2 = (**(code **)(**(longlong **)(lVar3 + 0x58) + 0x10))(*(longlong **)(lVar3 + 0x58),5);
      if (iVar2 != 0) {
        return 0;
      }
    }
  }
  return 1;
}

// ==== CMsgItem::helper_14046b340  @14046b340  [medium:callgraph-r1]  (orig: FUN_14046b340)
bool FUN_14046b340(longlong param_1)

{
  return *(longlong *)(param_1 + 0x88) != 0;
}

// ==== CMsgItem::helper_14046c650  @14046c650  [medium:callgraph-r1]  (orig: FUN_14046c650)
bool FUN_14046c650(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  bool bVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x21);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar8) {
    bVar9 = false;
  }
  else {
    lVar8 = 0;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    bVar9 = *(int *)(lVar4 + 0x1c) != 0;
  }
  return bVar9;
}

// ==== CMsgItem::helper_14046c750  @14046c750  [medium:callgraph-r1]  (orig: FUN_14046c750)
ulonglong FUN_14046c750(longlong param_1,uint param_2,undefined4 *param_3,undefined4 *param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  ulonglong extraout_RAX;
  ulonglong uVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong lVar12;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  ulonglong local_20;
  
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  cVar1 = *(char *)((longlong)puVar10 + 0x25);
  puVar5 = *(undefined8 **)(param_1 + 0x80);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar10[2];
      puVar10 = puVar5;
    }
    else {
      puVar7 = (undefined8 *)*puVar10;
    }
    puVar5 = puVar10;
    puVar10 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x25);
  }
  puVar10 = *(undefined8 **)(param_1 + 0x80);
  local_40 = puVar5;
  local_48 = *(longlong *)(param_1 + 0x50);
  if (*(longlong *)(param_1 + 0x50) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar10) || (param_2 < *(uint *)(puVar5 + 3))) {
    plVar9 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x80);
    local_38 = *(longlong *)(param_1 + 0x50);
  }
  else {
    plVar9 = &local_48;
  }
  plVar3 = (longlong *)*plVar9;
  uVar4 = *(ulonglong *)(param_1 + 0x80);
  local_28 = plVar3;
  uVar8 = plVar9[1];
  local_20 = uVar8;
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x50))) {
    _invalid_parameter_noinfo();
    uVar8 = extraout_RAX;
  }
  uVar6 = local_20;
  if (local_20 == uVar4) {
    uVar8 = uVar8 & 0xffffffffffffff00;
  }
  else {
    lVar11 = 0;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar11;
    }
    else {
      lVar12 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *param_3 = *(undefined4 *)(uVar6 + 0x1c);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar11 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(undefined4 *)(uVar6 + 0x20);
    *param_4 = uVar2;
    uVar8 = CONCAT71((uint7)(uint3)((uint)uVar2 >> 8),1);
  }
  return uVar8;
}

// ==== CMsgItem::helper_14046c8a0  @14046c8a0  [medium:callgraph-r1]  (orig: FUN_14046c8a0)
ulonglong FUN_14046c8a0(longlong param_1,uint param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  ulonglong extraout_RAX;
  ulonglong uVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  ulonglong local_10;
  
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0xc0))[1];
  cVar1 = *(char *)((longlong)puVar10 + 0x21);
  puVar5 = *(undefined8 **)(param_1 + 0xc0);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar10[2];
      puVar10 = puVar5;
    }
    else {
      puVar7 = (undefined8 *)*puVar10;
    }
    puVar5 = puVar10;
    puVar10 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x21);
  }
  puVar10 = *(undefined8 **)(param_1 + 0xc0);
  local_30 = puVar5;
  local_38 = *(longlong *)(param_1 + 0x90);
  if (*(longlong *)(param_1 + 0x90) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar10) || (param_2 < *(uint *)(puVar5 + 3))) {
    plVar9 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xc0);
    local_28 = *(longlong *)(param_1 + 0x90);
  }
  else {
    plVar9 = &local_38;
  }
  plVar3 = (longlong *)*plVar9;
  uVar4 = *(ulonglong *)(param_1 + 0xc0);
  local_18 = plVar3;
  uVar8 = plVar9[1];
  local_10 = uVar8;
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x90))) {
    _invalid_parameter_noinfo();
    uVar8 = extraout_RAX;
  }
  uVar6 = local_10;
  if (local_10 == uVar4) {
    uVar8 = uVar8 & 0xffffffffffffff00;
  }
  else {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = 0;
    }
    else {
      lVar11 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(undefined4 *)(uVar6 + 0x1c);
    *param_3 = uVar2;
    uVar8 = CONCAT71((uint7)(uint3)((uint)uVar2 >> 8),1);
  }
  return uVar8;
}

// ==== CMsgItem::helper_14046c9d0  @14046c9d0  [medium:callgraph-r1]  (orig: FUN_14046c9d0)
ulonglong FUN_14046c9d0(longlong param_1,uint param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  ulonglong extraout_RAX;
  ulonglong uVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  ulonglong local_10;
  
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x100))[1];
  cVar1 = *(char *)((longlong)puVar10 + 0x21);
  puVar5 = *(undefined8 **)(param_1 + 0x100);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar10[2];
      puVar10 = puVar5;
    }
    else {
      puVar7 = (undefined8 *)*puVar10;
    }
    puVar5 = puVar10;
    puVar10 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x21);
  }
  puVar10 = *(undefined8 **)(param_1 + 0x100);
  local_30 = puVar5;
  local_38 = *(longlong *)(param_1 + 0xd0);
  if (*(longlong *)(param_1 + 0xd0) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar10) || (param_2 < *(uint *)(puVar5 + 3))) {
    plVar9 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x100);
    local_28 = *(longlong *)(param_1 + 0xd0);
  }
  else {
    plVar9 = &local_38;
  }
  plVar3 = (longlong *)*plVar9;
  uVar4 = *(ulonglong *)(param_1 + 0x100);
  local_18 = plVar3;
  uVar8 = plVar9[1];
  local_10 = uVar8;
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0xd0))) {
    _invalid_parameter_noinfo();
    uVar8 = extraout_RAX;
  }
  uVar6 = local_10;
  if (local_10 == uVar4) {
    uVar8 = uVar8 & 0xffffffffffffff00;
  }
  else {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = 0;
    }
    else {
      lVar11 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(undefined4 *)(uVar6 + 0x1c);
    *param_3 = uVar2;
    uVar8 = CONCAT71((uint7)(uint3)((uint)uVar2 >> 8),1);
  }
  return uVar8;
}

