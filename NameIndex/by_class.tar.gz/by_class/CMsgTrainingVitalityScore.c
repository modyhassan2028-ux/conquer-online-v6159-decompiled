// ==== CMsgTrainingVitalityScore::ctor_or_dtor  @14047dd50  [high:vtable-assign]  (orig: FUN_14047dd50)
undefined8 * FUN_14047dd50(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTrainingVitalityScore::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTrainingVitalityScore::ctor_or_dtor  @14047dda0  [high:vtable-assign]  (orig: FUN_14047dda0)
void FUN_14047dda0(undefined8 *param_1)

{
  *param_1 = CMsgTrainingVitalityScore::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTrainingVitalityScore::vfunc_1  @14047ddd0  [high:rtti-vtable]  (orig: FUN_14047ddd0)
bool FUN_14047ddd0(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9e7;
    }
  }
  return false;
}

// ==== CMsgTrainingVitalityScore::vfunc_3  @14047dea0  [high:rtti-vtable]  (orig: FUN_14047dea0)
void FUN_14047dea0(void)

{
  return;
}

// ==== CMsgTrainingVitalityScore::ctor_or_dtor  @14047deb0  [high:vtable-assign]  (orig: FUN_14047deb0)
undefined8 * FUN_14047deb0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTrainingVitalityScore::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

