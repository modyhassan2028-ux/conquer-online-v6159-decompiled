// ==== CMsgShowHandCallAction@texasholdem::helper_1403c9810  @1403c9810  [medium:callgraph-r0]  (orig: FUN_1403c9810)
undefined8 FUN_1403c9810(longlong param_1)

{
  char cVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong lVar7;
  
  puVar2 = *(undefined8 **)(param_1 + 0x138);
  plVar3 = *(longlong **)(param_1 + 0x108);
  puVar6 = (undefined8 *)*puVar2;
  while( true ) {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar6 == puVar2) {
      return 0;
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar3;
    }
    if (puVar6 == *(undefined8 **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar6 + 100) != '\0') break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar6 + 0x81) == '\0') {
      puVar4 = (undefined8 *)puVar6[2];
      if (*(char *)((longlong)puVar4 + 0x81) == '\0') {
        cVar1 = *(char *)((longlong)*puVar4 + 0x81);
        puVar6 = puVar4;
        puVar4 = (undefined8 *)*puVar4;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar4 + 0x81);
          puVar6 = puVar4;
          puVar4 = (undefined8 *)*puVar4;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar6[1] + 0x81);
        puVar5 = (undefined8 *)puVar6[1];
        puVar4 = puVar6;
        while ((puVar6 = puVar5, cVar1 == '\0' && (puVar4 == (undefined8 *)puVar6[2]))) {
          cVar1 = *(char *)((longlong)puVar6[1] + 0x81);
          puVar5 = (undefined8 *)puVar6[1];
          puVar4 = puVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return 1;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1403cf3e0  @1403cf3e0  [medium:callgraph-r1]  (orig: FUN_1403cf3e0)
undefined8 FUN_1403cf3e0(longlong param_1,byte *param_2)

{
  byte bVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  byte bVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  int iVar11;
  uint uVar12;
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_38;
  longlong local_30;
  
  bVar1 = *param_2;
  uVar12 = (uint)bVar1;
  iVar11 = 1;
  do {
    uVar12 = uVar12 + 1;
    bVar7 = (char)uVar12 + (char)((int)uVar12 / 9) * -9;
    *param_2 = bVar7;
    puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x138))[1];
    cVar2 = *(char *)((longlong)puVar9 + 0x81);
    puVar4 = *(undefined8 **)(param_1 + 0x138);
    while (cVar2 == '\0') {
      if (*(byte *)(puVar9 + 3) < bVar7) {
        puVar6 = (undefined8 *)puVar9[2];
        puVar9 = puVar4;
      }
      else {
        puVar6 = (undefined8 *)*puVar9;
      }
      puVar4 = puVar9;
      puVar9 = puVar6;
      cVar2 = *(char *)((longlong)puVar6 + 0x81);
    }
    puVar9 = *(undefined8 **)(param_1 + 0x138);
    local_50 = puVar4;
    local_58 = *(longlong *)(param_1 + 0x108);
    if (*(longlong *)(param_1 + 0x108) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar4 == puVar9) || (*param_2 < *(byte *)(puVar4 + 3))) {
      plVar8 = &local_48;
      local_40 = *(undefined8 *)(param_1 + 0x138);
      local_48 = *(longlong *)(param_1 + 0x108);
    }
    else {
      plVar8 = &local_58;
    }
    plVar3 = (longlong *)*plVar8;
    lVar10 = *(longlong *)(param_1 + 0x138);
    local_38 = plVar3;
    local_30 = plVar8[1];
    if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x108))) {
      _invalid_parameter_noinfo();
    }
    lVar5 = local_30;
    if (local_30 != lVar10) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar3;
      }
      if (lVar5 == *(longlong *)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if ((*(char *)(lVar5 + 0x60) == '\x02') && (*(char *)(lVar5 + 0x62) == '\0')) {
        return 1;
      }
    }
    iVar11 = iVar11 + 1;
    if (8 < iVar11) {
      *param_2 = bVar1;
      return 0;
    }
  } while( true );
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1403cf560  @1403cf560  [medium:callgraph-r2]  (orig: FUN_1403cf560)
void FUN_1403cf560(longlong param_1,ushort *param_2,longlong *param_3,longlong *param_4)

{
  ushort uVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *local_58;
  longlong local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_38;
  
  local_40 = 0xfffffffffffffffe;
  if (*(int *)(param_1 + 0x210) != 0) {
    FUN_1403ccc50(param_1 + 0x108,&local_58,param_1 + 0x189);
    lVar4 = *(longlong *)(param_1 + 0x138);
    lVar7 = 0;
    local_38 = *(longlong **)(param_1 + 0x108);
    if ((local_58 == (longlong *)0x0) || (local_58 != local_38)) {
      _invalid_parameter_noinfo();
    }
    if (local_50 != lVar4) {
      if (local_58 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = lVar7;
      }
      else {
        lVar4 = *local_58;
      }
      if (local_50 == *(longlong *)(lVar4 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
      plVar3 = (longlong *)FUN_140087650(uVar2);
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x98))(plVar3,*(undefined4 *)(local_50 + 0x20));
      if (plVar3 != (longlong *)0x0) {
        uVar1 = *param_2;
        *param_2 = uVar1 | 4;
        if (*(int *)(param_1 + 0x1b8) == 1) {
          *param_2 = uVar1 | 0x24;
        }
        if (*(longlong *)(local_50 + 0x58) < *(longlong *)(param_1 + 0x198)) {
          if (*(int *)(param_1 + 0x1bc) == 0) {
            lVar4 = (**(code **)(*plVar3 + 0x60))(plVar3);
            if (*(longlong *)(param_1 + 0x198) - *(longlong *)(local_50 + 0x58) < lVar4) {
              *param_2 = *param_2 | 2;
            }
            else {
              *param_2 = *param_2 | 0x20;
            }
          }
          else if (*(int *)(param_1 + 0x1bc) == 1) {
            if ((uint)(*(int *)(param_1 + 0x198) - *(int *)(local_50 + 0x58)) <
                *(uint *)((longlong)plVar3 + 0xfa4)) {
              *param_2 = *param_2 | 2;
            }
            else {
              *param_2 = *param_2 | 0x20;
            }
          }
          lVar4 = *(longlong *)(param_1 + 0x198);
          if (*(int *)(param_1 + 0x1b8) == 0) {
            if ((*(char *)(param_1 + 0x208) == '\x01') || (*(char *)(param_1 + 0x208) == '\x02')) {
              lVar7 = (longlong)*(int *)(param_1 + 0x1c0);
              plVar6 = (longlong *)(lVar4 + lVar7);
              lVar8 = lVar4 - *(longlong *)(local_50 + 0x58);
              *param_3 = lVar8;
              *param_4 = lVar7;
              local_58 = plVar6;
              local_48 = lVar8;
            }
            else {
              lVar7 = (longlong)(*(int *)(param_1 + 0x1c0) * 2);
              plVar6 = (longlong *)(lVar4 + lVar7);
              lVar8 = lVar4 - *(longlong *)(local_50 + 0x58);
              *param_3 = lVar8;
              *param_4 = lVar7;
              local_58 = plVar6;
              local_48 = lVar8;
            }
          }
          else {
            lVar8 = *(longlong *)(param_1 + 0x1a0);
            plVar6 = (longlong *)(lVar4 + lVar8);
            local_58 = plVar6;
            local_48 = lVar8;
            if (*(int *)(param_1 + 0x1bc) == 0) {
              lVar7 = (**(code **)(*plVar3 + 0x60))(plVar3);
              lVar7 = lVar7 + (*(longlong *)(local_50 + 0x58) - *(longlong *)(param_1 + 0x198));
            }
            else if (*(int *)(param_1 + 0x1bc) == 1) {
              lVar7 = ((ulonglong)*(uint *)((longlong)plVar3 + 0xfa4) - lVar4) +
                      *(longlong *)(local_50 + 0x58);
            }
          }
          if (*(longlong *)(local_50 + 0x58) < (longlong)plVar6) {
            if (*(int *)(param_1 + 0x1bc) == 0) {
              if (((*(int *)(param_1 + 0x1b8) == 1) || (*(int *)(param_1 + 0x1b0) < 3)) &&
                 (lVar4 = (**(code **)(*plVar3 + 0x60))(plVar3),
                 (longlong)plVar6 - *(longlong *)(local_50 + 0x58) < lVar4)) {
                *param_2 = *param_2 | 0x10;
                *param_3 = lVar8;
                *param_4 = lVar7;
              }
            }
            else if ((*(int *)(param_1 + 0x1bc) == 1) &&
                    (((*(int *)(param_1 + 0x1b8) == 1 || (*(int *)(param_1 + 0x1b0) < 3)) &&
                     ((uint)((int)plVar6 - *(int *)(local_50 + 0x58)) <
                      *(uint *)((longlong)plVar3 + 0xfa4))))) {
              *param_2 = *param_2 | 0x10;
              *param_3 = lVar8;
              *param_4 = lVar7;
            }
          }
        }
        else {
          *param_2 = *param_2 | 8;
          lVar4 = *(longlong *)(param_1 + 0x198);
          if (*(int *)(param_1 + 0x1b8) == 0) {
            if ((*(char *)(param_1 + 0x208) == '\x01') || (*(char *)(param_1 + 0x208) == '\x02')) {
              lVar7 = (longlong)*(int *)(param_1 + 0x1c0);
              lVar5 = lVar4 + lVar7;
              lVar8 = lVar7;
            }
            else {
              lVar7 = (longlong)(*(int *)(param_1 + 0x1c0) * 2);
              lVar5 = lVar4 + lVar7;
              lVar8 = lVar7;
            }
          }
          else {
            lVar8 = (longlong)*(int *)(param_1 + 0x1c0);
            lVar5 = lVar4 + lVar8;
            if (*(int *)(param_1 + 0x1bc) == 0) {
              lVar7 = (**(code **)(*plVar3 + 0x60))(plVar3);
              lVar7 = (*(longlong *)(local_50 + 0x58) - *(longlong *)(param_1 + 0x198)) + lVar7;
            }
            else if (*(int *)(param_1 + 0x1bc) == 1) {
              lVar7 = ((ulonglong)*(uint *)((longlong)plVar3 + 0xfa4) - lVar4) +
                      *(longlong *)(local_50 + 0x58);
            }
          }
          if (*(longlong *)(local_50 + 0x58) < lVar5) {
            if (*(int *)(param_1 + 0x1bc) == 0) {
              lVar4 = (**(code **)(*plVar3 + 0x60))(plVar3);
              if (lVar5 - *(longlong *)(local_50 + 0x58) < lVar4) {
                if (*(char *)(param_1 + 0x208) == '\x01') {
                  *param_2 = *param_2 | 0x10;
                }
                else {
                  *param_2 = *param_2 | 1;
                }
                *param_3 = lVar8;
                *param_4 = lVar7;
              }
            }
            else if ((*(int *)(param_1 + 0x1bc) == 1) &&
                    ((uint)((int)lVar5 - *(int *)(local_50 + 0x58)) <
                     *(uint *)((longlong)plVar3 + 0xfa4))) {
              if (*(char *)(param_1 + 0x208) == '\x01') {
                *param_2 = *param_2 | 0x10;
              }
              else {
                *param_2 = *param_2 | 1;
              }
              *param_3 = lVar8;
              *param_4 = lVar7;
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1403d6c80  @1403d6c80  [medium:callgraph-r1]  (orig: FUN_1403d6c80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403d6c80(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  uint uVar3;
  longlong lVar4;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined4 local_480;
  undefined2 local_478 [4];
  longlong *local_470;
  longlong local_468;
  undefined8 local_460;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  FUN_1403ccc50(param_1 + 0x108,&local_470,param_1 + 0x189);
  lVar4 = *(longlong *)(param_1 + 0x138);
  if ((local_470 == (longlong *)0x0) || (local_470 != *(longlong **)(param_1 + 0x108))) {
    _invalid_parameter_noinfo();
  }
  if (local_468 != lVar4) {
    lVar4 = 0;
    if (local_470 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar4 = *local_470;
    }
    if (local_468 == *(longlong *)(lVar4 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    local_478[0] = 0;
    local_470 = (longlong *)0x0;
    local_460 = 0;
    FUN_1403cf560(param_1,local_478,&local_470,&local_460);
    uVar3 = 0xf;
    if (0 < (int)*(uint *)(param_1 + 0x22c)) {
      uVar3 = *(uint *)(param_1 + 0x22c);
    }
    FUN_1404dae00(local_448);
    local_480 = *(undefined4 *)(local_468 + 0x20);
    local_488 = local_460;
    cVar1 = FUN_1404daeb0(local_448,uVar3 & 0xffff,local_478[0],local_470);
    if (cVar1 != '\0') {
      FUN_1403d63a0(param_1,local_448,0);
    }
    *(uint *)(param_1 + 0x240) = uVar3;
    uVar2 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x244) = uVar2 / 1000;
    *(undefined4 *)(param_1 + 0x22c) = 0;
    FUN_1404dae50(local_448);
  }
  return;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1403e50e0  @1403e50e0  [medium:callgraph-r0]  (orig: FUN_1403e50e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1403e50e0(longlong param_1,char param_2,longlong *param_3,longlong param_4,char param_5)

{
  longlong *plVar1;
  char cVar2;
  ulong uVar3;
  int iVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong lVar8;
  char local_res10 [24];
  undefined1 auStack_958 [32];
  undefined8 local_938;
  uint local_930;
  char *local_928;
  undefined4 local_920;
  undefined8 local_918;
  undefined4 local_910;
  longlong local_908;
  longlong *local_8f8;
  longlong local_8f0;
  longlong *local_8e8;
  undefined8 local_8d8;
  undefined1 local_8c8 [1104];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8d8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_958;
  if (*(char *)(param_1 + 0x208) == '\0') {
    return 0;
  }
  if (param_2 != *(char *)(param_1 + 0x189)) {
    return 0;
  }
  if ((param_3 == (longlong *)0x0) || (*(int *)(param_1 + 0x210) == 0)) {
    return 0;
  }
  local_res10[0] = param_2;
  if ((*(int *)(param_1 + 0x23c) != 0) &&
     (uVar3 = tq::TimeGet(0),
     uVar3 / 1000 < (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)))) {
    return 0;
  }
  if ((*(int *)(param_1 + 0x234) != 0) &&
     (uVar3 = tq::TimeGet(0),
     uVar3 / 1000 < (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)))) {
    return 0;
  }
  if (((*(int *)(param_1 + 0x23c) == 0) ||
      (uVar3 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)) <= uVar3 / 1000)) &&
     ((*(int *)(param_1 + 0x234) == 0 ||
      (uVar3 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)) <= uVar3 / 1000)))) {
    FUN_1403ccc50(param_1 + 0x108,&local_8f8,local_res10);
    lVar6 = *(longlong *)(param_1 + 0x138);
    local_8e8 = *(longlong **)(param_1 + 0x108);
    if ((local_8f8 == (longlong *)0x0) || (local_8f8 != local_8e8)) {
      _invalid_parameter_noinfo();
    }
    if (local_8f0 == lVar6) {
      uVar7 = 0;
    }
    else {
      if (local_8f8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *local_8f8;
      }
      if (local_8f0 == *(longlong *)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar4 = (**(code **)(*param_3 + 8))(param_3);
      if (*(int *)(local_8f0 + 0x20) == iVar4) {
        lVar6 = *(longlong *)(param_1 + 0x198);
        if (*(longlong *)(local_8f0 + 0x58) < lVar6) {
          uVar7 = 0;
        }
        else {
          if (*(int *)(param_1 + 0x1b8) == 0) {
            if ((*(char *)(param_1 + 0x208) == '\x01') || (*(char *)(param_1 + 0x208) == '\x02')) {
              local_8f8 = (longlong *)(lVar6 + *(int *)(param_1 + 0x1c0));
            }
            else {
              local_8f8 = (longlong *)(lVar6 + *(int *)(param_1 + 0x1c0) * 2);
            }
          }
          else {
            if (param_4 < *(int *)(param_1 + 0x1c0)) {
              return 0;
            }
            local_8f8 = (longlong *)(lVar6 + param_4);
          }
          plVar1 = local_8f8;
          if (*(longlong *)(local_8f0 + 0x58) < (longlong)local_8f8) {
            *(longlong *)(param_1 + 0x1a0) =
                 (longlong)local_8f8 + (*(longlong *)(param_1 + 0x1a0) - lVar6);
            if (*(int *)(param_1 + 0x1bc) == 0) {
              lVar8 = (longlong)local_8f8 - *(longlong *)(local_8f0 + 0x58);
              lVar6 = (**(code **)(*param_3 + 0x60))(param_3);
              if (lVar6 <= lVar8) {
                return 0;
              }
              cVar2 = (**(code **)(*param_3 + 0x178))(param_3,lVar8,1);
              if (cVar2 != '\0') {
                lVar8 = param_3[0x1e2];
                lVar6 = *(longlong *)(local_8f0 + 0x58);
                uVar7 = (**(code **)(param_3[2] + 0x18))();
                local_920 = (**(code **)(*param_3 + 8))(param_3);
                local_928 = "false";
                if (param_5 != '\0') {
                  local_928 = "true";
                }
                local_930 = (uint)*(byte *)(param_1 + 0x208);
                local_938 = CONCAT44(local_938._4_4_,*(undefined4 *)(param_1 + 0x214));
                local_918 = uVar7;
                local_910 = (int)lVar8;
                local_908 = (longlong)plVar1 - lVar6;
                tq::MyLogSave("gmlog/texasholdem",
                              "NpcOwner[%u] Table[%u] Index[%u] Bet[%d] UserAction[%s] money lose: %u\t%s\t%u\t700\t702\t%I64d\t"
                             );
              }
              *(longlong **)(param_1 + 0x198) = plVar1;
              *(longlong *)(param_1 + 0x1a8) =
                   (longlong)plVar1 +
                   (*(longlong *)(param_1 + 0x1a8) - *(longlong *)(local_8f0 + 0x58));
              *(longlong **)(local_8f0 + 0x58) = plVar1;
            }
            else if (*(int *)(param_1 + 0x1bc) == 1) {
              if ((longlong)(ulonglong)*(uint *)((longlong)param_3 + 0xfa4) <=
                  (longlong)local_8f8 - *(longlong *)(local_8f0 + 0x58)) {
                return 0;
              }
              local_938 = 0;
              cVar2 = (**(code **)(param_3[2] + 0x2e0))
                                (param_3 + 2,0x1d,
                                 *(longlong *)(local_8f0 + 0x58) - (longlong)local_8f8,1);
              if (cVar2 != '\0') {
                iVar4 = *(int *)(local_8f0 + 0x58);
                uVar5 = (**(code **)(*param_3 + 8))(param_3);
                local_938._0_4_ = (int)plVar1 - iVar4;
                FUN_1401742b0(param_3,0xf,uVar5);
                lVar6 = param_3[0x1e2];
                iVar4 = *(int *)(local_8f0 + 0x58);
                uVar7 = (**(code **)(param_3[2] + 0x18))();
                local_920 = (**(code **)(*param_3 + 8))(param_3);
                local_928 = "false";
                if (param_5 != '\0') {
                  local_928 = "true";
                }
                local_908 = CONCAT44(local_908._4_4_,(int)plVar1 - iVar4);
                local_930 = (uint)*(byte *)(param_1 + 0x208);
                local_938 = CONCAT44(local_938._4_4_,*(undefined4 *)(param_1 + 0x214));
                local_918 = uVar7;
                local_910 = (int)lVar6;
                tq::MyLogSave("gmlog/texasholdem",
                              "NpcOwner[%u] Table[%u] Index[%u] Bet[%d] UserAction[%s] emoney lose: %u\t%s\t%u\t700\t702\t%d\t"
                             );
                *(longlong **)(param_1 + 0x198) = plVar1;
                *(longlong *)(param_1 + 0x1a8) =
                     (longlong)plVar1 +
                     (*(longlong *)(param_1 + 0x1a8) - *(longlong *)(local_8f0 + 0x58));
                *(longlong **)(local_8f0 + 0x58) = plVar1;
              }
            }
            *(undefined1 *)(local_8f0 + 0x61) = 1;
            if (*(longlong *)(param_1 + 0x218) == 0) {
              FUN_140459c90(local_8c8);
              cVar2 = FUN_140459d40(local_8c8,2,*(undefined8 *)(param_1 + 0x1a8));
              if (cVar2 != '\0') {
                FUN_1403d74e0(param_1,local_8c8,0);
              }
              FUN_140459ce0(local_8c8);
            }
            else {
              FUN_140362560(local_8c8);
              cVar2 = FUN_140362910(local_8c8,0xea,*(undefined4 *)(param_1 + 0x210),
                                    *(undefined8 *)(param_1 + 0x1a8));
              if (cVar2 != '\0') {
                FUN_1403d74e0(param_1,local_8c8,0);
              }
              FUN_1403625e0(local_8c8);
            }
            FUN_140452b50(local_478);
            local_930 = (**(code **)(*param_3 + 8))(param_3);
            local_938 = *(undefined8 *)(local_8f0 + 0x58);
            cVar2 = FUN_140452c00(local_478,0,1,*(undefined8 *)(param_1 + 0x1a0));
            if (cVar2 != '\0') {
              FUN_1403d63a0(param_1,local_478,0);
            }
            *(undefined4 *)(param_1 + 0x244) = 0;
            *(undefined4 *)(param_1 + 0x240) = 0;
            cVar2 = FUN_1403e44e0(param_1);
            if (cVar2 == '\0') {
              cVar2 = FUN_1403cf3e0(param_1,param_1 + 0x189);
              if (cVar2 == '\0') {
                FUN_140452ba0(local_478);
                return 0;
              }
              FUN_1403d6c80(param_1);
            }
            FUN_140452ba0(local_478);
            uVar7 = 1;
          }
          else {
            uVar7 = 0;
          }
        }
      }
      else {
        uVar7 = 0;
      }
    }
  }
  else {
    uVar7 = 0;
  }
  return uVar7;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1403e5710  @1403e5710  [medium:callgraph-r0]  (orig: FUN_1403e5710)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403e5710(longlong param_1,char param_2,longlong *param_3,char param_4)

{
  char cVar1;
  ulong uVar2;
  int iVar3;
  undefined8 uVar4;
  longlong lVar5;
  char local_res10 [24];
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  uint local_4d0;
  char *local_4c8;
  undefined4 local_4c0;
  undefined8 local_4b8;
  longlong *local_4a8;
  longlong local_4a0;
  longlong *local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (*(char *)(param_1 + 0x208) == '\0') {
    return 0;
  }
  if (param_2 != *(char *)(param_1 + 0x189)) {
    return 0;
  }
  if ((param_3 == (longlong *)0x0) || (*(int *)(param_1 + 0x210) == 0)) {
    return 0;
  }
  local_res10[0] = param_2;
  if ((*(int *)(param_1 + 0x23c) != 0) &&
     (uVar2 = tq::TimeGet(0),
     uVar2 / 1000 < (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)))) {
    return 0;
  }
  if ((*(int *)(param_1 + 0x234) != 0) &&
     (uVar2 = tq::TimeGet(0),
     uVar2 / 1000 < (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)))) {
    return 0;
  }
  if (((*(int *)(param_1 + 0x23c) == 0) ||
      (uVar2 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)) <= uVar2 / 1000)) &&
     ((*(int *)(param_1 + 0x234) == 0 ||
      (uVar2 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)) <= uVar2 / 1000)))) {
    FUN_1403ccc50(param_1 + 0x108,&local_4a8,local_res10);
    lVar5 = *(longlong *)(param_1 + 0x138);
    local_498 = *(longlong **)(param_1 + 0x108);
    if ((local_4a8 == (longlong *)0x0) || (local_4a8 != local_498)) {
      _invalid_parameter_noinfo();
    }
    if (local_4a0 == lVar5) {
      uVar4 = 0;
    }
    else {
      if (local_4a8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *local_4a8;
      }
      if (local_4a0 == *(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar3 = (**(code **)(*param_3 + 8))(param_3);
      if (*(int *)(local_4a0 + 0x20) == iVar3) {
        if (*(longlong *)(local_4a0 + 0x58) < *(longlong *)(param_1 + 0x198)) {
          uVar4 = 0;
        }
        else {
          *(undefined1 *)(local_4a0 + 0x61) = 1;
          FUN_140452b50(local_478);
          local_4d0 = (**(code **)(*param_3 + 8))(param_3);
          local_4d8 = *(undefined8 *)(local_4a0 + 0x58);
          cVar1 = FUN_140452c00(local_478,0,8,*(undefined8 *)(param_1 + 0x1a0));
          if (cVar1 != '\0') {
            FUN_1403d63a0(param_1,local_478,0);
          }
          uVar4 = (**(code **)(param_3[2] + 0x18))();
          local_4c0 = (**(code **)(*param_3 + 8))(param_3);
          local_4c8 = "false";
          if (param_4 != '\0') {
            local_4c8 = "true";
          }
          local_4d0 = (uint)*(byte *)(param_1 + 0x208);
          local_4d8 = CONCAT44(local_4d8._4_4_,*(undefined4 *)(param_1 + 0x214));
          local_4b8 = uVar4;
          tq::MyLogSave("gmlog/texasholdem",
                        "NpcOwner[%u] Table[%u] Index[%u] Check[%d] UserAction[%s] User[%u][%s]");
          *(undefined4 *)(param_1 + 0x244) = 0;
          *(undefined4 *)(param_1 + 0x240) = 0;
          cVar1 = FUN_1403e44e0(param_1);
          if (cVar1 == '\0') {
            cVar1 = FUN_1403cf3e0(param_1,param_1 + 0x189);
            if (cVar1 == '\0') {
              FUN_140452ba0(local_478);
              return 0;
            }
            FUN_1403d6c80(param_1);
          }
          FUN_140452ba0(local_478);
          uVar4 = 1;
        }
      }
      else {
        uVar4 = 0;
      }
    }
  }
  else {
    uVar4 = 0;
  }
  return uVar4;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1403e5a50  @1403e5a50  [medium:callgraph-r0]  (orig: FUN_1403e5a50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403e5a50(longlong param_1,char param_2,longlong *param_3,char param_4)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  longlong lVar5;
  char local_res10 [24];
  undefined1 auStack_4f8 [32];
  longlong local_4d8;
  uint local_4d0;
  char *local_4c8;
  undefined4 local_4c0;
  undefined8 local_4b8;
  longlong *local_4a8;
  longlong local_4a0;
  longlong *local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (*(char *)(param_1 + 0x208) == '\0') {
    uVar4 = 0;
  }
  else if (param_2 == *(char *)(param_1 + 0x189)) {
    if (param_3 == (longlong *)0x0) {
      uVar4 = 0;
    }
    else {
      local_res10[0] = param_2;
      FUN_1403ccc50(param_1 + 0x108,&local_4a8,local_res10);
      lVar5 = *(longlong *)(param_1 + 0x138);
      local_498 = *(longlong **)(param_1 + 0x108);
      if ((local_4a8 == (longlong *)0x0) || (local_4a8 != local_498)) {
        _invalid_parameter_noinfo();
      }
      if (local_4a0 == lVar5) {
        uVar4 = 0;
      }
      else {
        if (local_4a8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *local_4a8;
        }
        if (local_4a0 == *(longlong *)(lVar5 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        iVar2 = (**(code **)(*param_3 + 8))(param_3);
        if (*(int *)(local_4a0 + 0x20) == iVar2) {
          if (*(char *)(local_4a0 + 0x60) == '\x02') {
            puVar3 = (undefined8 *)FUN_1403cff10(param_1 + 0x1c8,local_4a0 + 0x20);
            *puVar3 = *(undefined8 *)(local_4a0 + 0x58);
          }
          *(undefined1 *)(local_4a0 + 0x60) = 1;
          *(undefined1 *)(local_4a0 + 0x61) = 1;
          FUN_140452b50(local_478);
          lVar5 = *(longlong *)(local_4a0 + 0x58);
          local_4d0 = (**(code **)(*param_3 + 8))(param_3);
          local_4d8 = lVar5;
          cVar1 = FUN_140452c00(local_478,0,4,
                                (*(longlong *)(param_1 + 0x1a0) - *(longlong *)(param_1 + 0x198)) +
                                lVar5);
          if (cVar1 != '\0') {
            FUN_1403d63a0(param_1,local_478,0);
          }
          *(undefined4 *)(param_1 + 0x244) = 0;
          *(undefined4 *)(param_1 + 0x240) = 0;
          uVar4 = (**(code **)(param_3[2] + 0x18))();
          local_4c0 = (**(code **)(*param_3 + 8))(param_3);
          local_4c8 = "false";
          if (param_4 != '\0') {
            local_4c8 = "true";
          }
          local_4d0 = (uint)*(byte *)(param_1 + 0x208);
          local_4d8 = CONCAT44(local_4d8._4_4_,*(undefined4 *)(param_1 + 0x214));
          local_4b8 = uVar4;
          tq::MyLogSave("gmlog/texasholdem",
                        "NpcOwner[%u] Table[%u] Index[%u] Fold[%d] UserAction[%s] User[%u][%s]");
          cVar1 = FUN_1403e3280(param_1);
          if (cVar1 == '\0') {
            cVar1 = FUN_1403e44e0(param_1);
            if (cVar1 == '\0') {
              cVar1 = FUN_1403cf3e0(param_1,param_1 + 0x189);
              if (cVar1 == '\0') {
                FUN_140452ba0(local_478);
                return 0;
              }
              FUN_1403d6c80(param_1);
            }
            FUN_140452ba0(local_478);
            uVar4 = 1;
          }
          else {
            FUN_140452ba0(local_478);
            uVar4 = 1;
          }
        }
        else {
          uVar4 = 0;
        }
      }
    }
  }
  else {
    uVar4 = 0;
  }
  return uVar4;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1403e5cf0  @1403e5cf0  [medium:callgraph-r0]  (orig: FUN_1403e5cf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403e5cf0(longlong param_1,char param_2,longlong *param_3,char param_4)

{
  int iVar1;
  longlong lVar2;
  char cVar3;
  ulong uVar4;
  int iVar5;
  undefined4 uVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong lVar9;
  char local_res10 [24];
  undefined1 auStack_958 [32];
  undefined8 local_938;
  uint local_930;
  char *local_928;
  undefined4 local_920;
  undefined8 local_918;
  undefined4 local_910;
  longlong local_908;
  char local_8f8;
  longlong *local_8f0;
  longlong local_8e8;
  longlong *local_8e0;
  undefined8 local_8d0;
  undefined1 local_8c8 [1104];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8d0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_958;
  if (*(char *)(param_1 + 0x208) == '\0') {
    return 0;
  }
  if (param_2 != *(char *)(param_1 + 0x189)) {
    return 0;
  }
  if ((param_3 == (longlong *)0x0) || (*(int *)(param_1 + 0x210) == 0)) {
    return 0;
  }
  local_res10[0] = param_2;
  local_8f8 = param_4;
  if (((*(int *)(param_1 + 0x23c) == 0) ||
      (uVar4 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)) <= uVar4 / 1000)) &&
     ((*(int *)(param_1 + 0x234) == 0 ||
      (uVar4 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)) <= uVar4 / 1000)))) {
    if (((*(int *)(param_1 + 0x23c) == 0) ||
        (uVar4 = tq::TimeGet(0),
        (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)) <= uVar4 / 1000)) &&
       ((*(int *)(param_1 + 0x234) == 0 ||
        (uVar4 = tq::TimeGet(0),
        (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)) <= uVar4 / 1000)))) {
      FUN_1403ccc50(param_1 + 0x108,&local_8f0,local_res10);
      lVar2 = *(longlong *)(param_1 + 0x138);
      lVar9 = 0;
      local_8e0 = *(longlong **)(param_1 + 0x108);
      if ((local_8f0 == (longlong *)0x0) || (local_8f0 != local_8e0)) {
        _invalid_parameter_noinfo();
      }
      if (local_8e8 == lVar2) {
        uVar8 = 0;
      }
      else {
        if (local_8f0 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar9 = *local_8f0;
        }
        if (local_8e8 == *(longlong *)(lVar9 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        iVar5 = (**(code **)(*param_3 + 8))(param_3);
        if (*(int *)(local_8e8 + 0x20) == iVar5) {
          lVar2 = *(longlong *)(local_8e8 + 0x58);
          lVar9 = *(longlong *)(param_1 + 0x198);
          if (lVar2 < lVar9) {
            if (*(int *)(param_1 + 0x1bc) == 0) {
              lVar7 = (**(code **)(*param_3 + 0x60))(param_3);
              if (lVar7 <= lVar9 - lVar2) {
                return 0;
              }
              cVar3 = (**(code **)(*param_3 + 0x178))(param_3,lVar9 - lVar2,1);
              if (cVar3 != '\0') {
                lVar7 = param_3[0x1e2];
                lVar2 = *(longlong *)(param_1 + 0x198);
                lVar9 = *(longlong *)(local_8e8 + 0x58);
                uVar8 = (**(code **)(param_3[2] + 0x18))();
                local_920 = (**(code **)(*param_3 + 8))(param_3);
                local_928 = "false";
                if (local_8f8 != '\0') {
                  local_928 = "true";
                }
                local_930 = (uint)*(byte *)(param_1 + 0x208);
                local_938 = CONCAT44(local_938._4_4_,*(undefined4 *)(param_1 + 0x214));
                local_918 = uVar8;
                local_910 = (int)lVar7;
                local_908 = lVar2 - lVar9;
                tq::MyLogSave("gmlog/texasholdem",
                              "NpcOwner[%u] Table[%u] Index[%u] Call[%d] UserAction[%s] money lose: %u\t%s\t%u\t700\t702\t%I64d\t"
                             );
              }
              *(longlong *)(param_1 + 0x1a8) =
                   *(longlong *)(param_1 + 0x1a8) +
                   (*(longlong *)(param_1 + 0x198) - *(longlong *)(local_8e8 + 0x58));
              *(longlong *)(local_8e8 + 0x58) = *(longlong *)(param_1 + 0x198);
            }
            else if (*(int *)(param_1 + 0x1bc) == 1) {
              if ((longlong)(ulonglong)*(uint *)((longlong)param_3 + 0xfa4) <= lVar9 - lVar2) {
                return 0;
              }
              local_938 = 0;
              cVar3 = (**(code **)(param_3[2] + 0x2e0))(param_3 + 2,0x1d,lVar2 - lVar9,1);
              if (cVar3 != '\0') {
                iVar5 = *(int *)(param_1 + 0x198);
                iVar1 = *(int *)(local_8e8 + 0x58);
                uVar6 = (**(code **)(*param_3 + 8))(param_3);
                local_938._0_4_ = iVar5 - iVar1;
                FUN_1401742b0(param_3,0xf,uVar6);
                lVar2 = param_3[0x1e2];
                iVar5 = *(int *)(param_1 + 0x198);
                iVar1 = *(int *)(local_8e8 + 0x58);
                uVar8 = (**(code **)(param_3[2] + 0x18))(param_3 + 2);
                local_920 = (**(code **)(*param_3 + 8))(param_3);
                local_928 = "false";
                if (local_8f8 != '\0') {
                  local_928 = "true";
                }
                local_908 = CONCAT44(local_908._4_4_,iVar5 - iVar1);
                local_930 = (uint)*(byte *)(param_1 + 0x208);
                local_938 = CONCAT44(local_938._4_4_,*(undefined4 *)(param_1 + 0x214));
                local_918 = uVar8;
                local_910 = (int)lVar2;
                tq::MyLogSave("gmlog/texasholdem",
                              "NpcOwner[%u] Table[%u] Index[%u] Call[%d] UserAction[%s] emoney lose: %u\t%s\t%u\t700\t702\t%d\t"
                             );
                *(longlong *)(param_1 + 0x1a8) =
                     *(longlong *)(param_1 + 0x1a8) +
                     (*(longlong *)(param_1 + 0x198) - *(longlong *)(local_8e8 + 0x58));
                *(longlong *)(local_8e8 + 0x58) = *(longlong *)(param_1 + 0x198);
              }
            }
            *(undefined1 *)(local_8e8 + 0x61) = 1;
            if (*(longlong *)(param_1 + 0x218) == 0) {
              FUN_140459c90(local_8c8);
              cVar3 = FUN_140459d40(local_8c8,2,*(undefined8 *)(param_1 + 0x1a8));
              if (cVar3 != '\0') {
                FUN_1403d74e0(param_1,local_8c8,0);
              }
              FUN_140459ce0(local_8c8);
            }
            else {
              FUN_140362560(local_8c8);
              cVar3 = FUN_140362910(local_8c8,0xea,*(undefined4 *)(param_1 + 0x210),
                                    *(undefined8 *)(param_1 + 0x1a8));
              if (cVar3 != '\0') {
                FUN_1403d74e0(param_1,local_8c8,0);
              }
              FUN_1403625e0(local_8c8);
            }
            FUN_140452b50(local_478);
            local_930 = (**(code **)(*param_3 + 8))(param_3);
            local_938 = *(undefined8 *)(local_8e8 + 0x58);
            cVar3 = FUN_140452c00(local_478,0,2,*(undefined8 *)(param_1 + 0x1a0));
            if (cVar3 != '\0') {
              FUN_1403d63a0(param_1,local_478,0);
            }
            *(undefined4 *)(param_1 + 0x244) = 0;
            *(undefined4 *)(param_1 + 0x240) = 0;
            cVar3 = FUN_1403e44e0(param_1);
            if (cVar3 == '\0') {
              cVar3 = FUN_1403cf3e0(param_1,param_1 + 0x189);
              if (cVar3 == '\0') {
                FUN_140452ba0(local_478);
                return 0;
              }
              FUN_1403d6c80(param_1);
            }
            FUN_140452ba0(local_478);
            uVar8 = 1;
          }
          else {
            uVar8 = 0;
          }
        }
        else {
          uVar8 = 0;
        }
      }
    }
    else {
      uVar8 = 0;
    }
    return uVar8;
  }
  return 0;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1403e62b0  @1403e62b0  [medium:callgraph-r0]  (orig: FUN_1403e62b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403e62b0(longlong param_1,char param_2,longlong *param_3,longlong param_4)

{
  longlong *plVar1;
  char cVar2;
  ulong uVar3;
  int iVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong lVar8;
  char local_res10 [24];
  undefined1 auStack_948 [32];
  undefined8 local_928;
  uint local_920;
  undefined4 local_918;
  undefined8 local_910;
  undefined4 local_908;
  longlong local_900;
  longlong *local_8f8;
  longlong local_8f0;
  longlong local_8e8;
  undefined8 local_8e0;
  longlong *local_8d8;
  undefined1 local_8c8 [1104];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8e0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_948;
  if (*(char *)(param_1 + 0x208) == '\0') {
    return 0;
  }
  if (param_2 != *(char *)(param_1 + 0x189)) {
    return 0;
  }
  if ((param_3 == (longlong *)0x0) || (*(int *)(param_1 + 0x210) == 0)) {
    return 0;
  }
  local_res10[0] = param_2;
  local_8e8 = param_4;
  if ((*(int *)(param_1 + 0x23c) != 0) &&
     (uVar3 = tq::TimeGet(0),
     uVar3 / 1000 < (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)))) {
    return 0;
  }
  if ((*(int *)(param_1 + 0x234) != 0) &&
     (uVar3 = tq::TimeGet(0),
     uVar3 / 1000 < (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)))) {
    return 0;
  }
  if (((*(int *)(param_1 + 0x23c) == 0) ||
      (uVar3 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)) <= uVar3 / 1000)) &&
     ((*(int *)(param_1 + 0x234) == 0 ||
      (uVar3 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)) <= uVar3 / 1000)))) {
    FUN_1403ccc50(param_1 + 0x108,&local_8f8,local_res10);
    lVar6 = *(longlong *)(param_1 + 0x138);
    local_8d8 = *(longlong **)(param_1 + 0x108);
    if ((local_8f8 == (longlong *)0x0) || (local_8f8 != local_8d8)) {
      _invalid_parameter_noinfo();
    }
    if (local_8f0 == lVar6) {
      uVar7 = 0;
    }
    else {
      if (local_8f8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *local_8f8;
      }
      if (local_8f0 == *(longlong *)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar4 = (**(code **)(*param_3 + 8))(param_3);
      if (*(int *)(local_8f0 + 0x20) == iVar4) {
        lVar6 = *(longlong *)(param_1 + 0x198);
        if ((*(longlong *)(local_8f0 + 0x58) < lVar6) ||
           ((param_2 == *(char *)(param_1 + 0x18a) && (*(char *)(param_1 + 0x208) == '\x01')))) {
          if (*(int *)(param_1 + 0x1b8) == 0) {
            if (2 < *(int *)(param_1 + 0x1b0)) {
              return 0;
            }
            if ((*(char *)(param_1 + 0x208) == '\x01') || (*(char *)(param_1 + 0x208) == '\x02')) {
              local_8f8 = (longlong *)(lVar6 + *(int *)(param_1 + 0x1c0));
            }
            else {
              local_8f8 = (longlong *)(lVar6 + *(int *)(param_1 + 0x1c0) * 2);
            }
          }
          else {
            if (local_8e8 < *(longlong *)(param_1 + 0x1a0)) {
              return 0;
            }
            local_8f8 = (longlong *)(lVar6 + local_8e8);
          }
          plVar1 = local_8f8;
          if (*(longlong *)(local_8f0 + 0x58) < (longlong)local_8f8) {
            *(longlong *)(param_1 + 0x1a0) =
                 (longlong)local_8f8 + (*(longlong *)(param_1 + 0x1a0) - lVar6);
            if (*(int *)(param_1 + 0x1bc) == 0) {
              lVar8 = (longlong)local_8f8 - *(longlong *)(local_8f0 + 0x58);
              lVar6 = (**(code **)(*param_3 + 0x60))(param_3);
              if (lVar6 <= lVar8) {
                return 0;
              }
              cVar2 = (**(code **)(*param_3 + 0x178))(param_3,lVar8,1);
              if (cVar2 != '\0') {
                lVar8 = param_3[0x1e2];
                lVar6 = *(longlong *)(local_8f0 + 0x58);
                uVar7 = (**(code **)(param_3[2] + 0x18))();
                local_918 = (**(code **)(*param_3 + 8))(param_3);
                local_920 = (uint)*(byte *)(param_1 + 0x208);
                local_928 = CONCAT44(local_928._4_4_,*(undefined4 *)(param_1 + 0x214));
                local_910 = uVar7;
                local_908 = (int)lVar8;
                local_900 = (longlong)plVar1 - lVar6;
                tq::MyLogSave("gmlog/texasholdem",
                              "NpcOwner[%u] Table[%u] Index[%u] Raise[%d] money lose: %u\t%s\t%u\t700\t702\t%I64d\t"
                             );
              }
              *(longlong **)(param_1 + 0x198) = plVar1;
              *(longlong *)(param_1 + 0x1a8) =
                   (longlong)plVar1 +
                   (*(longlong *)(param_1 + 0x1a8) - *(longlong *)(local_8f0 + 0x58));
              *(longlong **)(local_8f0 + 0x58) = plVar1;
            }
            else if (*(int *)(param_1 + 0x1bc) == 1) {
              if ((longlong)(ulonglong)*(uint *)((longlong)param_3 + 0xfa4) <=
                  (longlong)local_8f8 - *(longlong *)(local_8f0 + 0x58)) {
                return 0;
              }
              local_928 = 0;
              cVar2 = (**(code **)(param_3[2] + 0x2e0))
                                (param_3 + 2,0x1d,
                                 *(longlong *)(local_8f0 + 0x58) - (longlong)local_8f8,1);
              if (cVar2 != '\0') {
                iVar4 = *(int *)(local_8f0 + 0x58);
                uVar5 = (**(code **)(*param_3 + 8))(param_3);
                local_928._0_4_ = (int)plVar1 - iVar4;
                FUN_1401742b0(param_3,0xf,uVar5);
                lVar6 = param_3[0x1e2];
                iVar4 = *(int *)(local_8f0 + 0x58);
                uVar7 = (**(code **)(param_3[2] + 0x18))();
                local_918 = (**(code **)(*param_3 + 8))(param_3);
                local_900 = CONCAT44(local_900._4_4_,(int)plVar1 - iVar4);
                local_920 = (uint)*(byte *)(param_1 + 0x208);
                local_928 = CONCAT44(local_928._4_4_,*(undefined4 *)(param_1 + 0x214));
                local_910 = uVar7;
                local_908 = (int)lVar6;
                tq::MyLogSave("gmlog/texasholdem",
                              "NpcOwner[%u] Table[%u] Index[%u] Raise[%d] emoney lose: %u\t%s\t%u\t700\t702\t%d\t"
                             );
                *(longlong **)(param_1 + 0x198) = plVar1;
                *(longlong *)(param_1 + 0x1a8) =
                     (longlong)plVar1 +
                     (*(longlong *)(param_1 + 0x1a8) - *(longlong *)(local_8f0 + 0x58));
                *(longlong **)(local_8f0 + 0x58) = plVar1;
              }
            }
            *(undefined1 *)(local_8f0 + 0x61) = 1;
            *(int *)(param_1 + 0x1b0) = *(int *)(param_1 + 0x1b0) + 1;
            if (*(longlong *)(param_1 + 0x218) == 0) {
              FUN_140459c90(local_8c8);
              cVar2 = FUN_140459d40(local_8c8,2,*(undefined8 *)(param_1 + 0x1a8));
              if (cVar2 != '\0') {
                FUN_1403d74e0(param_1,local_8c8,0);
              }
              FUN_140459ce0(local_8c8);
            }
            else {
              FUN_140362560(local_8c8);
              cVar2 = FUN_140362910(local_8c8,0xea,*(undefined4 *)(param_1 + 0x210),
                                    *(undefined8 *)(param_1 + 0x1a8));
              if (cVar2 != '\0') {
                FUN_1403d74e0(param_1,local_8c8,0);
              }
              FUN_1403625e0(local_8c8);
            }
            FUN_140452b50(local_478);
            local_920 = (**(code **)(*param_3 + 8))(param_3);
            local_928 = *(undefined8 *)(local_8f0 + 0x58);
            cVar2 = FUN_140452c00(local_478,0,0x10,*(undefined8 *)(param_1 + 0x1a0));
            if (cVar2 != '\0') {
              FUN_1403d63a0(param_1,local_478,0);
            }
            *(undefined4 *)(param_1 + 0x244) = 0;
            *(undefined4 *)(param_1 + 0x240) = 0;
            cVar2 = FUN_1403e44e0(param_1);
            if (cVar2 == '\0') {
              cVar2 = FUN_1403cf3e0(param_1,param_1 + 0x189);
              if (cVar2 == '\0') {
                FUN_140452ba0(local_478);
                return 0;
              }
              FUN_1403d6c80(param_1);
            }
            FUN_140452ba0(local_478);
            uVar7 = 1;
          }
          else {
            uVar7 = 0;
          }
        }
        else {
          uVar7 = 0;
        }
      }
      else {
        uVar7 = 0;
      }
    }
  }
  else {
    uVar7 = 0;
  }
  return uVar7;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1403e68e0  @1403e68e0  [medium:callgraph-r0]  (orig: FUN_1403e68e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403e68e0(longlong param_1,char param_2,longlong *param_3)

{
  uint uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  char cVar5;
  ulong uVar6;
  int iVar7;
  undefined4 uVar8;
  longlong lVar9;
  undefined8 uVar10;
  longlong lVar11;
  char local_res10 [24];
  undefined1 auStack_948 [32];
  longlong local_928;
  uint local_920;
  undefined4 local_918;
  undefined8 local_910;
  undefined4 local_908;
  longlong local_900;
  longlong *local_8f8;
  longlong local_8f0;
  longlong *local_8e8;
  undefined8 local_8d8;
  undefined1 local_8c8 [1104];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8d8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_948;
  if (*(char *)(param_1 + 0x208) == '\0') {
    return 0;
  }
  if (param_2 != *(char *)(param_1 + 0x189)) {
    return 0;
  }
  if ((param_3 == (longlong *)0x0) || (*(int *)(param_1 + 0x210) == 0)) {
    return 0;
  }
  local_res10[0] = param_2;
  if (((*(int *)(param_1 + 0x23c) == 0) ||
      (uVar6 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)) <= uVar6 / 1000)) &&
     ((*(int *)(param_1 + 0x234) == 0 ||
      (uVar6 = tq::TimeGet(0),
      (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)) <= uVar6 / 1000)))) {
    if (((*(int *)(param_1 + 0x23c) == 0) ||
        (uVar6 = tq::TimeGet(0),
        (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)) <= uVar6 / 1000)) &&
       ((*(int *)(param_1 + 0x234) == 0 ||
        (uVar6 = tq::TimeGet(0),
        (uint)(*(int *)(param_1 + 0x234) + *(int *)(param_1 + 0x230)) <= uVar6 / 1000)))) {
      FUN_1403ccc50(param_1 + 0x108,&local_8f8,local_res10);
      plVar4 = local_8f8;
      lVar9 = *(longlong *)(param_1 + 0x138);
      lVar11 = 0;
      local_8e8 = *(longlong **)(param_1 + 0x108);
      if ((local_8f8 == (longlong *)0x0) || (local_8f8 != local_8e8)) {
        _invalid_parameter_noinfo();
      }
      if (local_8f0 == lVar9) {
        uVar10 = 0;
      }
      else {
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar11 = *plVar4;
        }
        if (local_8f0 == *(longlong *)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        iVar7 = (**(code **)(*param_3 + 8))(param_3);
        if (*(int *)(local_8f0 + 0x20) == iVar7) {
          if (*(int *)(param_1 + 0x1bc) == 0) {
            lVar9 = (**(code **)(*param_3 + 0x60))(param_3);
            if (lVar9 < 1) {
              return 0;
            }
            if ((*(int *)(param_1 + 0x1b8) == 0) &&
               (lVar9 = (**(code **)(*param_3 + 0x60))(param_3),
               *(longlong *)(param_1 + 0x198) < lVar9 + *(longlong *)(local_8f0 + 0x58))) {
              return 0;
            }
            lVar11 = *(longlong *)(local_8f0 + 0x58);
            lVar9 = (**(code **)(*param_3 + 0x60))(param_3);
            lVar9 = lVar11 + lVar9;
            if (lVar9 <= lVar11) {
              return 0;
            }
            cVar5 = (**(code **)(*param_3 + 0x178))
                              (param_3,lVar9 - *(longlong *)(local_8f0 + 0x58),1);
            if (cVar5 != '\0') {
              lVar3 = param_3[0x1e2];
              lVar11 = *(longlong *)(local_8f0 + 0x58);
              uVar10 = (**(code **)(param_3[2] + 0x18))();
              local_918 = (**(code **)(*param_3 + 8))(param_3);
              local_920 = (uint)*(byte *)(param_1 + 0x208);
              local_928 = CONCAT44(local_928._4_4_,*(undefined4 *)(param_1 + 0x214));
              local_910 = uVar10;
              local_908 = (int)lVar3;
              local_900 = lVar9 - lVar11;
              tq::MyLogSave("gmlog/texasholdem",
                            "NpcOwner[%u] Table[%u] Index[%u] AllIn[%d] money lose: %u\t%s\t%u\t700\t702\t%I64d\t"
                           );
            }
            *(undefined1 *)(local_8f0 + 0x62) = 1;
            if (*(longlong *)(param_1 + 0x198) < lVar9) {
              *(longlong *)(param_1 + 0x1a0) =
                   *(longlong *)(param_1 + 0x1a0) + (lVar9 - *(longlong *)(param_1 + 0x198));
              *(longlong *)(param_1 + 0x198) = lVar9;
            }
            *(longlong *)(param_1 + 0x1a8) =
                 *(longlong *)(param_1 + 0x1a8) + (lVar9 - *(longlong *)(local_8f0 + 0x58));
            *(longlong *)(local_8f0 + 0x58) = lVar9;
          }
          else if (*(int *)(param_1 + 0x1bc) == 1) {
            uVar1 = *(uint *)((longlong)param_3 + 0xfa4);
            if (uVar1 == 0) {
              return 0;
            }
            if ((*(int *)(param_1 + 0x1b8) == 0) &&
               (*(longlong *)(param_1 + 0x198) <
                (longlong)((ulonglong)uVar1 + *(longlong *)(local_8f0 + 0x58)))) {
              return 0;
            }
            iVar7 = *(int *)(local_8f0 + 0x58) + uVar1;
            local_8f8 = (longlong *)(longlong)iVar7;
            if ((longlong)local_8f8 <= *(longlong *)(local_8f0 + 0x58)) {
              return 0;
            }
            local_928 = 0;
            cVar5 = (**(code **)(param_3[2] + 0x2e0))
                              (param_3 + 2,0x1d,(longlong)(*(int *)(local_8f0 + 0x58) - iVar7),1);
            if (cVar5 != '\0') {
              iVar2 = *(int *)(local_8f0 + 0x58);
              uVar8 = (**(code **)(*param_3 + 8))(param_3);
              local_928._0_4_ = iVar7 - iVar2;
              FUN_1401742b0(param_3,0xf,uVar8);
              lVar9 = param_3[0x1e2];
              iVar2 = *(int *)(local_8f0 + 0x58);
              uVar10 = (**(code **)(param_3[2] + 0x18))();
              local_918 = (**(code **)(*param_3 + 8))(param_3);
              local_900 = CONCAT44(local_900._4_4_,iVar7 - iVar2);
              local_920 = (uint)*(byte *)(param_1 + 0x208);
              local_928 = CONCAT44(local_928._4_4_,*(undefined4 *)(param_1 + 0x214));
              local_910 = uVar10;
              local_908 = (int)lVar9;
              tq::MyLogSave("gmlog/texasholdem",
                            "NpcOwner[%u] Table[%u] Index[%u] AllIn[%d] emoney lose: %u\t%s\t%u\t700\t702\t%d\t"
                           );
              *(undefined1 *)(local_8f0 + 0x62) = 1;
              if (*(longlong *)(param_1 + 0x198) < (longlong)local_8f8) {
                *(longlong *)(param_1 + 0x1a0) =
                     *(longlong *)(param_1 + 0x1a0) + (longlong)(iVar7 - *(int *)(param_1 + 0x198));
                *(longlong **)(param_1 + 0x198) = local_8f8;
              }
              *(longlong *)(param_1 + 0x1a8) =
                   *(longlong *)(param_1 + 0x1a8) + (longlong)(iVar7 - *(int *)(local_8f0 + 0x58));
              *(longlong **)(local_8f0 + 0x58) = local_8f8;
            }
          }
          *(undefined1 *)(local_8f0 + 0x61) = 1;
          if (*(longlong *)(param_1 + 0x218) == 0) {
            FUN_140459c90(local_8c8);
            cVar5 = FUN_140459d40(local_8c8,2,*(undefined8 *)(param_1 + 0x1a8));
            if (cVar5 != '\0') {
              FUN_1403d74e0(param_1,local_8c8,0);
            }
            FUN_140459ce0(local_8c8);
          }
          else {
            FUN_140362560(local_8c8);
            cVar5 = FUN_140362910(local_8c8,0xea,*(undefined4 *)(param_1 + 0x210),
                                  *(undefined8 *)(param_1 + 0x1a8));
            if (cVar5 != '\0') {
              FUN_1403d74e0(param_1,local_8c8,0);
            }
            FUN_1403625e0(local_8c8);
          }
          FUN_140452b50(local_478);
          lVar9 = *(longlong *)(local_8f0 + 0x58);
          local_920 = (**(code **)(*param_3 + 8))(param_3);
          local_928 = lVar9;
          cVar5 = FUN_140452c00(local_478,0,0x20,
                                (*(longlong *)(param_1 + 0x1a0) - *(longlong *)(param_1 + 0x198)) +
                                lVar9);
          if (cVar5 != '\0') {
            FUN_1403d63a0(param_1,local_478,0);
          }
          *(undefined4 *)(param_1 + 0x244) = 0;
          *(undefined4 *)(param_1 + 0x240) = 0;
          cVar5 = FUN_1403e44e0(param_1);
          if (cVar5 == '\0') {
            cVar5 = FUN_1403cf3e0(param_1,param_1 + 0x189);
            if (cVar5 == '\0') {
              FUN_140452ba0(local_478);
              return 0;
            }
            FUN_1403d6c80(param_1);
          }
          FUN_140452ba0(local_478);
          uVar10 = 1;
        }
        else {
          uVar10 = 0;
        }
      }
    }
    else {
      uVar10 = 0;
    }
    return uVar10;
  }
  return 0;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_140452b50  @140452b50  [medium:callgraph-r1]  (orig: FUN_140452b50)
undefined8 * FUN_140452b50(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = texasholdem::CMsgShowHandCallAction::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_140452ba0  @140452ba0  [medium:callgraph-r1]  (orig: FUN_140452ba0)
void FUN_140452ba0(undefined8 *param_1)

{
  *param_1 = texasholdem::CMsgShowHandCallAction::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgShowHandCallAction@texasholdem::vfunc_1  @140452bd0  [high:rtti-vtable]  (orig: FUN_140452bd0)
undefined8 FUN_140452bd0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_140452c00  @140452c00  [medium:callgraph-r1]  (orig: FUN_140452c00)
undefined8
FUN_140452c00(longlong param_1,undefined2 param_2,undefined2 param_3,undefined8 param_4,
             undefined8 param_5,undefined4 param_6)

{
  *(undefined4 *)(param_1 + 8) = 0x82d;
  *(undefined4 *)(param_1 + 0xc) = 0x18;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = param_3;
  *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 4) = param_4;
  *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_5;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_6;
  return CONCAT71((uint7)(uint3)((uint)param_6 >> 8),1);
}

// ==== CMsgShowHandCallAction@texasholdem::vfunc_0  @140452c50  [high:rtti-vtable]  (orig: FUN_140452c50)
undefined8 * FUN_140452c50(undefined8 *param_1,uint param_2)

{
  *param_1 = texasholdem::CMsgShowHandCallAction::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgShowHandCallAction@texasholdem::vfunc_3  @140452ca0  [high:rtti-vtable]  (orig: FUN_140452ca0)
void FUN_140452ca0(longlong param_1)

{
  longlong lVar1;
  char cVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined7 uVar6;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))(*(longlong **)(lVar3 + 0x90),param_1);
  if ((lVar3 != 0) && (*(int *)(lVar3 + 0x1240) != 0)) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar4 = *(longlong *)(lVar4 + 0x108);
    if (lVar4 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar4 = 0;
    }
    cVar2 = FUN_140215360(lVar4,lVar3,*(undefined4 *)(lVar3 + 0x1240));
    if (cVar2 != '\0') {
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar5 = FUN_140087830(uVar5);
      lVar4 = FUN_140214ce0(uVar5,*(undefined4 *)(lVar3 + 0x1240));
      if ((lVar4 != 0) && (cVar2 = FUN_1403c9810(lVar4), cVar2 == '\0')) {
        lVar1 = *(longlong *)(param_1 + 0x428);
        uVar6 = (undefined7)((ulonglong)lVar1 >> 8);
        switch(*(undefined2 *)(lVar1 + 2)) {
        case 1:
          FUN_1403e50e0(lVar4,*(undefined1 *)(lVar3 + 0x1244),lVar3,*(undefined8 *)(lVar1 + 4),1);
          return;
        case 2:
          FUN_1403e5cf0(lVar4,*(undefined1 *)(lVar3 + 0x1244),lVar3,CONCAT71(uVar6,1));
          return;
        case 4:
          FUN_1403e5a50(lVar4,*(undefined1 *)(lVar3 + 0x1244),lVar3,CONCAT71(uVar6,1));
          return;
        case 8:
          FUN_1403e5710(lVar4,*(undefined1 *)(lVar3 + 0x1244),lVar3,CONCAT71(uVar6,1));
          return;
        case 0x10:
          FUN_1403e62b0(lVar4,*(undefined1 *)(lVar3 + 0x1244),lVar3,*(undefined8 *)(lVar1 + 4));
          return;
        case 0x20:
          FUN_1403e68e0(lVar4,*(undefined1 *)(lVar3 + 0x1244),lVar3);
        }
      }
    }
  }
  return;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_140459c90  @140459c90  [medium:callgraph-r1]  (orig: FUN_140459c90)
undefined8 * FUN_140459c90(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = texasholdem::CMsgShowHandRaceInteractive::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_140459ce0  @140459ce0  [medium:callgraph-r1]  (orig: FUN_140459ce0)
void FUN_140459ce0(undefined8 *param_1)

{
  *param_1 = texasholdem::CMsgShowHandRaceInteractive::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_140459d40  @140459d40  [medium:callgraph-r1]  (orig: FUN_140459d40)
undefined8 FUN_140459d40(longlong param_1,undefined1 param_2,undefined8 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  **(undefined1 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined8 *)(lVar1 + 1) = param_3;
  *(undefined4 *)(param_1 + 8) = 0x829;
  *(undefined4 *)(param_1 + 0xc) = 9;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1404dae00  @1404dae00  [medium:callgraph-r2]  (orig: FUN_1404dae00)
undefined8 * FUN_1404dae00(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = texasholdem::CMsgShowHandActivePlayer::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1404dae50  @1404dae50  [medium:callgraph-r2]  (orig: FUN_1404dae50)
void FUN_1404dae50(undefined8 *param_1)

{
  *param_1 = texasholdem::CMsgShowHandActivePlayer::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgShowHandCallAction@texasholdem::helper_1404daeb0  @1404daeb0  [medium:callgraph-r2]  (orig: FUN_1404daeb0)
undefined8
FUN_1404daeb0(longlong param_1,undefined2 param_2,undefined2 param_3,undefined8 param_4,
             undefined8 param_5,undefined4 param_6)

{
  *(undefined4 *)(param_1 + 8) = 0x82c;
  *(undefined4 *)(param_1 + 0xc) = 0x18;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = param_3;
  *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 4) = param_4;
  *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_5;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_6;
  return CONCAT71((uint7)(uint3)((uint)param_6 >> 8),1);
}

