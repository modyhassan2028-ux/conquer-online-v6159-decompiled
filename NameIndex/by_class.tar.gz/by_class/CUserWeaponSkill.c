// ==== CUserWeaponSkill::ctor_or_dtor  @14039d610  [high:vtable-assign]  (orig: FUN_14039d610)
void FUN_14039d610(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  *param_1 = CUserWeaponSkill::vftable;
  puVar1 = (undefined8 *)param_1[4];
  if (puVar1 != (undefined8 *)0x0) {
    if (*(char *)(param_1 + 5) == '\0') {
      (**(code **)*puVar1)(puVar1,1);
      param_1[4] = 0;
      return;
    }
    (**(code **)*puVar1)(puVar1,0);
    param_1[4] = 0;
  }
  return;
}

// ==== CUserWeaponSkill::helper_14039d660  @14039d660  [medium:callgraph-r0]  (orig: FUN_14039d660)
bool FUN_14039d660(longlong param_1)

{
  undefined1 uVar1;
  undefined4 uVar2;
  longlong *plVar3;
  
  plVar3 = *(longlong **)(param_1 + 0x20);
  if (plVar3 == (longlong *)0x0) {
    return false;
  }
  if (*(int *)(param_1 + 8) != 0) {
    return true;
  }
  plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,&DAT_1406de8d4);
  uVar2 = (**(code **)(*plVar3 + 0x40))(plVar3);
  *(undefined4 *)(param_1 + 8) = uVar2;
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x20))
                     (*(longlong **)(param_1 + 0x20),"owner_id");
  uVar2 = (**(code **)(*plVar3 + 0x40))(plVar3);
  *(undefined4 *)(param_1 + 0xc) = uVar2;
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x20))
                     (*(longlong **)(param_1 + 0x20),&DAT_14070eeb8);
  uVar2 = (**(code **)(*plVar3 + 0x50))(plVar3);
  *(undefined4 *)(param_1 + 0x14) = uVar2;
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x20))
                     (*(longlong **)(param_1 + 0x20),"level");
  uVar1 = (**(code **)(*plVar3 + 0x20))(plVar3);
  *(undefined1 *)(param_1 + 0x18) = uVar1;
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x20))
                     (*(longlong **)(param_1 + 0x20),"old_level");
  uVar1 = (**(code **)(*plVar3 + 0x20))(plVar3);
  *(undefined1 *)(param_1 + 0x19) = uVar1;
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x20))
                     (*(longlong **)(param_1 + 0x20),&DAT_1406de6d4);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  *(undefined4 *)(param_1 + 0x10) = uVar2;
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x20))
                     (*(longlong **)(param_1 + 0x20),"unlearn");
  uVar1 = (**(code **)(*plVar3 + 0x20))(plVar3);
  *(undefined1 *)(param_1 + 0x1a) = uVar1;
  return *(int *)(param_1 + 0x10) != 0x32;
}

// ==== CUserWeaponSkill::helper_14039db50  @14039db50  [medium:callgraph-r0]  (orig: FUN_14039db50)
void FUN_14039db50(void *param_1)

{
  if ((DAT_1409761c0 & 1) == 0) {
    DAT_1409761c0 = DAT_1409761c0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761b8,"CUserWeaponSkill");
    atexit((_func_5014 *)&LAB_1406d6b90);
  }
                    /* WARNING: Could not recover jumptable at 0x00014039dba5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409761b8,param_1);
  return;
}

// ==== CUserWeaponSkill::ctor_or_dtor  @14039dc10  [high:vtable-assign]  (orig: FUN_14039dc10)
undefined8 * FUN_14039dc10(undefined8 *param_1,ulonglong param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CUserWeaponSkill::vftable;
  puVar1 = (undefined8 *)param_1[4];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,*(char *)(param_1 + 5) == '\0');
    param_1[4] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_14039db50(param_1);
  }
  return param_1;
}

// ==== CUserWeaponSkill::ctor_or_dtor  @14039dc70  [high:vtable-assign]  (orig: FUN_14039dc70)
undefined8 *
FUN_14039dc70(undefined4 *param_1,undefined1 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  if ((DAT_1409761c0 & 1) == 0) {
    DAT_1409761c0 = DAT_1409761c0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761b8,"CUserWeaponSkill");
    atexit((_func_5014 *)&LAB_1406d6b90);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_1409761b8,0x30);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CUserWeaponSkill::vftable;
    puVar1[4] = 0;
    *(undefined1 *)(puVar1 + 5) = 0;
    *(undefined4 *)(puVar1 + 1) = 0;
    *(undefined4 *)((longlong)puVar1 + 0xc) = 0;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 0;
    *(undefined4 *)(puVar1 + 3) = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    plVar2 = (longlong *)InstanceGet();
    plVar2 = (longlong *)
             (**(code **)(*plVar2 + 0x20))(plVar2,"cq_weapon_skill",*plVar2,param_4,uVar3);
    puVar1[4] = plVar2;
    if (plVar2 == (longlong *)0x0) {
      (**(code **)*puVar1)(puVar1,1);
      puVar1 = (undefined8 *)0x0;
    }
    else {
      *(undefined1 *)(puVar1 + 5) = param_2;
      plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,&DAT_1406de8d4);
      (**(code **)(*plVar2 + 0xb8))(plVar2,*param_1);
      plVar2 = (longlong *)
               (**(code **)(*(longlong *)puVar1[4] + 0x20))((longlong *)puVar1[4],&DAT_1406de6d4);
      (**(code **)(*plVar2 + 0xb0))(plVar2,param_1[2]);
      plVar2 = (longlong *)
               (**(code **)(*(longlong *)puVar1[4] + 0x20))((longlong *)puVar1[4],"level");
      (**(code **)(*plVar2 + 0xd8))(plVar2,*(undefined1 *)(param_1 + 4));
      plVar2 = (longlong *)
               (**(code **)(*(longlong *)puVar1[4] + 0x20))((longlong *)puVar1[4],&DAT_14070eeb8);
      (**(code **)(*plVar2 + 0xa8))(plVar2,param_1[3]);
      plVar2 = (longlong *)
               (**(code **)(*(longlong *)puVar1[4] + 0x20))((longlong *)puVar1[4],"old_level");
      (**(code **)(*plVar2 + 0xd8))(plVar2,*(undefined1 *)((longlong)param_1 + 0x11));
      plVar2 = (longlong *)
               (**(code **)(*(longlong *)puVar1[4] + 0x20))((longlong *)puVar1[4],"owner_id");
      (**(code **)(*plVar2 + 0xb8))(plVar2,param_1[1]);
      plVar2 = (longlong *)
               (**(code **)(*(longlong *)puVar1[4] + 0x20))((longlong *)puVar1[4],"unlearn");
      (**(code **)(*plVar2 + 0xd8))(plVar2,*(undefined1 *)((longlong)param_1 + 0x12));
      (**(code **)(*(longlong *)puVar1[4] + 0x58))();
      *(undefined4 *)(puVar1 + 1) = *param_1;
      *(undefined4 *)((longlong)puVar1 + 0xc) = param_1[1];
      *(undefined4 *)(puVar1 + 2) = param_1[2];
      *(undefined4 *)((longlong)puVar1 + 0x14) = param_1[3];
      *(undefined4 *)(puVar1 + 3) = param_1[4];
    }
  }
  return puVar1;
}

// ==== CUserWeaponSkill::ctor_or_dtor  @14039de70  [high:vtable-assign]  (orig: FUN_14039de70)
undefined8 * FUN_14039de70(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  longlong lVar4;
  
  if ((DAT_1409761c0 & 1) == 0) {
    DAT_1409761c0 = DAT_1409761c0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761b8,"CUserWeaponSkill");
    atexit((_func_5014 *)&LAB_1406d6b90);
  }
  puVar2 = CMyHeap::Alloc((CMyHeap *)&DAT_1409761b8,0x30);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CUserWeaponSkill::vftable;
    puVar2[4] = 0;
    *(undefined1 *)(puVar2 + 5) = 0;
    *(undefined4 *)(puVar2 + 1) = 0;
    *(undefined4 *)((longlong)puVar2 + 0xc) = 0;
    *(undefined4 *)(puVar2 + 2) = 0;
    *(undefined4 *)((longlong)puVar2 + 0x14) = 0;
    *(undefined4 *)(puVar2 + 3) = 0;
  }
  if (puVar2 == (undefined8 *)0x0) {
    return (undefined8 *)0x0;
  }
  if (param_2 == 0) {
    lVar4 = FUN_140008520(0xe);
    if (*(longlong *)(lVar4 + 0x210) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pRecPoolMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x165);
      return (undefined8 *)0x0;
    }
    lVar4 = FUN_14028deb0(*(longlong *)(lVar4 + 0x210),4);
    puVar2[4] = lVar4;
    if (lVar4 == 0) {
      (**(code **)*puVar2)(puVar2,1);
      log_InlineLogERROR("get cq_weapon_skill rec err:type=%d,lev=%d,exp=%u,owner=%u,oldLev=%d",
                         (ulonglong)(uint)param_1[2],(ulonglong)*(byte *)(param_1 + 4),
                         (ulonglong)(uint)param_1[3],param_1[1],
                         (uint)*(byte *)((longlong)param_1 + 0x11));
      return (undefined8 *)0x0;
    }
  }
  else {
    plVar3 = (longlong *)InstanceGet();
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,"cq_weapon_skill");
    puVar2[4] = plVar3;
    if (plVar3 == (longlong *)0x0) {
      (**(code **)*puVar2)(puVar2,1);
      return (undefined8 *)0x0;
    }
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,&DAT_1406de8d4);
    (**(code **)(*plVar3 + 0xb8))(plVar3,param_2);
  }
  plVar3 = (longlong *)
           (**(code **)(*(longlong *)puVar2[4] + 0x20))((longlong *)puVar2[4],&DAT_1406de6d4);
  (**(code **)(*plVar3 + 0xb0))(plVar3,param_1[2]);
  plVar3 = (longlong *)(**(code **)(*(longlong *)puVar2[4] + 0x20))((longlong *)puVar2[4],"level");
  (**(code **)(*plVar3 + 0xd8))(plVar3,*(undefined1 *)(param_1 + 4));
  plVar3 = (longlong *)
           (**(code **)(*(longlong *)puVar2[4] + 0x20))((longlong *)puVar2[4],&DAT_14070eeb8);
  (**(code **)(*plVar3 + 0xa8))(plVar3,param_1[3]);
  plVar3 = (longlong *)
           (**(code **)(*(longlong *)puVar2[4] + 0x20))((longlong *)puVar2[4],"owner_id");
  (**(code **)(*plVar3 + 0xb8))(plVar3,param_1[1]);
  plVar3 = (longlong *)
           (**(code **)(*(longlong *)puVar2[4] + 0x20))((longlong *)puVar2[4],"old_level");
  (**(code **)(*plVar3 + 0xd8))(plVar3,*(undefined1 *)((longlong)param_1 + 0x11));
  plVar3 = (longlong *)(**(code **)(*(longlong *)puVar2[4] + 0x20))((longlong *)puVar2[4],"unlearn")
  ;
  (**(code **)(*plVar3 + 0xe8))(plVar3,0);
  (**(code **)(*(longlong *)puVar2[4] + 0x38))((longlong *)puVar2[4],0);
  *(undefined4 *)(puVar2 + 1) = *param_1;
  *(undefined4 *)((longlong)puVar2 + 0xc) = param_1[1];
  *(undefined4 *)(puVar2 + 2) = param_1[2];
  *(undefined4 *)((longlong)puVar2 + 0x14) = param_1[3];
  *(undefined4 *)(puVar2 + 3) = param_1[4];
  plVar3 = (longlong *)
           (**(code **)(*(longlong *)puVar2[4] + 0x20))((longlong *)puVar2[4],&DAT_1406de8d4);
  uVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
  *(undefined4 *)(puVar2 + 1) = uVar1;
  return puVar2;
}

// ==== CUserWeaponSkill::ctor_or_dtor  @14039e180  [high:vtable-assign]  (orig: FUN_14039e180)
undefined8 * FUN_14039e180(longlong param_1)

{
  char cVar1;
  undefined8 *puVar2;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",&DAT_1406e5370,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\userweaponskill.cpp"
                       ,0x2a);
    puVar2 = (undefined8 *)0x0;
  }
  else {
    if ((DAT_1409761c0 & 1) == 0) {
      DAT_1409761c0 = DAT_1409761c0 | 1;
      CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761b8,"CUserWeaponSkill");
      atexit((_func_5014 *)&LAB_1406d6b90);
    }
    puVar2 = CMyHeap::Alloc((CMyHeap *)&DAT_1409761b8,0x30);
    if (puVar2 == (undefined8 *)0x0) {
      puVar2 = (undefined8 *)0x0;
    }
    else {
      *puVar2 = CUserWeaponSkill::vftable;
      puVar2[4] = 0;
      *(undefined1 *)(puVar2 + 5) = 0;
      *(undefined4 *)(puVar2 + 1) = 0;
      *(undefined4 *)((longlong)puVar2 + 0xc) = 0;
      *(undefined4 *)(puVar2 + 2) = 0;
      *(undefined4 *)((longlong)puVar2 + 0x14) = 0;
      *(undefined4 *)(puVar2 + 3) = 0;
    }
    if (puVar2 == (undefined8 *)0x0) {
      puVar2 = (undefined8 *)0x0;
    }
    else {
      puVar2[4] = param_1;
      cVar1 = FUN_14039d660(puVar2);
      if (cVar1 == '\0') {
        (**(code **)*puVar2)(puVar2,1);
        puVar2 = (undefined8 *)0x0;
      }
    }
  }
  return puVar2;
}

