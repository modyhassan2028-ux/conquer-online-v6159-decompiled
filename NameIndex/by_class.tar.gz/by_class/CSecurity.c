// ==== CSecurity::helper_1404f71f0  @1404f71f0  [medium:callgraph-r0]  (orig: FUN_1404f71f0)
void FUN_1404f71f0(void)

{
  int iVar1;
  
  iVar1 = Ordinal_111();
  if (((iVar1 != 0x3e3) && (iVar1 != 0x2736)) && (iVar1 != 0x2746)) {
    log_InlineLogERROR("CListenSocket::AcceptErrorCb got error[%d].");
  }
  return;
}

// ==== CSecurity::helper_1404f8160  @1404f8160  [medium:callgraph-r0]  (orig: FUN_1404f8160)
void FUN_1404f8160(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                  longlong param_5)

{
  longlong lVar1;
  longlong lVar2;
  undefined4 local_18 [2];
  undefined8 local_10;
  
  lVar1 = FUN_140542a10();
  lVar2 = (**(code **)(*(longlong *)(param_5 + 0xb8) + 0x18))();
  if (lVar1 == lVar2) {
    local_18[0] = 1;
  }
  else {
    lVar2 = (**(code **)(*(longlong *)(param_5 + 0xa8) + 0x18))();
    local_18[0] = 0;
    if (lVar1 == lVar2) {
      local_18[0] = 2;
    }
  }
  local_10 = param_2;
  (**(code **)(**(longlong **)(param_5 + 0x88) + 0x50))
            (*(longlong **)(param_5 + 0x88),1,0x756c,0x10,local_18);
  return;
}

// ==== CSecurity::Init  @1404ffdc0  [high:log-string]  (orig: FUN_1404ffdc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404ffdc0(longlong param_1,undefined8 param_2,undefined2 param_3)

{
  char cVar1;
  undefined2 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined1 auStack_78 [32];
  undefined4 local_58;
  undefined8 *local_50;
  undefined4 local_48;
  undefined8 local_38;
  undefined8 local_30;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  if (*(longlong *)(param_1 + 8) != 0) {
    FUN_140542870();
    *(undefined8 *)(param_1 + 8) = 0;
  }
  cVar1 = FUN_140505380();
  if (cVar1 == '\0') {
    log_InlineLogERROR("CSecurity::Init() failed at %s, %d");
    uVar3 = 0;
  }
  else {
    local_30 = 0;
    local_38 = 2;
    uVar2 = Ordinal_9(param_3);
    local_38._0_4_ = CONCAT22(uVar2,(undefined2)local_38);
    uVar3 = FUN_1404f7250(param_2);
    local_48 = 0x10;
    local_50 = &local_38;
    local_58 = 5;
    lVar4 = FUN_140543ac0(uVar3,FUN_1404f8160,param_2,0x1a);
    *(longlong *)(param_1 + 8) = lVar4;
    if (lVar4 == 0) {
      log_InlineLogERROR("CListenSocket::Listen evconnlistener_new_bind error");
      uVar3 = 0;
    }
    else {
      FUN_140542b80(lVar4,FUN_1404f71f0);
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CSecurity::helper_140504000  @140504000  [medium:callgraph-r2]  (orig: FUN_140504000)
void FUN_140504000(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + 1;
    UNLOCK();
  }
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = param_3;
    *param_1 = param_2;
  }
  else {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
      param_1[1] = param_3;
      *param_1 = param_2;
    }
    else {
      param_1[1] = param_3;
      *param_1 = param_2;
    }
  }
  return;
}

// ==== CSecurity::helper_140504090  @140504090  [medium:callgraph-r2]  (orig: FUN_140504090)
void FUN_140504090(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + 1;
    UNLOCK();
  }
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = param_3;
    *param_1 = param_2;
  }
  else {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
      param_1[1] = param_3;
      *param_1 = param_2;
    }
    else {
      param_1[1] = param_3;
      *param_1 = param_2;
    }
  }
  return;
}

// ==== CSecurity::helper_140504120  @140504120  [medium:callgraph-r2]  (orig: FUN_140504120)
void FUN_140504120(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + 1;
    UNLOCK();
  }
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = param_3;
    *param_1 = param_2;
  }
  else {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
      param_1[1] = param_3;
      *param_1 = param_2;
    }
    else {
      param_1[1] = param_3;
      *param_1 = param_2;
    }
  }
  return;
}

// ==== CSecurity::helper_140504f70  @140504f70  [medium:callgraph-r1]  (orig: FUN_140504f70)
void FUN_140504f70(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x28);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count_d<bio_st,void_(__cdecl*)(bio_st*___ptr64),std::allocator<int>_>::
              vftable;
    puVar1[4] = param_3;
  }
  FUN_140504120(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CSecurity::helper_140504ff0  @140504ff0  [medium:callgraph-r1]  (orig: FUN_140504ff0)
void FUN_140504ff0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x28);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count_d<dh_st,void_(__cdecl*)(dh_st*___ptr64),std::allocator<int>_>::
              vftable;
    puVar1[4] = param_3;
  }
  FUN_140504000(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CSecurity::helper_140505070  @140505070  [medium:callgraph-r1]  (orig: FUN_140505070)
void FUN_140505070(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x20);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count_d<char,_anon_9F598A2B::OpenSSLFree,std::allocator<int>_>::vftable
    ;
  }
  FUN_140504090(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CSecurity::helper_140505380  @140505380  [medium:callgraph-r0]  (orig: FUN_140505380)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140505380(void)

{
  longlong *plVar1;
  int *piVar2;
  char cVar3;
  longlong *plVar4;
  bool bVar5;
  uint uVar6;
  int iVar7;
  undefined8 uVar8;
  longlong lVar9;
  char *pcVar10;
  undefined1 auStack_5b8 [32];
  longlong local_598;
  longlong *local_590;
  undefined1 local_588;
  undefined1 local_587;
  undefined1 local_586;
  uint local_584;
  longlong local_580;
  longlong *local_578;
  longlong local_570;
  longlong *local_568;
  longlong local_560;
  longlong *local_558;
  longlong local_550;
  longlong *local_548;
  longlong local_540;
  longlong *local_538;
  undefined8 local_530;
  CIniFile local_528 [1024];
  char local_128 [259];
  undefined1 local_25;
  ulonglong local_18;
  
  local_530 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_5b8;
  if (DAT_140976588 == '\0') {
    local_584 = 0;
    local_538 = (longlong *)0x0;
    local_540 = 0;
    CIniFile::CIniFile(local_528,"shell.ini","DHParam");
    uVar6 = _time32((__time32_t *)0x0);
    _snprintf(local_128,0x104,"AFX_SECURITY_H__13DFAA41_0437_4D50_8A40_CC7412122F69__INCLUDED_%d",
              (ulonglong)uVar6);
    local_25 = 0;
    lVar9 = -1;
    pcVar10 = local_128;
    do {
      if (lVar9 == 0) break;
      lVar9 = lVar9 + -1;
      cVar3 = *pcVar10;
      pcVar10 = pcVar10 + 1;
    } while (cVar3 != '\0');
    RAND_seed(local_128);
    memset(local_128,0,0x104);
    bVar5 = CIniFile::GetString(local_528,local_128,"DHFile",0x104);
    if (!bVar5) {
      strncpy(local_128,"dh.pem",0x103);
    }
    uVar8 = BIO_s_file();
    uVar8 = BIO_new(uVar8);
    local_598 = 0;
    local_590 = (longlong *)0x0;
    FUN_140504f70(&local_598,uVar8,&DAT_14051332c);
    plVar4 = local_590;
    if (local_590 != (longlong *)0x0) {
      LOCK();
      *(int *)(local_590 + 2) = (int)local_590[2] + 1;
      UNLOCK();
    }
    local_538 = local_590;
    local_540 = local_598;
    if (local_590 != (longlong *)0x0) {
      LOCK();
      plVar1 = local_590 + 2;
      lVar9 = *plVar1;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)lVar9 == 1) {
        (**(code **)*local_590)(local_590);
        LOCK();
        piVar2 = (int *)((longlong)plVar4 + 0x14);
        iVar7 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*local_590 + 8))();
        }
      }
    }
    lVar9 = local_598;
    if (local_598 == 0) {
      CIniFile::~CIniFile(local_528);
      plVar4 = local_590;
      if (local_590 != (longlong *)0x0) {
        LOCK();
        plVar1 = local_590 + 2;
        lVar9 = *plVar1;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)lVar9 == 1) {
          (**(code **)*local_590)(local_590);
          LOCK();
          piVar2 = (int *)((longlong)plVar4 + 0x14);
          iVar7 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            (**(code **)(*local_590 + 8))();
          }
        }
      }
      uVar8 = 0;
    }
    else {
      iVar7 = BIO_ctrl(local_598,0x6c,3,local_128);
      if (iVar7 < 1) {
        CIniFile::~CIniFile(local_528);
        plVar4 = local_590;
        if (local_590 != (longlong *)0x0) {
          LOCK();
          plVar1 = local_590 + 2;
          lVar9 = *plVar1;
          *(int *)plVar1 = (int)*plVar1 + -1;
          UNLOCK();
          if ((int)lVar9 == 1) {
            (**(code **)*local_590)(local_590);
            LOCK();
            piVar2 = (int *)((longlong)plVar4 + 0x14);
            iVar7 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar7 == 1) {
              (**(code **)(*local_590 + 8))();
            }
          }
        }
        uVar8 = 0;
      }
      else {
        uVar8 = PEM_read_bio_DHparams(lVar9,0,0,0);
        local_580 = 0;
        local_578 = (longlong *)0x0;
        FUN_140504ff0(&local_580,uVar8,&DAT_14051331a);
        if (local_578 != (longlong *)0x0) {
          LOCK();
          *(int *)(local_578 + 2) = (int)local_578[2] + 1;
          UNLOCK();
        }
        plVar4 = DAT_140976598;
        if (DAT_140976598 != (longlong *)0x0) {
          LOCK();
          plVar1 = DAT_140976598 + 2;
          lVar9 = *plVar1;
          *(int *)plVar1 = (int)*plVar1 + -1;
          UNLOCK();
          if ((int)lVar9 == 1) {
            (**(code **)*plVar4)(plVar4);
            LOCK();
            piVar2 = (int *)((longlong)plVar4 + 0x14);
            iVar7 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar7 == 1) {
              (**(code **)(*plVar4 + 8))(plVar4);
            }
          }
        }
        plVar4 = local_578;
        DAT_140976590 = local_580;
        DAT_140976598 = local_578;
        if (local_578 != (longlong *)0x0) {
          LOCK();
          plVar1 = local_578 + 2;
          lVar9 = *plVar1;
          *(int *)plVar1 = (int)*plVar1 + -1;
          UNLOCK();
          if ((int)lVar9 == 1) {
            (**(code **)*local_578)(local_578);
            LOCK();
            piVar2 = (int *)((longlong)plVar4 + 0x14);
            iVar7 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar7 == 1) {
              (**(code **)(*local_578 + 8))();
            }
          }
        }
        if (DAT_140976590 == 0) {
          CIniFile::~CIniFile(local_528);
          plVar4 = local_590;
          if (local_590 != (longlong *)0x0) {
            LOCK();
            plVar1 = local_590 + 2;
            lVar9 = *plVar1;
            *(int *)plVar1 = (int)*plVar1 + -1;
            UNLOCK();
            if ((int)lVar9 == 1) {
              (**(code **)*local_590)(local_590);
              LOCK();
              piVar2 = (int *)((longlong)plVar4 + 0x14);
              iVar7 = *piVar2;
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (iVar7 == 1) {
                (**(code **)(*local_590 + 8))();
              }
            }
          }
          uVar8 = 0;
        }
        else {
          iVar7 = DH_check(DAT_140976590,&local_584);
          if (iVar7 == 0) {
            CIniFile::~CIniFile(local_528);
            plVar4 = local_590;
            if (local_590 != (longlong *)0x0) {
              LOCK();
              plVar1 = local_590 + 2;
              lVar9 = *plVar1;
              *(int *)plVar1 = (int)*plVar1 + -1;
              UNLOCK();
              if ((int)lVar9 == 1) {
                (**(code **)*local_590)(local_590);
                LOCK();
                piVar2 = (int *)((longlong)plVar4 + 0x14);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                  (**(code **)(*local_590 + 8))();
                }
              }
            }
            uVar8 = 0;
          }
          else if (((((local_584 & 1) == 0) && ((local_584 & 2) == 0)) && ((local_584 & 4) == 0)) &&
                  ((local_584 & 8) == 0)) {
            iVar7 = DH_generate_key(DAT_140976590);
            if (iVar7 == 0) {
              CIniFile::~CIniFile(local_528);
              plVar4 = local_590;
              if (local_590 != (longlong *)0x0) {
                LOCK();
                plVar1 = local_590 + 2;
                lVar9 = *plVar1;
                *(int *)plVar1 = (int)*plVar1 + -1;
                UNLOCK();
                if ((int)lVar9 == 1) {
                  (**(code **)*local_590)(local_590);
                  LOCK();
                  piVar2 = (int *)((longlong)plVar4 + 0x14);
                  iVar7 = *piVar2;
                  *piVar2 = *piVar2 + -1;
                  UNLOCK();
                  if (iVar7 == 1) {
                    (**(code **)(*local_590 + 8))();
                  }
                }
              }
              uVar8 = 0;
            }
            else {
              local_586 = 0;
              uVar8 = BN_bn2hex(*(undefined8 *)(DAT_140976590 + 8));
              local_550 = 0;
              local_548 = (longlong *)0x0;
              FUN_140505070(&local_550,uVar8,0);
              if (local_548 != (longlong *)0x0) {
                LOCK();
                *(int *)(local_548 + 2) = (int)local_548[2] + 1;
                UNLOCK();
              }
              plVar4 = DAT_1409765b8;
              if (DAT_1409765b8 != (longlong *)0x0) {
                LOCK();
                plVar1 = DAT_1409765b8 + 2;
                lVar9 = *plVar1;
                *(int *)plVar1 = (int)*plVar1 + -1;
                UNLOCK();
                if ((int)lVar9 == 1) {
                  (**(code **)*plVar4)(plVar4);
                  LOCK();
                  piVar2 = (int *)((longlong)plVar4 + 0x14);
                  iVar7 = *piVar2;
                  *piVar2 = *piVar2 + -1;
                  UNLOCK();
                  if (iVar7 == 1) {
                    (**(code **)(*plVar4 + 8))(plVar4);
                  }
                }
              }
              plVar4 = local_548;
              DAT_1409765b0 = local_550;
              DAT_1409765b8 = local_548;
              if (local_548 != (longlong *)0x0) {
                LOCK();
                plVar1 = local_548 + 2;
                lVar9 = *plVar1;
                *(int *)plVar1 = (int)*plVar1 + -1;
                UNLOCK();
                if ((int)lVar9 == 1) {
                  (**(code **)*local_548)(local_548);
                  LOCK();
                  piVar2 = (int *)((longlong)plVar4 + 0x14);
                  iVar7 = *piVar2;
                  *piVar2 = *piVar2 + -1;
                  UNLOCK();
                  if (iVar7 == 1) {
                    (**(code **)(*local_548 + 8))();
                  }
                }
              }
              local_587 = 0;
              uVar8 = BN_bn2hex(*(undefined8 *)(DAT_140976590 + 0x10));
              local_560 = 0;
              local_558 = (longlong *)0x0;
              FUN_140505070(&local_560,uVar8,0);
              if (local_558 != (longlong *)0x0) {
                LOCK();
                *(int *)(local_558 + 2) = (int)local_558[2] + 1;
                UNLOCK();
              }
              plVar4 = DAT_1409765a8;
              if (DAT_1409765a8 != (longlong *)0x0) {
                LOCK();
                plVar1 = DAT_1409765a8 + 2;
                lVar9 = *plVar1;
                *(int *)plVar1 = (int)*plVar1 + -1;
                UNLOCK();
                if ((int)lVar9 == 1) {
                  (**(code **)*plVar4)(plVar4);
                  LOCK();
                  piVar2 = (int *)((longlong)plVar4 + 0x14);
                  iVar7 = *piVar2;
                  *piVar2 = *piVar2 + -1;
                  UNLOCK();
                  if (iVar7 == 1) {
                    (**(code **)(*plVar4 + 8))(plVar4);
                  }
                }
              }
              plVar4 = local_558;
              DAT_1409765a0 = local_560;
              DAT_1409765a8 = local_558;
              if (local_558 != (longlong *)0x0) {
                LOCK();
                plVar1 = local_558 + 2;
                lVar9 = *plVar1;
                *(int *)plVar1 = (int)*plVar1 + -1;
                UNLOCK();
                if ((int)lVar9 == 1) {
                  (**(code **)*local_558)(local_558);
                  LOCK();
                  piVar2 = (int *)((longlong)plVar4 + 0x14);
                  iVar7 = *piVar2;
                  *piVar2 = *piVar2 + -1;
                  UNLOCK();
                  if (iVar7 == 1) {
                    (**(code **)(*local_558 + 8))();
                  }
                }
              }
              local_588 = 0;
              uVar8 = BN_bn2hex(*(undefined8 *)(DAT_140976590 + 0x20));
              local_570 = 0;
              local_568 = (longlong *)0x0;
              FUN_140505070(&local_570,uVar8,0);
              if (local_568 != (longlong *)0x0) {
                LOCK();
                *(int *)(local_568 + 2) = (int)local_568[2] + 1;
                UNLOCK();
              }
              plVar4 = DAT_1409765c8;
              if (DAT_1409765c8 != (longlong *)0x0) {
                LOCK();
                plVar1 = DAT_1409765c8 + 2;
                lVar9 = *plVar1;
                *(int *)plVar1 = (int)*plVar1 + -1;
                UNLOCK();
                if ((int)lVar9 == 1) {
                  (**(code **)*plVar4)(plVar4);
                  LOCK();
                  piVar2 = (int *)((longlong)plVar4 + 0x14);
                  iVar7 = *piVar2;
                  *piVar2 = *piVar2 + -1;
                  UNLOCK();
                  if (iVar7 == 1) {
                    (**(code **)(*plVar4 + 8))(plVar4);
                  }
                }
              }
              plVar4 = local_568;
              DAT_1409765c0 = local_570;
              DAT_1409765c8 = local_568;
              if (local_568 != (longlong *)0x0) {
                LOCK();
                plVar1 = local_568 + 2;
                lVar9 = *plVar1;
                *(int *)plVar1 = (int)*plVar1 + -1;
                UNLOCK();
                if ((int)lVar9 == 1) {
                  (**(code **)*local_568)(local_568);
                  LOCK();
                  piVar2 = (int *)((longlong)plVar4 + 0x14);
                  iVar7 = *piVar2;
                  *piVar2 = *piVar2 + -1;
                  UNLOCK();
                  if (iVar7 == 1) {
                    (**(code **)(*local_568 + 8))();
                  }
                }
              }
              if (((DAT_1409765b0 == 0) || (DAT_1409765a0 == 0)) || (DAT_1409765c0 == 0)) {
                CIniFile::~CIniFile(local_528);
                plVar4 = local_590;
                if (local_590 != (longlong *)0x0) {
                  LOCK();
                  plVar1 = local_590 + 2;
                  lVar9 = *plVar1;
                  *(int *)plVar1 = (int)*plVar1 + -1;
                  UNLOCK();
                  if ((int)lVar9 == 1) {
                    (**(code **)*local_590)(local_590);
                    LOCK();
                    piVar2 = (int *)((longlong)plVar4 + 0x14);
                    iVar7 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar7 == 1) {
                      (**(code **)(*local_590 + 8))();
                    }
                  }
                }
                uVar8 = 0;
              }
              else {
                DAT_140976588 = '\x01';
                CIniFile::~CIniFile(local_528);
                plVar4 = local_590;
                if (local_590 != (longlong *)0x0) {
                  LOCK();
                  plVar1 = local_590 + 2;
                  lVar9 = *plVar1;
                  *(int *)plVar1 = (int)*plVar1 + -1;
                  UNLOCK();
                  if ((int)lVar9 == 1) {
                    (**(code **)*local_590)(local_590);
                    LOCK();
                    piVar2 = (int *)((longlong)plVar4 + 0x14);
                    iVar7 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar7 == 1) {
                      (**(code **)(*local_590 + 8))();
                    }
                  }
                }
                uVar8 = 1;
              }
            }
          }
          else {
            CIniFile::~CIniFile(local_528);
            plVar4 = local_590;
            if (local_590 != (longlong *)0x0) {
              LOCK();
              plVar1 = local_590 + 2;
              lVar9 = *plVar1;
              *(int *)plVar1 = (int)*plVar1 + -1;
              UNLOCK();
              if ((int)lVar9 == 1) {
                (**(code **)*local_590)(local_590);
                LOCK();
                piVar2 = (int *)((longlong)plVar4 + 0x14);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                  (**(code **)(*local_590 + 8))();
                }
              }
            }
            uVar8 = 0;
          }
        }
      }
    }
  }
  else {
    uVar8 = 1;
  }
  return uVar8;
}

// ==== CSecurity::helper_140542800  @140542800  [medium:callgraph-r3]  (orig: FUN_140542800)
undefined8 FUN_140542800(longlong *param_1)

{
  short *psVar1;
  
  psVar1 = (short *)((longlong)param_1 + 0x2c);
  *psVar1 = *psVar1 + -1;
  if (*psVar1 == 0) {
    (**(code **)(*param_1 + 0x10))();
    if (param_1[1] != 0) {
      FUN_14054f200(0);
    }
    if (param_1[1] != 0) {
      FUN_14054f1c0(param_1[1],1);
    }
    FUN_14053de00(param_1);
    return 1;
  }
  if (param_1[1] != 0) {
    FUN_14054f200(0);
  }
  return 0;
}

// ==== CSecurity::helper_140542940  @140542940  [medium:callgraph-r2]  (orig: FUN_140542940)
undefined4 FUN_140542940(undefined8 *param_1)

{
  undefined4 uVar1;
  
  if (param_1[1] != 0) {
    FUN_14054f1e0(0);
  }
  *(uint *)((longlong)param_1 + 0x34) = *(uint *)((longlong)param_1 + 0x34) | 1;
  if (param_1[2] == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = (**(code **)*param_1)(param_1);
  }
  if (param_1[1] != 0) {
    FUN_14054f200(0);
  }
  return uVar1;
}

// ==== CSecurity::helper_140542b80  @140542b80  [medium:callgraph-r0]  (orig: FUN_140542b80)
void FUN_140542b80(longlong param_1,undefined8 param_2)

{
  if (*(longlong *)(param_1 + 8) != 0) {
    FUN_14054f1e0(0);
  }
  *(undefined8 *)(param_1 + 0x18) = param_2;
  if (*(longlong *)(param_1 + 8) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CSecurity::helper_140542bc0  @140542bc0  [medium:callgraph-r2]  (orig: FUN_140542bc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140542bc0(undefined8 param_1,undefined8 param_2,longlong param_3)

{
  code *pcVar1;
  undefined8 uVar2;
  int iVar3;
  longlong lVar4;
  undefined1 auStack_e8 [32];
  undefined8 local_c8;
  int local_b8 [4];
  undefined1 local_a8 [128];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_e8;
  if (*(longlong *)(param_3 + 8) != 0) {
    FUN_14054f1e0(0);
  }
LAB_140542c10:
  do {
    local_b8[0] = 0x80;
    lVar4 = FUN_1405470e0(param_1,local_a8,local_b8,*(undefined4 *)(param_3 + 0x30));
    if (lVar4 < 0) {
      iVar3 = FUN_140545950(param_1);
      if ((iVar3 == 0x2733) || (iVar3 == 0x2714)) {
        lVar4 = *(longlong *)(param_3 + 8);
LAB_140542d2e:
        if (lVar4 != 0) {
          FUN_14054f200(0);
        }
      }
      else {
        pcVar1 = *(code **)(param_3 + 0x18);
        if (pcVar1 == (code *)0x0) {
          FUN_14054f810(param_1,"Error from accept() call");
        }
        else {
          *(short *)(param_3 + 0x2c) = *(short *)(param_3 + 0x2c) + 1;
          uVar2 = *(undefined8 *)(param_3 + 0x20);
          if (*(longlong *)(param_3 + 8) != 0) {
            FUN_14054f200(0);
          }
          (*pcVar1)(param_3,uVar2);
          if (*(longlong *)(param_3 + 8) != 0) {
            FUN_14054f1e0(0);
          }
LAB_140542d0c:
          FUN_140542800(param_3);
        }
      }
      return;
    }
    if (local_b8[0] != 0) {
      pcVar1 = *(code **)(param_3 + 0x10);
      if (pcVar1 == (code *)0x0) {
        Ordinal_3(lVar4);
        lVar4 = *(longlong *)(param_3 + 8);
        goto LAB_140542d2e;
      }
      *(short *)(param_3 + 0x2c) = *(short *)(param_3 + 0x2c) + 1;
      uVar2 = *(undefined8 *)(param_3 + 0x20);
      if (*(longlong *)(param_3 + 8) != 0) {
        FUN_14054f200(0);
      }
      local_c8 = uVar2;
      (*pcVar1)(param_3,lVar4,local_a8,local_b8[0]);
      if (*(longlong *)(param_3 + 8) != 0) {
        FUN_14054f1e0(0);
      }
      if (*(short *)(param_3 + 0x2c) == 1) goto LAB_140542d0c;
      *(short *)(param_3 + 0x2c) = *(short *)(param_3 + 0x2c) + -1;
      goto LAB_140542c10;
    }
    Ordinal_3(lVar4);
  } while( true );
}

// ==== CSecurity::helper_140542db0  @140542db0  [medium:callgraph-r3]  (orig: FUN_140542db0)
void FUN_140542db0(LPCRITICAL_SECTION param_1)

{
  if (param_1[2].DebugInfo != (PRTL_CRITICAL_SECTION_DEBUG)0xffffffffffffffff) {
    Ordinal_3();
  }
  LeaveCriticalSection(param_1);
  DeleteCriticalSection(param_1);
  FUN_14053de00(param_1);
  return;
}

// ==== CSecurity::helper_140543210  @140543210  [medium:callgraph-r3]  (orig: FUN_140543210)
undefined8 FUN_140543210(LPCRITICAL_SECTION param_1)

{
  HANDLE pvVar1;
  byte bVar2;
  int iVar3;
  undefined8 *puVar4;
  PRTL_CRITICAL_SECTION_DEBUG p_Var5;
  undefined4 local_res8 [2];
  
  puVar4 = (undefined8 *)FUN_1405c6d20();
  local_res8[0] = 0;
  p_Var5 = (PRTL_CRITICAL_SECTION_DEBUG)
           Ordinal_23(*(undefined1 *)((longlong)&param_1[3].LockSemaphore + 1),1);
  if ((*(byte *)((longlong)param_1[3].OwningThread + 0x34) & 1) == 0) {
    return 0;
  }
  if (p_Var5 == (PRTL_CRITICAL_SECTION_DEBUG)0xffffffffffffffff) {
    iVar3 = Ordinal_111();
  }
  else {
    Ordinal_21(p_Var5,0xffff,0x700b,(longlong)param_1[3].OwningThread + 0x38,8);
    if ((*(byte *)((longlong)param_1[3].OwningThread + 0x28) & 1) == 0) {
      FUN_140545840(p_Var5);
    }
    iVar3 = FUN_1405c6a60(*(undefined8 *)((longlong)param_1[3].OwningThread + 0x48),p_Var5,1);
    if (iVar3 < 0) {
      Ordinal_3(p_Var5);
      return 0xffffffff;
    }
    pvVar1 = param_1[3].OwningThread;
    bVar2 = *(byte *)&param_1[3].LockSemaphore >> 1;
    param_1[2].DebugInfo = p_Var5;
    iVar3 = (*(code *)*puVar4)(*(undefined8 *)((longlong)pvVar1 + 0x38),p_Var5,&param_1[3].SpinCount
                               ,0,bVar2,bVar2,local_res8,param_1 + 1);
    if (iVar3 != 0) {
      if (*(longlong *)((longlong)param_1[3].OwningThread + 8) != 0) {
        FUN_14054f1e0(0);
      }
      EnterCriticalSection(param_1);
      FUN_14053f050(*(undefined8 *)((longlong)param_1[3].OwningThread + 0x40),
                    &param_1[2].OwningThread);
      LeaveCriticalSection(param_1);
      if (*(longlong *)((longlong)param_1[3].OwningThread + 8) == 0) {
        return 0;
      }
      FUN_14054f200(0);
      return 0;
    }
    iVar3 = Ordinal_111();
    if (iVar3 == 0x3e5) {
      return 0;
    }
  }
  pvVar1 = param_1[3].OwningThread;
  param_1[2].LockCount = iVar3;
  FUN_14053f050(*(undefined8 *)((longlong)pvVar1 + 0x40),&param_1[2].OwningThread);
  return 0;
}

// ==== CSecurity::helper_140543660  @140543660  [medium:callgraph-r3]  (orig: FUN_140543660)
LPCRITICAL_SECTION FUN_140543660(HANDLE param_1,int param_2)

{
  int iVar1;
  LPCRITICAL_SECTION lpCriticalSection;
  
  if (param_2 == 2) {
    iVar1 = 0x10;
  }
  else {
    if (param_2 != 0x17) {
      return (LPCRITICAL_SECTION)0x0;
    }
    iVar1 = 0x1c;
  }
  iVar1 = iVar1 * 2 + 0x20;
  lpCriticalSection = (LPCRITICAL_SECTION)FUN_14053dc90(1,(longlong)iVar1 + 0x9f);
  if (lpCriticalSection != (LPCRITICAL_SECTION)0x0) {
    FUN_1405c6900(lpCriticalSection + 1,FUN_140542e10);
    lpCriticalSection[2].DebugInfo = (PRTL_CRITICAL_SECTION_DEBUG)0xffffffffffffffff;
    lpCriticalSection[3].OwningThread = param_1;
    *(char *)&lpCriticalSection[3].LockSemaphore = (char)iVar1;
    *(char *)((longlong)&lpCriticalSection[3].LockSemaphore + 1) = (char)param_2;
    iVar1 = FUN_14053ceb0(*(undefined8 *)((longlong)param_1 + 0x40));
    FUN_14053d6e0(&lpCriticalSection[2].OwningThread,iVar1 / 2,FUN_1405433c0,lpCriticalSection);
    InitializeCriticalSectionAndSpinCount(lpCriticalSection,1000);
  }
  return lpCriticalSection;
}

// ==== CSecurity::helper_140543740  @140543740  [medium:callgraph-r2]  (orig: FUN_140543740)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 *
FUN_140543740(longlong param_1,longlong param_2,undefined8 param_3,uint param_4,int param_5,
             undefined8 param_6)

{
  int iVar1;
  int iVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  undefined1 auStack_e8 [32];
  undefined4 local_c8 [4];
  undefined2 local_b8 [64];
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_e8;
  local_c8[0] = 0x80;
  if (param_1 == 0) {
    return (undefined8 *)0x0;
  }
  lVar3 = FUN_1405c7060();
  if (lVar3 == 0) {
    return (undefined8 *)0x0;
  }
  if (param_5 < 1) {
    if (-1 < param_5) goto LAB_1405437c8;
    param_5 = 0x80;
  }
  iVar1 = Ordinal_13(param_6,param_5);
  if (iVar1 < 0) {
    return (undefined8 *)0x0;
  }
LAB_1405437c8:
  iVar1 = Ordinal_6(param_6,local_b8,local_c8);
  if (iVar1 == 0) {
    puVar4 = (undefined8 *)FUN_14053dc90(1,0x78);
    if (puVar4 == (undefined8 *)0x0) {
      FUN_14054f740("calloc");
    }
    else {
      *(uint *)((longlong)puVar4 + 0x34) = *(uint *)((longlong)puVar4 + 0x34) | 1;
      puVar4[2] = param_2;
      puVar4[4] = param_3;
      *(uint *)(puVar4 + 5) = param_4 | 0x10;
      *puVar4 = &PTR_FUN_1407a1258;
      *(undefined2 *)((longlong)puVar4 + 0x2c) = 1;
      uVar5 = FUN_1405c7060(param_1);
      puVar4[9] = uVar5;
      puVar4[7] = param_6;
      puVar4[8] = param_1;
      iVar1 = FUN_1405c6a60(uVar5,param_6,1);
      if (-1 < iVar1) {
        uVar5 = FUN_14054f1a0(1);
        iVar1 = 0;
        plVar6 = puVar4 + 0xb;
        puVar4[1] = uVar5;
        *(undefined2 *)(puVar4 + 10) = 4;
        while( true ) {
          lVar3 = FUN_140543660(puVar4,local_b8[0]);
          *plVar6 = lVar3;
          if (lVar3 == 0) break;
          if ((param_2 != 0) && (iVar2 = FUN_140543210(lVar3), iVar2 < 0)) {
            FUN_14054f8b0("Couldn\'t start accepting on socket");
            EnterCriticalSection((LPCRITICAL_SECTION)puVar4[(longlong)iVar1 + 0xb]);
            FUN_140542db0(puVar4[(longlong)iVar1 + 0xb]);
            goto LAB_140543907;
          }
          *(short *)((longlong)puVar4 + 0x2c) = *(short *)((longlong)puVar4 + 0x2c) + 1;
          iVar1 = iVar1 + 1;
          plVar6 = plVar6 + 1;
          if (*(short *)(puVar4 + 10) <= iVar1) {
            if ((*(uint *)((longlong)puVar4 + 0x54) & 2) == 0) {
              *(uint *)((longlong)puVar4 + 0x54) = *(uint *)((longlong)puVar4 + 0x54) | 2;
              FUN_14053e4b0(puVar4[8]);
              return puVar4;
            }
            return puVar4;
          }
        }
        FUN_14054f8b0("Couldn\'t create accepting socket");
LAB_140543907:
        if (puVar4[1] != 0) {
          FUN_14054f1c0(puVar4[1],1);
        }
      }
      FUN_14053de00(puVar4);
    }
  }
  else {
    FUN_14054f810(param_6,"getsockname");
  }
  return (undefined8 *)0x0;
}

// ==== CSecurity::helper_140543950  @140543950  [medium:callgraph-r1]  (orig: FUN_140543950)
undefined8 *
FUN_140543950(longlong param_1,undefined8 param_2,undefined8 param_3,uint param_4,int param_5,
             undefined8 param_6)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined8 in_stack_ffffffffffffffd8;
  undefined4 uVar6;
  
  uVar6 = (undefined4)((ulonglong)in_stack_ffffffffffffffd8 >> 0x20);
  if ((((param_1 != 0) && (lVar2 = FUN_1405c7060(), lVar2 != 0)) &&
      (plVar3 = (longlong *)FUN_1405c6d20(), *plVar3 != 0)) && (plVar3[2] != 0)) {
    puVar4 = (undefined8 *)
             FUN_140543740(param_1,param_2,param_3,param_4,CONCAT44(uVar6,param_5),param_6);
    return puVar4;
  }
  if (param_5 < 1) {
    if (-1 < param_5) goto LAB_1405439f2;
    param_5 = 0x80;
  }
  iVar1 = Ordinal_13(param_6,param_5);
  if (iVar1 < 0) {
    return (undefined8 *)0x0;
  }
LAB_1405439f2:
  puVar4 = (undefined8 *)FUN_14053dc90(1,0xb0);
  if (puVar4 != (undefined8 *)0x0) {
    puVar4[2] = param_2;
    puVar4[4] = param_3;
    *(uint *)(puVar4 + 5) = param_4;
    *(undefined2 *)((longlong)puVar4 + 0x2c) = 1;
    *(undefined4 *)(puVar4 + 6) = 0;
    *puVar4 = &PTR_LAB_1407a1228;
    if ((param_4 & 1) == 0) {
      *(undefined4 *)(puVar4 + 6) = 0x4000000;
    }
    if ((param_4 & 4) != 0) {
      *(uint *)(puVar4 + 6) = *(uint *)(puVar4 + 6) | 0x80000000;
    }
    if ((param_4 & 0x10) != 0) {
      uVar5 = FUN_14054f1a0(1);
      puVar4[1] = uVar5;
    }
    FUN_14053d280(puVar4 + 7,param_1,param_6,0x12,FUN_140542bc0,puVar4);
    if ((param_4 & 0x20) == 0) {
      FUN_140542940(puVar4);
    }
  }
  return puVar4;
}

// ==== CSecurity::helper_140543ac0  @140543ac0  [medium:callgraph-r0]  (orig: FUN_140543ac0)
longlong FUN_140543ac0(undefined8 param_1,undefined8 param_2,undefined8 param_3,uint param_4,
                      int param_5,undefined2 *param_6,undefined4 param_7)

{
  int iVar1;
  longlong lVar2;
  longlong lVar3;
  undefined2 uVar4;
  undefined8 uVar5;
  undefined4 local_28 [4];
  
  local_28[0] = 1;
  if (param_6 == (undefined2 *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = *param_6;
  }
  if (param_5 != 0) {
    uVar5 = 0x4000001;
    if ((param_4 & 4) != 0) {
      uVar5 = 0x84000001;
    }
    lVar2 = FUN_140547060(uVar4,uVar5,0);
    if (lVar2 != -1) {
      iVar1 = Ordinal_21(lVar2,0xffff,8,local_28,4);
      if ((((-1 < iVar1) && (((param_4 & 8) == 0 || (iVar1 = FUN_1405458e0(lVar2), -1 < iVar1)))) &&
          ((-1 < (char)param_4 || (iVar1 = FUN_1405458f0(lVar2), -1 < iVar1)))) &&
         (((((param_4 & 0x40) == 0 || (iVar1 = FUN_140545900(lVar2), -1 < iVar1)) &&
           ((param_6 == (undefined2 *)0x0 || (iVar1 = Ordinal_2(lVar2,param_6,param_7), -1 < iVar1))
           )) && (lVar3 = FUN_140543950(param_1,param_2,param_3,param_4,param_5,lVar2), lVar3 != 0))
         )) {
        return lVar3;
      }
      Ordinal_3(lVar2);
    }
  }
  return 0;
}

// ==== CSecurity::helper_1405458e0  @1405458e0  [medium:callgraph-r1]  (orig: FUN_1405458e0)
undefined8 FUN_1405458e0(void)

{
  return 0;
}

// ==== CSecurity::helper_1405458f0  @1405458f0  [medium:callgraph-r1]  (orig: FUN_1405458f0)
undefined8 FUN_1405458f0(void)

{
  return 0;
}

// ==== CSecurity::helper_140545900  @140545900  [medium:callgraph-r1]  (orig: FUN_140545900)
undefined8 FUN_140545900(void)

{
  return 0;
}

// ==== CSecurity::helper_1405470e0  @1405470e0  [medium:callgraph-r3]  (orig: FUN_1405470e0)
longlong FUN_1405470e0(void)

{
  int iVar1;
  longlong lVar2;
  uint in_R9D;
  
  lVar2 = Ordinal_1();
  if (((-1 < lVar2) && ((in_R9D >> 0x1a & 1) != 0)) && (iVar1 = FUN_140545890(lVar2), iVar1 < 0)) {
    Ordinal_3(lVar2);
    return -1;
  }
  return lVar2;
}

