// ==== CMsgMobileString_A@world_kernel::vfunc_1  @1400769f0  [high:rtti-vtable]  (orig: FUN_1400769f0)
ulonglong FUN_1400769f0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x7531);
}

// ==== CMsgMobileString_A@world_kernel::vfunc_3  @140076ea0  [high:rtti-vtable]  (orig: FUN_140076ea0)
void FUN_140076ea0(void)

{
  return;
}

// ==== CMsgMobileString_A@world_kernel::vfunc_0  @140076eb0  [high:rtti-vtable]  (orig: FUN_140076eb0)
undefined8 * FUN_140076eb0(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgMobileString_A::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

