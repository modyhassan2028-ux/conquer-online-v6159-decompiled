// ==== CMsgDialog::helper_14011e4d0  @14011e4d0  [medium:callgraph-r2]  (orig: FUN_14011e4d0)
longlong FUN_14011e4d0(undefined4 *param_1,undefined4 *param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = (longlong)param_2 - (longlong)param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - (longlong)param_1;
    do {
      *(undefined4 *)(lVar1 + (longlong)param_1) = *param_1;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                 ((basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
                  (param_1 + 2) + lVar1),
                 (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
                 (param_1 + 2));
      param_1 = param_1 + 0xc;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x30) * 0x30 + param_3;
}

// ==== CMsgDialog::helper_140142c90  @140142c90  [medium:callgraph-r1]  (orig: FUN_140142c90)
void FUN_140142c90(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  undefined1 local_res8;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar4 = FUN_14011e4d0(uVar1,param_1[4],uVar2,local_res8,local_res8,0);
    lVar3 = param_1[4];
    for (lVar5 = lVar4; lVar5 != lVar3; lVar5 = lVar5 + 0x30) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
                ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(lVar5 + 8));
    }
    param_1[4] = lVar4;
  }
  return;
}

// ==== CMsgDialog::helper_140142d80  @140142d80  [medium:callgraph-r1]  (orig: FUN_140142d80)
void FUN_140142d80(longlong param_1)

{
  FUN_140142c90(param_1 + 0x9d0);
  FUN_140036640(param_1 + 0xa00);
  return;
}

// ==== CMsgDialog::helper_14032f1a0  @14032f1a0  [medium:callgraph-r3]  (orig: FUN_14032f1a0)
undefined4 FUN_14032f1a0(longlong param_1,longlong param_2,int param_3)

{
  char cVar1;
  longlong *plVar2;
  char cVar3;
  longlong lVar4;
  char *pcVar5;
  ulonglong uVar6;
  int iVar7;
  longlong lVar8;
  
  iVar7 = (int)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) + -1;
  uVar6 = (ulonglong)iVar7;
  if (-1 < iVar7) {
    do {
      plVar2 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      if ((ulonglong)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) <= uVar6
         ) {
        _invalid_parameter_noinfo();
      }
      lVar4 = (**(code **)(*plVar2 + 0x60))
                        (plVar2,*(undefined4 *)(*(longlong *)(param_1 + 0xc20) + uVar6 * 4));
      if (lVar4 != 0) {
        pcVar5 = (char *)FUN_140100430(lVar4,0x65);
        lVar8 = param_2 - (longlong)pcVar5;
        do {
          cVar3 = *pcVar5;
          cVar1 = pcVar5[lVar8];
          if (cVar3 != cVar1) break;
          pcVar5 = pcVar5 + 1;
        } while (cVar1 != '\0');
        if ((cVar3 == cVar1) && ((param_3 == 1 || (cVar3 = FUN_1400ffbe0(lVar4), cVar3 == '\0')))) {
          if ((ulonglong)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) <=
              (ulonglong)(longlong)iVar7) {
            _invalid_parameter_noinfo();
          }
          return *(undefined4 *)(*(longlong *)(param_1 + 0xc20) + (longlong)iVar7 * 4);
        }
      }
      iVar7 = iVar7 + -1;
      uVar6 = uVar6 - 1;
    } while (-1 < (longlong)uVar6);
  }
  return 0;
}

// ==== CMsgDialog::helper_14039a880  @14039a880  [medium:callgraph-r1]  (orig: FUN_14039a880)
void FUN_14039a880(longlong param_1,ulonglong param_2)

{
  if (param_2 < (ulonglong)(*(longlong *)(param_1 + 0xa20) - *(longlong *)(param_1 + 0xa18) >> 2)) {
    if ((ulonglong)(*(longlong *)(param_1 + 0xa20) - *(longlong *)(param_1 + 0xa18) >> 2) <= param_2
       ) {
      _invalid_parameter_noinfo();
    }
    *(undefined4 *)(param_1 + 0xa68) = *(undefined4 *)(*(longlong *)(param_1 + 0xa18) + param_2 * 4)
    ;
  }
  return;
}

// ==== CMsgDialog::helper_14039a9c0  @14039a9c0  [medium:callgraph-r2]  (orig: FUN_14039a9c0)
undefined8 FUN_14039a9c0(undefined8 param_1,undefined8 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  char *pcVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong lVar7;
  
  plVar3 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,3);
  pcVar4 = (char *)(**(code **)(*plVar3 + 0x78))();
  plVar3 = DAT_140975b60;
  lVar7 = -1;
  do {
    if (lVar7 == 0) break;
    lVar7 = lVar7 + -1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  if (lVar7 != -2) {
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar5 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,3);
    uVar6 = (**(code **)(*plVar5 + 0x78))(plVar5);
    lVar7 = *plVar3;
    uVar2 = FUN_14032f1a0(param_1,uVar6,1);
    lVar7 = (**(code **)(lVar7 + 0x60))(plVar3,uVar2);
    if (lVar7 == 0) {
      return 0;
    }
    plVar3 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,4);
    pcVar4 = (char *)(**(code **)(*plVar3 + 0x78))();
    lVar7 = -1;
    do {
      if (lVar7 == 0) break;
      lVar7 = lVar7 + -1;
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    if (lVar7 != -2) {
      plVar3 = (longlong *)FUN_140087d40();
      plVar5 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,4);
      uVar6 = (**(code **)(*plVar5 + 0x78))(plVar5);
      lVar7 = *plVar3;
      uVar2 = FUN_14032f1a0(param_1,uVar6,1);
      lVar7 = (**(code **)(lVar7 + 0x60))(plVar3,uVar2);
      if (lVar7 == 0) {
        return 0;
      }
    }
  }
  return 1;
}

// ==== CMsgDialog::helper_14039ab00  @14039ab00  [medium:callgraph-r1]  (orig: FUN_14039ab00)
longlong FUN_14039ab00(longlong param_1,int param_2)

{
  if ((-1 < param_2) &&
     (param_2 < (int)((*(longlong *)(param_1 + 0x9c0) - *(longlong *)(param_1 + 0x9b8)) / 0x30))) {
    if ((ulonglong)((*(longlong *)(param_1 + 0x9c0) - *(longlong *)(param_1 + 0x9b8)) / 0x30) <=
        (ulonglong)(longlong)param_2) {
      _invalid_parameter_noinfo();
    }
    return (longlong)param_2 * 0x30 + *(longlong *)(param_1 + 0x9b8);
  }
  return 0;
}

// ==== CMsgDialog::helper_14039aba0  @14039aba0  [medium:callgraph-r1]  (orig: FUN_14039aba0)
longlong FUN_14039aba0(longlong param_1,int param_2)

{
  ulonglong uVar1;
  
  if (-1 < param_2) {
    uVar1 = (ulonglong)param_2;
    if (uVar1 < (ulonglong)
                ((*(longlong *)(param_1 + 0x9f0) - *(longlong *)(param_1 + 0x9e8)) / 0x30)) {
      if ((ulonglong)((*(longlong *)(param_1 + 0x9f0) - *(longlong *)(param_1 + 0x9e8)) / 0x30) <=
          uVar1) {
        _invalid_parameter_noinfo();
      }
      return uVar1 * 0x30 + *(longlong *)(param_1 + 0x9e8);
    }
  }
  return 0;
}

// ==== CMsgDialog::helper_14039ace0  @14039ace0  [medium:callgraph-r2]  (orig: FUN_14039ace0)
longlong FUN_14039ace0(undefined4 *param_1,undefined4 *param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = (longlong)param_2 - (longlong)param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - (longlong)param_1;
    do {
      *(undefined4 *)(lVar1 + (longlong)param_1) = *param_1;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                 ((basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
                  (param_1 + 2) + lVar1),
                 (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
                 (param_1 + 2));
      param_1 = param_1 + 0xc;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x30) * 0x30 + param_3;
}

// ==== CMsgDialog::helper_14039afd0  @14039afd0  [medium:callgraph-r1]  (orig: FUN_14039afd0)
undefined1 FUN_14039afd0(longlong *param_1,undefined8 *param_2)

{
  byte bVar1;
  short sVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  longlong *plVar6;
  longlong lVar7;
  
  if (param_2 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar3 = FUN_14039a9c0();
    if (cVar3 != '\0') {
      plVar6 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,5);
      iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
      lVar7 = (**(code **)(*param_1 + 0x60))(param_1);
      if (iVar4 <= lVar7) {
        plVar6 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,6);
        iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
        if (iVar4 != 0) {
          bVar1 = *(byte *)((longlong)param_1 + 0xeee);
          plVar6 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,6);
          uVar5 = (**(code **)(*plVar6 + 0x48))(plVar6);
          if (bVar1 != uVar5) {
            return 0;
          }
        }
        sVar2 = *(short *)((longlong)param_1 + 0xef4);
        plVar6 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,8);
        iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
        if (iVar4 <= sVar2) {
          sVar2 = *(short *)((longlong)param_1 + 0xef4);
          plVar6 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,9);
          iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
          if (sVar2 <= iVar4) {
            return 1;
          }
        }
      }
    }
  }
  return 0;
}

// ==== CMsgDialog::helper_14039b110  @14039b110  [medium:callgraph-r0]  (orig: FUN_14039b110)
undefined8 FUN_14039b110(longlong *param_1,undefined4 param_2,undefined8 param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  IStringManager *pIVar6;
  undefined8 uVar7;
  
  plVar5 = DAT_140975b80;
  if (DAT_140975b80 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = (longlong *)0x0;
  }
  puVar4 = (undefined8 *)(**(code **)(*plVar5 + 0x40))(plVar5,param_2);
  if (puVar4 != (undefined8 *)0x0) {
    plVar5 = (longlong *)(**(code **)(*(longlong *)*puVar4 + 0x10))((longlong *)*puVar4,0xe);
    iVar3 = (**(code **)(*plVar5 + 0x48))(plVar5);
    if (iVar3 != 1) {
      plVar5 = (longlong *)(**(code **)(*(longlong *)*puVar4 + 0x10))((longlong *)*puVar4,0xe);
      (**(code **)(*plVar5 + 0x48))(plVar5);
      (**(code **)(*param_1 + 8))(param_1);
      log_InlineLogDBERROR
                (
                "table:cq_task, CUser::ProcessClientTask, User[%u], Task[%u], client_active[%d] != %d."
                );
      return 0;
    }
    cVar2 = FUN_14039afd0(param_1,puVar4);
    plVar5 = (longlong *)*puVar4;
    if (cVar2 == '\0') {
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,2);
      iVar3 = (**(code **)(*plVar5 + 0x48))(plVar5);
      if (iVar3 == 0) {
        pIVar6 = theInstance();
        lVar1 = param_1[2];
        uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_UNQUALIFIED");
        (**(code **)(lVar1 + 0x358))(param_1 + 2,uVar7);
        return 0;
      }
    }
    else {
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,1);
      iVar3 = (**(code **)(*plVar5 + 0x48))(plVar5);
      if (iVar3 == 0) {
        return 1;
      }
    }
    uVar7 = FUN_140008520((int)param_1[0x246]);
    uVar7 = FUN_140087730(uVar7);
    FUN_140145f60(uVar7,iVar3,param_1,0,0,param_3);
    return 1;
  }
  (**(code **)(*param_1 + 8))(param_1);
  log_InlineLogDBERROR("table:cq_task, CUser::ProcessClientTask, User[%u], Don\'t find Task[%u].");
  return 0;
}

// ==== CMsgDialog::helper_14039bca0  @14039bca0  [medium:callgraph-r1]  (orig: FUN_14039bca0)
void FUN_14039bca0(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  undefined1 local_res8;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar4 = FUN_14039ace0(uVar1,param_1[4],uVar2,local_res8,local_res8,0);
    lVar3 = param_1[4];
    for (lVar5 = lVar4; lVar5 != lVar3; lVar5 = lVar5 + 0x30) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
                ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(lVar5 + 8));
    }
    param_1[4] = lVar4;
  }
  return;
}

// ==== CMsgDialog::helper_14039c5a0  @14039c5a0  [medium:callgraph-r0]  (orig: FUN_14039c5a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14039c5a0(longlong *param_1,uint param_2,longlong *param_3)

{
  uint uVar1;
  longlong lVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint *puVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  undefined8 uVar11;
  IStringManager *pIVar12;
  longlong lVar13;
  undefined8 *******pppppppuVar14;
  longlong *plVar15;
  undefined1 auStack_a8 [32];
  longlong *local_88;
  longlong *local_80;
  longlong local_78 [2];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [8];
  undefined8 ******local_60 [2];
  longlong local_50;
  ulonglong local_48;
  ulonglong local_40;
  
  local_78[1] = 0xfffffffffffffffe;
  local_40 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  puVar8 = (uint *)FUN_14039aba0(param_1,param_2);
  if (puVar8 == (uint *)0x0) {
    return 0;
  }
  uVar1 = *puVar8;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)(puVar8 + 2));
  plVar15 = (longlong *)0x0;
  if (uVar1 == 0) {
    FUN_14039a880(param_1,(longlong)(int)param_2);
    FUN_140142c90(param_1 + 0x13a);
    FUN_140036640(param_1 + 0x140);
LAB_14039ca58:
    if (local_50 == 0) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
      uVar11 = 1;
    }
    else {
      pppppppuVar14 = local_60;
      if (0xf < local_48) {
        pppppppuVar14 = (undefined8 *******)local_60[0];
      }
      uVar7 = (**(code **)(*param_1 + 8))(param_1);
      uVar11 = FUN_140087e30();
      local_88 = (longlong *)((ulonglong)local_88 & 0xffffffff00000000);
      local_80 = param_3;
      cVar3 = FUN_140286530(uVar11,pppppppuVar14,uVar7,(int)param_1[0x146]);
      if (cVar3 == '\0') {
        pppppppuVar14 = local_60;
        if (0xf < local_48) {
          pppppppuVar14 = (undefined8 *******)local_60[0];
        }
        log_InlineLogLuaERROR
                  ("Lua return fault, Call From:CUser::ProcessDialog, lua function:%s.",
                   pppppppuVar14);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
        uVar11 = 0;
      }
      else {
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
        uVar11 = 1;
      }
    }
    return uVar11;
  }
  plVar10 = DAT_140975b80;
  if (DAT_140975b80 == (longlong *)0x0) {
    local_88 = (longlong *)CONCAT44(local_88._4_4_,0x3c3);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_setTask",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar10 = plVar15;
  }
  puVar9 = (undefined8 *)(**(code **)(*plVar10 + 0x40))(plVar10,uVar1);
  if (puVar9 != (undefined8 *)0x0) {
    local_78[0] = 0;
    plVar10 = (longlong *)(**(code **)(*(longlong *)*puVar9 + 0x10))((longlong *)*puVar9,0xe);
    iVar5 = (**(code **)(*plVar10 + 0x48))(plVar10);
    if (iVar5 == 0) {
      if ((int)param_1[0x146] == 0) {
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
        return 0;
      }
      plVar10 = (longlong *)(**(code **)(*(longlong *)*puVar9 + 0x10))((longlong *)*puVar9,0xf);
      iVar5 = (**(code **)(*plVar10 + 0x48))(plVar10);
      if (iVar5 == 1) {
        uVar11 = FUN_140008520((int)param_1[0x246]);
        plVar10 = (longlong *)FUN_1400875f0(uVar11);
        plVar10 = (longlong *)(**(code **)(*plVar10 + 0x30))(plVar10);
        plVar10 = (longlong *)(**(code **)(*plVar10 + 0x40))(plVar10,(int)param_1[0x146]);
        if (plVar10 != (longlong *)0x0) {
          (**(code **)(*plVar10 + 0x298))(plVar10,0x1040,local_78);
        }
      }
      else {
        uVar7 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
        uVar6 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
        uVar11 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
        local_80 = local_78;
        local_88 = (longlong *)CONCAT44(local_88._4_4_,(int)param_1[0x146]);
        cVar3 = FUN_1402c84c0(uVar11,uVar6,uVar7,0x1040);
        if (cVar3 == '\0') {
          iVar5 = FUN_1401649c0(param_1);
          if ((iVar5 == 0) || ((int)param_1[0x146] != 0xc)) {
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
            ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
            return 0;
          }
          uVar11 = FUN_140008520((int)param_1[0x246]);
          plVar10 = (longlong *)FUN_1400875f0(uVar11);
          plVar10 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,(int)param_1[0x146]);
          if (plVar10 == (longlong *)0x0) {
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
            ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
            return 0;
          }
          cVar3 = (**(code **)(*plVar10 + 0x298))(plVar10,0x1040,local_78);
          if (cVar3 == '\0') {
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
            ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
            return 0;
          }
        }
      }
      if (local_78[0] == 0) {
        local_88 = (longlong *)CONCAT44(local_88._4_4_,0x18b);
        log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT",&DAT_14070bf28,
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_task.cpp"
                          );
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
        return 0;
      }
    }
    else {
      plVar10 = (longlong *)(**(code **)(*(longlong *)*puVar9 + 0x10))((longlong *)*puVar9,0xe);
      iVar5 = (**(code **)(*plVar10 + 0x48))(plVar10);
      if (iVar5 == 2) {
        if ((int)param_1[0x14c] == 0) {
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
          return 0;
        }
        cVar3 = FUN_140332fe0(param_1);
        if (cVar3 == '\0') {
LAB_14039c8f3:
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
          return 0;
        }
        plVar10 = (longlong *)FUN_140087d40();
        lVar13 = (**(code **)(*plVar10 + 0x60))(plVar10,(int)param_1[0x14c]);
        if (lVar13 == 0) goto LAB_14039c8f3;
      }
    }
    FUN_14039a880(param_1,(longlong)(int)param_2);
    FUN_140142d80(param_1);
    cVar3 = FUN_14039afd0(param_1,puVar9);
    if (cVar3 == '\0') {
      plVar10 = (longlong *)(**(code **)(*(longlong *)*puVar9 + 0x10))((longlong *)*puVar9,2);
      iVar5 = (**(code **)(*plVar10 + 0x48))(plVar10);
      if (iVar5 != 0) {
        if (local_78[0] != 0) {
          plVar15 = (longlong *)(local_78[0] + 0x10);
        }
        uVar11 = FUN_140008520((int)param_1[0x246]);
        uVar11 = FUN_140087730(uVar11);
        local_88 = (longlong *)((ulonglong)local_88 & 0xffffffff00000000);
        local_80 = param_3;
        FUN_140145f60(uVar11,iVar5,param_1,plVar15);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
        return 1;
      }
      pIVar12 = theInstance();
      lVar13 = param_1[2];
      uVar11 = (*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_UNQUALIFIED");
      (**(code **)(lVar13 + 0x358))(param_1 + 2,uVar11);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
      return 0;
    }
    plVar10 = (longlong *)(**(code **)(*(longlong *)*puVar9 + 0x10))((longlong *)*puVar9,1);
    iVar5 = (**(code **)(*plVar10 + 0x48))(plVar10);
    if (iVar5 != 0) {
      if (local_78[0] != 0) {
        plVar15 = (longlong *)(local_78[0] + 0x10);
      }
      uVar11 = FUN_140008520((int)param_1[0x246]);
      uVar11 = FUN_140087730(uVar11);
      local_88 = (longlong *)((ulonglong)local_88 & 0xffffffff00000000);
      local_80 = param_3;
      FUN_140145f60(uVar11,iVar5,param_1,plVar15);
    }
    goto LAB_14039ca58;
  }
  if (param_3 != (longlong *)0x0) {
    lVar13 = -1;
    plVar15 = param_3;
    do {
      if (lVar13 == 0) break;
      lVar13 = lVar13 + -1;
      lVar2 = *plVar15;
      plVar15 = (longlong *)((longlong)plVar15 + 1);
    } while ((char)lVar2 != '\0');
    if (lVar13 != -2) {
      uVar4 = (**(code **)(*param_1 + 8))(param_1);
      local_88 = param_3;
      log_InlineLogDBERROR
                ("table:cq_task, CUser::ProcessTask, User[%u], Don\'t find Task[%u] in menu[%d], pszAccept: %s"
                 ,(ulonglong)uVar4,(ulonglong)uVar1,(ulonglong)param_2);
      goto LAB_14039c6ad;
    }
  }
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  log_InlineLogDBERROR
            ("table:cq_task, CUser::ProcessTask, User[%u], Don\'t find Task[%u] in menu[%d]",
             (ulonglong)uVar4,(ulonglong)uVar1,(ulonglong)param_2);
LAB_14039c6ad:
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
  return 0;
}

// ==== CMsgDialog::helper_14039ce00  @14039ce00  [medium:callgraph-r0]  (orig: FUN_14039ce00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14039ce00(longlong *param_1,undefined4 param_2,undefined8 param_3)

{
  int iVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined8 uVar6;
  undefined8 ***pppuVar7;
  undefined1 auStack_88 [32];
  undefined4 local_68;
  undefined8 local_60;
  undefined8 local_58;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_50 [8];
  undefined8 **local_48 [2];
  longlong local_38;
  ulonglong local_30;
  ulonglong local_28;
  
  local_58 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_88;
  piVar5 = (int *)FUN_14039ab00();
  uVar6 = 0;
  if (piVar5 != (int *)0x0) {
    iVar1 = *piVar5;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_50,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)(piVar5 + 2));
    if (iVar1 == 0) {
      FUN_14039a880(param_1,param_2);
      FUN_14039bca0(param_1 + 0x134);
    }
    else {
      FUN_14039a880(param_1,param_2);
      FUN_14039bca0(param_1 + 0x134);
      uVar6 = FUN_140008520((int)param_1[0x246]);
      uVar6 = FUN_140087730(uVar6);
      local_68 = 0;
      local_60 = param_3;
      FUN_140145f60(uVar6,iVar1,param_1,0);
    }
    lVar2 = DAT_140975bf0;
    if (local_38 == 0) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_50);
      uVar6 = 1;
    }
    else {
      pppuVar7 = local_48;
      if (0xf < local_30) {
        pppuVar7 = (undefined8 ***)local_48[0];
      }
      if (DAT_140975bf0 == 0) {
        local_68 = 0x3cd;
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pLuaScriptMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
      }
      uVar4 = (**(code **)(*param_1 + 8))(param_1);
      local_68 = 0;
      local_60 = param_3;
      cVar3 = FUN_140286530(lVar2,pppuVar7,uVar4,(int)param_1[0x146]);
      if (cVar3 == '\0') {
        pppuVar7 = local_48;
        if (0xf < local_30) {
          pppuVar7 = (undefined8 ***)local_48[0];
        }
        log_InlineLogLuaERROR
                  ("Lua return fault, Call From:CUser::ProcessDialog, lua function:%s.",pppuVar7);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_50);
        uVar6 = 0;
      }
      else {
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_50);
        uVar6 = 1;
      }
    }
  }
  return uVar6;
}

// ==== CMsgDialog::ctor_or_dtor  @1403a6340  [high:vtable-assign]  (orig: FUN_1403a6340)
undefined8 * FUN_1403a6340(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgDialog::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x1c),0x3f1,true);
  return param_1;
}

// ==== CMsgDialog::ctor_or_dtor  @1403a63c0  [high:vtable-assign]  (orig: FUN_1403a63c0)
void FUN_1403a63c0(undefined8 *param_1)

{
  *param_1 = CMsgDialog::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgDialog::vfunc_1  @1403a66c0  [high:rtti-vtable]  (orig: FUN_1403a66c0)
undefined8 FUN_1403a66c0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgDialog::ctor_or_dtor  @1403a66f0  [high:vtable-assign]  (orig: FUN_1403a66f0)
undefined8 * FUN_1403a66f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgDialog::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgDialog::vfunc_3  @1403a6750  [high:rtti-vtable]  (orig: FUN_1403a6750)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403a6750(longlong param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  bool bVar3;
  char cVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  char *pcVar12;
  char *pcVar13;
  undefined1 auStack_168 [32];
  undefined4 local_148;
  char local_138 [256];
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_168;
  bVar3 = tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_138,0x100);
  pcVar13 = local_138;
  if (!bVar3) {
    pcVar13 = "";
  }
  uVar11 = 0xffffffffffffffff;
  pcVar12 = local_138;
  do {
    if (uVar11 == 0) break;
    uVar11 = uVar11 - 1;
    cVar4 = *pcVar12;
    pcVar12 = pcVar12 + 1;
  } while (cVar4 != '\0');
  if (~uVar11 - 1 < 0x100) {
    lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar6 + 0x90) == 0) {
      local_148 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
    }
    plVar7 = (longlong *)
             (**(code **)(**(longlong **)(lVar6 + 0x90) + 0x88))
                       (*(longlong **)(lVar6 + 0x90),param_1);
    if (plVar7 != (longlong *)0x0) {
      plVar8 = (longlong *)FUN_1400e1e60();
      lVar2 = plVar7[0x1e2];
      lVar6 = *plVar8;
      puVar1 = *(undefined4 **)(param_1 + 0x428);
      uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
      (**(code **)(lVar6 + 0x108))(plVar8,uVar5,(int)lVar2,*puVar1);
      cVar4 = (**(code **)(plVar7[2] + 0x220))(plVar7 + 2);
      if (cVar4 == '\0') {
        pIVar9 = theInstance();
        lVar6 = plVar7[2];
        uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_DIE");
        (**(code **)(lVar6 + 0x358))(plVar7 + 2,uVar10);
      }
      else {
        cVar4 = FUN_140167b70(plVar7);
        if ((cVar4 == '\0') || (*(char *)(*(longlong *)(param_1 + 0x428) + 0xb) == 'e')) {
          lVar6 = *(longlong *)(param_1 + 0x428);
          cVar4 = *(char *)(lVar6 + 0xb);
          if (cVar4 == '\x06') {
            FUN_14039ce00(plVar7,*(undefined1 *)(lVar6 + 10),pcVar13);
          }
          else if (cVar4 == 'e') {
            FUN_14039c5a0(plVar7,*(undefined1 *)(lVar6 + 10),pcVar13);
          }
          else if (cVar4 == 'f') {
            FUN_14039b110(plVar7,*(undefined4 *)(lVar6 + 4),pcVar13);
          }
        }
      }
    }
  }
  else {
    local_148 = 0x7f;
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","strlen(szText) < MAX_PARAMSIZE",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgdialog.cpp"
                      );
  }
  return;
}

