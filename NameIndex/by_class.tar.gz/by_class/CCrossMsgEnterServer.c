// ==== CCrossMsgEnterServer::helper_140093ec0  @140093ec0  [medium:callgraph-r1]  (orig: FUN_140093ec0)
bool FUN_140093ec0(longlong param_1,int param_2)

{
  undefined8 uVar1;
  undefined1 uVar2;
  int iVar3;
  longlong *plVar4;
  
  if (param_2 == 3) {
    uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    uVar1 = FUN_140087650(uVar1);
    iVar3 = FUN_1402a8090(uVar1);
    return iVar3 < *(int *)(param_1 + 0x10);
  }
  if (param_2 == 4) {
    if (*(char *)(param_1 + 0x77c) != '\0') {
      uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
      uVar1 = FUN_140087650(uVar1);
      iVar3 = FUN_1402a8090(uVar1);
      if (iVar3 < *(int *)(param_1 + 0x10)) {
        plVar4 = (longlong *)CurrentInstanceGet();
        plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,0x25);
        if (plVar4 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140093f38. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          uVar2 = (**(code **)(*plVar4 + 0x40))(plVar4);
          return (bool)uVar2;
        }
      }
    }
  }
  else {
    log_InlineLogERROR("CMapGroup::IsAllowEnterOS, wrong cross action: %d");
  }
  return false;
}

// ==== CCrossMsgEnterServer::helper_140093f60  @140093f60  [medium:callgraph-r0]  (orig: FUN_140093f60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_140093f60(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,int param_6,byte param_7)

{
  char cVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined2 uVar8;
  undefined1 auStack_4c8 [32];
  uint local_4a8;
  byte local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1072];
  ulonglong local_58;
  
  local_498 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  cVar1 = FUN_140093ec0(param_1,param_6);
  uVar2 = 0;
  if (cVar1 != '\0') {
    local_4a8 = (uint)param_7;
    log_InlineLogOSMessage
              (
              "login os step1: create os user[id:%u, serverid:%u, os_serverid:%u, enter_server_type:%d] begin."
              );
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x90) == 0) {
      local_4a8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    local_4a0 = param_7;
    local_4a8 = param_5;
    plVar6 = (longlong *)FUN_1402b4d90(*(undefined8 *)(lVar5 + 0x90),param_2,param_3,param_4);
    if (plVar6 == (longlong *)0x0) {
      uVar2 = 0;
    }
    else {
      lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
      if (*(char *)(lVar5 + 0x77c) == '\0') {
        FUN_140168a40(plVar6,0);
      }
      else if (param_6 == 4) {
        FUN_140168a40(plVar6,2);
      }
      else {
        FUN_140168a40(plVar6,1);
      }
      uVar8 = 0;
      if (param_7 == 2) {
        uVar8 = 1;
      }
      else if (param_7 == 4) {
        uVar8 = 2;
      }
      FUN_1402b5280(local_488);
      cVar1 = FUN_1402b5330(local_488,uVar8,param_2,param_3);
      if (cVar1 != '\0') {
        if (param_7 == 0) {
          plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x68));
          lVar5 = *plVar7;
          uVar3 = FUN_140167b40(plVar6);
          uVar4 = (**(code **)(*plVar6 + 0x38))(plVar6);
          local_4a8 = 4;
          (**(code **)(lVar5 + 0x28))(plVar7,uVar4,uVar3,local_488);
        }
        else if (param_7 == 4) {
          plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x68));
          lVar5 = *plVar7;
          uVar3 = FUN_140167b50(plVar6);
          uVar4 = (**(code **)(*plVar6 + 0x38))(plVar6);
          local_4a8 = 4;
          (**(code **)(lVar5 + 0x28))(plVar7,uVar4,uVar3,local_488);
        }
        else if (param_7 == 2) {
          (**(code **)(*plVar6 + 0x130))(plVar6,local_488);
        }
      }
      FUN_1402b52d0(local_488);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CCrossMsgEnterServer::helper_140167b50  @140167b50  [medium:callgraph-r1]  (orig: FUN_140167b50)
undefined4 FUN_140167b50(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x132c);
}

// ==== CCrossMsgEnterServer::helper_140168a40  @140168a40  [medium:callgraph-r1]  (orig: FUN_140168a40)
void FUN_140168a40(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1334) = param_2;
  return;
}

// ==== CCrossMsgEnterServer::helper_14019c620  @14019c620  [medium:callgraph-r2]  (orig: FUN_14019c620)
undefined8
FUN_14019c620(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,uint param_6,undefined4 param_7)

{
  char cVar1;
  undefined4 uVar2;
  ulong uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *local_40 [3];
  void *local_28;
  undefined8 local_20;
  undefined8 local_18;
  
  if ((param_6 < 0x100000) || (param_6 == 0xffffffff)) {
    log_InlineLogOSERROR
              (
              "CUser::CreateOSUser os user socket id is error, socket id:%u, idOSUser:%u, idServer:%u."
              );
  }
  else {
    *(undefined4 *)(param_1 + 0x1230) = param_2;
    *(undefined4 *)(param_1 + 0xe84) = param_3;
    *(undefined4 *)(param_1 + 0xe80) = param_7;
    *(undefined4 *)(param_1 + 0x12fc) = param_4;
    *(uint *)(param_1 + 0x122c) = param_6;
    *(undefined4 *)(param_1 + 0x132c) = param_5;
    plVar7 = (longlong *)0x0;
    *(undefined4 *)(param_1 + 0x10e0) = 0;
    *(undefined4 *)(param_1 + 0x10e4) = 0;
    *(undefined2 *)(param_1 + 0x10e8) = 0;
    *(undefined4 *)(param_1 + 0x11e0) = 0;
    *(undefined4 *)(param_1 + 0x10ec) = 0;
    *(undefined1 *)(param_1 + 0x13b0) = 1;
    uVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0xf0))(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x1128) = uVar2;
    uVar3 = tq::TimeGet(0);
    *(ulong *)(param_1 + 0x112c) = uVar3;
    *(undefined4 *)(param_1 + 0x1140) = 0x1e;
    uVar3 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x1144) = uVar3 / 1000;
    *(undefined4 *)(param_1 + 0x1178) = 10;
    uVar3 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x117c) = uVar3 / 1000;
    *(undefined4 *)(param_1 + 0x1180) = 5;
    uVar3 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x1184) = uVar3 / 1000;
    *(undefined4 *)(param_1 + 0x1148) = 0x168;
    uVar3 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x114c) = uVar3 / 1000;
    *(undefined4 *)(param_1 + 0x1150) = 0x3c;
    uVar3 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x1154) = uVar3 / 1000;
    *(undefined4 *)(param_1 + 0x1158) = 5;
    uVar3 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x115c) = uVar3 / 1000;
    *(undefined4 *)(param_1 + 0x11fc) = 600;
    uVar3 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x1200) = uVar3 / 1000;
    lVar4 = FUN_1403e9370(0x20);
    plVar5 = plVar7;
    if (lVar4 != 0) {
      plVar5 = (longlong *)FUN_1403e8ca0(lVar4,*(undefined4 *)(param_1 + 0x1230),param_1 + 0x10);
    }
    *(longlong **)(param_1 + 0x1120) = plVar5;
    if (plVar5 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    if (*(longlong *)(lVar4 + 0x100) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar2 = *(undefined4 *)(param_1 + 0x1230);
      uVar6 = FUN_140008520(uVar2);
      uVar6 = FUN_1400877e0(uVar6);
      cVar1 = FUN_1402f1ed0(uVar6,uVar2,param_1);
      if (cVar1 != '\0') {
        plVar5 = (longlong *)FUN_1401181a0();
        (**(code **)(*plVar5 + 0x108))(plVar5,param_7);
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
        uVar6 = FUN_1401600f0(uVar6);
        FUN_1401f5d50(uVar6,param_7);
        lVar4 = FUN_1403bc150(*(undefined4 *)(param_1 + 0x1230));
        *(longlong *)(param_1 + 0x1118) = lVar4;
        if (lVar4 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        plVar5 = operator_new(8);
        if (plVar5 != (longlong *)0x0) {
          *plVar5 = (longlong)local_40;
          plVar7 = plVar5;
        }
        local_28 = (void *)0x0;
        local_20 = 0;
        local_18 = 0;
        local_40[0] = plVar7;
        FUN_1403bb940(*(undefined8 *)(param_1 + 0x1118),param_7,local_40);
        cVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x230))(param_1 + 0x10);
        if ((cVar1 == '\0') ||
           (cVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x238))(param_1 + 0x10),
           cVar1 != '\0')) {
          *(undefined1 *)(param_1 + 0x108) = 1;
        }
        else {
          *(undefined1 *)(param_1 + 0x108) = 0;
        }
        if (local_28 != (void *)0x0) {
          operator_delete(local_28);
        }
        local_28 = (void *)0x0;
        local_20 = 0;
        local_18 = 0;
        operator_delete(local_40[0]);
        return 1;
      }
    }
  }
  return 0;
}

// ==== CCrossMsgEnterServer::helper_1401f5d50  @1401f5d50  [medium:callgraph-r3]  (orig: FUN_1401f5d50)
void FUN_1401f5d50(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  undefined4 local_res10 [2];
  undefined4 local_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  longlong *local_58 [2];
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  
  local_res10[0] = param_2;
  FUN_1401f5550((longlong *)(param_1 + 0x18),&local_68,local_res10,param_4,0xfffffffffffffffe);
  lVar3 = *(longlong *)(param_1 + 0x48);
  local_58[0] = *(longlong **)(param_1 + 0x18);
  plVar1 = (longlong *)CONCAT44(uStack_64,local_68);
  if ((plVar1 == (longlong *)0x0) || (plVar1 != local_58[0])) {
    _invalid_parameter_noinfo();
  }
  lVar2 = uStack_60;
  if (uStack_60 != lVar3) {
    log_InlineLogERROR("CInnerStrengthMgr::CreateOSUser found user data, idUser:%u.");
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = *plVar1;
    }
    if (lVar2 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(lVar2 + 0x20) != 0) {
      FUN_1404056e0(*(undefined8 *)(lVar2 + 0x20));
      *(undefined8 *)(lVar2 + 0x20) = 0;
    }
    local_48 = local_68;
    uStack_44 = uStack_64;
    uStack_40 = (undefined4)uStack_60;
    uStack_3c = uStack_60._4_4_;
    FUN_1401f5190(param_1 + 0x18,local_58,&local_48);
  }
  uStack_60 = FUN_140408750(*(undefined4 *)(param_1 + 8),param_2,1);
  if (uStack_60 == 0) {
    log_InlineLogERROR(
                      "CInnerStrengthMgr::CreateOSUser CInnerStrengthPlayer::CreateNew failed, idUser:%u."
                      );
  }
  else {
    local_68 = param_2;
    FUN_1401f4fe0(param_1 + 0x18,&local_48,&local_68);
  }
  return;
}

// ==== CCrossMsgEnterServer::helper_1402a8090  @1402a8090  [medium:callgraph-r2]  (orig: FUN_1402a8090)
undefined4 FUN_1402a8090(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xc);
}

// ==== CCrossMsgEnterServer::helper_1402aed50  @1402aed50  [medium:callgraph-r2]  (orig: FUN_1402aed50)
uint FUN_1402aed50(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  uint uVar4;
  longlong lVar5;
  longlong *local_38;
  longlong lStack_30;
  undefined1 local_28 [16];
  
  uVar4 = *(int *)(param_1 + 0x14) + 1;
  if (*(longlong *)(param_1 + 0xd0) != 0) {
    plVar1 = *(longlong **)(param_1 + 200);
    plVar2 = *(longlong **)(param_1 + 0x98);
    plVar3 = (longlong *)*plVar1;
    local_38 = plVar2;
    lStack_30 = (longlong)plVar3;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar1) {
      *(uint *)(param_1 + 0x14) = uVar4;
    }
    else {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar2;
      }
      if (plVar3 == (longlong *)*(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar4 = *(uint *)(plVar3 + 3);
      FUN_14000ab40(param_1 + 0x98,local_28,&local_38);
    }
    return uVar4;
  }
  if (uVar4 < 3999999999) {
    *(uint *)(param_1 + 0x14) = uVar4;
    return uVar4;
  }
  log_InlineLogOSERROR(&DAT_1407415f0);
  return 0;
}

// ==== CCrossMsgEnterServer::helper_1402b4d90  @1402b4d90  [medium:callgraph-r1]  (orig: FUN_1402b4d90)
undefined8 *
FUN_1402b4d90(longlong *param_1,uint param_2,uint param_3,uint param_4,uint param_5,byte param_6)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  ulong uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  int *piVar10;
  ulong *puVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  uint in_stack_ffffffffffffff08;
  uint in_stack_ffffffffffffff10;
  longlong ***local_d8;
  int local_d0 [2];
  longlong ***local_c8;
  longlong **local_c0;
  undefined4 local_b8;
  undefined4 local_b4;
  longlong ***local_b0 [3];
  void *local_98;
  undefined8 local_90;
  undefined8 local_88;
  longlong ***local_80 [3];
  void *local_68;
  undefined8 local_60;
  undefined8 local_58;
  undefined8 local_50;
  longlong ***local_48;
  
  local_50 = 0xfffffffffffffffe;
  uVar12 = (ulonglong)param_3;
  uVar13 = (ulonglong)param_2;
  if ((((param_5 < 0x100000) || (param_5 == 0xffffffff)) || (param_2 == 0)) || (param_3 == 0)) {
    log_InlineLogOSERROR
              ("CUserManager::CreateOSUser os user param is error, socket id:%u, idOSUser:%u, idServer:%u."
               ,(ulonglong)param_5,(ulonglong)param_2,(ulonglong)param_3);
    puVar8 = (undefined8 *)0x0;
  }
  else {
    uVar6 = FUN_140008520((int)param_1[0x50]);
    uVar2 = FUN_14008b420(uVar6);
    if (param_3 == uVar2) {
      uVar6 = FUN_140008520((int)param_1[0x50]);
      uVar2 = FUN_14008b420(uVar6);
      log_InlineLogOSERROR
                ("CUserManager::CreateOSUser os user create error, gs server is local server, gs server_id:%u, local server_id:%u."
                 ,uVar12,(ulonglong)uVar2);
      puVar8 = (undefined8 *)0x0;
    }
    else {
      plVar7 = (longlong *)(**(code **)(*param_1 + 0xa0))(param_1,uVar13,param_3);
      if (plVar7 == (longlong *)0x0) {
        plVar7 = (longlong *)FUN_1402af110(param_1,uVar12,param_2);
        if (plVar7 != (longlong *)0x0) {
          uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
          local_d8 = (longlong ***)CONCAT44(local_d8._4_4_,uVar3);
          FUN_140050f20(param_1 + 0xb,&local_c8,&local_d8);
          local_d8 = (longlong ***)param_1[0x11];
          local_48 = (longlong ***)param_1[0xb];
          if ((local_c8 == (longlong ***)0x0) || (local_c8 != local_48)) {
            _invalid_parameter_noinfo();
          }
          if ((longlong ***)local_c0 != local_d8) {
            return (undefined8 *)0x0;
          }
          log_InlineLogOSWARNING("CUserManager::CreateOSUser login repeat[%u %u].",uVar13,uVar12);
          uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
          FUN_1402b0840(param_1,uVar3);
          (**(code **)(plVar7[2] + 8))();
        }
        puVar8 = (undefined8 *)0x0;
        local_c8 = (longlong ***)FUN_14016d5a0(0x1418);
        if (local_c8 != (longlong ***)0x0) {
          puVar8 = (undefined8 *)FUN_1401d0da0(local_c8);
        }
        if (puVar8 == (undefined8 *)0x0) {
          puVar8 = (undefined8 *)0x0;
        }
        else {
          iVar4 = FUN_1402aed50(param_1);
          local_d0[0] = iVar4;
          if (iVar4 == 0) {
            (**(code **)*puVar8)(puVar8,1);
            puVar8 = (undefined8 *)0x0;
          }
          else {
            cVar1 = FUN_14019c620(puVar8,(int)param_1[0x50],uVar13,uVar12,param_4,param_5,iVar4);
            if (cVar1 == '\0') {
              (**(code **)(puVar8[2] + 8))();
              puVar8 = (undefined8 *)0x0;
            }
            else {
              tq::CMySingleLock::CMySingleLock
                        ((CMySingleLock *)&local_d8,(ILockObj *)&DAT_140975f50);
              local_c8 = (longlong ***)CONCAT44(param_3,param_2);
              puVar9 = (undefined8 *)FUN_1402af4c0(param_1 + 0x51,local_d0);
              *puVar9 = puVar8;
              piVar10 = (int *)FUN_1402af3c0(param_1 + 3,&local_c8);
              *piVar10 = iVar4;
              puVar11 = (ulong *)FUN_140053460(param_1 + 0xb,local_d0);
              uVar5 = tq::TimeGet(0);
              *puVar11 = uVar5;
              tq::CMySingleLock::~CMySingleLock((CMySingleLock *)&local_d8);
              log_InlineLogOSMessage
                        ("login os step2: create os user[id:%u, serverid:%u, os_serverid:%u, enter_server_type:%d],user create ok."
                         ,uVar13,uVar12,(ulonglong)param_4,(uint)param_6);
            }
          }
        }
      }
      else {
        log_InlineLogOSMessage(&DAT_140742310,uVar13,uVar12);
        if (param_6 == 0) {
          local_d8 = operator_new(8);
          if (local_d8 == (longlong ***)0x0) {
            local_80[0] = (longlong ***)0x0;
          }
          else {
            *local_d8 = (longlong **)local_80;
            local_80[0] = local_d8;
          }
          local_68 = (void *)0x0;
          local_60 = 0;
          local_58 = 0;
          local_c8 = local_d8;
          local_b4 = (**(code **)(*plVar7 + 8))(plVar7);
          FUN_140037fe0(local_80,&local_b4);
          local_c8 = (longlong ***)local_b0;
          uVar6 = FUN_140043260(local_b0,local_80);
          FUN_1402b3560(param_1,uVar6,10,1,in_stack_ffffffffffffff08 & 0xffffff00,1);
          if (local_68 != (void *)0x0) {
            operator_delete(local_68);
          }
          local_68 = (void *)0x0;
          local_60 = 0;
          local_58 = 0;
          operator_delete(local_80[0]);
        }
        else {
          local_d8 = operator_new(8);
          if (local_d8 == (longlong ***)0x0) {
            local_b0[0] = (longlong ***)0x0;
          }
          else {
            *local_d8 = (longlong **)local_b0;
            local_b0[0] = local_d8;
          }
          local_98 = (void *)0x0;
          local_90 = 0;
          local_88 = 0;
          local_c8 = local_d8;
          local_b8 = (**(code **)(*plVar7 + 8))(plVar7);
          FUN_140037fe0(local_b0,&local_b8);
          local_c8 = (longlong ***)local_80;
          uVar6 = FUN_140043260(local_80,local_b0);
          FUN_1402b3560(param_1,uVar6,10,1,in_stack_ffffffffffffff08 & 0xffffff00,
                        in_stack_ffffffffffffff10 & 0xffffff00);
          if (local_98 != (void *)0x0) {
            operator_delete(local_98);
          }
          local_98 = (void *)0x0;
          local_90 = 0;
          local_88 = 0;
          operator_delete(local_b0[0]);
        }
        puVar8 = (undefined8 *)0x0;
      }
    }
  }
  return puVar8;
}

// ==== CCrossMsgEnterServer::helper_1402b5330  @1402b5330  [medium:callgraph-r1]  (orig: FUN_1402b5330)
undefined8 FUN_1402b5330(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  if (*(undefined2 **)(param_1 + 0x428) == (undefined2 *)0x0) {
    return 0;
  }
  *(undefined4 *)(param_1 + 8) = 0x9c42;
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 8) = param_4;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CCrossMsgEnterServer::helper_1402f1ed0  @1402f1ed0  [medium:callgraph-r3]  (orig: FUN_1402f1ed0)
undefined8 FUN_1402f1ed0(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 uVar10;
  undefined8 *puVar11;
  longlong **pplVar12;
  undefined8 *puVar13;
  longlong *plVar14;
  longlong *local_58;
  undefined8 *local_50;
  longlong *local_38;
  longlong *plStack_30;
  
  plVar8 = (longlong *)FUN_1404a1950(param_2,param_3);
  if (plVar8 == (longlong *)0x0) {
    uVar10 = 0;
  }
  else {
    plVar14 = plVar8;
    uVar7 = (**(code **)(*plVar8 + 8))(plVar8);
    plVar1 = (longlong *)(param_1 + 0x88);
    puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0xb8))[1];
    cVar2 = *(char *)((longlong)puVar13 + 0x29);
    puVar6 = *(undefined8 **)(param_1 + 0xb8);
    while (cVar2 == '\0') {
      if (*(uint *)(puVar13 + 3) < uVar7) {
        puVar11 = (undefined8 *)puVar13[2];
        puVar13 = puVar6;
      }
      else {
        puVar11 = (undefined8 *)*puVar13;
      }
      puVar6 = puVar13;
      puVar13 = puVar11;
      cVar2 = *(char *)((longlong)puVar11 + 0x29);
    }
    local_50 = puVar6;
    local_58 = (longlong *)*plVar1;
    puVar13 = *(undefined8 **)(param_1 + 0xb8);
    if ((longlong *)*plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar6 == puVar13) || (uVar7 < *(uint *)(puVar6 + 3))) {
      plStack_30 = (longlong *)*(undefined8 *)(param_1 + 0xb8);
      local_38 = (longlong *)*plVar1;
      pplVar12 = &local_38;
    }
    else {
      pplVar12 = &local_58;
    }
    plVar3 = *pplVar12;
    plVar4 = pplVar12[1];
    plVar5 = *(longlong **)(param_1 + 0xb8);
    if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 != plVar5) {
      log_InlineLogERROR(&DAT_140749cf0);
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar3;
      }
      if (plVar4 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      puVar13 = (undefined8 *)plVar4[4];
      if (puVar13 != (undefined8 *)0x0) {
        (**(code **)*puVar13)(puVar13,1);
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar3;
      }
      if (plVar4 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar4[4] = 0;
      local_38 = plVar3;
      plStack_30 = plVar4;
      FUN_1402efa90(param_1 + 0x88,&local_58,&local_38);
    }
    local_38 = (longlong *)CONCAT44(local_38._4_4_,uVar7);
    plStack_30 = plVar8;
    FUN_1402ef8e0(param_1 + 0x88,&local_58,&local_38,param_4,plVar14);
    uVar10 = 1;
  }
  return uVar10;
}

// ==== CCrossMsgEnterServer::ctor_or_dtor  @1403f39b0  [high:vtable-assign]  (orig: FUN_1403f39b0)
undefined8 * FUN_1403f39b0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgEnterServer::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgEnterServer::ctor_or_dtor  @1403f3a00  [high:vtable-assign]  (orig: FUN_1403f3a00)
void FUN_1403f3a00(undefined8 *param_1)

{
  *param_1 = CCrossMsgEnterServer::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgEnterServer::vfunc_1  @1403f3a30  [high:rtti-vtable]  (orig: FUN_1403f3a30)
undefined8 FUN_1403f3a30(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgEnterServer::ctor_or_dtor  @1403f3b20  [high:vtable-assign]  (orig: FUN_1403f3b20)
undefined8 * FUN_1403f3b20(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgEnterServer::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgEnterServer::vfunc_3  @1403f3b70  [high:rtti-vtable]  (orig: FUN_1403f3b70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403f3b70(longlong param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  longlong lVar3;
  char cVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined4 local_470;
  undefined1 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  puVar2 = *(undefined4 **)(param_1 + 0x428);
  if (puVar2 == (undefined4 *)0x0) {
    local_478 = 0x36;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    switch(*puVar2) {
    case 2:
      if (puVar2[1] == 0) {
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar8 = (longlong *)FUN_140087650(uVar7);
        lVar6 = (**(code **)(*plVar8 + 0x98))
                          (plVar8,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
        if (lVar6 != 0) {
          pIVar9 = theInstance();
          lVar3 = *(longlong *)(lVar6 + 0x10);
          uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_DENY_ENTER_USER_FULL");
          (**(code **)(lVar3 + 0x358))(lVar6 + 0x10,uVar7);
        }
      }
      else if (puVar2[1] == 1) {
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar8 = (longlong *)FUN_140087650(uVar7);
        lVar6 = (**(code **)(*plVar8 + 0x98))
                          (plVar8,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
        if (lVar6 != 0) {
          pIVar9 = theInstance();
          lVar3 = *(longlong *)(lVar6 + 0x10);
          uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_CROSS_FALG_WAR_DENY_CROSS");
          (**(code **)(lVar3 + 0x358))(lVar6 + 0x10,uVar7);
        }
      }
      break;
    case 3:
      if (puVar2[1] == 0) {
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar8 = (longlong *)FUN_140087650(uVar7);
        lVar6 = (**(code **)(*plVar8 + 0x98))
                          (plVar8,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
        if (lVar6 != 0) {
          pIVar9 = theInstance();
          lVar3 = *(longlong *)(lVar6 + 0x10);
          uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_DENY_ENTER_USER_FULL");
          (**(code **)(lVar3 + 0x358))(lVar6 + 0x10,uVar7);
        }
      }
      break;
    case 4:
      uVar5 = *(undefined4 *)(param_1 + 0x41c);
      uVar1 = *(undefined4 *)(param_1 + 0x420);
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      local_468 = 0;
      local_470 = puVar2[1];
      local_478 = puVar2[4];
      cVar4 = FUN_140093f60(uVar7,uVar1,uVar5,0);
      if (cVar4 == '\0') {
        **(undefined4 **)(param_1 + 0x428) = 6;
        plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        local_478 = 4;
        (**(code **)(*plVar8 + 0x28))
                  (plVar8,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c),param_1)
        ;
      }
      break;
    case 5:
      uVar5 = *(undefined4 *)(param_1 + 0x41c);
      uVar1 = *(undefined4 *)(param_1 + 0x420);
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      local_468 = 2;
      local_470 = puVar2[1];
      local_478 = puVar2[4];
      cVar4 = FUN_140093f60(uVar7,uVar1,uVar5,0);
      if (cVar4 == '\0') {
        **(undefined4 **)(param_1 + 0x428) = 7;
        plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        (**(code **)(*plVar8 + 8))(plVar8,param_1);
      }
      break;
    case 6:
      if (puVar2[1] - 3 < 2) {
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar8 = (longlong *)FUN_140087650(uVar7);
        plVar8 = (longlong *)
                 (**(code **)(*plVar8 + 0x98))
                           (plVar8,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
        if (plVar8 != (longlong *)0x0) {
          FUN_140368e20(local_448);
          uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
          cVar4 = FUN_140368ed0(local_448,2,uVar5,0);
          if (cVar4 != '\0') {
            (**(code **)(*plVar8 + 0x130))(plVar8,local_448);
          }
          pIVar9 = theInstance();
          lVar6 = plVar8[2];
          uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_DENY_ENTER_USER_FULL");
          (**(code **)(lVar6 + 0x358))(plVar8 + 2,uVar7);
          FUN_140368e70(local_448);
        }
      }
      break;
    case 8:
      uVar5 = *(undefined4 *)(param_1 + 0x41c);
      uVar1 = *(undefined4 *)(param_1 + 0x420);
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      local_468 = 4;
      local_470 = puVar2[1];
      local_478 = puVar2[4];
      cVar4 = FUN_140093f60(uVar7,uVar1,uVar5,puVar2[3]);
      if (cVar4 == '\0') {
        **(undefined4 **)(param_1 + 0x428) = 9;
        plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        local_478 = 4;
        (**(code **)(*plVar8 + 0x28))
                  (plVar8,*(undefined4 *)(param_1 + 0x420),
                   *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc),param_1);
      }
      break;
    case 9:
      if (puVar2[1] == 0) {
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar8 = (longlong *)FUN_140087650(uVar7);
        plVar8 = (longlong *)
                 (**(code **)(*plVar8 + 0xa0))
                           (plVar8,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c)
                           );
        if (plVar8 != (longlong *)0x0) {
          FUN_140368e20(local_448);
          uVar5 = (**(code **)(*plVar8 + 0x38))(plVar8);
          cVar4 = FUN_140368ed0(local_448,2,uVar5,0);
          if (cVar4 != '\0') {
            (**(code **)(*plVar8 + 0x130))(plVar8,local_448);
          }
          pIVar9 = theInstance();
          lVar6 = plVar8[2];
          uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_DENY_ENTER_USER_FULL");
          (**(code **)(lVar6 + 0x358))(plVar8 + 2,uVar7);
          FUN_140368e70(local_448);
        }
      }
    }
  }
  return;
}

