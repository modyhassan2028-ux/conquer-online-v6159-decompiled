// ==== CMsgDataArray::helper_140006cb0  @140006cb0  [medium:callgraph-r1]  (orig: FUN_140006cb0)
undefined4 FUN_140006cb0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x18c);
}

// ==== CMsgDataArray::helper_1400ff980  @1400ff980  [medium:callgraph-r1]  (orig: FUN_1400ff980)
void FUN_1400ff980(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                     (*(longlong **)(param_1 + 0x10),0x15);
                    /* WARNING: Could not recover jumptable at 0x0001400ff99d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMsgDataArray::helper_1401010e0  @1401010e0  [medium:callgraph-r1]  (orig: FUN_1401010e0)
bool FUN_1401010e0(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return iVar1 / 10 == 73000;
}

// ==== CMsgDataArray::helper_140104ad0  @140104ad0  [medium:callgraph-r1]  (orig: FUN_140104ad0)
ulonglong FUN_140104ad0(longlong *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined8 uVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  int local_88 [10];
  int local_60 [14];
  
  local_88[1] = 10;
  local_60[0] = 0x14;
  local_60[1] = 0x14;
  local_88[0] = 0;
  local_60[2] = 0x50;
  local_60[3] = 0xf0;
  local_60[4] = 0x2d0;
  local_60[5] = 0x870;
  local_60[6] = 0x1950;
  local_60[7] = 0x4bf0;
  local_60[8] = 0xe3d0;
  local_60[9] = 0xa8c;
  local_60[10] = 0x157c;
  local_60[0xb] = 9000;
  local_88[2] = 0x28;
  local_88[3] = 0x78;
  local_88[4] = 0x168;
  local_88[5] = 0x438;
  local_88[6] = 0xca8;
  local_88[7] = 0x25f8;
  local_88[8] = 0x71e8;
  plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
  iVar2 = (**(code **)(*plVar8 + 0x48))(plVar8);
  uVar12 = (ulonglong)iVar2;
  uVar13 = uVar12;
  if (param_2 - 1U < 8) {
    plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x15);
    iVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
    iVar3 = iVar3 + local_88[param_2];
    if (iVar2 < 0xc) {
      do {
        piVar1 = local_60 + uVar12;
        if (iVar3 < *piVar1) break;
        uVar12 = uVar12 + 1;
        uVar13 = (ulonglong)((int)uVar13 + 1);
        iVar3 = iVar3 - *piVar1;
      } while ((longlong)uVar12 < 0xc);
    }
    plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
    (**(code **)(*plVar8 + 0xb0))(plVar8,uVar13 & 0xffffffff);
    uVar4 = FUN_1400fe190(param_1);
    FUN_140104140(param_1,0x11,uVar4);
    plVar8 = (longlong *)FUN_140087f50();
    plVar9 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],3);
    uVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
    lVar10 = *plVar8;
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar10 + 0x60))(plVar8,uVar4,uVar5);
    plVar8 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar8 = (longlong *)0x0;
    }
    plVar9 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
    uVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
    plVar9 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
    uVar5 = (**(code **)(*plVar9 + 0x48))(plVar9);
    lVar10 = (**(code **)(*plVar8 + 0x78))(plVar8,uVar5,uVar4);
    param_1[5] = lVar10;
    FUN_140103140(param_1);
    (**(code **)(*param_1 + 8))(param_1);
    plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
    uVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
    iVar6 = FUN_1400ff680(uVar4);
    if ((iVar6 == 0x16) && (0xb < (int)uVar13)) {
      lVar10 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
      if (*(longlong *)(lVar10 + 0xb0) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar6 = FUN_140006cb0(*(undefined8 *)(lVar10 + 0xb0));
      if (iVar6 <= iVar3) {
        uVar11 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
        uVar11 = FUN_1400d6610(uVar11);
        iVar3 = FUN_140006cb0(uVar11);
      }
    }
    plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x15);
    (**(code **)(*plVar8 + 0xb0))(plVar8,iVar3);
    uVar7 = (**(code **)(*param_1 + 8))(param_1);
    if ((uVar7 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
      (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
    }
    if (iVar2 < (int)uVar13) {
      plVar8 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar8 = (longlong *)0x0;
      }
      plVar9 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
      uVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
      lVar10 = (**(code **)(*plVar8 + 0x78))(plVar8,uVar4,uVar13 & 0xffffffff);
      param_1[5] = lVar10;
      if (param_1[6] == 0) {
        FUN_140103140(param_1);
      }
    }
  }
  return uVar13 & 0xffffffff;
}

// ==== CMsgDataArray::helper_140104e80  @140104e80  [medium:callgraph-r1]  (orig: FUN_140104e80)
int FUN_140104e80(longlong *param_1)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  ulong uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong lVar13;
  int local_48 [12];
  
  local_48[0] = 0x14;
  local_48[1] = 0x14;
  local_48[2] = 0x50;
  local_48[3] = 0xf0;
  local_48[4] = 0x2d0;
  local_48[5] = 0x870;
  local_48[6] = 0x1950;
  local_48[7] = 0x4bf0;
  local_48[8] = 0xe3d0;
  local_48[9] = 0xa8c;
  local_48[10] = 0x157c;
  local_48[0xb] = 9000;
  plVar11 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
  iVar3 = (**(code **)(*plVar11 + 0x48))(plVar11);
  if (0xb < iVar3) {
    return iVar3;
  }
  plVar11 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x15);
  iVar4 = (**(code **)(*plVar11 + 0x48))(plVar11);
  if (0 < iVar4) {
    iVar8 = local_48[iVar3];
    plVar11 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x15)
    ;
    (**(code **)(*plVar11 + 0xb0))(plVar11,0);
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    if ((uVar5 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
      (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
    }
    else {
      cVar2 = FUN_1401032b0(param_1,0x15);
      if (cVar2 != '\0') {
        FUN_1401033b0(param_1);
        *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
      }
    }
    uVar6 = tq::TimeGet(0);
    iVar7 = rand();
    srand(iVar7 + uVar6);
    iVar8 = tq::RandGet(iVar8);
    if (iVar8 + 1 <= iVar4) {
      iVar4 = iVar3 + 1;
      plVar11 = (longlong *)
                (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
      (**(code **)(*plVar11 + 0xb0))(plVar11,iVar4);
      uVar9 = FUN_1400fe190(param_1);
      FUN_140104140(param_1,0x11,uVar9);
      plVar11 = (longlong *)FUN_140087f50();
      plVar12 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],3);
      uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
      lVar13 = *plVar11;
      uVar10 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar13 + 0x60))(plVar11,uVar9,uVar10);
      plVar11 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      plVar12 = (longlong *)
                (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
      uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
      plVar12 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
      uVar10 = (**(code **)(*plVar12 + 0x48))(plVar12);
      lVar13 = (**(code **)(*plVar11 + 0x78))(plVar11,uVar10,uVar9);
      param_1[5] = lVar13;
      FUN_140103140(param_1);
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      if ((uVar5 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
        (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
      }
      else {
        cVar2 = FUN_1401032b0(param_1,0xc);
        if (cVar2 != '\0') {
          FUN_1401033b0(param_1);
          *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
        }
      }
      bVar1 = iVar3 < iVar4;
      iVar3 = iVar4;
      if (bVar1) {
        plVar11 = (longlong *)FUN_140087d40();
        plVar12 = (longlong *)
                  (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
        uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
        lVar13 = (**(code **)(*plVar11 + 0x78))(plVar11,uVar9,iVar4);
        param_1[5] = lVar13;
        if (param_1[6] == 0) {
          FUN_140103140(param_1);
        }
      }
    }
    return iVar3;
  }
  return iVar3;
}

// ==== CMsgDataArray::helper_1401051a0  @1401051a0  [medium:callgraph-r1]  (orig: FUN_1401051a0)
ulonglong FUN_1401051a0(longlong *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  int local_78 [10];
  int local_50 [14];
  
  local_50[0] = 0x14;
  local_50[1] = 0x14;
  local_50[2] = 0x5a;
  local_50[3] = 0xf0;
  local_50[4] = 0x2d0;
  local_50[5] = 0x870;
  local_50[6] = 0x1950;
  local_50[7] = 0x4bf0;
  local_50[8] = 0xe3d0;
  local_50[9] = 0xa8c;
  local_50[10] = 0x157c;
  local_50[0xb] = 9000;
  local_78[0] = 1;
  local_78[1] = 10;
  local_78[2] = 0x1e;
  local_78[3] = 0x78;
  local_78[4] = 0x168;
  local_78[5] = 0x438;
  local_78[6] = 0xca8;
  local_78[7] = 0x25f8;
  local_78[8] = 0x71e8;
  plVar7 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
  iVar2 = (**(code **)(*plVar7 + 0x48))(plVar7);
  uVar10 = (ulonglong)iVar2;
  uVar11 = uVar10;
  if (param_2 < 9) {
    plVar7 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x15);
    iVar3 = (**(code **)(*plVar7 + 0x48))(plVar7);
    param_3 = iVar3 + local_78[param_2] + param_3;
    if (iVar2 < 0xc) {
      do {
        piVar1 = local_50 + uVar10;
        if (param_3 < *piVar1) break;
        uVar10 = uVar10 + 1;
        uVar11 = (ulonglong)((int)uVar11 + 1);
        param_3 = param_3 - *piVar1;
      } while ((longlong)uVar10 < 0xc);
    }
    plVar7 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
    (**(code **)(*plVar7 + 0xb0))(plVar7,uVar11 & 0xffffffff);
    uVar4 = FUN_1400fe190(param_1);
    FUN_140104140(param_1,0x11,uVar4);
    plVar7 = (longlong *)FUN_140087f50();
    plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],3);
    uVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
    lVar9 = *plVar7;
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar9 + 0x60))(plVar7,uVar4,uVar5);
    plVar7 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar7 = (longlong *)0x0;
    }
    plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
    uVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
    plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
    uVar5 = (**(code **)(*plVar8 + 0x48))(plVar8);
    lVar9 = (**(code **)(*plVar7 + 0x78))(plVar7,uVar5,uVar4);
    param_1[5] = lVar9;
    FUN_140103140(param_1);
    uVar6 = (**(code **)(*param_1 + 8))(param_1);
    if ((uVar6 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
      (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
    }
    if (2000000 < param_3) {
      param_3 = 2000000;
    }
    plVar7 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x15);
    (**(code **)(*plVar7 + 0xb0))(plVar7,param_3);
    uVar6 = (**(code **)(*param_1 + 8))(param_1);
    if ((uVar6 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
      (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
    }
    if (iVar2 < (int)uVar11) {
      plVar7 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar7 = (longlong *)0x0;
      }
      plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
      uVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
      lVar9 = (**(code **)(*plVar7 + 0x78))(plVar7,uVar4,uVar11 & 0xffffffff);
      param_1[5] = lVar9;
      if (param_1[6] == 0) {
        FUN_140103140(param_1);
      }
    }
  }
  return uVar11 & 0xffffffff;
}

// ==== CMsgDataArray::helper_1401054e0  @1401054e0  [medium:callgraph-r1]  (orig: FUN_1401054e0)
int FUN_1401054e0(longlong *param_1)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  ulong uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong lVar13;
  int local_48 [12];
  
  local_48[0] = 0x14;
  local_48[1] = 0x14;
  local_48[2] = 0x5a;
  local_48[3] = 0xf0;
  local_48[4] = 0x2d0;
  local_48[5] = 0x870;
  local_48[6] = 0x1950;
  local_48[7] = 0x4bf0;
  local_48[8] = 0xe3d0;
  local_48[9] = 0xa8c;
  local_48[10] = 0x157c;
  local_48[0xb] = 9000;
  plVar11 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
  iVar3 = (**(code **)(*plVar11 + 0x48))(plVar11);
  if (0xb < iVar3) {
    return iVar3;
  }
  plVar11 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x15);
  iVar4 = (**(code **)(*plVar11 + 0x48))(plVar11);
  if (0 < iVar4) {
    iVar8 = local_48[iVar3];
    plVar11 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x15)
    ;
    (**(code **)(*plVar11 + 0xb0))(plVar11,0);
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    if ((uVar5 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
      (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
    }
    else {
      cVar2 = FUN_1401032b0(param_1,0x15);
      if (cVar2 != '\0') {
        FUN_1401033b0(param_1);
        *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
      }
    }
    uVar6 = tq::TimeGet(0);
    iVar7 = rand();
    srand(iVar7 + uVar6);
    iVar8 = tq::RandGet(iVar8);
    if (iVar8 + 1 <= iVar4) {
      iVar4 = iVar3 + 1;
      plVar11 = (longlong *)
                (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
      (**(code **)(*plVar11 + 0xb0))(plVar11,iVar4);
      uVar9 = FUN_1400fe190(param_1);
      FUN_140104140(param_1,0x11,uVar9);
      plVar11 = (longlong *)FUN_140087f50();
      plVar12 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],3);
      uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
      lVar13 = *plVar11;
      uVar10 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar13 + 0x60))(plVar11,uVar9,uVar10);
      plVar11 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      plVar12 = (longlong *)
                (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
      uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
      plVar12 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
      uVar10 = (**(code **)(*plVar12 + 0x48))(plVar12);
      lVar13 = (**(code **)(*plVar11 + 0x78))(plVar11,uVar10,uVar9);
      param_1[5] = lVar13;
      FUN_140103140(param_1);
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      if ((uVar5 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
        (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
      }
      else {
        cVar2 = FUN_1401032b0(param_1,0xc);
        if (cVar2 != '\0') {
          FUN_1401033b0(param_1);
          *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
        }
      }
      bVar1 = iVar3 < iVar4;
      iVar3 = iVar4;
      if (bVar1) {
        plVar11 = (longlong *)FUN_140087d40();
        plVar12 = (longlong *)
                  (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
        uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
        lVar13 = (**(code **)(*plVar11 + 0x78))(plVar11,uVar9,iVar4);
        param_1[5] = lVar13;
        if (param_1[6] == 0) {
          FUN_140103140(param_1);
        }
      }
    }
    return iVar3;
  }
  return iVar3;
}

// ==== CMsgDataArray::helper_14032bf00  @14032bf00  [medium:callgraph-r2]  (orig: FUN_14032bf00)
uint FUN_14032bf00(longlong param_1,int param_2,char param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  longlong lVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong lVar10;
  uint uVar11;
  
  if (param_2 == 0) {
    return 0;
  }
  plVar9 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar9 = (longlong *)0x0;
  }
  lVar6 = (**(code **)(*plVar9 + 0x60))(plVar9,param_2);
  if (lVar6 != 0) {
    uVar11 = 1;
    uVar2 = FUN_1400fda10(lVar6,1,1);
    cVar1 = FUN_1400ff940(uVar2);
    if ((cVar1 != '\0') && (iVar3 = FUN_1400fda10(lVar6,1,1), 2 < iVar3 % 10)) {
      iVar3 = FUN_1400fda10(lVar6,5,1);
      iVar4 = FUN_1400fda10(lVar6,4,1);
      if (iVar3 / 100 <= iVar4 / 100) {
        uVar5 = FUN_1400fda10(lVar6,1,1);
        plVar9 = (longlong *)FUN_140087d40();
        lVar6 = (**(code **)(*plVar9 + 0x70))(plVar9,uVar5);
        if (lVar6 != 0) {
          while( true ) {
            uVar5 = uVar5 + 10;
            plVar9 = (longlong *)FUN_140087d40();
            lVar10 = (**(code **)(*plVar9 + 0x70))(plVar9,uVar5);
            if (lVar10 != 0) break;
LAB_14032c0d4:
            plVar9 = (longlong *)FUN_140087d40();
            lVar10 = (**(code **)(*plVar9 + 0x70))(plVar9,uVar5);
            if (lVar10 != 0) {
              return uVar5;
            }
            if (0x62 < (uVar5 % 1000) / 10) goto LAB_14032c15f;
            uVar11 = uVar11 + 1;
            if (1000000 < uVar11) {
              log_InlineLogERROR(&DAT_1406d9c10);
              return uVar5;
            }
          }
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))(*(longlong **)(lVar10 + 8),4);
          iVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(lVar6 + 8) + 0x10))(*(longlong **)(lVar6 + 8),4);
          iVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
          if (iVar4 <= iVar3) goto LAB_14032c0d4;
LAB_14032c15f:
          if (param_3 != '\0') {
            pIVar7 = theInstance();
            lVar6 = *(longlong *)(param_1 + 0x10);
            uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_UPGRADE_NOMORE");
            (**(code **)(lVar6 + 0x358))(param_1 + 0x10,uVar8);
          }
        }
        return 0;
      }
      if (param_3 != '\0') {
        pIVar7 = theInstance();
        lVar6 = *(longlong *)(param_1 + 0x10);
        uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_REPAIR_THEN_UPGRADE");
        (**(code **)(lVar6 + 0x358))(param_1 + 0x10,uVar8);
      }
    }
  }
  return 0;
}

// ==== CMsgDataArray::helper_14032c1a0  @14032c1a0  [medium:callgraph-r1]  (orig: FUN_14032c1a0)
undefined8
FUN_14032c1a0(undefined8 param_1,int param_2,int *param_3,int *param_4,undefined1 param_5)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  
  if (param_2 == 0) {
    return 0;
  }
  plVar5 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = (longlong *)0x0;
  }
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x60))(plVar5,param_2);
  if (plVar5 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    iVar4 = FUN_14032bd40(param_1,uVar3,param_5);
    *param_4 = iVar4;
    if (iVar4 != 0) {
      *param_3 = 10000;
      plVar6 = (longlong *)FUN_140087d40();
      iVar4 = FUN_1400fda10(plVar5,1,1);
      lVar1 = *plVar6;
      uVar3 = FUN_1400fda10(plVar5,0x68,1);
      cVar2 = (**(code **)(lVar1 + 0x110))(plVar6,uVar3,iVar4 % 10,param_3);
      if (cVar2 != '\0') {
        if (0 < *param_3) {
          return 1;
        }
        log_InlineLogERROR("CUser::GetUpEpQualityInfo. Chance <= 0 Item[%u]");
      }
    }
  }
  return 0;
}

// ==== CMsgDataArray::helper_14032d7e0  @14032d7e0  [medium:callgraph-r1]  (orig: FUN_14032d7e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14032d7e0(longlong *param_1,longlong param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined1 auStack_8d8 [32];
  undefined4 local_8b8;
  undefined8 local_8a8;
  undefined1 local_898 [1072];
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_8a8 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_8d8;
  if (param_2 != 0) {
    FUN_140387320(local_898);
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    local_8b8 = 2;
    iVar3 = FUN_1403873d0(local_898,param_2,uVar2,0);
    if (iVar3 == 0) {
      local_8b8 = 0x373e;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_898);
    }
    FUN_14039ed70(local_468);
    iVar3 = FUN_14039eef0(local_468,param_1 + 2,0,0);
    if (iVar3 == 0) {
      cVar1 = (**(code **)(param_1[2] + 0x230))(param_1 + 2);
      if ((cVar1 == '\0') || (cVar1 = (**(code **)(param_1[2] + 0x238))(param_1 + 2), cVar1 != '\0')
         ) {
        (**(code **)(*param_1 + 8))(param_1);
        log_InlineLogERROR("CUser::SynchroEquip user[%u] is unvisible.");
      }
    }
    else {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_468,0);
    }
    FUN_14039edf0(local_468);
    FUN_140387370(local_898);
    return;
  }
  local_8b8 = 0x373b;
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgDataArray::helper_140330010  @140330010  [medium:callgraph-r1]  (orig: FUN_140330010)
undefined8
FUN_140330010(longlong param_1,int param_2,undefined8 param_3,int *param_4,int *param_5,char param_6
             )

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  IStringManager *pIVar8;
  undefined8 uVar9;
  
  if (param_2 == 0) {
    return 0;
  }
  plVar6 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar6 = (longlong *)0x0;
  }
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x60))(plVar6,param_2);
  if (plVar6 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
  iVar4 = FUN_14032bf00(param_1,uVar3,param_6);
  *param_5 = iVar4;
  if (iVar4 == 0) {
    return 0;
  }
  uVar3 = FUN_1400fda10(plVar6,1,1);
  iVar4 = FUN_1400ff680(uVar3);
  if (iVar4 != 6) {
    uVar3 = FUN_1400fda10(plVar6,1,1);
    iVar4 = FUN_1400ff680(uVar3);
    if (iVar4 != 3) {
      uVar3 = FUN_1400fda10(plVar6,1,1);
      iVar4 = FUN_1400ff680(uVar3);
      if (iVar4 != 1) {
        plVar7 = (longlong *)FUN_140087d40();
        lVar1 = *plVar7;
        uVar3 = FUN_1401011d0(plVar6);
        uVar5 = FUN_1400fee00(plVar6);
        cVar2 = (**(code **)(lVar1 + 0x100))(plVar7,uVar5,uVar3,param_3,param_4);
        goto LAB_1403301ae;
      }
    }
  }
  plVar7 = (longlong *)FUN_140087d40();
  lVar1 = *plVar7;
  uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
  cVar2 = (**(code **)(lVar1 + 0x108))(plVar7,uVar3,param_3,param_4);
LAB_1403301ae:
  if (cVar2 == '\0') {
    if (param_6 != '\0') {
      pIVar8 = theInstance();
      lVar1 = *(longlong *)(param_1 + 0x10);
      uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_UPGRADE_NOMORE");
      (**(code **)(lVar1 + 0x358))(param_1 + 0x10,uVar9);
    }
    uVar9 = 0;
  }
  else if (*param_4 < 1) {
    FUN_1400fda10(plVar6,1,1);
    log_InlineLogERROR(&DAT_1407521e8);
    uVar9 = 0;
  }
  else {
    uVar9 = 1;
  }
  return uVar9;
}

// ==== CMsgDataArray::helper_140333c80  @140333c80  [medium:callgraph-r1]  (orig: FUN_140333c80)
bool FUN_140333c80(longlong param_1,longlong param_2,int param_3,int param_4,char param_5)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  char cVar4;
  bool bVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  longlong lVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  int iVar12;
  ulonglong uVar13;
  int iVar14;
  int iVar15;
  int local_res10;
  
  lVar1 = *(longlong *)(param_1 + 0xc28);
  lVar2 = *(longlong *)(param_1 + 0xc20);
  iVar15 = 0;
  iVar14 = 0;
  iVar8 = 0;
  local_res10 = 0;
  iVar6 = (int)(*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 2);
  if (iVar6 < 1) {
    return false;
  }
  iVar6 = iVar6 + -1;
  uVar13 = (ulonglong)iVar6;
  iVar7 = 1;
  iVar12 = 0;
  if (-1 < iVar6) {
    do {
      if ((ulonglong)(*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 2) <= uVar13)
      {
        _invalid_parameter_noinfo();
      }
      cVar4 = FUN_140332fe0(param_1,*(undefined4 *)(*(longlong *)(param_2 + 0x18) + uVar13 * 4));
      plVar3 = DAT_140975b60;
      if (cVar4 == '\0') {
        return false;
      }
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      if ((ulonglong)(*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 2) <= uVar13)
      {
        _invalid_parameter_noinfo();
      }
      lVar9 = (**(code **)(*plVar3 + 0x60))
                        (plVar3,*(undefined4 *)(*(longlong *)(param_2 + 0x18) + uVar13 * 4));
      if (lVar9 != 0) {
        cVar4 = FUN_1400ffc20(lVar9);
        if (cVar4 != '\0') {
          return false;
        }
        cVar4 = FUN_1400ffbe0(lVar9);
        if ((cVar4 != '\0') && (param_4 != 1)) {
          return false;
        }
        if (param_5 == '\0') {
          iVar6 = FUN_1400fda10(lVar9,1,1);
          if (iVar6 == 0xafc9c) {
            iVar8 = iVar8 + 1;
          }
          else {
            if (iVar6 != 0x109a00) {
              return false;
            }
            local_res10 = local_res10 + 1;
            iVar6 = FUN_140100000(lVar9);
            iVar15 = iVar15 + iVar6;
          }
        }
        else {
          iVar6 = FUN_1400fda10(lVar9,1,1);
          if (iVar6 == 0xafc9b) {
            iVar8 = iVar8 + 1;
          }
          else if (iVar6 == 0xb0944) {
            iVar14 = iVar14 + 1;
          }
          else {
            if (1 < iVar6 - 0x109a01U) {
              return false;
            }
            local_res10 = local_res10 + 1;
            iVar6 = FUN_140100000(lVar9);
            iVar15 = iVar15 + iVar6;
          }
        }
      }
      uVar13 = uVar13 - 1;
      iVar12 = local_res10;
    } while (-1 < (longlong)uVar13);
  }
  if (iVar15 + (iVar14 + iVar8 * 2) * 5 < param_3) {
    return false;
  }
  param_3 = param_3 - iVar15;
  if (param_3 < 1) {
    return true;
  }
  iVar12 = (0x28 - (int)(lVar1 - lVar2 >> 2)) + iVar12;
  iVar6 = FUN_1400ffd10(0x109a01);
  if (1 < iVar6) {
    iVar7 = FUN_1400ffd10(0x109a01);
  }
  iVar6 = param_3 / 5;
  if ((iVar14 < iVar6) || (param_3 % 5 != 0)) {
    if (iVar6 < iVar14) {
      iVar8 = (iVar7 - param_3 % 5) + 4;
    }
    else {
      iVar12 = iVar12 + iVar14;
      param_3 = param_3 + iVar14 * -5;
      iVar6 = param_3 / 10;
      param_3 = param_3 % 10;
      if (iVar8 < iVar6) {
        return false;
      }
      if ((iVar6 == iVar8) && (0 < param_3)) {
        return false;
      }
      if (param_3 == 0) goto LAB_140333f1d;
      iVar8 = (iVar7 - param_3) + 9;
    }
    bVar5 = iVar8 / iVar7 <= iVar6 + 1 + iVar12;
    if (!bVar5) {
      pIVar10 = theInstance();
      lVar1 = *(longlong *)(param_1 + 0x10);
      uVar11 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_OPEN_ITEM_BAG_FULL");
      (**(code **)(lVar1 + 0x358))(param_1 + 0x10,uVar11);
    }
  }
  else {
LAB_140333f1d:
    bVar5 = true;
  }
  return bVar5;
}

// ==== CMsgDataArray::helper_140333fa0  @140333fa0  [medium:callgraph-r0]  (orig: FUN_140333fa0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140333fa0(longlong *param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 extraout_EAX;
  undefined4 extraout_EAX_00;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  longlong *plVar10;
  IStringManager *pIVar11;
  uint extraout_var;
  char *pcVar12;
  uint extraout_var_00;
  undefined8 uVar13;
  longlong *plVar14;
  undefined1 auStack_8d8 [32];
  undefined8 local_8b8;
  ulonglong local_8b0;
  ulonglong local_8a8;
  undefined4 local_8a0;
  undefined4 local_898;
  char local_888;
  int local_884;
  int local_880;
  longlong *local_878;
  undefined8 local_870;
  char local_868;
  undefined1 local_867 [1022];
  undefined1 local_469;
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_870 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_8d8;
  if ((param_2 != 0) &&
     ((local_880 = param_2, cVar3 = FUN_140332fe0(), cVar3 != '\0' ||
      (cVar3 = FUN_140333220(param_1,param_2), cVar3 != '\0')))) {
    plVar10 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_8b8 = CONCAT44(local_8b8._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar10 = (longlong *)0x0;
    }
    plVar10 = (longlong *)(**(code **)(*plVar10 + 0x60))(plVar10,param_2);
    if (plVar10 != (longlong *)0x0) {
      local_878 = plVar10;
      uVar4 = FUN_1400fda10(plVar10,1,1);
      iVar5 = FUN_1400ff680(uVar4);
      if (iVar5 == 0xe) {
        return 0;
      }
      cVar3 = FUN_14032ef10(plVar10);
      if (cVar3 != '\0') {
        return 0;
      }
      uVar4 = FUN_1400fda10(plVar10,1,1);
      cVar3 = FUN_1400ff940(uVar4);
      if (cVar3 == '\0') {
        return 0;
      }
      cVar3 = FUN_14032ed10(plVar10);
      if (cVar3 == '\0') {
        iVar5 = FUN_1400fda10(plVar10,0xc,1);
        if (0xb < iVar5) {
          return 0;
        }
        iVar5 = FUN_1400ff980(plVar10);
        if (0 < iVar5) {
          lVar2 = param_1[0x1e2];
          plVar1 = param_1 + 2;
          (**(code **)(*plVar1 + 0x18))(plVar1);
          (**(code **)(*param_1 + 8))(param_1);
          local_8a8 = 0;
          local_8b0 = 0;
          local_8b8._0_4_ = (int)lVar2;
          tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t5000\t5000\t%d\t%d\t1\t");
          local_888 = FUN_140104440(plVar10);
          iVar5 = FUN_1400fda10(plVar10,0xc,1);
          iVar6 = FUN_140104e80(plVar10);
          plVar14 = DAT_140975b60;
          local_884 = iVar6;
          if (DAT_140975b60 == (longlong *)0x0) {
            local_8b8._0_4_ = 0x3c0;
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar14 = (longlong *)0x0;
          }
          local_8b0 = local_8b0 & 0xffffffff00000000;
          local_8b8._0_4_ = 0;
          (**(code **)(*plVar14 + 0x130))(plVar14,param_1,plVar10,3);
          if (iVar5 < iVar6) {
            lVar2 = param_1[0x1e2];
            (**(code **)(*plVar1 + 0x18))(plVar1);
            (**(code **)(*param_1 + 8))(param_1);
            local_8a8 = 0;
            local_8b0 = 0;
            local_8b8._0_4_ = (int)lVar2;
            tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t5000\t5001\t%d\t%d\t1\t");
            if (iVar6 < 9) {
              if (5 < iVar6) {
                local_868 = '\0';
                memset(local_867,0,0x3ff);
                pIVar11 = theInstance();
                FUN_140100430(plVar10,0x65);
                (**(code **)(*plVar1 + 0x18))(plVar1);
                pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_ITMEADDLEVEL6");
                local_8b0 = CONCAT44(local_8b0._4_4_,local_884);
                local_8b8._0_4_ = extraout_EAX_00;
                local_8b8._4_4_ = extraout_var_00;
                _snprintf(&local_868,0x400,pcVar12);
                local_469 = 0;
                (**(code **)(*param_1 + 0x140))(param_1,&local_868,1);
              }
            }
            else {
              local_438 = '\0';
              memset(local_437,0,0x3ff);
              pIVar11 = theInstance();
              FUN_140100430(plVar10,0x65);
              (**(code **)(*plVar1 + 0x18))(plVar1);
              pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_ITMEADDLEVEL9");
              local_8b0 = CONCAT44(local_8b0._4_4_,local_884);
              local_8b8._0_4_ = extraout_EAX;
              local_8b8._4_4_ = extraout_var;
              _snprintf(&local_438,0x400,pcVar12);
              local_39 = 0;
              (**(code **)(*param_1 + 0x140))(param_1,&local_438,1);
            }
          }
          if ((local_888 == '\0') && (cVar3 = FUN_140104440(plVar10), cVar3 != '\0')) {
            uVar4 = FUN_1400fda10(plVar10,5,1);
            uVar7 = FUN_1400fda10(plVar10,4,1);
            uVar8 = FUN_1400fda10(plVar10,1,1);
            uVar9 = (**(code **)(*plVar10 + 8))(plVar10);
            (**(code **)(*param_1 + 8))(param_1);
            (**(code **)(param_1[2] + 0x18))();
            local_8a8 = CONCAT44(local_8a8._4_4_,uVar7);
            local_8b0 = CONCAT44(local_8b0._4_4_,uVar8);
            local_8a0 = uVar4;
            local_8b8._0_4_ = uVar9;
            tq::MyLogSave("gmlog/ComposeItemRand",
                          "%s(%u) ComposeItem make:[id=%u, type=%u], dur=%d, max_dur=%d");
          }
          uVar4 = FUN_1400fda10(plVar10,1,1);
          iVar5 = FUN_1400ff680(uVar4);
          if ((iVar5 == 0x16) && (iVar5 = FUN_1400fda10(plVar10,7,1), iVar5 == 0x13)) {
            FUN_1403a6980(&local_868);
            uVar4 = FUN_1400fda10(plVar10,0xc,1);
            uVar7 = FUN_1400ff980(plVar10);
            uVar8 = (**(code **)(*param_1 + 8))(param_1);
            local_898 = 0;
            local_8a0 = 0;
            local_8a8 = local_8a8 & 0xffffffff00000000;
            local_8b0 = local_8b0 & 0xffffffff00000000;
            local_8b8._0_4_ = uVar7;
            iVar5 = FUN_1403a6a30(&local_868,6,uVar8,uVar4);
            if (iVar5 != 0) {
              (**(code **)(param_1[2] + 0x348))(param_1 + 2,&local_868,0);
            }
            FUN_1403a69d0(&local_868);
          }
          uVar13 = FUN_140008520((int)param_1[0x246]);
          uVar13 = FUN_140087c40(uVar13);
          FUN_140261810(uVar13,param_1,0xd);
          uVar4 = (**(code **)(*param_1 + 8))(param_1);
          uVar13 = FUN_140008520((int)param_1[0x246]);
          uVar13 = FUN_140118060(uVar13);
          local_8b8 = (ulonglong)local_8b8._4_4_ << 0x20;
          FUN_140269300(uVar13,uVar4,0x10);
          FUN_140194390(param_1);
          return 1;
        }
        return 0;
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMsgDataArray::helper_140334540  @140334540  [medium:callgraph-r0]  (orig: FUN_140334540)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140334540(longlong *param_1,int param_2)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 extraout_EAX;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong *plVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  char *pcVar12;
  longlong *plVar13;
  uint extraout_var;
  undefined1 auStack_898 [32];
  undefined8 local_878;
  ulonglong local_870;
  undefined8 local_868;
  undefined4 local_860;
  char local_858;
  int local_854;
  longlong *local_850;
  undefined8 local_848;
  char local_838;
  undefined1 local_837 [1022];
  undefined1 local_439;
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_848 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_898;
  if ((param_2 != 0) &&
     ((local_854 = param_2, cVar2 = FUN_140332fe0(), cVar2 != '\0' ||
      (cVar2 = FUN_140333220(param_1,param_2), cVar2 != '\0')))) {
    plVar9 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_878 = CONCAT44(local_878._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar9 = (longlong *)0x0;
    }
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,param_2);
    if (plVar9 != (longlong *)0x0) {
      local_850 = plVar9;
      uVar3 = FUN_1400fda10(plVar9,1,1);
      iVar4 = FUN_1400ff680(uVar3);
      if (iVar4 != 0xe) {
        return 0;
      }
      iVar4 = FUN_1400fda10(plVar9,0xc,1);
      if (iVar4 < 0xc) {
        iVar4 = FUN_1400ff980(plVar9);
        if (0 < iVar4) {
          lVar1 = param_1[0x1e2];
          (**(code **)(param_1[2] + 0x18))(param_1 + 2);
          (**(code **)(*param_1 + 8))(param_1);
          local_868 = 0;
          local_870 = 0;
          local_878._0_4_ = (int)lVar1;
          tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t5000\t5025\t%d\t%d\t1\t");
          local_858 = FUN_140104440(plVar9);
          iVar4 = FUN_1400fda10(plVar9,0xc,1);
          iVar5 = FUN_1401054e0(plVar9);
          plVar13 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            local_878._0_4_ = 0x3c0;
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar13 = (longlong *)0x0;
          }
          local_870 = local_870 & 0xffffffff00000000;
          local_878._0_4_ = 0;
          (**(code **)(*plVar13 + 0x130))(plVar13,param_1,plVar9,3);
          if (iVar4 < iVar5) {
            lVar1 = param_1[0x1e2];
            (**(code **)(param_1[2] + 0x18))(param_1 + 2);
            (**(code **)(*param_1 + 8))(param_1);
            local_868 = 0;
            local_870 = 0;
            local_878._0_4_ = (int)lVar1;
            tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t5000\t5026\t%d\t%d\t1\t");
            if (iVar5 < 9) {
              if (5 < iVar5) {
                local_438 = '\0';
                memset(local_437,0,0x3ff);
                pIVar10 = theInstance();
                FUN_140100430(plVar9,0x65);
                (**(code **)(param_1[2] + 0x18))();
                pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_MOUNTADDLEVEL6");
                local_870 = CONCAT44(local_870._4_4_,iVar5);
                local_878._0_4_ = extraout_EAX;
                local_878._4_4_ = extraout_var;
                _snprintf(&local_438,0x400,pcVar12);
                local_39 = 0;
                (**(code **)(*param_1 + 0x140))(param_1,&local_438,1);
              }
            }
            else {
              local_838 = '\0';
              memset(local_837,0,0x3ff);
              pIVar10 = theInstance();
              uVar11 = FUN_140100430(plVar9,0x65);
              (**(code **)(param_1[2] + 0x18))();
              pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_MOUNTADDLEVEL9");
              local_878 = uVar11;
              local_870._0_4_ = iVar5;
              _snprintf(&local_838,0x400,pcVar12);
              local_439 = 0;
              plVar13 = (longlong *)FUN_140008520((int)param_1[0x246]);
              local_870 = CONCAT44(local_870._4_4_,2000);
              local_878._0_4_ = 0xffffff;
              (**(code **)(*plVar13 + 0x60))(plVar13,&local_838,0xffffffff,0);
            }
          }
          if ((local_858 == '\0') && (cVar2 = FUN_140104440(plVar9), cVar2 != '\0')) {
            uVar3 = FUN_1400fda10(plVar9,5,1);
            uVar6 = FUN_1400fda10(plVar9,4,1);
            uVar7 = FUN_1400fda10(plVar9,1,1);
            uVar8 = (**(code **)(*plVar9 + 8))(plVar9);
            (**(code **)(*param_1 + 8))(param_1);
            (**(code **)(param_1[2] + 0x18))(param_1 + 2);
            local_868 = CONCAT44(local_868._4_4_,uVar6);
            local_870 = CONCAT44(local_870._4_4_,uVar7);
            local_860 = uVar3;
            local_878._0_4_ = uVar8;
            tq::MyLogSave("gmlog/ComposeMountRand",
                          "%s(%u) ComposeItem make:[id=%u, type=%u], dur=%d, max_dur=%d");
          }
          uVar11 = FUN_140008520((int)param_1[0x246]);
          uVar11 = FUN_140087c40(uVar11);
          FUN_140261810(uVar11,param_1,0xd);
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          uVar11 = FUN_140008520((int)param_1[0x246]);
          uVar11 = FUN_140118060(uVar11);
          local_878 = (ulonglong)local_878._4_4_ << 0x20;
          FUN_140269300(uVar11,uVar3,0x10);
          return 1;
        }
        return 0;
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMsgDataArray::helper_140346470  @140346470  [medium:callgraph-r2]  (orig: FUN_140346470)
void FUN_140346470(undefined8 param_1,uint param_2,undefined2 param_3,char param_4)

{
  ulonglong uVar1;
  
  if (0 < (int)param_2) {
    uVar1 = (ulonglong)param_2;
    do {
      FUN_140340e50(param_1,(param_4 != '\0') + 0x109a00,param_3,1,1,0,1);
      uVar1 = uVar1 - 1;
    } while (uVar1 != 0);
  }
  return;
}

// ==== CMsgDataArray::helper_140346500  @140346500  [medium:callgraph-r0]  (orig: FUN_140346500)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140346500(longlong *param_1,int param_2,longlong param_3,uint param_4)

{
  char cVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  longlong *plVar10;
  undefined8 uVar11;
  longlong *plVar12;
  IStringManager *pIVar13;
  char *pcVar14;
  longlong lVar15;
  ulonglong uVar16;
  undefined1 auStack_548 [32];
  ulonglong local_528;
  int local_520;
  undefined4 local_518;
  undefined4 local_510;
  undefined4 local_508;
  undefined4 local_500;
  undefined4 local_4f8;
  undefined4 local_4f0;
  char local_4e8;
  undefined1 local_4e7;
  int local_4e4;
  uint local_4e0;
  int local_4dc;
  int local_4d8;
  int local_4d4;
  undefined4 local_4d0;
  undefined4 local_4cc;
  int local_4c8;
  undefined4 local_4c4;
  int local_4c0;
  undefined4 local_4bc;
  longlong *local_4b8;
  undefined4 local_4b0;
  longlong *local_4a8;
  int local_4a0;
  longlong local_498;
  longlong *local_490;
  longlong *local_488;
  undefined8 local_480;
  char local_478;
  undefined1 local_477 [1022];
  undefined1 local_79;
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_548;
  uVar16 = (ulonglong)(int)param_4;
  if (((param_2 == 0) || (param_3 == 0)) || ((int)param_4 < 1)) {
    return 0;
  }
  local_4e4 = param_2;
  local_4e0 = param_4;
  local_4c8 = param_2;
  local_4a8 = param_1;
  local_498 = param_3;
  cVar1 = FUN_140332fe0();
  if ((cVar1 != '\0') || (cVar1 = FUN_140333220(param_1,param_2), cVar1 != '\0')) {
    plVar10 = (longlong *)FUN_140087d40();
    plVar10 = (longlong *)(**(code **)(*plVar10 + 0x60))(plVar10,param_2);
    if (plVar10 != (longlong *)0x0) {
      local_4b8 = plVar10;
      uVar3 = FUN_1400fda10(plVar10,1,1);
      iVar4 = FUN_1400ff680(uVar3);
      if (iVar4 == 0xe) {
        return 0;
      }
      cVar1 = FUN_14032ef10(plVar10);
      if (cVar1 != '\0') {
        return 0;
      }
      cVar1 = FUN_14032ed10(plVar10);
      if (cVar1 != '\0') {
        return 0;
      }
      iVar4 = FUN_1400fda10(plVar10,0xc,1);
      uVar3 = FUN_1400fda10(plVar10,1,1);
      iVar5 = FUN_1400ff680(uVar3);
      if (iVar5 == 0x16) {
        if (0xc < iVar4) {
          return 0;
        }
        if (iVar4 == 0xc) {
          uVar11 = FUN_140008520((int)param_1[0x246]);
          uVar11 = FUN_1400d6610(uVar11);
          iVar4 = FUN_140006cb0(uVar11);
          iVar5 = FUN_1400ff980(plVar10);
          if (iVar4 <= iVar5) {
            return 0;
          }
        }
      }
      else if (0xb < iVar4) {
        return 0;
      }
      lVar15 = 0;
      if (0 < (int)param_4) {
        do {
          if (param_2 == *(int *)(param_3 + lVar15 * 4)) {
            return 0;
          }
          cVar1 = FUN_140332fe0(param_1);
          if (cVar1 == '\0') {
            return 0;
          }
          plVar12 = (longlong *)FUN_140087d40();
          plVar12 = (longlong *)
                    (**(code **)(*plVar12 + 0x60))(plVar12,*(undefined4 *)(param_3 + lVar15 * 4));
          if (plVar12 == (longlong *)0x0) {
            return 0;
          }
          cVar1 = FUN_1400ffbe0(plVar12);
          if ((cVar1 != '\0') && (cVar1 = FUN_1400ffbe0(plVar10), cVar1 == '\0')) {
            return 0;
          }
          cVar1 = FUN_1400ffc20(plVar12);
          if (((cVar1 != '\0') || (cVar1 = FUN_1400ff650(plVar12,2), cVar1 != '\0')) ||
             (cVar1 = FUN_1400ff650(plVar12,1), cVar1 != '\0')) {
            return 0;
          }
          uVar3 = (**(code **)(*plVar12 + 8))(plVar12);
          cVar1 = FUN_1403380a0(param_1,uVar3);
          if (cVar1 != '\0') {
            return 0;
          }
          uVar3 = FUN_1400fda10(plVar10,1,1);
          cVar1 = FUN_1400ff940(uVar3);
          if ((cVar1 == '\0') && (cVar1 = FUN_14032ed10(plVar10), cVar1 == '\0')) {
            return 0;
          }
          uVar3 = FUN_1400fda10(plVar12,1,1);
          cVar1 = FUN_1400ff940(uVar3);
          if ((cVar1 == '\0') && (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
            return 0;
          }
          uVar11 = FUN_140008520((int)param_1[0x246]);
          cVar1 = FUN_14008a710(uVar11);
          if (cVar1 == '\0') {
            uVar3 = FUN_1400fda10(plVar10,1,1);
            iVar4 = FUN_1400ff680(uVar3);
            uVar3 = FUN_1400fda10(plVar12,1,1);
            iVar5 = FUN_1400ff680(uVar3);
            if ((iVar4 != iVar5) && (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
              return 0;
            }
            uVar3 = FUN_1400fda10(plVar10,1,1);
            cVar1 = FUN_14015f820(uVar3);
            if (cVar1 != '\0') {
              uVar3 = FUN_1400fda10(plVar12,1,1);
              cVar1 = FUN_14015f820(uVar3);
              if ((cVar1 == '\0') && (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
                return 0;
              }
            }
            cVar1 = FUN_14016caf0(plVar10);
            if (((cVar1 != '\0') && (cVar1 = FUN_14016caf0(plVar12), cVar1 == '\0')) &&
               (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
              return 0;
            }
            iVar4 = FUN_1400ff9e0(plVar10);
            if (((iVar4 == 0x26b) && (iVar4 = FUN_1400ff9e0(plVar12), iVar4 != 0x26b)) &&
               (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
              return 0;
            }
            iVar4 = FUN_1400ff9e0(plVar10);
            if (((iVar4 == 0x264) && (iVar4 = FUN_1400ff9e0(plVar12), iVar4 != 0x264)) &&
               (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
              return 0;
            }
            iVar4 = FUN_1400ff9e0(plVar10);
            if (((iVar4 == 0x1ff) && (iVar4 = FUN_1400ff9e0(plVar12), iVar4 != 0x1ff)) &&
               (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
              return 0;
            }
            iVar4 = FUN_1400ff9e0(plVar10);
            if (((iVar4 == 0x265) && (iVar4 = FUN_1400ff9e0(plVar12), iVar4 != 0x265)) &&
               (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
              return 0;
            }
            iVar4 = FUN_1400ff9e0(plVar10);
            if (((iVar4 == 0x269) && (iVar4 = FUN_1400ff9e0(plVar12), iVar4 != 0x269)) &&
               (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
              return 0;
            }
            iVar4 = FUN_1400ff9e0(plVar10);
            if ((iVar4 != 0x264) && (iVar4 = FUN_1400ff9e0(plVar12), iVar4 == 0x264)) {
              return 0;
            }
            iVar4 = FUN_1400ff9e0(plVar10);
            if ((iVar4 != 0x1ff) && (iVar4 = FUN_1400ff9e0(plVar12), iVar4 == 0x1ff)) {
              return 0;
            }
            iVar4 = FUN_1400ff9e0(plVar10);
            if ((iVar4 != 0x265) && (iVar4 = FUN_1400ff9e0(plVar12), iVar4 == 0x265)) {
              return 0;
            }
            iVar4 = FUN_1400ff9e0(plVar10);
            if ((iVar4 != 0x269) && (iVar4 = FUN_1400ff9e0(plVar12), iVar4 == 0x269)) {
              return 0;
            }
            cVar1 = FUN_1400f8840(plVar10);
            if (cVar1 == '\0') {
              iVar4 = FUN_1400ff9e0(plVar12);
              iVar5 = FUN_1400ff9e0(plVar10);
              if ((iVar4 != iVar5) && (cVar1 = FUN_14032ed10(plVar12), cVar1 == '\0')) {
                return 0;
              }
            }
            iVar4 = FUN_1400fda10(plVar12,0xc,1);
            if ((iVar4 < 1) || (8 < iVar4)) {
              return 0;
            }
            cVar1 = FUN_1401010e0(plVar12);
            if ((cVar1 == '\0') && (iVar4 = FUN_1401011d0(plVar12), 5 < iVar4)) {
              iVar4 = FUN_1401011d0(plVar12);
              iVar5 = FUN_1401011d0(plVar10);
              if (iVar5 < iVar4) {
                return 0;
              }
            }
          }
          else {
            cVar1 = FUN_14032ed10(plVar12);
            if (cVar1 == '\0') {
              uVar3 = FUN_1400fda10(plVar10,1,1);
              iVar4 = FUN_1400ff680(uVar3);
              uVar3 = FUN_1400fda10(plVar12,1,1);
              iVar5 = FUN_1400ff680(uVar3);
              if ((iVar4 != iVar5) &&
                 ((cVar1 = FUN_1400f8840(plVar10), cVar1 == '\0' ||
                  (cVar1 = FUN_1400f8840(plVar12), cVar1 == '\0')))) {
                return 0;
              }
            }
            iVar4 = FUN_1400fda10(plVar12,0xc,1);
            if ((iVar4 < 1) || (8 < iVar4)) {
              return 0;
            }
            cVar1 = FUN_1401010e0(plVar12);
            if ((cVar1 == '\0') && (iVar4 = FUN_1401011d0(plVar12), 5 < iVar4)) {
              iVar4 = FUN_1401011d0(plVar12);
              iVar5 = FUN_1401011d0(plVar10);
              if (iVar5 < iVar4) {
                return 0;
              }
            }
          }
          lVar15 = lVar15 + 1;
          uVar16 = (ulonglong)(int)local_4e0;
        } while (lVar15 < (longlong)uVar16);
      }
      local_4e8 = '\0';
      local_4d4 = 0;
      local_4c0 = FUN_1400fda10(plVar10,0xc,1);
      local_4d8 = 0;
      do {
        if ((int)uVar16 <= local_4d8) {
LAB_140346f86:
          iVar4 = local_4d4;
          if (local_4e8 != '\0') {
            if (local_4c0 < local_4d4) {
              if (local_4d4 < 9) {
                if (5 < local_4d4) {
                  local_478 = '\0';
                  memset(local_477,0,0x3ff);
                  pIVar13 = theInstance();
                  uVar16 = FUN_140100430(plVar10,0x65);
                  (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                  pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_ITMEADDLEVEL6")
                  ;
                  local_520 = iVar4;
                  local_528 = uVar16;
                  _snprintf(&local_478,0x400,pcVar14);
                  local_79 = 0;
                  (**(code **)(*param_1 + 0x140))(param_1,&local_478,1);
                }
              }
              else {
                local_478 = '\0';
                memset(local_477,0,0x3ff);
                pIVar13 = theInstance();
                uVar16 = FUN_140100430(plVar10,0x65);
                (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_ITMEADDLEVEL9");
                local_520 = iVar4;
                local_528 = uVar16;
                _snprintf(&local_478,0x400,pcVar14);
                local_79 = 0;
                (**(code **)(*param_1 + 0x140))(param_1,&local_478,1);
              }
            }
            uVar3 = FUN_1400fda10(plVar10,1,1);
            iVar4 = FUN_1400ff680(uVar3);
            if ((iVar4 == 0x16) && (iVar4 = FUN_1400fda10(plVar10,7,1), iVar4 == 0x13)) {
              FUN_1403a6980(&local_478);
              uVar3 = FUN_1400fda10(plVar10,0xc,1);
              uVar6 = FUN_1400ff980(plVar10);
              uVar7 = (**(code **)(*param_1 + 8))(param_1);
              local_508 = 0;
              local_510 = 0;
              local_518 = 0;
              local_520 = 0;
              local_528 = CONCAT44(local_528._4_4_,uVar6);
              iVar4 = FUN_1403a6a30(&local_478,6,uVar7,uVar3);
              if (iVar4 != 0) {
                (**(code **)(param_1[2] + 0x348))(param_1 + 2,&local_478,0);
              }
              FUN_1403a69d0(&local_478);
            }
            uVar11 = FUN_140008520((int)param_1[0x246]);
            uVar11 = FUN_140087c40(uVar11);
            FUN_140261810(uVar11,param_1,0xd);
            uVar3 = (**(code **)(*param_1 + 8))(param_1);
            uVar11 = FUN_140008520((int)param_1[0x246]);
            uVar11 = FUN_140118060(uVar11);
            local_528 = local_528 & 0xffffffff00000000;
            FUN_140269300(uVar11,uVar3,0x10);
            plVar12 = (longlong *)FUN_140087d40();
            local_520 = 0;
            local_528 = local_528 & 0xffffffff00000000;
            (**(code **)(*plVar12 + 0x130))(plVar12,param_1,plVar10,3);
            FUN_140194390(param_1);
            return 1;
          }
          return 0;
        }
        local_4dc = *(int *)(param_3 + (longlong)local_4d8 * 4);
        if (param_2 == local_4dc) {
          local_528 = CONCAT44(local_528._4_4_,0x22be);
          log_InlineLogERROR(&DAT_1406d9c10);
          return 0;
        }
        cVar1 = FUN_140332fe0(param_1,local_4dc);
        if (cVar1 == '\0') {
          log_InlineLogWARNING
                    ("CUser::ComposeItem client send two same item ids to server, item id:%u.");
          goto LAB_140346f86;
        }
        plVar12 = (longlong *)FUN_140087d40();
        plVar12 = (longlong *)(**(code **)(*plVar12 + 0x60))(plVar12);
        local_488 = plVar12;
        if (plVar12 == (longlong *)0x0) goto LAB_140346f86;
        iVar4 = FUN_1400fda10(plVar10,0xc,1);
        uVar3 = FUN_1400fda10(plVar10,1,1);
        iVar5 = FUN_1400ff680(uVar3);
        if (iVar5 == 0x16) {
          if (0xc < iVar4) goto LAB_140346f86;
          if (iVar4 == 0xc) {
            uVar11 = FUN_140008520((int)param_1[0x246]);
            uVar11 = FUN_1400d6610(uVar11);
            iVar4 = FUN_140006cb0(uVar11);
            iVar5 = FUN_1400ff980(plVar10);
            if (iVar4 <= iVar5) goto LAB_140346f86;
          }
        }
        else if (0xb < iVar4) goto LAB_140346f86;
        local_4cc = FUN_1400fda10(plVar12,1,1);
        local_4d0 = FUN_1400fda10(plVar12,0xc,1);
        local_4c4 = FUN_1400ff980(plVar12);
        local_4bc = FUN_1400fda10(plVar12,0xc,1);
        local_4b0 = FUN_1400fda10(plVar10,0xc,1);
        local_490 = param_1 + 2;
        uVar3 = FUN_1400ff980(plVar12);
        uVar6 = FUN_1400fda10(plVar12,1,1);
        uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
        plVar10 = local_4b8;
        uVar8 = FUN_1400ff980(local_4b8);
        iVar4 = FUN_1400fda10(plVar10,1,1);
        uVar9 = (**(code **)(*plVar10 + 8))(plVar10);
        (**(code **)(*local_4a8 + 8))();
        (**(code **)(*local_490 + 0x18))(local_490);
        local_4f8 = local_4bc;
        local_518 = local_4b0;
        local_528 = CONCAT44(local_528._4_4_,uVar9);
        local_520 = iVar4;
        local_510 = uVar8;
        local_508 = uVar7;
        local_500 = uVar6;
        local_4f0 = uVar3;
        tq::MyLogSave("gmlog/ComposeItem",
                      "%s(%u) ComposeItem Main:[id=%u, type=%u, addition_level=%d, addition_exp = %d] Accessory:[id=%u, type=%u, addition_level=%d, addition_exp = %d]"
                     );
        plVar10 = local_4b8;
        cVar1 = FUN_140104440(local_4b8);
        FUN_1400fda10(local_488,0xc,1);
        param_1 = local_4a8;
        cVar2 = FUN_140340190(local_4a8,local_4dc,1,1);
        if (cVar2 == '\0') {
          log_InlineLogERROR(&DAT_140754708);
          goto LAB_140346f86;
        }
        local_4d4 = FUN_140104ad0(plVar10);
        local_4e8 = '\x01';
        local_4e7 = 1;
        local_4a0 = local_4d4;
        if ((cVar1 == '\0') && (cVar1 = FUN_140104440(plVar10), cVar1 != '\0')) {
          uVar3 = FUN_1400fda10(plVar10,5,1);
          uVar6 = FUN_1400fda10(plVar10,4,1);
          iVar4 = FUN_1400fda10(plVar10,1,1);
          uVar7 = (**(code **)(*plVar10 + 8))(plVar10);
          (**(code **)(*param_1 + 8))(param_1);
          (**(code **)(param_1[2] + 0x18))(param_1 + 2);
          local_528 = CONCAT44(local_528._4_4_,uVar7);
          local_520 = iVar4;
          local_518 = uVar6;
          local_510 = uVar3;
          tq::MyLogSave("gmlog/ComposeItem",
                        "%s(%u) ComposeItem make:[id=%u, type=%u], dur=%d, max_dur=%d");
        }
        local_4d8 = local_4d8 + 1;
        uVar16 = (ulonglong)local_4e0;
        param_3 = local_498;
        param_2 = local_4e4;
      } while( true );
    }
  }
  return 0;
}

// ==== CMsgDataArray::helper_140347270  @140347270  [medium:callgraph-r0]  (orig: FUN_140347270)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140347270(longlong *param_1,int param_2,longlong param_3,uint param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  longlong *plVar14;
  longlong *plVar15;
  IStringManager *pIVar16;
  undefined8 uVar17;
  char *pcVar18;
  longlong lVar19;
  ulonglong uVar20;
  undefined1 auStack_918 [32];
  ulonglong local_8f8;
  int local_8f0;
  undefined4 local_8e8;
  undefined4 local_8e0;
  undefined4 local_8d8;
  undefined4 local_8d0;
  int local_8c8;
  undefined4 local_8c0;
  undefined4 local_8b8;
  undefined4 local_8b0;
  char local_8a8;
  undefined4 local_8a4;
  int local_8a0;
  int local_89c;
  int local_898;
  longlong *local_890;
  longlong *local_888;
  uint local_880;
  longlong local_878;
  undefined4 local_870;
  int local_86c;
  undefined4 local_868;
  int local_864;
  longlong *local_860;
  undefined8 local_858;
  char local_848;
  undefined1 local_847 [1022];
  undefined1 local_449;
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_858 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_918;
  uVar20 = (ulonglong)(int)param_4;
  if ((((param_2 != 0) && (param_3 != 0)) && (0 < (int)param_4)) &&
     ((local_888 = param_1, local_880 = param_4, local_878 = param_3, local_86c = param_2,
      local_864 = param_2, cVar1 = FUN_140332fe0(), cVar1 != '\0' ||
      (cVar1 = FUN_140333220(param_1,param_2), cVar1 != '\0')))) {
    plVar14 = (longlong *)FUN_140087d40();
    plVar14 = (longlong *)(**(code **)(*plVar14 + 0x60))(plVar14,param_2);
    if (plVar14 != (longlong *)0x0) {
      lVar19 = 0;
      local_890 = plVar14;
      if (0 < (int)param_4) {
        do {
          iVar3 = *(int *)(param_3 + lVar19 * 4);
          if (param_2 == iVar3) {
            return 0;
          }
          cVar1 = FUN_140332fe0(param_1,iVar3);
          if (cVar1 == '\0') {
            return 0;
          }
          plVar15 = (longlong *)FUN_140087d40();
          plVar15 = (longlong *)(**(code **)(*plVar15 + 0x60))(plVar15,iVar3);
          if (plVar15 == (longlong *)0x0) {
            return 0;
          }
          cVar1 = FUN_1400ffbe0(plVar15);
          if ((cVar1 != '\0') && (cVar1 = FUN_1400ffbe0(plVar14), cVar1 == '\0')) {
            return 0;
          }
          FUN_1400fda10(plVar15,1,1);
          FUN_1400fda10(plVar15,0xc,1);
          FUN_1400ff980(plVar15);
          cVar1 = FUN_1400ffc20(plVar15);
          if (((cVar1 != '\0') || (cVar1 = FUN_1400ff650(plVar15,2), cVar1 != '\0')) ||
             (cVar1 = FUN_1400ff650(plVar15,1), cVar1 != '\0')) {
            return 0;
          }
          uVar2 = (**(code **)(*plVar15 + 8))(plVar15);
          cVar1 = FUN_1403380a0(param_1,uVar2);
          if (cVar1 != '\0') {
            return 0;
          }
          uVar2 = FUN_1400fda10(plVar14,1,1);
          iVar3 = FUN_1400ff680(uVar2);
          if (iVar3 != 0xe) {
            return 0;
          }
          uVar2 = FUN_1400fda10(plVar15,1,1);
          iVar3 = FUN_1400ff680(uVar2);
          if (iVar3 != 0xe) {
            return 0;
          }
          iVar3 = FUN_1400fda10(plVar15,0xc,1);
          if (8 < iVar3) {
            return 0;
          }
          lVar19 = lVar19 + 1;
          param_3 = local_878;
        } while (lVar19 < (longlong)uVar20);
      }
      local_89c = 0;
      while( true ) {
        if ((int)uVar20 <= local_89c) {
          lVar19 = FUN_140008520((int)param_1[0x246]);
          lVar19 = *(longlong *)(lVar19 + 0x1f8);
          if (lVar19 == 0) {
            local_8f8 = CONCAT44(local_8f8._4_4_,0x163);
            log_InlineLogERROR(&DAT_1406d9c10);
            lVar19 = 0;
          }
          FUN_140261810(lVar19,param_1,0xd);
          lVar19 = FUN_140008520((int)param_1[0x246]);
          lVar19 = *(longlong *)(lVar19 + 0x200);
          if (lVar19 == 0) {
            local_8f8 = CONCAT44(local_8f8._4_4_,0x164);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          uVar2 = (**(code **)(*param_1 + 8))(param_1);
          local_8f8 = local_8f8 & 0xffffffff00000000;
          FUN_140269300(lVar19,uVar2,0x10);
          return 1;
        }
        iVar3 = *(int *)(param_3 + (longlong)local_89c * 4);
        local_898 = iVar3;
        if (param_2 == iVar3) {
          local_8f8 = CONCAT44(local_8f8._4_4_,0x2418);
          log_InlineLogERROR(&DAT_1406d9c10);
          return 0;
        }
        cVar1 = FUN_140332fe0(param_1,iVar3);
        if (cVar1 == '\0') break;
        plVar15 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_8f8 = CONCAT44(local_8f8._4_4_,0x3c0);
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar15 = (longlong *)0x0;
        }
        plVar15 = (longlong *)(**(code **)(*plVar15 + 0x60))(plVar15,iVar3);
        local_860 = plVar15;
        if (plVar15 == (longlong *)0x0) break;
        cVar1 = FUN_140104440(plVar15);
        if (cVar1 != '\0') {
          local_8a0 = FUN_1400fda10(plVar15,0xc,1);
          local_8a4 = FUN_1400fda10(plVar14,0xc,1);
          local_870 = FUN_1400fda10(plVar15,5,1);
          local_868 = FUN_1400fda10(plVar15,4,1);
          uVar2 = FUN_1400ff980(plVar15);
          uVar4 = FUN_1400fda10(plVar15,1,1);
          uVar5 = (**(code **)(*plVar15 + 8))(plVar15);
          uVar6 = FUN_1400ff980(plVar14);
          iVar3 = FUN_1400fda10(plVar14,1,1);
          uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
          (**(code **)(*local_888 + 8))(local_888);
          (**(code **)(local_888[2] + 0x18))(local_888 + 2);
          local_8b0 = local_870;
          local_8b8 = local_868;
          local_8c8 = local_8a0;
          local_8e8 = local_8a4;
          local_8f8 = CONCAT44(local_8f8._4_4_,uVar7);
          local_8f0 = iVar3;
          local_8e0 = uVar6;
          local_8d8 = uVar5;
          local_8d0 = uVar4;
          local_8c0 = uVar2;
          tq::MyLogSave("gmlog/ComposeMount",
                        "%s(%u) ComposeItem [id=%u, type=%u, addition_level=%d, addlevel_exp=%d] spend:[id=%u, type=%u, addition_level=%d, addlevel_exp=%d], dur=%d, max_dur=%d"
                       );
          plVar14 = local_890;
          param_1 = local_888;
          plVar15 = local_860;
          iVar3 = local_898;
        }
        local_8a8 = FUN_140104440(plVar14);
        iVar8 = FUN_1400fda10(plVar15,0xe,1);
        iVar9 = FUN_1400fda10(plVar14,0xe,1);
        iVar10 = FUN_1400fda10(plVar15,0xf,1);
        iVar11 = FUN_1400fda10(plVar14,0xf,1);
        iVar12 = FUN_1400fda10(plVar15,0x10,1);
        iVar13 = FUN_1400fda10(plVar14,0x10,1);
        local_8a0 = (iVar13 * 0x5a) / 100 + (iVar12 * 10) / 100;
        local_8a4 = FUN_1400fda10(plVar15,0xc,1);
        uVar2 = FUN_1400ff980(plVar15);
        cVar1 = FUN_140340190(param_1,iVar3,1,1);
        if (cVar1 == '\0') {
          log_InlineLogERROR(&DAT_140754938);
          return 0;
        }
        iVar3 = FUN_1400fda10(plVar14,0xc,1);
        iVar12 = FUN_1401051a0(plVar14,local_8a4,uVar2);
        FUN_140104140(plVar14,0xe,(iVar9 * 0x5a) / 100 + (iVar8 * 10) / 100);
        FUN_140104140(plVar14,0xf,(iVar11 * 0x5a) / 100 + (iVar10 * 10) / 100);
        FUN_140104140(plVar14,0x10,local_8a0,1);
        plVar15 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_8f8 = CONCAT44(local_8f8._4_4_,0x3c0);
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar15 = (longlong *)0x0;
        }
        local_8f0 = 0;
        local_8f8 = local_8f8 & 0xffffffff00000000;
        (**(code **)(*plVar15 + 0x130))(plVar15,param_1,plVar14);
        if (iVar3 < iVar12) {
          if (iVar12 < 9) {
            if (5 < iVar12) {
              local_448 = '\0';
              memset(local_447,0,0x3ff);
              pIVar16 = theInstance();
              uVar20 = FUN_140100430(plVar14,0x65);
              (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              pcVar18 = (char *)(*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_MOUNTADDLEVEL6");
              local_8f8 = uVar20;
              local_8f0 = iVar12;
              _snprintf(&local_448,0x400,pcVar18);
              local_49 = 0;
              (**(code **)(*param_1 + 0x140))(param_1,&local_448,1);
              plVar14 = local_890;
            }
          }
          else {
            local_848 = '\0';
            memset(local_847,0,0x3ff);
            pIVar16 = theInstance();
            uVar17 = FUN_140100430(plVar14,0x65);
            (**(code **)(param_1[2] + 0x18))(param_1 + 2);
            pcVar18 = (char *)(*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_MOUNTADDLEVEL9");
            local_8f8 = uVar17;
            local_8f0 = iVar12;
            _snprintf(&local_848,0x400,pcVar18);
            local_449 = 0;
            plVar14 = (longlong *)FUN_140008520((int)param_1[0x246]);
            local_8f0 = 2000;
            local_8f8 = CONCAT44(local_8f8._4_4_,0xffffff);
            (**(code **)(*plVar14 + 0x60))(plVar14,&local_848,0xffffffff);
            plVar14 = local_890;
          }
        }
        if ((local_8a8 == '\0') && (cVar1 = FUN_140104440(plVar14), cVar1 != '\0')) {
          local_8a4 = FUN_1400fda10(plVar14,0xc,1);
          uVar2 = FUN_1400fda10(plVar14,5,1);
          uVar4 = FUN_1400fda10(plVar14,4,1);
          uVar5 = FUN_1400ff980(plVar14);
          iVar3 = FUN_1400fda10(plVar14,1,1);
          uVar6 = (**(code **)(*plVar14 + 8))(plVar14);
          (**(code **)(*local_888 + 8))(local_888);
          (**(code **)(param_1[2] + 0x18))(param_1 + 2);
          local_8e8 = local_8a4;
          local_8f8 = CONCAT44(local_8f8._4_4_,uVar6);
          local_8f0 = iVar3;
          local_8e0 = uVar5;
          local_8d8 = uVar4;
          local_8d0 = uVar2;
          tq::MyLogSave("gmlog/ComposeMount",
                        "%s(%u) ComposeItem make:[id=%u, type=%u, addition_level=%d, addlevel_exp=%d], dur=%d, max_dur=%d"
                       );
          param_1 = local_888;
        }
        local_89c = local_89c + 1;
        uVar20 = (ulonglong)local_880;
        param_3 = local_878;
        plVar14 = local_890;
        param_2 = local_86c;
      }
      log_InlineLogWARNING
                ("CUser::ComposeMount client send two same item ids to server, item id:%u.");
      return 0;
    }
  }
  return 0;
}

// ==== CMsgDataArray::helper_140347c70  @140347c70  [medium:callgraph-r0]  (orig: FUN_140347c70)
undefined1 FUN_140347c70(undefined8 param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  
  cVar1 = FUN_140347270();
  if (cVar1 == '\0') {
    return 0;
  }
  cVar1 = FUN_140332fe0(param_1,param_2);
  if ((cVar1 == '\0') && (cVar1 = FUN_140333220(param_1,param_2), cVar1 == '\0')) {
    return 0;
  }
  plVar6 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar6 = (longlong *)0x0;
  }
  lVar5 = (**(code **)(*plVar6 + 0x60))(plVar6,param_2);
  if (lVar5 == 0) {
    return 0;
  }
  iVar2 = FUN_1400fda10(lVar5,0xe,1);
  iVar3 = FUN_1400fda10(lVar5,0xf,1);
  iVar4 = FUN_1400fda10(lVar5,0x10,1);
  FUN_140104140(lVar5,0xd,(iVar2 * 0x100 + iVar3) * 0x100 + iVar4,1);
  plVar6 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar6 = (longlong *)0x0;
  }
  (**(code **)(*plVar6 + 0x130))(plVar6,param_1,lVar5,3,0,0);
  return 1;
}

// ==== CMsgDataArray::helper_1403507b0  @1403507b0  [medium:callgraph-r1]  (orig: FUN_1403507b0)
undefined8 FUN_1403507b0(undefined8 param_1,longlong param_2,int param_3,int param_4,char param_5)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  longlong *plVar7;
  undefined8 uVar8;
  longlong lVar9;
  ulonglong uVar10;
  undefined4 *puVar11;
  int iVar12;
  ulonglong *puVar13;
  ulonglong uVar14;
  ulonglong *puVar15;
  undefined4 *puVar16;
  undefined4 *puVar17;
  ulonglong uVar18;
  int iVar19;
  ulonglong *puVar20;
  uint local_res10;
  ulonglong *local_198 [3];
  undefined4 *local_180;
  undefined4 *local_178;
  longlong local_170;
  ulonglong *local_168 [3];
  undefined4 *local_150;
  undefined4 *local_148;
  longlong local_140;
  ulonglong *local_138 [3];
  undefined4 *local_120;
  undefined4 *local_118;
  longlong local_110;
  uint local_108;
  ulonglong *local_100;
  int local_f4;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  uVar18 = *(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 2;
  puVar13 = (ulonglong *)0x0;
  iVar4 = 0;
  local_108 = 0;
  local_res10 = 0;
  if (uVar18 == 0) {
LAB_140352745:
    uVar8 = 1;
  }
  else {
    local_f4 = param_3;
    local_100 = operator_new(8);
    local_168[0] = puVar13;
    if (local_100 != (ulonglong *)0x0) {
      *local_100 = (ulonglong)local_168;
      local_168[0] = local_100;
    }
    local_150 = (undefined4 *)0x0;
    local_148 = (undefined4 *)0x0;
    local_140 = 0;
    local_e8 = local_100;
    local_100 = operator_new(8);
    local_138[0] = puVar13;
    if (local_100 != (ulonglong *)0x0) {
      *local_100 = (ulonglong)local_138;
      local_138[0] = local_100;
    }
    local_120 = (undefined4 *)0x0;
    local_118 = (undefined4 *)0x0;
    local_110 = 0;
    local_e8 = local_100;
    local_100 = operator_new(8);
    local_198[0] = puVar13;
    if (local_100 != (ulonglong *)0x0) {
      *local_100 = (ulonglong)local_198;
      local_198[0] = local_100;
    }
    local_180 = (undefined4 *)0x0;
    local_178 = (undefined4 *)0x0;
    local_170 = 0;
    local_e8 = local_100;
    puVar15 = puVar13;
    puVar20 = puVar13;
    puVar11 = local_150;
    iVar19 = local_f4;
    uVar14 = uVar18;
    while (uVar14 = uVar14 - 1, local_150 = puVar11, local_f4 = iVar19, uVar14 < uVar18) {
      if ((ulonglong)(*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 2) <= uVar14)
      {
        _invalid_parameter_noinfo();
      }
      cVar3 = FUN_140332fe0(param_1,*(undefined4 *)(*(longlong *)(param_2 + 0x18) + uVar14 * 4));
      plVar7 = DAT_140975b60;
      if (cVar3 == '\0') {
        if (local_180 != (undefined4 *)0x0) {
          operator_delete(local_180);
        }
        local_180 = (undefined4 *)0x0;
        local_178 = (undefined4 *)0x0;
        local_170 = 0;
        operator_delete(local_198[0]);
        if (local_120 != (undefined4 *)0x0) {
          operator_delete(local_120);
        }
        local_120 = (undefined4 *)0x0;
        local_118 = (undefined4 *)0x0;
        local_110 = 0;
        operator_delete(local_138[0]);
        if (local_150 != (undefined4 *)0x0) {
          operator_delete(local_150);
        }
        local_150 = (undefined4 *)0x0;
        local_148 = (undefined4 *)0x0;
        local_140 = 0;
        operator_delete(local_168[0]);
        return 0;
      }
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      if ((ulonglong)(*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 2) <= uVar14)
      {
        _invalid_parameter_noinfo();
      }
      plVar7 = (longlong *)
               (**(code **)(*plVar7 + 0x60))
                         (plVar7,*(undefined4 *)(*(longlong *)(param_2 + 0x18) + uVar14 * 4));
      if (plVar7 == (longlong *)0x0) goto LAB_140351182;
      cVar3 = FUN_1400ffbe0(plVar7);
      if (((cVar3 != '\0') && (param_4 != 1)) || (cVar3 = FUN_1400ffc20(plVar7), cVar3 != '\0')) {
        if (local_180 != (undefined4 *)0x0) {
          operator_delete(local_180);
        }
        local_180 = (undefined4 *)0x0;
        local_178 = (undefined4 *)0x0;
        local_170 = 0;
        operator_delete(local_198[0]);
        if (local_120 != (undefined4 *)0x0) {
          operator_delete(local_120);
        }
        local_120 = (undefined4 *)0x0;
        local_118 = (undefined4 *)0x0;
        local_110 = 0;
        operator_delete(local_138[0]);
        if (local_150 != (undefined4 *)0x0) {
          operator_delete(local_150);
        }
        local_150 = (undefined4 *)0x0;
        local_148 = (undefined4 *)0x0;
        local_140 = 0;
        operator_delete(local_168[0]);
        return 0;
      }
      if (param_5 == '\0') {
        iVar4 = FUN_1400fda10(plVar7,1,1);
        if (iVar4 == 0xafc9c) {
          iVar4 = FUN_140100000(plVar7);
          local_res10 = (int)puVar13 + iVar4;
          puVar13 = (ulonglong *)(ulonglong)local_res10;
          uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
          puVar11 = local_178;
          local_100 = (ulonglong *)CONCAT44(local_100._4_4_,uVar5);
          if (local_180 == (undefined4 *)0x0) {
            uVar10 = 0;
          }
          else {
            uVar10 = local_170 - (longlong)local_180 >> 2;
          }
          if ((ulonglong)((longlong)local_178 - (longlong)local_180 >> 2) < uVar10) {
            *local_178 = uVar5;
            local_178 = local_178 + 1;
          }
          else {
            if (local_178 < local_180) {
              _invalid_parameter_noinfo();
            }
            puVar16 = local_180;
            puVar13 = local_198[0];
            local_c8 = local_198[0];
            uStack_c0 = puVar11;
            if (((longlong)local_178 - (longlong)local_180 & 0xfffffffffffffffcU) == 0) {
              lVar9 = 0;
            }
            else {
              if (local_178 < local_180) {
                _invalid_parameter_noinfo();
              }
              if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_198[0])) {
                _invalid_parameter_noinfo();
              }
              lVar9 = (longlong)puVar11 - (longlong)puVar16 >> 2;
            }
            local_58 = (undefined4)local_c8;
            uStack_54 = local_c8._4_4_;
            uStack_50 = (undefined4)uStack_c0;
            uStack_4c = uStack_c0._4_4_;
            FUN_140036c20(local_198,&local_58,1,&local_100);
            puVar11 = local_180;
            if (local_178 < local_180) {
              _invalid_parameter_noinfo();
            }
            puVar13 = local_198[0];
            if (local_198[0] == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar10 = 0;
            }
            else {
              uVar10 = *local_198[0];
            }
            if (*(undefined4 **)(uVar10 + 0x20) < puVar11 + lVar9) {
LAB_14035112e:
              _invalid_parameter_noinfo();
            }
            else {
              if (puVar13 == (ulonglong *)0x0) {
                uVar10 = 0;
              }
              else {
                uVar10 = *puVar13;
              }
              if (puVar11 + lVar9 < *(undefined4 **)(uVar10 + 0x18)) goto LAB_14035112e;
            }
            puVar15 = (ulonglong *)(ulonglong)local_108;
            puVar13 = (ulonglong *)(ulonglong)local_res10;
          }
        }
        else {
          if (iVar4 != 0x109a00) {
            if (local_180 != (undefined4 *)0x0) {
              operator_delete(local_180);
            }
            local_180 = (undefined4 *)0x0;
            local_178 = (undefined4 *)0x0;
            local_170 = 0;
            operator_delete(local_198[0]);
            if (local_120 != (undefined4 *)0x0) {
              operator_delete(local_120);
            }
            local_120 = (undefined4 *)0x0;
            local_118 = (undefined4 *)0x0;
            local_110 = 0;
            operator_delete(local_138[0]);
            if (local_150 != (undefined4 *)0x0) {
              operator_delete(local_150);
            }
            local_150 = (undefined4 *)0x0;
            local_148 = (undefined4 *)0x0;
            local_140 = 0;
            operator_delete(local_168[0]);
            return 0;
          }
          iVar4 = FUN_140100000(plVar7);
          puVar20 = (ulonglong *)(ulonglong)(uint)((int)puVar20 + iVar4);
          uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
          puVar11 = local_148;
          local_100 = (ulonglong *)CONCAT44(local_100._4_4_,uVar5);
          if (local_150 == (undefined4 *)0x0) {
            uVar10 = 0;
          }
          else {
            uVar10 = local_140 - (longlong)local_150 >> 2;
          }
          if ((ulonglong)((longlong)local_148 - (longlong)local_150 >> 2) < uVar10) {
            *local_148 = uVar5;
            local_148 = local_148 + 1;
          }
          else {
            if (local_148 < local_150) {
              _invalid_parameter_noinfo();
            }
            puVar16 = local_150;
            puVar13 = local_168[0];
            local_d8 = local_168[0];
            uStack_d0 = puVar11;
            if (((longlong)local_148 - (longlong)local_150 & 0xfffffffffffffffcU) == 0) {
              lVar9 = 0;
            }
            else {
              if (local_148 < local_150) {
                _invalid_parameter_noinfo();
              }
              if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_168[0])) {
                _invalid_parameter_noinfo();
              }
              lVar9 = (longlong)puVar11 - (longlong)puVar16 >> 2;
            }
            local_98 = (undefined4)local_d8;
            uStack_94 = local_d8._4_4_;
            uStack_90 = (undefined4)uStack_d0;
            uStack_8c = uStack_d0._4_4_;
            FUN_140036c20(local_168,&local_98,1,&local_100);
            puVar11 = local_150;
            if (local_148 < local_150) {
              _invalid_parameter_noinfo();
            }
            puVar13 = local_168[0];
            if (local_168[0] == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar10 = 0;
            }
            else {
              uVar10 = *local_168[0];
            }
            if (puVar11 + lVar9 <= *(undefined4 **)(uVar10 + 0x20)) {
              if (puVar13 == (ulonglong *)0x0) {
                uVar10 = 0;
              }
              else {
                uVar10 = *puVar13;
              }
              if (*(undefined4 **)(uVar10 + 0x18) <= puVar11 + lVar9) {
                puVar15 = (ulonglong *)(ulonglong)local_108;
                puVar13 = (ulonglong *)(ulonglong)local_res10;
                goto LAB_140351182;
              }
            }
            _invalid_parameter_noinfo();
            puVar15 = (ulonglong *)(ulonglong)local_108;
            puVar13 = (ulonglong *)(ulonglong)local_res10;
          }
        }
      }
      else {
        iVar4 = FUN_1400fda10(plVar7,1,1);
        if (iVar4 == 0xafc9b) {
          iVar4 = FUN_140100000(plVar7);
          local_res10 = (int)puVar13 + iVar4;
          puVar13 = (ulonglong *)(ulonglong)local_res10;
          uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
          puVar11 = local_178;
          local_100 = (ulonglong *)CONCAT44(local_100._4_4_,uVar5);
          if (local_180 == (undefined4 *)0x0) {
            uVar10 = 0;
          }
          else {
            uVar10 = local_170 - (longlong)local_180 >> 2;
          }
          if ((ulonglong)((longlong)local_178 - (longlong)local_180 >> 2) < uVar10) {
            *local_178 = uVar5;
            local_178 = local_178 + 1;
          }
          else {
            if (local_178 < local_180) {
              _invalid_parameter_noinfo();
            }
            puVar16 = local_180;
            puVar13 = local_198[0];
            local_b8 = local_198[0];
            uStack_b0 = puVar11;
            if (((longlong)local_178 - (longlong)local_180 & 0xfffffffffffffffcU) == 0) {
              lVar9 = 0;
            }
            else {
              if (local_178 < local_180) {
                _invalid_parameter_noinfo();
              }
              if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_198[0])) {
                _invalid_parameter_noinfo();
              }
              lVar9 = (longlong)puVar11 - (longlong)puVar16 >> 2;
            }
            local_68 = (undefined4)local_b8;
            uStack_64 = local_b8._4_4_;
            uStack_60 = (undefined4)uStack_b0;
            uStack_5c = uStack_b0._4_4_;
            FUN_140036c20(local_198,&local_68,1,&local_100);
            puVar11 = local_180;
            if (local_178 < local_180) {
              _invalid_parameter_noinfo();
            }
            puVar13 = local_198[0];
            if (local_198[0] == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar10 = 0;
            }
            else {
              uVar10 = *local_198[0];
            }
            if (puVar11 + lVar9 <= *(undefined4 **)(uVar10 + 0x20)) {
              if (puVar13 == (ulonglong *)0x0) {
                uVar10 = 0;
              }
              else {
                uVar10 = *puVar13;
              }
              if (*(undefined4 **)(uVar10 + 0x18) <= puVar11 + lVar9) {
                puVar15 = (ulonglong *)(ulonglong)local_108;
                puVar13 = (ulonglong *)(ulonglong)local_res10;
                goto LAB_140351182;
              }
            }
            _invalid_parameter_noinfo();
            puVar15 = (ulonglong *)(ulonglong)local_108;
            puVar13 = (ulonglong *)(ulonglong)local_res10;
          }
        }
        else if (iVar4 == 0xb0944) {
          iVar4 = FUN_140100000(plVar7);
          local_108 = (int)puVar15 + iVar4;
          puVar15 = (ulonglong *)(ulonglong)local_108;
          uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
          puVar11 = local_118;
          local_100 = (ulonglong *)CONCAT44(local_100._4_4_,uVar5);
          if (local_120 == (undefined4 *)0x0) {
            uVar10 = 0;
          }
          else {
            uVar10 = local_110 - (longlong)local_120 >> 2;
          }
          if ((ulonglong)((longlong)local_118 - (longlong)local_120 >> 2) < uVar10) {
            *local_118 = uVar5;
            local_118 = local_118 + 1;
          }
          else {
            if (local_118 < local_120) {
              _invalid_parameter_noinfo();
            }
            puVar16 = local_120;
            puVar13 = local_138[0];
            local_a8 = local_138[0];
            uStack_a0 = puVar11;
            if (((longlong)local_118 - (longlong)local_120 & 0xfffffffffffffffcU) == 0) {
              lVar9 = 0;
            }
            else {
              if (local_118 < local_120) {
                _invalid_parameter_noinfo();
              }
              if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_138[0])) {
                _invalid_parameter_noinfo();
              }
              lVar9 = (longlong)puVar11 - (longlong)puVar16 >> 2;
            }
            local_88 = (undefined4)local_a8;
            uStack_84 = local_a8._4_4_;
            uStack_80 = (undefined4)uStack_a0;
            uStack_7c = uStack_a0._4_4_;
            FUN_140036c20(local_138,&local_88,1,&local_100);
            puVar11 = local_120;
            if (local_118 < local_120) {
              _invalid_parameter_noinfo();
            }
            puVar13 = local_138[0];
            if (local_138[0] == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar10 = 0;
            }
            else {
              uVar10 = *local_138[0];
            }
            if (puVar11 + lVar9 <= *(undefined4 **)(uVar10 + 0x20)) {
              if (puVar13 == (ulonglong *)0x0) {
                uVar10 = 0;
              }
              else {
                uVar10 = *puVar13;
              }
              if (*(undefined4 **)(uVar10 + 0x18) <= puVar11 + lVar9) {
                puVar15 = (ulonglong *)(ulonglong)local_108;
                puVar13 = (ulonglong *)(ulonglong)local_res10;
                goto LAB_140351182;
              }
            }
            _invalid_parameter_noinfo();
            puVar15 = (ulonglong *)(ulonglong)local_108;
            puVar13 = (ulonglong *)(ulonglong)local_res10;
          }
        }
        else {
          if (1 < iVar4 - 0x109a01U) {
            if (local_180 != (undefined4 *)0x0) {
              operator_delete(local_180);
            }
            local_180 = (undefined4 *)0x0;
            local_178 = (undefined4 *)0x0;
            local_170 = 0;
            operator_delete(local_198[0]);
            if (local_120 != (undefined4 *)0x0) {
              operator_delete(local_120);
            }
            local_120 = (undefined4 *)0x0;
            local_118 = (undefined4 *)0x0;
            local_110 = 0;
            operator_delete(local_138[0]);
            if (local_150 != (undefined4 *)0x0) {
              operator_delete(local_150);
            }
            local_150 = (undefined4 *)0x0;
            local_148 = (undefined4 *)0x0;
            local_140 = 0;
            operator_delete(local_168[0]);
            return 0;
          }
          iVar4 = FUN_140100000(plVar7);
          puVar20 = (ulonglong *)(ulonglong)(uint)((int)puVar20 + iVar4);
          uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
          puVar11 = local_148;
          local_100 = (ulonglong *)CONCAT44(local_100._4_4_,uVar5);
          if (local_150 == (undefined4 *)0x0) {
            uVar10 = 0;
          }
          else {
            uVar10 = local_140 - (longlong)local_150 >> 2;
          }
          if ((ulonglong)((longlong)local_148 - (longlong)local_150 >> 2) < uVar10) {
            *local_148 = uVar5;
            local_148 = local_148 + 1;
          }
          else {
            if (local_148 < local_150) {
              _invalid_parameter_noinfo();
            }
            puVar16 = local_150;
            puVar13 = local_168[0];
            local_e8 = local_168[0];
            uStack_e0 = puVar11;
            if (((longlong)local_148 - (longlong)local_150 & 0xfffffffffffffffcU) == 0) {
              lVar9 = 0;
            }
            else {
              if (local_148 < local_150) {
                _invalid_parameter_noinfo();
              }
              if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_168[0])) {
                _invalid_parameter_noinfo();
              }
              lVar9 = (longlong)puVar11 - (longlong)puVar16 >> 2;
            }
            local_78 = (undefined4)local_e8;
            uStack_74 = local_e8._4_4_;
            uStack_70 = (undefined4)uStack_e0;
            uStack_6c = uStack_e0._4_4_;
            FUN_140036c20(local_168,&local_78,1,&local_100);
            puVar11 = local_150;
            if (local_148 < local_150) {
              _invalid_parameter_noinfo();
            }
            puVar13 = local_168[0];
            if (local_168[0] == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar10 = 0;
            }
            else {
              uVar10 = *local_168[0];
            }
            if (puVar11 + lVar9 <= *(undefined4 **)(uVar10 + 0x20)) {
              if (puVar13 == (ulonglong *)0x0) {
                uVar10 = 0;
              }
              else {
                uVar10 = *puVar13;
              }
              if (*(undefined4 **)(uVar10 + 0x18) <= puVar11 + lVar9) {
                puVar15 = (ulonglong *)(ulonglong)local_108;
                puVar13 = (ulonglong *)(ulonglong)local_res10;
                goto LAB_140351182;
              }
            }
            _invalid_parameter_noinfo();
            puVar15 = (ulonglong *)(ulonglong)local_108;
            puVar13 = (ulonglong *)(ulonglong)local_res10;
          }
        }
      }
LAB_140351182:
      iVar4 = (int)puVar20;
      puVar11 = local_150;
      iVar19 = local_f4;
    }
    if (iVar4 < iVar19) {
      puVar13 = local_168[0];
      if (local_148 < puVar11) {
        _invalid_parameter_noinfo();
        puVar13 = local_168[0];
      }
      while( true ) {
        puVar16 = local_148;
        if (local_148 < local_150) {
          _invalid_parameter_noinfo();
        }
        if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_168[0])) {
          _invalid_parameter_noinfo();
        }
        uVar2 = local_108;
        puVar17 = local_120;
        if (puVar11 == puVar16) {
          iVar19 = iVar19 - iVar4;
          uVar1 = iVar19 / 5;
          iVar4 = iVar19 % 5;
          if ((int)uVar1 < (int)local_108) {
            if (iVar4 == 0) {
              if (local_118 < local_120) {
                _invalid_parameter_noinfo();
              }
              puVar13 = local_138[0];
              uVar14 = 0;
              uVar18 = uVar14;
              while( true ) {
                puVar11 = local_118;
                if (local_118 < local_120) {
                  _invalid_parameter_noinfo();
                }
                if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_138[0])) {
                  _invalid_parameter_noinfo();
                }
                if ((puVar17 == puVar11) || ((int)uVar1 <= (int)uVar18)) break;
                if (puVar13 == (ulonglong *)0x0) {
                  _invalid_parameter_noinfo();
                  uVar10 = uVar14;
                }
                else {
                  uVar10 = *puVar13;
                }
                if (*(undefined4 **)(uVar10 + 0x20) <= puVar17) {
                  _invalid_parameter_noinfo();
                }
                cVar3 = FUN_140340190(param_1,*puVar17,1,1);
                if (cVar3 == '\0') {
                  if (local_180 != (undefined4 *)0x0) {
                    operator_delete(local_180);
                  }
                  local_180 = (undefined4 *)0x0;
                  local_178 = (undefined4 *)0x0;
                  local_170 = 0;
                  operator_delete(local_198[0]);
                  if (local_120 != (undefined4 *)0x0) {
                    operator_delete(local_120);
                  }
                  local_120 = (undefined4 *)0x0;
                  local_118 = (undefined4 *)0x0;
                  local_110 = 0;
                  operator_delete(local_138[0]);
                  if (local_150 != (undefined4 *)0x0) {
                    operator_delete(local_150);
                  }
                  local_150 = (undefined4 *)0x0;
                  local_148 = (undefined4 *)0x0;
                  local_140 = 0;
                  operator_delete(local_168[0]);
                  return 0;
                }
                if (puVar13 == (ulonglong *)0x0) {
                  _invalid_parameter_noinfo();
                  uVar10 = uVar14;
                }
                else {
                  uVar10 = *puVar13;
                }
                if (*(undefined4 **)(uVar10 + 0x20) <= puVar17) {
                  _invalid_parameter_noinfo();
                }
                puVar17 = puVar17 + 1;
                uVar18 = (ulonglong)((int)uVar18 + 1);
              }
              if (local_180 != (undefined4 *)0x0) {
                operator_delete(local_180);
              }
              local_180 = (undefined4 *)0x0;
              local_178 = (undefined4 *)0x0;
              local_170 = 0;
              operator_delete(local_198[0]);
              if (local_120 != (undefined4 *)0x0) {
                operator_delete(local_120);
              }
              local_120 = (undefined4 *)0x0;
              local_118 = (undefined4 *)0x0;
              local_110 = 0;
              operator_delete(local_138[0]);
              if (local_150 != (undefined4 *)0x0) {
                operator_delete(local_150);
              }
              local_150 = (undefined4 *)0x0;
              local_148 = (undefined4 *)0x0;
              local_140 = 0;
              operator_delete(local_168[0]);
              return 1;
            }
            if (local_118 < local_120) {
              _invalid_parameter_noinfo();
            }
            puVar13 = local_138[0];
            iVar6 = 0;
            iVar19 = iVar6;
            while( true ) {
              puVar11 = local_118;
              if (local_118 < local_120) {
                _invalid_parameter_noinfo();
              }
              if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_138[0])) {
                _invalid_parameter_noinfo();
              }
              if ((puVar17 == puVar11) || ((int)(uVar1 + 1) <= iVar6)) {
                FUN_140346470(param_1,5 - iVar4,iVar19,param_5);
                if (local_180 != (undefined4 *)0x0) {
                  operator_delete(local_180);
                }
                local_180 = (undefined4 *)0x0;
                local_178 = (undefined4 *)0x0;
                local_170 = 0;
                operator_delete(local_198[0]);
                if (local_120 != (undefined4 *)0x0) {
                  operator_delete(local_120);
                }
                local_120 = (undefined4 *)0x0;
                local_118 = (undefined4 *)0x0;
                local_110 = 0;
                operator_delete(local_138[0]);
                if (local_150 != (undefined4 *)0x0) {
                  operator_delete(local_150);
                }
                local_150 = (undefined4 *)0x0;
                local_148 = (undefined4 *)0x0;
                local_140 = 0;
                operator_delete(local_168[0]);
                return 1;
              }
              plVar7 = DAT_140975b60;
              if (DAT_140975b60 == (longlong *)0x0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                plVar7 = (longlong *)0x0;
              }
              uVar18 = 0;
              if (puVar13 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                uVar18 = *puVar13;
              }
              if (*(undefined4 **)(uVar18 + 0x20) <= puVar17) {
                _invalid_parameter_noinfo();
              }
              lVar9 = (**(code **)(*plVar7 + 0x60))(plVar7,*puVar17);
              if (lVar9 == 0) break;
              iVar19 = FUN_1400fda10(lVar9,0x16,1);
              if (puVar13 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar18 = 0;
              }
              else {
                uVar18 = *puVar13;
              }
              uVar14 = 0;
              if (*(undefined4 **)(uVar18 + 0x20) <= puVar17) {
                _invalid_parameter_noinfo();
              }
              cVar3 = FUN_140340190(param_1,*puVar17,1,1);
              if (cVar3 == '\0') {
                if (local_180 != (undefined4 *)0x0) {
                  operator_delete(local_180);
                }
                local_180 = (undefined4 *)0x0;
                local_178 = (undefined4 *)0x0;
                local_170 = 0;
                operator_delete(local_198[0]);
                if (local_120 != (undefined4 *)0x0) {
                  operator_delete(local_120);
                }
                local_120 = (undefined4 *)0x0;
                local_118 = (undefined4 *)0x0;
                local_110 = 0;
                operator_delete(local_138[0]);
                if (local_150 != (undefined4 *)0x0) {
                  operator_delete(local_150);
                }
                local_150 = (undefined4 *)0x0;
                local_148 = (undefined4 *)0x0;
                local_140 = 0;
                operator_delete(local_168[0]);
                return 0;
              }
              if (puVar13 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                uVar14 = *puVar13;
              }
              if (*(undefined4 **)(uVar14 + 0x20) <= puVar17) {
                _invalid_parameter_noinfo();
              }
              puVar17 = puVar17 + 1;
              iVar6 = iVar6 + 1;
            }
            if (local_180 != (undefined4 *)0x0) {
              operator_delete(local_180);
            }
            local_180 = (undefined4 *)0x0;
            local_178 = (undefined4 *)0x0;
            local_170 = 0;
            operator_delete(local_198[0]);
            if (local_120 != (undefined4 *)0x0) {
              operator_delete(local_120);
            }
            local_120 = (undefined4 *)0x0;
            local_118 = (undefined4 *)0x0;
            local_110 = 0;
            operator_delete(local_138[0]);
            if (local_150 != (undefined4 *)0x0) {
              operator_delete(local_150);
            }
            local_150 = (undefined4 *)0x0;
            local_148 = (undefined4 *)0x0;
            local_140 = 0;
            operator_delete(local_168[0]);
            return 0;
          }
          puVar13 = local_138[0];
          if (local_118 < local_120) {
            _invalid_parameter_noinfo();
            puVar13 = local_138[0];
          }
          while( true ) {
            puVar11 = local_118;
            if (local_118 < local_120) {
              _invalid_parameter_noinfo();
            }
            if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_138[0])) {
              _invalid_parameter_noinfo();
            }
            puVar16 = local_180;
            if (puVar17 == puVar11) break;
            if (puVar13 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar18 = 0;
            }
            else {
              uVar18 = *puVar13;
            }
            uVar14 = 0;
            if (*(undefined4 **)(uVar18 + 0x20) <= puVar17) {
              _invalid_parameter_noinfo();
            }
            cVar3 = FUN_140340190(param_1,*puVar17,1,1);
            if (cVar3 == '\0') {
              if (local_180 != (undefined4 *)0x0) {
                operator_delete(local_180);
              }
              local_180 = (undefined4 *)0x0;
              local_178 = (undefined4 *)0x0;
              local_170 = 0;
              operator_delete(local_198[0]);
              if (local_120 != (undefined4 *)0x0) {
                operator_delete(local_120);
              }
              local_120 = (undefined4 *)0x0;
              local_118 = (undefined4 *)0x0;
              local_110 = 0;
              operator_delete(local_138[0]);
              if (local_150 != (undefined4 *)0x0) {
                operator_delete(local_150);
              }
              local_150 = (undefined4 *)0x0;
              local_148 = (undefined4 *)0x0;
              local_140 = 0;
              operator_delete(local_168[0]);
              return 0;
            }
            if (puVar13 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
            }
            else {
              uVar14 = *puVar13;
            }
            if (*(undefined4 **)(uVar14 + 0x20) <= puVar17) {
              _invalid_parameter_noinfo();
            }
            puVar17 = puVar17 + 1;
          }
          if ((uVar1 == uVar2) && (iVar4 == 0)) {
            if (local_180 != (undefined4 *)0x0) {
              operator_delete(local_180);
            }
            local_180 = (undefined4 *)0x0;
            local_178 = (undefined4 *)0x0;
            local_170 = 0;
            operator_delete(local_198[0]);
            if (local_120 != (undefined4 *)0x0) {
              operator_delete(local_120);
            }
            local_120 = (undefined4 *)0x0;
            local_118 = (undefined4 *)0x0;
            local_110 = 0;
            operator_delete(local_138[0]);
            if (local_150 != (undefined4 *)0x0) {
              operator_delete(local_150);
            }
            local_150 = (undefined4 *)0x0;
            local_148 = (undefined4 *)0x0;
            local_140 = 0;
            operator_delete(local_168[0]);
            return 1;
          }
          iVar19 = iVar19 + uVar2 * -5;
          if ((int)(local_res10 * 10) < iVar19) {
            log_InlineLogERROR(&DAT_1406d9c10);
            if (local_180 != (undefined4 *)0x0) {
              operator_delete(local_180);
            }
            local_180 = (undefined4 *)0x0;
            local_178 = (undefined4 *)0x0;
            local_170 = 0;
            operator_delete(local_198[0]);
            if (local_120 != (undefined4 *)0x0) {
              operator_delete(local_120);
            }
            local_120 = (undefined4 *)0x0;
            local_118 = (undefined4 *)0x0;
            local_110 = 0;
            operator_delete(local_138[0]);
            if (local_150 != (undefined4 *)0x0) {
              operator_delete(local_150);
            }
            local_150 = (undefined4 *)0x0;
            local_148 = (undefined4 *)0x0;
            local_140 = 0;
            operator_delete(local_168[0]);
            return 0;
          }
          iVar4 = iVar19 / 10;
          if (iVar4 < (int)local_res10) {
            if (iVar19 % 10 == 0) {
              if (local_178 < local_180) {
                _invalid_parameter_noinfo();
              }
              puVar13 = local_198[0];
              uVar14 = 0;
              uVar18 = uVar14;
              while( true ) {
                puVar11 = local_178;
                if (local_178 < local_180) {
                  _invalid_parameter_noinfo();
                }
                if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_198[0])) {
                  _invalid_parameter_noinfo();
                }
                if ((puVar16 == puVar11) || (iVar4 <= (int)uVar18)) {
                  if (local_180 != (undefined4 *)0x0) {
                    operator_delete(local_180);
                  }
                  local_180 = (undefined4 *)0x0;
                  local_178 = (undefined4 *)0x0;
                  local_170 = 0;
                  operator_delete(local_198[0]);
                  if (local_120 != (undefined4 *)0x0) {
                    operator_delete(local_120);
                  }
                  local_120 = (undefined4 *)0x0;
                  local_118 = (undefined4 *)0x0;
                  local_110 = 0;
                  operator_delete(local_138[0]);
                  if (local_150 != (undefined4 *)0x0) {
                    operator_delete(local_150);
                  }
                  local_150 = (undefined4 *)0x0;
                  local_148 = (undefined4 *)0x0;
                  local_140 = 0;
                  operator_delete(local_168[0]);
                  return 1;
                }
                if (puVar13 == (ulonglong *)0x0) {
                  _invalid_parameter_noinfo();
                  uVar10 = uVar14;
                }
                else {
                  uVar10 = *puVar13;
                }
                if (*(undefined4 **)(uVar10 + 0x20) <= puVar16) {
                  _invalid_parameter_noinfo();
                }
                cVar3 = FUN_140340190(param_1,*puVar16,1,1);
                if (cVar3 == '\0') break;
                if (puVar13 == (ulonglong *)0x0) {
                  _invalid_parameter_noinfo();
                  uVar10 = uVar14;
                }
                else {
                  uVar10 = *puVar13;
                }
                if (*(undefined4 **)(uVar10 + 0x20) <= puVar16) {
                  _invalid_parameter_noinfo();
                }
                puVar16 = puVar16 + 1;
                uVar18 = (ulonglong)((int)uVar18 + 1);
              }
              if (local_180 != (undefined4 *)0x0) {
                operator_delete(local_180);
              }
              local_180 = (undefined4 *)0x0;
              local_178 = (undefined4 *)0x0;
              local_170 = 0;
              operator_delete(local_198[0]);
              if (local_120 != (undefined4 *)0x0) {
                operator_delete(local_120);
              }
              local_120 = (undefined4 *)0x0;
              local_118 = (undefined4 *)0x0;
              local_110 = 0;
              operator_delete(local_138[0]);
              if (local_150 != (undefined4 *)0x0) {
                operator_delete(local_150);
              }
              local_150 = (undefined4 *)0x0;
              local_148 = (undefined4 *)0x0;
              local_140 = 0;
              operator_delete(local_168[0]);
              return 0;
            }
            if (local_178 < local_180) {
              _invalid_parameter_noinfo();
            }
            puVar13 = local_198[0];
            iVar12 = 0;
            iVar6 = iVar12;
            while( true ) {
              puVar11 = local_178;
              if (local_178 < local_180) {
                _invalid_parameter_noinfo();
              }
              if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_198[0])) {
                _invalid_parameter_noinfo();
              }
              if ((puVar16 == puVar11) || (iVar4 + 1 <= iVar12)) {
                FUN_140346470(param_1,10 - iVar19 % 10,iVar6,param_5);
                if (local_180 != (undefined4 *)0x0) {
                  operator_delete(local_180);
                }
                local_180 = (undefined4 *)0x0;
                local_178 = (undefined4 *)0x0;
                local_170 = 0;
                operator_delete(local_198[0]);
                if (local_120 != (undefined4 *)0x0) {
                  operator_delete(local_120);
                }
                local_120 = (undefined4 *)0x0;
                local_118 = (undefined4 *)0x0;
                local_110 = 0;
                operator_delete(local_138[0]);
                if (local_150 != (undefined4 *)0x0) {
                  operator_delete(local_150);
                }
                local_150 = (undefined4 *)0x0;
                local_148 = (undefined4 *)0x0;
                local_140 = 0;
                operator_delete(local_168[0]);
                return 1;
              }
              plVar7 = DAT_140975b60;
              if (DAT_140975b60 == (longlong *)0x0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                plVar7 = (longlong *)0x0;
              }
              uVar18 = 0;
              if (puVar13 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                uVar18 = *puVar13;
              }
              if (*(undefined4 **)(uVar18 + 0x20) <= puVar16) {
                _invalid_parameter_noinfo();
              }
              lVar9 = (**(code **)(*plVar7 + 0x60))(plVar7,*puVar16);
              if (lVar9 == 0) break;
              iVar6 = FUN_1400fda10(lVar9,0x16,1);
              if (puVar13 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar18 = 0;
              }
              else {
                uVar18 = *puVar13;
              }
              uVar14 = 0;
              if (*(undefined4 **)(uVar18 + 0x20) <= puVar16) {
                _invalid_parameter_noinfo();
              }
              cVar3 = FUN_140340190(param_1,*puVar16,1,1);
              if (cVar3 == '\0') {
                if (local_180 != (undefined4 *)0x0) {
                  operator_delete(local_180);
                }
                local_180 = (undefined4 *)0x0;
                local_178 = (undefined4 *)0x0;
                local_170 = 0;
                operator_delete(local_198[0]);
                if (local_120 != (undefined4 *)0x0) {
                  operator_delete(local_120);
                }
                local_120 = (undefined4 *)0x0;
                local_118 = (undefined4 *)0x0;
                local_110 = 0;
                operator_delete(local_138[0]);
                if (local_150 != (undefined4 *)0x0) {
                  operator_delete(local_150);
                }
                local_150 = (undefined4 *)0x0;
                local_148 = (undefined4 *)0x0;
                local_140 = 0;
                operator_delete(local_168[0]);
                return 0;
              }
              if (puVar13 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                uVar14 = *puVar13;
              }
              if (*(undefined4 **)(uVar14 + 0x20) <= puVar16) {
                _invalid_parameter_noinfo();
              }
              puVar16 = puVar16 + 1;
              iVar12 = iVar12 + 1;
            }
            if (local_180 != (undefined4 *)0x0) {
              operator_delete(local_180);
            }
            local_180 = (undefined4 *)0x0;
            local_178 = (undefined4 *)0x0;
            local_170 = 0;
            operator_delete(local_198[0]);
            if (local_120 != (undefined4 *)0x0) {
              operator_delete(local_120);
            }
            local_120 = (undefined4 *)0x0;
            local_118 = (undefined4 *)0x0;
            local_110 = 0;
            operator_delete(local_138[0]);
            if (local_150 != (undefined4 *)0x0) {
              operator_delete(local_150);
            }
            local_150 = (undefined4 *)0x0;
            local_148 = (undefined4 *)0x0;
            local_140 = 0;
            operator_delete(local_168[0]);
            return 0;
          }
          if (local_178 < local_180) {
            _invalid_parameter_noinfo();
          }
          puVar13 = local_198[0];
          uVar14 = 0;
          uVar18 = uVar14;
          while( true ) {
            puVar11 = local_178;
            if (local_178 < local_180) {
              _invalid_parameter_noinfo();
            }
            if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_198[0])) {
              _invalid_parameter_noinfo();
            }
            if ((puVar16 == puVar11) || (iVar4 <= (int)uVar18)) break;
            if (puVar13 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar10 = uVar14;
            }
            else {
              uVar10 = *puVar13;
            }
            if (*(undefined4 **)(uVar10 + 0x20) <= puVar16) {
              _invalid_parameter_noinfo();
            }
            cVar3 = FUN_140340190(param_1,*puVar16,1,1);
            if (cVar3 == '\0') {
              if (local_180 != (undefined4 *)0x0) {
                operator_delete(local_180);
              }
              local_180 = (undefined4 *)0x0;
              local_178 = (undefined4 *)0x0;
              local_170 = 0;
              operator_delete(local_198[0]);
              if (local_120 != (undefined4 *)0x0) {
                operator_delete(local_120);
              }
              local_120 = (undefined4 *)0x0;
              local_118 = (undefined4 *)0x0;
              local_110 = 0;
              operator_delete(local_138[0]);
              if (local_150 != (undefined4 *)0x0) {
                operator_delete(local_150);
              }
              local_150 = (undefined4 *)0x0;
              local_148 = (undefined4 *)0x0;
              local_140 = 0;
              operator_delete(local_168[0]);
              return 0;
            }
            if (puVar13 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar10 = uVar14;
            }
            else {
              uVar10 = *puVar13;
            }
            if (*(undefined4 **)(uVar10 + 0x20) <= puVar16) {
              _invalid_parameter_noinfo();
            }
            puVar16 = puVar16 + 1;
            uVar18 = (ulonglong)((int)uVar18 + 1);
          }
          if (local_180 != (undefined4 *)0x0) {
            operator_delete(local_180);
          }
          local_180 = (undefined4 *)0x0;
          local_178 = (undefined4 *)0x0;
          local_170 = 0;
          operator_delete(local_198[0]);
          if (local_120 != (undefined4 *)0x0) {
            operator_delete(local_120);
          }
          local_120 = (undefined4 *)0x0;
          local_118 = (undefined4 *)0x0;
          local_110 = 0;
          operator_delete(local_138[0]);
          if (local_150 != (undefined4 *)0x0) {
            operator_delete(local_150);
          }
          local_150 = (undefined4 *)0x0;
          local_148 = (undefined4 *)0x0;
          local_140 = 0;
          operator_delete(local_168[0]);
          goto LAB_140352745;
        }
        if (puVar13 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar18 = 0;
        }
        else {
          uVar18 = *puVar13;
        }
        uVar14 = 0;
        if (*(undefined4 **)(uVar18 + 0x20) <= puVar11) {
          _invalid_parameter_noinfo();
        }
        cVar3 = FUN_140340190(param_1,*puVar11,1,1);
        if (cVar3 == '\0') break;
        if (puVar13 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          uVar14 = *puVar13;
        }
        if (*(undefined4 **)(uVar14 + 0x20) <= puVar11) {
          _invalid_parameter_noinfo();
        }
        puVar11 = puVar11 + 1;
      }
      if (local_180 != (undefined4 *)0x0) {
        operator_delete(local_180);
      }
      local_180 = (undefined4 *)0x0;
      local_178 = (undefined4 *)0x0;
      local_170 = 0;
      operator_delete(local_198[0]);
      if (local_120 != (undefined4 *)0x0) {
        operator_delete(local_120);
      }
      local_120 = (undefined4 *)0x0;
      local_118 = (undefined4 *)0x0;
      local_110 = 0;
      operator_delete(local_138[0]);
      if (local_150 != (undefined4 *)0x0) {
        operator_delete(local_150);
      }
      local_150 = (undefined4 *)0x0;
      local_148 = (undefined4 *)0x0;
      local_140 = 0;
      operator_delete(local_168[0]);
      uVar8 = 0;
    }
    else {
      if (local_148 < puVar11) {
        _invalid_parameter_noinfo();
      }
      puVar13 = local_168[0];
      uVar14 = 0;
      uVar18 = uVar14;
      while( true ) {
        puVar16 = local_148;
        if (local_148 < local_150) {
          _invalid_parameter_noinfo();
        }
        if ((puVar13 == (ulonglong *)0x0) || (puVar13 != local_168[0])) {
          _invalid_parameter_noinfo();
        }
        if ((puVar11 == puVar16) || (iVar19 <= (int)uVar18)) {
          if (local_180 != (undefined4 *)0x0) {
            operator_delete(local_180);
          }
          local_180 = (undefined4 *)0x0;
          local_178 = (undefined4 *)0x0;
          local_170 = 0;
          operator_delete(local_198[0]);
          if (local_120 != (undefined4 *)0x0) {
            operator_delete(local_120);
          }
          local_120 = (undefined4 *)0x0;
          local_118 = (undefined4 *)0x0;
          local_110 = 0;
          operator_delete(local_138[0]);
          if (local_150 != (undefined4 *)0x0) {
            operator_delete(local_150);
          }
          local_150 = (undefined4 *)0x0;
          local_148 = (undefined4 *)0x0;
          local_140 = 0;
          operator_delete(local_168[0]);
          return 1;
        }
        if (puVar13 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar10 = uVar14;
        }
        else {
          uVar10 = *puVar13;
        }
        if (*(undefined4 **)(uVar10 + 0x20) <= puVar11) {
          _invalid_parameter_noinfo();
        }
        cVar3 = FUN_140340190(param_1,*puVar11,1,1);
        if (cVar3 == '\0') break;
        if (puVar13 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar10 = uVar14;
        }
        else {
          uVar10 = *puVar13;
        }
        if (*(undefined4 **)(uVar10 + 0x20) <= puVar11) {
          _invalid_parameter_noinfo();
        }
        puVar11 = puVar11 + 1;
        uVar18 = (ulonglong)((int)uVar18 + 1);
      }
      if (local_180 != (undefined4 *)0x0) {
        operator_delete(local_180);
      }
      local_180 = (undefined4 *)0x0;
      local_178 = (undefined4 *)0x0;
      local_170 = 0;
      operator_delete(local_198[0]);
      if (local_120 != (undefined4 *)0x0) {
        operator_delete(local_120);
      }
      local_120 = (undefined4 *)0x0;
      local_118 = (undefined4 *)0x0;
      local_110 = 0;
      operator_delete(local_138[0]);
      if (local_150 != (undefined4 *)0x0) {
        operator_delete(local_150);
      }
      local_150 = (undefined4 *)0x0;
      local_148 = (undefined4 *)0x0;
      local_140 = 0;
      operator_delete(local_168[0]);
      uVar8 = 0;
    }
  }
  return uVar8;
}

// ==== CMsgDataArray::helper_1403570e0  @1403570e0  [medium:callgraph-r0]  (orig: FUN_1403570e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_1403570e0(longlong *param_1,undefined4 param_2,int param_3,int param_4,int *param_5,char param_6
             )

{
  char cVar1;
  char cVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong *plVar10;
  undefined8 uVar11;
  IStringManager *pIVar12;
  ulonglong uVar13;
  char *pcVar14;
  uint uVar15;
  int iVar16;
  int *piVar17;
  double dVar18;
  undefined1 auStack_938 [32];
  ulonglong local_918;
  int local_910;
  int local_908;
  undefined4 local_900;
  undefined4 local_8f8;
  int local_8f4;
  longlong *local_8f0 [3];
  void *local_8d8;
  undefined8 local_8d0;
  undefined8 local_8c8;
  longlong *local_8c0;
  undefined8 local_8b8;
  longlong *local_8b0;
  char local_8a8;
  undefined1 local_8a7 [1071];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8b8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_938;
  if ((param_6 == '\0') && (param_3 < 1)) {
    uVar3 = 0;
  }
  else {
    plVar7 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_918 = CONCAT44(local_918._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar7 = (longlong *)0x0;
    }
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x60))(plVar7,param_2);
    uVar3 = 0;
    if (plVar7 != (longlong *)0x0) {
      cVar1 = FUN_140333220(param_1,param_2);
      if ((cVar1 == '\0') && (cVar1 = FUN_140332fe0(param_1,param_2), cVar1 == '\0')) {
        return 0;
      }
      uVar4 = FUN_1400fda10(plVar7,1,1);
      iVar5 = FUN_1400ff680(uVar4);
      if (iVar5 == 0xe) {
        uVar3 = 0;
      }
      else {
        cVar1 = FUN_14032ef10(plVar7);
        if (cVar1 == '\0') {
          cVar1 = FUN_140106d70(plVar7);
          if (cVar1 == '\0') {
            cVar1 = FUN_1400ffbe0(plVar7);
            plVar10 = (longlong *)0x0;
            iVar5 = 0;
            local_8f8 = 0;
            local_8f4 = 0;
            uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
            local_918 = CONCAT71(local_918._1_7_,1);
            cVar2 = FUN_14032c1a0(param_1,uVar4,&local_8f4,&local_8f8);
            uVar3 = 0;
            if (cVar2 != '\0') {
              plVar8 = (longlong *)FUN_140087d40();
              lVar9 = (**(code **)(*plVar8 + 0x70))(plVar8,local_8f8);
              uVar3 = 0;
              if (lVar9 != 0) {
                plVar8 = (longlong *)FUN_140087d40();
                lVar9 = (**(code **)(*plVar8 + 0x70))(plVar8,0x109a00);
                uVar3 = 0;
                if (lVar9 != 0) {
                  dVar18 = ceil(DAT_140755e58 / (double)local_8f4);
                  if ((double)param_3 <= dVar18) {
                    dVar18 = (double)param_3;
                  }
                  iVar16 = (int)dVar18;
                  uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
                  FUN_140188880(param_1,uVar4);
                  if (param_6 == '\0') {
                    if (iVar16 < 1) {
                      uVar4 = FUN_1400fda10(plVar7,1,1);
                      FUN_1400fecd0(uVar4);
                      log_InlineLogERROR("CUser::UpEquipmentQuality, Type[%u] nReqItemNum[%d] <= 0")
                      ;
                      return 0;
                    }
                    if (param_5 == (int *)0x0) {
                      return 0;
                    }
                    local_8c0 = operator_new(8);
                    local_8f0[0] = plVar10;
                    if (local_8c0 != (longlong *)0x0) {
                      *local_8c0 = (longlong)local_8f0;
                      local_8f0[0] = local_8c0;
                    }
                    local_8d8 = (void *)0x0;
                    local_8d0 = 0;
                    local_8c8 = 0;
                    piVar17 = param_5;
                    local_8b0 = local_8c0;
                    if (0 < param_4) {
                      do {
                        if (*piVar17 != 0) {
                          cVar2 = FUN_140332fe0(param_1);
                          if (cVar2 == '\0') {
                            if (local_8d8 != (void *)0x0) {
                              operator_delete(local_8d8);
                            }
                            local_8d8 = (void *)0x0;
                            local_8d0 = 0;
                            local_8c8 = 0;
                            operator_delete(local_8f0[0]);
                            return 0;
                          }
                          FUN_140037fe0(local_8f0,param_5 + (int)plVar10);
                        }
                        uVar15 = (int)plVar10 + 1;
                        plVar10 = (longlong *)(ulonglong)uVar15;
                        piVar17 = piVar17 + 1;
                      } while ((int)uVar15 < param_4);
                    }
                    local_918 = local_918 & 0xffffffffffffff00;
                    cVar2 = FUN_140333c80(param_1,local_8f0,iVar16,cVar1 != '\0');
                    if (cVar2 == '\0') {
                      if (local_8d8 != (void *)0x0) {
                        operator_delete(local_8d8);
                      }
                      local_8d8 = (void *)0x0;
                      local_8d0 = 0;
                      local_8c8 = 0;
                      operator_delete(local_8f0[0]);
                      return 0;
                    }
                    local_918 = local_918 & 0xffffffffffffff00;
                    cVar1 = FUN_1403507b0(param_1,local_8f0,iVar16,cVar1 != '\0');
                    if (cVar1 == '\0') {
                      if (local_8d8 != (void *)0x0) {
                        operator_delete(local_8d8);
                      }
                      local_8d8 = (void *)0x0;
                      local_8d0 = 0;
                      local_8c8 = 0;
                      operator_delete(local_8f0[0]);
                      return 0;
                    }
                    lVar9 = param_1[0x1e2];
                    plVar10 = param_1 + 2;
                    (**(code **)(*plVar10 + 0x18))(plVar10);
                    (**(code **)(*param_1 + 8))(param_1);
                    local_918 = CONCAT44(local_918._4_4_,(int)lVar9);
                    local_910 = iVar16;
                    tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t999\t1902\t0\t0\t%d\t");
                    iVar5 = tq::RandGet(10000);
                    if (iVar16 * local_8f4 + -1 < iVar5) {
                      FUN_1400f83e0(&local_8a8);
                      uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
                      local_918 = local_918 & 0xffffffff00000000;
                      iVar5 = FUN_1400f8490(&local_8a8,uVar4,0x13,0);
                      if (iVar5 != 0) {
                        (**(code **)(*plVar10 + 0x350))(plVar10,&local_8a8);
                      }
                      uVar4 = FUN_1400fda10(plVar7,1,1);
                      uVar4 = FUN_1400fecd0(uVar4);
                      (**(code **)(*plVar7 + 8))(plVar7);
                      (**(code **)(*param_1 + 8))(param_1);
                      local_908 = 0x109a00;
                      local_918 = CONCAT44(local_918._4_4_,uVar4);
                      local_910 = iVar16;
                      tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                                    "User[%u] up quality Item[%u][%u] fail at cost %d Treasure[%u]")
                      ;
                      iVar5 = FUN_1400fda10(plVar7,5,1);
                      iVar16 = tq::RandGet(100);
                      if ((iVar16 < 5) && (1 < iVar5 / 100)) {
                        iVar5 = iVar5 + -100;
                        FUN_140104140(plVar7,5,iVar5,0);
                      }
                      iVar16 = FUN_1400fda10(plVar7,0x7a,1);
                      iVar5 = iVar5 - iVar16 / 2;
                      if (iVar5 < 100) {
                        iVar5 = 100;
                      }
                      FUN_140104140(plVar7,4,iVar5);
                      FUN_140104080(plVar7,1);
                      plVar10 = (longlong *)FUN_140087d40();
                      local_910 = 0;
                      local_918 = local_918 & 0xffffffff00000000;
                      (**(code **)(*plVar10 + 0x130))(plVar10,param_1,plVar7,3);
                      FUN_140170e90(param_1,0x28b8);
                      uVar11 = FUN_140008520((int)param_1[0x246]);
                      uVar11 = FUN_140087c40(uVar11);
                      FUN_140261810(uVar11,param_1,0xd);
                      FUN_1400f8430(&local_8a8);
                      if (local_8d8 != (void *)0x0) {
                        operator_delete(local_8d8);
                      }
                      local_8d8 = (void *)0x0;
                      local_8d0 = 0;
                      local_8c8 = 0;
                      operator_delete(local_8f0[0]);
                      return 1;
                    }
                    FUN_140170e90(param_1,0x28b7);
                    if (local_8d8 != (void *)0x0) {
                      operator_delete(local_8d8);
                    }
                    local_8d8 = (void *)0x0;
                    local_8d0 = 0;
                    local_8c8 = 0;
                    operator_delete(local_8f0[0]);
                    iVar5 = iVar16;
                  }
                  uVar6 = FUN_1400fda10(plVar7,1,1);
                  uVar4 = local_8f8;
                  cVar1 = FUN_140106b20(plVar7,local_8f8);
                  if (cVar1 == '\0') {
                    local_918 = CONCAT44(local_918._4_4_,0x177d);
                    log_InlineLogERROR(&DAT_1406d9c10);
                    uVar3 = 0;
                  }
                  else {
                    (**(code **)(*plVar7 + 8))(plVar7);
                    (**(code **)(*param_1 + 8))(param_1);
                    local_900 = 0x109a00;
                    local_910 = uVar4;
                    local_918 = CONCAT44(local_918._4_4_,uVar6);
                    local_908 = iVar5;
                    tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                                  "User[%u] up quality Item[%u] from [%u] to [%u] at cost %d Treasure[%u]"
                                 );
                    iVar5 = FUN_1400fda10(plVar7,0x7a,1);
                    iVar16 = tq::RandGet(100);
                    if (iVar16 < 2) {
                      iVar16 = tq::RandGet(3);
                      iVar5 = iVar5 + 100 + iVar16 * 100;
                    }
                    iVar16 = FUN_1400ff520(plVar7,0);
                    iVar5 = ((iVar16 + 100) * iVar5) / 100;
                    FUN_140104140(plVar7,5,iVar5);
                    FUN_140104140(plVar7,4,iVar5);
                    iVar5 = tq::RandGet(300);
                    if ((iVar5 == 0) && (param_6 == '\0')) {
                      uVar4 = FUN_1400fda10(plVar7,1,1);
                      iVar5 = FUN_1400ff680(uVar4);
                      if (iVar5 != 0xc) {
                        uVar4 = FUN_1400fda10(plVar7,1,1);
                        iVar5 = FUN_1400ff680(uVar4);
                        if (iVar5 != 0xd) {
                          uVar4 = FUN_1400fda10(plVar7,1,1);
                          iVar5 = FUN_1400ff680(uVar4);
                          if ((iVar5 != 0x15) && (iVar5 = FUN_1400ff9e0(plVar7), iVar5 != 0x26b)) {
                            uVar4 = FUN_1400fda10(plVar7,1,1);
                            iVar5 = FUN_1400ff680(uVar4);
                            if (iVar5 != 0x16) {
                              iVar5 = FUN_1400fda10(plVar7,8,1);
                              if (iVar5 == 0) {
                                FUN_140104140(plVar7,8,0xff,0);
                                local_8a8 = param_6;
                                memset(local_8a7,0,0x3ff);
                                pIVar12 = theInstance();
                                uVar13 = FUN_140100430(plVar7,0x65);
                                (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                                pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar12)
                                                            (pIVar12,"STR_UPLEV_HOLE1");
                                local_918 = uVar13;
                                _snprintf(&local_8a8,0x3ff,pcVar14);
                                FUN_140173900(param_1,&local_8a8);
                                (**(code **)(*plVar7 + 8))(plVar7);
                                tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                                              "Item[%u] got No.1 GemHole.");
                                FUN_140170e90(param_1,0x28b9);
                              }
                              else {
                                iVar5 = FUN_1400fda10(plVar7,9,1);
                                if (iVar5 == 0) {
                                  FUN_140104140(plVar7,9,0xff,0);
                                  local_8a8 = '\0';
                                  memset(local_8a7,0,0x3ff);
                                  pIVar12 = theInstance();
                                  uVar13 = FUN_140100430(plVar7,0x65);
                                  (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                                  pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar12)
                                                              (pIVar12,"STR_UPLEV_HOLE2");
                                  local_918 = uVar13;
                                  _snprintf(&local_8a8,0x3ff,pcVar14);
                                  FUN_140173900(param_1,&local_8a8);
                                  (**(code **)(*plVar7 + 8))(plVar7);
                                  tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                                                "Item[%u] got No.2 GemHole.");
                                  FUN_140170e90(param_1,0x28ba);
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    FUN_140104080(plVar7,1);
                    FUN_1400f83e0(local_478);
                    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
                    local_918 = local_918 & 0xffffffff00000000;
                    iVar5 = FUN_1400f8490(local_478,uVar4,0x13);
                    if (iVar5 != 0) {
                      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
                    }
                    FUN_14032d7e0(param_1,plVar7);
                    FUN_140194390(param_1);
                    uVar11 = FUN_140008520((int)param_1[0x246]);
                    uVar11 = FUN_140087c40(uVar11);
                    FUN_140261810(uVar11,param_1,0xd);
                    FUN_1400f8430(local_478);
                    uVar3 = 1;
                  }
                }
              }
            }
          }
          else {
            uVar3 = 0;
          }
        }
        else {
          uVar3 = 0;
        }
      }
    }
  }
  return uVar3;
}

// ==== CMsgDataArray::helper_140357b20  @140357b20  [medium:callgraph-r0]  (orig: FUN_140357b20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_140357b20(longlong *param_1,undefined4 param_2,int param_3,int param_4,int *param_5,char param_6
             )

{
  char cVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  longlong *plVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong lVar10;
  IStringManager *pIVar11;
  ulonglong uVar12;
  char *pcVar13;
  int *piVar14;
  bool bVar15;
  double dVar16;
  undefined1 auStack_948 [32];
  undefined4 *local_928;
  int local_920;
  int local_918;
  int local_910;
  int local_908;
  int local_904;
  undefined4 local_900 [2];
  longlong *local_8f8 [3];
  void *local_8e0;
  undefined8 local_8d8;
  undefined8 local_8d0;
  longlong *local_8c8;
  undefined8 local_8c0;
  longlong *local_8b8;
  char local_8a8;
  undefined1 local_8a7 [1071];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8c0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_948;
  if ((param_6 == '\0') && (param_3 < 1)) {
    return 0;
  }
  cVar1 = FUN_140333220();
  if ((cVar1 == '\0') && (cVar2 = FUN_140332fe0(param_1,param_2), cVar2 == '\0')) {
    return 0;
  }
  plVar7 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    local_928 = (undefined4 *)CONCAT44(local_928._4_4_,0x3c0);
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar7 = (longlong *)0x0;
  }
  plVar7 = (longlong *)(**(code **)(*plVar7 + 0x60))(plVar7,param_2);
  if (plVar7 == (longlong *)0x0) {
    return 0;
  }
  uVar3 = FUN_1400fda10(plVar7,1,1);
  iVar4 = FUN_1400ff680(uVar3);
  if (iVar4 == 0xe) {
    return 0;
  }
  cVar2 = FUN_14032ef10(plVar7);
  if (cVar2 != '\0') {
    return 0;
  }
  uVar8 = FUN_140008520((int)param_1[0x246]);
  cVar2 = FUN_14008abf0(uVar8);
  if ((cVar2 != '\0') && (cVar2 = FUN_140103310(plVar7), cVar2 != '\0')) {
    return 0;
  }
  uVar3 = FUN_1400fda10(plVar7,1,1);
  iVar4 = FUN_1400ff680(uVar3);
  if (iVar4 == 0xc) {
    return 0;
  }
  uVar3 = FUN_1400fda10(plVar7,1,1);
  iVar4 = FUN_1400ff680(uVar3);
  if (iVar4 == 0xd) {
    return 0;
  }
  uVar3 = FUN_1400fda10(plVar7,1,1);
  iVar4 = FUN_1400ff680(uVar3);
  if (iVar4 == 0x15) {
    return 0;
  }
  uVar3 = FUN_1400fda10(plVar7,1,1);
  iVar4 = FUN_1400ff680(uVar3);
  if (iVar4 == 0x16) {
    return 0;
  }
  cVar2 = FUN_140106d70(plVar7);
  if (cVar2 != '\0') {
    return 0;
  }
  cVar2 = FUN_1400ffbe0(plVar7);
  bVar15 = cVar2 != '\0';
  local_900[0] = 0;
  local_908 = 0;
  local_904 = 0;
  uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
  local_920 = CONCAT31(local_920._1_3_,1);
  local_928 = local_900;
  cVar2 = FUN_140330010(param_1,uVar3,&local_908,&local_904);
  if (cVar2 == '\0') {
    return 0;
  }
  plVar9 = (longlong *)FUN_140087d40();
  uVar3 = local_900[0];
  lVar10 = (**(code **)(*plVar9 + 0x70))(plVar9,local_900[0]);
  if (lVar10 == 0) {
    return 0;
  }
  if (cVar1 != '\0') {
    plVar9 = (longlong *)
             (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))(*(longlong **)(lVar10 + 8),4);
    iVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
    iVar5 = (**(code **)(param_1[2] + 0x70))();
    if (iVar5 < iVar4) {
      pIVar11 = theInstance();
      lVar10 = *param_1;
      uVar8 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_NEXTEQP_OVERLEV");
      (**(code **)(lVar10 + 0x150))(param_1,2000,uVar8);
      return 0;
    }
  }
  plVar9 = (longlong *)FUN_140087d40();
  lVar10 = (**(code **)(*plVar9 + 0x70))(plVar9,local_908);
  if (lVar10 == 0) {
    return 0;
  }
  dVar16 = ceil(DAT_140755e58 / (double)local_904);
  if ((double)param_3 <= dVar16) {
    dVar16 = (double)param_3;
  }
  iVar4 = (int)dVar16;
  if (param_6 != '\0') {
    iVar4 = 0;
    goto LAB_140358323;
  }
  if (iVar4 < 1) {
    uVar3 = FUN_1400fda10(plVar7,1,1);
    FUN_1400fecd0(uVar3);
    log_InlineLogERROR("CUser::UpEquipmentLevel, Type[%u] nReqItemNum[%d] <= 0");
    return 0;
  }
  if ((local_908 != 0x109a01) && (local_908 != 0x109a00)) {
    log_InlineLogERROR("CUser::UpEquipmentLevel, ReqType[%u] Error");
    return 0;
  }
  if (param_5 == (int *)0x0) {
    return 0;
  }
  local_8c8 = operator_new(8);
  if (local_8c8 == (longlong *)0x0) {
    local_8f8[0] = (longlong *)0x0;
  }
  else {
    *local_8c8 = (longlong)local_8f8;
    local_8f8[0] = local_8c8;
  }
  iVar5 = 0;
  local_8e0 = (void *)0x0;
  local_8d8 = 0;
  local_8d0 = 0;
  piVar14 = param_5;
  local_8b8 = local_8c8;
  if (0 < param_4) {
    do {
      if (*piVar14 != 0) {
        cVar1 = FUN_140332fe0(param_1);
        if (cVar1 == '\0') {
          if (local_8e0 != (void *)0x0) {
            operator_delete(local_8e0);
          }
          local_8e0 = (void *)0x0;
          local_8d8 = 0;
          local_8d0 = 0;
          operator_delete(local_8f8[0]);
          return 0;
        }
        FUN_140037fe0(local_8f8,param_5 + iVar5);
      }
      iVar5 = iVar5 + 1;
      piVar14 = piVar14 + 1;
    } while (iVar5 < param_4);
  }
  if (local_908 == 0x109a01) {
    local_928._0_1_ = 1;
    cVar1 = FUN_140333c80(param_1,local_8f8,iVar4,bVar15);
    if (cVar1 == '\0') {
      if (local_8e0 != (void *)0x0) {
        operator_delete(local_8e0);
      }
      local_8e0 = (void *)0x0;
      local_8d8 = 0;
      local_8d0 = 0;
      operator_delete(local_8f8[0]);
      return 0;
    }
    local_928 = (undefined4 *)CONCAT71(local_928._1_7_,1);
    cVar1 = FUN_1403507b0(param_1,local_8f8,iVar4,bVar15);
    if (cVar1 == '\0') {
      if (local_8e0 != (void *)0x0) {
        operator_delete(local_8e0);
      }
      local_8e0 = (void *)0x0;
      local_8d8 = 0;
      local_8d0 = 0;
      operator_delete(local_8f8[0]);
      return 0;
    }
LAB_140358075:
    if (local_908 != 0x109a00) goto LAB_140358091;
    FUN_140170e90(param_1,0x28b6);
  }
  else {
    if (local_908 == 0x109a00) {
      local_928 = (undefined4 *)((ulonglong)local_928._1_7_ << 8);
      cVar1 = FUN_140333c80(param_1,local_8f8,iVar4,bVar15);
      if (cVar1 == '\0') {
        if (local_8e0 != (void *)0x0) {
          operator_delete(local_8e0);
        }
        local_8e0 = (void *)0x0;
        local_8d8 = 0;
        local_8d0 = 0;
        operator_delete(local_8f8[0]);
        return 0;
      }
      local_928 = (undefined4 *)((ulonglong)local_928 & 0xffffffffffffff00);
      cVar1 = FUN_1403507b0(param_1,local_8f8,iVar4,bVar15);
      if (cVar1 == '\0') {
        if (local_8e0 != (void *)0x0) {
          operator_delete(local_8e0);
        }
        local_8e0 = (void *)0x0;
        local_8d8 = 0;
        local_8d0 = 0;
        operator_delete(local_8f8[0]);
        return 0;
      }
      goto LAB_140358075;
    }
LAB_140358091:
    iVar5 = tq::RandGet(10000);
    if (iVar4 * local_904 + -1 < iVar5) {
      FUN_1400f83e0(&local_8a8);
      uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
      local_928 = (undefined4 *)((ulonglong)local_928 & 0xffffffff00000000);
      iVar5 = FUN_1400f8490(&local_8a8,uVar3,0x14);
      if (iVar5 != 0) {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,&local_8a8);
      }
      uVar3 = FUN_1400fda10(plVar7,1,1);
      uVar3 = FUN_1400fecd0(uVar3);
      (**(code **)(*plVar7 + 8))(plVar7);
      (**(code **)(*param_1 + 8))(param_1);
      local_918 = local_908;
      local_928 = (undefined4 *)CONCAT44(local_928._4_4_,uVar3);
      local_920 = iVar4;
      tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                    "User[%u] up lev Item[%u][%u] fail at cost %d Treasure[%u]");
      iVar4 = FUN_1400fda10(plVar7,5,1);
      iVar5 = tq::RandGet(100);
      if ((iVar5 < 5) && (1 < iVar4 / 100)) {
        iVar4 = iVar4 + -100;
        FUN_140104140(plVar7,5,iVar4,0);
      }
      iVar5 = FUN_1400fda10(plVar7,0x7a,1);
      iVar4 = iVar4 - iVar5 / 2;
      if (iVar4 < 100) {
        iVar4 = 100;
      }
      FUN_140104140(plVar7,4,iVar4);
      FUN_140104080(plVar7,1);
      plVar9 = (longlong *)FUN_140087d40();
      local_920 = 0;
      local_928 = (undefined4 *)((ulonglong)local_928 & 0xffffffff00000000);
      (**(code **)(*plVar9 + 0x130))(plVar9,param_1,plVar7,3);
      FUN_140170e90(param_1,0x28b5);
      uVar8 = FUN_140008520((int)param_1[0x246]);
      uVar8 = FUN_140087c40(uVar8);
      FUN_140261810(uVar8,param_1,0xd);
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      uVar8 = FUN_140008520((int)param_1[0x246]);
      uVar8 = FUN_140118060(uVar8);
      local_928 = (undefined4 *)((ulonglong)local_928 & 0xffffffff00000000);
      FUN_140269300(uVar8,uVar3,0x2d,0);
      FUN_1400f8430(&local_8a8);
      if (local_8e0 != (void *)0x0) {
        operator_delete(local_8e0);
      }
      local_8e0 = (void *)0x0;
      local_8d8 = 0;
      local_8d0 = 0;
      operator_delete(local_8f8[0]);
      return 1;
    }
    FUN_140170e90(param_1,0x28b4);
    uVar3 = (**(code **)(*param_1 + 8))(param_1);
    uVar8 = FUN_140008520((int)param_1[0x246]);
    uVar8 = FUN_140118060(uVar8);
    local_928 = (undefined4 *)((ulonglong)local_928 & 0xffffffff00000000);
    FUN_140269300(uVar8,uVar3,0x2d);
  }
  if (local_8e0 != (void *)0x0) {
    operator_delete(local_8e0);
  }
  local_8e0 = (void *)0x0;
  local_8d8 = 0;
  local_8d0 = 0;
  operator_delete(local_8f8[0]);
  uVar3 = local_900[0];
LAB_140358323:
  uVar6 = FUN_1400fda10(plVar7,1,1);
  cVar1 = FUN_140106b20(plVar7,uVar3);
  if (cVar1 != '\0') {
    (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(*param_1 + 8))(param_1);
    local_910 = local_908;
    local_928 = (undefined4 *)CONCAT44(local_928._4_4_,uVar6);
    local_920 = uVar3;
    local_918 = iVar4;
    tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,
                  "User[%u] up lev Item[%u] from [%u] to [%u] at cost %d Treasure[%u]");
    iVar4 = FUN_1400fda10(plVar7,0x7a,1);
    iVar5 = tq::RandGet(100);
    if (iVar5 < 2) {
      iVar5 = tq::RandGet(3);
      iVar4 = iVar4 + 100 + iVar5 * 100;
    }
    iVar5 = FUN_1400ff520(plVar7,0);
    iVar4 = ((iVar5 + 100) * iVar4) / 100;
    FUN_140104140(plVar7,5,iVar4);
    FUN_140104140(plVar7,4,iVar4);
    if ((param_6 == '\0') && (iVar4 = FUN_1400ff9e0(plVar7), iVar4 != 0x26b)) {
      iVar4 = FUN_1400fda10(plVar7,8,1);
      if (iVar4 == 0) {
        iVar4 = tq::RandGet(0x4b0);
        if (iVar4 == 0) {
          FUN_140104140(plVar7,8,0xff,0);
          FUN_140194390(param_1);
          local_8a8 = '\0';
          memset(local_8a7,0,0x3ff);
          pIVar11 = theInstance();
          uVar12 = FUN_140100430(plVar7,0x65);
          (**(code **)(param_1[2] + 0x18))(param_1 + 2);
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_UPLEV_HOLE1");
          local_928 = (undefined4 *)uVar12;
          _snprintf(&local_8a8,0x3ff,pcVar13);
          FUN_140173900(param_1,&local_8a8);
          (**(code **)(*plVar7 + 8))(plVar7);
          tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,"Item[%u] got No.1 GemHole.");
          FUN_140170e90(param_1,0x28b9);
        }
      }
      else {
        iVar4 = FUN_1400fda10(plVar7,9,1);
        if ((iVar4 == 0) && (iVar4 = tq::RandGet(0x960), iVar4 == 0)) {
          FUN_140104140(plVar7,9,0xff,0);
          FUN_140194390(param_1);
          local_8a8 = '\0';
          memset(local_8a7,0,0x3ff);
          pIVar11 = theInstance();
          uVar12 = FUN_140100430(plVar7,0x65);
          (**(code **)(param_1[2] + 0x18))(param_1 + 2);
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_UPLEV_HOLE2");
          local_928 = (undefined4 *)uVar12;
          _snprintf(&local_8a8,0x3ff,pcVar13);
          FUN_140173900(param_1,&local_8a8);
          (**(code **)(*plVar7 + 8))(plVar7);
          tq::MyLogSave(PTR_s_gmlog_ItemUp_log_140953c28,"Item[%u] got No.2 GemHole.");
          FUN_140170e90(param_1,0x28ba);
        }
      }
    }
    FUN_140104080(plVar7,1);
    FUN_1400f83e0(local_478);
    uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
    local_928 = (undefined4 *)((ulonglong)local_928 & 0xffffffff00000000);
    iVar4 = FUN_1400f8490(local_478,uVar3,0x14);
    if (iVar4 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
    }
    FUN_14032d7e0(param_1,plVar7);
    uVar8 = FUN_140008520((int)param_1[0x246]);
    uVar8 = FUN_140087c40(uVar8);
    FUN_140261810(uVar8,param_1,0xd);
    FUN_1400f8430(local_478);
    return 1;
  }
  local_928 = (undefined4 *)CONCAT44(local_928._4_4_,0x189f);
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMsgDataArray::ctor_or_dtor  @140453a60  [high:vtable-assign]  (orig: FUN_140453a60)
undefined8 * FUN_140453a60(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgDataArray::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgDataArray::ctor_or_dtor  @140453ab0  [high:vtable-assign]  (orig: FUN_140453ab0)
void FUN_140453ab0(undefined8 *param_1)

{
  *param_1 = CMsgDataArray::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgDataArray::vfunc_1  @140453ef0  [high:rtti-vtable]  (orig: FUN_140453ef0)
ulonglong FUN_140453ef0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x7f4);
}

// ==== CMsgDataArray::helper_140453f20  @140453f20  [medium:callgraph-r0]  (orig: FUN_140453f20)
longlong FUN_140453f20(char *param_1,char *param_2,int param_3,char *param_4,int param_5)

{
  char cVar1;
  bool bVar2;
  char *pcVar3;
  char *pcVar4;
  longlong lVar5;
  char *pcVar6;
  int iVar7;
  int iVar8;
  char *pcVar9;
  longlong lVar10;
  
  bVar2 = false;
  lVar10 = (longlong)param_3;
  if (((param_3 < 1) || (param_5 < 1)) || (param_1 == (char *)0x0)) {
    return 0;
  }
  cVar1 = *param_1;
  iVar7 = 0;
  pcVar9 = param_1;
  pcVar3 = param_1;
  do {
    pcVar6 = pcVar3;
    if (cVar1 == '\0') {
LAB_140454087:
      return (longlong)pcVar6 - (longlong)param_1;
    }
    if (bVar2) {
      if (cVar1 == *param_4) {
        lVar5 = 1;
        iVar8 = 1;
        if (1 < (longlong)param_5) {
          pcVar4 = param_4;
          do {
            pcVar4 = pcVar4 + 1;
            if (pcVar4[(longlong)pcVar9 - (longlong)param_4] != *pcVar4) break;
            lVar5 = lVar5 + 1;
            iVar8 = iVar8 + 1;
          } while (lVar5 < param_5);
        }
        if (iVar8 == param_5) {
          bVar2 = false;
          pcVar6 = pcVar3 + 1;
          *pcVar3 = *pcVar9;
        }
      }
    }
    else if (cVar1 == *param_2) {
      lVar5 = 1;
      iVar8 = 1;
      if (1 < lVar10) {
        pcVar4 = param_2;
        do {
          pcVar4 = pcVar4 + 1;
          if (pcVar4[(longlong)pcVar9 - (longlong)param_2] != *pcVar4) break;
          lVar5 = lVar5 + 1;
          iVar8 = iVar8 + 1;
        } while (lVar5 < lVar10);
      }
      if (iVar8 == param_3) {
        bVar2 = true;
        pcVar9 = pcVar9 + lVar10;
      }
      else {
        *pcVar3 = *pcVar9;
        pcVar6 = pcVar3 + 1;
      }
    }
    else {
      *pcVar3 = *pcVar9;
      pcVar6 = pcVar3 + 1;
    }
    iVar7 = iVar7 + 1;
    pcVar9 = pcVar9 + 1;
    if (0xff < iVar7) {
      log_InlineLogERROR(&DAT_1406d9c10);
      goto LAB_140454087;
    }
    cVar1 = *pcVar9;
    pcVar3 = pcVar6;
  } while( true );
}

// ==== CMsgDataArray::ctor_or_dtor  @1404540c0  [high:vtable-assign]  (orig: FUN_1404540c0)
undefined8 * FUN_1404540c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgDataArray::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgDataArray::vfunc_3  @140454110  [high:rtti-vtable]  (orig: FUN_140454110)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140454110(longlong param_1)

{
  longlong *plVar1;
  byte bVar2;
  undefined1 *puVar3;
  char cVar4;
  longlong lVar5;
  IStringManager *pIVar6;
  undefined8 uVar7;
  char *pcVar8;
  ulonglong uVar9;
  byte *pbVar10;
  ulonglong uVar11;
  undefined1 auStack_278 [32];
  undefined1 *local_258;
  undefined1 local_250;
  int local_248;
  longlong local_240;
  undefined8 local_238;
  byte local_228 [255];
  undefined1 local_129;
  byte local_128 [90];
  undefined1 local_ce [166];
  ulonglong local_28;
  
  local_238 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_278;
  local_240 = param_1;
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    local_258 = (undefined1 *)CONCAT44(local_258._4_4_,0x130);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1);
  if (lVar5 != 0) {
    plVar1 = (longlong *)(lVar5 + 0x10);
    cVar4 = (**(code **)(*plVar1 + 0x220))(plVar1);
    if (cVar4 == '\0') {
      pIVar6 = theInstance();
      lVar5 = *plVar1;
      uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_DIE");
      (**(code **)(lVar5 + 0x358))(plVar1,uVar7);
    }
    else {
      puVar3 = *(undefined1 **)(param_1 + 0x428);
      switch(*puVar3) {
      case 0:
        bVar2 = puVar3[1];
        if ((1 < bVar2) && ((bVar2 == 0 || ((longlong)(int)(bVar2 - 1) * 4 + 8U < 0x3fd)))) {
          FUN_140346500(lVar5,*(undefined4 *)(puVar3 + 4),puVar3 + 8,(byte)puVar3[1] - 1);
        }
        break;
      case 1:
        memcpy(local_128,
               "ZM Canot run in Dos ~820 d3C:\\windows\\system32 D~00Adminstrator\\Documents and Settings8r2"
               ,0x5a);
        memset(local_ce,0,0xa5);
        uVar9 = 0xffffffffffffffff;
        pbVar10 = local_128;
        do {
          if (uVar9 == 0) break;
          uVar9 = uVar9 - 1;
          bVar2 = *pbVar10;
          pbVar10 = pbVar10 + 1;
        } while (bVar2 != 0);
        bVar2 = puVar3[1];
        local_228[0] = 0;
        memset(local_228 + 1,0,0xff);
        if ((puVar3[1] == 0) || ((longlong)(int)((byte)puVar3[1] - 1) + 8U < 0x3fd)) {
          for (local_248 = 0; local_248 < (int)(uint)bVar2; local_248 = local_248 + 1) {
            uVar11 = (ulonglong)local_248;
            local_228[uVar11] = local_128[uVar11 % (~uVar9 - 1)] ^ puVar3[uVar11 + 4];
          }
          local_129 = 0;
          tq::MyLogSave("log/crack_url","%s");
          pcVar8 = strstr((char *)local_228,"&pass=");
          if (pcVar8 == (char *)0x0) {
            pcVar8 = strstr((char *)local_228,"&p=");
            if (pcVar8 == (char *)0x0) {
              pcVar8 = strstr((char *)local_228,"rnd=");
              if (pcVar8 == (char *)0x0) {
                tq::MyLogSave("crimelog/crack_url","unknow format.");
              }
              else {
                pcVar8[4] = '\0';
                tq::MyLogSave("crimelog/crack_url","%s");
              }
            }
            else {
              local_258 = (undefined1 *)CONCAT44(local_258._4_4_,3);
              uVar11 = FUN_140453f20(local_228,&DAT_14077e90c,3,&DAT_14077e908);
              uVar9 = 0xff;
              if (uVar11 < 0xff) {
                uVar9 = uVar11;
              }
              local_228[uVar9] = 0;
              tq::MyLogSave("crimelog/crack_url","%s");
            }
          }
          else {
            local_258 = (undefined1 *)CONCAT44(local_258._4_4_,6);
            uVar11 = FUN_140453f20(local_228,"&pass=",6,"&role=");
            uVar9 = 0xff;
            if (uVar11 < 0xff) {
              uVar9 = uVar11;
            }
            local_228[uVar9] = 0;
            tq::MyLogSave("crimelog/crack_url","%s");
          }
        }
        break;
      case 2:
        bVar2 = puVar3[1];
        if ((1 < bVar2) && ((bVar2 == 0 || ((longlong)(int)(bVar2 - 1) * 4 + 8U < 0x3fd)))) {
          FUN_140347270(lVar5,*(undefined4 *)(puVar3 + 4),puVar3 + 8,(byte)puVar3[1] - 1);
        }
        break;
      case 3:
        bVar2 = puVar3[1];
        if ((1 < bVar2) && ((bVar2 == 0 || ((longlong)(int)(bVar2 - 1) * 4 + 8U < 0x3fd)))) {
          FUN_140347c70(lVar5,*(undefined4 *)(puVar3 + 4),puVar3 + 8,(byte)puVar3[1] - 1);
        }
        break;
      case 4:
        bVar2 = puVar3[1];
        if ((bVar2 != 0) && ((bVar2 == 0 || ((longlong)(int)(bVar2 - 1) * 4 + 8U < 0x3fd)))) {
          FUN_140333fa0(lVar5,*(undefined4 *)(puVar3 + 4));
        }
        break;
      case 5:
        bVar2 = puVar3[1];
        if ((bVar2 != 0) && ((bVar2 == 0 || ((longlong)(int)(bVar2 - 1) * 4 + 8U < 0x3fd)))) {
          FUN_140334540(lVar5,*(undefined4 *)(puVar3 + 4));
        }
        break;
      case 6:
        bVar2 = puVar3[1];
        if ((2 < bVar2) && ((bVar2 == 0 || ((longlong)(int)(bVar2 - 2) * 4 + 8U < 0x3fd)))) {
          local_258 = puVar3 + 0xc;
          local_250 = 0;
          FUN_140357b20(lVar5,*(undefined4 *)(puVar3 + 4),*(undefined4 *)(puVar3 + 8),
                        (byte)puVar3[1] - 2);
        }
        break;
      case 7:
        bVar2 = puVar3[1];
        if ((2 < bVar2) && ((bVar2 == 0 || ((longlong)(int)(bVar2 - 2) * 4 + 8U < 0x3fd)))) {
          local_258 = puVar3 + 0xc;
          local_250 = 0;
          FUN_1403570e0(lVar5,*(undefined4 *)(puVar3 + 4),*(undefined4 *)(puVar3 + 8),
                        (byte)puVar3[1] - 2);
        }
      }
    }
  }
  return;
}

