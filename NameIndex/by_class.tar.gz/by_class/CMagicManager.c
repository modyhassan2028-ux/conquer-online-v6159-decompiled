// ==== CMagicManager::helper_1400e40b0  @1400e40b0  [medium:callgraph-r2]  (orig: FUN_1400e40b0)
void FUN_1400e40b0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMagicManager::helper_1400e4110  @1400e4110  [medium:callgraph-r2]  (orig: FUN_1400e4110)
void FUN_1400e4110(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMagicManager::helper_1400e42b0  @1400e42b0  [medium:callgraph-r2]  (orig: FUN_1400e42b0)
void FUN_1400e42b0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400e42d4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMagicManager::helper_1400e56d0  @1400e56d0  [medium:callgraph-r1]  (orig: FUN_1400e56d0)
void FUN_1400e56d0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1400e4cc0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMagicManager::helper_1400e5c40  @1400e5c40  [medium:callgraph-r1]  (orig: FUN_1400e5c40)
undefined8 * FUN_1400e5c40(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1400e42b0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1400e5e2c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1400e5e2c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1400e40b0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1400e4110(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1400e40b0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1400e4110(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1400e40b0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1400e4110(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMagicManager::helper_1400e71c0  @1400e71c0  [medium:callgraph-r0]  (orig: FUN_1400e71c0)
longlong * FUN_1400e71c0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1400e56d0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1400e5c40(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMagicManager::helper_1402ec680  @1402ec680  [medium:callgraph-r2]  (orig: FUN_1402ec680)
void FUN_1402ec680(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMagicManager::helper_1402ec940  @1402ec940  [medium:callgraph-r2]  (orig: FUN_1402ec940)
void FUN_1402ec940(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402ec964. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMagicManager::helper_1402ece50  @1402ece50  [medium:callgraph-r0]  (orig: FUN_1402ece50)
void FUN_1402ece50(void *param_1)

{
  if ((DAT_140975fb8 & 1) == 0) {
    DAT_140975fb8 = DAT_140975fb8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975fb0,"CMagicManager");
    atexit((_func_5014 *)&LAB_1406d6a10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001402ecea5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975fb0,param_1);
  return;
}

// ==== CMagicManager::helper_1402ed0f0  @1402ed0f0  [medium:callgraph-r2]  (orig: FUN_1402ed0f0)
void FUN_1402ed0f0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMagicManager::helper_1402ed3a0  @1402ed3a0  [medium:callgraph-r2]  (orig: FUN_1402ed3a0)
void FUN_1402ed3a0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMagicManager::helper_1402ed400  @1402ed400  [medium:callgraph-r2]  (orig: FUN_1402ed400)
void FUN_1402ed400(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMagicManager::helper_1402ed4a0  @1402ed4a0  [medium:callgraph-r2]  (orig: FUN_1402ed4a0)
void FUN_1402ed4a0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402ed4c4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMagicManager::helper_1402ed8f0  @1402ed8f0  [medium:callgraph-r0]  (orig: FUN_1402ed8f0)
void FUN_1402ed8f0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402ed8f0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMagicManager::helper_1402ed940  @1402ed940  [medium:callgraph-r1]  (orig: FUN_1402ed940)
void FUN_1402ed940(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402ed940(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMagicManager::helper_1402eda90  @1402eda90  [medium:callgraph-r3]  (orig: FUN_1402eda90)
undefined8 *
FUN_1402eda90(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CMagicManager::helper_1402edbb0  @1402edbb0  [medium:callgraph-r1]  (orig: FUN_1402edbb0)
void FUN_1402edbb0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CMagicManager::helper_1402edc10  @1402edc10  [medium:callgraph-r1]  (orig: FUN_1402edc10)
void FUN_1402edc10(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CMagicManager::helper_1402eddc0  @1402eddc0  [medium:callgraph-r1]  (orig: FUN_1402eddc0)
void FUN_1402eddc0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402ed8f0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMagicManager::helper_1402ede40  @1402ede40  [medium:callgraph-r1]  (orig: FUN_1402ede40)
void FUN_1402ede40(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402ed940(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMagicManager::helper_1402ee0d0  @1402ee0d0  [medium:callgraph-r1]  (orig: FUN_1402ee0d0)
undefined8 * FUN_1402ee0d0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402ed4a0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1402ee2bc;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1402ee2bc:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402ed3a0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402ed400(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1402ed3a0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402ed400(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402ed3a0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1402ed400(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMagicManager::helper_1402eea40  @1402eea40  [medium:callgraph-r2]  (orig: FUN_1402eea40)
undefined8 *
FUN_1402eea40(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1402eda90(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMagicManager::helper_1402eed80  @1402eed80  [medium:callgraph-r0]  (orig: FUN_1402eed80)
longlong * FUN_1402eed80(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402ede40(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402ee0d0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMagicManager::helper_1402ef0c0  @1402ef0c0  [medium:callgraph-r0]  (orig: FUN_1402ef0c0)
void FUN_1402ef0c0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  uVar7 = 0xfffffffffffffffe;
  plVar5 = (longlong *)**(longlong **)(param_1 + 0xf8);
  plVar2 = *(longlong **)(param_1 + 200);
  plVar8 = plVar2;
  plVar9 = plVar5;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0xf8);
    if ((*(longlong **)(param_1 + 200) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 200) != plVar2)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar5) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar4 = (undefined8 *)plVar5[4];
    if (puVar4 != (undefined8 *)0x0) {
      (**(code **)*puVar4)(puVar4,1);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar9 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar9 + 0x29);
        plVar5 = plVar9;
        plVar3 = (longlong *)*plVar9;
        while (plVar9 = plVar5, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar9 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar9, plVar9 = plVar5, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2])
               )) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar9 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 0xf8) + 8);
  cVar1 = *(char *)((longlong)plVar5 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402ed940(param_1 + 200,plVar5[2],param_3,param_4,uVar7,plVar8,plVar9);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0xf8) + 8) = *(longlong *)(param_1 + 0xf8);
  *(undefined8 *)(param_1 + 0x100) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0xf8) = *(undefined8 *)(param_1 + 0xf8);
  *(longlong *)(*(longlong *)(param_1 + 0xf8) + 0x10) = *(longlong *)(param_1 + 0xf8);
  return;
}

// ==== CMagicManager::helper_1402ef280  @1402ef280  [medium:callgraph-r0]  (orig: FUN_1402ef280)
void FUN_1402ef280(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  uVar7 = 0xfffffffffffffffe;
  plVar5 = (longlong *)**(longlong **)(param_1 + 0x138);
  plVar2 = *(longlong **)(param_1 + 0x108);
  plVar8 = plVar2;
  plVar9 = plVar5;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x138);
    if ((*(longlong **)(param_1 + 0x108) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0x108) != plVar2)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar5) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar4 = (undefined8 *)plVar5[4];
    if (puVar4 != (undefined8 *)0x0) {
      (**(code **)*puVar4)(puVar4,1);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar9 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar9 + 0x29);
        plVar5 = plVar9;
        plVar3 = (longlong *)*plVar9;
        while (plVar9 = plVar5, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar9 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar9, plVar9 = plVar5, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2])
               )) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar9 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x138) + 8);
  cVar1 = *(char *)((longlong)plVar5 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402ed940(param_1 + 0x108,plVar5[2],param_3,param_4,uVar7,plVar8,plVar9);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x138) + 8) = *(longlong *)(param_1 + 0x138);
  *(undefined8 *)(param_1 + 0x140) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x138) = *(undefined8 *)(param_1 + 0x138);
  *(longlong *)(*(longlong *)(param_1 + 0x138) + 0x10) = *(longlong *)(param_1 + 0x138);
  return;
}

// ==== CMagicManager::helper_1402ef440  @1402ef440  [medium:callgraph-r0]  (orig: FUN_1402ef440)
void FUN_1402ef440(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  uVar7 = 0xfffffffffffffffe;
  plVar5 = (longlong *)**(longlong **)(param_1 + 0x178);
  plVar2 = *(longlong **)(param_1 + 0x148);
  plVar8 = plVar2;
  plVar9 = plVar5;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x178);
    if ((*(longlong **)(param_1 + 0x148) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0x148) != plVar2)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar5) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar4 = (undefined8 *)plVar5[4];
    if (puVar4 != (undefined8 *)0x0) {
      (**(code **)*puVar4)(puVar4,1);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar9 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar9 + 0x29);
        plVar5 = plVar9;
        plVar3 = (longlong *)*plVar9;
        while (plVar9 = plVar5, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar9 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar9, plVar9 = plVar5, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2])
               )) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar9 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x178) + 8);
  cVar1 = *(char *)((longlong)plVar5 + 0x29);
  while (cVar1 == '\0') {
    FUN_14002ca30(param_1 + 0x148,plVar5[2],param_3,param_4,uVar7,plVar8,plVar9);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x178) + 8) = *(longlong *)(param_1 + 0x178);
  *(undefined8 *)(param_1 + 0x180) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x178) = *(undefined8 *)(param_1 + 0x178);
  *(longlong *)(*(longlong *)(param_1 + 0x178) + 0x10) = *(longlong *)(param_1 + 0x178);
  return;
}

// ==== CMagicManager::helper_1402ef600  @1402ef600  [medium:callgraph-r0]  (orig: FUN_1402ef600)
void FUN_1402ef600(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  uVar7 = 0xfffffffffffffffe;
  plVar5 = (longlong *)**(longlong **)(param_1 + 0x1b8);
  plVar2 = *(longlong **)(param_1 + 0x188);
  plVar8 = plVar2;
  plVar9 = plVar5;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x1b8);
    if ((*(longlong **)(param_1 + 0x188) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0x188) != plVar2)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar5) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar4 = (undefined8 *)plVar5[4];
    if (puVar4 != (undefined8 *)0x0) {
      (**(code **)*puVar4)(puVar4,1);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar9 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar9 + 0x29);
        plVar5 = plVar9;
        plVar3 = (longlong *)*plVar9;
        while (plVar9 = plVar5, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar9 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar9, plVar9 = plVar5, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2])
               )) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar9 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x1b8) + 8);
  cVar1 = *(char *)((longlong)plVar5 + 0x29);
  while (cVar1 == '\0') {
    FUN_14002ca30(param_1 + 0x188,plVar5[2],param_3,param_4,uVar7,plVar8,plVar9);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x1b8) + 8) = *(longlong *)(param_1 + 0x1b8);
  *(undefined8 *)(param_1 + 0x1c0) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x1b8) = *(undefined8 *)(param_1 + 0x1b8);
  *(longlong *)(*(longlong *)(param_1 + 0x1b8) + 0x10) = *(longlong *)(param_1 + 0x1b8);
  return;
}

// ==== CMagicManager::helper_1402efa90  @1402efa90  [medium:callgraph-r1]  (orig: FUN_1402efa90)
undefined8 * FUN_1402efa90(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402ec940(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1402efc7c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1402efc7c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402ed0f0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402ec680(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1402ed0f0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402ec680(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402ed0f0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1402ec680(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMagicManager::helper_1402eff20  @1402eff20  [medium:callgraph-r1]  (orig: FUN_1402eff20)
longlong * FUN_1402eff20(longlong *param_1,longlong *param_2,longlong *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  bool bVar7;
  undefined8 *puVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar8 = (undefined8 *)param_1[6];
  bVar7 = true;
  if (*(char *)((longlong)puVar8[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar8[1];
    do {
      puVar8 = puVar5;
      bVar7 = *param_3 < (longlong)puVar8[3];
      if (bVar7) {
        puVar5 = (undefined8 *)*puVar8;
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar8;
  local_38 = lVar2;
  puVar4 = puVar8;
  if (bVar7 == false) {
LAB_1402f007d:
    local_30 = puVar4;
    if (*param_3 <= (longlong)puVar5[3]) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1402f00ad;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar8;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar8;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x29);
          puVar4 = (undefined8 *)puVar8[1];
          puVar3 = puVar8;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1402f007d;
    }
    bVar7 = true;
  }
  plVar6 = (longlong *)FUN_1402eea40(param_1,&local_38,bVar7,puVar8,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1402f00ad:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMagicManager::helper_1402f0250  @1402f0250  [medium:callgraph-r0]  (orig: FUN_1402f0250)
longlong * FUN_1402f0250(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402eddc0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402efa90(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMagicManager::helper_1402f04a0  @1402f04a0  [medium:callgraph-r0]  (orig: FUN_1402f04a0)
undefined8 FUN_1402f04a0(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 *puVar10;
  undefined7 uVar11;
  undefined8 *puVar12;
  int iVar13;
  undefined8 uVar14;
  longlong local_90;
  undefined8 *local_88;
  longlong local_80;
  undefined8 local_78;
  longlong local_70;
  longlong local_68;
  longlong local_60;
  longlong *local_58;
  undefined1 local_50 [24];
  
  uVar14 = 0xfffffffffffffffe;
  FUN_140008520(*(undefined4 *)(param_1 + 0x1c8));
  plVar5 = (longlong *)InstanceGet();
  plVar5 = (longlong *)
           (**(code **)(*plVar5 + 0x10))(plVar5,"SELECT * FROM cq_magictype",1,*plVar5,uVar14);
  if (plVar5 == (longlong *)0x0) {
    uVar11 = 0;
  }
  else {
    for (iVar13 = 0; iVar4 = (**(code **)(*plVar5 + 0x40))(plVar5), iVar13 < iVar4;
        iVar13 = iVar13 + 1) {
      (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)iVar13);
      plVar6 = (longlong *)(**(code **)(*plVar5 + 0x38))(plVar5);
      if (plVar6 != (longlong *)0x0) {
        plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,1);
        plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,8);
        lVar9 = (**(code **)(*plVar7 + 0x58))(plVar7);
        iVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
        lVar9 = (longlong)iVar4 + (lVar9 << 0x20);
        plVar7 = (longlong *)(param_1 + 200);
        puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0xf8))[1];
        cVar1 = *(char *)((longlong)puVar12 + 0x29);
        puVar3 = *(undefined8 **)(param_1 + 0xf8);
        while (cVar1 == '\0') {
          if ((longlong)puVar12[3] < lVar9) {
            puVar10 = (undefined8 *)puVar12[2];
            puVar12 = puVar3;
          }
          else {
            puVar10 = (undefined8 *)*puVar12;
          }
          puVar3 = puVar12;
          puVar12 = puVar10;
          cVar1 = *(char *)((longlong)puVar10 + 0x29);
        }
        local_88 = puVar3;
        local_90 = *plVar7;
        puVar12 = *(undefined8 **)(param_1 + 0xf8);
        if (*plVar7 == 0) {
          _invalid_parameter_noinfo();
        }
        if ((puVar3 == puVar12) || (lVar9 < (longlong)puVar3[3])) {
          local_78 = *(undefined8 *)(param_1 + 0xf8);
          local_80 = *plVar7;
          plVar8 = &local_80;
        }
        else {
          plVar8 = &local_90;
        }
        local_70 = *plVar8;
        local_68 = plVar8[1];
        lVar2 = *(longlong *)(param_1 + 0xf8);
        if ((local_70 == 0) || (local_70 != *plVar7)) {
          _invalid_parameter_noinfo();
        }
        if (local_68 == lVar2) {
          local_60 = lVar9;
          local_58 = plVar6;
          FUN_1402eff20(plVar7,local_50,&local_60);
        }
        else {
          (**(code **)*plVar6)(plVar6,1);
        }
      }
    }
    uVar14 = (**(code **)*plVar5)(plVar5);
    uVar11 = (undefined7)((ulonglong)uVar14 >> 8);
  }
  return CONCAT71(uVar11,1);
}

// ==== CMagicManager::helper_1402f06c0  @1402f06c0  [medium:callgraph-r0]  (orig: FUN_1402f06c0)
undefined8 FUN_1402f06c0(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  int iVar4;
  uint uVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  undefined7 uVar10;
  longlong *plVar11;
  undefined8 *puVar12;
  int iVar13;
  ulonglong uVar14;
  undefined8 uVar15;
  longlong local_90;
  undefined8 *local_88;
  longlong local_80;
  undefined8 local_78;
  longlong local_70;
  longlong local_68;
  ulonglong local_60;
  longlong *local_58;
  undefined1 local_50 [24];
  
  uVar15 = 0xfffffffffffffffe;
  FUN_140008520(*(undefined4 *)(param_1 + 0x1c8));
  plVar6 = (longlong *)InstanceGet();
  plVar6 = (longlong *)
           (**(code **)(*plVar6 + 0x10))(plVar6,"SELECT * FROM cq_magictype_ex",1,*plVar6,uVar15);
  if (plVar6 == (longlong *)0x0) {
    uVar10 = 0;
  }
  else {
    for (iVar13 = 0; iVar4 = (**(code **)(*plVar6 + 0x40))(plVar6), iVar13 < iVar4;
        iVar13 = iVar13 + 1) {
      (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)iVar13);
      plVar7 = (longlong *)(**(code **)(*plVar6 + 0x38))(plVar6);
      if (plVar7 != (longlong *)0x0) {
        plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
        uVar5 = (**(code **)(*plVar8 + 0x40))(plVar8);
        uVar14 = (ulonglong)uVar5;
        plVar8 = (longlong *)(param_1 + 0x108);
        puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x138))[1];
        cVar1 = *(char *)((longlong)puVar12 + 0x29);
        puVar3 = *(undefined8 **)(param_1 + 0x138);
        while (cVar1 == '\0') {
          if ((longlong)puVar12[3] < (longlong)uVar14) {
            puVar9 = (undefined8 *)puVar12[2];
            puVar12 = puVar3;
          }
          else {
            puVar9 = (undefined8 *)*puVar12;
          }
          puVar3 = puVar12;
          puVar12 = puVar9;
          cVar1 = *(char *)((longlong)puVar9 + 0x29);
        }
        local_88 = puVar3;
        local_90 = *plVar8;
        puVar12 = *(undefined8 **)(param_1 + 0x138);
        if (*plVar8 == 0) {
          _invalid_parameter_noinfo();
        }
        if ((puVar3 == puVar12) || ((longlong)uVar14 < (longlong)puVar3[3])) {
          local_78 = *(undefined8 *)(param_1 + 0x138);
          local_80 = *plVar8;
          plVar11 = &local_80;
        }
        else {
          plVar11 = &local_90;
        }
        local_70 = *plVar11;
        local_68 = plVar11[1];
        lVar2 = *(longlong *)(param_1 + 0x138);
        if ((local_70 == 0) || (local_70 != *plVar8)) {
          _invalid_parameter_noinfo();
        }
        if (local_68 == lVar2) {
          local_60 = uVar14;
          local_58 = plVar7;
          FUN_1402eff20(plVar8,local_50,&local_60);
        }
        else {
          (**(code **)*plVar7)(plVar7,1);
        }
      }
    }
    uVar15 = (**(code **)*plVar6)(plVar6);
    uVar10 = (undefined7)((ulonglong)uVar15 >> 8);
  }
  return CONCAT71(uVar10,1);
}

// ==== CMagicManager::helper_1402f08b0  @1402f08b0  [medium:callgraph-r0]  (orig: FUN_1402f08b0)
undefined8 FUN_1402f08b0(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  int iVar4;
  uint uVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined7 uVar10;
  undefined8 *puVar11;
  int iVar12;
  undefined8 *puVar13;
  undefined8 uVar14;
  longlong local_90;
  undefined8 *local_88;
  longlong local_80;
  undefined8 local_78;
  longlong local_70;
  longlong local_68;
  undefined4 local_60 [2];
  longlong *local_58;
  undefined1 local_50 [24];
  
  uVar14 = 0xfffffffffffffffe;
  FUN_140008520(*(undefined4 *)(param_1 + 0x1c8));
  plVar6 = (longlong *)InstanceGet();
  plVar6 = (longlong *)
           (**(code **)(*plVar6 + 0x10))
                     (plVar6,"SELECT * FROM cq_magictype WHERE auto_learn!=0",1,*plVar6,uVar14);
  if (plVar6 == (longlong *)0x0) {
    uVar10 = 0;
  }
  else {
    for (iVar12 = 0; iVar4 = (**(code **)(*plVar6 + 0x40))(plVar6), iVar12 < iVar4;
        iVar12 = iVar12 + 1) {
      (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)iVar12);
      plVar7 = (longlong *)(**(code **)(*plVar6 + 0x38))(plVar6);
      if (plVar7 != (longlong *)0x0) {
        plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
        uVar5 = (**(code **)(*plVar8 + 0x40))(plVar8);
        plVar8 = (longlong *)(param_1 + 0x148);
        puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0x178))[1];
        cVar1 = *(char *)((longlong)puVar13 + 0x29);
        puVar3 = *(undefined8 **)(param_1 + 0x178);
        while (cVar1 == '\0') {
          if (*(uint *)(puVar13 + 3) < uVar5) {
            puVar11 = (undefined8 *)puVar13[2];
            puVar13 = puVar3;
          }
          else {
            puVar11 = (undefined8 *)*puVar13;
          }
          puVar3 = puVar13;
          puVar13 = puVar11;
          cVar1 = *(char *)((longlong)puVar11 + 0x29);
        }
        local_88 = puVar3;
        local_90 = *plVar8;
        puVar13 = *(undefined8 **)(param_1 + 0x178);
        if (*plVar8 == 0) {
          _invalid_parameter_noinfo();
        }
        if ((puVar3 == puVar13) || (uVar5 < *(uint *)(puVar3 + 3))) {
          local_78 = *(undefined8 *)(param_1 + 0x178);
          local_80 = *plVar8;
          plVar9 = &local_80;
        }
        else {
          plVar9 = &local_90;
        }
        local_70 = *plVar9;
        local_68 = plVar9[1];
        lVar2 = *(longlong *)(param_1 + 0x178);
        if ((local_70 == 0) || (local_70 != *plVar8)) {
          _invalid_parameter_noinfo();
        }
        if (local_68 == lVar2) {
          plVar9 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
          local_60[0] = (**(code **)(*plVar9 + 0x40))(plVar9);
          local_58 = plVar7;
          FUN_14002d3d0(plVar8,local_50,local_60);
        }
        else {
          (**(code **)*plVar7)(plVar7,1);
        }
      }
    }
    uVar14 = (**(code **)*plVar6)(plVar6);
    uVar10 = (undefined7)((ulonglong)uVar14 >> 8);
  }
  return CONCAT71(uVar10,1);
}

// ==== CMagicManager::helper_1402f0ab0  @1402f0ab0  [medium:callgraph-r0]  (orig: FUN_1402f0ab0)
undefined8 FUN_1402f0ab0(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  int iVar4;
  uint uVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined7 uVar10;
  undefined8 *puVar11;
  int iVar12;
  undefined8 *puVar13;
  undefined8 uVar14;
  longlong local_90;
  undefined8 *local_88;
  longlong local_80;
  undefined8 local_78;
  longlong local_70;
  longlong local_68;
  undefined4 local_60 [2];
  longlong *local_58;
  undefined1 local_50 [24];
  
  uVar14 = 0xfffffffffffffffe;
  FUN_140008520(*(undefined4 *)(param_1 + 0x1c8));
  plVar6 = (longlong *)InstanceGet();
  plVar6 = (longlong *)
           (**(code **)(*plVar6 + 0x10))(plVar6,"SELECT * FROM cq_magictypeop",1,*plVar6,uVar14);
  if (plVar6 == (longlong *)0x0) {
    uVar10 = 0;
  }
  else {
    for (iVar12 = 0; iVar4 = (**(code **)(*plVar6 + 0x40))(plVar6), iVar12 < iVar4;
        iVar12 = iVar12 + 1) {
      (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)iVar12);
      plVar7 = (longlong *)(**(code **)(*plVar6 + 0x38))(plVar6);
      if (plVar7 != (longlong *)0x0) {
        plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
        uVar5 = (**(code **)(*plVar8 + 0x40))(plVar8);
        plVar8 = (longlong *)(param_1 + 0x188);
        puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0x1b8))[1];
        cVar1 = *(char *)((longlong)puVar13 + 0x29);
        puVar3 = *(undefined8 **)(param_1 + 0x1b8);
        while (cVar1 == '\0') {
          if (*(uint *)(puVar13 + 3) < uVar5) {
            puVar11 = (undefined8 *)puVar13[2];
            puVar13 = puVar3;
          }
          else {
            puVar11 = (undefined8 *)*puVar13;
          }
          puVar3 = puVar13;
          puVar13 = puVar11;
          cVar1 = *(char *)((longlong)puVar11 + 0x29);
        }
        local_88 = puVar3;
        local_90 = *plVar8;
        puVar13 = *(undefined8 **)(param_1 + 0x1b8);
        if (*plVar8 == 0) {
          _invalid_parameter_noinfo();
        }
        if ((puVar3 == puVar13) || (uVar5 < *(uint *)(puVar3 + 3))) {
          local_78 = *(undefined8 *)(param_1 + 0x1b8);
          local_80 = *plVar8;
          plVar9 = &local_80;
        }
        else {
          plVar9 = &local_90;
        }
        local_70 = *plVar9;
        local_68 = plVar9[1];
        lVar2 = *(longlong *)(param_1 + 0x1b8);
        if ((local_70 == 0) || (local_70 != *plVar8)) {
          _invalid_parameter_noinfo();
        }
        if (local_68 == lVar2) {
          plVar9 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
          local_60[0] = (**(code **)(*plVar9 + 0x40))(plVar9);
          local_58 = plVar7;
          FUN_14002d3d0(plVar8,local_50,local_60);
        }
        else {
          (**(code **)*plVar7)(plVar7,1);
        }
      }
    }
    uVar14 = (**(code **)*plVar6)(plVar6);
    uVar10 = (undefined7)((ulonglong)uVar14 >> 8);
  }
  return CONCAT71(uVar10,1);
}

// ==== CMagicManager::vfunc_1  @1402f2650  [high:rtti-vtable]  (orig: FUN_1402f2650)
undefined1 FUN_1402f2650(undefined8 param_1)

{
  char cVar1;
  
  cVar1 = FUN_1402f08b0();
  if (cVar1 != '\0') {
    cVar1 = FUN_1402f04a0(param_1);
    if (cVar1 != '\0') {
      cVar1 = FUN_1402f0ab0(param_1);
      if (cVar1 != '\0') {
        cVar1 = FUN_1402f06c0(param_1);
        if (cVar1 != '\0') {
          return 1;
        }
      }
    }
  }
  return 0;
}

// ==== CMagicManager::helper_1402f3b10  @1402f3b10  [medium:callgraph-r0]  (orig: FUN_1402f3b10)
undefined8 * FUN_1402f3b10(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402edc10(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMagicManager::ctor_or_dtor  @1402f3bc0  [high:vtable-assign]  (orig: FUN_1402f3bc0)
void FUN_1402f3bc0(undefined8 *param_1)

{
  undefined8 *puVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *local_48;
  longlong *plStack_40;
  longlong *local_38;
  undefined8 *puStack_30;
  undefined1 local_28 [16];
  
  *param_1 = CMagicManager::vftable;
  plVar7 = *(longlong **)param_1[0x17];
  plVar3 = (longlong *)param_1[0x11];
  local_48 = plVar3;
  plStack_40 = plVar7;
  while( true ) {
    plVar4 = (longlong *)param_1[0x17];
    if (((longlong *)param_1[0x11] == (longlong *)0x0) || ((longlong *)param_1[0x11] != plVar3)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar7) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar3;
    }
    if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar5 = (undefined8 *)plVar7[4];
    if (puVar5 != (undefined8 *)0x0) {
      (**(code **)*puVar5)(puVar5,1);
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar4 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
        cVar2 = *(char *)(*plVar4 + 0x29);
        plVar7 = plVar4;
        plVar4 = (longlong *)*plVar4;
        while (plStack_40 = plVar7, cVar2 == '\0') {
          cVar2 = *(char *)(*plVar4 + 0x29);
          plVar7 = plVar4;
          plVar4 = (longlong *)*plVar4;
        }
      }
      else {
        cVar2 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar4 = plVar7;
        while ((plVar7 = plVar6, plStack_40 = plVar7, cVar2 == '\0' &&
               (plVar4 == (longlong *)plVar7[2]))) {
          cVar2 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar4 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  puVar5 = param_1 + 0x11;
  cVar2 = *(char *)((longlong)*(longlong **)(param_1[0x17] + 8) + 0x29);
  plVar7 = *(longlong **)(param_1[0x17] + 8);
  while (cVar2 == '\0') {
    FUN_1402ed8f0(puVar5,plVar7[2]);
    plVar3 = (longlong *)*plVar7;
    operator_delete(plVar7);
    plVar7 = plVar3;
    cVar2 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(undefined8 *)(param_1[0x17] + 8) = param_1[0x17];
  param_1[0x18] = 0;
  *(undefined8 *)param_1[0x17] = param_1[0x17];
  *(undefined8 *)(param_1[0x17] + 0x10) = param_1[0x17];
  FUN_1402ef0c0(param_1);
  FUN_1402ef280(param_1);
  FUN_1402ef440(param_1);
  FUN_1402ef600(param_1);
  puVar1 = param_1 + 0x31;
  plStack_40 = (longlong *)param_1[0x37];
  local_48 = (longlong *)*puVar1;
  puStack_30 = (undefined8 *)*plStack_40;
  local_38 = local_48;
  FUN_14002da30(puVar1,local_28,&local_38,&local_48);
  operator_delete((void *)param_1[0x37]);
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  operator_delete((void *)*puVar1);
  puVar1 = param_1 + 0x29;
  puStack_30 = (undefined8 *)param_1[0x2f];
  local_48 = (longlong *)*puVar1;
  plStack_40 = (longlong *)*puStack_30;
  local_38 = local_48;
  FUN_14002da30(puVar1,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[0x2f]);
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  operator_delete((void *)*puVar1);
  puVar1 = param_1 + 0x21;
  puStack_30 = (undefined8 *)param_1[0x27];
  local_48 = (longlong *)*puVar1;
  plStack_40 = (longlong *)*puStack_30;
  local_38 = local_48;
  FUN_1402eed80(puVar1,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[0x27]);
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  operator_delete((void *)*puVar1);
  puVar1 = param_1 + 0x19;
  puStack_30 = (undefined8 *)param_1[0x1f];
  local_48 = (longlong *)*puVar1;
  plStack_40 = (longlong *)*puStack_30;
  local_38 = local_48;
  FUN_1402eed80(puVar1,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[0x1f]);
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  operator_delete((void *)*puVar1);
  puStack_30 = (undefined8 *)param_1[0x17];
  local_48 = (longlong *)*puVar5;
  plStack_40 = (longlong *)*puStack_30;
  local_38 = local_48;
  FUN_1402f0250(puVar5,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[0x17]);
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  operator_delete((void *)*puVar5);
  puVar5 = param_1 + 9;
  puStack_30 = (undefined8 *)param_1[0xf];
  local_48 = (longlong *)*puVar5;
  plStack_40 = (longlong *)*puStack_30;
  local_38 = local_48;
  FUN_1400e71c0(puVar5,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[0xf]);
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  operator_delete((void *)*puVar5);
  puVar5 = param_1 + 1;
  puStack_30 = (undefined8 *)param_1[7];
  local_48 = (longlong *)*puVar5;
  plStack_40 = (longlong *)*puStack_30;
  local_38 = local_48;
  FUN_14000bd50(puVar5,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[7]);
  param_1[7] = 0;
  param_1[8] = 0;
  operator_delete((void *)*puVar5);
  return;
}

// ==== CMagicManager::vfunc_2  @1402f40b0  [high:rtti-vtable]  (orig: FUN_1402f40b0)
void FUN_1402f40b0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMagicManager::helper_1402f4650  @1402f4650  [medium:callgraph-r0]  (orig: FUN_1402f4650)
undefined8 * FUN_1402f4650(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402edbb0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMagicManager::ctor_or_dtor  @1402f46d0  [high:vtable-assign]  (orig: FUN_1402f46d0)
undefined8 * FUN_1402f46d0(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CMagicManager::vftable;
  FUN_14000ef40(param_1 + 1);
  FUN_1400ec260(param_1 + 9);
  FUN_1402f4650(param_1 + 0x11);
  FUN_1402f3b10(param_1 + 0x19);
  FUN_1402f3b10(param_1 + 0x21);
  FUN_14002e1c0(param_1 + 0x29);
  FUN_14002e1c0(param_1 + 0x31);
  *(undefined4 *)(param_1 + 0x39) = param_2;
  *(undefined1 *)((longlong)param_1 + 0x1cc) = 0;
  return param_1;
}

// ==== CMagicManager::vfunc_0  @1402f4770  [high:rtti-vtable]  (orig: FUN_1402f4770)
undefined8 FUN_1402f4770(undefined8 param_1,uint param_2)

{
  FUN_1402f3bc0();
  if ((param_2 & 1) != 0) {
    FUN_1402ece50(param_1);
  }
  return param_1;
}

