// ==== CMsgRouletteNpcInfo::ctor_or_dtor  @14040ac40  [high:vtable-assign]  (orig: FUN_14040ac40)
undefined8 * FUN_14040ac40(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRouletteNpcInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRouletteNpcInfo::ctor_or_dtor  @14040ac90  [high:vtable-assign]  (orig: FUN_14040ac90)
void FUN_14040ac90(undefined8 *param_1)

{
  *param_1 = CMsgRouletteNpcInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRouletteNpcInfo::vfunc_1  @14040acc0  [high:rtti-vtable]  (orig: FUN_14040acc0)
ulonglong FUN_14040acc0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xaf7);
}

// ==== CMsgRouletteNpcInfo::vfunc_3  @14040ae70  [high:rtti-vtable]  (orig: FUN_14040ae70)
void FUN_14040ae70(void)

{
  return;
}

// ==== CMsgRouletteNpcInfo::ctor_or_dtor  @14040ae80  [high:vtable-assign]  (orig: FUN_14040ae80)
undefined8 * FUN_14040ae80(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRouletteNpcInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

