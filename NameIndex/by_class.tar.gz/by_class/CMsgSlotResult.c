// ==== CMsgSlotResult::ctor_or_dtor  @140424450  [high:vtable-assign]  (orig: FUN_140424450)
undefined8 * FUN_140424450(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgSlotResult::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgSlotResult::ctor_or_dtor  @1404244a0  [high:vtable-assign]  (orig: FUN_1404244a0)
void FUN_1404244a0(undefined8 *param_1)

{
  *param_1 = CMsgSlotResult::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgSlotResult::vfunc_1  @1404244d0  [high:rtti-vtable]  (orig: FUN_1404244d0)
bool FUN_1404244d0(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x548;
    }
  }
  return false;
}

// ==== CMsgSlotResult::vfunc_3  @140424630  [high:rtti-vtable]  (orig: FUN_140424630)
void FUN_140424630(void)

{
  return;
}

// ==== CMsgSlotResult::ctor_or_dtor  @140424640  [high:vtable-assign]  (orig: FUN_140424640)
undefined8 * FUN_140424640(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgSlotResult::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

