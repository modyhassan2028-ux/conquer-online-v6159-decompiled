// ==== CTrainingVitalityMgr::helper_140153210  @140153210  [medium:callgraph-r2]  (orig: FUN_140153210)
void FUN_140153210(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CTrainingVitalityMgr::helper_140153270  @140153270  [medium:callgraph-r2]  (orig: FUN_140153270)
void FUN_140153270(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CTrainingVitalityMgr::helper_140153410  @140153410  [medium:callgraph-r2]  (orig: FUN_140153410)
void FUN_140153410(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140153434. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CTrainingVitalityMgr::helper_140154780  @140154780  [medium:callgraph-r1]  (orig: FUN_140154780)
undefined8 * FUN_140154780(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140153410(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14015496c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14015496c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140153210(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140153270(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_140153210(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140153270(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140153210(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_140153270(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CTrainingVitalityMgr::helper_140166c00  @140166c00  [medium:callgraph-r0]  (orig: FUN_140166c00)
void FUN_140166c00(longlong *param_1,int param_2)

{
  if (param_2 < 0) {
    (**(code **)(*param_1 + 8))();
                    /* WARNING: Could not recover jumptable at 0x000140166c23. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("User(%u) Set Strength Value(%d) Error.");
    return;
  }
  FUN_140373c60(param_1 + 0x1cf);
  return;
}

// ==== CTrainingVitalityMgr::helper_1402e2720  @1402e2720  [medium:callgraph-r0]  (orig: FUN_1402e2720)
void FUN_1402e2720(void *param_1)

{
  if ((DAT_140975fa8 & 1) == 0) {
    DAT_140975fa8 = DAT_140975fa8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975fa0,"CTrainingVitalityMgr");
    atexit((_func_5014 *)&LAB_1406d6a00);
  }
                    /* WARNING: Could not recover jumptable at 0x0001402e2775. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975fa0,param_1);
  return;
}

// ==== CTrainingVitalityMgr::helper_1402e4180  @1402e4180  [medium:callgraph-r1]  (orig: FUN_1402e4180)
void FUN_1402e4180(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CTrainingVitalityMgr::helper_1402e41e0  @1402e41e0  [medium:callgraph-r1]  (orig: FUN_1402e41e0)
void FUN_1402e41e0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CTrainingVitalityMgr::helper_1402e42e0  @1402e42e0  [medium:callgraph-r2]  (orig: FUN_1402e42e0)
void FUN_1402e42e0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402e3f20(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CTrainingVitalityMgr::helper_1402e4360  @1402e4360  [medium:callgraph-r2]  (orig: FUN_1402e4360)
void FUN_1402e4360(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402e3f70(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CTrainingVitalityMgr::helper_1402e5ee0  @1402e5ee0  [medium:callgraph-r0]  (orig: FUN_1402e5ee0)
longlong * FUN_1402e5ee0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CTrainingVitalityMgr::helper_1402e5ff0  @1402e5ff0  [medium:callgraph-r1]  (orig: FUN_1402e5ff0)
longlong * FUN_1402e5ff0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402e42e0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402e54e0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CTrainingVitalityMgr::helper_1402e61f0  @1402e61f0  [medium:callgraph-r1]  (orig: FUN_1402e61f0)
longlong * FUN_1402e61f0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402e4360(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402e5b20(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CTrainingVitalityMgr::helper_1402e6f70  @1402e6f70  [medium:callgraph-r0]  (orig: FUN_1402e6f70)
void FUN_1402e6f70(undefined8 param_1,longlong *param_2,undefined1 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  
  if (param_2 != (longlong *)0x0) {
    plVar5 = (longlong *)CurrentInstanceGet();
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,0x11);
    if (plVar5 != (longlong *)0x0) {
      lVar1 = *plVar5;
      uVar2 = FUN_1402e69e0(param_1,param_2,param_3);
      uVar3 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      (**(code **)(lVar1 + 0x58))(plVar5,uVar4,uVar3,param_3,uVar2);
    }
  }
  return;
}

// ==== CTrainingVitalityMgr::MakeUpCostAndRecover  @1402e7ec0  [high:log-string]  (orig: FUN_1402e7ec0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1402e7ec0(longlong param_1,longlong *param_2,undefined1 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  char cVar4;
  uint uVar5;
  longlong lVar6;
  __time64_t _Var7;
  longlong lVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  uint uVar11;
  undefined8 *puVar12;
  longlong lVar13;
  longlong lVar14;
  double dVar15;
  undefined1 auStack_508 [32];
  undefined4 *local_4e8;
  undefined4 *local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d0;
  undefined4 local_4c8;
  undefined4 local_4c4;
  undefined4 local_4c0;
  undefined4 local_4bc;
  undefined4 local_4b8 [2];
  longlong *local_4b0;
  longlong local_4a8;
  longlong local_4a0;
  undefined8 local_498;
  longlong local_490;
  undefined8 *local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_480 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar4 = *(char *)((longlong)puVar12 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x38);
    while (cVar4 == '\0') {
      if (*(uint *)(puVar12 + 3) < uVar5) {
        puVar9 = (undefined8 *)puVar12[2];
        puVar12 = puVar3;
      }
      else {
        puVar9 = (undefined8 *)*puVar12;
      }
      puVar3 = puVar12;
      puVar12 = puVar9;
      cVar4 = *(char *)((longlong)puVar9 + 0x29);
    }
    local_488 = puVar3;
    local_490 = *(longlong *)(param_1 + 8);
    puVar12 = *(undefined8 **)(param_1 + 0x38);
    if (*(longlong *)(param_1 + 8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar12) || (uVar5 < *(uint *)(puVar3 + 3))) {
      local_498 = *(undefined8 *)(param_1 + 0x38);
      local_4a0 = *(longlong *)(param_1 + 8);
      plVar10 = &local_4a0;
    }
    else {
      plVar10 = &local_490;
    }
    plVar1 = (longlong *)*plVar10;
    local_4a8 = plVar10[1];
    lVar14 = *(longlong *)(param_1 + 0x38);
    local_4b0 = plVar1;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    lVar2 = local_4a8;
    if (local_4a8 != lVar14) {
      lVar14 = 0;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = lVar14;
      }
      else {
        lVar13 = *plVar1;
      }
      if (lVar2 == *(longlong *)(lVar13 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar2 = *(longlong *)(lVar2 + 0x20);
      if (lVar2 == 0) {
        local_4e8 = (undefined4 *)CONCAT44(local_4e8._4_4_,0x709);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        local_4b8[0] = (**(code **)(*param_2 + 8))(param_2);
        FUN_1402e5ee0(param_1 + 0x48,&local_4b0,local_4b8);
        plVar10 = local_4b0;
        lVar13 = *(longlong *)(param_1 + 0x78);
        if ((local_4b0 == (longlong *)0x0) || (local_4b0 != *(longlong **)(param_1 + 0x48))) {
          _invalid_parameter_noinfo();
        }
        lVar6 = local_4a8;
        if (local_4a8 != lVar13) {
          if (plVar10 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar13 = lVar14;
          }
          else {
            lVar13 = *plVar10;
          }
          if (lVar6 == *(longlong *)(lVar13 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar13 = *(longlong *)(lVar6 + 0x20);
          if (lVar13 == 0) {
            local_4e8 = (undefined4 *)CONCAT44(local_4e8._4_4_,0x713);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            cVar4 = FUN_14047d1f0(lVar13,param_3);
            if ((cVar4 != '\0') && (lVar6 = FUN_14047ca90(lVar13,param_3), lVar6 != -1)) {
              _Var7 = _time64((__time64_t *)0x0);
              lVar8 = _Var7 - lVar6;
              if (_Var7 - lVar6 < 1) {
                lVar8 = lVar14;
              }
              if (*(uint *)(param_1 + 0xb4) != 0) {
                dVar15 = ceil((((double)*(uint *)(param_1 + 0xb8) /
                               (double)*(uint *)(param_1 + 0xb4)) / _DAT_140727618) *
                              ((double)lVar8 / _DAT_140727618));
                uVar5 = *(uint *)(param_1 + 0xbc);
                uVar11 = (uint)(longlong)dVar15;
                if ((uVar5 < uVar11) && (uVar5 != 0)) {
                  uVar11 = uVar5;
                }
                uVar5 = FUN_140166bf0(param_2);
                if (uVar11 <= uVar5) {
                  FUN_140166c00(param_2,uVar5 - uVar11,1);
                  local_4bc = 0;
                  local_4c4 = 0;
                  local_4c8 = 0;
                  local_4c0 = 0;
                  local_4e0 = &local_4c0;
                  local_4e8 = &local_4c8;
                  cVar4 = FUN_14047d000(lVar13,param_3,&local_4bc,&local_4c4);
                  if (cVar4 == '\0') {
                    (**(code **)(*param_2 + 8))(param_2);
                    log_InlineLogERROR(
                                      "CTrainingVitalityMgr::MakeUpCostAndRecover(), User(%u) Get Protect Fate(%u) Attrib And Delete Failed."
                                      );
                  }
                  else {
                    local_4e0 = (undefined4 *)CONCAT44(local_4e0._4_4_,local_4c0);
                    local_4e8 = (undefined4 *)CONCAT44(local_4e8._4_4_,local_4c8);
                    FUN_140477740(lVar2,param_3,local_4bc,local_4c4);
                    FUN_1402e6f70(param_1,param_2,param_3);
                    FUN_140450dc0(local_478);
                    cVar4 = FUN_140450e80(local_478,param_3,8);
                    if (cVar4 != '\0') {
                      (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
                    }
                    (**(code **)(*param_2 + 8))(param_2);
                    local_4d0 = local_4c0;
                    local_4d8 = local_4c8;
                    local_4e0 = (undefined4 *)CONCAT44(local_4e0._4_4_,local_4c4);
                    local_4e8 = (undefined4 *)CONCAT44(local_4e8._4_4_,local_4bc);
                    tq::MyLogSave("gmlog/TrainingVitality",
                                  "Recover User Fate Attrib. UserID(%u) FateNo(%u), AttribAndValue1(%u),AttribAndValue2(%u),AttribAndValue3(%u),AttribAndValue4(%u)"
                                 );
                    FUN_140450e10(local_478);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CTrainingVitalityMgr::helper_1402e8e00  @1402e8e00  [medium:callgraph-r0]  (orig: FUN_1402e8e00)
void FUN_1402e8e00(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1402e5ff0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CTrainingVitalityMgr::helper_1402e8ef0  @1402e8ef0  [medium:callgraph-r0]  (orig: FUN_1402e8ef0)
void FUN_1402e8ef0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1402e61f0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CTrainingVitalityMgr::ctor_or_dtor  @1402e97a0  [high:vtable-assign]  (orig: FUN_1402e97a0)
void FUN_1402e97a0(undefined8 *param_1)

{
  *param_1 = CTrainingVitalityMgr::vftable;
  FUN_1402e8ef0(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_1402e8e00(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CTrainingVitalityMgr::helper_1402e9810  @1402e9810  [medium:callgraph-r0]  (orig: FUN_1402e9810)
undefined8 * FUN_1402e9810(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402e4180(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CTrainingVitalityMgr::helper_1402e9890  @1402e9890  [medium:callgraph-r0]  (orig: FUN_1402e9890)
undefined8 * FUN_1402e9890(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402e41e0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CTrainingVitalityMgr::ctor_or_dtor  @1402e9910  [high:vtable-assign]  (orig: FUN_1402e9910)
undefined8 * FUN_1402e9910(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CTrainingVitalityMgr::vftable;
  FUN_1402e9810(param_1 + 1);
  FUN_1402e9890(param_1 + 9);
  *(undefined4 *)(param_1 + 0x11) = param_2;
  *(undefined4 *)((longlong)param_1 + 0x8c) = 0;
  *(undefined1 *)(param_1 + 0x12) = 1;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  *(undefined4 *)(param_1 + 0x16) = 4;
  *(undefined4 *)((longlong)param_1 + 0xb4) = 0xa8;
  *(undefined4 *)(param_1 + 0x17) = 4000;
  *(undefined4 *)((longlong)param_1 + 0xbc) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0x46;
  return param_1;
}

// ==== CTrainingVitalityMgr::ctor_or_dtor  @1402e99c0  [high:vtable-assign]  (orig: FUN_1402e99c0)
undefined8 * FUN_1402e99c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CTrainingVitalityMgr::vftable;
  FUN_1402e8ef0(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_1402e8e00(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    FUN_1402e2720(param_1);
  }
  return param_1;
}

// ==== CTrainingVitalityMgr::helper_140477740  @140477740  [medium:callgraph-r0]  (orig: FUN_140477740)
void FUN_140477740(longlong param_1,char param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (3 < (byte)(param_2 - 1U)) {
    return;
  }
  if (*(longlong *)(param_1 + 0x20) == 0) {
    return;
  }
  if (param_2 == '\x01') {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))(*(longlong **)(param_1 + 0x20),2)
    ;
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_3);
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))(*(longlong **)(param_1 + 0x20),3)
    ;
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_4);
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))(*(longlong **)(param_1 + 0x20),4)
    ;
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_5);
    uVar2 = 5;
  }
  else if (param_2 == '\x02') {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))(*(longlong **)(param_1 + 0x20),6)
    ;
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_3);
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))(*(longlong **)(param_1 + 0x20),7)
    ;
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_4);
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))(*(longlong **)(param_1 + 0x20),8)
    ;
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_5);
    uVar2 = 9;
  }
  else if (param_2 == '\x03') {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                       (*(longlong **)(param_1 + 0x20),10);
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_3);
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                       (*(longlong **)(param_1 + 0x20),0xb);
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_4);
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                       (*(longlong **)(param_1 + 0x20),0xc);
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_5);
    uVar2 = 0xd;
  }
  else {
    if (param_2 != '\x04') goto LAB_14047793c;
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                       (*(longlong **)(param_1 + 0x20),0xe);
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_3);
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                       (*(longlong **)(param_1 + 0x20),0xf);
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_4);
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                       (*(longlong **)(param_1 + 0x20),0x10);
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_5);
    uVar2 = 0x11;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                     (*(longlong **)(param_1 + 0x20),uVar2);
  (**(code **)(*plVar1 + 0xa8))(plVar1,param_6);
LAB_14047793c:
  if (*(char *)(param_1 + 0x30) == '\0') {
    (**(code **)(**(longlong **)(param_1 + 0x20) + 0x38))(*(longlong **)(param_1 + 0x20),0);
  }
  return;
}

// ==== CTrainingVitalityMgr::helper_14047ca90  @14047ca90  [medium:callgraph-r0]  (orig: FUN_14047ca90)
undefined8 FUN_14047ca90(longlong param_1,byte param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 uVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar9 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar9 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar9[2];
      puVar9 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar9;
    }
    puVar3 = puVar9;
    puVar9 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar9 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar9) || (param_2 < *(byte *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar10 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = *(longlong **)(lVar4 + 0x20);
    if (plVar7 != (longlong *)0x0) {
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,3);
      uVar5 = (**(code **)(*plVar7 + 0x50))(plVar7);
      uVar8 = FUN_14047bd60(param_1,uVar5);
      return uVar8;
    }
  }
  return 0xffffffffffffffff;
}

// ==== CTrainingVitalityMgr::helper_14047d000  @14047d000  [medium:callgraph-r0]  (orig: FUN_14047d000)
undefined1
FUN_14047d000(longlong param_1,byte param_2,undefined4 *param_3,undefined4 *param_4,
             undefined4 *param_5,undefined4 *param_6)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  char cVar5;
  undefined1 uVar6;
  undefined4 uVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong **pplVar10;
  undefined8 *puVar11;
  longlong lVar12;
  longlong *local_38;
  undefined8 *local_30;
  longlong *local_28;
  longlong *plStack_20;
  
  puVar11 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar5 = *(char *)((longlong)puVar11 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x40);
  while (cVar5 == '\0') {
    if (*(byte *)(puVar11 + 3) < param_2) {
      puVar8 = (undefined8 *)puVar11[2];
      puVar11 = puVar4;
    }
    else {
      puVar8 = (undefined8 *)*puVar11;
    }
    puVar4 = puVar11;
    puVar11 = puVar8;
    cVar5 = *(char *)((longlong)puVar8 + 0x29);
  }
  local_30 = puVar4;
  local_38 = *(longlong **)(param_1 + 0x10);
  puVar11 = *(undefined8 **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x10) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar11) || (param_2 < *(byte *)(puVar4 + 3))) {
    plStack_20 = (longlong *)*(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong **)(param_1 + 0x10);
    pplVar10 = &local_28;
  }
  else {
    pplVar10 = &local_38;
  }
  plVar1 = *pplVar10;
  plVar2 = pplVar10[1];
  plVar3 = *(longlong **)(param_1 + 0x40);
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  if (plVar2 == plVar3) {
    uVar6 = 0;
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = 0;
    }
    else {
      lVar12 = *plVar1;
    }
    if (plVar2 == *(longlong **)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = (longlong *)plVar2[4];
    if (plVar3 == (longlong *)0x0) {
      uVar6 = 0;
    }
    else {
      plVar9 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
      uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
      *param_3 = uVar7;
      plVar9 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,5);
      uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
      *param_4 = uVar7;
      plVar9 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,6);
      uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
      *param_5 = uVar7;
      plVar9 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,7);
      uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
      *param_6 = uVar7;
      cVar5 = (**(code **)(*plVar3 + 0x40))(plVar3,0);
      uVar6 = 0;
      if (cVar5 != '\0') {
        (**(code **)*plVar3)(plVar3,1);
        local_28 = plVar1;
        plStack_20 = plVar2;
        FUN_140154780(param_1 + 0x10,&local_38,&local_28);
        uVar6 = 1;
      }
    }
  }
  return uVar6;
}

// ==== CTrainingVitalityMgr::helper_14047d1f0  @14047d1f0  [medium:callgraph-r0]  (orig: FUN_14047d1f0)
bool FUN_14047d1f0(longlong param_1,byte param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar6 + 3) < param_2) {
      puVar4 = (undefined8 *)puVar6[2];
      puVar6 = puVar3;
    }
    else {
      puVar4 = (undefined8 *)*puVar6;
    }
    puVar3 = puVar6;
    puVar6 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x29);
  }
  puVar6 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar6) || (param_2 < *(byte *)(puVar3 + 3))) {
    plVar5 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar5 = &local_38;
  }
  local_18 = *plVar5;
  lVar2 = *(longlong *)(param_1 + 0x40);
  local_10 = plVar5[1];
  if ((local_18 == 0) || (local_18 != *(longlong *)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  return local_10 != lVar2;
}

