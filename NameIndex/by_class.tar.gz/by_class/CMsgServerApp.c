// ==== CMsgServerApp::ctor_or_dtor  @14001d880  [high:vtable-assign]  (orig: FUN_14001d880)
CWinApp * FUN_14001d880(CWinApp *param_1)

{
  CWinApp::CWinApp(param_1,(char *)0x0);
  *(undefined ***)param_1 = CMsgServerApp::vftable;
  *(undefined8 *)(param_1 + 0x140) = 0;
  return param_1;
}

// ==== CMsgServerApp::helper_14001d8e0  @14001d8e0  [medium:callgraph-r0]  (orig: FUN_14001d8e0)
void FUN_14001d8e0(void)

{
  char *local_18 [3];
  
  local_18[0] = "Invalid parameter!";
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_18,(ThrowInfo *)&DAT_140944608);
}

// ==== CMsgServerApp::helper_14001d910  @14001d910  [medium:callgraph-r0]  (orig: FUN_14001d910)
void FUN_14001d910(void)

{
  char *local_res8 [4];
  
  local_res8[0] = "pure call handler!";
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_res8,(ThrowInfo *)&DAT_140944608);
}

// ==== CMsgServerApp::vfunc_28  @14001d940  [high:rtti-vtable]  (orig: FUN_14001d940)
void FUN_14001d940(CWinApp *param_1)

{
  if (*(HANDLE *)(param_1 + 0x140) != (HANDLE)0x0) {
    CloseHandle(*(HANDLE *)(param_1 + 0x140));
    *(undefined8 *)(param_1 + 0x140) = 0;
  }
  CWinApp::ExitInstance(param_1);
  return;
}

// ==== CMsgServerApp::vfunc_2  @14001d980  [high:rtti-vtable]  (orig: FUN_14001d980)
void FUN_14001d980(void)

{
  return;
}

// ==== CMsgServerApp::vfunc_3  @14001d9a0  [high:rtti-vtable]  (orig: FUN_14001d9a0)
void FUN_14001d9a0(void)

{
  return;
}

// ==== CMsgServerApp::vfunc_4  @14001d9b0  [high:rtti-vtable]  (orig: FUN_14001d9b0)
void FUN_14001d9b0(void)

{
  return;
}

// ==== CMsgServerApp::vfunc_12  @14001d9f0  [high:rtti-vtable]  (orig: FUN_14001d9f0)
undefined ** FUN_14001d9f0(void)

{
  return &PTR_LAB_1406dff48;
}

// ==== CMsgServerApp::vfunc_1  @14001da00  [high:rtti-vtable]  (orig: FUN_14001da00)
CWinApp * FUN_14001da00(CWinApp *param_1,uint param_2)

{
  CWinApp::~CWinApp(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgServerApp::vfunc_22  @14001dbd0  [high:rtti-vtable]  (orig: FUN_14001dbd0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14001dbd0(longlong param_1)

{
  DWORD DVar1;
  int iVar2;
  BOOL BVar3;
  char *pcVar4;
  HANDLE pvVar5;
  HWND pHVar6;
  undefined1 auStack_2728 [32];
  CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> local_2708 [8];
  undefined8 local_2700;
  CIniFile local_26f8 [1024];
  CDialog local_22f8 [8912];
  char local_28 [16];
  ulonglong local_18;
  undefined8 uStack_10;
  
  uStack_10 = 0x14001dbdc;
  local_2700 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_2728;
  _set_invalid_parameter_handler(FUN_14001d8e0);
  _set_purecall_handler(FUN_14001d910);
  CIniFile::CIniFile(local_26f8,"shell.ini","AccountServer");
  CIniFile::GetString(local_26f8,local_28,"SERVERNAME",0x10);
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>(local_2708);
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::Format
            (local_2708,"%s - %s","Conquer Online Server",local_28);
  pcVar4 = ATL::CSimpleStringT<char,1>::operator_char_const____ptr64
                     ((CSimpleStringT<char,1> *)local_2708);
  pvVar5 = CreateMutexA((LPSECURITY_ATTRIBUTES)0x0,1,pcVar4);
  *(HANDLE *)(param_1 + 0x140) = pvVar5;
  if (pvVar5 == (HANDLE)0x0) {
    pcVar4 = ATL::CSimpleStringT<char,1>::operator_char_const____ptr64
                       ((CSimpleStringT<char,1> *)local_2708);
    MessageBoxA((HWND)0x0,"Create mutex failed.",pcVar4,0x30);
    ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
    ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>(local_2708);
    CIniFile::~CIniFile(local_26f8);
  }
  else {
    DVar1 = GetLastError();
    if (DVar1 == 0xb7) {
      CloseHandle(*(HANDLE *)(param_1 + 0x140));
      *(undefined8 *)(param_1 + 0x140) = 0;
      pHVar6 = GetDesktopWindow();
      pHVar6 = GetWindow(pHVar6,5);
      iVar2 = IsWindow(pHVar6);
      while (iVar2 != 0) {
        pcVar4 = ATL::CSimpleStringT<char,1>::operator_char_const____ptr64
                           ((CSimpleStringT<char,1> *)local_2708);
        pvVar5 = GetPropA(pHVar6,pcVar4);
        if (pvVar5 != (HANDLE)0x0) {
          BVar3 = IsIconic(pHVar6);
          if (BVar3 != 0) {
            ShowWindow(pHVar6,9);
          }
          SetForegroundWindow(pHVar6);
          ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
          ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>(local_2708);
          CIniFile::~CIniFile(local_26f8);
          return 0;
        }
        pHVar6 = GetWindow(pHVar6,2);
        iVar2 = IsWindow(pHVar6);
      }
      pcVar4 = ATL::CSimpleStringT<char,1>::operator_char_const____ptr64
                         ((CSimpleStringT<char,1> *)local_2708);
      MessageBoxA((HWND)0x0,"MsgServer is running, but I can\'t find its window.",pcVar4,0x30);
      ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
      ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>(local_2708);
      CIniFile::~CIniFile(local_26f8);
    }
    else {
      CreateDirectoryA("log",(LPSECURITY_ATTRIBUTES)0x0);
      CreateDirectoryA("crimelog",(LPSECURITY_ATTRIBUTES)0x0);
      FUN_1400238a0(local_22f8,0);
      *(CDialog **)(param_1 + 0x40) = local_22f8;
      CDialog::DoModal(local_22f8);
      FUN_14001db10(local_22f8);
      ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
      ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>(local_2708);
      CIniFile::~CIniFile(local_26f8);
    }
  }
  return 0;
}

// ==== CMsgServerApp::ctor_or_dtor  @1406d5ec0  [high:vtable-assign]  (orig: FUN_1406d5ec0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1406d5ec0(void)

{
  CWinApp::CWinApp((CWinApp *)&DAT_140975510,(char *)0x0);
  _DAT_140975510 = CMsgServerApp::vftable;
  _DAT_140975650 = 0;
  atexit(FUN_1406d6500);
  return;
}

// ==== CMsgServerApp::helper_1406d6500  @1406d6500  [medium:callgraph-r0]  (orig: FUN_1406d6500)
void FUN_1406d6500(void)

{
  CWinApp::~CWinApp((CWinApp *)&DAT_140975510);
  return;
}

