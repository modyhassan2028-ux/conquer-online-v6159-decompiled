// ==== CAchievementSet::Create  @140375b20  [high:log-string]  (orig: FUN_140375b20)
undefined8 FUN_140375b20(longlong param_1)

{
  char cVar1;
  undefined8 *puVar2;
  int iVar3;
  uint uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined8 uVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  int local_res10;
  longlong local_c8;
  undefined8 *local_c0;
  longlong local_b8;
  undefined8 local_b0;
  longlong local_a8;
  undefined8 *local_a0;
  longlong local_98;
  longlong local_90;
  longlong local_88;
  longlong local_80;
  undefined4 local_78 [2];
  longlong *local_70;
  longlong local_68;
  undefined8 local_60;
  undefined4 local_58 [2];
  longlong *local_50;
  undefined8 local_48;
  undefined1 local_40 [24];
  
  local_48 = 0xfffffffffffffffe;
  plVar5 = (longlong *)InstanceGet();
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"SELECT * FROM cq_achievementtype",1);
  uVar11 = 0;
  if (plVar5 != (longlong *)0x0) {
    lVar6 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (lVar6 == 0) {
      log_InlineLogERROR("CAchievementSet::Create. cq_achievement record count is 0!");
    }
    local_res10 = 0;
    iVar3 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (0 < iVar3) {
      do {
        (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)local_res10);
        plVar7 = (longlong *)(**(code **)(*plVar5 + 0x38))(plVar5);
        if (plVar7 == (longlong *)0x0) {
          log_InlineLogERROR("CAchievementSet::Create pRec == NULL!");
          (**(code **)*plVar5)(plVar5);
          return 0;
        }
        plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
        uVar4 = (**(code **)(*plVar8 + 0x40))(plVar8);
        plVar8 = (longlong *)(param_1 + 8);
        puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
        cVar1 = *(char *)((longlong)puVar13 + 0x29);
        puVar2 = *(undefined8 **)(param_1 + 0x38);
        while (cVar1 == '\0') {
          if (*(uint *)(puVar13 + 3) < uVar4) {
            puVar12 = (undefined8 *)puVar13[2];
            puVar13 = puVar2;
          }
          else {
            puVar12 = (undefined8 *)*puVar13;
          }
          puVar2 = puVar13;
          puVar13 = puVar12;
          cVar1 = *(char *)((longlong)puVar12 + 0x29);
        }
        local_a0 = puVar2;
        local_a8 = *plVar8;
        puVar13 = *(undefined8 **)(param_1 + 0x38);
        if (*plVar8 == 0) {
          _invalid_parameter_noinfo();
        }
        if ((puVar2 == puVar13) || (uVar4 < *(uint *)(puVar2 + 3))) {
          local_60 = *(undefined8 *)(param_1 + 0x38);
          local_68 = *plVar8;
          plVar9 = &local_68;
        }
        else {
          plVar9 = &local_a8;
        }
        local_88 = *plVar9;
        local_80 = plVar9[1];
        lVar6 = *(longlong *)(param_1 + 0x38);
        if ((local_88 == 0) || (local_88 != *plVar8)) {
          _invalid_parameter_noinfo();
        }
        if (local_80 != lVar6) {
          plVar9 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
          (**(code **)(*plVar9 + 0x40))(plVar9);
          log_InlineLogERROR("CAchievementSet::Create(). ID[%u] is repeat");
        }
        plVar9 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,2);
        uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
        plVar9 = (longlong *)(param_1 + 0x48);
        puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
        cVar1 = *(char *)((longlong)puVar13 + 0x29);
        puVar2 = *(undefined8 **)(param_1 + 0x78);
        while (cVar1 == '\0') {
          if (*(uint *)(puVar13 + 3) < uVar4) {
            puVar12 = (undefined8 *)puVar13[2];
            puVar13 = puVar2;
          }
          else {
            puVar12 = (undefined8 *)*puVar13;
          }
          puVar2 = puVar13;
          puVar13 = puVar12;
          cVar1 = *(char *)((longlong)puVar12 + 0x29);
        }
        local_c0 = puVar2;
        local_c8 = *plVar9;
        puVar13 = *(undefined8 **)(param_1 + 0x78);
        if (*plVar9 == 0) {
          _invalid_parameter_noinfo();
        }
        if ((puVar2 == puVar13) || (uVar4 < *(uint *)(puVar2 + 3))) {
          local_b0 = *(undefined8 *)(param_1 + 0x78);
          local_b8 = *plVar9;
          plVar10 = &local_b8;
        }
        else {
          plVar10 = &local_c8;
        }
        local_98 = *plVar10;
        local_90 = plVar10[1];
        lVar6 = *(longlong *)(param_1 + 0x78);
        if ((local_98 == 0) || (local_98 != *plVar9)) {
          _invalid_parameter_noinfo();
        }
        if (local_90 != lVar6) {
          plVar10 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,2);
          (**(code **)(*plVar10 + 0x40))(plVar10);
          log_InlineLogERROR("CAchievementSet::Create(). Position[%u] is repeat");
        }
        plVar10 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
        local_78[0] = (**(code **)(*plVar10 + 0x40))(plVar10);
        local_70 = plVar7;
        FUN_14002d3d0(plVar8,local_40,local_78);
        plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,2);
        local_58[0] = (**(code **)(*plVar8 + 0x40))(plVar8);
        local_50 = plVar7;
        FUN_14002d3d0(plVar9,local_40,local_58);
        local_res10 = local_res10 + 1;
        iVar3 = (**(code **)(*plVar5 + 0x40))(plVar5);
      } while (local_res10 < iVar3);
    }
    (**(code **)*plVar5)(plVar5);
    uVar11 = 1;
  }
  return uVar11;
}

// ==== CAchievementSet::ctor_or_dtor  @1403764f0  [high:vtable-assign]  (orig: FUN_1403764f0)
void FUN_1403764f0(undefined8 *param_1)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong local_58;
  undefined8 *puStack_50;
  longlong local_48;
  undefined8 *puStack_40;
  undefined1 local_38 [16];
  
  uVar8 = 0xfffffffffffffffe;
  *param_1 = CAchievementSet::vftable;
  plVar1 = param_1 + 1;
  plVar3 = (longlong *)*plVar1;
  plVar4 = *(longlong **)param_1[7];
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar4;
          plVar4 = (longlong *)param_1[7];
          if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
            _invalid_parameter_noinfo();
          }
          if (plVar6 == plVar4) {
            cVar2 = *(char *)((longlong)*(longlong **)(param_1[7] + 8) + 0x29);
            plVar3 = *(longlong **)(param_1[7] + 8);
            while (cVar2 == '\0') {
              FUN_14002ca30(plVar1,plVar3[2]);
              plVar4 = (longlong *)*plVar3;
              operator_delete(plVar3);
              plVar3 = plVar4;
              cVar2 = *(char *)((longlong)plVar4 + 0x29);
            }
            *(undefined8 *)(param_1[7] + 8) = param_1[7];
            param_1[8] = 0;
            *(undefined8 *)param_1[7] = param_1[7];
            *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
            plVar3 = param_1 + 9;
            cVar2 = *(char *)((longlong)*(longlong **)(param_1[0xf] + 8) + 0x29);
            plVar4 = *(longlong **)(param_1[0xf] + 8);
            while (cVar2 == '\0') {
              FUN_14002ca30(plVar3,plVar4[2]);
              plVar6 = (longlong *)*plVar4;
              operator_delete(plVar4);
              plVar4 = plVar6;
              cVar2 = *(char *)((longlong)plVar6 + 0x29);
            }
            *(undefined8 *)(param_1[0xf] + 8) = param_1[0xf];
            param_1[0x10] = 0;
            *(undefined8 *)param_1[0xf] = param_1[0xf];
            *(undefined8 *)(param_1[0xf] + 0x10) = param_1[0xf];
            puStack_50 = (undefined8 *)param_1[0xf];
            local_58 = *plVar3;
            puStack_40 = (undefined8 *)*puStack_50;
            local_48 = local_58;
            FUN_14002da30(plVar3,local_38,&local_48,&local_58,uVar8);
            operator_delete((void *)param_1[0xf]);
            param_1[0xf] = 0;
            param_1[0x10] = 0;
            operator_delete((void *)*plVar3);
            puStack_40 = (undefined8 *)param_1[7];
            local_58 = *plVar1;
            puStack_50 = (undefined8 *)*puStack_40;
            local_48 = local_58;
            FUN_14002da30(plVar1,local_38,&local_58,&local_48);
            operator_delete((void *)param_1[7]);
            param_1[7] = 0;
            param_1[8] = 0;
            operator_delete((void *)*plVar1);
            return;
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar3;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          (*(code *)**(undefined8 **)plVar6[4])((undefined8 *)plVar6[4],1);
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar4 = plVar6;
        }
        plVar4 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
        cVar2 = *(char *)(*plVar4 + 0x29);
        plVar6 = (longlong *)*plVar4;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*plVar6 + 0x29);
          plVar4 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar4 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar4 + 0x29) != '\0');
    do {
      plVar5 = plVar4;
      plVar4 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar4 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar4 + 0x29) == '\0');
  } while( true );
}

// ==== CAchievementSet::vfunc_0  @140376780  [high:rtti-vtable]  (orig: FUN_140376780)
void * FUN_140376780(void *param_1,uint param_2)

{
  FUN_1403764f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CAchievementSet::ctor_or_dtor  @1403767b0  [high:vtable-assign]  (orig: FUN_1403767b0)
undefined8 * FUN_1403767b0(undefined8 *param_1)

{
  *param_1 = CAchievementSet::vftable;
  FUN_14002e1c0(param_1 + 1);
  FUN_14002e1c0(param_1 + 9);
  return param_1;
}

