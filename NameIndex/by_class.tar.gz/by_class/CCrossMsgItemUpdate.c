// ==== CCrossMsgItemUpdate::ctor_or_dtor  @140370ec0  [high:vtable-assign]  (orig: FUN_140370ec0)
undefined8 * FUN_140370ec0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgItemUpdate::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgItemUpdate::ctor_or_dtor  @140370f10  [high:vtable-assign]  (orig: FUN_140370f10)
void FUN_140370f10(undefined8 *param_1)

{
  *param_1 = CCrossMsgItemUpdate::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgItemUpdate::vfunc_1  @140370f40  [high:rtti-vtable]  (orig: FUN_140370f40)
undefined8 FUN_140370f40(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgItemUpdate::ctor_or_dtor  @1403710f0  [high:vtable-assign]  (orig: FUN_1403710f0)
undefined8 * FUN_1403710f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgItemUpdate::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgItemUpdate::vfunc_3  @140371140  [high:rtti-vtable]  (orig: FUN_140371140)
void FUN_140371140(longlong param_1)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  int iVar8;
  
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar4 = (longlong *)FUN_140087650(uVar3);
  lVar5 = (**(code **)(*plVar4 + 0x98))(plVar4,**(undefined4 **)(param_1 + 0x428));
  if ((lVar5 != 0) && (*(char *)(lVar5 + 0x12c8) != '\0')) {
    for (iVar8 = 0; iVar8 < (int)(uint)*(ushort *)(*(longlong *)(param_1 + 0x428) + 4);
        iVar8 = iVar8 + 1) {
      lVar6 = (longlong)iVar8;
      if (*(int *)(*(longlong *)(param_1 + 0x428) + 8 + lVar6 * 0x28) == 0) {
        log_InlineLogERROR("CCrossMsgItemUpdate::Process idGSItem is null, user id:%u.");
      }
      else {
        plVar4 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar4 = (longlong *)0x0;
        }
        plVar4 = (longlong *)
                 (**(code **)(*plVar4 + 0x60))
                           (plVar4,*(undefined4 *)
                                    (*(longlong *)(param_1 + 0x428) + 8 + lVar6 * 0x28));
        if (plVar4 == (longlong *)0x0) {
          FUN_140168a20(lVar5);
          log_InlineLogERROR(
                            "CCrossMsgItemUpdate::Process Invalid item_id[%lu], item_type[%d], user_id[%lu] enter_serverid[%lu]."
                            );
        }
        else {
          lVar7 = FUN_1400fdb80(plVar4,0x18,1);
          FUN_140104140(plVar4,4,*(undefined4 *)
                                  (*(longlong *)(param_1 + 0x428) + 0x10 + lVar6 * 0x28));
          FUN_140104140(plVar4,7,*(undefined4 *)
                                  (*(longlong *)(param_1 + 0x428) + 0x14 + lVar6 * 0x28));
          FUN_140104140(plVar4,0xd,
                        *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18 + lVar6 * 0x28));
          FUN_140104140(plVar4,0x19,
                        *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c + lVar6 * 0x28));
          FUN_140106830(plVar4,0x18,
                        *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0x28 + lVar6 * 0x28));
          FUN_140104140(plVar4,0x1a,
                        *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x20 + lVar6 * 0x28));
          if (*(int *)(*(longlong *)(param_1 + 0x428) + 0x20 + lVar6 * 0x28) < 1) {
            FUN_1400fda10(plVar4,1,1);
            (**(code **)(*plVar4 + 8))(plVar4);
            log_InlineLogERROR(
                              "CCrossMsgItemUpdate::Process CROSS_OPT_ITEM_UPDATE. Item[%u] Type[%d] AccumulateNum[%d] at %s, %d"
                              );
          }
          plVar1 = DAT_140975b60;
          if ((lVar7 == 0) &&
             (*(longlong *)(*(longlong *)(param_1 + 0x428) + 0x28 + lVar6 * 0x28) != 0)) {
            if (DAT_140975b60 == (longlong *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            lVar6 = *plVar1;
            uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
            (**(code **)(lVar6 + 0x158))(plVar1,uVar2);
          }
        }
      }
    }
  }
  return;
}

