// ==== CMsgAuctionItem::helper_1402289d0  @1402289d0  [medium:callgraph-r0]  (orig: FUN_1402289d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_1402289d0(longlong param_1,longlong *param_2,undefined2 param_3,undefined2 param_4,
                  undefined4 *param_5)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 auStack_98 [32];
  undefined4 local_78;
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined1 uStack_4c;
  undefined1 local_4b;
  undefined1 local_4a;
  undefined1 local_49;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_98;
  if (param_2 != (longlong *)0x0) {
    local_44 = CONCAT22(local_44._2_2_,0x8c);
    uStack_58 = 0;
    uStack_54 = 0;
    uStack_50 = 0;
    uStack_4c = 0;
    local_68 = 0;
    local_64 = 0;
    local_60 = 0;
    local_5c = 0;
    local_4b = 0;
    local_4a = 0;
    local_49 = 0;
    local_48 = 0;
    local_40 = 0;
    local_68 = (**(code **)(*param_2 + 8))(param_2);
    local_5c = *param_5;
    local_64 = CONCAT22(param_4,param_3);
    uStack_58 = param_5[1];
    uStack_54 = param_5[2];
    uStack_50 = param_5[3];
    uVar1 = param_5[4];
    uStack_4c = (undefined1)uVar1;
    local_4b = (undefined1)((uint)uVar1 >> 8);
    local_4a = (undefined1)((uint)uVar1 >> 0x10);
    local_49 = (undefined1)((uint)uVar1 >> 0x18);
    local_48 = param_5[5];
    local_44 = param_5[6];
    local_40 = param_5[7];
    local_60 = 0;
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    FUN_14008aba0(uVar2,0x1637b,&local_68);
  }
  else {
    local_78 = 0x57e;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return param_2 != (longlong *)0x0;
}

// ==== CMsgAuctionItem::ctor_or_dtor  @14041f890  [high:vtable-assign]  (orig: FUN_14041f890)
undefined8 * FUN_14041f890(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgAuctionItem::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgAuctionItem::ctor_or_dtor  @14041f8e0  [high:vtable-assign]  (orig: FUN_14041f8e0)
void FUN_14041f8e0(undefined8 *param_1)

{
  *param_1 = CMsgAuctionItem::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgAuctionItem::vfunc_1  @14041f910  [high:rtti-vtable]  (orig: FUN_14041f910)
ulonglong FUN_14041f910(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x529);
}

// ==== CMsgAuctionItem::ctor_or_dtor  @14041fa40  [high:vtable-assign]  (orig: FUN_14041fa40)
undefined8 * FUN_14041fa40(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAuctionItem::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAuctionItem::vfunc_3  @14041fa90  [high:rtti-vtable]  (orig: FUN_14041fa90)
void FUN_14041fa90(longlong param_1,longlong param_2)

{
  longlong lVar1;
  undefined4 *puVar2;
  longlong lVar3;
  char cVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  cVar4 = FUN_14008a710(uVar6);
  if ((cVar4 == '\0') && (param_2 != 0)) {
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar7 = (longlong *)FUN_140087650(uVar6);
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x88))(plVar7,param_1);
    if (plVar7 != (longlong *)0x0) {
      plVar8 = (longlong *)FUN_1400e1e60();
      lVar3 = plVar7[0x1e2];
      lVar1 = *plVar8;
      puVar2 = *(undefined4 **)(param_1 + 0x428);
      uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
      (**(code **)(lVar1 + 0x108))(plVar8,uVar5,(int)lVar3,*puVar2);
      lVar1 = *(longlong *)(param_1 + 0x428);
      if (*(short *)(lVar1 + 4) == 0) {
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087a10(uVar6);
        cVar4 = FUN_1402289d0(uVar6,plVar7,*(undefined2 *)(lVar1 + 0x28),
                              *(undefined2 *)(lVar1 + 0x2e),lVar1 + 8);
        if (cVar4 == '\0') {
          *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x2a) = 0;
          *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x2c) = 0;
          (**(code **)(plVar7[2] + 0x350))(plVar7 + 2,param_1);
        }
      }
    }
  }
  return;
}

