// ==== CCrossClientThread::ctor_or_dtor  @14004c0a0  [high:vtable-assign]  (orig: FUN_14004c0a0)
CThreadBase * FUN_14004c0a0(CThreadBase *param_1,longlong param_2)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CCrossClientThread::vftable;
  *(longlong *)(param_1 + 0x40) = param_2;
  *(undefined8 *)(param_1 + 0x48) = 0;
  param_1[0x50] = (CThreadBase)0x0;
  param_1[0x51] = (CThreadBase)0x0;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pMsgPort",
                       "f:\\version\\cqserver-78.0.11-1204\\crossclient\\crossclientthread.cpp",0x17
                      );
  }
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x38))();
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x40))(*(longlong **)(param_1 + 0x40),0x14);
  *(undefined8 *)(param_1 + 0x52) = 0;
  *(undefined8 *)(param_1 + 0x5a) = 0;
  return param_1;
}

// ==== CCrossClientThread::ctor_or_dtor  @14004c150  [high:vtable-assign]  (orig: FUN_14004c150)
void FUN_14004c150(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CCrossClientThread::vftable;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
                    /* WARNING: Could not recover jumptable at 0x00014004c183. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CCrossClientThread::vfunc_4  @14004c190  [high:rtti-vtable]  (orig: FUN_14004c190)
undefined1 FUN_14004c190(CThreadBase *param_1,bool param_2)

{
  bool bVar1;
  char cVar2;
  longlong lVar3;
  
  bVar1 = CThreadBase::CreateThread(param_1,"CrossClientThread",param_2);
  if (bVar1) {
    lVar3 = FUN_1400548c0();
    *(longlong *)(param_1 + 0x48) = lVar3;
    if (lVar3 != 0) {
      cVar2 = FUN_14004cbe0(lVar3,*(undefined8 *)(param_1 + 0x40),param_1);
      if (cVar2 != '\0') {
        return 1;
      }
    }
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT",
                       "m_pCrossKernel && m_pCrossKernel->Create(m_pMsgPort, this)",
                       "f:\\version\\cqserver-78.0.11-1204\\crossclient\\crossclientthread.cpp",0x2f
                      );
  }
  return 0;
}

// ==== CCrossClientThread::vfunc_2  @14004c210  [high:rtti-vtable]  (orig: FUN_14004c210)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14004c210(longlong param_1)

{
  char cVar1;
  uint uVar2;
  longlong lVar3;
  char *pcVar4;
  undefined1 auStack_858 [32];
  char *local_838;
  undefined8 local_828;
  CIniFile local_818 [1024];
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_828 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_858;
  CIniFile::CIniFile(local_818,"shell.ini","AccountServer");
  CIniFile::GetString(local_818,(char *)(param_1 + 0x52),"SERVERNAME",0x10);
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x40) + 8))();
  _snprintf(local_418,0x3ff,"#%u: CrossClientThread running.",(ulonglong)uVar2);
  local_19 = 0;
  lVar3 = -1;
  pcVar4 = local_418;
  do {
    if (lVar3 == 0) break;
    lVar3 = lVar3 + -1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  local_838 = local_418;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
            (*(longlong **)(param_1 + 0x40),0,0x9c41,~(uint)lVar3);
  CIniFile::~CIniFile(local_818);
  return;
}

// ==== CCrossClientThread::vfunc_3  @14004c300  [high:rtti-vtable]  (orig: FUN_14004c300)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14004c300(longlong *param_1)

{
  char cVar1;
  int iVar2;
  short sVar3;
  undefined1 auStack_8e8 [32];
  undefined4 *local_8c8;
  undefined8 *local_8c0;
  undefined8 local_8b8;
  undefined4 local_8b0;
  CTickAnalyst local_8a8 [24];
  CTickAnalyst local_890 [24];
  undefined8 local_878;
  CTickAnalyst local_870 [24];
  undefined2 local_858 [2];
  int local_854;
  undefined4 local_850;
  short local_84c;
  undefined2 local_84a;
  undefined1 local_848 [1040];
  undefined4 local_438;
  undefined2 local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_878 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  local_8b8 = param_1;
  CTickAnalyst::CTickAnalyst(local_8a8,0x48);
  (**(code **)(*(longlong *)param_1[8] + 0x58))((longlong *)param_1[8],0x14);
  CTickAnalyst::~CTickAnalyst(local_8a8);
  CTickAnalyst::CTickAnalyst(local_870,0x2b);
LAB_14004c380:
  do {
    local_8c0 = &local_8b8;
    local_8c8 = &local_438;
    cVar1 = (**(code **)(*(longlong *)param_1[8] + 0x48))
                      ((longlong *)param_1[8],0xffffffff,0xffffffff,0x418);
    if (cVar1 == '\0') {
LAB_14004c570:
      CTickAnalyst::~CTickAnalyst(local_870);
      return 1;
    }
    if (local_8b8._4_4_ != 0x3e9) {
      CTickAnalyst::CTickAnalyst(local_8a8,0x2d);
      if ((char)param_1[10] == '\0') {
        if (local_8b8._4_4_ == 0x3fc) {
          if (local_430 != 0x9c4f) {
            CTickAnalyst::~CTickAnalyst(local_8a8);
            goto LAB_14004c380;
          }
        }
        else if (((local_8b8._4_4_ != 0x3f1) && (local_8b8._4_4_ != 0x11173)) &&
                (local_8b8._4_4_ != 0x11174)) {
          CTickAnalyst::~CTickAnalyst(local_8a8);
          goto LAB_14004c380;
        }
      }
      local_8c8 = (undefined4 *)CONCAT44(local_8c8._4_4_,(undefined4)local_8b8);
      FUN_140054380(param_1[9],local_8b8._4_4_,&local_438,local_8b0);
      CTickAnalyst::~CTickAnalyst(local_8a8);
      goto LAB_14004c380;
    }
    CTickAnalyst::CTickAnalyst(local_890,0x2c);
    if ((char)param_1[10] == '\0') {
      CTickAnalyst::~CTickAnalyst(local_890);
    }
    else {
      cVar1 = FUN_140054160(param_1[9],local_438);
      if (cVar1 == '\0') {
        CTickAnalyst::~CTickAnalyst(local_890);
      }
      else {
        iVar2 = FUN_140052920(param_1[9],local_438);
        if (iVar2 == 0) {
          CTickAnalyst::~CTickAnalyst(local_890);
        }
        else {
          if (local_430 + 0x10 < 0x419) {
            local_858[0] = 0;
            local_850 = 0xffffffff;
            local_84a = local_434;
            local_84c = (short)(local_430 + 0x10);
            local_854 = iVar2;
            memcpy(local_848,local_42c,(longlong)local_430);
            sVar3 = local_84c;
          }
          else {
            sVar3 = 0;
          }
          if ((sVar3 != 0) &&
             (cVar1 = (**(code **)(*param_1 + 0x28))(param_1,local_858), cVar1 == '\0')) {
            CTickAnalyst::~CTickAnalyst(local_890);
            goto LAB_14004c570;
          }
          CTickAnalyst::~CTickAnalyst(local_890);
        }
      }
    }
  } while( true );
}

// ==== CCrossClientThread::vfunc_5  @14004c5b0  [high:rtti-vtable]  (orig: FUN_14004c5b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14004c5b0(longlong param_1,void *param_2,int param_3)

{
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined1 local_444 [1052];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  memset((void *)((longlong)&local_448 + 1),0,0x417);
  local_448 = param_3;
  memcpy(local_444,param_2,(longlong)param_3);
  local_458 = &local_448;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
            (*(longlong **)(param_1 + 0x40),1,0x7573,0x418);
  return;
}

// ==== CCrossClientThread::ctor_or_dtor  @14004c770  [high:vtable-assign]  (orig: FUN_14004c770)
CThreadBase * FUN_14004c770(CThreadBase *param_1,uint param_2)

{
  *(undefined ***)param_1 = CCrossClientThread::vftable;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
  CThreadBase::~CThreadBase(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossClientThread::vfunc_1  @14004c830  [high:rtti-vtable]  (orig: FUN_14004c830)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14004c830(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_458 [32];
  char *local_438;
  undefined8 local_428;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_428 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  pcVar3 = (char *)(param_1 + 0x50);
  if ((*pcVar3 != '\0') || (*(char *)(param_1 + 0x51) == '\0')) {
    *pcVar3 = '\0';
    local_438 = pcVar3;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0xe,0x2737,1);
    local_418[0] = '\0';
    memset(local_418 + 1,0,0x3ff);
    _snprintf(local_418,0x3ff,"Intermediary server connection broken.");
    local_19 = 0;
    lVar2 = -1;
    pcVar3 = local_418;
    do {
      if (lVar2 == 0) break;
      lVar2 = lVar2 + -1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    local_438 = local_418;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0,0x9c41,~(uint)lVar2);
    *(undefined1 *)(param_1 + 0x51) = 1;
  }
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
  if (*(longlong *)(param_1 + 0x48) != 0) {
    FUN_14004cc60(*(undefined8 *)(param_1 + 0x48));
    *(undefined8 *)(param_1 + 0x48) = 0;
  }
  return;
}

// ==== CCrossClientThread::helper_14004cbe0  @14004cbe0  [medium:callgraph-r0]  (orig: FUN_14004cbe0)
undefined1 FUN_14004cbe0(longlong param_1,longlong param_2,longlong param_3)

{
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  *(longlong *)(param_1 + 8) = param_2;
  *(longlong *)(param_1 + 0x10) = param_3;
  return 1;
}

// ==== CCrossClientThread::helper_14004cc60  @14004cc60  [medium:callgraph-r0]  (orig: FUN_14004cc60)
undefined8 FUN_14004cc60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return 1;
}

// ==== CCrossClientThread::helper_140052920  @140052920  [medium:callgraph-r0]  (orig: FUN_140052920)
undefined4 FUN_140052920(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x48))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x48);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x48);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x18);
  if (*(longlong *)(param_1 + 0x18) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x48);
    local_28 = *(longlong *)(param_1 + 0x18);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x48);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CCrossClientThread::helper_140054160  @140054160  [medium:callgraph-r0]  (orig: FUN_140054160)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140054160(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  ulong uVar5;
  int iVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined1 auStack_4c8 [32];
  uint *local_4a8;
  uint local_498 [4];
  longlong *local_488;
  longlong local_480;
  longlong local_478;
  undefined8 local_470;
  longlong local_468;
  undefined8 *local_460;
  undefined4 local_458;
  undefined4 local_454;
  uint local_450;
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 200))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x25);
  puVar3 = *(undefined8 **)(param_1 + 200);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar7 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x25);
  }
  puVar8 = *(undefined8 **)(param_1 + 200);
  local_460 = puVar3;
  local_468 = *(longlong *)(param_1 + 0x98);
  local_498[0] = param_2;
  if (*(longlong *)(param_1 + 0x98) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (local_498[0] < *(uint *)(puVar3 + 3))) {
    plVar9 = &local_478;
    local_470 = *(undefined8 *)(param_1 + 200);
    local_478 = *(longlong *)(param_1 + 0x98);
  }
  else {
    plVar9 = &local_468;
  }
  plVar2 = (longlong *)*plVar9;
  lVar10 = *(longlong *)(param_1 + 200);
  local_480 = plVar9[1];
  local_488 = plVar2;
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x98))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_480;
  if (local_480 != lVar10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = tq::TimeGet(0);
    if (uVar5 / 1000 < (uint)(*(int *)(lVar4 + 0x20) + *(int *)(lVar4 + 0x1c))) {
      return 0;
    }
    local_488 = (longlong *)*plVar9;
    local_480 = plVar9[1];
    FUN_140051480(param_1 + 0x98,&local_478,&local_488);
    iVar6 = FUN_140052920(param_1,local_498[0]);
    if (iVar6 != 0) {
      FUN_140054040(param_1);
      memset((void *)((longlong)&local_458 + 1),0,0x417);
      local_4a8 = &local_458;
      local_450 = local_498[0];
      local_458 = 0;
      local_454 = 1;
      (**(code **)(**(longlong **)(param_1 + 8) + 0x50))
                (*(longlong **)(param_1 + 8),0xe,0x2735,0x418);
    }
    local_4a8 = local_498;
    (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),0xe,0x2744,4);
  }
  return 1;
}

