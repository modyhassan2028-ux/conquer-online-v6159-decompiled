// ==== CMsgDeathMarked::ctor_or_dtor  @1404201a0  [high:vtable-assign]  (orig: FUN_1404201a0)
undefined8 * FUN_1404201a0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgDeathMarked::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgDeathMarked::ctor_or_dtor  @1404201f0  [high:vtable-assign]  (orig: FUN_1404201f0)
void FUN_1404201f0(undefined8 *param_1)

{
  *param_1 = CMsgDeathMarked::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgDeathMarked::vfunc_1  @140420220  [high:rtti-vtable]  (orig: FUN_140420220)
ulonglong FUN_140420220(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x821);
}

// ==== CMsgDeathMarked::ctor_or_dtor  @1404202b0  [high:vtable-assign]  (orig: FUN_1404202b0)
undefined8 * FUN_1404202b0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgDeathMarked::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

