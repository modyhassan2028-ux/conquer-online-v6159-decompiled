// ==== CTaskDetail::helper_1403b9560  @1403b9560  [medium:callgraph-r0]  (orig: FUN_1403b9560)
void FUN_1403b9560(void *param_1)

{
  if ((DAT_140976280 & 1) == 0) {
    DAT_140976280 = DAT_140976280 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976278,"CTaskDetail");
    atexit((_func_5014 *)&LAB_1406d6c50);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403b95b5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976278,param_1);
  return;
}

// ==== CTaskDetail::ctor_or_dtor  @1403b9620  [high:vtable-assign]  (orig: FUN_1403b9620)
undefined8 * FUN_1403b9620(undefined8 *param_1,byte param_2)

{
  *param_1 = CTaskDetail::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1403b9560();
  }
  return param_1;
}

// ==== CTaskDetail::ctor_or_dtor  @1403b9650  [high:vtable-assign]  (orig: FUN_1403b9650)
undefined8 * FUN_1403b9650(undefined4 param_1)

{
  undefined8 *puVar1;
  
  if ((DAT_140976280 & 1) == 0) {
    DAT_140976280 = DAT_140976280 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976278,"CTaskDetail");
    atexit((_func_5014 *)&LAB_1406d6c50);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976278,0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CTaskDetail::vftable;
    *(undefined4 *)(puVar1 + 2) = param_1;
    *(undefined1 *)((longlong)puVar1 + 0x14) = 0;
    puVar1[1] = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pTaskDetail",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usertaskdetail.cpp"
                       ,0x38);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

