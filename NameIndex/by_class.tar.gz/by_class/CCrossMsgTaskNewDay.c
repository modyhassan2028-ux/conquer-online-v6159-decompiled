// ==== CCrossMsgTaskNewDay::ctor_or_dtor  @14044f0b0  [high:vtable-assign]  (orig: FUN_14044f0b0)
undefined8 * FUN_14044f0b0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgTaskNewDay::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgTaskNewDay::ctor_or_dtor  @14044f100  [high:vtable-assign]  (orig: FUN_14044f100)
void FUN_14044f100(undefined8 *param_1)

{
  *param_1 = CCrossMsgTaskNewDay::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgTaskNewDay::vfunc_1  @14044f130  [high:rtti-vtable]  (orig: FUN_14044f130)
ulonglong FUN_14044f130(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c6e);
}

// ==== CCrossMsgTaskNewDay::vfunc_5  @14044f160  [high:rtti-vtable]  (orig: FUN_14044f160)
undefined8 FUN_14044f160(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 8;
  *(undefined4 *)(param_1 + 8) = 0x9c6e;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 4) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CCrossMsgTaskNewDay::ctor_or_dtor  @14044f1b0  [high:vtable-assign]  (orig: FUN_14044f1b0)
undefined8 * FUN_14044f1b0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgTaskNewDay::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgTaskNewDay::vfunc_3  @14044f200  [high:rtti-vtable]  (orig: FUN_14044f200)
void FUN_14044f200(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x00014044f270. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x80))
            (*(longlong **)(lVar1 + 0x90),**(undefined4 **)(param_1 + 0x428),
             (*(undefined4 **)(param_1 + 0x428))[1]);
  return;
}

