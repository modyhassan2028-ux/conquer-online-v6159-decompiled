// ==== CModMsgLogout::ctor_or_dtor  @14035cfb0  [high:vtable-assign]  (orig: FUN_14035cfb0)
CMsg * FUN_14035cfb0(CMsg *param_1)

{
  *(undefined ***)param_1 = tq::CMsg::vftable;
  tq::CMsg::Init(param_1);
  *(undefined ***)param_1 = gs::CMsg::vftable;
  *(undefined ***)param_1 = CModMsgLogout::vftable;
  tq::CMsg::Init(param_1);
  *(CMsg **)(param_1 + 0x408) = param_1 + 8;
  return param_1;
}

// ==== CModMsgLogout::ctor_or_dtor  @14035d010  [high:vtable-assign]  (orig: FUN_14035d010)
void FUN_14035d010(undefined8 *param_1)

{
  *param_1 = CModMsgLogout::vftable;
  *param_1 = gs::CMsg::vftable;
  *param_1 = tq::CMsg::vftable;
  return;
}

// ==== CModMsgLogout::vfunc_6  @14035d090  [high:rtti-vtable]  (orig: FUN_14035d090)
bool FUN_14035d090(CMsg *param_1,char *param_2,ushort param_3)

{
  bool bVar1;
  
  bVar1 = tq::CMsg::Create(param_1,param_2,param_3);
  if (!bVar1) {
    return bVar1;
  }
  return *(short *)(param_1 + 10) == 0x3ea;
}

// ==== CModMsgLogout::ctor_or_dtor  @14035d0c0  [high:vtable-assign]  (orig: FUN_14035d0c0)
undefined8 * FUN_14035d0c0(undefined8 *param_1,byte param_2)

{
  *param_1 = CModMsgLogout::vftable;
  *param_1 = gs::CMsg::vftable;
  *param_1 = tq::CMsg::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

