// ==== CSlotWinningRule::ctor_or_dtor  @1404242b0  [high:vtable-assign]  (orig: FUN_1404242b0)
void FUN_1404242b0(undefined8 *param_1)

{
  *param_1 = CSlotWinningRule::vftable;
  FUN_1401e0500(param_1 + 10);
  operator_delete((void *)param_1[10]);
  FUN_1403f70e0(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CSlotWinningRule::ctor_or_dtor  @140424320  [high:vtable-assign]  (orig: FUN_140424320)
undefined8 * FUN_140424320(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CSlotWinningRule::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_1403f7250(param_1 + 2);
  FUN_1401eb7e0(param_1 + 10);
  return param_1;
}

// ==== CSlotWinningRule::ctor_or_dtor  @140424360  [high:vtable-assign]  (orig: FUN_140424360)
undefined8 * FUN_140424360(undefined8 *param_1,uint param_2)

{
  *param_1 = CSlotWinningRule::vftable;
  FUN_1401e0500(param_1 + 10);
  operator_delete((void *)param_1[10]);
  FUN_1403f70e0(param_1 + 2);
  operator_delete((void *)param_1[2]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CSlotWinningRule::ctor_or_dtor  @1404243f0  [high:vtable-assign]  (orig: FUN_1404243f0)
undefined8 * FUN_1404243f0(undefined4 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x90);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CSlotWinningRule::vftable;
    *(undefined4 *)(puVar1 + 1) = param_1;
    FUN_1403f7250(puVar1 + 2);
    FUN_1401eb7e0(puVar1 + 10);
  }
  return puVar1;
}

