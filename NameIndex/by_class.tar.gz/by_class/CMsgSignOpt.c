// ==== CMsgSignOpt::helper_140006e20  @140006e20  [medium:callgraph-r1]  (orig: FUN_140006e20)
undefined4 FUN_140006e20(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x234);
}

// ==== CMsgSignOpt::helper_140006e30  @140006e30  [medium:callgraph-r2]  (orig: FUN_140006e30)
undefined4 FUN_140006e30(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x238);
}

// ==== CMsgSignOpt::helper_140006e40  @140006e40  [medium:callgraph-r1]  (orig: FUN_140006e40)
undefined4 FUN_140006e40(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x23c);
}

// ==== CMsgSignOpt::helper_140006e50  @140006e50  [medium:callgraph-r1]  (orig: FUN_140006e50)
undefined4 FUN_140006e50(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x240);
}

// ==== CMsgSignOpt::helper_140006e60  @140006e60  [medium:callgraph-r1]  (orig: FUN_140006e60)
undefined4 FUN_140006e60(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x244);
}

// ==== CMsgSignOpt::helper_140006e70  @140006e70  [medium:callgraph-r1]  (orig: FUN_140006e70)
undefined4 FUN_140006e70(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x248);
}

// ==== CMsgSignOpt::helper_140006e80  @140006e80  [medium:callgraph-r1]  (orig: FUN_140006e80)
undefined4 FUN_140006e80(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x24c);
}

// ==== CMsgSignOpt::helper_140006e90  @140006e90  [medium:callgraph-r1]  (orig: FUN_140006e90)
undefined4 FUN_140006e90(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x250);
}

// ==== CMsgSignOpt::helper_140006ea0  @140006ea0  [medium:callgraph-r1]  (orig: FUN_140006ea0)
undefined4 FUN_140006ea0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x254);
}

// ==== CMsgSignOpt::helper_140006eb0  @140006eb0  [medium:callgraph-r1]  (orig: FUN_140006eb0)
undefined4 FUN_140006eb0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 600);
}

// ==== CMsgSignOpt::helper_140006ec0  @140006ec0  [medium:callgraph-r1]  (orig: FUN_140006ec0)
undefined4 FUN_140006ec0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x25c);
}

// ==== CMsgSignOpt::helper_140006ed0  @140006ed0  [medium:callgraph-r1]  (orig: FUN_140006ed0)
undefined4 FUN_140006ed0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x260);
}

// ==== CMsgSignOpt::helper_140208780  @140208780  [medium:callgraph-r1]  (orig: FUN_140208780)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140208780(undefined8 param_1,longlong param_2,undefined1 param_3,undefined4 param_4)

{
  char cVar1;
  undefined1 auStack_488 [32];
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  if (param_2 != 0) {
    local_468 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_488;
    FUN_140413680(local_458);
    cVar1 = FUN_140413740(local_458,3,param_3,param_4);
    if (cVar1 != '\0') {
      (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_458);
    }
    FUN_1404136d0(local_458);
  }
  return;
}

// ==== CMsgSignOpt::helper_140208820  @140208820  [medium:callgraph-r1]  (orig: FUN_140208820)
bool FUN_140208820(undefined4 *param_1,longlong param_2)

{
  int iVar1;
  undefined8 uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  longlong lVar7;
  IStringManager *pIVar8;
  
  if (param_2 == 0) {
    return false;
  }
  iVar4 = FUN_140371860(param_2 + 0xe78);
  iVar1 = *(int *)(param_2 + 0xfa4);
  lVar7 = FUN_140008520(*param_1);
  if (*(longlong *)(lVar7 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar5 = FUN_140006e30(*(undefined8 *)(lVar7 + 0xb0));
  if ((uint)(iVar1 + iVar4) < uVar5) {
    pIVar8 = theInstance();
    lVar7 = *(longlong *)(param_2 + 0x10);
    uVar2 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_FILL_SIGN_EMONEY_NOT_ENOUGH");
    (**(code **)(lVar7 + 0x358))(param_2 + 0x10,uVar2);
    return false;
  }
  uVar2 = FUN_140008520(*param_1);
  uVar2 = FUN_1400d6610(uVar2);
  uVar6 = FUN_140006e30(uVar2);
  cVar3 = FUN_14017bda0(param_2,uVar6,0x4e,3,0x15e,0x10e2,0x15e,0x10e3);
  return cVar3 != '\0';
}

// ==== CMsgSignOpt::helper_140208960  @140208960  [medium:callgraph-r1]  (orig: FUN_140208960)
longlong * FUN_140208960(undefined8 param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  if (param_2 == 0) {
    plVar2 = (longlong *)0x0;
  }
  else {
    plVar2 = (longlong *)InstanceGet();
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,"cq_sign_everyday");
    if (plVar2 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar2 = (longlong *)0x0;
    }
    else {
      plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,0);
      (**(code **)(*plVar3 + 0xb8))(plVar3,param_2);
      plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,1);
      (**(code **)(*plVar3 + 0xb0))(plVar3,0);
      plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,2);
      (**(code **)(*plVar3 + 0xa8))(plVar3,param_3);
      cVar1 = (**(code **)(*plVar2 + 0x50))(plVar2,1);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CSignMgr::CSignMgr::CreateNewSignRec, user:%lu");
        (**(code **)*plVar2)(plVar2,1);
        plVar2 = (longlong *)0x0;
      }
    }
  }
  return plVar2;
}

// ==== CMsgSignOpt::helper_140209210  @140209210  [medium:callgraph-r0]  (orig: FUN_140209210)
void FUN_140209210(undefined4 *param_1,longlong *param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  char cVar3;
  undefined1 uVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  uint uVar12;
  undefined8 *puVar13;
  longlong lVar14;
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_30;
  longlong *local_28;
  
  if (param_2 != (longlong *)0x0) {
    uVar8 = FUN_140008520(*param_1);
    cVar3 = FUN_14008ac00(uVar8);
    if (cVar3 != '\0') {
      uVar5 = (**(code **)(*param_2 + 8))(param_2);
      puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0xe))[1];
      cVar3 = *(char *)((longlong)puVar13 + 0x29);
      puVar2 = *(undefined8 **)(param_1 + 0xe);
      while (cVar3 == '\0') {
        if (*(uint *)(puVar13 + 3) < uVar5) {
          puVar11 = (undefined8 *)puVar13[2];
          puVar13 = puVar2;
        }
        else {
          puVar11 = (undefined8 *)*puVar13;
        }
        puVar2 = puVar13;
        puVar13 = puVar11;
        cVar3 = *(char *)((longlong)puVar11 + 0x29);
      }
      puVar13 = *(undefined8 **)(param_1 + 0xe);
      local_50 = puVar2;
      local_58 = *(longlong *)(param_1 + 2);
      if (*(longlong *)(param_1 + 2) == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar2 == puVar13) || (uVar5 < *(uint *)(puVar2 + 3))) {
        plVar9 = &local_48;
        local_40 = *(undefined8 *)(param_1 + 0xe);
        local_48 = *(longlong *)(param_1 + 2);
      }
      else {
        plVar9 = &local_58;
      }
      plVar10 = (longlong *)*plVar9;
      plVar1 = *(longlong **)(param_1 + 0xe);
      local_28 = (longlong *)plVar9[1];
      local_30 = plVar10;
      if ((plVar10 == (longlong *)0x0) || (plVar10 != *(longlong **)(param_1 + 2))) {
        _invalid_parameter_noinfo();
      }
      plVar9 = local_28;
      if (local_28 == plVar1) {
        iVar6 = tq::DateStamp(0);
        uVar7 = (**(code **)(*param_2 + 8))(param_2);
        plVar9 = (longlong *)
                 FUN_140208960(param_1,uVar7,
                               1 << (((char)iVar6 + (char)(iVar6 / 100) * -100) - 1U & 0x1f));
        if (plVar9 == (longlong *)0x0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("CSignMgr::Sign, CreateNewSignPlayer faild, idUser[%lu]!");
          return;
        }
        uVar7 = (**(code **)(*param_2 + 8))(param_2);
        local_30 = (longlong *)CONCAT44(local_30._4_4_,uVar7);
        local_28 = plVar9;
        FUN_14002d3d0(param_1 + 2,&local_48,&local_30);
        uVar8 = FUN_140008520(*param_1);
        uVar8 = FUN_1400d6610(uVar8);
        uVar7 = FUN_140006e20(uVar8);
        uVar8 = FUN_140008520(*param_1);
        uVar8 = FUN_140087730(uVar8);
        FUN_140145f60(uVar8,uVar7,param_2,0,0,0);
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
        lVar14 = *plVar9;
      }
      else {
        lVar14 = 0;
        if (plVar10 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar14 = *plVar10;
        }
        if (plVar9 == *(longlong **)(lVar14 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar9 = (longlong *)plVar9[4];
        if (plVar9 == (longlong *)0x0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("CSignMgr::Sign, pRec is NULL, user id[%lu].");
          return;
        }
        iVar6 = tq::DateStamp(0);
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
        uVar5 = (**(code **)(*plVar10 + 0x50))(plVar10);
        uVar12 = 1 << (((char)iVar6 +
                       (((char)(iVar6 / 100) + (char)(iVar6 >> 0x1f)) -
                       (char)((longlong)iVar6 * 0x51eb851f >> 0x3f)) * -100) - 1U & 0x1f);
        if ((uVar5 & uVar12) != 0) {
          return;
        }
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
        (**(code **)(*plVar10 + 0xa8))(plVar10,uVar12 | uVar5);
        (**(code **)(*plVar9 + 0x38))(plVar9,0);
        uVar8 = FUN_140008520(*param_1);
        uVar8 = FUN_1400d6610(uVar8);
        uVar7 = FUN_140006e20(uVar8);
        uVar8 = FUN_140008520(*param_1);
        uVar8 = FUN_140087730(uVar8);
        FUN_140145f60(uVar8,uVar7,param_2,0,0,0);
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
        lVar14 = *plVar9;
      }
      plVar9 = (longlong *)(**(code **)(lVar14 + 0x10))(plVar9,1);
      uVar7 = (**(code **)(*plVar10 + 0x50))(plVar10);
      uVar4 = (**(code **)(*plVar9 + 0x20))(plVar9);
      FUN_140208780(param_1,param_2,uVar4,uVar7);
    }
  }
  return;
}

// ==== CMsgSignOpt::helper_140209580  @140209580  [medium:callgraph-r0]  (orig: FUN_140209580)
void FUN_140209580(undefined4 *param_1,longlong *param_2,uint param_3)

{
  longlong *plVar1;
  char cVar2;
  undefined1 uVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  uint uVar10;
  longlong lVar11;
  undefined4 local_res10 [2];
  undefined4 local_58;
  undefined4 uStack_54;
  longlong *local_50;
  undefined1 local_48 [32];
  
  if (param_2 != (longlong *)0x0) {
    uVar7 = FUN_140008520(*param_1);
    cVar2 = FUN_14008ac00(uVar7);
    if ((cVar2 != '\0') && (iVar4 = tq::DateStamp(0), param_3 < (uint)(iVar4 % 100))) {
      local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
      FUN_14002d940(param_1 + 2,&local_58,local_res10);
      plVar9 = (longlong *)CONCAT44(uStack_54,local_58);
      plVar8 = *(longlong **)(param_1 + 0xe);
      if ((plVar9 == (longlong *)0x0) || (plVar9 != *(longlong **)(param_1 + 2))) {
        _invalid_parameter_noinfo();
      }
      plVar1 = local_50;
      if (local_50 == plVar8) {
        cVar2 = FUN_140208820(param_1,param_2);
        if (cVar2 == '\0') {
          return;
        }
        uVar5 = (**(code **)(*param_2 + 8))(param_2);
        plVar8 = (longlong *)FUN_140208960(param_1,uVar5,1 << ((char)param_3 - 1U & 0x1f));
        if (plVar8 == (longlong *)0x0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("CSignMgr::FillSign, CreateNewSignPlayer faild, idUser[%lu]!");
          return;
        }
        local_58 = (**(code **)(*param_2 + 8))(param_2);
        local_50 = plVar8;
        FUN_14002d3d0(param_1 + 2,local_48,&local_58);
        uVar7 = FUN_140008520(*param_1);
        uVar7 = FUN_1400d6610(uVar7);
        uVar5 = FUN_140006e20(uVar7);
        uVar7 = FUN_140008520(*param_1);
        uVar7 = FUN_140087730(uVar7);
      }
      else {
        lVar11 = 0;
        if (plVar9 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar11 = *plVar9;
        }
        if (plVar1 == *(longlong **)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar8 = (longlong *)plVar1[4];
        if (plVar8 == (longlong *)0x0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("CSignMgr::FillSign, player[%lu] is NULL.");
          return;
        }
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,2);
        uVar6 = (**(code **)(*plVar9 + 0x50))(plVar9);
        uVar10 = 1 << ((char)param_3 - 1U & 0x1f);
        if ((uVar6 & uVar10) != 0) {
          return;
        }
        cVar2 = FUN_140208820(param_1,param_2);
        if (cVar2 == '\0') {
          return;
        }
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,2);
        (**(code **)(*plVar9 + 0xa8))(plVar9,uVar10 | uVar6);
        (**(code **)(*plVar8 + 0x38))(plVar8,0);
        uVar7 = FUN_140008520(*param_1);
        uVar7 = FUN_1400d6610(uVar7);
        uVar5 = FUN_140006e20(uVar7);
        uVar7 = FUN_140008520(*param_1);
        uVar7 = FUN_140087730(uVar7);
      }
      FUN_140145f60(uVar7,uVar5,param_2,0,0,0);
      plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,2);
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,1);
      uVar5 = (**(code **)(*plVar9 + 0x50))(plVar9);
      uVar3 = (**(code **)(*plVar8 + 0x20))(plVar8);
      FUN_140208780(param_1,param_2,uVar3,uVar5);
    }
  }
  return;
}

// ==== CMsgSignOpt::helper_140209860  @140209860  [medium:callgraph-r0]  (orig: FUN_140209860)
void FUN_140209860(undefined4 *param_1,longlong *param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  char cVar3;
  byte bVar4;
  undefined1 uVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong *plVar10;
  IStringManager *pIVar11;
  longlong *plVar12;
  uint uVar13;
  undefined8 *puVar14;
  longlong lVar15;
  uint uVar16;
  undefined8 *puVar17;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  if (param_2 != (longlong *)0x0) {
    uVar9 = FUN_140008520(*param_1);
    cVar3 = FUN_14008ac00(uVar9);
    if (cVar3 != '\0') {
      uVar6 = (**(code **)(*param_2 + 8))(param_2);
      puVar17 = (undefined8 *)(*(undefined8 **)(param_1 + 0xe))[1];
      cVar3 = *(char *)((longlong)puVar17 + 0x29);
      puVar1 = *(undefined8 **)(param_1 + 0xe);
      while (cVar3 == '\0') {
        if (*(uint *)(puVar17 + 3) < uVar6) {
          puVar14 = (undefined8 *)puVar17[2];
          puVar17 = puVar1;
        }
        else {
          puVar14 = (undefined8 *)*puVar17;
        }
        puVar1 = puVar17;
        puVar17 = puVar14;
        cVar3 = *(char *)((longlong)puVar14 + 0x29);
      }
      puVar17 = *(undefined8 **)(param_1 + 0xe);
      local_30 = puVar1;
      local_38 = *(longlong *)(param_1 + 2);
      if (*(longlong *)(param_1 + 2) == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar1 == puVar17) || (uVar6 < *(uint *)(puVar1 + 3))) {
        plVar12 = &local_28;
        local_20 = *(undefined8 *)(param_1 + 0xe);
        local_28 = *(longlong *)(param_1 + 2);
      }
      else {
        plVar12 = &local_38;
      }
      plVar10 = (longlong *)*plVar12;
      lVar15 = *(longlong *)(param_1 + 0xe);
      local_18 = plVar10;
      local_10 = plVar12[1];
      if ((plVar10 == (longlong *)0x0) || (plVar10 != *(longlong **)(param_1 + 2))) {
        _invalid_parameter_noinfo();
      }
      lVar2 = local_10;
      if (local_10 != lVar15) {
        if (plVar10 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar15 = 0;
        }
        else {
          lVar15 = *plVar10;
        }
        if (lVar2 == *(longlong *)(lVar15 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar12 = *(longlong **)(lVar2 + 0x20);
        if (plVar12 == (longlong *)0x0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("CSignMgr::FillSign, pRec is NULL, user id[%lu].");
        }
        else {
          plVar10 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,1);
          bVar4 = (**(code **)(*plVar10 + 0x20))(plVar10);
          if (bVar4 < 5) {
            uVar16 = 0;
            plVar10 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,2);
            uVar6 = (**(code **)(*plVar10 + 0x50))(plVar10);
            uVar13 = 1;
            lVar15 = 0x20;
            do {
              if ((uVar6 & uVar13) != 0) {
                uVar16 = uVar16 + 1;
              }
              uVar13 = uVar13 << 1 | (uint)((int)uVar13 < 0);
              lVar15 = lVar15 + -1;
            } while (lVar15 != 0);
            if (bVar4 == 0) {
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              uVar6 = FUN_140006e40(uVar9);
              if (uVar16 < uVar6) {
                return;
              }
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              iVar7 = FUN_140006e90(uVar9);
            }
            else if (bVar4 == 1) {
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              uVar6 = FUN_140006e50(uVar9);
              if (uVar16 < uVar6) {
                return;
              }
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              iVar7 = FUN_140006ea0(uVar9);
            }
            else if (bVar4 == 2) {
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              uVar6 = FUN_140006e60(uVar9);
              if (uVar16 < uVar6) {
                return;
              }
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              iVar7 = FUN_140006eb0(uVar9);
            }
            else if (bVar4 == 3) {
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              uVar6 = FUN_140006e70(uVar9);
              if (uVar16 < uVar6) {
                return;
              }
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              iVar7 = FUN_140006ec0(uVar9);
            }
            else {
              if (bVar4 != 4) {
                return;
              }
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              uVar6 = FUN_140006e80(uVar9);
              if (uVar16 < uVar6) {
                return;
              }
              uVar9 = FUN_140008520(*param_1);
              uVar9 = FUN_1400d6610(uVar9);
              iVar7 = FUN_140006ed0(uVar9);
            }
            if (iVar7 != 0) {
              if ((param_2[0x185] - param_2[0x184] >> 2) + 1U < 0x29) {
                plVar10 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,1);
                (**(code **)(*plVar10 + 0xb0))(plVar10,bVar4 + 1);
                (**(code **)(*plVar12 + 0x38))(plVar12,0);
                uVar9 = FUN_140008520(*param_1);
                uVar9 = FUN_140087730(uVar9);
                FUN_140145f60(uVar9,iVar7,param_2,0,0,0);
                plVar10 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,2);
                plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,1);
                uVar8 = (**(code **)(*plVar10 + 0x50))(plVar10);
                uVar5 = (**(code **)(*plVar12 + 0x20))(plVar12);
                FUN_140208780(param_1,param_2,uVar5,uVar8);
              }
              else {
                pIVar11 = theInstance();
                lVar15 = param_2[2];
                uVar9 = (*(code *)**(undefined8 **)pIVar11)
                                  (pIVar11,"STR_SIGN_REWARD_ITEM_NEED_SAPRE");
                (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar9);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgSignOpt::helper_140209c60  @140209c60  [medium:callgraph-r0]  (orig: FUN_140209c60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140209c60(undefined4 *param_1,longlong *param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  char cVar3;
  undefined1 uVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  longlong lVar12;
  undefined1 auStack_4b8 [32];
  longlong local_498;
  undefined8 local_490;
  longlong *local_488;
  longlong local_480;
  longlong local_478;
  undefined8 *local_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  if (param_2 != (longlong *)0x0) {
    local_468 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
    uVar7 = FUN_140008520(*param_1);
    cVar3 = FUN_14008ac00(uVar7);
    if (cVar3 != '\0') {
      uVar5 = (**(code **)(*param_2 + 8))(param_2);
      puVar11 = (undefined8 *)(*(undefined8 **)(param_1 + 0xe))[1];
      cVar3 = *(char *)((longlong)puVar11 + 0x29);
      puVar1 = *(undefined8 **)(param_1 + 0xe);
      while (cVar3 == '\0') {
        if (*(uint *)(puVar11 + 3) < uVar5) {
          puVar10 = (undefined8 *)puVar11[2];
          puVar11 = puVar1;
        }
        else {
          puVar10 = (undefined8 *)*puVar11;
        }
        puVar1 = puVar11;
        puVar11 = puVar10;
        cVar3 = *(char *)((longlong)puVar10 + 0x29);
      }
      local_470 = puVar1;
      local_478 = *(longlong *)(param_1 + 2);
      puVar11 = *(undefined8 **)(param_1 + 0xe);
      if (*(longlong *)(param_1 + 2) == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar1 == puVar11) || (uVar5 < *(uint *)(puVar1 + 3))) {
        local_490 = *(undefined8 *)(param_1 + 0xe);
        local_498 = *(longlong *)(param_1 + 2);
        plVar9 = &local_498;
      }
      else {
        plVar9 = &local_478;
      }
      plVar8 = (longlong *)*plVar9;
      local_488 = plVar8;
      local_480 = plVar9[1];
      lVar12 = *(longlong *)(param_1 + 0xe);
      if ((plVar8 == (longlong *)0x0) || (plVar8 != *(longlong **)(param_1 + 2))) {
        _invalid_parameter_noinfo();
      }
      lVar2 = local_480;
      if (local_480 == lVar12) {
        FUN_140413680(local_458);
        cVar3 = FUN_140413740(local_458,3,0,0);
        if (cVar3 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_458);
        }
        FUN_1404136d0(local_458);
      }
      else {
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar8;
        }
        if (lVar2 == *(longlong *)(lVar12 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar9 = *(longlong **)(lVar2 + 0x20);
        if (plVar9 == (longlong *)0x0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("CSignMgr::FillSign, pRec is NULL, user id[%lu].");
        }
        else {
          plVar8 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
          plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,1);
          uVar6 = (**(code **)(*plVar8 + 0x50))(plVar8);
          uVar4 = (**(code **)(*plVar9 + 0x20))(plVar9);
          FUN_140208780(param_1,param_2,uVar4,uVar6);
        }
      }
    }
  }
  return;
}

// ==== CMsgSignOpt::ctor_or_dtor  @140413680  [high:vtable-assign]  (orig: FUN_140413680)
undefined8 * FUN_140413680(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgSignOpt::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgSignOpt::ctor_or_dtor  @1404136d0  [high:vtable-assign]  (orig: FUN_1404136d0)
void FUN_1404136d0(undefined8 *param_1)

{
  *param_1 = CMsgSignOpt::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgSignOpt::vfunc_1  @140413700  [high:rtti-vtable]  (orig: FUN_140413700)
bool FUN_140413700(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xc80;
    }
  }
  return false;
}

// ==== CMsgSignOpt::helper_140413740  @140413740  [medium:callgraph-r1]  (orig: FUN_140413740)
ulonglong FUN_140413740(longlong param_1,undefined1 param_2,undefined1 param_3,undefined4 param_4)

{
  longlong lVar1;
  ulonglong in_RAX;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    uVar2 = in_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 8) = 0xc80;
    *(undefined4 *)(param_1 + 0xc) = 8;
    **(undefined1 **)(param_1 + 0x428) = param_2;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = param_3;
    lVar1 = *(longlong *)(param_1 + 0x428);
    *(undefined4 *)(lVar1 + 4) = param_4;
    uVar2 = CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
  }
  return uVar2;
}

// ==== CMsgSignOpt::ctor_or_dtor  @1404137c0  [high:vtable-assign]  (orig: FUN_1404137c0)
undefined8 * FUN_1404137c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgSignOpt::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgSignOpt::vfunc_3  @140413810  [high:rtti-vtable]  (orig: FUN_140413810)
void FUN_140413810(longlong param_1)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  IStringManager *pIVar5;
  longlong lVar6;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x88))(plVar3,param_1);
    if (lVar4 != 0) {
      cVar1 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x220))(lVar4 + 0x10);
      if (cVar1 == '\0') {
        pIVar5 = theInstance();
        lVar6 = *(longlong *)(lVar4 + 0x10);
        uVar2 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_DIE");
        (**(code **)(lVar6 + 0x358))(lVar4 + 0x10,uVar2);
      }
      else {
        cVar1 = **(char **)(param_1 + 0x428);
        if (cVar1 == '\0') {
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x220) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x220);
          }
          FUN_140209210(uVar2,lVar4);
        }
        else if (cVar1 == '\x01') {
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x220) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x220);
          }
          FUN_140209580(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        }
        else if (cVar1 == '\x02') {
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x220) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x220);
          }
          FUN_140209860(uVar2,lVar4);
        }
        else if (cVar1 == '\x03') {
          lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar6 + 0x220) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar2 = 0;
          }
          else {
            uVar2 = *(undefined8 *)(lVar6 + 0x220);
          }
          FUN_140209c60(uVar2,lVar4);
        }
      }
    }
  }
  return;
}

