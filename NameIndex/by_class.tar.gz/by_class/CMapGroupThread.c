// ==== CMapGroupThread::ctor_or_dtor  @14001d2d0  [high:vtable-assign]  (orig: FUN_14001d2d0)
CThreadBase * FUN_14001d2d0(CThreadBase *param_1,longlong param_2,undefined4 param_3)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CMapGroupThread::vftable;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","pPort",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupthread.cpp",0x12);
  }
  *(longlong *)(param_1 + 0x48) = param_2;
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x50) = param_3;
  return param_1;
}

// ==== CMapGroupThread::ctor_or_dtor  @14001d360  [high:vtable-assign]  (orig: FUN_14001d360)
void FUN_14001d360(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CMapGroupThread::vftable;
                    /* WARNING: Could not recover jumptable at 0x00014001d380. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CMapGroupThread::vfunc_4  @14001d390  [high:rtti-vtable]  (orig: FUN_14001d390)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_14001d390(CThreadBase *param_1,bool param_2)

{
  bool bVar1;
  undefined7 extraout_var;
  undefined8 uVar2;
  code *pcVar3;
  ulonglong uVar4;
  undefined1 auStack_58 [32];
  char local_38 [40];
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_58;
  local_38[0] = '\0';
  local_38[1] = '\0';
  local_38[2] = '\0';
  local_38[3] = '\0';
  local_38[4] = '\0';
  local_38[5] = '\0';
  local_38[6] = '\0';
  local_38[7] = '\0';
  local_38[8] = '\0';
  local_38[9] = '\0';
  local_38[10] = '\0';
  local_38[0xb] = '\0';
  local_38[0xc] = '\0';
  local_38[0xd] = '\0';
  local_38[0xe] = '\0';
  local_38[0xf] = '\0';
  local_38[0x10] = '\0';
  local_38[0x11] = '\0';
  local_38[0x12] = '\0';
  local_38[0x13] = '\0';
  local_38[0x14] = '\0';
  local_38[0x15] = '\0';
  local_38[0x16] = '\0';
  local_38[0x17] = '\0';
  local_38[0x18] = '\0';
  local_38[0x19] = '\0';
  local_38[0x1a] = '\0';
  local_38[0x1b] = '\0';
  local_38[0x1c] = '\0';
  local_38[0x1d] = '\0';
  local_38[0x1e] = '\0';
  local_38[0x1f] = '\0';
  local_38[0x20] = '\0';
  local_38[0x21] = '\0';
  local_38[0x22] = '\0';
  local_38[0x23] = 0;
  _snprintf(local_38,0x23,"MapGroupThread[%d]",(ulonglong)*(uint *)(param_1 + 0x50));
  bVar1 = CThreadBase::CreateThread(param_1,local_38,param_2);
  uVar4 = CONCAT71(extraout_var,bVar1);
  if (bVar1) {
    uVar2 = FUN_1400f01f0();
    *(undefined8 *)(param_1 + 0x40) = uVar2;
    pcVar3 = (code *)FUN_140508f10(0);
    uVar4 = 0;
    if (pcVar3 != (code *)0x0) {
      uVar4 = (*pcVar3)(*(undefined8 *)(param_1 + 0x40),*(undefined8 *)(param_1 + 0x48));
      return uVar4;
    }
  }
  return uVar4 & 0xffffffffffffff00;
}

// ==== CMapGroupThread::vfunc_1  @14001d440  [high:rtti-vtable]  (orig: FUN_14001d440)
void FUN_14001d440(longlong param_1)

{
  tq::TimeGet(0);
  if (*(longlong **)(param_1 + 0x40) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x28))();
  }
  *(undefined8 *)(param_1 + 0x40) = 0;
                    /* WARNING: Could not recover jumptable at 0x00014001d46f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  tq::TimeGet(0);
  return;
}

// ==== CMapGroupThread::vfunc_2  @14001d480  [high:rtti-vtable]  (orig: FUN_14001d480)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14001d480(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1024];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  InstanceGet();
  local_418[0] = '\0';
  memset(local_418 + 1,0,0x3ff);
  (**(code **)(**(longlong **)(param_1 + 0x48) + 8))();
  _snprintf(local_418,0x3ff,"#%u: map group thread is up and running");
  lVar2 = -1;
  pcVar3 = local_418;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  local_428 = local_418;
  (**(code **)(**(longlong **)(param_1 + 0x48) + 0x50))
            (*(longlong **)(param_1 + 0x48),0,0x9c41,~(uint)lVar2);
  return;
}

// ==== CMapGroupThread::vfunc_3  @14001d530  [high:rtti-vtable]  (orig: FUN_14001d530)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14001d530(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  int iVar3;
  uint uVar4;
  undefined1 auStack_508 [32];
  undefined1 *local_4e8;
  undefined4 *local_4e0;
  char local_4d8;
  char local_4d7;
  ulong local_4d4;
  ulong local_4d0;
  longlong local_4c8;
  int local_4c0;
  undefined4 local_4b8 [4];
  undefined8 local_4a8;
  CTickAnalyst local_4a0 [24];
  CTickAnalyst local_488 [24];
  CTickAnalyst local_470 [24];
  CTickAnalyst local_458 [32];
  undefined1 local_438 [1056];
  ulonglong local_18;
  
  local_4a8 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  local_4c8 = param_1;
  if ((DAT_140975504 & 1) == 0) {
    DAT_140975504 = DAT_140975504 | 1;
    DAT_140975500 = tq::TimeGet(0);
  }
  local_4d8 = 0;
  CTickAnalyst::CTickAnalyst(local_488,0x47);
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x58))();
  local_4d8 = cVar1;
  CTickAnalyst::~CTickAnalyst(local_488);
  CTickAnalyst::CTickAnalyst(local_470,0);
  uVar2 = tq::TimeGet(0);
  local_4d0 = uVar2;
  if (cVar1 == '\0') {
    CTickAnalyst::CTickAnalyst(local_4a0,0xc);
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x20))(*(longlong **)(param_1 + 0x40),uVar2);
    CTickAnalyst::~CTickAnalyst(local_4a0);
    if (uVar2 - DAT_140975500 < 0x2711) {
      DAT_140975500 = DAT_140975500 + 0x7d;
    }
    else {
      log_InlineLogWARNING("resync CMapGroupKernel::OnTimer cumulative deviation %dms");
      DAT_140975500 = uVar2;
    }
  }
  else {
    while( true ) {
      local_4e0 = local_4b8;
      local_4e8 = local_438;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x48))
                        (*(longlong **)(param_1 + 0x48),0xffffffff,0xffffffff,0x418);
      if (cVar1 == '\0') break;
      local_4d7 = 1;
      CTickAnalyst::CTickAnalyst(local_458,1);
      local_4e8 = (undefined1 *)CONCAT44(local_4e8._4_4_,local_4b8[0]);
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x18))();
      local_4d7 = cVar1;
      CTickAnalyst::~CTickAnalyst(local_458);
      if (cVar1 == '\0') {
        log_InlineLogERROR(
                          "CMapGroupThread::OnProcess ProcessMsg returned error with packet:%d, port:%d"
                          );
      }
    }
  }
  iVar3 = (**(code **)(**(longlong **)(param_1 + 0x48) + 8))();
  uVar4 = iVar3 - 0xe;
  local_4c8 = CONCAT44(local_4c8._4_4_,uVar4);
  local_4d4 = tq::TimeGet(0);
  local_4c0 = local_4d4 - uVar2;
  if (uVar4 < 5) {
    LOCK();
    (&DAT_1409756c4)[(int)uVar4] = (&DAT_1409756c4)[(int)uVar4] + local_4c0;
    UNLOCK();
    LOCK();
    (&DAT_1409756d8)[(int)uVar4] = (&DAT_1409756d8)[(int)uVar4] + 1;
    UNLOCK();
    if ((int)(&DAT_1409756b0)[(int)uVar4] < local_4c0) {
      (&DAT_1409756b0)[(int)uVar4] = local_4c0;
    }
  }
  if ((int)(local_4d4 - DAT_140975500) < 0x7d) {
    DAT_140949640 = 0x7d - (local_4d4 - DAT_140975500);
  }
  else {
    DAT_140949640 = 0;
  }
  CTickAnalyst::~CTickAnalyst(local_470);
  return 1;
}

// ==== CMapGroupThread::ctor_or_dtor  @14001d7e0  [high:vtable-assign]  (orig: FUN_14001d7e0)
CThreadBase * FUN_14001d7e0(CThreadBase *param_1,uint param_2)

{
  *(undefined ***)param_1 = CMapGroupThread::vftable;
  CThreadBase::~CThreadBase(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMapGroupThread::helper_1400f01f0  @1400f01f0  [medium:callgraph-r0]  (orig: FUN_1400f01f0)
undefined8 FUN_1400f01f0(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  if ((DAT_140975ca0 & 1) == 0) {
    DAT_140975ca0 = DAT_140975ca0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975c98,"CMapGroupKernel");
    atexit((_func_5014 *)&LAB_1406d66a0);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140975c98,0x210);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1400f0000(pvVar1);
  }
  return uVar2;
}

