// ==== CMsgMailOperation@mail::helper_1400d6940  @1400d6940  [medium:callgraph-r1]  (orig: FUN_1400d6940)
undefined8 FUN_1400d6940(undefined8 param_1,longlong param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = (longlong *)0x0;
  }
  lVar3 = (**(code **)(*plVar4 + 0x60))(plVar4,param_3);
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar4 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    cVar1 = (**(code **)(*plVar4 + 0x130))(plVar4,param_2,lVar3,0xb,0,0);
    if (cVar1 != '\0') {
      uVar2 = FUN_1400fda10(lVar3,1,1);
      cVar1 = FUN_1400ff940(uVar2);
      if (cVar1 != '\0') {
        FUN_14019a030(param_2,param_3,0,0);
      }
      return 1;
    }
  }
  return 0;
}

// ==== CMsgMailOperation@mail::helper_1400d6ac0  @1400d6ac0  [medium:callgraph-r1]  (orig: FUN_1400d6ac0)
ulonglong FUN_1400d6ac0(undefined8 param_1,longlong param_2,undefined4 param_3)

{
  ulonglong extraout_RAX;
  longlong lVar1;
  ulonglong extraout_RAX_00;
  longlong lVar2;
  ulonglong uVar3;
  longlong *plVar4;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    plVar4 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    lVar1 = (**(code **)(*plVar4 + 0x60))(plVar4,param_3);
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = extraout_RAX_00 & 0xffffffffffffff00;
    }
    else {
      lVar2 = FUN_140100070(lVar1);
      if ((lVar2 != 0) || (lVar1 = FUN_140100290(lVar1), lVar1 != 0)) {
        plVar4 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar4 = (longlong *)0x0;
        }
        (**(code **)(*plVar4 + 0x178))(plVar4,param_3);
      }
      FUN_140336100(param_2,param_3);
      uVar3 = FUN_140340de0(param_2,param_3,1);
    }
  }
  return uVar3;
}

// ==== CMsgMailOperation@mail::helper_1400d6c40  @1400d6c40  [medium:callgraph-r1]  (orig: FUN_1400d6c40)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1400d6c40(undefined8 param_1,longlong *param_2,undefined4 param_3,char param_4)

{
  uint uVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong *plVar4;
  
  if (param_2 != (longlong *)0x0) {
    uVar1 = (**(code **)(*param_2 + 8))(param_2);
    if (uVar1 != 0) {
      plVar4 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        plVar4 = (longlong *)0x0;
      }
      lVar2 = (**(code **)(*plVar4 + 0x60))(plVar4,param_3);
      if (lVar2 != 0) {
        if (param_4 == '\0') {
          FUN_1400fda10(lVar2,0xc,1);
          FUN_1400fda10(lVar2,0x13,1);
          FUN_1400ffda0(lVar2);
          FUN_1400fda10(lVar2,0xf,1);
          FUN_1400fda10(lVar2,0xe,1);
          FUN_1400fda10(lVar2,0x10,1);
          FUN_1400fda10(lVar2,5,1);
          FUN_1400fda10(lVar2,4,1);
          FUN_1400fda10(lVar2,9,1);
          FUN_1400fda10(lVar2,8,1);
          FUN_1400fda10(lVar2,1,1);
          FUN_140100430(lVar2,0x65);
          uVar3 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
          tq::MyLogSave("gmlog/mail",
                        "Receive Item Fail Receiver id[%u] name[%s] | item id[%d] name[%s] type[%u] gem1[%d] gem2[%d] magic3[%d] dur[%d] max_dur[%d] antimonster[%u], dec_dmg[%u] add_life[%u] accumulate[%d] specialflag[%d]"
                        ,(ulonglong)uVar1,uVar3);
        }
        else {
          FUN_1400fda10(lVar2,0xc,1);
          FUN_1400fda10(lVar2,0x13,1);
          FUN_1400ffda0(lVar2);
          FUN_1400fda10(lVar2,0xf,1);
          FUN_1400fda10(lVar2,0xe,1);
          FUN_1400fda10(lVar2,0x10,1);
          FUN_1400fda10(lVar2,5,1);
          FUN_1400fda10(lVar2,4,1);
          FUN_1400fda10(lVar2,9,1);
          FUN_1400fda10(lVar2,8,1);
          FUN_1400fda10(lVar2,1,1);
          FUN_140100430(lVar2,0x65);
          uVar3 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
          tq::MyLogSave("gmlog/mail",
                        "Receive Item Succuss| Receiver id[%u] name[%s] | item id[%u] name[%s] type[%u] gem1[%d] gem2[%d] magic3[%d] dur[%d] max_dur[%d] antimonster[%u], dec_dmg[%u] add_life[%u] accumulate[%d] specialflag[%d]"
                        ,(ulonglong)uVar1,uVar3);
        }
      }
    }
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_1400d86c0  @1400d86c0  [medium:callgraph-r1]  (orig: FUN_1400d86c0)
undefined8 FUN_1400d86c0(longlong param_1,undefined4 param_2,ulonglong param_3)

{
  longlong lVar1;
  longlong *plVar2;
  longlong lVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x40));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2)
  ;
  if (plVar2 != (longlong *)0x0) {
    lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2);
    lVar1 = lVar1 + (param_3 & 0xffffffff);
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x40));
    if (*(longlong *)(lVar3 + 0xb0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = FUN_140006cc0(*(undefined8 *)(lVar3 + 0xb0));
    if ((lVar1 <= lVar3) && (-1 < lVar1)) {
      return 0;
    }
    (**(code **)(plVar2[2] + 0x358))(plVar2 + 2,&DAT_140700278);
  }
  return 1;
}

// ==== CMsgMailOperation@mail::helper_1400d87d0  @1400d87d0  [medium:callgraph-r1]  (orig: FUN_1400d87d0)
ulonglong FUN_1400d87d0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x40));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2)
  ;
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400d8891. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x180))(plVar2,param_3,1);
  return uVar3;
}

// ==== CMsgMailOperation@mail::helper_1400d88a0  @1400d88a0  [medium:callgraph-r1]  (orig: FUN_1400d88a0)
undefined8 FUN_1400d88a0(longlong param_1,undefined4 param_2,int param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x40));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 != 0) {
    if (param_3 + *(int *)(lVar1 + 0xfa4) < 0x3b9aca01) {
      return 0;
    }
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x358))(lVar1 + 0x10,&DAT_1407002a8);
  }
  return 1;
}

// ==== CMsgMailOperation@mail::helper_1400d8960  @1400d8960  [medium:callgraph-r1]  (orig: FUN_1400d8960)
ulonglong FUN_1400d8960(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x40));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2e0))
                    ((longlong *)(lVar1 + 0x10),0x1d,param_3,1,0);
  return uVar2;
}

// ==== CMsgMailOperation@mail::helper_1400d8a40  @1400d8a40  [medium:callgraph-r1]  (orig: FUN_1400d8a40)
void FUN_1400d8a40(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x40));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_4);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1401742b0(lVar1,param_2,param_3,param_4,param_5);
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_1400dc530  @1400dc530  [medium:callgraph-r0]  (orig: FUN_1400dc530)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400dc530(longlong *param_1,int param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  int local_4b8;
  int local_4b4;
  longlong *local_4b0;
  longlong local_4a8;
  longlong *local_4a0;
  longlong *local_490;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  local_4b8 = param_2;
  local_4b4 = param_3;
  if (param_3 == 0) {
    local_4c8 = 0x3ab;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == 0) {
    local_4c8 = 0x3af;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1400db220(param_1,&local_4b0,&local_4b8);
    plVar5 = local_4b0;
    lVar7 = param_1[6];
    lVar6 = 0;
    local_4a0 = (longlong *)*param_1;
    if ((local_4b0 == (longlong *)0x0) || (local_4b0 != local_4a0)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = local_4a8;
    if (local_4a8 != lVar7) {
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar6;
      }
      else {
        lVar7 = *plVar5;
      }
      if (lVar1 == *(longlong *)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1400db860(lVar1 + 0x20,&local_4b0,&local_4b4);
      lVar7 = *(longlong *)(lVar1 + 0x50);
      local_490 = *(longlong **)(lVar1 + 0x20);
      if ((local_4b0 == (longlong *)0x0) || (local_4b0 != local_490)) {
        _invalid_parameter_noinfo();
      }
      if (local_4a8 != lVar7) {
        if (local_4b0 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar6 = *local_4b0;
        }
        if (local_4a8 == *(longlong *)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar7 = *(longlong *)(local_4a8 + 0x20);
        if (lVar7 == 0) {
          local_4c8 = 0x3bf;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          uVar4 = FUN_140008520((int)param_1[8]);
          plVar5 = (longlong *)FUN_140087650(uVar4);
          lVar6 = (**(code **)(*plVar5 + 0x98))(plVar5,param_2);
          if (lVar6 == 0) {
            local_4c8 = 0x3c4;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            iVar3 = FUN_14035ad90(lVar7,9);
            if (iVar3 != 0) {
              FUN_1400d6940(param_1,lVar6,iVar3);
            }
            FUN_14035c2e0(local_478);
            uVar4 = FUN_14035ae90(lVar7,4);
            cVar2 = FUN_14035c3a0(local_478,param_3,uVar4);
            if (cVar2 != '\0') {
              (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x350))
                        ((longlong *)(lVar6 + 0x10),local_478);
            }
            FUN_14035c330(local_478);
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_1400dc7c0  @1400dc7c0  [medium:callgraph-r0]  (orig: FUN_1400dc7c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400dc7c0(longlong *param_1,int param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined1 auStack_4e8 [32];
  int local_4c8;
  int local_4b8;
  int local_4b4;
  longlong *local_4b0;
  longlong local_4a8;
  longlong *local_4a0;
  longlong *local_490;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  local_4b8 = param_2;
  local_4b4 = param_3;
  if (param_3 == 0) {
    local_4c8 = 0x433;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == 0) {
    local_4c8 = 0x437;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1400db220(param_1,&local_4b0,&local_4b8);
    plVar5 = local_4b0;
    lVar6 = param_1[6];
    lVar7 = 0;
    local_4a0 = (longlong *)*param_1;
    if ((local_4b0 == (longlong *)0x0) || (local_4b0 != local_4a0)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = local_4a8;
    if (local_4a8 != lVar6) {
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = lVar7;
      }
      else {
        lVar6 = *plVar5;
      }
      if (lVar1 == *(longlong *)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1400db860(lVar1 + 0x20,&local_4b0,&local_4b4);
      lVar6 = *(longlong *)(lVar1 + 0x50);
      local_490 = *(longlong **)(lVar1 + 0x20);
      if ((local_4b0 == (longlong *)0x0) || (local_4b0 != local_490)) {
        _invalid_parameter_noinfo();
      }
      if (local_4a8 != lVar6) {
        if (local_4b0 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar7 = *local_4b0;
        }
        if (local_4a8 == *(longlong *)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar6 = *(longlong *)(local_4a8 + 0x20);
        if (lVar6 == 0) {
          local_4c8 = 0x447;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          iVar3 = FUN_14035ad90(lVar6,1);
          if (param_2 == iVar3) {
            iVar3 = FUN_14035ad90(lVar6,5);
            if (iVar3 != 0) {
              cVar2 = FUN_1400d86c0(param_1,param_2,iVar3);
              if (cVar2 == '\0') {
                FUN_14035adf0(lVar6,5,0);
                cVar2 = FUN_14035ad40(lVar6);
                local_4c8 = iVar3;
                if (cVar2 == '\0') {
                  tq::MyLogSave("gmlog/mail",
                                "Receive Mail Money Failed| idMail[%u] idReceiver[%u] dwMoney[%u]");
                }
                else {
                  cVar2 = FUN_1400d87d0(param_1,param_2,iVar3);
                  if (cVar2 == '\0') {
                    tq::MyLogSave("gmlog/mail",
                                  "Receive Mail Money Failed| idMail[%u] idReceiver[%u] dwMoney[%u]"
                                 );
                  }
                  else {
                    uVar4 = FUN_140008520((int)param_1[8]);
                    plVar5 = (longlong *)FUN_140087650(uVar4);
                    lVar6 = (**(code **)(*plVar5 + 0x98))(plVar5,param_2);
                    if (lVar6 != 0) {
                      FUN_14035c460(local_478);
                      cVar2 = FUN_14035c520(local_478,param_3,3);
                      if (cVar2 != '\0') {
                        (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x350))
                                  ((longlong *)(lVar6 + 0x10),local_478);
                      }
                      FUN_14035c4b0(local_478);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_1400dcab0  @1400dcab0  [medium:callgraph-r0]  (orig: FUN_1400dcab0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400dcab0(longlong *param_1,int param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  undefined1 auStack_4e8 [32];
  int local_4c8;
  uint local_4c0;
  int local_4b8;
  int local_4b4;
  longlong *local_4b0;
  longlong local_4a8;
  longlong *local_4a0;
  longlong *local_490;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  local_4b8 = param_2;
  local_4b4 = param_3;
  if (param_2 == 0) {
    local_4c8 = 0x49b;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 == 0) {
    local_4c8 = 0x49f;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1400db220(param_1,&local_4b0,&local_4b8);
    plVar6 = local_4b0;
    lVar7 = param_1[6];
    lVar8 = 0;
    local_4a0 = (longlong *)*param_1;
    if ((local_4b0 == (longlong *)0x0) || (local_4b0 != local_4a0)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = local_4a8;
    if (local_4a8 != lVar7) {
      if (plVar6 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar6;
      }
      if (lVar1 == *(longlong *)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1400db860(lVar1 + 0x20,&local_4b0,&local_4b4);
      lVar7 = *(longlong *)(lVar1 + 0x50);
      local_490 = *(longlong **)(lVar1 + 0x20);
      if ((local_4b0 == (longlong *)0x0) || (local_4b0 != local_490)) {
        _invalid_parameter_noinfo();
      }
      if (local_4a8 != lVar7) {
        if (local_4b0 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar8 = *local_4b0;
        }
        if (local_4a8 == *(longlong *)(lVar8 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar7 = *(longlong *)(local_4a8 + 0x20);
        if (lVar7 == 0) {
          local_4c8 = 0x4af;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          iVar4 = FUN_14035ad90(lVar7,1);
          if (param_2 == iVar4) {
            iVar4 = FUN_14035ad90(lVar7,6);
            if (0 < iVar4) {
              cVar2 = FUN_1400d88a0(param_1,param_2,iVar4);
              if (cVar2 == '\0') {
                FUN_14035adf0(lVar7,6,0);
                bVar3 = FUN_14035ad90(lVar7,10);
                cVar2 = FUN_14035ad40(lVar7);
                local_4c8 = iVar4;
                if (cVar2 == '\0') {
                  local_4c0 = (uint)bVar3;
                  tq::MyLogSave("gmlog/mail",
                                "Receive Mail EMoney Failed| idMail[%u] idReceiver[%u] nEMoney[%d] RcdType[%u]"
                               );
                }
                else {
                  cVar2 = FUN_1400d8960(param_1,param_2,(longlong)iVar4);
                  if (cVar2 == '\0') {
                    local_4c0 = (uint)bVar3;
                    tq::MyLogSave("gmlog/mail",
                                  "Receive Mail EMoney Failed| idMail[%u] idReceiver[%u] nEMoney[%d] RcdType[%u]"
                                 );
                  }
                  else {
                    if (bVar3 == 0) {
                      FUN_1400d8a40(param_1,0x2e,0,param_2);
                    }
                    else {
                      FUN_1400d8a40(param_1,bVar3,0,param_2);
                    }
                    uVar5 = FUN_140008520((int)param_1[8]);
                    plVar6 = (longlong *)FUN_140087650(uVar5);
                    lVar7 = (**(code **)(*plVar6 + 0x98))(plVar6,param_2);
                    if (lVar7 != 0) {
                      FUN_14035c460(local_478);
                      cVar2 = FUN_14035c520(local_478,param_3,4);
                      if (cVar2 != '\0') {
                        (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x350))
                                  ((longlong *)(lVar7 + 0x10),local_478);
                      }
                      FUN_14035c4b0(local_478);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_1400dcdf0  @1400dcdf0  [medium:callgraph-r0]  (orig: FUN_1400dcdf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400dcdf0(longlong *param_1,int param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  IStringManager *pIVar7;
  longlong lVar8;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  int local_4b8;
  int local_4b4;
  longlong *local_4b0;
  longlong local_4a8;
  longlong *local_4a0;
  longlong *local_490;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  local_4b8 = param_2;
  local_4b4 = param_3;
  if (param_2 == 0) {
    local_4c8 = 0x516;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 == 0) {
    local_4c8 = 0x51a;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1400db220(param_1,&local_4b0,&local_4b8);
    plVar5 = local_4b0;
    lVar8 = param_1[6];
    lVar6 = 0;
    local_4a0 = (longlong *)*param_1;
    if ((local_4b0 == (longlong *)0x0) || (local_4b0 != local_4a0)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = local_4a8;
    if (local_4a8 != lVar8) {
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar8 = lVar6;
      }
      else {
        lVar8 = *plVar5;
      }
      if (lVar1 == *(longlong *)(lVar8 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1400db860(lVar1 + 0x20,&local_4b0,&local_4b4);
      lVar8 = *(longlong *)(lVar1 + 0x50);
      local_490 = *(longlong **)(lVar1 + 0x20);
      if ((local_4b0 == (longlong *)0x0) || (local_4b0 != local_490)) {
        _invalid_parameter_noinfo();
      }
      if (local_4a8 != lVar8) {
        if (local_4b0 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar6 = *local_4b0;
        }
        if (local_4a8 == *(longlong *)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar8 = *(longlong *)(local_4a8 + 0x20);
        if (lVar8 == 0) {
          local_4c8 = 0x52a;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          iVar3 = FUN_14035ad90(lVar8,1);
          if (param_2 == iVar3) {
            iVar3 = FUN_14035ad90(lVar8,9);
            if (iVar3 != 0) {
              uVar4 = FUN_140008520((int)param_1[8]);
              plVar5 = (longlong *)FUN_140087650(uVar4);
              lVar6 = (**(code **)(*plVar5 + 0x98))(plVar5,param_2);
              if (lVar6 == 0) {
                local_4c8 = 0x536;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else if ((*(longlong *)(lVar6 + 0xc28) - *(longlong *)(lVar6 + 0xc20) >> 2) + 1U <
                       0x29) {
                FUN_14035adf0(lVar8,9,0);
                cVar2 = FUN_14035ad40(lVar8);
                if (cVar2 == '\0') {
                  FUN_1400d6c40(param_1,lVar6,iVar3,0);
                }
                else {
                  cVar2 = FUN_1400d6ac0(param_1,lVar6,iVar3);
                  if (cVar2 == '\0') {
                    FUN_1400d6c40(param_1,lVar6,iVar3,0);
                  }
                  else {
                    FUN_1400d6c40(param_1,lVar6,iVar3,1);
                    FUN_14035c460(local_478);
                    cVar2 = FUN_14035c520(local_478,param_3,5);
                    if (cVar2 != '\0') {
                      (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x350))
                                ((longlong *)(lVar6 + 0x10),local_478);
                    }
                    FUN_14035c4b0(local_478);
                  }
                }
              }
              else {
                pIVar7 = theInstance();
                lVar8 = *(longlong *)(lVar6 + 0x10);
                uVar4 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_BAG_FULL");
                (**(code **)(lVar8 + 0x358))(lVar6 + 0x10,uVar4);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_1400dd140  @1400dd140  [medium:callgraph-r0]  (orig: FUN_1400dd140)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400dd140(longlong *param_1,int param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined1 auStack_4e8 [32];
  int local_4c8;
  undefined8 local_4c0;
  int local_4b8;
  int local_4b4;
  longlong *local_4b0 [2];
  longlong *local_4a0;
  longlong local_498;
  undefined8 local_490;
  longlong *local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_490 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  local_4b0[0] = (longlong *)CONCAT44(local_4b0[0]._4_4_,param_2);
  local_4b8 = param_3;
  if (param_2 == 0) {
    local_4c8 = 0x55d;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 == 0) {
    local_4c8 = 0x561;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1400db220(param_1,&local_4a0,local_4b0);
    plVar5 = local_4a0;
    lVar6 = param_1[6];
    lVar7 = 0;
    local_4b0[0] = (longlong *)*param_1;
    if ((local_4a0 == (longlong *)0x0) || (local_4a0 != local_4b0[0])) {
      _invalid_parameter_noinfo();
    }
    lVar1 = local_498;
    if (local_498 != lVar6) {
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = lVar7;
      }
      else {
        lVar6 = *plVar5;
      }
      if (lVar1 == *(longlong *)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1400db860(lVar1 + 0x20,&local_4a0,&local_4b8);
      lVar6 = *(longlong *)(lVar1 + 0x50);
      local_488 = *(longlong **)(lVar1 + 0x20);
      if ((local_4a0 == (longlong *)0x0) || (local_4a0 != local_488)) {
        _invalid_parameter_noinfo();
      }
      if (local_498 != lVar6) {
        if (local_4a0 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar7 = *local_4a0;
        }
        if (local_498 == *(longlong *)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar6 = *(longlong *)(local_498 + 0x20);
        if (lVar6 == 0) {
          local_4c8 = 0x571;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          iVar3 = FUN_14035ad90(lVar6,1);
          if (param_2 == iVar3) {
            iVar3 = FUN_14035ad90(lVar6,7);
            if (iVar3 != 0) {
              local_4b4 = iVar3;
              uVar4 = FUN_140008520((int)param_1[8]);
              plVar5 = (longlong *)FUN_140087650(uVar4);
              plVar5 = (longlong *)(**(code **)(*plVar5 + 0x98))(plVar5,param_2);
              local_4b0[0] = plVar5;
              if (plVar5 == (longlong *)0x0) {
                local_4c8 = 0x57d;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                FUN_14035adf0(lVar6,7,0);
                cVar2 = FUN_14035ad40(lVar6);
                if (cVar2 == '\0') {
                  local_4c8 = iVar3;
                  tq::MyLogSave("gmlog/mail",
                                "Receive Mail Action Failed| idMail[%u] idReceiver[%u] Action[%u]");
                }
                else {
                  uVar4 = FUN_140008520((int)param_1[8]);
                  uVar4 = FUN_140087730(uVar4);
                  local_4c0 = 0;
                  local_4c8 = 0;
                  FUN_140145f60(uVar4,iVar3,plVar5,0);
                  FUN_14035c460(local_478);
                  cVar2 = FUN_14035c520(local_478,param_3,6);
                  if (cVar2 != '\0') {
                    (**(code **)(plVar5[2] + 0x350))(plVar5 + 2,local_478);
                  }
                  FUN_14035c4b0(local_478);
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_1400e0a50  @1400e0a50  [medium:callgraph-r0]  (orig: FUN_1400e0a50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400e0a50(longlong *param_1,int param_2,int param_3)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  char cVar4;
  int iVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  int local_res18 [4];
  undefined1 auStack_508 [32];
  undefined4 local_4e8;
  int local_4d8 [4];
  undefined4 local_4c8;
  undefined4 uStack_4c4;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  undefined8 local_4b8;
  undefined4 uStack_4b0;
  undefined4 uStack_4ac;
  longlong *local_4a8 [2];
  undefined4 local_498;
  undefined4 uStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  local_res18[0] = param_3;
  local_4d8[0] = param_2;
  if (param_3 == 0) {
    local_4e8 = 0x3f1;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == 0) {
    local_4e8 = 0x3f5;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1400db220(param_1,&local_4c8,local_4d8);
    lVar9 = param_1[6];
    lVar8 = 0;
    local_4b8 = (longlong *)*param_1;
    plVar7 = (longlong *)CONCAT44(uStack_4c4,local_4c8);
    if ((plVar7 == (longlong *)0x0) || (plVar7 != local_4b8)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = CONCAT44(uStack_4bc,uStack_4c0);
    if (lVar2 != lVar9) {
      if (plVar7 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar8;
      }
      else {
        lVar9 = *plVar7;
      }
      if (lVar2 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      puVar1 = (undefined8 *)(lVar2 + 0x20);
      FUN_1400db860(puVar1,&local_4b8,local_res18);
      plVar7 = local_4b8;
      lVar9 = *(longlong *)(lVar2 + 0x50);
      local_4a8[0] = (longlong *)*puVar1;
      if ((local_4b8 == (longlong *)0x0) || (local_4b8 != local_4a8[0])) {
        _invalid_parameter_noinfo();
      }
      lVar3 = CONCAT44(uStack_4ac,uStack_4b0);
      if (lVar3 != lVar9) {
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar8 = *plVar7;
        }
        if (lVar3 == *(longlong *)(lVar8 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar9 = *(longlong *)(lVar3 + 0x20);
        if (lVar9 == 0) {
          local_4e8 = 0x405;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          uVar6 = FUN_140008520((int)param_1[8]);
          plVar7 = (longlong *)FUN_140087650(uVar6);
          lVar8 = (**(code **)(*plVar7 + 0x98))(plVar7,param_2);
          if (lVar8 == 0) {
            local_4e8 = 0x40a;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            iVar5 = FUN_14035ad90(lVar9,5);
            if ((((iVar5 < 1) && (iVar5 = FUN_14035ad90(lVar9,6), iVar5 < 1)) &&
                (iVar5 = FUN_14035ad90(lVar9,9), iVar5 == 0)) &&
               (iVar5 = FUN_14035ad90(lVar9,7), iVar5 == 0)) {
              cVar4 = FUN_14035b730(lVar9);
              if (cVar4 != '\0') {
                local_498 = (undefined4)local_4b8;
                uStack_494 = local_4b8._4_4_;
                uStack_490 = uStack_4b0;
                uStack_48c = uStack_4ac;
                FUN_1400db4a0(puVar1,local_4a8,&local_498);
                if (*(longlong *)(lVar2 + 0x58) == 0) {
                  FUN_1400de830(param_1,&local_498,&local_4c8);
                  FUN_14035c930(local_478);
                  cVar4 = FUN_14035c9f0(local_478,2);
                  if (cVar4 != '\0') {
                    (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x350))
                              ((longlong *)(lVar8 + 0x10),local_478);
                  }
                  FUN_14035c980(local_478);
                }
                FUN_14035b7a0(lVar9);
              }
            }
            else {
              FUN_14035c930(local_478);
              cVar4 = FUN_14035c9f0(local_478,1);
              if (cVar4 != '\0') {
                (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x350))
                          ((longlong *)(lVar8 + 0x10),local_478);
              }
              FUN_14035c980(local_478);
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_140336100  @140336100  [medium:callgraph-r2]  (orig: FUN_140336100)
void FUN_140336100(longlong param_1,int param_2)

{
  int *piVar1;
  longlong lVar2;
  rsize_t _DstSize;
  int *_Dst;
  
  if (param_2 != 0) {
    piVar1 = *(int **)(param_1 + 0xd58);
    if (piVar1 < *(int **)(param_1 + 0xd50)) {
      _invalid_parameter_noinfo();
    }
    _Dst = *(int **)(param_1 + 0xd50);
    if (*(int **)(param_1 + 0xd58) < _Dst) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *(longlong *)(param_1 + 0xd38);
    for (; (_Dst != piVar1 && (*_Dst != param_2)); _Dst = _Dst + 1) {
    }
    piVar1 = *(int **)(param_1 + 0xd58);
    if (piVar1 < *(int **)(param_1 + 0xd50)) {
      _invalid_parameter_noinfo();
    }
    if ((lVar2 == 0) || (lVar2 != *(longlong *)(param_1 + 0xd38))) {
      _invalid_parameter_noinfo();
    }
    if (_Dst != piVar1) {
      lVar2 = *(longlong *)(param_1 + 0xd58) - (longlong)(_Dst + 1) >> 2;
      if (0 < lVar2) {
        _DstSize = lVar2 << 2;
        memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
      }
      *(longlong *)(param_1 + 0xd58) = *(longlong *)(param_1 + 0xd58) + -4;
      if ((_Dst < *(int **)(param_1 + 0xd50)) || (*(int **)(param_1 + 0xd58) < _Dst)) {
        _invalid_parameter_noinfo();
      }
    }
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_14035ad40  @14035ad40  [medium:callgraph-r1]  (orig: FUN_14035ad40)
ulonglong FUN_14035ad40(longlong *param_1)

{
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  param_1 = (longlong *)*param_1;
  if (param_1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014035ad86. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(*param_1 + 0x38))(param_1,0);
  return uVar1;
}

// ==== CMsgMailOperation@mail::helper_14035adf0  @14035adf0  [medium:callgraph-r1]  (orig: FUN_14035adf0)
void FUN_14035adf0(longlong *param_1,uint param_2,undefined4 param_3,char param_4)

{
  longlong *plVar1;
  
  if (param_2 < 0xb) {
    if ((longlong *)*param_1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    plVar1 = (longlong *)(**(code **)(*(longlong *)*param_1 + 0x10))();
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_3);
    if (param_4 != '\0') {
      (**(code **)(*(longlong *)*param_1 + 0x38))((longlong *)*param_1,0);
    }
  }
  return;
}

// ==== CMsgMailOperation@mail::helper_14035c2e0  @14035c2e0  [medium:callgraph-r1]  (orig: FUN_14035c2e0)
undefined8 * FUN_14035c2e0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = mail::CMsgMailContent::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMailOperation@mail::helper_14035c330  @14035c330  [medium:callgraph-r1]  (orig: FUN_14035c330)
void FUN_14035c330(undefined8 *param_1)

{
  *param_1 = mail::CMsgMailContent::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMailOperation@mail::helper_14035c3a0  @14035c3a0  [medium:callgraph-r1]  (orig: FUN_14035c3a0)
undefined8 FUN_14035c3a0(longlong param_1,int param_2,char *param_3)

{
  if (((*(int **)(param_1 + 0x428) != (int *)0x0) && (param_3 != (char *)0x0)) && (param_2 != 0)) {
    *(undefined4 *)(param_1 + 0xc) = 0x104;
    *(undefined4 *)(param_1 + 8) = 0x418;
    **(int **)(param_1 + 0x428) = param_2;
    strncpy((char *)(*(longlong *)(param_1 + 0x428) + 4),param_3,0xff);
    return 1;
  }
  return 0;
}

// ==== CMsgMailOperation@mail::vfunc_5  @14035c4e0  [high:rtti-vtable]  (orig: FUN_14035c4e0)
bool FUN_14035c4e0(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x415;
    }
  }
  return false;
}

// ==== CMsgMailOperation@mail::vfunc_0  @14035c550  [high:rtti-vtable]  (orig: FUN_14035c550)
undefined8 * FUN_14035c550(undefined8 *param_1,uint param_2)

{
  *param_1 = mail::CMsgMailOperation::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgMailOperation@mail::vfunc_3  @14035c5a0  [high:rtti-vtable]  (orig: FUN_14035c5a0)
void FUN_14035c5a0(longlong param_1)

{
  undefined2 *puVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar4 = (longlong *)FUN_140087650(uVar3);
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x88))(plVar4,param_1);
  if (plVar4 != (longlong *)0x0) {
    iVar2 = (**(code **)(*plVar4 + 8))(plVar4);
    if (iVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      puVar1 = *(undefined2 **)(param_1 + 0x428);
      if (puVar1 == (undefined2 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else if (*(int *)(puVar1 + 2) == 0) {
        plVar4 = (longlong *)FUN_1400e1e60();
        (**(code **)(*plVar4 + 0x40))(plVar4,iVar2,0x5a);
        log_InlineLogWARNING("CMsgMailOperation::Process Mail id is 0, user:%u, usAction:%u.");
      }
      else {
        switch(*puVar1) {
        case 1:
          lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar5 + 0x180) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar3 = 0;
          }
          else {
            uVar3 = *(undefined8 *)(lVar5 + 0x180);
          }
          FUN_1400dc530(uVar3,iVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          break;
        case 2:
          lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar5 + 0x180) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar3 = 0;
          }
          else {
            uVar3 = *(undefined8 *)(lVar5 + 0x180);
          }
          FUN_1400e0a50(uVar3,iVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          break;
        case 3:
          lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar5 + 0x180) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar3 = 0;
          }
          else {
            uVar3 = *(undefined8 *)(lVar5 + 0x180);
          }
          FUN_1400dc7c0(uVar3,iVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          break;
        case 4:
          lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar5 + 0x180) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar3 = 0;
          }
          else {
            uVar3 = *(undefined8 *)(lVar5 + 0x180);
          }
          FUN_1400dcab0(uVar3,iVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          break;
        case 5:
          lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar5 + 0x180) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar3 = 0;
          }
          else {
            uVar3 = *(undefined8 *)(lVar5 + 0x180);
          }
          FUN_1400dcdf0(uVar3,iVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          break;
        case 6:
          lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar5 + 0x180) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar3 = 0;
          }
          else {
            uVar3 = *(undefined8 *)(lVar5 + 0x180);
          }
          FUN_1400dd140(uVar3,iVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        }
      }
    }
  }
  return;
}

