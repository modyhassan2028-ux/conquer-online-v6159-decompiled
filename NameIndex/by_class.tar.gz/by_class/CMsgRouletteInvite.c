// ==== CMsgRouletteInvite::ctor_or_dtor  @140413070  [high:vtable-assign]  (orig: FUN_140413070)
undefined8 * FUN_140413070(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRouletteInvite::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRouletteInvite::ctor_or_dtor  @1404130c0  [high:vtable-assign]  (orig: FUN_1404130c0)
void FUN_1404130c0(undefined8 *param_1)

{
  *param_1 = CMsgRouletteInvite::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRouletteInvite::vfunc_1  @1404130f0  [high:rtti-vtable]  (orig: FUN_1404130f0)
ulonglong FUN_1404130f0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xaf6);
}

// ==== CMsgRouletteInvite::vfunc_3  @140413180  [high:rtti-vtable]  (orig: FUN_140413180)
void FUN_140413180(void)

{
  return;
}

// ==== CMsgRouletteInvite::ctor_or_dtor  @140413190  [high:vtable-assign]  (orig: FUN_140413190)
undefined8 * FUN_140413190(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRouletteInvite::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

