// ==== CMsgRouletteTable::ctor_or_dtor  @1404dd7f0  [high:vtable-assign]  (orig: FUN_1404dd7f0)
undefined8 * FUN_1404dd7f0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRouletteTable::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRouletteTable::ctor_or_dtor  @1404dd840  [high:vtable-assign]  (orig: FUN_1404dd840)
void FUN_1404dd840(undefined8 *param_1)

{
  *param_1 = CMsgRouletteTable::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRouletteTable::vfunc_1  @1404dd870  [high:rtti-vtable]  (orig: FUN_1404dd870)
ulonglong FUN_1404dd870(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xaf8);
}

// ==== CMsgRouletteTable::vfunc_3  @1404dda20  [high:rtti-vtable]  (orig: FUN_1404dda20)
void FUN_1404dda20(void)

{
  return;
}

// ==== CMsgRouletteTable::ctor_or_dtor  @1404dda30  [high:vtable-assign]  (orig: FUN_1404dda30)
undefined8 * FUN_1404dda30(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRouletteTable::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

