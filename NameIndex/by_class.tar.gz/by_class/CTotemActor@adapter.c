// ==== CTotemActor@adapter::helper_140188f70  @140188f70  [medium:callgraph-r0]  (orig: FUN_140188f70)
undefined4 FUN_140188f70(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x1100) != 0) {
    plVar1 = *(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x1100) + 0x58) + 8);
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
    uVar2 = (**(code **)(*plVar1 + 0x58))(plVar1);
    if ((uVar2 >> 0x34 & 1) != 0) {
      return 0;
    }
  }
  return *(undefined4 *)(param_1 + 0xb28);
}

// ==== CTotemActor@adapter::helper_14059d2f0  @14059d2f0  [medium:callgraph-r0]  (orig: FUN_14059d2f0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 * FUN_14059d2f0(undefined8 *param_1,char *param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 local_res18;
  undefined8 local_res20;
  undefined1 auStack_1068 [32];
  undefined8 *local_1048;
  undefined8 local_1040;
  undefined8 local_1038;
  char local_1028;
  undefined1 local_1027 [4094];
  undefined1 local_29;
  ulonglong local_28;
  undefined8 uStack_18;
  
  uStack_18 = 0x14059d30b;
  local_1040 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_1068;
  local_res18 = param_3;
  local_res20 = param_4;
  local_1048 = param_1;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  *param_1 = tq::CString::vftable;
  if (param_2 != (char *)0x0) {
    local_1028 = '\0';
    memset(local_1027,0,0xfff);
    vsprintf_s(&local_1028,0xfff,param_2,(va_list)&local_res18);
    local_1038 = 0;
    local_29 = 0;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::assign
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1),
               &local_1028);
  }
  return param_1;
}

// ==== CTotemActor@adapter::vfunc_1  @14059d430  [high:rtti-vtable]  (orig: FUN_14059d430)
void FUN_14059d430(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CTotemActor@adapter::vfunc_5  @14059d450  [high:rtti-vtable]  (orig: FUN_14059d450)
void FUN_14059d450(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014059d49a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_6  @14059d4b0  [high:rtti-vtable]  (orig: FUN_14059d4b0)
void FUN_14059d4b0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014059d4fa. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_8  @14059d510  [high:rtti-vtable]  (orig: FUN_14059d510)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_14059d510(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 local_res20;
  undefined1 auStack_438 [32];
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_438;
  if (param_3 == (char *)0x0) {
    return false;
  }
  local_res20 = param_4;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    _vsnprintf(local_418,0x400,param_3,(va_list)&local_res20);
    local_19 = 0;
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x358))((longlong *)(lVar1 + 0x10),local_418);
  }
  return lVar1 != 0;
}

// ==== CTotemActor@adapter::vfunc_9  @14059d5d0  [high:rtti-vtable]  (orig: FUN_14059d5d0)
undefined8 FUN_14059d5d0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0xffffffff;
  }
  uVar2 = FUN_140188f70(lVar1);
  return uVar2;
}

// ==== CTotemActor@adapter::vfunc_10  @14059d600  [high:rtti-vtable]  (orig: FUN_14059d600)
void FUN_14059d600(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140194ac0(lVar1,param_3);
  }
  return;
}

// ==== CTotemActor@adapter::vfunc_11  @14059d630  [high:rtti-vtable]  (orig: FUN_14059d630)
undefined8 FUN_14059d630(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return 0xffffffff;
  }
                    /* WARNING: Could not recover jumptable at 0x00014059d658. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x108))(plVar1);
  return uVar2;
}

// ==== CTotemActor@adapter::vfunc_12  @14059d660  [high:rtti-vtable]  (orig: FUN_14059d660)
undefined8 FUN_14059d660(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0xffffffff;
  }
                    /* WARNING: Could not recover jumptable at 0x00014059d68a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTotemActor@adapter::vfunc_16  @14059d690  [high:rtti-vtable]  (orig: FUN_14059d690)
void FUN_14059d690(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d6aa. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_17  @14059d6c0  [high:rtti-vtable]  (orig: FUN_14059d6c0)
void FUN_14059d6c0(void)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d6d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x200))(plVar1);
  return;
}

// ==== CTotemActor@adapter::vfunc_18  @14059d6e0  [high:rtti-vtable]  (orig: FUN_14059d6e0)
void FUN_14059d6e0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d709. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x70))(plVar1,param_2,param_3);
  return;
}

// ==== CTotemActor@adapter::vfunc_19  @14059d710  [high:rtti-vtable]  (orig: FUN_14059d710)
void FUN_14059d710(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d72a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xb8))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_20  @14059d740  [high:rtti-vtable]  (orig: FUN_14059d740)
void FUN_14059d740(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d75a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x210))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_21  @14059d770  [high:rtti-vtable]  (orig: FUN_14059d770)
void FUN_14059d770(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d78a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xf8))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_22  @14059d7a0  [high:rtti-vtable]  (orig: FUN_14059d7a0)
void FUN_14059d7a0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d7ba. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x268))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_23  @14059d7d0  [high:rtti-vtable]  (orig: FUN_14059d7d0)
void FUN_14059d7d0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d7f9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x270))(plVar1,param_2,param_3);
  return;
}

// ==== CTotemActor@adapter::vfunc_24  @14059d800  [high:rtti-vtable]  (orig: FUN_14059d800)
void FUN_14059d800(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d829. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x208))(plVar1,param_2,param_3);
  return;
}

// ==== CTotemActor@adapter::vfunc_25  @14059d830  [high:rtti-vtable]  (orig: FUN_14059d830)
void FUN_14059d830(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d84a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x18))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_26  @14059d850  [high:rtti-vtable]  (orig: FUN_14059d850)
void FUN_14059d850(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d879. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x218))(plVar1,param_2,param_3);
  return;
}

// ==== CTotemActor@adapter::vfunc_27  @14059d880  [high:rtti-vtable]  (orig: FUN_14059d880)
void FUN_14059d880(void)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d893. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x220))(plVar1);
  return;
}

// ==== CTotemActor@adapter::vfunc_28  @14059d8a0  [high:rtti-vtable]  (orig: FUN_14059d8a0)
void FUN_14059d8a0(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d8cc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1,param_2,param_3,0);
  return;
}

// ==== CTotemActor@adapter::vfunc_29  @14059d8d0  [high:rtti-vtable]  (orig: FUN_14059d8d0)
void FUN_14059d8d0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d8ea. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x280))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_30  @14059d900  [high:rtti-vtable]  (orig: FUN_14059d900)
void FUN_14059d900(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014059d91a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x288))(plVar1,param_2);
  return;
}

// ==== CTotemActor@adapter::vfunc_14  @14059d930  [high:rtti-vtable]  (orig: FUN_14059d930)
bool FUN_14059d930(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CTotemActor@adapter::vfunc_1  @14059d950  [high:rtti-vtable]  (orig: FUN_14059d950)
undefined8 FUN_14059d950(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar2 == 0) {
      return 0;
    }
    cVar1 = FUN_140332fe0(lVar2,param_3);
    if (((cVar1 != '\0') || (cVar1 = FUN_140333220(lVar2,param_3), cVar1 != '\0')) ||
       (cVar1 = FUN_1403330a0(lVar2,param_3), cVar1 != '\0')) {
      plVar3 = (longlong *)FUN_140087d40();
      lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_3);
      if (lVar2 != 0) {
        return 1;
      }
    }
    plVar3 = (longlong *)CurrentInstanceGet();
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,0x12);
    if ((plVar3 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(*plVar3 + 0x40))(plVar3,param_2,param_3,0), cVar1 != '\0')) {
      plVar3 = (longlong *)FUN_140087d40();
      lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_3);
      if (lVar2 != 0) {
        return 1;
      }
    }
    return 0;
  }
  return 0;
}

// ==== CTotemActor@adapter::vfunc_15  @14059da50  [high:rtti-vtable]  (orig: FUN_14059da50)
undefined8 FUN_14059da50(undefined8 param_1,int param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined1 local_48 [64];
  
  if ((param_2 != 0) && (param_3 != 0)) {
    plVar5 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = (longlong *)0x0;
    }
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x60))(plVar5,param_3);
    if (plVar5 != (longlong *)0x0) {
      plVar6 = (longlong *)CurrentInstanceGet();
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0x12);
      if (plVar6 != (longlong *)0x0) {
        cVar2 = (**(code **)(*plVar6 + 0x40))(plVar6,param_2,param_3,0);
        if (cVar2 != '\0') {
          plVar7 = (longlong *)FUN_140087d40();
          lVar1 = *plVar7;
          uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
          cVar2 = (**(code **)(lVar1 + 0xc0))(plVar7,uVar3,local_48);
          if (cVar2 != '\0') {
            lVar1 = *plVar6;
            uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
            uVar4 = FUN_1400fda10(plVar5,2,1);
            (**(code **)(lVar1 + 0x88))(plVar6,param_2,uVar4,uVar3,local_48);
            return 1;
          }
        }
        log_InlineLogERROR(&DAT_1406d9c10);
      }
    }
    return 0;
  }
  return 0;
}

// ==== CTotemActor@adapter::vfunc_0  @14059dbe0  [high:rtti-vtable]  (orig: FUN_14059dbe0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_14059dbe0(undefined8 param_1,int param_2,undefined4 param_3,char param_4,undefined1 param_5)

{
  undefined1 uVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 ****ppppuVar4;
  undefined1 auStack_78 [32];
  undefined4 local_58;
  undefined8 local_48;
  undefined **local_40;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_38 [8];
  undefined8 ***local_30 [3];
  ulonglong local_18;
  ulonglong local_10;
  
  local_48 = 0xfffffffffffffffe;
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  if (param_2 == 0) {
    local_58 = 0x158;
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","idItem != ID_NONE",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\adapter\\src\\totemactor.cpp"
                      );
    uVar1 = 0;
  }
  else {
    plVar3 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_58 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      plVar3 = (longlong *)0x0;
    }
    lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
    if (lVar2 == 0) {
      if (param_4 == '\0') {
        uVar1 = 0;
      }
      else {
        FUN_14059d2f0(&local_40,"UPDATE cq_item SET syndicate=%u WHERE id=%u LIMIT 1",param_3,
                      param_2);
        plVar3 = (longlong *)InstanceGet();
        ppppuVar4 = local_30;
        if (0xf < local_18) {
          ppppuVar4 = (undefined8 ****)local_30[0];
        }
        uVar1 = (**(code **)(*plVar3 + 0x30))(plVar3,ppppuVar4,param_5,1);
        local_40 = tq::CString::vftable;
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_38);
      }
    }
    else {
      FUN_140104140(lVar2,0x17,param_3,param_5);
      uVar1 = 1;
    }
  }
  return uVar1;
}

// ==== CTotemActor@adapter::vfunc_2  @14059dd40  [high:rtti-vtable]  (orig: FUN_14059dd40)
undefined8 FUN_14059dd40(undefined8 param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  char *_Format;
  undefined4 extraout_var;
  longlong *plVar4;
  
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = (longlong *)0x0;
  }
  lVar3 = (**(code **)(*plVar4 + 0x60))();
  if (lVar3 == 0) {
    return 0;
  }
  memset(param_2,0,0x80);
  *param_2 = param_3;
  uVar1 = FUN_1400fda10(lVar3,1,1);
  param_2[1] = uVar1;
  uVar1 = FUN_1400fda10(lVar3,3,1);
  param_2[3] = uVar1;
  uVar1 = FUN_1400fda10(lVar3,0x17,1);
  param_2[0x18] = uVar1;
  uVar1 = FUN_1400fda10(lVar3,8,1);
  param_2[9] = uVar1;
  uVar1 = FUN_1400fda10(lVar3,9,1);
  param_2[10] = uVar1;
  uVar1 = FUN_1400fda10(lVar3,0xc,1);
  param_2[0xd] = uVar1;
  _Format = (char *)FUN_140100430(lVar3,0x65);
  iVar2 = _snprintf((char *)(param_2 + 0x1c),0x10,_Format);
  *(undefined1 *)((longlong)param_2 + 0x7f) = 0;
  return CONCAT71((int7)(CONCAT44(extraout_var,iVar2) >> 8),1);
}

// ==== CTotemActor@adapter::vfunc_3  @14059de70  [high:rtti-vtable]  (orig: FUN_14059de70)
ulonglong FUN_14059de70(undefined8 param_1,undefined4 *param_2,longlong *param_3)

{
  undefined4 uVar1;
  int iVar2;
  ulonglong extraout_RAX;
  longlong *plVar3;
  longlong lVar4;
  ulonglong extraout_RAX_00;
  char *_Format;
  undefined4 extraout_var;
  
  if (param_3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  memset(param_2,0,0x80);
  plVar3 = (longlong *)(**(code **)(*param_3 + 8))(param_3,0);
  uVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
  *param_2 = uVar1;
  plVar3 = (longlong *)(**(code **)(*param_3 + 8))(param_3,1);
  uVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
  param_2[1] = uVar1;
  plVar3 = (longlong *)(**(code **)(*param_3 + 8))(param_3,3);
  uVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
  param_2[3] = uVar1;
  plVar3 = (longlong *)(**(code **)(*param_3 + 8))(param_3,0x17);
  uVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
  param_2[0x18] = uVar1;
  plVar3 = (longlong *)(**(code **)(*param_3 + 8))(param_3,8);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[9] = uVar1;
  plVar3 = (longlong *)(**(code **)(*param_3 + 8))(param_3,9);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[10] = uVar1;
  plVar3 = (longlong *)(**(code **)(*param_3 + 8))(param_3,0xc);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0xd] = uVar1;
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar4 = (**(code **)(*plVar3 + 0x70))(plVar3,param_2[1]);
  if (lVar4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  plVar3 = (longlong *)(**(code **)(**(longlong **)(lVar4 + 8) + 0x10))(*(longlong **)(lVar4 + 8),1)
  ;
  _Format = (char *)(**(code **)(*plVar3 + 0x78))(plVar3);
  iVar2 = _snprintf((char *)(param_2 + 0x1c),0x10,_Format);
  *(undefined1 *)((longlong)param_2 + 0x7f) = 0;
  return CONCAT71((int7)(CONCAT44(extraout_var,iVar2) >> 8),1);
}

// ==== CTotemActor@adapter::vfunc_0  @14059e040  [high:rtti-vtable]  (orig: FUN_14059e040)
void FUN_14059e040(longlong param_1)

{
  FUN_14059e0a0(param_1 + -8);
  return;
}

// ==== CTotemActor@adapter::helper_14059e0a0  @14059e0a0  [medium:callgraph-r0]  (orig: FUN_14059e0a0)
undefined8 * FUN_14059e0a0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CTotemActor::vftable;
  param_1[1] = adapter::CTotemActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CTotemActor@adapter::vfunc_7  @14059e0f0  [high:rtti-vtable]  (orig: FUN_14059e0f0)
undefined8 FUN_14059e0f0(longlong param_1,undefined8 param_2,longlong param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  undefined8 *puVar3;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    uVar1 = 0;
    if (lVar2 != 0) {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar2 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(undefined2 *)(param_3 + 8),0);
      if (puVar3 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar1 = 0;
      }
      else {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),puVar3);
        (**(code **)*puVar3)(puVar3,1);
        uVar1 = 1;
      }
    }
  }
  return uVar1;
}

// ==== CTotemActor@adapter::vfunc_4  @14059e1f0  [high:rtti-vtable]  (orig: FUN_14059e1f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

longlong * FUN_14059e1f0(undefined8 param_1,undefined4 param_2,undefined4 param_3,char param_4)

{
  longlong lVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *****pppppuVar4;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  longlong *local_468;
  undefined8 local_460;
  undefined **local_458;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_450 [8];
  undefined8 ****local_448 [3];
  ulonglong local_430;
  char local_428 [8];
  char local_420 [8];
  char local_418 [8];
  char local_410 [8];
  char local_408 [4];
  undefined1 local_404 [988];
  ulonglong local_28;
  
  local_460 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  plVar2 = (longlong *)0x0;
  local_468 = (longlong *)0x0;
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    local_478 = 0x3c0;
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar3 = plVar2;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))();
  if (lVar1 == 0) {
    if (param_4 != '\0') {
      local_428[0] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0];
      local_428[1] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[1];
      local_428[2] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[2];
      local_428[3] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[3];
      local_428[4] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[4];
      local_428[5] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[5];
      local_428[6] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[6];
      local_428[7] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[7];
      local_420[0] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[8];
      local_420[1] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[9];
      local_420[2] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[10];
      local_420[3] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0xb];
      local_420[4] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0xc];
      local_420[5] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0xd];
      local_420[6] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0xe];
      local_420[7] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0xf];
      local_418[0] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x10];
      local_418[1] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x11];
      local_418[2] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x12];
      local_418[3] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x13];
      local_418[4] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x14];
      local_418[5] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x15];
      local_418[6] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x16];
      local_418[7] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x17];
      local_410[0] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x18];
      local_410[1] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x19];
      local_410[2] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x1a];
      local_410[3] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x1b];
      local_410[4] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x1c];
      local_410[5] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x1d];
      local_410[6] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x1e];
      local_410[7] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x1f];
      local_408[0] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x20];
      local_408[1] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x21];
      local_408[2] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x22];
      local_408[3] = s_SELECT___FROM_cq_item_WHERE_id___1407aeb10[0x23];
      memset(local_404,0,0x3dc);
      FUN_14059d2f0(&local_458,local_428,param_2);
      plVar3 = (longlong *)InstanceGet();
      pppppuVar4 = local_448;
      if (0xf < local_430) {
        pppppuVar4 = (undefined8 *****)local_448[0];
      }
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,pppppuVar4,1);
      if (plVar3 != (longlong *)0x0) {
        lVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
        if (lVar1 != 0) {
          plVar2 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,param_3);
          plVar2 = (longlong *)(**(code **)(*plVar2 + 0x58))(plVar2);
          local_468 = plVar2;
        }
        (**(code **)*plVar3)(plVar3);
      }
      local_458 = tq::CString::vftable;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_450);
    }
  }
  else {
    plVar2 = (longlong *)FUN_1400fdb80(lVar1,param_3,1);
  }
  return plVar2;
}

// ==== CTotemActor@adapter::vfunc_13  @14059e3a0  [high:rtti-vtable]  (orig: FUN_14059e3a0)
bool FUN_14059e3a0(longlong param_1,int param_2,longlong *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  ulonglong *puVar3;
  char cVar4;
  int iVar5;
  longlong lVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  uint uVar11;
  undefined4 local_res8 [2];
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined1 local_58 [8];
  undefined1 local_50 [24];
  longlong *local_38;
  longlong *local_30;
  ulonglong uVar12;
  
  FUN_140036640(param_3);
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar6 + 0x90),local_58);
  uVar10 = 0;
  uVar12 = uVar10;
LAB_14059e430:
  do {
    do {
      uVar11 = (uint)uVar12;
      cVar4 = FUN_1400ce310(local_50);
      while( true ) {
        if (cVar4 == '\0') goto LAB_14059e65e;
        cVar4 = (**(code **)(*local_38 + 0x298))(local_38,0x1001,&local_30);
        if (cVar4 != '\0') break;
        cVar4 = FUN_1400ce310(local_50);
      }
      uVar11 = uVar11 + 1;
      uVar12 = (ulonglong)uVar11;
      if (1000000 < uVar11) {
        log_InlineLogERROR(&DAT_1406d9c10);
LAB_14059e65e:
        return uVar11 < 1000000;
      }
      if (local_30 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar5 = (**(code **)(local_30[2] + 0x170))(local_30 + 2);
    } while (iVar5 != param_2);
    if (local_30 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    local_res8[0] = (**(code **)(*local_30 + 8))();
    puVar1 = (undefined4 *)param_3[3];
    uVar8 = uVar10;
    if (puVar1 != (undefined4 *)0x0) {
      uVar8 = param_3[5] - (longlong)puVar1 >> 2;
    }
    puVar2 = (undefined4 *)param_3[4];
    if (uVar8 <= (ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 2)) {
      if (puVar2 < puVar1) {
        _invalid_parameter_noinfo();
      }
      uVar8 = param_3[3];
      lVar6 = *param_3;
      uVar7 = uVar10;
      if ((param_3[4] - uVar8 & 0xfffffffffffffffc) != 0) {
        if ((ulonglong)param_3[4] < uVar8) {
          _invalid_parameter_noinfo();
        }
        if ((lVar6 == 0) || (lVar6 != *param_3)) {
          _invalid_parameter_noinfo();
        }
        uVar7 = (longlong)((longlong)puVar2 - uVar8) >> 2;
      }
      local_78 = (undefined4)lVar6;
      uStack_74 = (undefined4)((ulonglong)lVar6 >> 0x20);
      uStack_70 = SUB84(puVar2,0);
      uStack_6c = (undefined4)((ulonglong)puVar2 >> 0x20);
      local_68 = local_78;
      uStack_64 = uStack_74;
      uStack_60 = uStack_70;
      uStack_5c = uStack_6c;
      FUN_140036c20(param_3,&local_68,1,local_res8);
      uVar8 = param_3[3];
      if ((ulonglong)param_3[4] < uVar8) {
        _invalid_parameter_noinfo();
      }
      puVar3 = (ulonglong *)*param_3;
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar9 = uVar10;
      }
      else {
        uVar9 = *puVar3;
      }
      uVar8 = uVar8 + uVar7 * 4;
      if (uVar8 <= *(ulonglong *)(uVar9 + 0x20)) break;
      goto LAB_14059e629;
    }
    *puVar2 = local_res8[0];
    param_3[4] = (longlong)(puVar2 + 1);
  } while( true );
  uVar7 = uVar10;
  if (puVar3 != (ulonglong *)0x0) {
    uVar7 = *puVar3;
  }
  if (uVar8 < *(ulonglong *)(uVar7 + 0x18)) {
LAB_14059e629:
    _invalid_parameter_noinfo();
  }
  goto LAB_14059e430;
}

