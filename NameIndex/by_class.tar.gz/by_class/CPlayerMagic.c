// ==== CPlayerMagic::helper_1400fd800  @1400fd800  [medium:callgraph-r0]  (orig: FUN_1400fd800)
longlong FUN_1400fd800(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x210);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CPlayerMagic::helper_1400ff460  @1400ff460  [medium:callgraph-r3]  (orig: FUN_1400ff460)
ulonglong FUN_1400ff460(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  int iVar5;
  int local_res8 [2];
  
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4);
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  if ((int)uVar3 == 0) {
    return uVar3;
  }
  uVar4 = 0;
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),8);
  local_res8[0] = (**(code **)(*plVar2 + 0x48))(plVar2);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),9);
  local_res8[1] = (**(code **)(*plVar2 + 0x48))(plVar2);
  uVar3 = uVar4;
  do {
    iVar1 = local_res8[uVar4];
    if ((iVar1 != 0) && (iVar1 != 0xff)) {
      iVar5 = (int)uVar3;
      if (iVar1 == 0x3d) {
        uVar3 = (ulonglong)(iVar5 + 0xf);
      }
      else if (iVar1 == 0x3e) {
        uVar3 = (ulonglong)(iVar5 + 0x1e);
      }
      else if (iVar1 == 0x3f) {
        uVar3 = (ulonglong)(iVar5 + 0x32);
      }
    }
    uVar4 = uVar4 + 1;
  } while ((longlong)uVar4 < 2);
  return uVar3;
}

// ==== CPlayerMagic::helper_1401009d0  @1401009d0  [medium:callgraph-r2]  (orig: FUN_1401009d0)
ulonglong FUN_1401009d0(longlong param_1,undefined8 param_2,char param_3)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  uint uVar4;
  
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4);
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  if ((int)uVar3 == 0) {
    return uVar3;
  }
  if (param_3 == '\0') {
    uVar3 = FUN_1400ff460(param_1);
    return uVar3;
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),8);
  iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  uVar4 = 0;
  if ((iVar1 != 0) && (uVar4 = 0, iVar1 != 0xff)) {
    if (iVar1 == 0x3d) {
      uVar4 = 0xf;
    }
    else {
      if (iVar1 == 0x3e) {
        return 0x1e;
      }
      if (iVar1 == 0x3f) {
        return 0x32;
      }
    }
  }
  return (ulonglong)uVar4;
}

// ==== CPlayerMagic::helper_140160520  @140160520  [medium:callgraph-r0]  (orig: FUN_140160520)
void FUN_140160520(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x12b8) = param_2;
  return;
}

// ==== CPlayerMagic::helper_140161590  @140161590  [medium:callgraph-r0]  (orig: FUN_140161590)
void FUN_140161590(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xa7c) = param_2;
  return;
}

// ==== CPlayerMagic::helper_140178c40  @140178c40  [medium:callgraph-r0]  (orig: FUN_140178c40)
ulonglong FUN_140178c40(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  
  uVar3 = 0;
  if (*(longlong *)(param_1 + 0x1100) != 0) {
    plVar1 = *(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x1100) + 0x58) + 8);
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
    uVar2 = (**(code **)(*plVar1 + 0x58))(plVar1);
    uVar3 = uVar2 >> 0x26;
    if ((uVar3 & 1) != 0) {
      return CONCAT71((uint7)(uVar2 >> 0x2e),1);
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CPlayerMagic::helper_140180d80  @140180d80  [medium:callgraph-r1]  (orig: FUN_140180d80)
int FUN_140180d80(longlong *param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  ulonglong uVar4;
  longlong lVar5;
  int iVar6;
  int iVar7;
  undefined8 uVar8;
  
  iVar7 = 0;
  if (param_1[0x220] != 0) {
    plVar3 = *(longlong **)(*(longlong *)(param_1[0x220] + 0x58) + 8);
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
    uVar4 = (**(code **)(*plVar3 + 0x58))(plVar3);
    if ((uVar4 >> 0x26 & 1) != 0) {
      uVar8 = 1;
      goto LAB_140180dd6;
    }
  }
  uVar8 = 0;
LAB_140180dd6:
  iVar6 = 1;
  do {
    plVar3 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar5 = *plVar3;
    uVar1 = FUN_14032b4b0(param_1,iVar6);
    lVar5 = (**(code **)(lVar5 + 0x60))(plVar3,uVar1);
    if (lVar5 != 0) {
      uVar1 = (**(code **)(*param_1 + 8))(param_1);
      iVar2 = FUN_1401009d0(lVar5,uVar1,uVar8);
      iVar7 = iVar7 + iVar2;
    }
    iVar6 = iVar6 + 1;
  } while (iVar6 < 0x14);
  return iVar7;
}

// ==== CPlayerMagic::helper_1402ed280  @1402ed280  [medium:callgraph-r2]  (orig: FUN_1402ed280)
void FUN_1402ed280(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402ed2a4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CPlayerMagic::helper_1403e9290  @1403e9290  [medium:callgraph-r0]  (orig: FUN_1403e9290)
ulonglong FUN_1403e9290(longlong *param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  ulonglong in_RAX;
  longlong *plVar5;
  undefined4 extraout_var;
  
  if (param_1 != (longlong *)0x0) {
    in_RAX = (**(code **)(*param_1 + 0x2d8))(param_1,0xa0);
    if ((char)in_RAX != '\0') {
      plVar5 = (longlong *)FUN_1401181a0();
      lVar1 = *plVar5;
      uVar2 = (**(code **)(*param_1 + 0x10))(param_1);
      iVar3 = (**(code **)(lVar1 + 0xb0))(plVar5,uVar2,0xa0);
      iVar4 = tq::RandGet(10000);
      return CONCAT71((int7)(CONCAT44(extraout_var,iVar4) >> 8),iVar4 <= iVar3);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CPlayerMagic::helper_1403f0020  @1403f0020  [medium:callgraph-r1]  (orig: FUN_1403f0020)
undefined8
FUN_1403f0020(longlong param_1,undefined1 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 param_5)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  *(undefined4 *)(param_1 + 8) = 0x450;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 10) = param_2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
  **(undefined4 **)(param_1 + 0x428) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_5;
  return 1;
}

// ==== CPlayerMagic::helper_1404183d0  @1404183d0  [medium:callgraph-r0]  (orig: FUN_1404183d0)
undefined8 FUN_1404183d0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return 0;
}

// ==== CPlayerMagic::helper_1404183f0  @1404183f0  [medium:callgraph-r0]  (orig: FUN_1404183f0)
bool FUN_1404183f0(longlong param_1,longlong param_2)

{
  *(longlong *)(param_1 + 8) = param_2;
  return param_2 != 0;
}

// ==== CPlayerMagic::helper_140418400  @140418400  [medium:callgraph-r0]  (orig: FUN_140418400)
bool FUN_140418400(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)InstanceGet();
  lVar2 = (**(code **)(*plVar1 + 0x20))(plVar1,"cq_magic");
  *(longlong *)(param_1 + 8) = lVar2;
  return lVar2 != 0;
}

// ==== CPlayerMagic::helper_140418430  @140418430  [medium:callgraph-r0]  (orig: FUN_140418430)
void FUN_140418430(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0);
                    /* WARNING: Could not recover jumptable at 0x00014041844a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1);
  return;
}

// ==== CPlayerMagic::helper_140418450  @140418450  [medium:callgraph-r0]  (orig: FUN_140418450)
undefined8 FUN_140418450(longlong param_1)

{
  undefined8 uVar1;
  
  if ((*(char *)(param_1 + 0x24) == '\0') && (*(char *)(param_1 + 0x26) == '\0')) {
                    /* WARNING: Could not recover jumptable at 0x000140418465. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
    return uVar1;
  }
  return 1;
}

// ==== CPlayerMagic::helper_140418480  @140418480  [medium:callgraph-r0]  (orig: FUN_140418480)
undefined1 FUN_140418480(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x25);
}

// ==== CPlayerMagic::helper_140418490  @140418490  [medium:callgraph-r0]  (orig: FUN_140418490)
void FUN_140418490(longlong param_1,undefined1 param_2)

{
  longlong *plVar1;
  
  if (*(char *)(param_1 + 0x26) == '\0') {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
    (**(code **)(*plVar1 + 0x48))(plVar1);
                    /* WARNING: Could not recover jumptable at 0x0001404184bf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR(&DAT_140774130);
    return;
  }
  *(undefined1 *)(param_1 + 0x25) = param_2;
  return;
}

// ==== CPlayerMagic::helper_1404184d0  @1404184d0  [medium:callgraph-r0]  (orig: FUN_1404184d0)
undefined1 FUN_1404184d0(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x26);
}

// ==== CPlayerMagic::helper_1404184e0  @1404184e0  [medium:callgraph-r0]  (orig: FUN_1404184e0)
void FUN_1404184e0(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x26) = param_2;
  return;
}

// ==== CPlayerMagic::helper_1404187b0  @1404187b0  [medium:callgraph-r0]  (orig: FUN_1404187b0)
bool FUN_1404187b0(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x20));
  lVar5 = *(longlong *)(lVar4 + 0x100);
  if (*(longlong *)(lVar4 + 0x100) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar5 = 0;
  }
  lVar5 = FUN_1402f0fe0(lVar5,uVar1,uVar2);
  *(longlong *)(param_1 + 0x10) = lVar5;
  return lVar5 != 0;
}

// ==== CPlayerMagic::helper_140418c50  @140418c50  [medium:callgraph-r0]  (orig: FUN_140418c50)
undefined8 FUN_140418c50(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    cVar1 = FUN_1404187b0();
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),1);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
      plVar4 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
      (**(code **)(*plVar2 + 0x40))(plVar2);
      (**(code **)(*plVar3 + 0x48))(plVar3);
      (**(code **)(*plVar4 + 0x48))(plVar4);
      log_InlineLogDBERROR(&DAT_140774350);
      return 0;
    }
  }
  if (param_2 < 100) {
    plVar2 = *(longlong **)(param_1 + 8);
  }
  else {
    plVar2 = *(longlong **)(param_1 + 0x10);
    param_2 = param_2 + -100;
  }
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,param_2);
                    /* WARNING: Could not recover jumptable at 0x000140418d83. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar5 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar5;
}

// ==== CPlayerMagic::helper_140418d90  @140418d90  [medium:callgraph-r0]  (orig: FUN_140418d90)
void FUN_140418d90(longlong param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  longlong *plVar2;
  
  if (99 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),param_2);
  (**(code **)(*plVar2 + 0xb0))(plVar2,param_3);
  if (param_2 == 3) {
    cVar1 = FUN_1404187b0(param_1);
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  return;
}

// ==== CPlayerMagic::helper_140418e40  @140418e40  [medium:callgraph-r0]  (orig: FUN_140418e40)
undefined8 FUN_140418e40(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    cVar1 = FUN_1404187b0();
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
      (**(code **)(*plVar2 + 0x48))(plVar2);
      (**(code **)(*plVar3 + 0x48))(plVar3);
      log_InlineLogDBERROR(&DAT_140774318);
      return 0;
    }
  }
  if (param_2 < 100) {
    plVar2 = *(longlong **)(param_1 + 8);
  }
  else {
    plVar2 = *(longlong **)(param_1 + 0x10);
    param_2 = param_2 + -100;
  }
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,param_2);
                    /* WARNING: Could not recover jumptable at 0x000140418f13. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar4 = (**(code **)(*plVar2 + 0x50))(plVar2);
  return uVar4;
}

// ==== CPlayerMagic::helper_140418f20  @140418f20  [medium:callgraph-r0]  (orig: FUN_140418f20)
void FUN_140418f20(longlong param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  longlong *plVar2;
  
  if (99 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),param_2);
  (**(code **)(*plVar2 + 0xa8))(plVar2,param_3);
  if (param_2 == 3) {
    cVar1 = FUN_1404187b0(param_1);
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  return;
}

// ==== CPlayerMagic::helper_140456fe0  @140456fe0  [medium:callgraph-r0]  (orig: FUN_140456fe0)
ulonglong FUN_140456fe0(longlong param_1,undefined2 param_2,int param_3,undefined2 param_4,
                       undefined4 param_5,undefined1 param_6,undefined4 param_7,undefined4 param_8)

{
  ulong uVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  undefined4 extraout_var;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(int *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_4;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_5;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = param_2;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_6;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_7;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_8;
    uVar1 = tq::TimeGet(0);
    **(ulong **)(param_1 + 0x428) = uVar1;
    *(undefined4 *)(param_1 + 8) = 0x44f;
    *(undefined4 *)(param_1 + 0xc) = 0x1c;
    uVar2 = CONCAT71((int7)(CONCAT44(extraout_var,uVar1) >> 8),1);
  }
  return uVar2;
}

// ==== CPlayerMagic::helper_140457240  @140457240  [medium:callgraph-r0]  (orig: FUN_140457240)
ulonglong FUN_140457240(longlong param_1,undefined2 param_2,int param_3,undefined1 param_4,
                       undefined4 param_5,undefined4 param_6)

{
  ulong uVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  undefined4 extraout_var;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(int *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = param_2;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_4;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_5;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_6;
    uVar1 = tq::TimeGet(0);
    **(ulong **)(param_1 + 0x428) = uVar1;
    *(undefined4 *)(param_1 + 8) = 0x44f;
    *(undefined4 *)(param_1 + 0xc) = 0x1c;
    uVar2 = CONCAT71((int7)(CONCAT44(extraout_var,uVar1) >> 8),1);
  }
  return uVar2;
}

// ==== CPlayerMagic::vfunc_1  @140480a30  [high:rtti-vtable]  (orig: FUN_140480a30)
void FUN_140480a30(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140480a3a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
  return;
}

// ==== CPlayerMagic::helper_1404810d0  @1404810d0  [medium:callgraph-r0]  (orig: FUN_1404810d0)
uint FUN_1404810d0(longlong param_1,longlong param_2,undefined1 param_3)

{
  uint extraout_EAX;
  uint extraout_EAX_00;
  int iVar1;
  uint uVar2;
  
  if (*(longlong *)(param_1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_EAX;
  }
  else {
    if (param_2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return extraout_EAX_00 & 0xffffff00;
    }
    iVar1 = FUN_140418c50(*(longlong *)(param_1 + 0x90),0x68);
    uVar2 = 0;
    if (iVar1 != 0) {
      uVar2 = FUN_1401b9c20(*(undefined8 *)(param_1 + 0x1c8),param_2,param_3);
      return uVar2;
    }
  }
  return uVar2 & 0xffffff00;
}

// ==== CPlayerMagic::helper_1404811b0  @1404811b0  [medium:callgraph-r1]  (orig: FUN_1404811b0)
ulonglong FUN_1404811b0(longlong param_1,ulonglong param_2)

{
  int iVar1;
  int iVar2;
  ulonglong extraout_RAX;
  longlong lVar3;
  ulonglong uVar4;
  
  if (*(longlong *)(param_1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  iVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x70))
                    (*(longlong *)(param_1 + 0x1c8) + 0x10);
  iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x78);
  if (((iVar2 <= iVar1) &&
      (iVar1 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x76), iVar1 != -1)) &&
     (iVar1 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x76), iVar1 != 0)) {
    lVar3 = FUN_140418fd0(*(undefined8 *)(param_1 + 0x90),0x75);
    if ((lVar3 != 0) &&
       (uVar4 = FUN_140418fd0(*(undefined8 *)(param_1 + 0x90),0x75), (param_2 & uVar4) == 0)) {
      return 0;
    }
    return 1;
  }
  return 0;
}

// ==== CPlayerMagic::helper_140482560  @140482560  [medium:callgraph-r0]  (orig: FUN_140482560)
undefined8 FUN_140482560(longlong param_1)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  longlong *plVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  longlong local_res8;
  
  if (*(longlong *)(param_1 + 0x1c8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar3 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x74);
    if (iVar3 == 0x59) {
      plVar6 = (longlong *)
               (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x2a8))
                         (*(longlong *)(param_1 + 0x1c8) + 0x10,*(undefined4 *)(param_1 + 0x98));
      if ((plVar6 != (longlong *)0x0) &&
         (cVar2 = (**(code **)(*plVar6 + 0x220))(plVar6), cVar2 != '\0')) {
        local_res8 = 0;
        cVar2 = (**(code **)(*plVar6 + 0x298))(plVar6,0x1001,&local_res8);
        if ((cVar2 != '\0') && (local_res8 != 0)) {
          uVar4 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),3);
          cVar2 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x2d8))(local_res8 + 0x10,0x59);
          if (cVar2 != '\0') {
            plVar6 = (longlong *)FUN_1401181a0();
            uVar5 = (**(code **)(*plVar6 + 0xa0))(plVar6,*(undefined4 *)(param_1 + 0x98),0x59);
            if (uVar4 < uVar5) {
              pIVar7 = theInstance();
              lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
              uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_MAGIC_SHIELD_FAILED");
              (**(code **)(lVar1 + 0x358))(*(longlong *)(param_1 + 0x1c8) + 0x10,uVar8);
              return 0;
            }
          }
          return 1;
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CPlayerMagic::DropMagicAllEffect  @140482c80  [high:log-string]  (orig: FUN_140482c80)
void FUN_140482c80(longlong param_1,undefined8 param_2,longlong param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  iVar4 = 1;
  uVar3 = 2;
  do {
    uVar1 = FUN_140418e40(param_3,8);
    if (uVar1 == 1) {
      return;
    }
    if ((uVar1 & uVar3) != 0) {
      uVar1 = FUN_140418e40(param_3,10);
      if (uVar1 == 0) {
        return;
      }
      if ((uVar1 & uVar3) != 0) {
        uVar1 = FUN_140418e40(param_3,9);
        if ((uVar3 & uVar1) == 0) {
          iVar2 = FUN_140340e50(*(undefined8 *)(param_1 + 0x1c8),0x2dd5b6,0,1,1,0,1);
          if (iVar2 == 0) {
            (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
            log_InlineLogERROR(
                              "CPlayerMagic::DropMagicAllEffect(), user:%u, magictype:%d, effecttype:%u award item failed."
                              );
          }
        }
        else {
          iVar2 = FUN_140340e50(*(undefined8 *)(param_1 + 0x1c8),0x2dd5b6,1,1,1,0,1);
          if (iVar2 == 0) {
            (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
            log_InlineLogERROR(
                              "CPlayerMagic::DropMagicAllEffect(), user:%u, magictype:%d, effecttype:%u award molonoly item failed."
                              );
          }
        }
      }
    }
    iVar4 = iVar4 + 1;
    uVar3 = uVar3 << 1 | (uint)((int)uVar3 < 0);
  } while (iVar4 < 0x20);
  return;
}

// ==== CPlayerMagic::helper_140483270  @140483270  [medium:callgraph-r0]  (orig: FUN_140483270)
void FUN_140483270(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  char cVar2;
  undefined2 uVar3;
  undefined2 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong *local_res10;
  
  if (param_2 != (longlong *)0x0) {
    local_res10 = (longlong *)0x0;
    (**(code **)(*param_2 + 0x298))(param_2,0x1001,&local_res10);
    if ((((*(longlong *)(param_1 + 0x1c8) != 0) && (cVar2 = FUN_140167b70(), cVar2 != '\0')) &&
        (local_res10 != (longlong *)0x0)) && (cVar2 = FUN_140167b70(), cVar2 == '\0')) {
      uVar5 = (**(code **)(local_res10[2] + 0x168))(local_res10 + 2);
      uVar3 = (**(code **)(local_res10[2] + 0x40))(local_res10 + 2);
      uVar4 = (**(code **)(local_res10[2] + 0x48))(local_res10 + 2);
      plVar8 = (longlong *)FUN_140087ed0();
      lVar1 = *plVar8;
      uVar6 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
      uVar7 = (**(code **)(*local_res10 + 8))();
      (**(code **)(lVar1 + 0x2d8))(plVar8,uVar7,uVar6,uVar5,uVar3,uVar4);
    }
  }
  return;
}

// ==== CPlayerMagic::helper_140483500  @140483500  [medium:callgraph-r2]  (orig: FUN_140483500)
void FUN_140483500(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CPlayerMagic::helper_1404836b0  @1404836b0  [medium:callgraph-r2]  (orig: FUN_1404836b0)
void FUN_1404836b0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CPlayerMagic::helper_1404839b0  @1404839b0  [medium:callgraph-r2]  (orig: FUN_1404839b0)
void FUN_1404839b0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001404839d4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CPlayerMagic::helper_140483de0  @140483de0  [medium:callgraph-r2]  (orig: FUN_140483de0)
void FUN_140483de0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x25) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x25) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x25);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x25);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x25);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x25);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140483e04. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CPlayerMagic::helper_140484270  @140484270  [medium:callgraph-r0]  (orig: FUN_140484270)
void FUN_140484270(void *param_1)

{
  if ((DAT_1409764c8 & 1) == 0) {
    DAT_1409764c8 = DAT_1409764c8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409764c0,"CPlayerMagic");
    atexit((_func_5014 *)&LAB_1406d6ed0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404842c5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409764c0,param_1);
  return;
}

// ==== CPlayerMagic::helper_140485cd0  @140485cd0  [medium:callgraph-r2]  (orig: FUN_140485cd0)
void FUN_140485cd0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CPlayerMagic::helper_140485d90  @140485d90  [medium:callgraph-r2]  (orig: FUN_140485d90)
void FUN_140485d90(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CPlayerMagic::helper_140486050  @140486050  [medium:callgraph-r2]  (orig: FUN_140486050)
void FUN_140486050(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x25) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CPlayerMagic::helper_1404860b0  @1404860b0  [medium:callgraph-r2]  (orig: FUN_1404860b0)
void FUN_1404860b0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x25) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CPlayerMagic::helper_140488130  @140488130  [medium:callgraph-r0]  (orig: FUN_140488130)
void FUN_140488130(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140488130(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CPlayerMagic::helper_140488180  @140488180  [medium:callgraph-r1]  (orig: FUN_140488180)
void FUN_140488180(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140488180(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CPlayerMagic::helper_140488240  @140488240  [medium:callgraph-r2]  (orig: FUN_140488240)
undefined8 *
FUN_140488240(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CPlayerMagic::helper_140488490  @140488490  [medium:callgraph-r1]  (orig: FUN_140488490)
void FUN_140488490(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CPlayerMagic::helper_1404884f0  @1404884f0  [medium:callgraph-r2]  (orig: FUN_1404884f0)
void FUN_1404884f0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x25);
  while (cVar1 == '\0') {
    FUN_1404884f0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x25);
  }
  return;
}

// ==== CPlayerMagic::helper_140488540  @140488540  [medium:callgraph-r1]  (orig: FUN_140488540)
void FUN_140488540(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x24) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x25) = 0;
  return;
}

// ==== CPlayerMagic::helper_1404885a0  @1404885a0  [medium:callgraph-r1]  (orig: FUN_1404885a0)
void FUN_1404885a0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CPlayerMagic::helper_140488c10  @140488c10  [medium:callgraph-r1]  (orig: FUN_140488c10)
void FUN_140488c10(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140488130(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CPlayerMagic::helper_140488c90  @140488c90  [medium:callgraph-r1]  (orig: FUN_140488c90)
void FUN_140488c90(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140488180(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CPlayerMagic::helper_140488ee0  @140488ee0  [medium:callgraph-r1]  (orig: FUN_140488ee0)
undefined8 * FUN_140488ee0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x25) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140483de0(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x25) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x24);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x24);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_1404890cc;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x25);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x25);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x25);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x25);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_1404890cc:
  if (*(char *)((longlong)plVar5 + 0x24) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x24) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x24) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x24) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x24) = 0;
            FUN_140486050(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
            if ((*(char *)(*plVar11 + 0x24) != '\x01') || (*(char *)(plVar11[2] + 0x24) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x24) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x24) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
                FUN_1404860b0(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x24) = *(undefined1 *)((longlong)plVar10 + 0x24);
              *(undefined1 *)((longlong)plVar10 + 0x24) = 1;
              *(undefined1 *)(plVar11[2] + 0x24) = 1;
              FUN_140486050(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x24) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x24) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x24) = 0;
            FUN_1404860b0(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
            if ((*(char *)(plVar11[2] + 0x24) != '\x01') || (*(char *)(*plVar11 + 0x24) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x24) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x24) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
                FUN_140486050(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x24) = *(undefined1 *)((longlong)plVar10 + 0x24);
              *(undefined1 *)((longlong)plVar10 + 0x24) = 1;
              *(undefined1 *)(*plVar11 + 0x24) = 1;
              FUN_1404860b0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x24) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CPlayerMagic::helper_1404892a0  @1404892a0  [medium:callgraph-r1]  (orig: FUN_1404892a0)
void FUN_1404892a0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x25);
  while (cVar1 == '\0') {
    FUN_1404884f0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x25);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CPlayerMagic::helper_1404898e0  @1404898e0  [medium:callgraph-r1]  (orig: FUN_1404898e0)
undefined8 *
FUN_1404898e0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140488240(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CPlayerMagic::helper_140489c40  @140489c40  [medium:callgraph-r0]  (orig: FUN_140489c40)
longlong * FUN_140489c40(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1404892a0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x25) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x25) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x25);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x25);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x25);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x25);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140488ee0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CPlayerMagic::helper_14048b5f0  @14048b5f0  [medium:callgraph-r0]  (orig: FUN_14048b5f0)
longlong FUN_14048b5f0(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  
  plVar2 = *(longlong **)(param_1 + 8);
  plVar6 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2))
    {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar6) {
      return 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = plVar6[4];
    if ((lVar7 != 0) && (iVar5 = FUN_140418c50(lVar7,2), iVar5 == param_2)) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar6 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar6 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x29);
        plVar4 = (longlong *)plVar6[1];
        plVar3 = plVar6;
        while ((plVar6 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar4 = (longlong *)plVar6[1];
          plVar3 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return lVar7;
}

// ==== CPlayerMagic::helper_14048b710  @14048b710  [medium:callgraph-r0]  (orig: FUN_14048b710)
longlong FUN_14048b710(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  
  plVar2 = *(longlong **)(param_1 + 0x48);
  plVar6 = (longlong *)**(undefined8 **)(param_1 + 0x78);
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x78);
    if ((*(longlong **)(param_1 + 0x48) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0x48) != plVar2)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar6) {
      return 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = plVar6[4];
    if ((lVar7 != 0) && (iVar5 = FUN_140418c50(lVar7,2), iVar5 == param_2)) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar6 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar6 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x29);
        plVar4 = (longlong *)plVar6[1];
        plVar3 = plVar6;
        while ((plVar6 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar4 = (longlong *)plVar6[1];
          plVar3 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return lVar7;
}

// ==== CPlayerMagic::DropMagicEffect  @14048c4c0  [high:log-string]  (orig: FUN_14048c4c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14048c4c0(longlong param_1,undefined4 param_2,byte param_3)

{
  byte bVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong lVar10;
  longlong *plVar11;
  uint uVar12;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  lVar10 = *(longlong *)(param_1 + 0x1c8);
  if (lVar10 == 0) {
    uVar9 = 0;
  }
  else if ((*(longlong *)(lVar10 + 0xc28) - *(longlong *)(lVar10 + 0xc20) >> 2) + 1U < 0x29) {
    lVar10 = FUN_14048b5f0(param_1);
    uVar9 = 0;
    if (lVar10 != 0) {
      uVar12 = 1 << (param_3 & 0x1f);
      uVar3 = FUN_140418e40(lVar10,8);
      if ((uVar12 & uVar3) == 0) {
        uVar9 = 0;
      }
      else {
        uVar4 = FUN_140418e40(lVar10,10);
        if ((uVar12 & uVar4) == 0) {
          uVar9 = 0;
        }
        else if ((uVar3 < uVar12) || (uVar4 < uVar12)) {
          uVar9 = 0;
        }
        else {
          bVar1 = FUN_140418c50(lVar10,7);
          if (bVar1 == param_3) {
            FUN_140418d90(lVar10,7);
          }
          FUN_140418f20(lVar10,8,uVar3 - uVar12);
          FUN_140418f20(lVar10,10);
          uVar3 = FUN_140418e40(lVar10,9);
          if ((uVar12 & uVar3) == 0) {
            local_498 = 1;
            local_4a0 = 0;
            local_4a8 = 1;
            iVar5 = FUN_140340e50(*(undefined8 *)(param_1 + 0x1c8),0x2dd5b6,0,1);
            if (iVar5 == 0) {
              (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
              log_InlineLogERROR(
                                "CPlayerMagic::DropMagicEffect(), user:%u, magictype:%d, effecttype:%u award item failed."
                                );
              return 0;
            }
          }
          else {
            FUN_140418f20(lVar10,9,uVar3 - uVar12);
            local_498 = 1;
            local_4a0 = 0;
            local_4a8 = 1;
            iVar5 = FUN_140340e50(*(undefined8 *)(param_1 + 0x1c8),0x2dd5b6,1,1);
            if (iVar5 == 0) {
              (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
              log_InlineLogERROR(
                                "CPlayerMagic::DropMagicEffect(), user:%u, magictype:%d, effecttype:%u award molonoly item failed."
                                );
              return 0;
            }
          }
          FUN_140418450(lVar10);
          FUN_140456f30(local_478);
          uVar6 = FUN_140418e40(lVar10,10);
          uVar7 = FUN_140418e40(lVar10,8);
          uVar8 = FUN_140418e40(lVar10,7);
          local_4a8 = uVar7;
          local_4a0 = uVar6;
          cVar2 = FUN_140457240(local_478,6,param_2,uVar8);
          if (cVar2 != '\0') {
            plVar11 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
            (**(code **)(*plVar11 + 0x350))(plVar11,local_478);
          }
          FUN_140456f80(local_478);
          uVar9 = 1;
        }
      }
    }
  }
  else {
    uVar9 = 0;
  }
  return uVar9;
}

// ==== CPlayerMagic::helper_14048cf30  @14048cf30  [medium:callgraph-r0]  (orig: FUN_14048cf30)
ulonglong FUN_14048cf30(longlong param_1,char param_2)

{
  uint uVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  longlong lVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong *plVar10;
  undefined8 uVar11;
  uint uVar12;
  undefined8 uVar13;
  
  uVar12 = (uint)*(byte *)(*(longlong *)(param_1 + 0x1c8) + 0xeee);
  uVar1 = uVar12 / 10;
  if (uVar1 == 0xd) {
    uVar11 = 0x3052;
    uVar13 = 0xac;
  }
  else {
    if (uVar1 != 0xe) {
      return (ulonglong)uVar12 * 0xcccccccd & 0xffffffff;
    }
    uVar11 = 0x305c;
    uVar13 = 0xad;
  }
  if (param_2 == '\0') {
    plVar10 = (longlong *)FUN_1401181a0(param_1,uVar11);
    lVar7 = *plVar10;
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
    iVar6 = (**(code **)(lVar7 + 0xa0))(plVar10,uVar3,uVar13);
    plVar10 = (longlong *)FUN_1401181a0();
    lVar7 = *plVar10;
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
    uVar9 = (**(code **)(lVar7 + 0xa8))(plVar10,uVar3,uVar13,(iVar6 / 1000) * 1000);
  }
  else {
    lVar7 = FUN_14048b5f0();
    uVar9 = 0;
    if (lVar7 != 0) {
      plVar10 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar10 = (longlong *)0x0;
      }
      lVar8 = *plVar10;
      uVar3 = FUN_14032d440(*(undefined8 *)(param_1 + 0x1c8));
      lVar8 = (**(code **)(lVar8 + 0x60))(plVar10,uVar3);
      uVar9 = 0;
      if ((lVar8 != 0) && (uVar9 = FUN_1400ff9e0(lVar8), (int)uVar9 == 0x26c)) {
        uVar3 = FUN_140418c50(lVar7,0x89);
        plVar10 = (longlong *)FUN_1401181a0();
        lVar8 = *plVar10;
        uVar4 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
        cVar2 = (**(code **)(lVar8 + 0x60))(plVar10,uVar4,uVar13);
        if (cVar2 == '\0') {
          uVar4 = FUN_140418c50(lVar7,0x88);
          plVar10 = (longlong *)FUN_1401181a0();
          lVar7 = *plVar10;
          uVar5 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
          uVar9 = (**(code **)(lVar7 + 8))(plVar10,uVar5,uVar13,0,uVar4,0,0,0,0,0,uVar3);
        }
        else {
          plVar10 = (longlong *)FUN_1401181a0();
          lVar7 = *plVar10;
          uVar4 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
          uVar9 = (**(code **)(lVar7 + 0xa8))(plVar10,uVar4,uVar13,uVar3);
        }
      }
    }
  }
  return uVar9;
}

// ==== CPlayerMagic::helper_14048d1a0  @14048d1a0  [medium:callgraph-r0]  (orig: FUN_14048d1a0)
void FUN_14048d1a0(longlong param_1)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  
  plVar1 = (longlong *)(param_1 + 0x178);
  plVar3 = (longlong *)*plVar1;
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x1a8);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar4;
          plVar4 = *(longlong **)(param_1 + 0x1a8);
          if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
            _invalid_parameter_noinfo();
          }
          if (plVar6 == plVar4) {
            plVar3 = *(longlong **)(*(longlong *)(param_1 + 0x1a8) + 8);
            cVar2 = *(char *)((longlong)plVar3 + 0x29);
            while (cVar2 == '\0') {
              FUN_140488180(plVar1,plVar3[2]);
              plVar4 = (longlong *)*plVar3;
              operator_delete(plVar3);
              plVar3 = plVar4;
              cVar2 = *(char *)((longlong)plVar4 + 0x29);
            }
            *(longlong *)(*(longlong *)(param_1 + 0x1a8) + 8) = *(longlong *)(param_1 + 0x1a8);
            *(undefined8 *)(param_1 + 0x1b0) = 0;
            *(undefined8 *)*(undefined8 *)(param_1 + 0x1a8) = *(undefined8 *)(param_1 + 0x1a8);
            *(longlong *)(*(longlong *)(param_1 + 0x1a8) + 0x10) = *(longlong *)(param_1 + 0x1a8);
            return;
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar3;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (plVar6[4] != 0) {
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar3;
            }
            if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            FUN_1403a7180(plVar6[4]);
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar4 = plVar6;
        }
        plVar4 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
        cVar2 = *(char *)(*plVar4 + 0x29);
        plVar6 = (longlong *)*plVar4;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*plVar6 + 0x29);
          plVar4 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar4 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar4 + 0x29) != '\0');
    do {
      plVar5 = plVar4;
      plVar4 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar4 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar4 + 0x29) == '\0');
  } while( true );
}

// ==== CPlayerMagic::helper_14048d7c0  @14048d7c0  [medium:callgraph-r0]  (orig: FUN_14048d7c0)
longlong * FUN_14048d7c0(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14048d91d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14048d94c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14048d91d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1404898e0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14048d94c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CPlayerMagic::helper_14048d970  @14048d970  [medium:callgraph-r1]  (orig: FUN_14048d970)
undefined8 * FUN_14048d970(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402ed280(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14048db5c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14048db5c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140485cd0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140483500(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_140485cd0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140483500(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140485cd0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_140483500(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CPlayerMagic::helper_14048e370  @14048e370  [medium:callgraph-r1]  (orig: FUN_14048e370)
undefined8 * FUN_14048e370(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1404839b0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14048e55c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14048e55c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140485d90(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1404836b0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_140485d90(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1404836b0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140485d90(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1404836b0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CPlayerMagic::helper_14048ec40  @14048ec40  [medium:callgraph-r0]  (orig: FUN_14048ec40)
longlong * FUN_14048ec40(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140488c10(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14048d970(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CPlayerMagic::helper_14048ee90  @14048ee90  [medium:callgraph-r0]  (orig: FUN_14048ee90)
longlong * FUN_14048ee90(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140488c90(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14048e370(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CPlayerMagic::helper_14048f9d0  @14048f9d0  [medium:callgraph-r1]  (orig: FUN_14048f9d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14048f9d0(longlong param_1,char param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (*(longlong *)(param_1 + 0x90) == 0) {
    local_468 = 0x8db;
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  iVar2 = FUN_140418c50(*(longlong *)(param_1 + 0x90),2);
  if (iVar2 - 10000U < 0x100) {
    local_468 = 0x8dc;
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x76);
  if (0 < iVar2) {
    iVar3 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),4);
    if (iVar2 <= iVar3) {
LAB_14048fb32:
      iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),3);
      iVar2 = iVar2 + 1;
      uVar4 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1c0));
      uVar5 = FUN_1400877e0(uVar5);
      lVar6 = FUN_1402f0fe0(uVar5,uVar4,iVar2);
      if (lVar6 == 0) {
        return 0;
      }
      FUN_140418d90(*(undefined8 *)(param_1 + 0x90),4);
      FUN_140418d90(*(undefined8 *)(param_1 + 0x90),3,iVar2);
      FUN_140418450(*(undefined8 *)(param_1 + 0x90));
      if (param_2 != '\0') {
        FUN_140456f30(local_448);
        uVar4 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2);
        local_468 = 0;
        cVar1 = FUN_1404570d0(local_448,1,uVar4,iVar2);
        if (cVar1 == '\0') {
          local_468 = 0x8f8;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          plVar7 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
          (**(code **)(*plVar7 + 0x350))(plVar7,local_448);
        }
        FUN_140456f80(local_448);
      }
      iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2);
      if (iVar2 == 0x3052) {
        plVar7 = (longlong *)FUN_1401181a0();
        lVar6 = *plVar7;
        uVar4 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
        (**(code **)(lVar6 + 0x10))(plVar7,uVar4,0xac);
        FUN_14048cf30(param_1,1);
      }
      else {
        iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2);
        if (iVar2 == 0x305c) {
          plVar7 = (longlong *)FUN_1401181a0();
          lVar6 = *plVar7;
          uVar4 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
          (**(code **)(lVar6 + 0x10))(plVar7,uVar4,0xad);
          FUN_14048cf30(param_1,1);
        }
      }
      return 1;
    }
    iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),6);
    if (iVar2 != 0) {
      iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),6);
      iVar3 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),3);
      if (iVar2 / 2 <= iVar3) {
        iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),6);
        iVar3 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),3);
        if (iVar3 < iVar2) goto LAB_14048fb32;
      }
    }
  }
  return 0;
}

// ==== CPlayerMagic::helper_140490490  @140490490  [medium:callgraph-r0]  (orig: FUN_140490490)
undefined8 FUN_140490490(longlong param_1,uint param_2,char param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong lVar7;
  longlong **pplVar8;
  undefined8 *puVar9;
  undefined8 uVar10;
  longlong *local_38;
  undefined8 *local_30;
  longlong *local_28;
  longlong *plStack_20;
  
  uVar10 = 0xfffffffffffffffe;
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
  cVar1 = *(char *)((longlong)puVar9 + 0x29);
  puVar5 = *(undefined8 **)(param_1 + 0x78);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar9[2];
      puVar9 = puVar5;
    }
    else {
      puVar6 = (undefined8 *)*puVar9;
    }
    puVar5 = puVar9;
    puVar9 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x29);
  }
  local_30 = puVar5;
  local_38 = *(longlong **)(param_1 + 0x48);
  puVar9 = *(undefined8 **)(param_1 + 0x78);
  if (*(longlong **)(param_1 + 0x48) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar9) || (param_2 < *(uint *)(puVar5 + 3))) {
    plStack_20 = (longlong *)*(undefined8 *)(param_1 + 0x78);
    local_28 = *(longlong **)(param_1 + 0x48);
    pplVar8 = &local_28;
  }
  else {
    pplVar8 = &local_38;
  }
  plVar2 = *pplVar8;
  plVar3 = pplVar8[1];
  plVar4 = *(longlong **)(param_1 + 0x78);
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x48))) {
    _invalid_parameter_noinfo();
  }
  if (plVar3 == plVar4) {
    uVar10 = 0;
  }
  else {
    if (param_3 != '\0') {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar3 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3[4] != 0) {
        FUN_1404183d0(plVar3[4]);
        plVar3[4] = 0;
      }
    }
    local_28 = plVar2;
    plStack_20 = plVar3;
    FUN_14048d970(param_1 + 0x48,&local_38,&local_28,param_4,uVar10);
    uVar10 = 1;
  }
  return uVar10;
}

// ==== CPlayerMagic::helper_1404913c0  @1404913c0  [medium:callgraph-r0]  (orig: FUN_1404913c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1404913c0(longlong param_1,uint param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  char *pcVar6;
  uint uVar7;
  longlong lVar8;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (*(longlong *)(param_1 + 0x90) == 0) {
    local_478 = 0x5d0;
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if ((int)param_2 < 1) {
    return 0;
  }
  plVar5 = (longlong *)(**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x160))()
  ;
  iVar2 = (**(code **)(*plVar5 + 8))();
  if (iVar2 == 0x40f) {
    if ((param_2 == 1) &&
       ((((((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 6 ||
            (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x13)) ||
           (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0xb)) ||
          (((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x10 ||
            (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x1b)) ||
           ((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x31 ||
            ((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x33 ||
             (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x34)))))))) ||
         (((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x37 ||
           ((((((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x3e ||
                (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x3a)) ||
               (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x3b)) ||
              ((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x38 ||
               (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x3c)))) ||
             ((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x41 ||
              ((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x45 ||
               (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x46)))))) ||
            (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x17)))) ||
          (((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 == 0x49 ||
            (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2), iVar2 == 0x3052)) ||
           (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2), iVar2 == 0x305c)))))) ||
        (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2), iVar2 == 0x3066)))) {
      iVar2 = tq::RandGet(0x14);
      param_2 = (uint)(iVar2 == 0);
    }
    else {
      cVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x260))();
      if (cVar1 != '\0') {
        param_2 = (int)param_2 / 2;
      }
      param_2 = MulDiv(param_2,10,100);
      if ((int)param_2 < 2) {
        param_2 = 1;
      }
    }
    if (param_3 == 0) goto LAB_14049171e;
    cVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x260))();
    if (cVar1 != '\0') {
      param_3 = param_3 / 2;
    }
    param_3 = MulDiv(param_3,10,100);
    if (param_3 < 2) {
      param_3 = 1;
    }
  }
  if (param_3 != 0) {
    plVar5 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
    local_478 = CONCAT31(local_478._1_3_,1);
    (**(code **)(*plVar5 + 0x2f8))(plVar5,(longlong)param_3,1,1);
  }
LAB_14049171e:
  uVar7 = 0;
  pcVar6 = &DAT_140786f28;
  do {
    if (*pcVar6 == *(char *)(*(longlong *)(param_1 + 0x1c8) + 0xeee)) {
      lVar8 = 1L << ((byte)uVar7 & 0x3f);
      goto LAB_14049174d;
    }
    uVar7 = uVar7 + 1;
    pcVar6 = pcVar6 + 1;
  } while (uVar7 < 0x26);
  lVar8 = 0;
LAB_14049174d:
  cVar1 = FUN_1404811b0(param_1,lVar8);
  if (((cVar1 != '\0') && (param_2 != 0)) &&
     (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x76), -1 < iVar2)) {
    iVar2 = FUN_140180d80(*(undefined8 *)(param_1 + 0x1c8));
    iVar2 = param_2 + (int)(param_2 * iVar2) / 100;
    iVar3 = FUN_140175470(*(undefined8 *)(param_1 + 0x1c8));
    if (iVar3 != 0) {
      iVar3 = FUN_140164ee0(*(undefined8 *)(param_1 + 0x1c8));
      iVar2 = (iVar3 * iVar2) / 100;
    }
    iVar3 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),4);
    FUN_140418d90(*(undefined8 *)(param_1 + 0x90),4,iVar2 + iVar3);
    FUN_1403eff70(local_458);
    uVar4 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2);
    local_478 = 0;
    iVar2 = FUN_1403f0020(local_458,1,uVar4,iVar2 + iVar3);
    if (iVar2 == 0) {
      local_478 = 0x629;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar5 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
      (**(code **)(*plVar5 + 0x350))(plVar5,local_458);
    }
    FUN_14048f9d0(param_1,1);
    FUN_1403effc0(local_458);
    return 1;
  }
  return 0;
}

// ==== CPlayerMagic::LearnMagic  @1404939c0  [high:log-string]  (orig: FUN_1404939c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_1404939c0(longlong param_1,undefined4 param_2,undefined4 param_3,char param_4)

{
  char cVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  longlong lVar10;
  undefined8 uVar11;
  longlong lVar12;
  longlong *plVar13;
  undefined1 auStack_918 [32];
  undefined4 local_8f8;
  undefined1 local_8f0;
  undefined4 local_8e8;
  undefined4 local_8e0;
  int local_8d8 [2];
  longlong local_8d0;
  undefined8 local_8c8;
  undefined1 local_8c0 [24];
  undefined1 local_8a8 [1072];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8c8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_918;
  lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x1c0));
  lVar10 = *(longlong *)(lVar10 + 0x100);
  if (lVar10 == 0) {
    local_8f8 = 0x144;
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar10 = 0;
  }
  lVar10 = FUN_1402f0fe0(lVar10,param_2,param_3);
  if (lVar10 == 0) {
    local_8f8 = 0xe19;
    log_InlineLogERROR("CPlayerMagic::LearnMagic(), Can\'t Find Magic(Type:%d, Level:%d) at %s, %d")
    ;
    return 0;
  }
  lVar10 = FUN_14048b5f0(param_1,param_2);
  if (lVar10 != 0) {
    cVar1 = FUN_1404184d0(lVar10);
    if ((cVar1 != '\0') && (cVar1 = FUN_140418480(lVar10), cVar1 == '\0')) {
      FUN_140456f30(local_8a8);
      uVar3 = FUN_140418e40(lVar10,10);
      uVar4 = FUN_140418e40(lVar10,8);
      uVar2 = FUN_140418c50(lVar10,7);
      uVar5 = FUN_140418c50(lVar10,4);
      uVar6 = FUN_140418c50(lVar10,3);
      uVar7 = FUN_140418c50(lVar10,2);
      local_8f8 = uVar5;
      local_8f0 = uVar2;
      local_8e8 = uVar4;
      local_8e0 = uVar3;
      cVar1 = FUN_140456fe0(local_8a8,0,uVar7,uVar6);
      if (cVar1 == '\0') {
        local_8f8 = 0xe2a;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar13 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
        (**(code **)(*plVar13 + 0x350))(plVar13,local_8a8);
      }
      FUN_140418490(lVar10,1);
      FUN_140456f80(local_8a8);
    }
    return 0;
  }
  lVar10 = FUN_14048b710(param_1,param_2);
  if (lVar10 == 0) {
    lVar10 = FUN_1404186d0(*(undefined4 *)(param_1 + 0x1c0),0);
    if (lVar10 == 0) {
      local_8f8 = 0xe47;
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    if (param_4 == '\0') {
      uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x1c0));
      uVar11 = FUN_1400fd800(uVar11);
      lVar12 = FUN_14028deb0(uVar11,1);
      if (lVar12 == 0) {
        FUN_1404183d0(lVar10);
        (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
        local_8f8 = 0;
        log_InlineLogERROR("pop cq_magic rec err:owner=%u,type=%d,lev=%d,exp=%u");
        return 0;
      }
      cVar1 = FUN_1404183f0(lVar10,lVar12);
      if (cVar1 == '\0') {
        FUN_1404183d0(lVar10);
        return 0;
      }
    }
    else {
      if ((*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0xa88) == 0) ||
         (cVar1 = FUN_140418400(lVar10), cVar1 == '\0')) {
        FUN_1404183d0(lVar10);
        return 0;
      }
      FUN_1404184e0(lVar10,1);
    }
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
    FUN_140418d90(lVar10,1,uVar3);
    FUN_140418d90(lVar10,2,param_2);
    FUN_140418d90(lVar10,3,param_3);
    FUN_140418d90(lVar10,4);
    FUN_140418d90(lVar10,5);
    FUN_140418d90(lVar10,6);
    FUN_1404187b0(lVar10);
    cVar1 = FUN_1404184d0(lVar10);
    if (cVar1 == '\0') {
      FUN_140418450(lVar10);
      iVar8 = FUN_140418430(lVar10);
    }
    else {
      *(int *)(param_1 + 0x88) = *(int *)(param_1 + 0x88) + 1;
      iVar8 = *(int *)(param_1 + 0x88);
      FUN_140418d90(lVar10,0,iVar8);
    }
    if (iVar8 == 0) {
      local_8f8 = 0xe76;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  else {
    iVar8 = FUN_140418430(lVar10);
    FUN_140418d90(lVar10,2,param_2);
    FUN_140418d90(lVar10,3,param_3);
    FUN_140418d90(lVar10,4);
    FUN_140418d90(lVar10,5);
    FUN_140418450(lVar10);
    FUN_1404187b0(lVar10);
  }
  FUN_140456f30(local_478);
  uVar3 = FUN_140418e40(lVar10,10);
  uVar4 = FUN_140418e40(lVar10,8);
  uVar2 = FUN_140418c50(lVar10,7);
  uVar5 = FUN_140418c50(lVar10,4);
  uVar6 = FUN_140418c50(lVar10,3);
  uVar7 = FUN_140418c50(lVar10,2);
  local_8f8 = uVar5;
  local_8f0 = uVar2;
  local_8e8 = uVar4;
  local_8e0 = uVar3;
  cVar1 = FUN_140456fe0(local_478,0,uVar7,uVar6);
  if (cVar1 == '\0') {
    local_8f8 = 0xe81;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar13 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
    (**(code **)(*plVar13 + 0x350))(plVar13,local_478);
  }
  FUN_140490490(param_1,iVar8,0);
  local_8d8[0] = iVar8;
  local_8d0 = lVar10;
  FUN_14048d7c0(param_1 + 8,local_8c0,local_8d8);
  iVar9 = FUN_140418c50(lVar10,2);
  if (iVar9 != 0x3052) {
    iVar9 = FUN_140418c50(lVar10,2);
    if (iVar9 != 0x305c) goto LAB_140493f28;
  }
  FUN_14048cf30(param_1,1);
LAB_140493f28:
  FUN_140456f80(local_478);
  return iVar8;
}

// ==== CPlayerMagic::ProcessAttach  @140494350  [high:log-string]  (orig: FUN_140494350)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140494350(longlong *param_1)

{
  char cVar1;
  undefined1 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  longlong *plVar14;
  undefined8 uVar15;
  longlong *plVar16;
  longlong *plVar17;
  IStringManager *pIVar18;
  longlong lVar19;
  char *pcVar20;
  undefined1 auStack_f18 [32];
  ulonglong local_ef8;
  undefined8 local_ef0;
  undefined4 local_ee8;
  undefined4 local_ee0;
  uint local_ed8;
  undefined2 local_ed0;
  uint local_ec8;
  longlong *local_eb8;
  uint local_eb0;
  uint local_eac;
  undefined4 local_ea8;
  undefined8 local_ea0;
  undefined1 local_e98 [1072];
  undefined1 local_a68 [1072];
  char local_638;
  undefined1 local_637 [510];
  undefined1 local_439;
  char local_438;
  undefined1 local_437 [1023];
  ulonglong local_38;
  
  local_ea0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_f18;
  if (param_1[0x12] == 0) {
    local_ef8 = CONCAT44(local_ef8._4_4_,0x18b1);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_1[0x39] == 0) {
    local_ef8 = CONCAT44(local_ef8._4_4_,0x18b2);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar14 = (longlong *)
            (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x2a8))
                      ((longlong *)(param_1[0x39] + 0x10),(int)param_1[0x13]);
  if ((plVar14 == (longlong *)0x0) ||
     ((cVar1 = (**(code **)(*plVar14 + 0x220))(plVar14), cVar1 == '\0' &&
      (iVar3 = FUN_140418c50(param_1[0x12],0x74), iVar3 != 0x6a)))) {
    return 0;
  }
  lVar19 = *(longlong *)(param_1[0x39] + 0x10);
  uVar4 = (**(code **)(*plVar14 + 0x48))(plVar14);
  uVar5 = (**(code **)(*plVar14 + 0x40))(plVar14);
  iVar3 = (**(code **)(lVar19 + 0x158))(param_1[0x39] + 0x10,uVar5,uVar4);
  iVar6 = FUN_140418c50(param_1[0x12],0x73);
  if (iVar6 < iVar3) {
    return 0;
  }
  FUN_140483270(param_1,plVar14);
  iVar3 = (**(code **)(*(longlong *)param_1[0x39] + 8))();
  if (((((int)param_1[0x13] != iVar3) &&
       (cVar1 = (**(code **)(*plVar14 + 0x220))(plVar14), cVar1 != '\0')) && (param_1[0x12] != 0))
     && ((iVar3 = FUN_140418c50(param_1[0x12],0x68), iVar3 != 0 &&
         (cVar1 = FUN_1403e9290(plVar14), cVar1 != '\0')))) {
    FUN_140386780(local_a68);
    plVar14 = (longlong *)param_1[0x39];
    uVar2 = FUN_140418c50(param_1[0x12],7);
    uVar4 = FUN_140418c50(param_1[0x12],3);
    uVar5 = FUN_140418c50(param_1[0x12],2);
    uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
    local_ed0 = (ushort)local_ed0._1_1_ << 8;
    local_ed8 = 2;
    local_ee0 = 1;
    local_ee8 = 0;
    local_ef0 = CONCAT44(local_ef0._4_4_,(int)param_1[0x13]);
    local_ef8 = CONCAT71(local_ef8._1_7_,uVar2);
    iVar3 = FUN_1403868f0(local_a68,uVar7,uVar5,uVar4);
    if (iVar3 == 0) {
      local_ef8 = CONCAT44(local_ef8._4_4_,0x18c4);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x348))
                ((longlong *)(param_1[0x39] + 0x10),local_a68,1);
    }
    FUN_1403867d0(local_a68);
    return 1;
  }
  iVar3 = FUN_140418c50(param_1[0x12],0x74);
  if (iVar3 == 0x59) {
    cVar1 = FUN_140482560(param_1);
    if (cVar1 == '\0') {
      return 0;
    }
  }
  else {
    if (iVar3 == 0x7d) {
      cVar1 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x2d8))
                        ((longlong *)(param_1[0x39] + 0x10),0x2f);
      if (cVar1 != '\0') {
        plVar16 = (longlong *)FUN_1401181a0();
        lVar19 = *plVar16;
        uVar4 = (**(code **)(*(longlong *)param_1[0x39] + 8))();
        (**(code **)(lVar19 + 0x10))(plVar16,uVar4,0x2f);
      }
      cVar1 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x2d8))
                        ((longlong *)(param_1[0x39] + 0x10),0x7d);
    }
    else if (iVar3 == 0x91) {
      cVar1 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x2d8))
                        ((longlong *)(param_1[0x39] + 0x10),0x91);
    }
    else {
      if (iVar3 != 0x94) goto LAB_14049472d;
      cVar1 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x2d8))
                        ((longlong *)(param_1[0x39] + 0x10),0x94);
    }
    if (cVar1 != '\0') {
      plVar14 = (longlong *)FUN_1401181a0();
      lVar19 = *plVar14;
      uVar4 = (**(code **)(*(longlong *)param_1[0x39] + 8))();
      (**(code **)(lVar19 + 0x10))(plVar14,uVar4,iVar3);
      return 1;
    }
  }
LAB_14049472d:
  local_eb0 = 0;
  uVar8 = FUN_140418c50(param_1[0x12],3);
  local_eac = uVar8;
  iVar6 = FUN_140418c50(param_1[0x12],0x74);
  if (iVar6 == 0x59) {
    iVar6 = FUN_140418c50(param_1[0x12],0x87);
    iVar9 = FUN_140418c50(param_1[0x12],0x88);
    cVar1 = FUN_140178c40(param_1[0x39]);
    if (cVar1 != '\0') {
      uVar4 = FUN_140418c50(param_1[0x12],2);
      uVar15 = FUN_140008520((int)param_1[0x38]);
      uVar15 = FUN_1400877e0(uVar15);
      plVar16 = (longlong *)FUN_1402f0fe0(uVar15,uVar4,3);
      if (plVar16 != (longlong *)0x0) {
        plVar17 = (longlong *)(**(code **)(*plVar16 + 0x10))(plVar16,0x23);
        iVar10 = (**(code **)(*plVar17 + 0x48))(plVar17);
        plVar16 = (longlong *)(**(code **)(*plVar16 + 0x10))(plVar16,0x24);
        iVar11 = (**(code **)(*plVar16 + 0x48))(plVar16);
        if (iVar10 < iVar6) {
          iVar6 = iVar10;
        }
        if (iVar11 < iVar9) {
          iVar9 = iVar11;
        }
        local_eac = 3;
        if (uVar8 < 3) {
          local_eac = uVar8;
        }
      }
    }
  }
  else if (iVar3 == 0x92) {
    iVar9 = FUN_140418c50(param_1[0x12],0x71);
    iVar6 = FUN_140418c50(param_1[0x12],0x90);
  }
  else if (iVar3 == 0x9f) {
    iVar9 = FUN_140418c50(param_1[0x12],0x71);
    iVar6 = FUN_140418c50(param_1[0x12],0x89);
  }
  else if (iVar3 == 0x94) {
    iVar9 = FUN_140418c50(param_1[0x12],0x71);
    iVar6 = FUN_140418c50(param_1[0x12],0x6e);
    local_eb0 = FUN_140418c50(param_1[0x12],0x90);
  }
  else {
    iVar9 = FUN_140418c50(param_1[0x12],0x71);
    iVar6 = FUN_140418c50(param_1[0x12],0x6e);
  }
  local_ea8 = 0;
  iVar10 = FUN_140418c50(param_1[0x12],0x66);
  if ((iVar10 != 0x25) && (iVar10 = FUN_140418c50(param_1[0x12],0x66), iVar10 != 0x3f)) {
    local_ea8 = FUN_140418c50(param_1[0x12],0x7b);
  }
  if (((iVar3 != 0x6a) && (iVar3 != 0x91)) && (iVar6 < 1)) {
    FUN_140418c50(param_1[0x12],3);
    FUN_140418c50(param_1[0x12],2);
    local_ef8 = CONCAT44(local_ef8._4_4_,0x191e);
    log_InlineLogERROR(
                      "CPlayerMagic::ProcessAttach(), Magic(Type:%d, Level:%d) Power Less Than Or Equal To Zero at %s, %d"
                      );
  }
  FUN_140386780(local_e98);
  plVar16 = (longlong *)param_1[0x39];
  uVar2 = FUN_140418c50(param_1[0x12],7);
  uVar4 = FUN_140418c50(param_1[0x12],2);
  uVar5 = (**(code **)(*plVar16 + 8))(plVar16);
  local_ed0 = (ushort)local_ed0._1_1_ << 8;
  local_ed8 = 0;
  local_ee0 = 1;
  local_ee8 = 0;
  local_ef0 = CONCAT44(local_ef0._4_4_,(int)param_1[0x13]);
  local_ef8 = CONCAT71(local_ef8._1_7_,uVar2);
  iVar10 = FUN_1403868f0(local_e98,uVar5,uVar4,local_eac);
  if (iVar10 == 0) {
    local_ef8 = CONCAT44(local_ef8._4_4_,0x1928);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x348))
              ((longlong *)(param_1[0x39] + 0x10),local_e98,1);
  }
  iVar10 = FUN_140418c50(param_1[0x12],0x74);
  FUN_1404810d0(param_1,plVar14,iVar10 != 0x6a);
  local_eb8 = (longlong *)0x0;
  cVar1 = (**(code **)(*plVar14 + 0x298))(plVar14,0x1001,&local_eb8);
  if ((cVar1 == '\0') &&
     (((((iVar3 == 0x11 || (iVar3 == 0xb)) ||
        ((iVar3 == 0xc || ((iVar3 == 0x14 || (iVar3 == 0x27)))))) || (iVar3 == 0x28)) ||
      (iVar3 == 0x59)))) {
    FUN_1403867d0(local_e98);
    return 0;
  }
  if ((local_eb8 != (longlong *)0x0) && (iVar10 = FUN_140418c50(param_1[0x12]), iVar10 == 0x6a)) {
    cVar1 = FUN_14016f960(param_1[0x39]);
    if (cVar1 == '\0') {
      pIVar18 = theInstance();
      lVar19 = *(longlong *)(param_1[0x39] + 0x10);
      uVar15 = (*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_NOT_PK_MODE");
      (**(code **)(lVar19 + 0x358))(param_1[0x39] + 0x10,uVar15);
      FUN_1403867d0(local_e98);
      return 0;
    }
    iVar10 = FUN_14018eb30(local_eb8);
    iVar11 = FUN_14018eb30(param_1[0x39]);
    if (iVar11 < iVar10) {
      iVar11 = FUN_14018eb30(local_eb8);
      iVar12 = FUN_14018eb30(param_1[0x39]);
      iVar10 = (0x14 - (iVar11 - iVar12)) * 5;
      if ((iVar10 < 1) || (iVar13 = tq::RandGet(100), iVar10 < iVar13)) {
        pIVar18 = theInstance();
        lVar19 = *(longlong *)(param_1[0x39] + 0x10);
        uVar15 = (*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_KEEPGHOST_FAIL");
        (**(code **)(lVar19 + 0x358))(param_1[0x39] + 0x10,uVar15,iVar11 - iVar12);
        FUN_1403867d0(local_e98);
        return 0;
      }
    }
  }
  if (iVar3 == 0x10) {
    plVar16 = (longlong *)FUN_1401181a0();
    lVar19 = *plVar16;
    (**(code **)(*plVar14 + 0x10))(plVar14);
    (**(code **)(lVar19 + 0x28))(plVar16);
LAB_140494fb6:
    if (local_eb8 != (longlong *)0x0) {
      if ((param_1[0x39] != 0) &&
         (lVar19 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x160))(), lVar19 != 0)) {
        uVar15 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x160))();
        cVar1 = FUN_1401195d0(uVar15);
        if (cVar1 != '\0') {
          iVar10 = (**(code **)(*(longlong *)param_1[0x39] + 8))();
          iVar11 = (**(code **)(*local_eb8 + 8))();
          plVar16 = local_eb8;
          if (iVar10 != iVar11) {
            iVar10 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x170))();
            iVar11 = (**(code **)(plVar16[2] + 0x170))(plVar16 + 2);
            if (iVar10 == iVar11) {
              plVar16 = (longlong *)FUN_1401181a0();
              lVar19 = *plVar16;
              uVar4 = (**(code **)(*local_eb8 + 8))();
              cVar1 = (**(code **)(lVar19 + 0x60))(plVar16,uVar4,iVar3);
              if ((cVar1 == '\0') &&
                 (((iVar10 = FUN_140418c50(param_1[0x12],2), iVar10 == 0x447 ||
                   (iVar10 = FUN_140418c50(param_1[0x12],2), iVar10 == 0x442)) ||
                  (iVar10 = FUN_140418c50(param_1[0x12]), iVar10 == 0x43d)))) {
                plVar16 = (longlong *)CurrentInstanceGet();
                if ((plVar16 != (longlong *)0x0) &&
                   (plVar16 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16,0x18),
                   plVar16 != (longlong *)0x0)) {
                  lVar19 = *plVar16;
                  uVar4 = (**(code **)(*param_1 + 8))(param_1);
                  (**(code **)(lVar19 + 0x50))(plVar16,uVar4,1);
                }
                plVar16 = (longlong *)FUN_140087ed0();
                lVar19 = *plVar16;
                uVar4 = (**(code **)(*(longlong *)param_1[0x39] + 8))();
                (**(code **)(lVar19 + 0x158))(plVar16,uVar4,1);
              }
            }
          }
        }
      }
      if (((local_eb8 != (longlong *)0x0) && (param_1[0x39] != 0)) &&
         ((lVar19 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x160))(), lVar19 != 0 &&
          (iVar10 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x170))(), iVar10 != 0)))) {
        uVar15 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x160))();
        cVar1 = FUN_1400f8890(uVar15);
        if (cVar1 != '\0') {
          iVar10 = (**(code **)(*(longlong *)param_1[0x39] + 8))();
          iVar11 = (**(code **)(*local_eb8 + 8))();
          plVar16 = local_eb8;
          if (iVar10 != iVar11) {
            iVar10 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x170))();
            iVar11 = (**(code **)(plVar16[2] + 0x170))(plVar16 + 2);
            if (iVar10 == iVar11) {
              plVar16 = (longlong *)FUN_1401181a0();
              lVar19 = *plVar16;
              uVar4 = (**(code **)(*local_eb8 + 8))();
              cVar1 = (**(code **)(lVar19 + 0x60))(plVar16,uVar4,iVar3);
              if ((cVar1 == '\0') &&
                 ((((iVar10 = FUN_140418c50(param_1[0x12]), iVar10 == 0x447 ||
                    (iVar10 = FUN_140418c50(param_1[0x12]), iVar10 == 0x442)) ||
                   (iVar10 = FUN_140418c50(param_1[0x12]), iVar10 == 0x43d)) &&
                  (plVar16 = (longlong *)CurrentInstanceGet(), plVar16 != (longlong *)0x0)))) {
                uVar15 = FUN_140008520((int)param_1[0x38]);
                cVar1 = FUN_14008b330(uVar15);
                if (cVar1 == '\0') {
                  plVar16 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16);
                  if (plVar16 != (longlong *)0x0) {
                    lVar19 = *plVar16;
                    uVar4 = (**(code **)(*param_1 + 8))(param_1);
                    (**(code **)(lVar19 + 0x90))(plVar16,uVar4,1);
                  }
                }
                else {
                  plVar16 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16);
                  if (plVar16 != (longlong *)0x0) {
                    lVar19 = *plVar16;
                    uVar4 = (**(code **)(*param_1 + 8))(param_1);
                    (**(code **)(lVar19 + 0x98))(plVar16,uVar4,1);
                  }
                }
              }
            }
          }
        }
      }
    }
    if (iVar3 == 0x6a) {
      if (local_eb8 == (longlong *)0x0) goto LAB_14049555b;
      if (((param_1[0x39] != 0) &&
          (lVar19 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x160))(), lVar19 != 0)) &&
         (iVar10 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x170))(), iVar10 != 0)) {
        uVar15 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x160))();
        cVar1 = FUN_1400f8890(uVar15);
        if (cVar1 != '\0') {
          iVar10 = (**(code **)(*(longlong *)param_1[0x39] + 8))();
          iVar11 = (**(code **)(*local_eb8 + 8))();
          plVar16 = local_eb8;
          if (iVar10 != iVar11) {
            iVar10 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x170))();
            iVar11 = (**(code **)(plVar16[2] + 0x170))(plVar16 + 2);
            if (iVar10 != iVar11) {
              plVar16 = (longlong *)FUN_1401181a0();
              lVar19 = *plVar16;
              uVar4 = (**(code **)(*local_eb8 + 8))();
              cVar1 = (**(code **)(lVar19 + 0x60))(plVar16,uVar4,0x6a);
              if ((cVar1 == '\0') &&
                 (plVar16 = (longlong *)CurrentInstanceGet(), plVar16 != (longlong *)0x0)) {
                uVar15 = FUN_140008520((int)param_1[0x38]);
                cVar1 = FUN_14008b330(uVar15);
                if (cVar1 == '\0') {
                  plVar16 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16);
                  if (plVar16 != (longlong *)0x0) {
                    lVar19 = *plVar16;
                    uVar4 = (**(code **)(*param_1 + 8))(param_1);
                    (**(code **)(lVar19 + 0x90))(plVar16,uVar4,1);
                  }
                }
                else {
                  plVar16 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16);
                  if (plVar16 != (longlong *)0x0) {
                    lVar19 = *plVar16;
                    uVar4 = (**(code **)(*param_1 + 8))(param_1);
                    (**(code **)(lVar19 + 0x98))(plVar16,uVar4,1);
                  }
                }
              }
            }
          }
        }
      }
    }
    if ((local_eb8 != (longlong *)0x0) && (iVar3 == 0x6a)) {
      local_638 = '\0';
      memset(local_637,0,0x1ff);
      _snprintf(&local_638,0x200,"</F>Event_KeepGhost");
      local_439 = 0;
      uVar4 = (**(code **)(*local_eb8 + 8))();
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      uVar15 = FUN_140087e30();
      local_ef0 = 0;
      local_ef8 = local_ef8 & 0xffffffff00000000;
      cVar1 = FUN_140286530(uVar15,&local_638,uVar5,uVar4);
      if (cVar1 == '\0') {
        log_InlineLogLuaERROR
                  ("Lua return fault, Call From:CPlayerMagic::ProcessAttach, lua function:%s.");
      }
    }
  }
  else {
    if (iVar3 == 0xd) {
      iVar9 = iVar9 + *(int *)(param_1[0x39] + 0xa74);
      uVar15 = FUN_140008520((int)param_1[0x38]);
      cVar1 = FUN_14008abf0(uVar15);
      if (cVar1 != '\0') {
        iVar10 = FUN_140418c50(param_1[0x12]);
        local_eb0 = local_eb0 + iVar10;
      }
      goto LAB_140494fb6;
    }
    if (iVar3 == 0x12) {
      uVar15 = FUN_140008520((int)param_1[0x38]);
      cVar1 = FUN_14008abf0(uVar15);
      if (cVar1 == '\0') {
        iVar9 = iVar9 + *(int *)(param_1[0x39] + 0xa74);
      }
      else if (*(byte *)(param_1[0x39] + 0xeee) / 10 == 1) {
        iVar10 = FUN_1403837b0(param_1[0x39]);
        FUN_1401a6420(param_1[0x39],8,(longlong)iVar10,1);
      }
      goto LAB_140494fb6;
    }
    if (iVar3 != 0x19) {
      if (iVar3 == 0x16) {
        cVar1 = (**(code **)(local_eb8[2] + 0x2d8))();
        if (cVar1 != '\0') {
          FUN_140160520(local_eb8,1);
          plVar16 = (longlong *)FUN_1401181a0();
          lVar19 = *plVar16;
          uVar4 = (**(code **)(*local_eb8 + 8))();
          (**(code **)(lVar19 + 0x10))(plVar16,uVar4,0x2f);
        }
      }
      else if (iVar3 == 0x59) {
        if (local_eb8 == (longlong *)0x0) {
          FUN_1403867d0(local_e98);
          return 0;
        }
        if (((param_1[0x39] != 0) &&
            (lVar19 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x160))(), lVar19 != 0)) &&
           (iVar10 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x170))(), iVar10 != 0)) {
          uVar15 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x160))();
          cVar1 = FUN_1400f8890(uVar15);
          if (cVar1 != '\0') {
            iVar10 = (**(code **)(*(longlong *)param_1[0x39] + 8))();
            iVar11 = (**(code **)(*local_eb8 + 8))();
            if (iVar10 != iVar11) {
              lVar19 = param_1[0x39];
              iVar10 = (**(code **)(local_eb8[2] + 0x170))();
              iVar11 = (**(code **)(*(longlong *)(lVar19 + 0x10) + 0x170))(lVar19 + 0x10);
              if (iVar11 == iVar10) {
                plVar16 = (longlong *)FUN_1401181a0();
                lVar19 = *plVar16;
                uVar4 = (**(code **)(*local_eb8 + 8))();
                cVar1 = (**(code **)(lVar19 + 0x60))(plVar16,uVar4,0x59);
                if ((cVar1 == '\0') &&
                   (plVar16 = (longlong *)CurrentInstanceGet(), plVar16 != (longlong *)0x0)) {
                  uVar15 = FUN_140008520((int)param_1[0x38]);
                  cVar1 = FUN_14008b330(uVar15);
                  if (cVar1 == '\0') {
                    plVar16 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16,0x1c);
                    if (plVar16 != (longlong *)0x0) {
                      lVar19 = *plVar16;
                      uVar4 = (**(code **)(*param_1 + 8))(param_1);
                      (**(code **)(lVar19 + 0x90))(plVar16,uVar4,1);
                    }
                  }
                  else {
                    plVar16 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16,0x25);
                    if (plVar16 != (longlong *)0x0) {
                      lVar19 = *plVar16;
                      uVar4 = (**(code **)(*param_1 + 8))(param_1);
                      (**(code **)(lVar19 + 0x98))(plVar16,uVar4,1);
                    }
                  }
                }
              }
            }
          }
        }
        plVar16 = (longlong *)FUN_1401181a0();
        lVar19 = *plVar16;
        uVar4 = (**(code **)(*plVar14 + 0x10))(plVar14);
        local_ec8 = local_eac;
        local_ed0 = 0;
        local_ed8 = local_ed8 & 0xffffff00;
        local_ee0 = 0;
        local_ee8 = 0;
        local_ef0 = CONCAT44(local_ef0._4_4_,local_ea8);
        local_ef8 = CONCAT44(local_ef8._4_4_,iVar9);
        (**(code **)(lVar19 + 8))(plVar16,uVar4,0x59,iVar6);
        goto LAB_1404955d3;
      }
      goto LAB_140494fb6;
    }
    if (local_eb8 != (longlong *)0x0) {
      local_ef8 = 0;
      (**(code **)(local_eb8[2] + 0x2e0))(local_eb8 + 2,0x1c,0,1);
      goto LAB_140494fb6;
    }
  }
LAB_14049555b:
  plVar16 = (longlong *)FUN_1401181a0();
  lVar19 = *plVar16;
  uVar4 = (**(code **)(*plVar14 + 0x10))(plVar14);
  local_ec8 = local_eb0;
  local_ed0 = 0;
  local_ed8 = local_ed8 & 0xffffff00;
  local_ee0 = 0;
  local_ee8 = 0;
  local_ef0 = CONCAT44(local_ef0._4_4_,local_ea8);
  local_ef8 = CONCAT44(local_ef8._4_4_,iVar9);
  (**(code **)(lVar19 + 8))(plVar16,uVar4,iVar3,iVar6);
  if ((iVar3 == 0x28) || (iVar3 == 0x9f)) {
    uVar4 = FUN_140418c50(param_1[0x12],0x73);
    FUN_140161590(param_1[0x39],uVar4);
  }
LAB_1404955d3:
  FUN_1404913c0(param_1);
  local_438 = '\0';
  memset(local_437,0,0x3ff);
  switch(iVar3) {
  case 5:
    pIVar18 = theInstance();
    pcVar20 = (char *)(*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_HITRATE_ADD");
    local_ef8 = CONCAT44(local_ef8._4_4_,iVar6 + -30000);
    _snprintf(&local_438,0x3ff,pcVar20);
    (**(code **)(*plVar14 + 0x358))(plVar14,&local_438);
    break;
  case 6:
  case 0x2c:
  case 0x74:
    iVar3 = (iVar6 + -30000) / 100;
    if (iVar3 < 2) {
      pIVar18 = theInstance();
      pcVar20 = (char *)(*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_DEFENCE_ADD2");
      local_ef8 = CONCAT44(local_ef8._4_4_,iVar6 + -0x7594);
      _snprintf(&local_438,0x3ff,pcVar20);
    }
    else {
      pIVar18 = theInstance();
      pcVar20 = (char *)(*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_DEFENCE_ADD");
      local_ef8 = CONCAT44(local_ef8._4_4_,iVar3);
      _snprintf(&local_438,0x3ff,pcVar20);
    }
    (**(code **)(*plVar14 + 0x358))(plVar14,&local_438);
    break;
  case 7:
    pIVar18 = theInstance();
    pcVar20 = (char *)(*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_ATTACK_ADD");
    local_ef8 = CONCAT44(local_ef8._4_4_,iVar6 + -30000);
    _snprintf(&local_438,0x3ff,pcVar20);
    (**(code **)(*plVar14 + 0x358))(plVar14,&local_438);
    break;
  case 0x15:
    pIVar18 = theInstance();
    pcVar20 = (char *)(*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_DODGE_ADD");
    local_ef8 = CONCAT44(local_ef8._4_4_,iVar6 + -30000);
    _snprintf(&local_438,0x3ff,pcVar20);
    (**(code **)(*plVar14 + 0x358))(plVar14,&local_438);
  }
  FUN_1403867d0(local_e98);
  return 1;
}

// ==== CPlayerMagic::helper_1404981c0  @1404981c0  [medium:callgraph-r0]  (orig: FUN_1404981c0)
undefined8 * FUN_1404981c0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140488540(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x25) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CPlayerMagic::ctor_or_dtor  @140498370  [high:vtable-assign]  (orig: FUN_140498370)
void FUN_140498370(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  char cVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *local_48;
  longlong *plStack_40;
  longlong *local_38;
  undefined8 *puStack_30;
  undefined1 local_28 [16];
  
  *param_1 = CPlayerMagic::vftable;
  plVar7 = *(longlong **)param_1[7];
  plVar4 = (longlong *)param_1[1];
  local_48 = plVar4;
  plStack_40 = plVar7;
  while( true ) {
    plVar5 = (longlong *)param_1[7];
    if (((longlong *)param_1[1] == (longlong *)0x0) || ((longlong *)param_1[1] != plVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar7) break;
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar4;
    }
    if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar8 = plVar7[4];
    if (lVar8 != 0) {
      FUN_140418450(lVar8);
      FUN_1404183d0(lVar8);
    }
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar5 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
        cVar3 = *(char *)(*plVar5 + 0x29);
        plVar7 = plVar5;
        plVar5 = (longlong *)*plVar5;
        while (plStack_40 = plVar7, cVar3 == '\0') {
          cVar3 = *(char *)(*plVar5 + 0x29);
          plVar7 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        cVar3 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar5 = plVar7;
        while ((plVar7 = plVar6, plStack_40 = plVar7, cVar3 == '\0' &&
               (plVar5 == (longlong *)plVar7[2]))) {
          cVar3 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar5 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar3 = *(char *)((longlong)*(longlong **)(param_1[7] + 8) + 0x29);
  plVar7 = *(longlong **)(param_1[7] + 8);
  while (cVar3 == '\0') {
    FUN_140488130(param_1 + 1,plVar7[2]);
    plVar4 = (longlong *)*plVar7;
    operator_delete(plVar7);
    plVar7 = plVar4;
    cVar3 = *(char *)((longlong)plVar4 + 0x29);
  }
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  plVar7 = *(longlong **)param_1[0xf];
  plVar4 = (longlong *)param_1[9];
  local_48 = plVar4;
  plStack_40 = plVar7;
  while( true ) {
    plVar5 = (longlong *)param_1[0xf];
    if (((longlong *)param_1[9] == (longlong *)0x0) || ((longlong *)param_1[9] != plVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar7) break;
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar4;
    }
    if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar8 = plVar7[4];
    if (lVar8 != 0) {
      FUN_140418450(lVar8);
      FUN_1404183d0(lVar8);
    }
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar5 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
        cVar3 = *(char *)(*plVar5 + 0x29);
        plVar7 = plVar5;
        plVar5 = (longlong *)*plVar5;
        while (plStack_40 = plVar7, cVar3 == '\0') {
          cVar3 = *(char *)(*plVar5 + 0x29);
          plVar7 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        cVar3 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar5 = plVar7;
        while ((plVar7 = plVar6, plStack_40 = plVar7, cVar3 == '\0' &&
               (plVar5 == (longlong *)plVar7[2]))) {
          cVar3 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar5 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  puVar1 = param_1 + 9;
  cVar3 = *(char *)((longlong)*(longlong **)(param_1[0xf] + 8) + 0x29);
  plVar7 = *(longlong **)(param_1[0xf] + 8);
  while (cVar3 == '\0') {
    FUN_140488130(puVar1,plVar7[2]);
    plVar4 = (longlong *)*plVar7;
    operator_delete(plVar7);
    plVar7 = plVar4;
    cVar3 = *(char *)((longlong)plVar4 + 0x29);
  }
  *(undefined8 *)(param_1[0xf] + 8) = param_1[0xf];
  param_1[0x10] = 0;
  *(undefined8 *)param_1[0xf] = param_1[0xf];
  *(undefined8 *)(param_1[0xf] + 0x10) = param_1[0xf];
  FUN_14048d1a0(param_1);
  puVar2 = param_1 + 0x2f;
  plStack_40 = (longlong *)param_1[0x35];
  local_48 = (longlong *)*puVar2;
  puStack_30 = (undefined8 *)*plStack_40;
  local_38 = local_48;
  FUN_14048ee90(puVar2,local_28,&local_38,&local_48);
  operator_delete((void *)param_1[0x35]);
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  operator_delete((void *)*puVar2);
  puVar2 = param_1 + 0x27;
  puStack_30 = (undefined8 *)param_1[0x2d];
  local_48 = (longlong *)*puVar2;
  plStack_40 = (longlong *)*puStack_30;
  local_38 = local_48;
  FUN_140489c40(puVar2,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[0x2d]);
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  operator_delete((void *)*puVar2);
  puStack_30 = (undefined8 *)param_1[0xf];
  local_48 = (longlong *)*puVar1;
  plStack_40 = (longlong *)*puStack_30;
  local_38 = local_48;
  FUN_14048ec40(puVar1,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[0xf]);
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  operator_delete((void *)*puVar1);
  puVar1 = param_1 + 1;
  puStack_30 = (undefined8 *)param_1[7];
  local_48 = (longlong *)*puVar1;
  plStack_40 = (longlong *)*puStack_30;
  local_38 = local_48;
  FUN_14048ec40(puVar1,local_28,&local_48,&local_38);
  operator_delete((void *)param_1[7]);
  param_1[7] = 0;
  param_1[8] = 0;
  operator_delete((void *)*puVar1);
  return;
}

// ==== CPlayerMagic::helper_1404a1630  @1404a1630  [medium:callgraph-r0]  (orig: FUN_1404a1630)
undefined8 * FUN_1404a1630(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140488490(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CPlayerMagic::helper_1404a16b0  @1404a16b0  [medium:callgraph-r0]  (orig: FUN_1404a16b0)
undefined8 * FUN_1404a16b0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1404885a0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CPlayerMagic::vfunc_0  @1404a1730  [high:rtti-vtable]  (orig: FUN_1404a1730)
undefined8 FUN_1404a1730(undefined8 param_1,uint param_2)

{
  FUN_140498370();
  if ((param_2 & 1) != 0) {
    FUN_140484270(param_1);
  }
  return param_1;
}

// ==== CPlayerMagic::ctor_or_dtor  @1404a1760  [high:vtable-assign]  (orig: FUN_1404a1760)
undefined8 * FUN_1404a1760(undefined8 *param_1,undefined4 param_2,longlong param_3)

{
  *param_1 = CPlayerMagic::vftable;
  FUN_1404a1630(param_1 + 1);
  FUN_1404a1630(param_1 + 9);
  *(undefined1 *)((longlong)param_1 + 0x8c) = 1;
  *(undefined4 *)(param_1 + 0x13) = 0;
  *(undefined4 *)((longlong)param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0x15) = 0;
  *(undefined4 *)((longlong)param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0x16) = 0;
  *(undefined4 *)((longlong)param_1 + 0xb4) = 0;
  *(undefined4 *)(param_1 + 0x17) = 0;
  *(undefined4 *)((longlong)param_1 + 0xbc) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc4) = 0;
  *(undefined1 *)(param_1 + 0x19) = 0;
  *(undefined4 *)((longlong)param_1 + 0xd4) = 0;
  *(undefined4 *)(param_1 + 0x1b) = 0;
  *(undefined4 *)((longlong)param_1 + 0xdc) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)((longlong)param_1 + 0xe4) = 0;
  *(undefined4 *)(param_1 + 0x1d) = 0;
  *(undefined1 *)((longlong)param_1 + 0xec) = 0;
  *(undefined1 *)((longlong)param_1 + 0xf4) = 1;
  *(undefined1 *)((longlong)param_1 + 0xf5) = 0;
  *(undefined4 *)(param_1 + 0x1f) = 0;
  *(undefined4 *)((longlong)param_1 + 0xfc) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)((longlong)param_1 + 0x104) = 0;
  *(undefined4 *)(param_1 + 0x21) = 0;
  *(undefined4 *)((longlong)param_1 + 0x10c) = 0;
  *(undefined4 *)(param_1 + 0x22) = 0;
  *(undefined4 *)((longlong)param_1 + 0x114) = 0;
  *(undefined4 *)(param_1 + 0x23) = 0;
  *(undefined4 *)((longlong)param_1 + 0x11c) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)((longlong)param_1 + 0x124) = 0;
  *(undefined4 *)(param_1 + 0x25) = 0;
  *(undefined1 *)((longlong)param_1 + 300) = 0;
  *(undefined4 *)(param_1 + 0x26) = 0;
  FUN_1404981c0(param_1 + 0x27);
  FUN_1404a16b0(param_1 + 0x2f);
  *(undefined4 *)(param_1 + 0x37) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1bc) = 0;
  *(undefined4 *)(param_1 + 0x3a) = 0;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  *(undefined4 *)(param_1 + 0x38) = param_2;
  param_1[0x39] = param_3;
  param_1[0x12] = 0;
  *(undefined4 *)((longlong)param_1 + 0xcc) = 800;
  *(undefined4 *)(param_1 + 0x16) = 800;
  *(undefined4 *)(param_1 + 0x1a) = 800;
  *(undefined4 *)(param_1 + 0x1e) = 0xfaef8081;
  *(undefined4 *)(param_1 + 0x11) = 99000000;
  return param_1;
}

