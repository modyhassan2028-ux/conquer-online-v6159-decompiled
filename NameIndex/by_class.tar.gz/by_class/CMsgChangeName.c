// ==== CMsgChangeName::helper_14008a950  @14008a950  [medium:callgraph-r2]  (orig: FUN_14008a950)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14008a950(longlong param_1,undefined4 param_2,char *param_3,undefined2 param_4)

{
  undefined1 auStack_78 [32];
  undefined4 *local_58;
  undefined4 local_48;
  undefined2 local_44;
  char local_42 [42];
  ulonglong local_18;
  
  if (param_3 != (char *)0x0) {
    local_18 = DAT_1409707c0 ^ (ulonglong)auStack_78;
    local_48 = param_2;
    local_44 = param_4;
    tq::SafeCopy(local_42,param_3,0x24);
    local_58 = &local_48;
    (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
              (*(longlong **)(param_1 + 0x80),8,0x15f9e,0x2c);
  }
  return;
}

// ==== CMsgChangeName::helper_140166f00  @140166f00  [medium:callgraph-r1]  (orig: FUN_140166f00)
undefined8 FUN_140166f00(longlong param_1)

{
  longlong *plVar1;
  char *pcVar2;
  
  plVar1 = (longlong *)(param_1 + 0x10);
  pcVar2 = (char *)(**(code **)(*(longlong *)(param_1 + 0x10) + 0x18))(plVar1);
  pcVar2 = strstr(pcVar2,"[Z");
  if (pcVar2 == (char *)0x0) {
    pcVar2 = (char *)(**(code **)(*plVar1 + 0x18))(plVar1);
    pcVar2 = strstr(pcVar2,"[z");
    if (pcVar2 == (char *)0x0) {
      return 0;
    }
  }
  return 1;
}

// ==== CMsgChangeName::helper_140166f60  @140166f60  [medium:callgraph-r1]  (orig: FUN_140166f60)
undefined8 FUN_140166f60(longlong param_1)

{
  switch(*(undefined4 *)(param_1 + 0x100)) {
  case 0:
    return 1;
  case 1:
    return 2;
  case 2:
    return 3;
  case 3:
    return 4;
  case 4:
    return 5;
  case 5:
    return 10;
  case 6:
    return 0x1e;
  case 7:
    return 0x32;
  default:
    return 99;
  }
}

// ==== CMsgChangeName::helper_140178490  @140178490  [medium:callgraph-r0]  (orig: FUN_140178490)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140178490(longlong param_1)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  undefined8 uVar4;
  uint uVar5;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  cVar2 = FUN_14008abf0(uVar4);
  if (cVar2 == '\0') {
    uVar1 = *(uint *)(param_1 + 0x1054);
    iVar3 = FUN_140166f60(param_1);
    if ((int)(iVar3 - uVar1) < 0) {
      uVar5 = 0;
    }
    else {
      iVar3 = FUN_140166f60(param_1);
      uVar5 = iVar3 - uVar1;
    }
    FUN_1403ee140(local_448);
    iVar3 = FUN_1403ee230(local_448,3,uVar1 & 0xffff,uVar5 & 0xffff);
    if (iVar3 != 0) {
      (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_448);
    }
    FUN_1403ee190(local_448);
  }
  return;
}

// ==== CMsgChangeName::helper_1401bb9d0  @1401bb9d0  [medium:callgraph-r1]  (orig: FUN_1401bb9d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1401bb9d0(longlong *param_1,char *param_2)

{
  void *pvVar1;
  undefined8 *puVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  IStringManager *pIVar6;
  char *pcVar7;
  longlong *plVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong lVar11;
  undefined8 uVar12;
  ulonglong uVar13;
  void *pvVar14;
  undefined8 *puVar15;
  undefined8 *puVar16;
  longlong lVar17;
  bool bVar18;
  undefined1 auStack_be8 [32];
  char *local_bc8;
  undefined4 local_bc0;
  longlong *local_bb8 [3];
  void *local_ba0;
  void *local_b98;
  undefined8 local_b90;
  longlong *local_b88;
  undefined4 uStack_b80;
  undefined4 uStack_b7c;
  longlong *local_b78 [6];
  undefined8 *local_b48;
  undefined8 local_b40;
  longlong *local_b38 [2];
  undefined8 local_b28;
  undefined8 uStack_b20;
  undefined4 local_b18;
  undefined4 uStack_b14;
  undefined4 uStack_b10;
  undefined4 uStack_b0c;
  longlong *local_af8;
  undefined8 uStack_af0;
  longlong *local_ae8;
  undefined8 uStack_ae0;
  undefined8 *local_ad8;
  longlong *local_ac8;
  undefined8 uStack_ac0;
  longlong *local_ab8;
  undefined8 uStack_ab0;
  undefined8 local_aa8;
  undefined8 uStack_aa0;
  longlong *local_a98;
  undefined8 uStack_a90;
  longlong *local_a88;
  undefined8 uStack_a80;
  longlong *local_a78;
  undefined8 uStack_a70;
  longlong *local_a68 [2];
  longlong *local_a58;
  undefined4 local_a48;
  undefined4 uStack_a44;
  undefined4 uStack_a40;
  undefined4 uStack_a3c;
  undefined8 local_a38;
  undefined4 local_a28;
  undefined4 uStack_a24;
  undefined4 uStack_a20;
  undefined4 uStack_a1c;
  longlong *local_a18;
  longlong *local_a08;
  longlong *local_9f8;
  undefined4 local_9e8;
  undefined4 uStack_9e4;
  undefined4 uStack_9e0;
  undefined4 uStack_9dc;
  longlong *local_9d8;
  longlong *local_9c8;
  undefined1 local_9b8 [1104];
  undefined1 local_568 [1072];
  char local_138 [255];
  undefined1 local_39;
  ulonglong local_38;
  
  local_a38 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_be8;
  local_b28 = (longlong *)param_2;
  if (param_2 != (char *)0x0) {
    uVar13 = 0xffffffffffffffff;
    pcVar7 = param_2;
    do {
      if (uVar13 == 0) break;
      uVar13 = uVar13 - 1;
      cVar3 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar3 != '\0');
    if (~uVar13 - 1 < 0x10) {
      FUN_14000ef40(local_b78);
      memset(local_138,0,0x100);
      pIVar6 = theInstance();
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      pcVar7 = (char *)(*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_USER_CHANGENAMEOK");
      local_bc8 = param_2;
      _snprintf(local_138,0x100,pcVar7);
      local_39 = 0;
      FUN_140371dc0(param_1 + 0x1cf,param_2);
      FUN_140371580(param_1 + 0x1cf);
      iVar4 = (**(code **)(*param_1 + 0x48))(param_1);
      if (iVar4 != 0) {
        uVar5 = (**(code **)(*param_1 + 0x48))(param_1);
        local_b38[0] = (longlong *)CONCAT44(local_b38[0]._4_4_,uVar5);
        FUN_14000d480(local_b78,&local_b18,local_b38);
      }
      local_b38[0] = operator_new(8);
      if (local_b38[0] == (longlong *)0x0) {
        local_bb8[0] = (longlong *)0x0;
      }
      else {
        *local_b38[0] = (longlong)local_bb8;
        local_bb8[0] = local_b38[0];
      }
      lVar17 = 0;
      local_ba0 = (void *)0x0;
      local_b98 = (void *)0x0;
      local_b90 = 0;
      local_b88 = (longlong *)0x0;
      iVar4 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
      if (iVar4 != 0) {
        FUN_140036640(local_bb8);
        plVar8 = (longlong *)FUN_140087ed0();
        lVar11 = *plVar8;
        uVar5 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
        (**(code **)(lVar11 + 0x2b0))(plVar8,uVar5,local_bb8);
        pvVar14 = local_ba0;
        local_ac8 = (longlong *)0x0;
        if (local_b98 < local_ba0) {
          _invalid_parameter_noinfo();
        }
        plVar8 = local_bb8[0];
        local_ac8 = local_bb8[0];
        uStack_ac0 = pvVar14;
        uStack_ac0._0_4_ = SUB84(pvVar14,0);
        uStack_ac0._4_4_ = (undefined4)((ulonglong)pvVar14 >> 0x20);
        local_b88 = local_bb8[0];
        uStack_b80 = (undefined4)uStack_ac0;
        uStack_b7c = uStack_ac0._4_4_;
        uStack_ac0 = pvVar14;
        while( true ) {
          pvVar1 = local_b98;
          local_9c8 = (longlong *)0x0;
          if (local_b98 < local_ba0) {
            _invalid_parameter_noinfo();
          }
          local_9c8 = local_bb8[0];
          if ((plVar8 == (longlong *)0x0) || (plVar8 != local_bb8[0])) {
            _invalid_parameter_noinfo();
          }
          if (pvVar14 == pvVar1) break;
          if (plVar8 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar17;
          }
          else {
            lVar11 = *plVar8;
          }
          if (*(void **)(lVar11 + 0x20) <= pvVar14) {
            _invalid_parameter_noinfo();
          }
          FUN_14000d480(local_b78,&local_b18,pvVar14);
          if (plVar8 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar17;
          }
          else {
            lVar11 = *plVar8;
          }
          if (*(void **)(lVar11 + 0x20) <= pvVar14) {
            _invalid_parameter_noinfo();
          }
          pvVar14 = (void *)((longlong)pvVar14 + 4);
        }
      }
      FUN_140036640(local_bb8);
      plVar8 = (longlong *)FUN_1401183a0();
      lVar11 = *plVar8;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar11 + 0xf8))(plVar8,uVar5,local_bb8);
      pvVar14 = local_ba0;
      local_a78 = (longlong *)0x0;
      if (local_b98 < local_ba0) {
        _invalid_parameter_noinfo();
      }
      plVar8 = local_bb8[0];
      local_a78 = local_bb8[0];
      uStack_a70 = pvVar14;
      uStack_a70._0_4_ = SUB84(pvVar14,0);
      uStack_a70._4_4_ = (undefined4)((ulonglong)pvVar14 >> 0x20);
      local_b88 = local_bb8[0];
      uStack_b80 = (undefined4)uStack_a70;
      uStack_b7c = uStack_a70._4_4_;
      uStack_a70 = pvVar14;
      while( true ) {
        pvVar1 = local_b98;
        local_a58 = (longlong *)0x0;
        if (local_b98 < local_ba0) {
          _invalid_parameter_noinfo();
        }
        local_a58 = local_bb8[0];
        if ((plVar8 == (longlong *)0x0) || (plVar8 != local_bb8[0])) {
          _invalid_parameter_noinfo();
        }
        if (pvVar14 == pvVar1) break;
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar17;
        }
        else {
          lVar11 = *plVar8;
        }
        if (*(void **)(lVar11 + 0x20) <= pvVar14) {
          _invalid_parameter_noinfo();
        }
        FUN_14000d480(local_b78,&local_b18,pvVar14);
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar17;
        }
        else {
          lVar11 = *plVar8;
        }
        if (*(void **)(lVar11 + 0x20) <= pvVar14) {
          _invalid_parameter_noinfo();
        }
        pvVar14 = (void *)((longlong)pvVar14 + 4);
      }
      FUN_140036640(local_bb8);
      plVar8 = (longlong *)FUN_1401183a0();
      lVar11 = *plVar8;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar11 + 0x1d0))(plVar8,uVar5,local_bb8);
      pvVar14 = local_ba0;
      local_a88 = (longlong *)0x0;
      if (local_b98 < local_ba0) {
        _invalid_parameter_noinfo();
      }
      plVar8 = local_bb8[0];
      local_a88 = local_bb8[0];
      uStack_a80 = pvVar14;
      uStack_a80._0_4_ = SUB84(pvVar14,0);
      uStack_a80._4_4_ = (undefined4)((ulonglong)pvVar14 >> 0x20);
      local_b88 = local_bb8[0];
      uStack_b80 = (undefined4)uStack_a80;
      uStack_b7c = uStack_a80._4_4_;
      uStack_a80 = pvVar14;
      while( true ) {
        pvVar1 = local_b98;
        local_a18 = (longlong *)0x0;
        if (local_b98 < local_ba0) {
          _invalid_parameter_noinfo();
        }
        local_a18 = local_bb8[0];
        if ((plVar8 == (longlong *)0x0) || (plVar8 != local_bb8[0])) {
          _invalid_parameter_noinfo();
        }
        if (pvVar14 == pvVar1) break;
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar17;
        }
        else {
          lVar11 = *plVar8;
        }
        if (*(void **)(lVar11 + 0x20) <= pvVar14) {
          _invalid_parameter_noinfo();
        }
        FUN_14000d480(local_b78,&local_b18,pvVar14);
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar17;
        }
        else {
          lVar11 = *plVar8;
        }
        if (*(void **)(lVar11 + 0x20) <= pvVar14) {
          _invalid_parameter_noinfo();
        }
        pvVar14 = (void *)((longlong)pvVar14 + 4);
      }
      FUN_140036640(local_bb8);
      plVar8 = (longlong *)FUN_1401183a0();
      lVar11 = *plVar8;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar11 + 0x150))(plVar8,uVar5,local_bb8);
      pvVar14 = local_ba0;
      local_af8 = (longlong *)0x0;
      if (local_b98 < local_ba0) {
        _invalid_parameter_noinfo();
      }
      plVar8 = local_bb8[0];
      local_af8 = local_bb8[0];
      uStack_af0 = pvVar14;
      uStack_af0._0_4_ = SUB84(pvVar14,0);
      uStack_af0._4_4_ = (undefined4)((ulonglong)pvVar14 >> 0x20);
      local_b88 = local_bb8[0];
      uStack_b80 = (undefined4)uStack_af0;
      uStack_b7c = uStack_af0._4_4_;
      uStack_af0 = pvVar14;
      while( true ) {
        pvVar1 = local_b98;
        local_9f8 = (longlong *)0x0;
        if (local_b98 < local_ba0) {
          _invalid_parameter_noinfo();
        }
        local_9f8 = local_bb8[0];
        if ((plVar8 == (longlong *)0x0) || (plVar8 != local_bb8[0])) {
          _invalid_parameter_noinfo();
        }
        if (pvVar14 == pvVar1) break;
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar17;
        }
        else {
          lVar11 = *plVar8;
        }
        if (*(void **)(lVar11 + 0x20) <= pvVar14) {
          _invalid_parameter_noinfo();
        }
        FUN_14000d480(local_b78,&local_b18,pvVar14);
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar17;
        }
        else {
          lVar11 = *plVar8;
        }
        if (*(void **)(lVar11 + 0x20) <= pvVar14) {
          _invalid_parameter_noinfo();
        }
        pvVar14 = (void *)((longlong)pvVar14 + 4);
      }
      iVar4 = FUN_140164ac0(param_1);
      if (iVar4 != 0) {
        FUN_140036640(local_bb8);
        plVar8 = (longlong *)CurrentInstanceGet();
        if (plVar8 == (longlong *)0x0) {
          local_bc8 = (char *)CONCAT44(local_bc8._4_4_,0x60d0);
          log_InlineLogERROR(&DAT_1406d9c10);
          if (local_ba0 != (void *)0x0) {
            operator_delete(local_ba0);
          }
          local_ba0 = (void *)0x0;
          local_b98 = (void *)0x0;
          local_b90 = 0;
          operator_delete(local_bb8[0]);
          uStack_b20 = local_b48;
          puVar15 = uStack_b20;
          local_b28 = local_b78[0];
          plVar8 = local_b28;
          uVar9 = *local_b48;
          local_a98 = local_b78[0];
          local_b28._0_4_ = SUB84(local_b78[0],0);
          local_b28._4_4_ = (undefined4)((ulonglong)local_b78[0] >> 0x20);
          uStack_b20._0_4_ = SUB84(local_b48,0);
          uStack_b20._4_4_ = (undefined4)((ulonglong)local_b48 >> 0x20);
          local_9e8 = (undefined4)local_b28;
          uStack_9e4 = local_b28._4_4_;
          uStack_9e0 = (undefined4)uStack_b20;
          uStack_9dc = uStack_b20._4_4_;
          uStack_a90._0_4_ = (undefined4)uVar9;
          uStack_a90._4_4_ = (undefined4)((ulonglong)uVar9 >> 0x20);
          local_a28 = (undefined4)local_b28;
          uStack_a24 = local_b28._4_4_;
          uStack_a20 = (undefined4)uStack_a90;
          uStack_a1c = uStack_a90._4_4_;
          local_b28 = plVar8;
          uStack_b20 = puVar15;
          uStack_a90 = uVar9;
          FUN_14000bd50(local_b78,&local_b18,&local_a28,&local_9e8);
          operator_delete(local_b48);
          local_b48 = (undefined8 *)0x0;
          local_b40 = 0;
          operator_delete(local_b78[0]);
          return 0;
        }
        plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,8);
        if (plVar8 != (longlong *)0x0) {
          lVar11 = *plVar8;
          uVar5 = FUN_140164ac0(param_1);
          (**(code **)(lVar11 + 0x1e8))(plVar8,uVar5,local_bb8);
        }
        pvVar14 = local_ba0;
        local_ab8 = (longlong *)0x0;
        if (local_b98 < local_ba0) {
          _invalid_parameter_noinfo();
        }
        plVar8 = local_bb8[0];
        local_ab8 = local_bb8[0];
        uStack_ab0 = pvVar14;
        uStack_ab0._0_4_ = SUB84(pvVar14,0);
        uStack_ab0._4_4_ = (undefined4)((ulonglong)pvVar14 >> 0x20);
        local_b88 = local_bb8[0];
        uStack_b80 = (undefined4)uStack_ab0;
        uStack_b7c = uStack_ab0._4_4_;
        uStack_ab0 = pvVar14;
        while( true ) {
          pvVar1 = local_b98;
          local_9d8 = (longlong *)0x0;
          if (local_b98 < local_ba0) {
            _invalid_parameter_noinfo();
          }
          local_9d8 = local_bb8[0];
          if ((plVar8 == (longlong *)0x0) || (plVar8 != local_bb8[0])) {
            _invalid_parameter_noinfo();
          }
          if (pvVar14 == pvVar1) break;
          if (plVar8 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar17;
          }
          else {
            lVar11 = *plVar8;
          }
          if (*(void **)(lVar11 + 0x20) <= pvVar14) {
            _invalid_parameter_noinfo();
          }
          FUN_14000d480(local_b78,&local_b18,pvVar14);
          if (plVar8 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar17;
          }
          else {
            lVar11 = *plVar8;
          }
          if (*(void **)(lVar11 + 0x20) <= pvVar14) {
            _invalid_parameter_noinfo();
          }
          pvVar14 = (void *)((longlong)pvVar14 + 4);
        }
      }
      plVar8 = local_b78[0];
      puVar15 = (undefined8 *)*local_b48;
      local_a08 = local_b78[0];
      do {
        while( true ) {
          while( true ) {
            puVar16 = local_b48;
            local_a68[0] = local_b78[0];
            if ((plVar8 == (longlong *)0x0) || (plVar8 != local_b78[0])) {
              _invalid_parameter_noinfo();
            }
            if (puVar15 == puVar16) {
              FUN_1403ee140(local_568);
              uVar9 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              iVar4 = FUN_1403ee1c0(local_568,uVar9,1);
              if (iVar4 != 0) {
                (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_568);
              }
              uVar9 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              uVar5 = (**(code **)(*param_1 + 8))(param_1);
              uVar12 = FUN_140008520((int)param_1[0x246]);
              FUN_14008a950(uVar12,uVar5,uVar9,100);
              plVar8 = (longlong *)FUN_140087ed0();
              if (plVar8 != (longlong *)0x0) {
                lVar17 = *plVar8;
                uVar5 = (**(code **)(*param_1 + 8))(param_1);
                (**(code **)(lVar17 + 0x4f0))(plVar8,uVar5,local_b28);
                lVar17 = *plVar8;
                uVar5 = (**(code **)(*param_1 + 8))(param_1);
                cVar3 = (**(code **)(lVar17 + 0x410))(plVar8,uVar5);
                if (cVar3 != '\0') {
                  FUN_1403f36a0(local_9b8);
                  lVar17 = *plVar8;
                  uVar9 = (**(code **)(lVar17 + 0x450))(plVar8);
                  uVar5 = (**(code **)(*param_1 + 8))(param_1);
                  uVar5 = (**(code **)(lVar17 + 0x510))(plVar8,uVar5);
                  iVar4 = FUN_1403f3790(local_9b8,1,uVar5,uVar9);
                  if (iVar4 != 0) {
                    (**(code **)(*param_1 + 0x130))(param_1,local_9b8);
                  }
                  FUN_1403f3720(local_9b8);
                }
              }
              FUN_1403ee190(local_568);
              if (local_ba0 != (void *)0x0) {
                operator_delete(local_ba0);
              }
              local_ba0 = (void *)0x0;
              local_b98 = (void *)0x0;
              local_b90 = 0;
              operator_delete(local_bb8[0]);
              uStack_aa0 = local_b48;
              puVar15 = uStack_aa0;
              local_aa8 = local_b78[0];
              plVar8 = local_aa8;
              uVar9 = *local_b48;
              local_ae8 = local_b78[0];
              local_aa8._0_4_ = SUB84(local_b78[0],0);
              local_aa8._4_4_ = (undefined4)((ulonglong)local_b78[0] >> 0x20);
              uStack_aa0._0_4_ = SUB84(local_b48,0);
              uStack_aa0._4_4_ = (undefined4)((ulonglong)local_b48 >> 0x20);
              local_a48 = (undefined4)local_aa8;
              uStack_a44 = local_aa8._4_4_;
              uStack_a40 = (undefined4)uStack_aa0;
              uStack_a3c = uStack_aa0._4_4_;
              uStack_ae0._0_4_ = (undefined4)uVar9;
              uStack_ae0._4_4_ = (undefined4)((ulonglong)uVar9 >> 0x20);
              local_b18 = (undefined4)local_aa8;
              uStack_b14 = local_aa8._4_4_;
              uStack_b10 = (undefined4)uStack_ae0;
              uStack_b0c = uStack_ae0._4_4_;
              uStack_ae0 = uVar9;
              local_aa8 = plVar8;
              uStack_aa0 = puVar15;
              FUN_14000bd50(local_b78,local_a68,&local_b18,&local_a48);
              operator_delete(local_b48);
              local_b48 = (undefined8 *)0x0;
              local_b40 = 0;
              operator_delete(local_b78[0]);
              return 1;
            }
            if (plVar8 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar11 = lVar17;
            }
            else {
              lVar11 = *plVar8;
            }
            if (puVar15 == *(undefined8 **)(lVar11 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            uVar5 = *(undefined4 *)(puVar15 + 3);
            uVar9 = FUN_140008520((int)param_1[0x246]);
            plVar10 = (longlong *)FUN_140087650(uVar9);
            lVar11 = (**(code **)(*plVar10 + 0x98))(plVar10,uVar5);
            if (lVar11 == 0) {
              plVar10 = (longlong *)FUN_1400e1de0();
              lVar11 = *plVar10;
              uVar9 = (**(code **)(param_1[2] + 0x18))();
              local_bc0 = 0;
              local_bc8 = (char *)CONCAT44(local_bc8._4_4_,6);
              (**(code **)(lVar11 + 8))(plVar10,uVar9,uVar5,local_138);
            }
            if (plVar8 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)puVar15 + 0x1d) == '\0') break;
            _invalid_parameter_noinfo();
          }
          puVar16 = puVar15;
          puVar2 = (undefined8 *)puVar15[2];
          if (*(char *)((longlong)puVar15[2] + 0x1d) != '\0') break;
          do {
            puVar15 = puVar2;
            puVar2 = (undefined8 *)*puVar15;
            local_ad8 = puVar15;
          } while (*(char *)((longlong)*puVar15 + 0x1d) == '\0');
        }
        do {
          puVar15 = (undefined8 *)puVar16[1];
          if (*(char *)((longlong)puVar15 + 0x1d) != '\0') break;
          bVar18 = puVar16 == (undefined8 *)puVar15[2];
          puVar16 = puVar15;
        } while (bVar18);
      } while( true );
    }
  }
  local_bc8 = (char *)CONCAT44(local_bc8._4_4_,0x608f);
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMsgChangeName::helper_1401bc650  @1401bc650  [medium:callgraph-r0]  (orig: FUN_1401bc650)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401bc650(longlong *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  IStringManager *pIVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 *puVar9;
  char *pcVar10;
  ulonglong uVar11;
  undefined1 auStack_e68 [32];
  char *local_e48;
  char *local_e40;
  undefined4 local_e38;
  undefined2 local_e30;
  undefined4 local_e28;
  undefined4 local_e20;
  undefined1 local_e18;
  int local_e08;
  char *local_e00;
  longlong *local_df8;
  undefined8 local_df0;
  undefined1 local_de8 [1104];
  undefined1 local_998 [1104];
  undefined1 local_548;
  undefined7 uStack_547;
  undefined4 uStack_540;
  undefined1 uStack_53c;
  undefined1 local_53b;
  undefined1 uStack_53a;
  undefined1 local_539;
  char local_538 [255];
  undefined1 local_439;
  char local_438 [1023];
  undefined1 local_39;
  ulonglong local_38;
  
  if (param_2 != (char *)0x0) {
    local_df0 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_e68;
    uVar11 = 0xffffffffffffffff;
    pcVar10 = param_2;
    do {
      if (uVar11 == 0) break;
      uVar11 = uVar11 - 1;
      cVar1 = *pcVar10;
      pcVar10 = pcVar10 + 1;
    } while (cVar1 != '\0');
    if (~uVar11 - 1 < 0x10) {
      iVar3 = *(int *)((longlong)param_1 + 0x1054);
      local_e08 = iVar3;
      local_e00 = param_2;
      local_df8 = param_1;
      uVar5 = FUN_140008520((int)param_1[0x246]);
      cVar1 = FUN_14008abf0(uVar5);
      if ((cVar1 == '\0') && (iVar2 = FUN_140166f60(param_1), iVar2 <= iVar3)) {
        pIVar6 = theInstance();
        lVar8 = param_1[2];
        uVar5 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_CHANGENAME_NUM_LIMIT");
        (**(code **)(lVar8 + 0x358))(param_1 + 2,uVar5);
      }
      else if (0x329 < *(uint *)((longlong)param_1 + 0xfa4)) {
        iVar2 = tq::NameStrCheck(param_2,false);
        if (iVar2 != 0) {
          uVar5 = FUN_140008520((int)param_1[0x246]);
          cVar1 = FUN_14008a1d0(uVar5,param_2,0);
          if (cVar1 == '\0') {
            _snprintf(local_438,0x400,"SELECT * FROM cq_user WHERE name = \'%s\' LIMIT 1");
            local_39 = 0;
            FUN_140008520((int)param_1[0x246]);
            plVar7 = (longlong *)InstanceGet();
            plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,local_438,2);
            if ((plVar7 != (longlong *)0x0) &&
               (lVar8 = (**(code **)(*plVar7 + 0x40))(plVar7), lVar8 != 0)) {
              FUN_1403ee140(local_de8);
              iVar3 = FUN_1403ee230(local_de8,2,0);
              if (iVar3 != 0) {
                (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_de8);
              }
              (**(code **)*plVar7)(plVar7);
              FUN_1403ee190(local_de8);
              return;
            }
            if (plVar7 != (longlong *)0x0) {
              (**(code **)*plVar7)(plVar7);
            }
            local_548 = 0;
            uStack_547 = 0;
            uStack_540 = 0;
            uStack_53c = 0;
            local_53b = 0;
            uStack_53a = 0;
            local_539 = 0;
            puVar9 = (undefined8 *)(**(code **)(param_1[2] + 0x18))(param_1 + 2);
            local_548 = (undefined1)*puVar9;
            uStack_547 = (undefined7)((ulonglong)*puVar9 >> 8);
            uStack_540 = *(undefined4 *)(puVar9 + 1);
            uStack_53c = (undefined1)*(undefined2 *)((longlong)puVar9 + 0xc);
            local_53b = (undefined1)((ushort)*(undefined2 *)((longlong)puVar9 + 0xc) >> 8);
            uStack_53a = *(undefined1 *)((longlong)puVar9 + 0xe);
            local_e48 = (char *)0x0;
            cVar1 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,0xfffffffffffffcd6,1);
            if (cVar1 != '\0') {
              uVar4 = (**(code **)(*param_1 + 8))(param_1);
              local_e48 = (char *)CONCAT44(local_e48._4_4_,0x32a);
              FUN_1401742b0(param_1,0x19,uVar4,0);
              FUN_140373d50(param_1 + 0x1cf,iVar3 + 1,0);
              pIVar6 = theInstance();
              lVar8 = param_1[2];
              (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_CHANGENAME_SUCCESS");
              (**(code **)(lVar8 + 0x358))(param_1 + 2);
              memset(local_538,0,0x100);
              pIVar6 = theInstance();
              (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              pcVar10 = (char *)(*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_CHANGENAME");
              local_e48 = param_2;
              _snprintf(local_538,0x100,pcVar10);
              local_439 = 0;
              FUN_14015b240(local_998);
              local_e18 = 1;
              local_e20 = 0;
              local_e28 = 0;
              local_e30 = 0;
              local_e38 = CONCAT22(local_e38._2_2_,2000);
              local_e40 = (char *)CONCAT44(local_e40._4_4_,0xff0000);
              local_e48 = (char *)0x0;
              iVar3 = FUN_14015b300(local_998,"SYSTEM","ALLUSERS",local_538);
              if (iVar3 != 0) {
                plVar7 = (longlong *)FUN_140008520((int)param_1[0x246]);
                (**(code **)(*plVar7 + 0x68))(plVar7,local_998,0xffffffff);
              }
              cVar1 = FUN_1401bb9d0(param_1,param_2);
              if (cVar1 == '\0') {
                (**(code **)(*param_1 + 8))(param_1);
                log_InlineLogERROR("CUser::ApplyChangeName. User[%u] NewName[%s] Change Name Fail!")
                ;
              }
              lVar8 = param_1[0x1e2];
              (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              (**(code **)(*param_1 + 8))(param_1);
              local_e38 = 0x32a;
              local_e40._0_4_ = 0x32a;
              local_e48 = (char *)CONCAT44(local_e48._4_4_,(int)lVar8);
              tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t114\t13\t%d\t%d\t1\t");
              (**(code **)(*param_1 + 8))(param_1);
              local_e40 = (char *)CONCAT44(local_e40._4_4_,0x32a);
              local_e48 = param_2;
              tq::MyLogSave("gmlog/changename",
                            "User[%d] OldName[%s] NewName[%s] pay EMONEY[%d] for ChangeName");
              memset(local_438,0,0x400);
              (**(code **)(*param_1 + 8))(param_1);
              local_e48 = &local_548;
              local_e40 = param_2;
              _snprintf(local_438,0x400,
                        "INSERT cq_changename_backup SET iduser=\'%u\',oldname=\'%s\',newname=\'%s\'"
                       );
              local_39 = 0;
              FUN_140008520((int)param_1[0x246]);
              plVar7 = (longlong *)InstanceGet();
              (**(code **)(*plVar7 + 0x30))(plVar7,local_438,0,1);
              FUN_14015b2c0(local_998);
              return;
            }
            (**(code **)(*param_1 + 8))(param_1);
            tq::MyLogSave("gmlog/changenamefail","User[%d] Pay Emoney[%d] to changename fail");
            return;
          }
        }
        FUN_14015b240(local_de8);
        pIVar6 = theInstance();
        uVar5 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_ILLEGAL_NAME1");
        local_e18 = 1;
        local_e20 = 0;
        local_e28 = 0;
        local_e30 = 0;
        local_e38 = CONCAT22(local_e38._2_2_,2000);
        local_e40 = (char *)CONCAT44(local_e40._4_4_,0xff0000);
        local_e48 = (char *)0x0;
        iVar3 = FUN_14015b300(local_de8,"SYSTEM","ALLUSERS",uVar5);
        if (iVar3 != 0) {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_de8);
        }
        FUN_14015b2c0(local_de8);
      }
    }
  }
  return;
}

// ==== CMsgChangeName::helper_1401bcc20  @1401bcc20  [medium:callgraph-r0]  (orig: FUN_1401bcc20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401bcc20(longlong *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  IStringManager *pIVar6;
  char *pcVar7;
  ulonglong uVar8;
  undefined1 auStack_e48 [32];
  char *local_e28;
  undefined4 local_e20;
  undefined2 local_e18;
  undefined2 local_e10;
  undefined4 local_e08;
  undefined4 local_e00;
  undefined1 local_df8;
  longlong *local_de8;
  char *local_de0;
  undefined8 local_dd8;
  undefined1 local_dc8 [1104];
  undefined1 local_978 [1104];
  char local_528 [255];
  undefined1 local_429;
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  if (param_2 != (char *)0x0) {
    local_dd8 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_e48;
    uVar8 = 0xffffffffffffffff;
    pcVar7 = param_2;
    do {
      if (uVar8 == 0) break;
      uVar8 = uVar8 - 1;
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    if (~uVar8 - 1 < 0x10) {
      local_de8 = param_1;
      local_de0 = param_2;
      (**(code **)(*param_1 + 8))(param_1);
      cVar1 = FUN_140166f00(param_1);
      if (cVar1 != '\0') {
        iVar2 = tq::NameStrCheck(param_2,false);
        if (iVar2 != 0) {
          uVar3 = FUN_140008520((int)param_1[0x246]);
          cVar1 = FUN_14008a1d0(uVar3,param_2,0);
          if (cVar1 == '\0') {
            _snprintf(local_428,0x400,"SELECT * FROM cq_user WHERE name = \'%s\' LIMIT 1");
            local_29 = 0;
            FUN_140008520((int)param_1[0x246]);
            plVar4 = (longlong *)InstanceGet();
            plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,local_428,2);
            if ((plVar4 != (longlong *)0x0) &&
               (lVar5 = (**(code **)(*plVar4 + 0x40))(plVar4), lVar5 != 0)) {
              FUN_1403ee140(local_dc8);
              iVar2 = FUN_1403ee230(local_dc8,2,0);
              if (iVar2 != 0) {
                (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_dc8);
              }
              (**(code **)*plVar4)(plVar4);
              FUN_1403ee190(local_dc8);
              return;
            }
            if (plVar4 != (longlong *)0x0) {
              (**(code **)*plVar4)(plVar4);
            }
            memset(local_428,0,0x400);
            _snprintf(local_428,0x400,"SELECT * FROM cq_deluser WHERE name = \'%s\' LIMIT 1");
            local_29 = 0;
            FUN_140008520((int)param_1[0x246]);
            plVar4 = (longlong *)InstanceGet();
            plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,local_428,2);
            if ((plVar4 != (longlong *)0x0) &&
               (lVar5 = (**(code **)(*plVar4 + 0x40))(plVar4), lVar5 != 0)) {
              FUN_1403ee140(local_dc8);
              iVar2 = FUN_1403ee230(local_dc8,2,0);
              if (iVar2 != 0) {
                (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_dc8);
              }
              (**(code **)*plVar4)(plVar4);
              FUN_1403ee190(local_dc8);
              return;
            }
            if (plVar4 != (longlong *)0x0) {
              (**(code **)*plVar4)(plVar4);
            }
            pIVar6 = theInstance();
            lVar5 = param_1[2];
            (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_CHANGENAME_SUCCESS");
            (**(code **)(lVar5 + 0x358))(param_1 + 2);
            memset(local_528,0,0x100);
            pIVar6 = theInstance();
            (**(code **)(param_1[2] + 0x18))(param_1 + 2);
            pcVar7 = (char *)(*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_CHANGENAME");
            local_e28 = param_2;
            _snprintf(local_528,0x100,pcVar7);
            local_429 = 0;
            FUN_14015b240(local_978);
            local_df8 = 1;
            local_e00 = 0;
            local_e08 = 0;
            local_e10 = 0;
            local_e18 = 2000;
            local_e20 = 0xff0000;
            local_e28 = (char *)0x0;
            iVar2 = FUN_14015b300(local_978,"SYSTEM","ALLUSERS",local_528);
            if (iVar2 != 0) {
              plVar4 = (longlong *)FUN_140008520((int)param_1[0x246]);
              (**(code **)(*plVar4 + 0x68))(plVar4,local_978,0xffffffff);
            }
            cVar1 = FUN_1401bb9d0(param_1,param_2);
            if (cVar1 == '\0') {
              (**(code **)(*param_1 + 8))(param_1);
              log_InlineLogERROR(
                                "CUser::ApplyForceChangeName. User[%u] NewName[%s] Change Name Fail!"
                                );
            }
            (**(code **)(param_1[2] + 0x18))(param_1 + 2);
            (**(code **)(*param_1 + 8))(param_1);
            local_e28 = param_2;
            tq::MyLogSave("gmlog/changename","User[%d] OldName[%s] NewName[%s]  for ForceChangeName"
                         );
            FUN_14015b2c0(local_978);
            return;
          }
        }
        FUN_14015b240(local_dc8);
        pIVar6 = theInstance();
        uVar3 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_ILLEGAL_NAME1");
        local_df8 = 1;
        local_e00 = 0;
        local_e08 = 0;
        local_e10 = 0;
        local_e18 = 2000;
        local_e20 = 0xff0000;
        local_e28 = (char *)0x0;
        iVar2 = FUN_14015b300(local_dc8,"SYSTEM","ALLUSERS",uVar3);
        if (iVar2 != 0) {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_dc8);
        }
        FUN_14015b2c0(local_dc8);
      }
    }
  }
  return;
}

// ==== CMsgChangeName::helper_140371dc0  @140371dc0  [medium:callgraph-r2]  (orig: FUN_140371dc0)
void FUN_140371dc0(longlong param_1,char *param_2)

{
  char cVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  char *pcVar5;
  
  if (param_2 != (char *)0x0) {
    uVar3 = 0xffffffffffffffff;
    pcVar5 = param_2;
    do {
      if (uVar3 == 0) break;
      uVar3 = uVar3 - 1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    if (~uVar3 - 1 < 0x10) {
      lVar4 = (param_1 + 0x10) - (longlong)param_2;
      do {
        cVar1 = *param_2;
        param_2 = param_2 + 1;
        param_2[lVar4 + -1] = cVar1;
      } while (cVar1 != '\0');
      if (*(longlong *)(param_1 + 0x230) != 0) {
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                           (*(longlong **)(param_1 + 0x230),&DAT_1406ef6e0);
        (**(code **)(*plVar2 + 0x80))(plVar2,param_1 + 0x10);
      }
    }
  }
  return;
}

// ==== CMsgChangeName::helper_140373d50  @140373d50  [medium:callgraph-r1]  (orig: FUN_140373d50)
void FUN_140373d50(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x1dc) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"changenamerecord");
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CMsgChangeName::ctor_or_dtor  @1403ee140  [high:vtable-assign]  (orig: FUN_1403ee140)
undefined8 * FUN_1403ee140(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgChangeName::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgChangeName::ctor_or_dtor  @1403ee190  [high:vtable-assign]  (orig: FUN_1403ee190)
void FUN_1403ee190(undefined8 *param_1)

{
  *param_1 = CMsgChangeName::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgChangeName::helper_1403ee1c0  @1403ee1c0  [medium:callgraph-r2]  (orig: FUN_1403ee1c0)
undefined8 FUN_1403ee1c0(longlong param_1,char *param_2,undefined2 param_3)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x16;
  *(undefined4 *)(param_1 + 8) = 0x820;
  **(undefined2 **)(param_1 + 0x428) = param_3;
  strncpy((char *)(*(longlong *)(param_1 + 0x428) + 6),param_2,0xf);
  return 1;
}

// ==== CMsgChangeName::vfunc_1  @1403ee2a0  [high:rtti-vtable]  (orig: FUN_1403ee2a0)
undefined8 FUN_1403ee2a0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgChangeName::ctor_or_dtor  @1403ee2d0  [high:vtable-assign]  (orig: FUN_1403ee2d0)
undefined8 * FUN_1403ee2d0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgChangeName::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgChangeName::vfunc_3  @1403ee320  [high:rtti-vtable]  (orig: FUN_1403ee320)
void FUN_1403ee320(longlong param_1)

{
  short sVar1;
  short *psVar2;
  longlong lVar3;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))(*(longlong **)(lVar3 + 0x90),param_1);
  if (lVar3 != 0) {
    psVar2 = *(short **)(param_1 + 0x428);
    sVar1 = *psVar2;
    if (sVar1 == 0) {
      FUN_1401bc650(lVar3,psVar2 + 3);
    }
    else if (sVar1 == 3) {
      FUN_140178490(lVar3);
    }
    else if (sVar1 == 4) {
      FUN_1401bcc20(lVar3,psVar2 + 3);
    }
    else {
      log_InlineLogERROR("Receive Error MsgChangeName");
    }
  }
  return;
}

