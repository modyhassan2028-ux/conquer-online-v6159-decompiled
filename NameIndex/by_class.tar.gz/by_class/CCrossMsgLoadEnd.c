// ==== CCrossMsgLoadEnd::helper_14008b080  @14008b080  [medium:callgraph-r2]  (orig: FUN_14008b080)
void FUN_14008b080(longlong param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  *param_2 = *(undefined4 *)(param_1 + 0x720);
  *param_3 = *(undefined4 *)(param_1 + 0x724);
  param_3[1] = *(undefined4 *)(param_1 + 0x728);
  *param_4 = *(undefined4 *)(param_1 + 0x72c);
  return;
}

// ==== CCrossMsgLoadEnd::helper_1400a89f0  @1400a89f0  [medium:callgraph-r3]  (orig: FUN_1400a89f0)
longlong * FUN_1400a89f0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x49) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x49) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CCrossMsgLoadEnd::helper_1400b4910  @1400b4910  [medium:callgraph-r2]  (orig: FUN_1400b4910)
void FUN_1400b4910(longlong param_1,int param_2,undefined4 *param_3,undefined8 *param_4,
                  undefined4 *param_5)

{
  longlong lVar1;
  longlong lVar2;
  int local_res10 [2];
  longlong *local_28;
  longlong local_20;
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_1400a89f0((longlong *)(param_1 + 0x438),&local_28,local_res10);
    lVar1 = *(longlong *)(param_1 + 0x468);
    if ((local_28 == (longlong *)0x0) || (local_28 != *(longlong **)(param_1 + 0x438))) {
      _invalid_parameter_noinfo();
    }
    if (local_20 != lVar1) {
      lVar1 = 0;
      if (local_28 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar2 = lVar1;
      }
      else {
        lVar2 = *local_28;
      }
      if (local_20 == *(longlong *)(lVar2 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *param_3 = *(undefined4 *)(local_20 + 0x34);
      if (local_28 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar2 = lVar1;
      }
      else {
        lVar2 = *local_28;
      }
      if (local_20 == *(longlong *)(lVar2 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *param_4 = *(undefined8 *)(local_20 + 0x38);
      if (local_28 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar1 = *local_28;
      }
      if (local_20 == *(longlong *)(lVar1 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *param_5 = *(undefined4 *)(local_20 + 0x40);
    }
  }
  return;
}

// ==== CCrossMsgLoadEnd::helper_1400f8060  @1400f8060  [medium:callgraph-r1]  (orig: FUN_1400f8060)
undefined8 FUN_1400f8060(longlong param_1,undefined1 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c58;
  *(undefined4 *)(param_1 + 0xc) = 8;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 4) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CCrossMsgLoadEnd::helper_140179c90  @140179c90  [medium:callgraph-r1]  (orig: FUN_140179c90)
int FUN_140179c90(longlong param_1,undefined8 *param_2)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong lVar5;
  int local_res8 [2];
  undefined4 local_res18 [2];
  undefined4 local_res20 [2];
  undefined8 in_stack_ffffffffffffffa8;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 local_48 [2];
  undefined4 local_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  int local_30;
  undefined4 local_2c;
  undefined4 local_28;
  
  uVar7 = (undefined4)((ulonglong)in_stack_ffffffffffffffa8 >> 0x20);
  iVar2 = *(int *)(param_1 + 0x1334);
  local_res8[0] = 0;
  local_res18[0] = 0;
  if (iVar2 == 0) {
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    iVar2 = FUN_14008b420(uVar4);
    if ((iVar2 != *(int *)(param_1 + 0x135c)) || (iVar2 = *(int *)(param_1 + 0x1360), iVar2 == 0)) {
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
      FUN_14008b080(uVar4,local_res8,&local_40,local_res18);
      goto LAB_140179f68;
    }
  }
  else {
    if (iVar2 != 1) {
      if (iVar2 == 2) {
        plVar3 = (longlong *)CurrentInstanceGet();
        if (plVar3 != (longlong *)0x0) {
          uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
          cVar1 = FUN_14008b330(uVar4);
          if (cVar1 != '\0') {
            plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,0x25);
            if (plVar3 != (longlong *)0x0) {
              local_res8[0] = (**(code **)(*plVar3 + 0x28))(plVar3);
              uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
              plVar3 = (longlong *)FUN_1400876b0(uVar4);
              lVar5 = (**(code **)(*plVar3 + 0x10))(plVar3,local_res8[0],1);
              if (lVar5 != 0) {
                local_38 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                                     (*(longlong **)(lVar5 + 0x58),0xb);
                uStack_34 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                                      (*(longlong **)(lVar5 + 0x58),0xc);
                local_res20[0] = 0;
                local_48[0] = 0;
                *param_2 = CONCAT44(uStack_34,local_38);
                cVar1 = FUN_1402c4200(lVar5,0x18,local_res20,local_48);
                if (cVar1 != '\0') {
                  *(undefined4 *)param_2 = local_res20[0];
                  *(undefined4 *)((longlong)param_2 + 4) = local_48[0];
                  return local_res8[0];
                }
                local_res18[0] = 0x3c;
              }
            }
            goto LAB_140179f68;
          }
        }
        log_InlineLogERROR("CUser::GetOtherServerInitMap, can not get froniter flag war map id");
        uVar7 = *(undefined4 *)(param_1 + 0x12fc);
        uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
        puVar6 = local_res18;
        FUN_1400b4910(uVar4,uVar7,local_res8,&local_40,puVar6);
        uVar7 = (undefined4)((ulonglong)puVar6 >> 0x20);
      }
      goto LAB_140179f68;
    }
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    iVar2 = FUN_14008b420(uVar4);
    if ((iVar2 != *(int *)(param_1 + 0x135c)) || (iVar2 = *(int *)(param_1 + 0x1360), iVar2 == 0)) {
      iVar2 = *(int *)(param_1 + 0x132c);
      if (iVar2 == 0) {
        iVar2 = *(int *)(param_1 + 0x12fc);
      }
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
      puVar6 = local_res18;
      FUN_1400b4910(uVar4,iVar2,local_res8,&local_40,puVar6);
      uVar7 = (undefined4)((ulonglong)puVar6 >> 0x20);
      goto LAB_140179f68;
    }
  }
  local_40 = *(undefined4 *)(param_1 + 0x1364);
  uStack_3c = *(undefined4 *)(param_1 + 0x1368);
  local_res8[0] = iVar2;
  uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  uVar4 = FUN_1400d6610(uVar4);
  iVar2 = FUN_140006d00(uVar4);
  if (iVar2 < 1) {
    local_res18[0] = 1;
  }
  else {
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    uVar4 = FUN_1400d6610(uVar4);
    local_res18[0] = FUN_140006d00(uVar4);
  }
  *(undefined4 *)(param_1 + 0x135c) = 0;
  *(undefined4 *)(param_1 + 0x1360) = 0;
  *(undefined4 *)(param_1 + 0x1364) = 0;
  *(undefined4 *)(param_1 + 0x1368) = 0;
LAB_140179f68:
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  if (*(longlong *)(lVar5 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x98) + 0x10))
                    (*(longlong **)(lVar5 + 0x98),local_res8[0],1);
  if (lVar5 != 0) {
    *param_2 = CONCAT44(uStack_3c,local_40);
    cVar1 = FUN_1402c4410(lVar5,param_2,(longlong)param_2 + 4,local_res18[0],
                          CONCAT44(uVar7,local_res18[0]));
    if (cVar1 != '\0') {
      return local_res8[0];
    }
  }
  local_30 = 0;
  local_2c = 0;
  local_28 = 0;
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  if (*(longlong *)(lVar5 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006c50(*(undefined8 *)(lVar5 + 0xb0),&local_30);
  *(undefined4 *)((longlong)param_2 + 4) = local_28;
  *(undefined4 *)param_2 = local_2c;
  return local_30;
}

// ==== CCrossMsgLoadEnd::helper_140195020  @140195020  [medium:callgraph-r0]  (orig: FUN_140195020)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140195020(longlong *param_1,char param_2)

{
  undefined8 *puVar1;
  char cVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined8 uVar11;
  ulonglong uVar12;
  tm *ptVar13;
  undefined1 auStack_1178 [32];
  uint local_1158;
  int local_1150;
  int local_1148;
  int local_1140;
  int local_1138;
  __time64_t local_1128 [2];
  undefined1 local_1118 [1072];
  undefined1 local_ce8 [1072];
  undefined1 local_8b8 [1072];
  undefined1 local_488 [1104];
  ulonglong local_38;
  undefined8 local_30;
  
  local_30 = 0x140195033;
  local_1128[1] = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_1178;
  puVar8 = (undefined8 *)FUN_1400e1e60();
  puVar1 = (undefined8 *)*puVar8;
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  (*(code *)*puVar1)(puVar8,uVar4);
  plVar9 = (longlong *)FUN_1401181a0();
  lVar10 = *plVar9;
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar10 + 0x58))(plVar9,uVar4);
  if ((*(int *)((longlong)param_1 + 0xf9c) != 0) && ((int)param_1[500] != 0)) {
    local_1158 = local_1158 & 0xffffff00;
    cVar2 = FUN_140172b80(param_1,*(int *)((longlong)param_1 + 0xf9c),(int)param_1[500],1);
    if (cVar2 == '\0') {
      local_1158 = 0x7077;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  *(undefined4 *)((longlong)param_1 + 0x11a4) = 0;
  *(undefined4 *)(param_1 + 0x235) = 2;
  cVar2 = FUN_140383750(param_1);
  if (cVar2 != '\0') {
    FUN_140164ef0(param_1);
    iVar5 = (**(code **)(param_1[2] + 0x168))(param_1 + 2);
    if (iVar5 != 0x259) {
      iVar5 = (**(code **)(param_1[2] + 0x168))(param_1 + 2);
      if (iVar5 != 0x40f) goto LAB_140195150;
    }
    FUN_140164f80(param_1);
  }
LAB_140195150:
  lVar10 = FUN_140008520((int)param_1[0x246]);
  lVar10 = *(longlong *)(lVar10 + 0x140);
  if (lVar10 == 0) {
    local_1158 = 0x149;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  FUN_14024e510(lVar10,uVar4);
  lVar10 = FUN_140008520((int)param_1[0x246]);
  lVar10 = *(longlong *)(lVar10 + 400);
  if (lVar10 == 0) {
    local_1158 = 0x155;
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar10 = 0;
  }
  FUN_140237eb0(lVar10,param_1);
  plVar9 = (longlong *)FUN_1400e1e60();
  lVar10 = *plVar9;
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar10 + 8))(plVar9,uVar4);
  plVar9 = (longlong *)FUN_1400e1e60();
  lVar10 = *plVar9;
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar10 + 0x10))(plVar9,uVar4);
  FUN_140194390(param_1);
  FUN_14018fc20(param_1);
  FUN_140362560(local_488);
  uVar3 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
  uVar4 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
  uVar6 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  local_1140 = 0;
  local_1148 = 0;
  local_1150 = CONCAT22(local_1150._2_2_,1000);
  local_1158 = CONCAT22(local_1158._2_2_,uVar3);
  iVar5 = FUN_140362620(local_488,uVar7,uVar6,uVar4);
  if (iVar5 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_488);
  }
  if (param_2 == '\0') {
    FUN_1403f1310(local_ce8);
    uVar4 = (**(code **)(*param_1 + 0x38))(param_1);
    cVar2 = FUN_1403f13c0(local_ce8,3,uVar4);
    if (cVar2 != '\0') {
      plVar9 = (longlong *)FUN_140008520((int)param_1[0x246]);
      uVar4 = *(undefined4 *)((longlong)param_1 + 0x12fc);
      lVar10 = *plVar9;
      uVar6 = (**(code **)(*param_1 + 0x38))(param_1);
      local_1158 = 4;
      (**(code **)(lVar10 + 0x28))(plVar9,uVar6,uVar4,local_ce8);
    }
    (**(code **)(*param_1 + 0x38))(param_1);
    log_InlineLogOSMessage("login os step5: os user[id:%u, serverid:%u] login ok. from GS");
    FUN_1403f1360(local_ce8);
  }
  else if (param_2 == '\x04') {
    FUN_1403f1310(local_1118);
    cVar2 = FUN_1403f13c0(local_1118,4,*(undefined4 *)((longlong)param_1 + 0x12fc));
    if (cVar2 != '\0') {
      plVar9 = (longlong *)FUN_140008520((int)param_1[0x246]);
      uVar4 = *(undefined4 *)((longlong)param_1 + 0x132c);
      lVar10 = *plVar9;
      uVar6 = (**(code **)(*param_1 + 0x38))(param_1);
      local_1158 = 4;
      (**(code **)(lVar10 + 0x28))(plVar9,uVar6,uVar4,local_1118);
    }
    FUN_1400f7f70(local_ce8);
    uVar11 = FUN_140008520((int)param_1[0x246]);
    uVar4 = FUN_14008b420(uVar11);
    cVar2 = FUN_1400f8060(local_ce8,3,uVar4);
    if (cVar2 != '\0') {
      plVar9 = (longlong *)FUN_140008520((int)param_1[0x246]);
      uVar4 = *(undefined4 *)((longlong)param_1 + 0x12fc);
      lVar10 = *plVar9;
      uVar6 = (**(code **)(*param_1 + 0x38))(param_1);
      local_1158 = 4;
      (**(code **)(lVar10 + 0x28))(plVar9,uVar6,uVar4,local_ce8);
    }
    (**(code **)(*param_1 + 0x38))(param_1);
    log_InlineLogOSMessage("login os step5: os user[id:%u, serverid:%u] login ok. from OS");
    FUN_1400f7fc0(local_ce8);
    FUN_1403f1360(local_1118);
  }
  else if (param_2 == '\x02') {
    FUN_1403f1310(local_ce8);
    uVar4 = (**(code **)(*param_1 + 0x38))(param_1);
    cVar2 = FUN_1403f13c0(local_ce8,2,uVar4);
    if (cVar2 != '\0') {
      (**(code **)(*param_1 + 0x130))(param_1,local_ce8);
    }
    FUN_1400f7f70(local_1118);
    uVar11 = FUN_140008520((int)param_1[0x246]);
    uVar4 = FUN_14008b420(uVar11);
    cVar2 = FUN_1400f8060(local_1118,1,uVar4);
    if (cVar2 != '\0') {
      plVar9 = (longlong *)FUN_140008520((int)param_1[0x246]);
      uVar4 = *(undefined4 *)((longlong)param_1 + 0x12fc);
      lVar10 = *plVar9;
      uVar6 = (**(code **)(*param_1 + 0x38))(param_1);
      local_1158 = 4;
      (**(code **)(lVar10 + 0x28))(plVar9,uVar6,uVar4,local_1118);
    }
    (**(code **)(*param_1 + 0x38))(param_1);
    log_InlineLogOSMessage("login os step5: os user[id:%u, serverid:%u] login ok. from CS");
    FUN_1400f7fc0(local_1118);
    FUN_1403f1360(local_ce8);
  }
  FUN_1403f0d80(local_8b8);
  uVar4 = (**(code **)(*param_1 + 0x38))(param_1);
  cVar2 = FUN_1403f0e40(local_8b8,3,uVar4);
  if (cVar2 != '\0') {
    (**(code **)(*param_1 + 0x138))(param_1,local_8b8,4);
  }
  plVar9 = *(longlong **)(*(longlong *)(param_1[0x220] + 0x58) + 8);
  plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,4);
  uVar12 = (**(code **)(*plVar9 + 0x58))(plVar9);
  if ((uVar12 >> 0x1f & 1) == 0) {
    FUN_1403f04c0(local_1118);
    cVar2 = FUN_1403f0570(local_1118,2);
    if (cVar2 != '\0') {
      (**(code **)(*param_1 + 0x138))(param_1,local_1118,4);
    }
    FUN_1403f0510(local_1118);
  }
  local_1128[0] = _time64((__time64_t *)0x0);
  ptVar13 = _localtime64(local_1128);
  if (ptVar13 != (tm *)0x0) {
    FUN_1403a6980(local_1118);
    local_1138 = ptVar13->tm_sec;
    local_1140 = ptVar13->tm_min;
    local_1148 = ptVar13->tm_hour;
    local_1150 = ptVar13->tm_mday;
    local_1158 = ptVar13->tm_yday;
    iVar5 = FUN_1403a6a30(local_1118,0,ptVar13->tm_year,ptVar13->tm_mon);
    if (iVar5 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_1118);
    }
    FUN_1403a69d0(local_1118);
  }
  FUN_1403f0dd0(local_8b8);
  FUN_1403625e0(local_488);
  return;
}

// ==== CCrossMsgLoadEnd::helper_1401c9640  @1401c9640  [medium:callgraph-r1]  (orig: FUN_1401c9640)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1401c9640(longlong *param_1,undefined4 param_2,undefined4 *param_3)

{
  byte bVar1;
  uint uVar2;
  char cVar3;
  undefined2 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  IStringManager *pIVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  ulonglong uVar13;
  undefined1 auStack_11b8 [32];
  undefined4 local_1198;
  undefined2 local_1190;
  undefined4 local_1188;
  undefined4 local_1180;
  uint local_1178;
  undefined4 *local_1170;
  undefined8 local_1168;
  undefined1 local_1158 [1072];
  undefined1 local_d28 [1104];
  undefined1 local_8d8 [1104];
  undefined1 local_488 [1104];
  ulonglong local_38;
  undefined8 local_30;
  
  local_30 = 0x1401c9654;
  local_1168 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_11b8;
  *(undefined4 *)(param_1 + 0x260) = 1;
  local_1170 = param_3;
  FUN_14019ca20(param_1,0);
  FUN_14037dfb0(local_d28);
  uVar8 = FUN_140008520((int)param_1[0x246]);
  uVar8 = FUN_14008a730(uVar8,0);
  iVar5 = FUN_14037e0a0(local_d28,0x3d,uVar8);
  if (iVar5 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_d28);
  }
  bVar1 = *(byte *)(param_1 + 0x1f2);
  local_1178 = 0xffffffff;
  uVar8 = FUN_140008520((int)param_1[0x246]);
  cVar3 = FUN_14008b330(uVar8);
  if (cVar3 == '\0') {
    plVar11 = (longlong *)FUN_140087ed0();
    lVar10 = *plVar11;
    uVar6 = (**(code **)(*param_1 + 8))(param_1);
    cVar3 = (**(code **)(lVar10 + 0x6b8))(plVar11,uVar6);
    local_1178 = 10 - (cVar3 != '\0');
  }
  else {
    local_1178 = 0xb;
  }
  uVar2 = local_1178;
  if (bVar1 != local_1178) {
    *(char *)(param_1 + 0x1f2) = (char)local_1178;
    FUN_140362560(local_8d8);
    uVar6 = (**(code **)(*param_1 + 8))(param_1);
    cVar3 = FUN_140362910(local_8d8,0x60,uVar6,(longlong)(int)uVar2);
    if (cVar3 != '\0') {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_8d8);
    }
    uVar8 = FUN_140008520((int)param_1[0x246]);
    cVar3 = FUN_14008abf0(uVar8);
    if (cVar3 == '\0') {
      if (uVar2 == 10) {
        pIVar9 = theInstance();
        lVar10 = param_1[2];
        uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_OS_SAFE_PK_MODE");
        (**(code **)(lVar10 + 0x358))(param_1 + 2,uVar8);
      }
      else if (uVar2 == 9) {
        pIVar9 = theInstance();
        lVar10 = param_1[2];
        uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_PLUNDER_PK_MODE");
        (**(code **)(lVar10 + 0x358))(param_1 + 2,uVar8);
      }
      else if (uVar2 == 7) {
        pIVar9 = theInstance();
        lVar10 = param_1[2];
        uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_OS_PK_MODE");
        (**(code **)(lVar10 + 0x358))(param_1 + 2,uVar8);
      }
      else if (uVar2 == 0xb) {
        iVar5 = FUN_140373290(param_1 + 0x1cf);
        if (iVar5 == 0) {
          pIVar9 = theInstance();
          lVar10 = param_1[2];
          uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_LEAGUE_PK_MODE_NO_LEAGUE_USER");
          (**(code **)(lVar10 + 0x358))(param_1 + 2,uVar8);
        }
        else {
          pIVar9 = theInstance();
          lVar10 = param_1[2];
          uVar8 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_LEAGUE_PK_MODE");
          (**(code **)(lVar10 + 0x358))(param_1 + 2,uVar8);
        }
      }
      else {
        log_InlineLogERROR("CUser::OSUserEnterServer PK mode error[%d]");
      }
    }
    FUN_1403625e0(local_8d8);
  }
  lVar10 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar10 + 0x1a8) == 0) {
    local_1198 = 0x159;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar8 = 0;
  }
  else {
    uVar8 = *(undefined8 *)(lVar10 + 0x1a8);
  }
  FUN_1402e8bd0(uVar8,param_1);
  uVar8 = FUN_140008520((int)param_1[0x246]);
  cVar3 = FUN_14008b330(uVar8);
  if (cVar3 != '\0') {
    plVar11 = (longlong *)FUN_140087ed0();
    lVar10 = *plVar11;
    uVar6 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar10 + 8))(plVar11,uVar6);
    iVar5 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
    if (iVar5 != 0) {
      plVar11 = (longlong *)FUN_140087ed0();
      lVar10 = FUN_140008520((int)param_1[0x246]);
      if (*(longlong *)(lVar10 + 0x208) == 0) {
        local_1198 = 0x166;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar8 = 0;
      }
      else {
        uVar8 = *(undefined8 *)(lVar10 + 0x208);
      }
      lVar10 = *plVar11;
      uVar6 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
      uVar8 = FUN_140262a60(uVar8,uVar6);
      uVar6 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
      uVar7 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar10 + 0x20))(plVar11,uVar7,uVar6,uVar8);
      param_3 = local_1170;
    }
    plVar11 = (longlong *)CurrentInstanceGet();
    if (plVar11 != (longlong *)0x0) {
      lVar10 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
      if (lVar10 != 0) {
        lVar10 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
        plVar12 = *(longlong **)(*(longlong *)(lVar10 + 0x58) + 8);
        plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,4);
        uVar13 = (**(code **)(*plVar12 + 0x58))(plVar12);
        if ((uVar13 >> 0x1f & 1) != 0) {
          plVar11 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,0x25);
          if (plVar11 != (longlong *)0x0) {
            lVar10 = *plVar11;
            uVar6 = (**(code **)(*param_1 + 8))(param_1);
            (**(code **)(lVar10 + 0xe0))(plVar11,uVar6);
          }
        }
      }
    }
  }
  FUN_1403eed30(local_1158);
  iVar5 = FUN_1403eede0(local_1158,1,0);
  if (iVar5 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_1158);
  }
  uVar8 = FUN_140008520((int)param_1[0x246]);
  plVar11 = (longlong *)FUN_1400876b0(uVar8);
  lVar10 = (**(code **)(*plVar11 + 0x10))(plVar11,param_2,1);
  if (lVar10 == 0) {
    FUN_1403eed80(local_1158);
    FUN_14037e030(local_d28);
    uVar8 = 0;
  }
  else {
    param_1[0x220] = lVar10;
    *(undefined4 *)(param_1 + 0x21b) = *param_3;
    *(undefined4 *)((longlong)param_1 + 0x10dc) = param_3[1];
    FUN_140362560(local_488);
    uVar6 = (**(code **)(**(longlong **)(lVar10 + 0x58) + 0x10))(*(longlong **)(lVar10 + 0x58),3);
    uVar4 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
    uVar7 = (**(code **)(*param_1 + 8))(param_1);
    local_1180 = 0;
    local_1190 = 0x56;
    local_1198 = CONCAT22(local_1198._2_2_,uVar4);
    local_1188 = uVar6;
    iVar5 = FUN_140362620(local_488,uVar7,(int)param_1[0x21b],
                          *(undefined4 *)((longlong)param_1 + 0x10dc));
    if (iVar5 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_488);
    }
    uVar6 = (**(code **)(**(longlong **)(lVar10 + 0x58) + 0x10))(*(longlong **)(lVar10 + 0x58),3);
    FUN_1401a41c0(param_1,uVar6);
    FUN_1401c4e10(param_1,5);
    FUN_140336d00(param_1);
    FUN_1403625e0(local_488);
    FUN_1403eed80(local_1158);
    FUN_14037e030(local_d28);
    uVar8 = 1;
  }
  return uVar8;
}

// ==== CCrossMsgLoadEnd::helper_140262a60  @140262a60  [medium:callgraph-r2]  (orig: FUN_140262a60)
longlong FUN_140262a60(void)

{
  longlong lVar1;
  
  lVar1 = FUN_1402629e0();
  if (lVar1 == 0) {
    return 0;
  }
  return lVar1 + 0x38;
}

// ==== CCrossMsgLoadEnd::helper_1402ae5f0  @1402ae5f0  [medium:callgraph-r1]  (orig: FUN_1402ae5f0)
void FUN_1402ae5f0(longlong param_1,uint param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong local_18;
  longlong local_10;
  
  plVar1 = (longlong *)(param_1 + 0x58);
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0x88))[1];
  cVar2 = *(char *)((longlong)puVar6 + 0x21);
  puVar4 = *(undefined8 **)(param_1 + 0x88);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar6 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar6[2];
      puVar6 = puVar4;
    }
    else {
      puVar5 = (undefined8 *)*puVar6;
    }
    puVar4 = puVar6;
    puVar6 = puVar5;
    cVar2 = *(char *)((longlong)puVar5 + 0x21);
  }
  puVar6 = *(undefined8 **)(param_1 + 0x88);
  local_30 = puVar4;
  local_38 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar6) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x88);
    local_28 = *plVar1;
  }
  else {
    plVar7 = &local_38;
  }
  local_18 = *plVar7;
  lVar3 = *(longlong *)(param_1 + 0x88);
  local_10 = plVar7[1];
  if ((local_18 == 0) || (local_18 != *plVar1)) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar3) {
    local_18 = *plVar7;
    local_10 = plVar7[1];
    FUN_14004ee60(plVar1,&local_28,&local_18);
  }
  return;
}

// ==== CCrossMsgLoadEnd::helper_1402b1b80  @1402b1b80  [medium:callgraph-r0]  (orig: FUN_1402b1b80)
ulonglong FUN_1402b1b80(longlong param_1,undefined8 param_2,longlong *param_3)

{
  int iVar1;
  ulonglong uVar2;
  undefined8 *puVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  undefined8 uVar7;
  longlong *plVar8;
  ulonglong uVar9;
  undefined8 *puVar10;
  ulonglong *puVar11;
  undefined8 *puVar12;
  undefined4 local_res18 [2];
  undefined4 local_res20 [2];
  undefined4 local_58;
  undefined4 local_54;
  ulonglong local_50;
  ulonglong local_48;
  undefined8 local_40;
  ulonglong local_38;
  undefined8 *local_30;
  ulonglong local_28;
  undefined8 local_20;
  
  local_40 = 0xfffffffffffffffe;
  if (param_3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pUser",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.cpp"
                       ,0x4df);
    uVar9 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    uVar5 = (**(code **)(*param_3 + 8))(param_3);
    puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x88))[1];
    cVar4 = *(char *)((longlong)puVar12 + 0x21);
    puVar3 = *(undefined8 **)(param_1 + 0x88);
    while (cVar4 == '\0') {
      if (*(uint *)(puVar12 + 3) < uVar5) {
        puVar10 = (undefined8 *)puVar12[2];
        puVar12 = puVar3;
      }
      else {
        puVar10 = (undefined8 *)*puVar12;
      }
      puVar3 = puVar12;
      puVar12 = puVar10;
      cVar4 = *(char *)((longlong)puVar10 + 0x21);
    }
    local_30 = puVar3;
    local_38 = *(ulonglong *)(param_1 + 0x58);
    puVar12 = *(undefined8 **)(param_1 + 0x88);
    if (*(ulonglong *)(param_1 + 0x58) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar12) || (uVar5 < *(uint *)(puVar3 + 3))) {
      local_20 = *(undefined8 *)(param_1 + 0x88);
      local_28 = *(ulonglong *)(param_1 + 0x58);
      puVar11 = &local_28;
    }
    else {
      puVar11 = &local_38;
    }
    uVar9 = *puVar11;
    local_48 = puVar11[1];
    uVar2 = *(ulonglong *)(param_1 + 0x88);
    local_50 = uVar9;
    if ((uVar9 == 0) || (uVar9 != *(ulonglong *)(param_1 + 0x58))) {
      _invalid_parameter_noinfo();
      uVar9 = extraout_RAX_00;
    }
    if (local_48 == uVar2) {
      uVar9 = uVar9 & 0xffffffffffffff00;
    }
    else {
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
      plVar8 = (longlong *)FUN_1400875f0(uVar7);
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x30))(plVar8);
      (**(code **)(*plVar8 + 0x28))(plVar8,param_3 + 2);
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 1;
      iVar1 = *(int *)(param_1 + 0xc);
      if (*(int *)(param_1 + 0x10) < iVar1) {
        *(int *)(param_1 + 0x10) = iVar1;
        LOCK();
        UNLOCK();
        DAT_140975708 = iVar1;
      }
      DAT_14097570c = *(undefined4 *)(param_1 + 0xc);
      LOCK();
      UNLOCK();
      LOCK();
      DAT_140975714 = DAT_140975714 + 1;
      UNLOCK();
      LOCK();
      DAT_14097571c = DAT_14097571c + 1;
      UNLOCK();
      uVar5 = (int)*(undefined8 *)(param_1 + 0x240) + *(int *)(param_1 + 0xc);
      if (*(uint *)(param_1 + 8) <= uVar5) {
        *(uint *)(param_1 + 8) = uVar5;
      }
      cVar4 = (**(code **)(param_3[2] + 0x230))(param_3 + 2);
      if (cVar4 != '\0') {
        local_res18[0] = (**(code **)(*param_3 + 8))(param_3);
        FUN_140037fe0(param_1 + 0x250,local_res18);
      }
      local_res20[0] = (**(code **)(*param_3 + 8))(param_3);
      tq::CMySingleLock::CMySingleLock((CMySingleLock *)&local_50,(ILockObj *)&DAT_140975f50);
      FUN_1402af5f0(param_1 + 0x288,local_res20);
      tq::CMySingleLock::~CMySingleLock((CMySingleLock *)&local_50);
      uVar6 = (**(code **)(*param_3 + 8))(param_3);
      FUN_1402ae5f0(param_1,uVar6);
      local_58 = 0;
      local_54 = 0;
      uVar6 = FUN_140179c90(param_3,&local_58);
      uVar9 = FUN_1401c9640(param_3,uVar6,&local_58);
    }
  }
  return uVar9;
}

// ==== CCrossMsgLoadEnd::helper_1402e8bd0  @1402e8bd0  [medium:callgraph-r2]  (orig: FUN_1402e8bd0)
void FUN_1402e8bd0(longlong param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  uint uVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  if (param_2 != (longlong *)0x0) {
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar1 = *(char *)((longlong)puVar7 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x38);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar7 + 3) < uVar5) {
        puVar8 = (undefined8 *)puVar7[2];
        puVar7 = puVar3;
      }
      else {
        puVar8 = (undefined8 *)*puVar7;
      }
      puVar3 = puVar7;
      puVar7 = puVar8;
      cVar1 = *(char *)((longlong)puVar8 + 0x29);
    }
    puVar7 = *(undefined8 **)(param_1 + 0x38);
    local_30 = puVar3;
    local_38 = *(longlong *)(param_1 + 8);
    if (*(longlong *)(param_1 + 8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar7) || (uVar5 < *(uint *)(puVar3 + 3))) {
      plVar6 = &local_28;
      local_20 = *(undefined8 *)(param_1 + 0x38);
      local_28 = *(longlong *)(param_1 + 8);
    }
    else {
      plVar6 = &local_38;
    }
    plVar2 = (longlong *)*plVar6;
    lVar9 = *(longlong *)(param_1 + 0x38);
    local_18 = plVar2;
    local_10 = plVar6[1];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    lVar4 = local_10;
    if (local_10 != lVar9) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)(lVar4 + 0x20);
      if (lVar9 != 0) {
        FUN_140478d30(lVar9,1,param_2,param_2);
      }
    }
  }
  return;
}

// ==== CCrossMsgLoadEnd::ctor_or_dtor  @140361e70  [high:vtable-assign]  (orig: FUN_140361e70)
undefined8 * FUN_140361e70(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLoadEnd::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLoadEnd::ctor_or_dtor  @140361ec0  [high:vtable-assign]  (orig: FUN_140361ec0)
void FUN_140361ec0(undefined8 *param_1)

{
  *param_1 = CCrossMsgLoadEnd::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLoadEnd::vfunc_1  @140361ef0  [high:rtti-vtable]  (orig: FUN_140361ef0)
undefined8 FUN_140361ef0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLoadEnd::ctor_or_dtor  @140361f80  [high:vtable-assign]  (orig: FUN_140361f80)
undefined8 * FUN_140361f80(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLoadEnd::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgLoadEnd::vfunc_3  @140361fd0  [high:rtti-vtable]  (orig: FUN_140361fd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140361fd0(longlong param_1)

{
  short sVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  undefined4 local_430;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  sVar1 = *(short *)(*(longlong *)(param_1 + 0x428) + 4);
  if (sVar1 == 0) {
    if (*(longlong *)(param_1 + 0x428) == 0) {
      local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x37);
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar7 = (longlong *)FUN_140087650(uVar5);
    lVar6 = (**(code **)(*plVar7 + 0x98))(plVar7);
    if (lVar6 == 0) {
      return;
    }
    memset((void *)((longlong)&local_438 + 1),0,0x417);
    local_438 = 1;
    local_434 = 1;
    local_430 = *(undefined4 *)(lVar6 + 0x122c);
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar7 = (longlong *)FUN_14001b560(uVar5);
    local_448 = &local_438;
    (**(code **)(*plVar7 + 0x50))(plVar7,1,0x7541,0x418);
    return;
  }
  if (sVar1 == 1) {
    log_InlineLogOSMessage("login os step4: load os user[id:%u, serverid:%u] all info ok. from GS");
    if (*(longlong *)(param_1 + 0x428) != 0) {
      uVar2 = *(undefined4 *)(param_1 + 0x420);
      uVar3 = *(undefined4 *)(param_1 + 0x41c);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar5 = FUN_140087650(uVar5);
      plVar7 = (longlong *)FUN_1402af110(uVar5,uVar3,uVar2);
      if (plVar7 == (longlong *)0x0) {
        log_InlineLogOSWARNING
                  ("CCrossMsgLoadEnd::Process from gs not found os user, idServer:%u, idOSUser:%u.")
        ;
        return;
      }
      uVar2 = *(undefined4 *)(param_1 + 0x41c);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar5 = FUN_140087650(uVar5);
      cVar4 = FUN_1402b1b80(uVar5,uVar2,plVar7);
      if (cVar4 == '\0') {
        return;
      }
      cVar4 = FUN_140361f20(param_1,*(undefined4 *)(param_1 + 0x420),0);
      if (cVar4 != '\0') {
        (**(code **)(*plVar7 + 0x138))(plVar7,param_1,4);
      }
      FUN_140195020(plVar7,0);
      return;
    }
    local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x5a);
  }
  else if (sVar1 == 3) {
    log_InlineLogOSMessage("login os step4: load os user[id:%u, serverid:%u] all info ok. from CS");
    if (*(longlong *)(param_1 + 0x428) != 0) {
      uVar2 = *(undefined4 *)(param_1 + 0x420);
      uVar3 = *(undefined4 *)(param_1 + 0x41c);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar5 = FUN_140087650(uVar5);
      lVar6 = FUN_1402af110(uVar5,uVar3,uVar2);
      if (lVar6 == 0) {
        log_InlineLogOSWARNING
                  ("CCrossMsgLoadEnd::Process from cs not found os user, idServer:%u, idOSUser:%u.")
        ;
        return;
      }
      uVar2 = *(undefined4 *)(param_1 + 0x41c);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar5 = FUN_140087650(uVar5);
      cVar4 = FUN_1402b1b80(uVar5,uVar2,lVar6);
      if (cVar4 == '\0') {
        return;
      }
      FUN_140195020(lVar6,2);
      return;
    }
    local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x48);
  }
  else {
    if (sVar1 != 4) {
      return;
    }
    log_InlineLogOSMessage("login os step4: load os user[id:%u, serverid:%u] all info ok. from OS");
    if (*(longlong *)(param_1 + 0x428) != 0) {
      uVar2 = *(undefined4 *)(param_1 + 0x420);
      uVar3 = *(undefined4 *)(param_1 + 0x41c);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar5 = FUN_140087650(uVar5);
      lVar6 = FUN_1402af110(uVar5,uVar3,uVar2);
      if (lVar6 == 0) {
        log_InlineLogOSWARNING
                  (
                  "CCrossMsgLoadEnd::Process from gs not found os user, idServer:%u, idOSUser:%u, action_type:%d.."
                  );
        return;
      }
      uVar2 = *(undefined4 *)(param_1 + 0x41c);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar5 = FUN_140087650(uVar5);
      cVar4 = FUN_1402b1b80(uVar5,uVar2,lVar6);
      if (cVar4 == '\0') {
        return;
      }
      FUN_140195020(lVar6,4);
      return;
    }
    local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x70);
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CCrossMsgLoadEnd::helper_1403f0570  @1403f0570  [medium:callgraph-r1]  (orig: FUN_1403f0570)
undefined8 FUN_1403f0570(longlong param_1,undefined2 param_2)

{
  undefined2 *puVar1;
  
  FUN_1402b5600();
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 8) = 0x9c56;
  *(undefined4 *)(param_1 + 0xc) = 8;
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CCrossMsgLoadEnd::helper_1403f0e40  @1403f0e40  [medium:callgraph-r1]  (orig: FUN_1403f0e40)
undefined8 FUN_1403f0e40(longlong param_1,undefined2 param_2,undefined4 param_3)

{
  undefined2 *puVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x1c;
  *(undefined4 *)(param_1 + 8) = 0x9c5e;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_3;
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CCrossMsgLoadEnd::helper_1403f13c0  @1403f13c0  [medium:callgraph-r1]  (orig: FUN_1403f13c0)
undefined8 FUN_1403f13c0(longlong param_1,undefined2 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c4e;
  *(undefined4 *)(param_1 + 0xc) = 8;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 4) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

