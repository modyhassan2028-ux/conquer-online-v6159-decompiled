// ==== CopyingOutputStreamAdaptor@io@protobuf@google::helper_14055cec0  @14055cec0  [medium:callgraph-r0]  (orig: FUN_14055cec0)
void FUN_14055cec0(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  *param_1 = google::protobuf::io::CopyingOutputStreamAdaptor::vftable;
  FUN_14055d2d0(param_1);
  if ((*(char *)(param_1 + 2) != '\0') &&
     (puVar1 = (undefined8 *)param_1[1], puVar1 != (undefined8 *)0x0)) {
    (**(code **)*puVar1)(puVar1,1);
  }
  FUN_14055d6d0(param_1 + 4);
  FUN_14055d8d0(param_1);
  return;
}

// ==== CopyingOutputStreamAdaptor@io@protobuf@google::vfunc_1  @14055cf80  [high:rtti-vtable]  (orig: FUN_14055cf80)
undefined8 FUN_14055cf80(longlong param_1,longlong *param_2,int *param_3)

{
  char cVar1;
  longlong lVar2;
  
  if ((*(int *)(param_1 + 0x2c) == *(int *)(param_1 + 0x28)) &&
     (cVar1 = FUN_14055d2d0(param_1), cVar1 == '\0')) {
    return 0;
  }
  FUN_14055d390(param_1);
  lVar2 = FUN_14055d750(param_1 + 0x20);
  *param_2 = lVar2 + *(int *)(param_1 + 0x2c);
  *param_3 = *(int *)(param_1 + 0x28) - *(int *)(param_1 + 0x2c);
  *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_1 + 0x28);
  return CONCAT71((uint7)(uint3)((uint)*(undefined4 *)(param_1 + 0x28) >> 8),1);
}

// ==== CopyingOutputStreamAdaptor@io@protobuf@google::vfunc_2  @14055d020  [high:rtti-vtable]  (orig: FUN_14055d020)
void FUN_14055d020(longlong param_1,int param_2)

{
  undefined8 uVar1;
  longlong lVar2;
  undefined1 *puVar3;
  undefined1 local_128 [8];
  undefined1 local_120 [64];
  undefined1 local_e0 [8];
  undefined1 local_d8 [64];
  undefined1 local_98 [8];
  undefined1 local_90 [64];
  uint local_50;
  undefined8 local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined8 local_30;
  undefined8 local_28;
  undefined8 local_20;
  undefined8 local_18;
  
  local_48 = 0xfffffffffffffffe;
  local_50 = 0;
  if (param_2 < 0) {
    puVar3 = local_128;
    for (lVar2 = 1; lVar2 != 0; lVar2 = lVar2 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    local_40 = FUN_140556890(local_120,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\io\\zero_copy_stream_impl_lite.cc"
                             ,0x165);
    local_50 = local_50 | 1;
    local_38 = local_40;
    uVar1 = FUN_1405564f0(local_40,"CHECK failed: (count) >= (0): ");
    FUN_140556a40(local_128,uVar1);
  }
  if ((local_50 & 1) != 0) {
    local_50 = local_50 & 0xfffffffe;
    FUN_140556900(local_120);
  }
  if (*(int *)(param_1 + 0x2c) != *(int *)(param_1 + 0x28)) {
    puVar3 = local_e0;
    for (lVar2 = 1; lVar2 != 0; lVar2 = lVar2 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    local_30 = FUN_140556890(local_d8,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\io\\zero_copy_stream_impl_lite.cc"
                             ,0x166);
    local_50 = local_50 | 2;
    local_28 = local_30;
    uVar1 = FUN_1405564f0(local_30,"CHECK failed: (buffer_used_) == (buffer_size_): ");
    uVar1 = FUN_1405564f0(uVar1," BackUp() can only be called after Next().");
    FUN_140556a40(local_e0,uVar1);
  }
  if ((local_50 & 2) != 0) {
    local_50 = local_50 & 0xfffffffd;
    FUN_140556900(local_d8);
  }
  if (*(int *)(param_1 + 0x2c) < param_2) {
    puVar3 = local_98;
    for (lVar2 = 1; lVar2 != 0; lVar2 = lVar2 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    local_20 = FUN_140556890(local_90,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\io\\zero_copy_stream_impl_lite.cc"
                             ,0x168);
    local_50 = local_50 | 4;
    local_18 = local_20;
    uVar1 = FUN_1405564f0(local_20,"CHECK failed: (count) <= (buffer_used_): ");
    uVar1 = FUN_1405564f0(uVar1,
                          " Can\'t back up over more bytes than were returned by the last call to Next()."
                         );
    FUN_140556a40(local_98,uVar1);
  }
  if ((local_50 & 4) != 0) {
    local_50 = local_50 & 0xfffffffb;
    FUN_140556900(local_90);
  }
  *(int *)(param_1 + 0x2c) = *(int *)(param_1 + 0x2c) - param_2;
  return;
}

// ==== CopyingOutputStreamAdaptor@io@protobuf@google::vfunc_3  @14055d2b0  [high:rtti-vtable]  (orig: FUN_14055d2b0)
longlong FUN_14055d2b0(longlong param_1)

{
  return (longlong)*(int *)(param_1 + 0x2c) + *(longlong *)(param_1 + 0x18);
}

// ==== CopyingOutputStreamAdaptor@io@protobuf@google::helper_14055d2d0  @14055d2d0  [medium:callgraph-r0]  (orig: FUN_14055d2d0)
undefined8 FUN_14055d2d0(longlong param_1)

{
  char cVar1;
  undefined8 uVar2;
  
  if (*(char *)(param_1 + 0x11) == '\0') {
    if (*(int *)(param_1 + 0x2c) == 0) {
      uVar2 = 1;
    }
    else {
      uVar2 = FUN_14055d750(param_1 + 0x20);
      cVar1 = (**(code **)(**(longlong **)(param_1 + 8) + 8))
                        (*(undefined8 *)(param_1 + 8),uVar2,*(undefined4 *)(param_1 + 0x2c));
      if (cVar1 == '\0') {
        *(undefined1 *)(param_1 + 0x11) = 1;
        FUN_14055d3f0(param_1);
        uVar2 = 0;
      }
      else {
        *(longlong *)(param_1 + 0x18) =
             (longlong)*(int *)(param_1 + 0x2c) + *(longlong *)(param_1 + 0x18);
        *(undefined4 *)(param_1 + 0x2c) = 0;
        uVar2 = 1;
      }
    }
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}

// ==== CopyingOutputStreamAdaptor@io@protobuf@google::helper_14055d390  @14055d390  [medium:callgraph-r0]  (orig: FUN_14055d390)
void FUN_14055d390(longlong param_1)

{
  char cVar1;
  void *pvVar2;
  
  cVar1 = FUN_14055d760(param_1 + 0x20,0);
  if (cVar1 != '\0') {
    pvVar2 = operator_new__((longlong)*(int *)(param_1 + 0x28));
    FUN_14055d700(param_1 + 0x20,pvVar2);
  }
  return;
}

// ==== CopyingOutputStreamAdaptor@io@protobuf@google::helper_14055d3f0  @14055d3f0  [medium:callgraph-r1]  (orig: FUN_14055d3f0)
void FUN_14055d3f0(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x2c) = 0;
  FUN_14055d700(param_1 + 0x20,0);
  return;
}

// ==== CopyingOutputStreamAdaptor@io@protobuf@google::vfunc_0  @14055d670  [high:rtti-vtable]  (orig: FUN_14055d670)
void * FUN_14055d670(void *param_1,uint param_2)

{
  FUN_14055cec0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CopyingOutputStreamAdaptor@io@protobuf@google::helper_14055d760  @14055d760  [medium:callgraph-r1]  (orig: FUN_14055d760)
bool FUN_14055d760(longlong *param_1,longlong param_2)

{
  return *param_1 == param_2;
}

