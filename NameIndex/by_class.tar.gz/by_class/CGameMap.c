// ==== CGameMap::helper_1402c5b40  @1402c5b40  [medium:callgraph-r0]  (orig: FUN_1402c5b40)
void FUN_1402c5b40(void *param_1)

{
  if ((DAT_140975f98 & 1) == 0) {
    DAT_140975f98 = DAT_140975f98 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975f90,"CGameMap");
    atexit((_func_5014 *)&LAB_1406d69f0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001402c5b95. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975f90,param_1);
  return;
}

// ==== CGameMap::vfunc_1  @1402c5c00  [high:rtti-vtable]  (orig: FUN_1402c5c00)
void FUN_1402c5c00(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,&DAT_140951730);
                    /* WARNING: Could not recover jumptable at 0x0001402c5c23. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1);
  return;
}

// ==== CGameMap::vfunc_4  @1402c8bc0  [high:rtti-vtable]  (orig: FUN_1402c8bc0)
void FUN_1402c8bc0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  longlong *plVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  longlong *local_res10;
  undefined8 local_res18 [2];
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  local_res18[0] = 0;
  cVar2 = (**(code **)(*param_2 + 0x298))(param_2,0x1001,local_res18);
  if (cVar2 == '\0') {
    iVar3 = (**(code **)(*param_2 + 0x40))(param_2);
    if (iVar3 / 0x12 + -1 < 1) {
      iVar3 = 0;
    }
    else {
      iVar3 = (**(code **)(*param_2 + 0x40))(param_2);
      iVar3 = iVar3 / 0x12 + -1;
    }
    iVar4 = (**(code **)(*param_2 + 0x40))(param_2);
    if (iVar3 <= iVar4 / 0x12 + 1) {
      do {
        iVar4 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))();
        if ((iVar4 + -1) / 0x12 + 1 <= iVar3) {
          return;
        }
        iVar4 = (**(code **)(*param_2 + 0x48))(param_2);
        if (iVar4 / 0x12 + -1 < 1) {
          iVar4 = 0;
        }
        else {
          iVar4 = (**(code **)(*param_2 + 0x48))(param_2);
          iVar4 = iVar4 / 0x12 + -1;
        }
        iVar5 = (**(code **)(*param_2 + 0x48))(param_2);
        if (iVar4 <= iVar5 / 0x12 + 1) {
          do {
            iVar5 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))();
            if ((iVar5 + -1) / 0x12 + 1 <= iVar4) break;
            lVar7 = FUN_14017eea0(param_1,iVar3,iVar4);
            uVar10 = 0;
            plVar1 = *(longlong **)(lVar7 + 8);
            lVar7 = (**(code **)(*plVar1 + 0x10))(plVar1);
            if (lVar7 != 0) {
              do {
                plVar8 = (longlong *)(**(code **)(*plVar1 + 0x18))(plVar1,uVar10);
                if (((plVar8 != (longlong *)0x0) &&
                    (iVar5 = (**(code **)(*plVar8 + 0x18))(plVar8), iVar5 == 0x1001)) &&
                   (iVar5 = (**(code **)(*param_2 + 0x150))(param_2,plVar8), iVar5 < 0x13)) {
                  (**(code **)(*plVar8 + 0x30))(plVar8,param_2);
                }
                uVar10 = uVar10 + 1;
                uVar9 = (**(code **)(*plVar1 + 0x10))(plVar1);
              } while (uVar10 < uVar9);
            }
            iVar4 = iVar4 + 1;
            iVar5 = (**(code **)(*param_2 + 0x48))(param_2);
          } while (iVar4 <= iVar5 / 0x12 + 1);
        }
        iVar3 = iVar3 + 1;
        iVar4 = (**(code **)(*param_2 + 0x40))(param_2);
      } while (iVar3 <= iVar4 / 0x12 + 1);
    }
  }
  else {
    iVar3 = (**(code **)(*param_2 + 0x40))(param_2);
    if (iVar3 / 0x12 + -1 < 1) {
      iVar3 = 0;
    }
    else {
      iVar3 = (**(code **)(*param_2 + 0x40))(param_2);
      iVar3 = iVar3 / 0x12 + -1;
    }
    iVar4 = (**(code **)(*param_2 + 0x40))(param_2);
    if (iVar3 <= iVar4 / 0x12 + 1) {
      do {
        iVar4 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))();
        if ((iVar4 + -1) / 0x12 + 1 <= iVar3) {
          return;
        }
        iVar4 = (**(code **)(*param_2 + 0x48))(param_2);
        if (iVar4 / 0x12 + -1 < 1) {
          iVar4 = 0;
        }
        else {
          iVar4 = (**(code **)(*param_2 + 0x48))(param_2);
          iVar4 = iVar4 / 0x12 + -1;
        }
        iVar5 = (**(code **)(*param_2 + 0x48))(param_2);
        if (iVar4 <= iVar5 / 0x12 + 1) {
          do {
            iVar5 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))();
            if ((iVar5 + -1) / 0x12 + 1 <= iVar4) break;
            lVar7 = FUN_14017eea0(param_1,iVar3,iVar4);
            uVar10 = 0;
            plVar1 = *(longlong **)(lVar7 + 8);
            lVar7 = (**(code **)(*plVar1 + 0x10))(plVar1);
            if (lVar7 != 0) {
              do {
                plVar8 = (longlong *)(**(code **)(*plVar1 + 0x18))(plVar1,uVar10);
                if (plVar8 != (longlong *)0x0) {
                  iVar5 = (**(code **)(*param_2 + 0x10))(param_2);
                  iVar6 = (**(code **)(*plVar8 + 0x10))(plVar8);
                  if ((iVar6 != iVar5) &&
                     (iVar5 = (**(code **)(*param_2 + 0x150))(param_2,plVar8), iVar5 < 0x13)) {
                    local_res10 = (longlong *)0x0;
                    cVar2 = FUN_14011dbb0(param_1);
                    if ((cVar2 == '\0') ||
                       ((cVar2 = (**(code **)(*plVar8 + 0x40))(plVar8,&local_res10), cVar2 == '\0'
                        || (cVar2 = (**(code **)(*local_res10 + 0x280))(), cVar2 == '\0')))) {
                      (**(code **)(*plVar8 + 0x30))(plVar8,param_2);
                    }
                  }
                }
                uVar10 = uVar10 + 1;
                uVar9 = (**(code **)(*plVar1 + 0x10))(plVar1);
              } while (uVar10 < uVar9);
            }
            iVar4 = iVar4 + 1;
            iVar5 = (**(code **)(*param_2 + 0x48))(param_2);
          } while (iVar4 <= iVar5 / 0x12 + 1);
        }
        iVar3 = iVar3 + 1;
        iVar4 = (**(code **)(*param_2 + 0x40))(param_2);
      } while (iVar3 <= iVar4 / 0x12 + 1);
    }
  }
  return;
}

// ==== CGameMap::helper_1402cf8b0  @1402cf8b0  [medium:callgraph-r1]  (orig: FUN_1402cf8b0)
void FUN_1402cf8b0(undefined8 *param_1,undefined8 *param_2)

{
  for (; param_1 != param_2; param_1 = param_1 + 6) {
    if ((void *)param_1[3] != (void *)0x0) {
      operator_delete((void *)param_1[3]);
    }
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    operator_delete((void *)*param_1);
  }
  return;
}

// ==== CGameMap::vfunc_6  @1402cfb70  [high:rtti-vtable]  (orig: FUN_1402cfb70)
void FUN_1402cfb70(longlong param_1,longlong *param_2,longlong param_3,char param_4)

{
  uint uVar1;
  undefined4 uVar2;
  bool bVar3;
  longlong *plVar4;
  undefined4 *puVar5;
  char cVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined8 uVar13;
  undefined4 *puVar14;
  int local_108;
  longlong *local_f8;
  undefined4 local_f0;
  undefined4 local_ec;
  longlong local_e8;
  longlong *local_e0;
  longlong *local_d8 [3];
  undefined4 *local_c0;
  undefined4 *local_b8;
  undefined8 local_b0;
  undefined4 local_a8;
  undefined4 local_a4;
  longlong *local_a0;
  longlong *local_90 [3];
  void *local_78;
  longlong local_70;
  undefined8 local_68;
  longlong *local_60 [2];
  undefined8 local_50;
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (param_2 != (longlong *)0x0) {
    plVar12 = (longlong *)0x0;
    local_50 = 0;
    local_e0 = (longlong *)0x0;
    local_f8 = (longlong *)0x0;
    bVar3 = false;
    cVar6 = (**(code **)(*param_2 + 0x38))(param_2,0x1001,&local_50);
    if ((cVar6 != '\0') ||
       (((((cVar6 = (**(code **)(*param_2 + 0x38))(param_2,0x1002,&local_e0), cVar6 != '\0' &&
           (iVar7 = (**(code **)(*local_e0 + 8))(), iVar7 - 0xaae61U < 99999)) &&
          (cVar6 = FUN_140388010(local_e0,1), cVar6 == '\0')) &&
         (cVar6 = FUN_140388010(local_e0,2), cVar6 == '\0')) || (param_4 != '\0')))) {
      bVar3 = true;
    }
    cVar6 = FUN_14011dbb0(param_1);
    if (((cVar6 == '\0') ||
        (cVar6 = (**(code **)(*param_2 + 0x40))(param_2,&local_f8), cVar6 == '\0')) ||
       (cVar6 = (**(code **)(*local_f8 + 0x280))(), cVar6 == '\0')) {
      local_a0 = operator_new(8);
      local_d8[0] = plVar12;
      if (local_a0 != (longlong *)0x0) {
        *local_a0 = (longlong)local_d8;
        local_d8[0] = local_a0;
      }
      local_c0 = (undefined4 *)0x0;
      local_b8 = (undefined4 *)0x0;
      local_b0 = 0;
      local_60[0] = local_a0;
      local_a0 = operator_new(8);
      local_90[0] = plVar12;
      if (local_a0 != (longlong *)0x0) {
        *local_a0 = (longlong)local_90;
        local_90[0] = local_a0;
      }
      local_78 = (void *)0x0;
      local_70 = 0;
      local_68 = 0;
      local_60[0] = local_a0;
      iVar7 = (**(code **)(*param_2 + 0x20))(param_2);
      if (iVar7 / 0x12 + -1 < 1) {
        local_108 = 0;
      }
      else {
        iVar7 = (**(code **)(*param_2 + 0x20))(param_2);
        local_108 = iVar7 / 0x12 + -1;
      }
      for (; (iVar7 = (**(code **)(*param_2 + 0x20))(param_2), local_108 <= iVar7 / 0x12 + 1 &&
             (iVar7 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))(),
             local_108 < (iVar7 + -1) / 0x12 + 1)); local_108 = local_108 + 1) {
        iVar7 = (**(code **)(*param_2 + 0x28))(param_2);
        if (iVar7 / 0x12 + -1 < 1) {
          iVar7 = 0;
        }
        else {
          iVar7 = (**(code **)(*param_2 + 0x28))(param_2);
          iVar7 = iVar7 / 0x12 + -1;
        }
        for (; (iVar8 = (**(code **)(*param_2 + 0x28))(param_2), iVar7 <= iVar8 / 0x12 + 1 &&
               (iVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))(),
               iVar7 < (iVar8 + -1) / 0x12 + 1)); iVar7 = iVar7 + 1) {
          local_a0 = (longlong *)0x0;
          while( true ) {
            plVar4 = local_a0;
            lVar10 = FUN_14017eea0(param_1,local_108,iVar7);
            plVar11 = (longlong *)(**(code **)(**(longlong **)(lVar10 + 8) + 0x10))();
            if (plVar11 <= plVar4) break;
            local_f0 = 0;
            local_ec = 0x1000;
            lVar10 = FUN_14017eea0(param_1,local_108,iVar7);
            plVar11 = (longlong *)
                      (**(code **)(**(longlong **)(lVar10 + 8) + 0x18))
                                (*(longlong **)(lVar10 + 8),plVar4);
            if (plVar11 != (longlong *)0x0) {
              local_f0 = (**(code **)(*plVar11 + 0x10))(plVar11);
              local_ec = (**(code **)(*plVar11 + 0x18))(plVar11);
              cVar6 = (**(code **)(*plVar11 + 0x40))(plVar11,&local_f8);
              if ((cVar6 != '\0') &&
                 (iVar8 = (**(code **)(*local_f8 + 0x150))(local_f8,param_2), iVar8 < 0x13)) {
                if (param_4 == '\0') {
                  iVar8 = (**(code **)(*param_2 + 0x18))(param_2);
                  iVar9 = (**(code **)(*plVar11 + 0x18))(plVar11);
                  if (iVar9 == iVar8) {
                    iVar8 = (**(code **)(*param_2 + 0x10))(param_2);
                    iVar9 = (**(code **)(*plVar11 + 0x10))(plVar11);
                    if (iVar9 == iVar8) goto LAB_1402d0074;
                  }
                }
                cVar6 = (**(code **)(*plVar11 + 0x38))(plVar11,0x1002,local_60);
                if (((cVar6 != '\0') && (bVar3)) &&
                   (iVar8 = (**(code **)(*local_60[0] + 8))(), 0x1869e < iVar8 - 0xaae61U)) {
                  (**(code **)(*local_f8 + 0x350))(local_f8,param_3);
                  bVar3 = false;
                }
                local_e8 = 0;
                cVar6 = (**(code **)(*plVar11 + 0x38))(plVar11,0x1001,&local_e8);
                if ((cVar6 != '\0') && (local_e8 != 0)) {
                  cVar6 = FUN_140167b70();
                  if (cVar6 == '\0') {
                    local_a8 = *(undefined4 *)(local_e8 + 0x122c);
                    FUN_140037fe0(local_d8,&local_a8);
                  }
                  else {
                    local_a4 = *(undefined4 *)(local_e8 + 0x122c);
                    FUN_140037fe0(local_90,&local_a4);
                  }
                }
              }
            }
LAB_1402d0074:
            local_a0 = (longlong *)((longlong)plVar4 + 1);
          }
        }
      }
      puVar14 = local_c0;
      uVar1 = *(uint *)(param_3 + 0xc);
      local_60[0] = (longlong *)0x0;
      if (local_b8 < local_c0) {
        _invalid_parameter_noinfo();
      }
      plVar4 = local_d8[0];
      local_60[0] = local_d8[0];
      if (uVar1 < 0x3f8) {
        if ((longlong)local_b8 - (longlong)local_c0 >> 2 != 0) {
          plVar12 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x74));
          (**(code **)(*plVar12 + 0x40))(plVar12,local_d8,param_3);
        }
      }
      else {
        while( true ) {
          puVar5 = local_b8;
          local_a0 = (longlong *)0x0;
          if (local_b8 < local_c0) {
            _invalid_parameter_noinfo();
          }
          local_a0 = local_d8[0];
          if ((plVar4 == (longlong *)0x0) || (plVar4 != local_d8[0])) {
            _invalid_parameter_noinfo();
          }
          if (puVar14 == puVar5) break;
          if (plVar4 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar11 = plVar12;
          }
          else {
            plVar11 = (longlong *)*plVar4;
          }
          if ((undefined4 *)plVar11[4] <= puVar14) {
            _invalid_parameter_noinfo();
          }
          uVar2 = *puVar14;
          uVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x74));
          plVar11 = (longlong *)FUN_140087650(uVar13);
          lVar10 = (**(code **)(*plVar11 + 0xa8))(plVar11,uVar2);
          if (lVar10 != 0) {
            (**(code **)(*(longlong *)(lVar10 + 0x10) + 0x350))((longlong *)(lVar10 + 0x10),param_3)
            ;
          }
          if (plVar4 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar11 = plVar12;
          }
          else {
            plVar11 = (longlong *)*plVar4;
          }
          if ((undefined4 *)plVar11[4] <= puVar14) {
            _invalid_parameter_noinfo();
          }
          puVar14 = puVar14 + 1;
        }
      }
      if (local_70 - (longlong)local_78 >> 2 != 0) {
        plVar12 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x74));
        (**(code **)(*plVar12 + 0x48))(plVar12,local_90,param_3);
      }
      if (local_78 != (void *)0x0) {
        operator_delete(local_78);
      }
      local_78 = (void *)0x0;
      local_70 = 0;
      local_68 = 0;
      operator_delete(local_90[0]);
      if (local_c0 != (undefined4 *)0x0) {
        operator_delete(local_c0);
      }
      local_c0 = (undefined4 *)0x0;
      local_b8 = (undefined4 *)0x0;
      local_b0 = 0;
      operator_delete(local_d8[0]);
    }
    else if (param_4 != '\0') {
      (**(code **)(*local_f8 + 0x350))(local_f8,param_3);
    }
  }
  return;
}

// ==== CGameMap::vfunc_5  @1402d0360  [high:rtti-vtable]  (orig: FUN_1402d0360)
void FUN_1402d0360(longlong param_1,int param_2,int param_3,longlong param_4)

{
  uint uVar1;
  undefined4 uVar2;
  bool bVar3;
  longlong *plVar4;
  undefined4 *puVar5;
  char cVar6;
  int iVar7;
  int iVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined8 uVar12;
  longlong *plVar13;
  undefined4 *puVar14;
  int iVar15;
  longlong *plVar16;
  longlong *local_d8;
  undefined4 local_d0;
  undefined4 local_cc;
  longlong local_c8;
  longlong *local_c0;
  longlong *local_b0 [3];
  undefined4 *local_98;
  undefined4 *local_90;
  undefined8 local_88;
  longlong *local_80 [2];
  longlong *local_70 [3];
  void *local_58;
  longlong local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  if (param_4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  bVar3 = false;
  plVar11 = (longlong *)0x0;
  local_d8 = (longlong *)0x0;
  local_c0 = operator_new(8);
  local_b0[0] = plVar11;
  if (local_c0 != (longlong *)0x0) {
    *local_c0 = (longlong)local_b0;
    local_b0[0] = local_c0;
  }
  local_98 = (undefined4 *)0x0;
  local_90 = (undefined4 *)0x0;
  local_88 = 0;
  local_80[0] = local_c0;
  local_c0 = operator_new(8);
  local_70[0] = plVar11;
  if (local_c0 != (longlong *)0x0) {
    *local_c0 = (longlong)local_70;
    local_70[0] = local_c0;
  }
  local_58 = (void *)0x0;
  local_50 = 0;
  local_48 = 0;
  uVar1 = param_2 / 0x12 - 1;
  plVar16 = plVar11;
  local_80[0] = local_c0;
  if (0 < (int)uVar1) {
    plVar16 = (longlong *)(ulonglong)uVar1;
  }
  while ((iVar15 = (int)plVar16, iVar15 <= param_2 / 0x12 + 1 &&
         (iVar7 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))(),
         iVar15 < (iVar7 + -1) / 0x12 + 1))) {
    uVar1 = param_3 / 0x12 - 1;
    plVar13 = plVar11;
    if (0 < (int)uVar1) {
      plVar13 = (longlong *)(ulonglong)uVar1;
    }
    while ((iVar7 = (int)plVar13, iVar7 <= param_3 / 0x12 + 1 &&
           (iVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))(),
           iVar7 < (iVar8 + -1) / 0x12 + 1))) {
      local_c0 = (longlong *)0x0;
      while( true ) {
        plVar4 = local_c0;
        lVar9 = FUN_14017eea0(param_1,plVar16,plVar13);
        plVar10 = (longlong *)(**(code **)(**(longlong **)(lVar9 + 8) + 0x10))();
        if (plVar10 <= plVar4) break;
        lVar9 = FUN_14017eea0(param_1,plVar16,plVar13);
        plVar10 = (longlong *)
                  (**(code **)(**(longlong **)(lVar9 + 8) + 0x18))(*(longlong **)(lVar9 + 8),plVar4)
        ;
        if (((plVar10 != (longlong *)0x0) &&
            (cVar6 = (**(code **)(*plVar10 + 0x40))(plVar10,&local_d8), cVar6 != '\0')) &&
           (iVar8 = (**(code **)(*local_d8 + 0x158))(local_d8,param_2,param_3), iVar8 < 0x13)) {
          cVar6 = (**(code **)(*plVar10 + 0x38))(plVar10,0x1002,local_80);
          if (((cVar6 != '\0') && (!bVar3)) &&
             (iVar8 = (**(code **)(*local_80[0] + 8))(), 0x1869e < iVar8 - 0xaae61U)) {
            (**(code **)(*local_d8 + 0x350))(local_d8,param_4);
            bVar3 = true;
          }
          cVar6 = (**(code **)(*plVar10 + 0x38))(plVar10,0x1001,&local_c8);
          if (cVar6 != '\0') {
            if ((local_c8 == 0) || (cVar6 = FUN_140167b70(local_c8), cVar6 == '\0')) {
              local_cc = *(undefined4 *)(local_c8 + 0x122c);
              FUN_140037fe0(local_b0,&local_cc);
            }
            else {
              local_d0 = *(undefined4 *)(local_c8 + 0x122c);
              FUN_140037fe0(local_70,&local_d0);
            }
          }
        }
        local_c0 = (longlong *)((longlong)plVar4 + 1);
      }
      plVar13 = (longlong *)(ulonglong)(iVar7 + 1);
    }
    plVar16 = (longlong *)(ulonglong)(iVar15 + 1);
  }
  puVar14 = local_98;
  uVar1 = *(uint *)(param_4 + 0xc);
  local_80[0] = (longlong *)0x0;
  if (local_90 < local_98) {
    _invalid_parameter_noinfo();
  }
  plVar16 = local_b0[0];
  local_80[0] = local_b0[0];
  if (uVar1 < 0x3f8) {
    if ((longlong)local_90 - (longlong)local_98 >> 2 != 0) {
      plVar11 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x74));
      (**(code **)(*plVar11 + 0x40))(plVar11,local_b0,param_4);
    }
  }
  else {
    while( true ) {
      puVar5 = local_90;
      local_c0 = (longlong *)0x0;
      if (local_90 < local_98) {
        _invalid_parameter_noinfo();
      }
      local_c0 = local_b0[0];
      if ((plVar16 == (longlong *)0x0) || (plVar16 != local_b0[0])) {
        _invalid_parameter_noinfo();
      }
      if (puVar14 == puVar5) break;
      if (plVar16 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar13 = plVar11;
      }
      else {
        plVar13 = (longlong *)*plVar16;
      }
      if ((undefined4 *)plVar13[4] <= puVar14) {
        _invalid_parameter_noinfo();
      }
      uVar2 = *puVar14;
      uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x74));
      plVar13 = (longlong *)FUN_140087650(uVar12);
      lVar9 = (**(code **)(*plVar13 + 0xa8))(plVar13,uVar2);
      if (lVar9 != 0) {
        (**(code **)(*(longlong *)(lVar9 + 0x10) + 0x350))((longlong *)(lVar9 + 0x10),param_4);
      }
      if (plVar16 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar13 = plVar11;
      }
      else {
        plVar13 = (longlong *)*plVar16;
      }
      if ((undefined4 *)plVar13[4] <= puVar14) {
        _invalid_parameter_noinfo();
      }
      puVar14 = puVar14 + 1;
    }
  }
  if (local_50 - (longlong)local_58 >> 2 != 0) {
    plVar11 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x74));
    (**(code **)(*plVar11 + 0x48))(plVar11,local_70,param_4);
  }
  if (local_58 != (void *)0x0) {
    operator_delete(local_58);
  }
  local_58 = (void *)0x0;
  local_50 = 0;
  local_48 = 0;
  operator_delete(local_70[0]);
  if (local_98 != (undefined4 *)0x0) {
    operator_delete(local_98);
  }
  local_98 = (undefined4 *)0x0;
  local_90 = (undefined4 *)0x0;
  local_88 = 0;
  operator_delete(local_b0[0]);
  return;
}

// ==== CGameMap::vfunc_7  @1402d0910  [high:rtti-vtable]  (orig: FUN_1402d0910)
void FUN_1402d0910(longlong *param_1,longlong param_2,longlong *param_3)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  longlong *plVar8;
  undefined8 uVar9;
  longlong *plVar10;
  undefined4 *puVar11;
  longlong *plVar12;
  longlong *local_res20;
  longlong *local_f8 [3];
  undefined4 *local_e0;
  undefined4 *local_d8;
  undefined8 local_d0;
  longlong *local_c8 [2];
  longlong *local_b8 [3];
  void *local_a0;
  longlong local_98;
  undefined8 local_90;
  uint local_88;
  undefined1 local_80 [40];
  longlong *local_58;
  longlong *local_50;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
  if (*(longlong *)(lVar7 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar7 + 0x90),local_80);
  plVar8 = (longlong *)0x0;
  local_res20 = operator_new(8);
  local_f8[0] = plVar8;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_f8;
    local_f8[0] = local_res20;
  }
  local_e0 = (undefined4 *)0x0;
  local_d8 = (undefined4 *)0x0;
  local_d0 = 0;
  local_c8[0] = local_res20;
  local_res20 = operator_new(8);
  local_b8[0] = plVar8;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_b8;
    local_b8[0] = local_res20;
  }
  local_a0 = (void *)0x0;
  local_98 = 0;
  local_90 = 0;
  plVar12 = plVar8;
  local_c8[0] = local_res20;
LAB_1402d0a50:
  do {
    cVar4 = FUN_1400cf370(local_80);
    if (cVar4 == '\0') {
LAB_1402d0c42:
      puVar11 = local_e0;
      uVar1 = *(uint *)(param_2 + 0xc);
      local_c8[0] = (longlong *)0x0;
      if (local_d8 < local_e0) {
        _invalid_parameter_noinfo();
      }
      plVar12 = local_f8[0];
      local_c8[0] = local_f8[0];
      if (uVar1 < 0x3f8) {
        if ((longlong)local_d8 - (longlong)local_e0 >> 2 != 0) {
          plVar8 = (longlong *)FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
          (**(code **)(*plVar8 + 0x40))(plVar8,local_f8,param_2);
        }
      }
      else {
        while( true ) {
          puVar3 = local_d8;
          local_50 = (longlong *)0x0;
          if (local_d8 < local_e0) {
            _invalid_parameter_noinfo();
          }
          local_50 = local_f8[0];
          if ((plVar12 == (longlong *)0x0) || (plVar12 != local_f8[0])) {
            _invalid_parameter_noinfo();
          }
          if (puVar11 == puVar3) break;
          if (plVar12 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar10 = plVar8;
          }
          else {
            plVar10 = (longlong *)*plVar12;
          }
          if ((undefined4 *)plVar10[4] <= puVar11) {
            _invalid_parameter_noinfo();
          }
          uVar2 = *puVar11;
          uVar9 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
          plVar10 = (longlong *)FUN_140087650(uVar9);
          lVar7 = (**(code **)(*plVar10 + 0xa8))(plVar10,uVar2);
          if (lVar7 != 0) {
            (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x350))((longlong *)(lVar7 + 0x10),param_2);
          }
          if (plVar12 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar10 = plVar8;
          }
          else {
            plVar10 = (longlong *)*plVar12;
          }
          if ((undefined4 *)plVar10[4] <= puVar11) {
            _invalid_parameter_noinfo();
          }
          puVar11 = puVar11 + 1;
        }
      }
      if (local_98 - (longlong)local_a0 >> 2 != 0) {
        plVar8 = (longlong *)FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
        (**(code **)(*plVar8 + 0x48))(plVar8,local_b8,param_2);
      }
      if (local_a0 != (void *)0x0) {
        operator_delete(local_a0);
      }
      local_a0 = (void *)0x0;
      local_98 = 0;
      local_90 = 0;
      operator_delete(local_b8[0]);
      if (local_e0 != (undefined4 *)0x0) {
        operator_delete(local_e0);
      }
      local_e0 = (undefined4 *)0x0;
      local_d8 = (undefined4 *)0x0;
      local_d0 = 0;
      operator_delete(local_f8[0]);
      return;
    }
    local_88 = (int)plVar12 + 1;
    plVar12 = (longlong *)(ulonglong)local_88;
    if (1000000 < local_88) {
      log_InlineLogERROR(&DAT_1406d9c10);
      goto LAB_1402d0c42;
    }
    if (local_58 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar10 = (longlong *)(**(code **)(local_58[2] + 0x160))();
    iVar5 = (**(code **)(*plVar10 + 8))(plVar10);
    iVar6 = (**(code **)(*param_1 + 8))(param_1);
  } while (iVar5 != iVar6);
  if (param_3 != (longlong *)0x0) {
    if (local_58 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    iVar5 = (**(code **)(*local_58 + 8))();
    iVar6 = (**(code **)(*param_3 + 8))(param_3);
    if (iVar6 == iVar5) goto LAB_1402d0a50;
  }
  if (local_58 == (longlong *)0x0) {
LAB_1402d0bed:
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar4 = FUN_140167b70();
    if (cVar4 != '\0') {
      if (local_58 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      local_res20 = (longlong *)
                    CONCAT44(local_res20._4_4_,*(undefined4 *)((longlong)local_58 + 0x122c));
      FUN_140037fe0(local_b8,&local_res20);
      goto LAB_1402d0a50;
    }
    if (local_58 == (longlong *)0x0) goto LAB_1402d0bed;
  }
  local_c8[0] = (longlong *)CONCAT44(local_c8[0]._4_4_,*(undefined4 *)((longlong)local_58 + 0x122c))
  ;
  FUN_140037fe0(local_f8,local_c8);
  goto LAB_1402d0a50;
}

// ==== CGameMap::helper_1402d2ac0  @1402d2ac0  [medium:callgraph-r1]  (orig: FUN_1402d2ac0)
void FUN_1402d2ac0(undefined8 *param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  if (param_1 != param_2) {
    uVar3 = 0xfffffffffffffffe;
    do {
      puVar2 = (undefined8 *)param_1[3];
      if (puVar2 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)param_1[4];
        for (; puVar2 != puVar1; puVar2 = puVar2 + 3) {
          (**(code **)*puVar2)(puVar2,0,param_3,param_4,uVar3);
        }
        operator_delete((void *)param_1[3]);
      }
      param_1[3] = 0;
      param_1[4] = 0;
      param_1[5] = 0;
      operator_delete((void *)*param_1);
      param_1 = param_1 + 6;
    } while (param_1 != param_2);
  }
  return;
}

// ==== CGameMap::ctor_or_dtor  @1402d4430  [high:vtable-assign]  (orig: FUN_1402d4430)
undefined8 * FUN_1402d4430(undefined8 *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  FUN_1402b5540();
  *param_1 = CGameMap::vftable;
  plVar1 = operator_new(8);
  plVar3 = (longlong *)0x0;
  plVar2 = plVar3;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 3);
    plVar2 = plVar1;
  }
  param_1[3] = plVar2;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  plVar2 = operator_new(8);
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x10);
    plVar3 = plVar2;
  }
  param_1[0x10] = plVar3;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  *(undefined4 *)(param_1 + 1) = 0x1008;
  *(undefined4 *)((longlong)param_1 + 0x74) = 0xffffffff;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xd] = 0;
  *(undefined4 *)(param_1 + 2) = 0xffffffff;
  *(undefined4 *)(param_1 + 0xf) = 0;
  *(undefined4 *)(param_1 + 0xe) = 0;
  return param_1;
}

// ==== CGameMap::helper_1402d4510  @1402d4510  [medium:callgraph-r0]  (orig: FUN_1402d4510)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402d4510(longlong *param_1)

{
  uint uVar1;
  longlong *plVar2;
  undefined1 auStack_b8 [32];
  undefined1 local_98;
  longlong *local_90;
  longlong *local_88;
  undefined1 local_80 [32];
  undefined8 local_60;
  char local_58 [63];
  undefined1 local_19;
  ulonglong local_18;
  
  local_60 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  *param_1 = (longlong)CGameMap::vftable;
  local_88 = param_1;
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1[0xb] + 8) + 0x20))
                     (*(longlong **)(param_1[0xb] + 8),&DAT_140951730);
  (**(code **)(*plVar2 + 0x40))(plVar2);
  _snprintf(local_58,0x40,"GameMap id: %d");
  local_19 = 0;
  FUN_14001afe0("\t\t\t\t\t\tBegin destroy %s",local_58);
  if (param_1[0xb] != 0) {
    FUN_14001aff0(local_80,"m_pData",7);
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    if (1000000 < uVar1) {
      (**(code **)(*(longlong *)param_1[0xb] + 0x70))();
    }
    (**(code **)(*(longlong *)param_1[0xb] + 0x58))();
    FUN_14001b030(local_80);
  }
  if ((longlong *)param_1[0xc] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0xc] + 0x60))();
  }
  if ((longlong *)param_1[9] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[9] + 0x10))();
  }
  if ((longlong *)param_1[10] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[10] + 8))();
  }
  if (param_1[0xd] != 0) {
    FUN_14001aff0(local_80,"m_pPKQuarterFinals",7);
    FUN_140398c60(param_1[0xd]);
    FUN_14001b030(local_80);
  }
  plVar2 = param_1 + 0x10;
  local_90 = plVar2;
  if (param_1[0x13] != 0) {
    FUN_1402cf8b0(param_1[0x13],param_1[0x14],param_1 + 0x12,local_98);
    operator_delete((void *)param_1[0x13]);
  }
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  operator_delete((void *)*plVar2);
  plVar2 = param_1 + 3;
  local_90 = plVar2;
  if (param_1[6] != 0) {
    FUN_1402d2ac0(param_1[6],param_1[7],param_1 + 5,local_98);
    operator_delete((void *)param_1[6]);
  }
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  operator_delete((void *)*plVar2);
  FUN_1402b55a0(param_1);
  return;
}

// ==== CGameMap::vfunc_0  @1402d4830  [high:rtti-vtable]  (orig: FUN_1402d4830)
undefined8 FUN_1402d4830(undefined8 param_1,uint param_2)

{
  FUN_1402d4510();
  if ((param_2 & 1) != 0) {
    FUN_1402c5b40(param_1);
  }
  return param_1;
}

