// ==== CGSMsgTalk::ctor_or_dtor  @140462b90  [high:vtable-assign]  (orig: FUN_140462b90)
undefined8 * FUN_140462b90(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CGSMsgTalk::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x2d),0x3e1,true);
  return param_1;
}

// ==== CGSMsgTalk::ctor_or_dtor  @140462c10  [high:vtable-assign]  (orig: FUN_140462c10)
void FUN_140462c10(undefined8 *param_1)

{
  *param_1 = CGSMsgTalk::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CGSMsgTalk::helper_140462c50  @140462c50  [medium:callgraph-r0]  (orig: FUN_140462c50)
bool FUN_140462c50(longlong param_1,char *param_2,char *param_3,char *param_4,char *param_5,
                  undefined4 param_6,undefined2 param_7,undefined2 param_8,undefined4 param_9,
                  undefined4 param_10,undefined1 param_11)

{
  char cVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  ulong uVar6;
  uint uVar7;
  ulonglong uVar8;
  char *pcVar9;
  
  if (param_2 != (char *)0x0) {
    uVar8 = 0xffffffffffffffff;
    pcVar9 = param_2;
    do {
      if (uVar8 == 0) break;
      uVar8 = uVar8 - 1;
      cVar1 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar1 != '\0');
    if ((~uVar8 - 1 < 0x10) && (param_3 != (char *)0x0)) {
      uVar8 = 0xffffffffffffffff;
      pcVar9 = param_3;
      do {
        if (uVar8 == 0) break;
        uVar8 = uVar8 - 1;
        cVar1 = *pcVar9;
        pcVar9 = pcVar9 + 1;
      } while (cVar1 != '\0');
      if ((~uVar8 - 1 < 0x10) && (param_4 != (char *)0x0)) {
        uVar8 = 0xffffffffffffffff;
        pcVar9 = param_4;
        do {
          if (uVar8 == 0) break;
          uVar8 = uVar8 - 1;
          cVar1 = *pcVar9;
          pcVar9 = pcVar9 + 1;
        } while (cVar1 != '\0');
        if (~uVar8 - 1 < 0x100) {
          if (param_5 != (char *)0x0) {
            uVar8 = 0xffffffffffffffff;
            pcVar9 = param_5;
            do {
              if (uVar8 == 0) break;
              uVar8 = uVar8 - 1;
              cVar1 = *pcVar9;
              pcVar9 = pcVar9 + 1;
            } while (cVar1 != '\0');
            if (0xf < ~uVar8 - 1) {
              return false;
            }
          }
          FUN_1402b5600(param_1);
          *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_6;
          *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = param_7;
          *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 10) = param_8;
          uVar6 = tq::SysTimeGet();
          *(ulong *)(*(longlong *)(param_1 + 0x428) + 0xc) = uVar6;
          *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_9;
          *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_10;
          *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = param_11;
          bVar2 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_2);
          bVar3 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_3);
          bVar4 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_5);
          bVar5 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_4);
          uVar6 = tq::TimeGet(0);
          **(ulong **)(param_1 + 0x428) = uVar6;
          *(undefined4 *)(param_1 + 8) = 0x3ec;
          uVar7 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
          *(uint *)(param_1 + 0xc) = uVar7 + 0x1f;
          return ((bVar2 && bVar3) && bVar4) && bVar5;
        }
      }
    }
  }
  return false;
}

// ==== CGSMsgTalk::vfunc_1  @140462e20  [high:rtti-vtable]  (orig: FUN_140462e20)
undefined8 FUN_140462e20(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CGSMsgTalk::ctor_or_dtor  @140462ea0  [high:vtable-assign]  (orig: FUN_140462ea0)
undefined8 * FUN_140462ea0(undefined8 *param_1,uint param_2)

{
  *param_1 = CGSMsgTalk::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CGSMsgTalk::ctor_or_dtor  @140462f00  [high:vtable-assign]  (orig: FUN_140462f00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140462f00(longlong param_1)

{
  ushort uVar1;
  undefined4 *puVar2;
  longlong lVar3;
  bool bVar4;
  longlong lVar5;
  char cVar6;
  char cVar7;
  undefined1 uVar8;
  bool bVar9;
  undefined4 uVar10;
  int iVar11;
  uint uVar12;
  longlong lVar13;
  longlong *plVar14;
  char *pcVar15;
  undefined8 uVar16;
  longlong *plVar17;
  ulonglong uVar18;
  uint uVar19;
  longlong lVar20;
  undefined1 auStack_a88 [32];
  char *local_a68;
  undefined4 local_a60;
  undefined2 local_a58;
  undefined2 local_a50;
  undefined4 local_a48;
  undefined4 local_a40;
  undefined1 local_a38;
  undefined8 local_a28;
  undefined **local_a18;
  int local_a0c;
  longlong local_5f0;
  CStringPacker local_5e8 [32];
  char local_5c8;
  undefined8 local_5c7;
  undefined4 local_5bf;
  undefined2 local_5bb;
  undefined1 local_5b9;
  char local_5b8;
  undefined8 local_5b7;
  undefined4 local_5af;
  undefined2 local_5ab;
  undefined1 local_5a9;
  char local_5a8;
  undefined8 local_5a7;
  undefined8 local_59f;
  undefined8 local_597;
  undefined8 local_58f;
  undefined8 local_587;
  undefined8 local_57f;
  undefined8 local_577;
  undefined4 local_56f;
  undefined2 local_56b;
  undefined1 local_569;
  char local_568;
  undefined8 local_567;
  undefined4 local_55f;
  undefined2 local_55b;
  undefined1 local_559;
  char local_558;
  undefined8 local_557;
  undefined4 local_54f;
  undefined2 local_54b;
  undefined1 local_549;
  char local_548;
  undefined8 local_547;
  undefined4 local_53f;
  undefined2 local_53b;
  undefined1 local_539;
  char local_538 [4];
  char local_534 [252];
  char local_438;
  undefined1 local_437 [255];
  undefined1 local_338;
  undefined1 local_337 [255];
  undefined4 local_238;
  undefined2 local_234;
  undefined1 local_232;
  undefined1 local_231 [249];
  undefined1 local_138;
  undefined1 local_137 [255];
  ulonglong local_38;
  
  local_a28 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_a88;
  local_5c8 = '\0';
  local_5c7 = 0;
  local_5bf = 0;
  local_5bb = 0;
  local_5b9 = 0;
  local_5b8 = '\0';
  local_5b7 = 0;
  local_5af = 0;
  local_5ab = 0;
  local_5a9 = 0;
  local_568 = '\0';
  local_567 = 0;
  local_55f = 0;
  local_55b = 0;
  local_559 = 0;
  local_538[0] = '\0';
  memset(local_538 + 1,0,0xff);
  local_558 = '\0';
  local_557 = 0;
  local_54f = 0;
  local_54b = 0;
  local_549 = 0;
  local_548 = '\0';
  local_547 = 0;
  local_53f = 0;
  local_53b = 0;
  local_539 = 0;
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,&local_5c8,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),1,&local_5b8,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),2,&local_568,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),3,local_538,0x100);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),4,&local_558,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),5,&local_548,0x10);
  uVar18 = 0xffffffffffffffff;
  pcVar15 = local_538;
  do {
    if (uVar18 == 0) break;
    uVar18 = uVar18 - 1;
    cVar6 = *pcVar15;
    pcVar15 = pcVar15 + 1;
  } while (cVar6 != '\0');
  if (~uVar18 - 1 < 0x100) {
    lVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar13 + 0x90) == 0) {
      local_a68 = (char *)CONCAT44(local_a68._4_4_,0x130);
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
    }
    plVar14 = (longlong *)
              (**(code **)(**(longlong **)(lVar13 + 0x90) + 0xa0))
                        (*(longlong **)(lVar13 + 0x90),*(undefined4 *)(param_1 + 0x420),
                         *(undefined4 *)(param_1 + 0x41c));
    if (plVar14 != (longlong *)0x0) {
      pcVar15 = (char *)(**(code **)(plVar14[2] + 0x18))(plVar14 + 2);
      lVar13 = -(longlong)pcVar15;
      do {
        cVar6 = *pcVar15;
        cVar7 = pcVar15[(longlong)(&local_5c8 + lVar13)];
        if (cVar6 != cVar7) break;
        pcVar15 = pcVar15 + 1;
      } while (cVar7 != '\0');
      if ((cVar6 == cVar7) ||
         (cVar6 = (**(code **)(plVar14[2] + 0x230))(plVar14 + 2), cVar6 != '\0')) {
        plVar17 = (longlong *)FUN_1400e1e60();
        lVar5 = plVar14[0x1e2];
        lVar13 = *plVar17;
        puVar2 = *(undefined4 **)(param_1 + 0x428);
        uVar10 = (**(code **)(*plVar14 + 8))(plVar14);
        (**(code **)(lVar13 + 0x108))(plVar17,uVar10,(int)lVar5,*puVar2);
        cVar6 = FUN_1401765e0(plVar14,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8));
        if ((cVar6 == '\0') && ((int)plVar14[0x1f8] != 1)) {
          cVar6 = (**(code **)(plVar14[2] + 0x230))(plVar14 + 2);
          if (cVar6 != '\0') {
            tq::GmLogSave("-TALK %s->%s: %s",&local_5c8,&local_5b8,local_538);
          }
          uVar12 = *(uint *)(*(longlong *)(param_1 + 0x428) + 0x10);
          if ((uVar12 < 1000000) || (2000000 < uVar12)) {
            if (local_538[0] == '/') {
              iVar11 = _stricmp(local_538,"/afgetghserveraaversion");
              if (iVar11 == 0) {
                local_5a8 = '\0';
                local_5a7 = 0;
                local_59f = 0;
                local_597 = 0;
                local_58f = 0;
                local_587 = 0;
                local_57f = 0;
                local_577 = 0;
                local_56f = 0;
                local_56b = 0;
                local_569 = 0;
                _snprintf(&local_5a8,0x40,
                          "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\gsmsgtalk.cpp"
                         );
                local_569 = 0;
                (**(code **)(plVar14[2] + 0x358))(plVar14 + 2,&local_5a8);
                return;
              }
              iVar11 = _stricmp(local_538,"/afgetghserveraaip");
              if (iVar11 == 0) {
                local_438 = '\0';
                memset(local_437,0,0xfe);
                iVar11 = Ordinal_57(&local_438,0xff);
                if (iVar11 == -1) {
                  return;
                }
                lVar13 = Ordinal_52(&local_438);
                if (lVar13 == 0) {
                  return;
                }
                local_5a8 = '\0';
                local_5a7 = 0;
                local_59f = 0;
                local_597 = 0;
                local_58f = 0;
                local_587 = 0;
                local_57f = 0;
                local_577 = 0;
                local_56f = 0;
                local_56b = 0;
                local_569 = 0;
                plVar17 = *(longlong **)(lVar13 + 0x18);
                lVar20 = 0;
                lVar3 = *plVar17;
                lVar5 = lVar20;
                while (lVar3 != 0) {
                  pcVar15 = (char *)Ordinal_12(**(undefined4 **)(lVar5 + (longlong)plVar17));
                  iVar11 = _stricmp(pcVar15,"127.0.0.1");
                  if (iVar11 != 0) {
                    local_a68 = pcVar15;
                    _snprintf(&local_5a8,0x40,"%s%s ",&local_5a8);
                    local_569 = 0;
                  }
                  lVar20 = lVar20 + 1;
                  lVar5 = lVar20 * 8;
                  plVar17 = *(longlong **)(lVar13 + 0x18);
                  lVar3 = plVar17[lVar20];
                }
                (**(code **)(plVar14[2] + 0x358))(plVar14 + 2,&local_5a8);
                return;
              }
            }
            cVar7 = (**(code **)(plVar14[2] + 0x230))(plVar14 + 2);
            cVar6 = local_538[0];
            if ((cVar7 == '\0') || ((local_538[0] != '/' && (local_538[3] != '/')))) {
              FUN_140462b90(&local_a18);
              lVar13 = *(longlong *)(param_1 + 0x428);
              uVar8 = (**(code **)(*plVar14 + 0x50))(plVar14);
              local_a40 = FUN_1401657e0(plVar14);
              local_a48 = *(undefined4 *)(lVar13 + 0x14);
              local_a50 = *(undefined2 *)(lVar13 + 10);
              local_a58 = *(undefined2 *)(lVar13 + 8);
              local_a60 = *(undefined4 *)(lVar13 + 4);
              local_a68 = &local_568;
              local_a38 = uVar8;
              iVar11 = FUN_140462c50(&local_a18,&local_5c8,&local_5b8,local_538);
              if (iVar11 == 0) {
                local_a68 = (char *)CONCAT44(local_a68._4_4_,0xfa);
                log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT",
                                   "msgTalk.Create(szSender, szReceiver, szWords, szEmotion, m_pInfo->dwWordsColor, m_pInfo->unTxtAttribute, m_pInfo->unTxtStyle, m_pInfo->dwLookFace, pUser->GetAllOfficial(), pUser->GetSex())"
                                   ,
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\gsmsgtalk.cpp"
                                  );
                local_a18 = CGSMsgTalk::vftable;
                tq::CStringPacker::~CStringPacker(local_5e8);
                FUN_1402b55f0(&local_a18);
              }
              else {
                bVar4 = true;
                uVar12 = tq::CStringPacker::GetStrAmount((CStringPacker *)(param_1 + 0x430));
                if (4 < uVar12) {
                  uVar19 = 4;
                  uVar12 = tq::CStringPacker::GetStrAmount((CStringPacker *)(param_1 + 0x430));
                  if (4 < uVar12) {
                    do {
                      local_438 = '\0';
                      memset(local_437,0,0xff);
                      tq::CStringPacker::GetString
                                ((CStringPacker *)(param_1 + 0x430),uVar19,&local_438,0x100);
                      bVar9 = tq::CStringPacker::AddString(local_5e8,&local_438);
                      if (bVar9) {
                        uVar12 = tq::CStringPacker::GetSize(local_5e8);
                        local_a0c = uVar12 + 0x1f;
                      }
                      bVar4 = (bool)(bVar4 & bVar9);
                      uVar19 = uVar19 + 1;
                      uVar12 = tq::CStringPacker::GetStrAmount((CStringPacker *)(param_1 + 0x430));
                    } while (uVar19 < uVar12);
                    if (!bVar4) {
                      local_a68 = (char *)CONCAT44(local_a68._4_4_,0x109);
                      log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","bSucMake",
                                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\gsmsgtalk.cpp"
                                        );
                      local_a18 = CGSMsgTalk::vftable;
                      tq::CStringPacker::~CStringPacker(local_5e8);
                      FUN_1402b55f0(&local_a18);
                      return;
                    }
                  }
                }
                cVar6 = (**(code **)(plVar14[2] + 0x220))(plVar14 + 2);
                if (cVar6 == '\0') {
                  uVar1 = *(ushort *)(*(longlong *)(param_1 + 0x428) + 8);
                  if ((uVar1 < 0x7d3) ||
                     ((((0x7d4 < uVar1 && (uVar1 != 0x7d6)) && (uVar1 != 0x7d9)) && (uVar1 != 0x7e9)
                      ))) {
                    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = 0x7dd;
                    (**(code **)(plVar14[2] + 0x348))(plVar14 + 2,&local_a18,0);
                  }
                  else {
                    (**(code **)(*plVar14 + 0x138))(plVar14,&local_a18,4);
                  }
                  local_a18 = CGSMsgTalk::vftable;
                  tq::CStringPacker::~CStringPacker(local_5e8);
                  FUN_1402b55f0(&local_a18);
                }
                else {
                  uVar1 = *(ushort *)(*(longlong *)(param_1 + 0x428) + 8);
                  if (uVar1 < 0x963) {
                    if (uVar1 == 0x962) {
                      uVar16 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                      uVar16 = FUN_140087970(uVar16);
                      cVar6 = FUN_140005850(uVar16);
                      if ((cVar6 != '\0') &&
                         ((iVar11 = FUN_1401657e0(plVar14), iVar11 != 0 ||
                          (cVar6 = FUN_140165680(plVar14), cVar6 != '\0')))) {
                        iVar11 = *(int *)(*(longlong *)(param_1 + 0x428) + 0x14);
                        if (iVar11 != 0) {
                          uVar16 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                          cVar6 = FUN_1400b4b50(uVar16,iVar11);
                          if (cVar6 == '\0') {
                            *(undefined4 *)(local_5f0 + 0x14) = 0;
                          }
                          else {
                            *(int *)(local_5f0 + 0x14) =
                                 *(int *)(*(longlong *)(param_1 + 0x428) + 0x14) << 0x10;
                          }
                        }
                        *(int *)(local_5f0 + 0x14) =
                             *(int *)(local_5f0 + 0x14) + (uint)*(ushort *)(param_1 + 0x41c);
                        FUN_140179b00(plVar14,&local_a18);
                      }
                    }
                    else {
                      switch(uVar1) {
                      case 2000:
                        (**(code **)(plVar14[2] + 0x348))(plVar14 + 2,&local_a18,0);
                        break;
                      case 0x7d1:
                      case 0x7d3:
                      case 0x7d4:
                      case 0x7d6:
                      case 0x7d9:
                      case 0x7de:
                      case 0x7e5:
                      case 0x7e9:
                      case 0x838:
                      case 0x83e:
                      case 0x899:
                      case 0x89a:
                      case 0x89b:
                      case 0x89c:
                      case 0x89d:
                        (**(code **)(*plVar14 + 0x138))(plVar14,&local_a18,4);
                        break;
                      case 0x7da:
                        cVar6 = (**(code **)(plVar14[2] + 0x230))(plVar14 + 2);
                        if (cVar6 != '\0') {
                          plVar14 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                          (**(code **)(*plVar14 + 0x68))(plVar14,&local_a18,0xffffffff);
                        }
                        break;
                      case 0x7db:
                        cVar6 = (**(code **)(plVar14[2] + 0x230))(plVar14 + 2);
                        if (cVar6 != '\0') {
                          (**(code **)(plVar14[2] + 0x348))(plVar14 + 2,&local_a18,0);
                        }
                        break;
                      case 0x89e:
                        log_InlineLogOSERROR("_TXTATR_MSG_OTHER");
                      }
                    }
                  }
                  local_a18 = CGSMsgTalk::vftable;
                  tq::CStringPacker::~CStringPacker(local_5e8);
                  FUN_1402b55f0(&local_a18);
                }
              }
            }
            else {
              local_238 = DAT_140713ecc;
              local_234 = DAT_140713ed0;
              local_232 = DAT_140713ed2;
              memset(local_231,0,0xf9);
              local_338 = 0;
              memset(local_337,0,0xff);
              local_138 = 0;
              memset(local_137,0,0xff);
              memset(&local_438,0,0x100);
              if (cVar6 == '/') {
                uVar18 = 0xffffffffffffffff;
                pcVar15 = local_538;
                do {
                  if (uVar18 == 0) break;
                  uVar18 = uVar18 - 1;
                  cVar6 = *pcVar15;
                  pcVar15 = pcVar15 + 1;
                } while (cVar6 != '\0');
                tq::SafeCopy(&local_438,local_538 + 1,~uVar18 - 1);
              }
              else if (local_538[3] == '/') {
                uVar18 = 0xffffffffffffffff;
                pcVar15 = local_538;
                do {
                  if (uVar18 == 0) break;
                  uVar18 = uVar18 - 1;
                  cVar6 = *pcVar15;
                  pcVar15 = pcVar15 + 1;
                } while (cVar6 != '\0');
                tq::SafeCopy(&local_438,local_534,~uVar18 - 7);
              }
              local_a68 = &local_138;
              sscanf(&local_438,"%s %s %s",&local_238,&local_338);
              lVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              if (*(longlong *)(lVar13 + 0x198) == 0) {
                local_a68 = (char *)CONCAT44(local_a68._4_4_,0x156);
                log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pPMMgr",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                  );
                uVar16 = 0;
              }
              else {
                uVar16 = *(undefined8 *)(lVar13 + 0x198);
              }
              FUN_1402a1ce0(uVar16,&local_438,plVar14);
            }
          }
          else if (DAT_140975c38 != 0) {
            (**(code **)(*(longlong *)(DAT_140975c38 + 0x10) + 0x350))
                      ((longlong *)(DAT_140975c38 + 0x10),param_1);
          }
        }
      }
      else {
        uVar16 = (**(code **)(plVar14[2] + 0x18))(plVar14 + 2);
        log_InlineLogOSERROR(&DAT_1406e8b68,uVar16,&local_5c8);
      }
    }
  }
  else {
    local_a68 = (char *)CONCAT44(local_a68._4_4_,0x75);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","strlen(szWords) <= 255",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\gsmsgtalk.cpp"
                      );
  }
  return;
}

