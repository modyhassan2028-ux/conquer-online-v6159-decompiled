// ==== CMsg::method_14015afe0  @14015afe0  [medium:param1-type]  (orig: FUN_14015afe0)
CMsg * FUN_14015afe0(CMsg *param_1)

{
  *(undefined ***)param_1 = tq::CMsg::vftable;
  tq::CMsg::Init(param_1);
  return param_1;
}

// ==== CMsg::method_14035ced0  @14035ced0  [medium:param1-type]  (orig: FUN_14035ced0)
CMsg * FUN_14035ced0(CMsg *param_1)

{
  *(undefined ***)param_1 = tq::CMsg::vftable;
  tq::CMsg::Init(param_1);
  *(undefined ***)param_1 = gs::CMsg::vftable;
  return param_1;
}

