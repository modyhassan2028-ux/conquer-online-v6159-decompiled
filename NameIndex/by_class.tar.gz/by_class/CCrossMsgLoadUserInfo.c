// ==== CCrossMsgLoadUserInfo::helper_140105f30  @140105f30  [medium:callgraph-r2]  (orig: FUN_140105f30)
void FUN_140105f30(longlong *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  uVar1 = (**(code **)(*param_1 + 8))();
  if ((uVar1 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
  }
  else {
    uVar2 = (undefined4)param_1[0xd];
  }
  *param_2 = uVar2;
  param_2[1] = 0;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[2] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],2);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[3] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],3);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[4] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],4);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[5] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],5);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[6] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],6);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[7] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],7);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[8] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],8);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[9] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],9);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[10] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],10);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0xb] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xb);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0xc] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0xd] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xd);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0xe] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xe);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0xf] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xf);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x10] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x10);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x11] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x11);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x12] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x12);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x13] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x13);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x14] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x14);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x15] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x15);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x16] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x16);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x17] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x17);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x18] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x19);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  param_2[0x1c] = uVar2;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x18);
  uVar4 = (**(code **)(*plVar3 + 0x58))(plVar3);
  *(undefined8 *)(param_2 + 0x1a) = uVar4;
  plVar3 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x1a);
  uVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  *(undefined1 *)(param_2 + 0x1e) = 1;
  param_2[0x1d] = uVar2;
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1401585b0  @1401585b0  [medium:callgraph-r1]  (orig: FUN_1401585b0)
void FUN_1401585b0(longlong param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  if (param_2 != (longlong *)0x0) {
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar1 = *(char *)((longlong)puVar8 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x38);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar8 + 3) < uVar5) {
        puVar6 = (undefined8 *)puVar8[2];
        puVar8 = puVar3;
      }
      else {
        puVar6 = (undefined8 *)*puVar8;
      }
      puVar3 = puVar8;
      puVar8 = puVar6;
      cVar1 = *(char *)((longlong)puVar6 + 0x29);
    }
    puVar8 = *(undefined8 **)(param_1 + 0x38);
    local_30 = puVar3;
    local_38 = *(longlong *)(param_1 + 8);
    if (*(longlong *)(param_1 + 8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar8) || (uVar5 < *(uint *)(puVar3 + 3))) {
      plVar7 = &local_28;
      local_20 = *(undefined8 *)(param_1 + 0x38);
      local_28 = *(longlong *)(param_1 + 8);
    }
    else {
      plVar7 = &local_38;
    }
    plVar2 = (longlong *)*plVar7;
    lVar9 = *(longlong *)(param_1 + 0x38);
    local_18 = plVar2;
    local_10 = plVar7[1];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    lVar4 = local_10;
    if (local_10 != lVar9) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)(lVar4 + 0x20);
      if (lVar9 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_1403af2a0(lVar9,param_2);
      }
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_140167210  @140167210  [medium:callgraph-r1]  (orig: FUN_140167210)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140167210(longlong *param_1)

{
  int iVar1;
  undefined4 uVar2;
  longlong *plVar3;
  char *_Source;
  char *_Source_00;
  undefined1 auStack_4b8 [32];
  undefined8 local_498;
  int local_488;
  undefined4 local_484;
  undefined4 local_480;
  char local_47c [1124];
  ulonglong local_18;
  
  local_498 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  iVar1 = (**(code **)(param_1[2] + 0x170))();
  if (iVar1 != 0) {
    plVar3 = (longlong *)FUN_140087ed0();
    _Source = (char *)(**(code **)(*plVar3 + 0x290))(plVar3,iVar1);
    if (_Source != (char *)0x0) {
      plVar3 = (longlong *)FUN_140087ed0();
      _Source_00 = (char *)(**(code **)(*plVar3 + 0x298))(plVar3,iVar1);
      if (_Source_00 != (char *)0x0) {
        local_484 = 0;
        local_480 = 0;
        local_47c[0] = '\0';
        local_47c[1] = '\0';
        local_47c[2] = '\0';
        local_47c[3] = '\0';
        local_47c[4] = '\0';
        local_47c[5] = '\0';
        local_47c[6] = '\0';
        local_47c[7] = '\0';
        local_47c[8] = '\0';
        local_47c[9] = '\0';
        local_47c[10] = '\0';
        local_47c[0xb] = '\0';
        local_47c[0xc] = '\0';
        local_47c[0xd] = '\0';
        local_47c[0xe] = '\0';
        local_47c[0xf] = '\0';
        local_47c[0x10] = '\0';
        local_47c[0x11] = '\0';
        local_47c[0x12] = '\0';
        local_47c[0x13] = '\0';
        local_47c[0x14] = '\0';
        local_47c[0x15] = '\0';
        local_47c[0x16] = '\0';
        local_47c[0x17] = '\0';
        local_47c[0x18] = '\0';
        local_47c[0x19] = '\0';
        local_47c[0x1a] = '\0';
        local_47c[0x1b] = '\0';
        local_47c[0x1c] = '\0';
        local_47c[0x1d] = '\0';
        local_47c[0x1e] = '\0';
        local_47c[0x1f] = '\0';
        local_47c[0x20] = '\0';
        local_47c[0x21] = '\0';
        local_47c[0x22] = '\0';
        local_47c[0x23] = '\0';
        local_47c[0x24] = '\0';
        local_47c[0x25] = '\0';
        local_47c[0x26] = '\0';
        local_47c[0x27] = '\0';
        local_47c[0x28] = '\0';
        local_47c[0x29] = '\0';
        local_47c[0x2a] = '\0';
        local_47c[0x2b] = '\0';
        local_47c[0x2c] = '\0';
        local_47c[0x2d] = '\0';
        local_47c[0x2e] = '\0';
        local_47c[0x2f] = '\0';
        local_47c[0x30] = '\0';
        local_47c[0x31] = '\0';
        local_47c[0x32] = '\0';
        local_47c[0x33] = '\0';
        local_488 = iVar1;
        plVar3 = (longlong *)FUN_140087ed0();
        local_484 = (**(code **)(*plVar3 + 0x2c0))(plVar3,iVar1);
        plVar3 = (longlong *)FUN_140087ed0();
        local_480 = (**(code **)(*plVar3 + 0x2c8))(plVar3,iVar1);
        strncpy(local_47c + 0x10,_Source,0x24);
        strncpy(local_47c,_Source_00,0x10);
        FUN_1403b6940(local_47c + 0x34);
        uVar2 = (**(code **)(*param_1 + 8))(param_1);
        iVar1 = FUN_1403b69f0(local_47c + 0x34,0,uVar2,&local_488);
        if (iVar1 != 0) {
          (**(code **)(*param_1 + 0x130))(param_1,local_47c + 0x34);
        }
        FUN_1403b6990(local_47c + 0x34);
      }
    }
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_140167bb0  @140167bb0  [medium:callgraph-r1]  (orig: FUN_140167bb0)
longlong FUN_140167bb0(longlong *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  
  uVar1 = (**(code **)(*param_1 + 8))();
  if ((0xee69a15e < uVar1) && (*(int *)((longlong)param_1 + 0x12fc) != 0)) {
    return (longlong)param_1 + 0x133a;
  }
  param_1 = param_1 + 0x1cf;
  iVar2 = FUN_140373290(param_1);
  if (iVar2 != 0) {
    lVar5 = FUN_140087ed0();
    if (lVar5 != 0) {
      plVar6 = (longlong *)FUN_140087ed0();
      iVar2 = FUN_140373290(param_1);
      iVar3 = (**(code **)(*plVar6 + 0x440))(plVar6);
      if (iVar2 == iVar3) {
        plVar6 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x000140167c3f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        lVar5 = (**(code **)(*plVar6 + 0x468))(plVar6);
        return lVar5;
      }
      plVar6 = (longlong *)FUN_140087ed0();
      uVar4 = FUN_140373290(param_1);
                    /* WARNING: Could not recover jumptable at 0x000140167c68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      lVar5 = (**(code **)(*plVar6 + 0x470))(plVar6,uVar4);
      return lVar5;
    }
  }
  return 0;
}

// ==== CCrossMsgLoadUserInfo::helper_140167cb0  @140167cb0  [medium:callgraph-r1]  (orig: FUN_140167cb0)
undefined1 FUN_140167cb0(longlong *param_1)

{
  longlong lVar1;
  undefined1 uVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  
  uVar3 = (**(code **)(*param_1 + 8))();
  if ((0xee69a15e < uVar3) && (*(int *)((longlong)param_1 + 0x12fc) != 0)) {
    return (char)param_1[0x267];
  }
  plVar5 = (longlong *)FUN_140087ed0();
  lVar1 = *plVar5;
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
                    /* WARNING: Could not recover jumptable at 0x000140167d14. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(lVar1 + 0x410))(plVar5,uVar4);
  return uVar2;
}

// ==== CCrossMsgLoadUserInfo::helper_14017acd0  @14017acd0  [medium:callgraph-r1]  (orig: FUN_14017acd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14017acd0(longlong *param_1,char param_2)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  longlong *plVar4;
  undefined8 uVar5;
  int iVar6;
  undefined1 auStack_988 [32];
  int local_968 [2];
  undefined8 local_960;
  undefined1 local_958 [1280];
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_960 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_988;
  iVar6 = 0;
  local_968[0] = 0;
  memset(local_958,0,0x500);
  plVar4 = (longlong *)FUN_140118220();
  lVar1 = *plVar4;
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar1 + 200))(plVar4,uVar3,local_968,local_958);
  if (local_968[0] < 1) {
    uVar5 = 1;
  }
  else if (local_968[0] < 0x15) {
    FUN_1403ef4f0(local_458);
    uVar3 = (**(code **)(*param_1 + 8))(param_1);
    cVar2 = FUN_1403ef5a0(local_458,param_2 == '\0',uVar3);
    if (cVar2 == '\0') {
      FUN_1403ef540(local_458);
      uVar5 = 0;
    }
    else {
      if (0 < local_968[0]) {
        do {
          cVar2 = FUN_1403ef5e0(local_458,local_958 + (longlong)iVar6 * 0x40);
          if (cVar2 == '\0') {
            if (param_2 == '\0') {
              (**(code **)(*param_1 + 0x138))(param_1,local_458,4);
            }
            else {
              (**(code **)(*param_1 + 0x130))(param_1,local_458);
            }
            uVar3 = (**(code **)(*param_1 + 8))(param_1);
            cVar2 = FUN_1403ef5a0(local_458,param_2 == '\0',uVar3);
            if ((cVar2 == '\0') ||
               (cVar2 = FUN_1403ef5e0(local_458,local_958 + (longlong)iVar6 * 0x40), cVar2 == '\0'))
            {
              FUN_1403ef540(local_458);
              return 0;
            }
          }
          iVar6 = iVar6 + 1;
        } while (iVar6 < local_968[0]);
      }
      if (param_2 == '\0') {
        (**(code **)(*param_1 + 0x138))(param_1,local_458,4);
      }
      else {
        (**(code **)(*param_1 + 0x130))(param_1,local_458);
      }
      FUN_1403ef540(local_458);
      uVar5 = 1;
    }
  }
  else {
    log_InlineLogERROR("CUser::SendTaskInfoToCrossServer the task num is max than 20");
    uVar5 = 0;
  }
  return uVar5;
}

// ==== CCrossMsgLoadUserInfo::helper_14019a540  @14019a540  [medium:callgraph-r1]  (orig: FUN_14019a540)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14019a540(longlong *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 *puVar4;
  char cVar5;
  undefined4 uVar6;
  longlong lVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  ulonglong uVar11;
  longlong *plVar12;
  longlong *plVar13;
  bool bVar14;
  undefined1 auStack_698 [32];
  undefined4 local_678;
  undefined8 *local_668;
  undefined4 uStack_660;
  undefined4 uStack_65c;
  undefined8 *local_658;
  undefined4 uStack_650;
  undefined4 uStack_64c;
  undefined8 *local_648;
  undefined8 uStack_640;
  undefined8 *local_638;
  undefined8 *local_628;
  undefined8 uStack_620;
  undefined8 *local_618;
  undefined8 *local_608;
  undefined8 local_5f8;
  undefined4 local_5e8;
  undefined1 local_5e4 [124];
  undefined4 local_568;
  undefined1 local_564 [124];
  undefined4 local_4e8;
  undefined1 local_4e4 [124];
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_5f8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_698;
  FUN_1403f16f0(local_468);
  uVar6 = (**(code **)(*param_1 + 8))(param_1);
  cVar5 = FUN_1403f17a0(local_468,uVar6);
  if (cVar5 == '\0') {
    FUN_1403f1740(local_468);
  }
  else {
    puVar1 = (undefined8 *)param_1[0x1a5];
    puVar8 = (undefined8 *)*puVar1;
    plVar13 = (longlong *)0x0;
    puVar2 = (undefined8 *)param_1[0x19f];
    local_618 = puVar2;
    local_608 = puVar2;
LAB_14019a5f0:
    if (puVar2 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 != puVar1) {
      plVar10 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_678 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar10 = plVar13;
      }
      if (puVar2 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar12 = plVar13;
      }
      else {
        plVar12 = (longlong *)*puVar2;
      }
      if (puVar8 == (undefined8 *)plVar12[6]) {
        _invalid_parameter_noinfo();
      }
      lVar7 = (**(code **)(*plVar10 + 0x60))(plVar10);
      if (lVar7 != 0) {
        local_5e8 = 0;
        memset(local_5e4,0,0x7c);
        FUN_140105f30(lVar7,&local_5e8);
        cVar5 = FUN_1403f17d0(local_468,&local_5e8);
        if (cVar5 == '\0') {
          (**(code **)(*param_1 + 0x130))(param_1,local_468);
          FUN_1403f1830(local_468);
          FUN_1403f17d0(local_468,&local_5e8);
        }
      }
      if (puVar2 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x21) == '\0') {
        puVar9 = puVar8;
        puVar4 = (undefined8 *)puVar8[2];
        if (*(char *)((longlong)puVar8[2] + 0x21) == '\0') {
          do {
            puVar8 = puVar4;
            puVar4 = (undefined8 *)*puVar8;
            local_638 = puVar8;
          } while (*(char *)((longlong)*puVar8 + 0x21) == '\0');
        }
        else {
          do {
            puVar8 = (undefined8 *)puVar9[1];
            if (*(char *)((longlong)puVar8 + 0x21) != '\0') break;
            bVar14 = puVar9 == (undefined8 *)puVar8[2];
            puVar9 = puVar8;
          } while (bVar14);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_14019a5f0;
    }
    uVar11 = param_1[0x184];
    local_658 = (undefined8 *)0x0;
    if ((ulonglong)param_1[0x185] < uVar11) {
      _invalid_parameter_noinfo();
    }
    puVar1 = (undefined8 *)param_1[0x181];
    uVar3 = param_1[0x185];
    local_668 = (undefined8 *)0x0;
    local_658 = puVar1;
    if (uVar3 < (ulonglong)param_1[0x184]) {
      _invalid_parameter_noinfo();
    }
    puVar8 = (undefined8 *)param_1[0x181];
    local_668 = puVar8;
    while( true ) {
      if ((puVar1 == (undefined8 *)0x0) || (puVar1 != puVar8)) {
        _invalid_parameter_noinfo();
      }
      if (uVar11 == uVar3) break;
      plVar10 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_678 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar10 = plVar13;
      }
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar12 = plVar13;
      }
      else {
        plVar12 = (longlong *)*puVar1;
      }
      if ((ulonglong)plVar12[4] <= uVar11) {
        _invalid_parameter_noinfo();
      }
      lVar7 = (**(code **)(*plVar10 + 0x60))(plVar10);
      if (lVar7 != 0) {
        local_4e8 = 0;
        memset(local_4e4,0,0x7c);
        FUN_140105f30(lVar7,&local_4e8);
        cVar5 = FUN_1403f17d0(local_468,&local_4e8);
        if (cVar5 == '\0') {
          (**(code **)(*param_1 + 0x130))(param_1,local_468);
          FUN_1403f1830(local_468);
          FUN_1403f17d0(local_468,&local_4e8);
        }
      }
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar10 = plVar13;
      }
      else {
        plVar10 = (longlong *)*puVar1;
      }
      if ((ulonglong)plVar10[4] <= uVar11) {
        _invalid_parameter_noinfo();
      }
      uVar11 = uVar11 + 4;
    }
    uVar11 = param_1[0x19c];
    local_628 = (undefined8 *)0x0;
    if ((ulonglong)param_1[0x19d] < uVar11) {
      _invalid_parameter_noinfo();
    }
    local_658 = (undefined8 *)param_1[0x199];
    uStack_620._0_4_ = (undefined4)uVar11;
    uStack_620._4_4_ = (undefined4)(uVar11 >> 0x20);
    uStack_650 = (undefined4)uStack_620;
    uStack_64c = uStack_620._4_4_;
    uVar3 = param_1[0x19d];
    local_648 = (undefined8 *)0x0;
    local_628 = local_658;
    uStack_620 = uVar11;
    if (uVar3 < (ulonglong)param_1[0x19c]) {
      _invalid_parameter_noinfo();
    }
    puVar8 = local_658;
    puVar1 = (undefined8 *)param_1[0x199];
    uStack_640._0_4_ = (undefined4)uVar3;
    uStack_640._4_4_ = (undefined4)(uVar3 >> 0x20);
    uStack_660 = (undefined4)uStack_640;
    uStack_65c = uStack_640._4_4_;
    uVar11 = CONCAT44(uStack_64c,uStack_650);
    local_668 = puVar1;
    local_648 = puVar1;
    uStack_640 = uVar3;
    while( true ) {
      if ((puVar8 == (undefined8 *)0x0) || (puVar8 != puVar1)) {
        _invalid_parameter_noinfo();
      }
      if (uVar11 == uVar3) break;
      plVar10 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_678 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar10 = plVar13;
      }
      if (puVar8 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar12 = plVar13;
      }
      else {
        plVar12 = (longlong *)*puVar8;
      }
      if ((ulonglong)plVar12[4] <= uVar11) {
        _invalid_parameter_noinfo();
      }
      lVar7 = (**(code **)(*plVar10 + 0x60))(plVar10);
      if (lVar7 != 0) {
        local_568 = 0;
        memset(local_564,0,0x7c);
        FUN_140105f30(lVar7,&local_568);
        cVar5 = FUN_1403f17d0(local_468,&local_568);
        if (cVar5 == '\0') {
          (**(code **)(*param_1 + 0x130))(param_1,local_468);
          FUN_1403f1830(local_468);
          FUN_1403f17d0(local_468,&local_568);
        }
      }
      if (puVar8 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar10 = plVar13;
      }
      else {
        plVar10 = (longlong *)*puVar8;
      }
      if ((ulonglong)plVar10[4] <= uVar11) {
        _invalid_parameter_noinfo();
      }
      uVar11 = uVar11 + 4;
    }
    (**(code **)(*param_1 + 0x130))(param_1,local_468);
    FUN_1403f1740(local_468);
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_14019aae0  @14019aae0  [medium:callgraph-r1]  (orig: FUN_14019aae0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14019aae0(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  undefined8 *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 *puVar13;
  undefined8 *puVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong *plVar17;
  longlong lVar18;
  longlong *plVar19;
  longlong *plVar20;
  bool bVar21;
  undefined1 auStack_658 [32];
  undefined4 local_638;
  undefined4 local_630;
  undefined4 local_628;
  undefined4 local_620;
  undefined4 local_618;
  undefined4 local_610;
  undefined4 local_608;
  undefined4 local_5f8;
  undefined4 local_5f4;
  longlong *local_5f0;
  undefined4 *local_5e8;
  undefined8 *local_5e0;
  longlong *local_5d8;
  longlong *local_5d0;
  longlong *local_5c8;
  longlong *local_5b8;
  longlong *local_5a8;
  undefined8 uStack_5a0;
  longlong *local_598;
  undefined8 uStack_590;
  longlong *local_588;
  undefined4 uStack_580;
  undefined4 uStack_57c;
  longlong *local_578 [3];
  undefined8 *local_560;
  undefined8 *local_558;
  undefined8 local_550;
  longlong *local_548 [3];
  undefined8 *local_530;
  undefined8 *local_528;
  undefined8 local_520;
  longlong *local_518 [3];
  undefined8 *local_500;
  undefined8 *local_4f8;
  undefined8 local_4f0;
  longlong *local_4e8;
  longlong *local_4d8;
  undefined4 uStack_4d0;
  undefined4 uStack_4cc;
  undefined8 *local_4c8;
  longlong *local_4c0;
  undefined8 local_4b0;
  longlong *local_4a8;
  longlong *local_498;
  longlong *local_488;
  longlong *local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_4b0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_658;
  local_5d0 = param_1;
  FUN_1403f1970(local_468);
  uVar5 = (**(code **)(*param_1 + 8))(param_1);
  cVar4 = FUN_1403f1a20(local_468,uVar5);
  if (cVar4 == '\0') {
    FUN_1403f19c0(local_468);
  }
  else {
    local_5e0 = (undefined8 *)param_1[0x1a5];
    plVar17 = (longlong *)*local_5e0;
    plVar16 = (longlong *)param_1[0x19f];
    local_5b8 = plVar17;
    local_4e8 = plVar16;
    local_4c0 = plVar16;
LAB_14019aba5:
    puVar14 = local_5e0;
    plVar15 = (longlong *)0x0;
    if ((plVar16 == (longlong *)0x0) || (plVar16 != local_4e8)) {
      _invalid_parameter_noinfo();
    }
    if (plVar17 != puVar14) {
      plVar19 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_638 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar19 = plVar15;
      }
      if (plVar16 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar20 = plVar15;
      }
      else {
        plVar20 = (longlong *)*plVar16;
      }
      if (plVar17 == (undefined8 *)plVar20[6]) {
        _invalid_parameter_noinfo();
      }
      puVar13 = (undefined4 *)
                (**(code **)(*plVar19 + 0x60))(plVar19,*(undefined4 *)((longlong)plVar17 + 0x1c));
      local_5e8 = puVar13;
      if (puVar13 != (undefined4 *)0x0) {
        local_5a8 = operator_new(8);
        if (local_5a8 != (longlong *)0x0) {
          *local_5a8 = (longlong)local_548;
          plVar15 = local_5a8;
        }
        local_530 = (undefined8 *)0x0;
        local_528 = (undefined8 *)0x0;
        local_520 = 0;
        local_598 = local_5a8;
        local_548[0] = plVar15;
        FUN_140109210(puVar13,local_548);
        plVar15 = local_530;
        local_5f0 = local_530;
        local_5c8 = (longlong *)0x0;
        if (local_528 < local_530) {
          _invalid_parameter_noinfo();
        }
        local_5d8 = local_548[0];
        local_5c8 = local_548[0];
        plVar19 = local_548[0];
        while( true ) {
          puVar14 = local_528;
          local_478 = (longlong *)0x0;
          if (local_528 < local_530) {
            _invalid_parameter_noinfo();
          }
          local_478 = local_548[0];
          if ((plVar19 == (longlong *)0x0) || (plVar19 != local_548[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar15 == puVar14) break;
          if (plVar19 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar18 = 0;
          }
          else {
            lVar18 = *plVar19;
          }
          if (*(undefined8 **)(lVar18 + 0x20) <= plVar15) {
            _invalid_parameter_noinfo();
          }
          local_5c8 = (longlong *)*plVar15;
          if (local_5c8 != (longlong *)0x0) {
            if (plVar16 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar18 = 0;
            }
            else {
              lVar18 = *plVar16;
            }
            if (plVar17 == *(undefined8 **)(lVar18 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            local_5f4 = *(undefined4 *)((longlong)plVar17 + 0x1c);
            cVar4 = FUN_140167b70(param_1);
            if (cVar4 != '\0') {
              local_5f4 = FUN_140100c20(puVar13);
            }
            local_5f8 = FUN_1400fda10(puVar13,1,1);
            plVar17 = local_5c8;
            uVar5 = (**(code **)(*local_5c8 + 0x30))(local_5c8,8);
            uVar6 = (**(code **)(*plVar17 + 0x30))(plVar17,7);
            uVar7 = (**(code **)(*plVar17 + 0x30))(plVar17,6);
            uVar8 = (**(code **)(*plVar17 + 0x30))(plVar17,5);
            uVar9 = (**(code **)(*plVar17 + 0x30))(plVar17,4);
            uVar10 = (**(code **)(*plVar17 + 0x30))(plVar17,3);
            uVar11 = (**(code **)(*plVar17 + 0x30))(plVar17,2);
            uVar12 = (**(code **)*local_5c8)();
            local_608 = local_5f8;
            local_638 = uVar10;
            local_630 = uVar9;
            local_628 = uVar8;
            local_620 = uVar7;
            local_618 = uVar6;
            local_610 = uVar5;
            cVar4 = FUN_1403f1a50(local_468,uVar12,local_5f4,uVar11);
            plVar17 = local_5b8;
            plVar15 = local_5f0;
            plVar19 = local_5d8;
            plVar16 = local_4c0;
            puVar13 = local_5e8;
            param_1 = local_5d0;
            if (cVar4 == '\0') {
              (**(code **)(*local_5d0 + 0x130))(local_5d0,local_468);
              FUN_1403f1b60(local_468);
              local_5f8 = FUN_1400fda10(local_5e8,1,1);
              plVar17 = local_5c8;
              uVar5 = (**(code **)(*local_5c8 + 0x30))(local_5c8,8);
              uVar6 = (**(code **)(*plVar17 + 0x30))(plVar17,7);
              uVar7 = (**(code **)(*plVar17 + 0x30))(plVar17,6);
              uVar8 = (**(code **)(*plVar17 + 0x30))(plVar17,5);
              uVar9 = (**(code **)(*plVar17 + 0x30))(plVar17,4);
              uVar10 = (**(code **)(*plVar17 + 0x30))(plVar17,3);
              uVar11 = (**(code **)(*plVar17 + 0x30))(plVar17,2);
              uVar12 = (**(code **)*local_5c8)();
              local_608 = local_5f8;
              local_638 = uVar10;
              local_630 = uVar9;
              local_628 = uVar8;
              local_620 = uVar7;
              local_618 = uVar6;
              local_610 = uVar5;
              FUN_1403f1a50(local_468,uVar12,local_5f4,uVar11);
              plVar17 = local_5b8;
              plVar15 = local_5f0;
              plVar19 = local_5d8;
              plVar16 = local_4c0;
              puVar13 = local_5e8;
              param_1 = local_5d0;
            }
          }
          if (plVar19 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar18 = 0;
          }
          else {
            lVar18 = *plVar19;
          }
          if (*(undefined8 **)(lVar18 + 0x20) <= plVar15) {
            _invalid_parameter_noinfo();
          }
          plVar15 = plVar15 + 1;
          local_5f0 = plVar15;
        }
        if (local_530 != (undefined8 *)0x0) {
          operator_delete(local_530);
        }
        local_530 = (undefined8 *)0x0;
        local_528 = (undefined8 *)0x0;
        local_520 = 0;
        operator_delete(local_548[0]);
      }
      if (plVar16 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar17 + 0x21) == '\0') {
        puVar14 = plVar17;
        puVar3 = (undefined8 *)plVar17[2];
        if (*(char *)(plVar17[2] + 0x21) == '\0') {
          do {
            plVar17 = puVar3;
            puVar3 = (undefined8 *)*plVar17;
            local_5b8 = plVar17;
            local_4c8 = plVar17;
          } while (*(char *)(*plVar17 + 0x21) == '\0');
        }
        else {
          do {
            plVar17 = (longlong *)puVar14[1];
            local_5b8 = plVar17;
            if (*(char *)((longlong)plVar17 + 0x21) != '\0') break;
            bVar21 = puVar14 == (undefined8 *)plVar17[2];
            puVar14 = plVar17;
          } while (bVar21);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_14019aba5;
    }
    puVar13 = (undefined4 *)param_1[0x184];
    local_588 = (longlong *)0x0;
    local_5e8 = puVar13;
    if ((undefined4 *)param_1[0x185] < puVar13) {
      _invalid_parameter_noinfo();
    }
    plVar17 = (longlong *)param_1[0x181];
    plVar16 = (longlong *)param_1[0x185];
    local_4d8 = (longlong *)0x0;
    local_5b8 = plVar17;
    local_598 = plVar16;
    local_588 = plVar17;
    if (plVar16 < (undefined4 *)param_1[0x184]) {
      _invalid_parameter_noinfo();
    }
    local_5a8 = (longlong *)param_1[0x181];
    local_4d8 = local_5a8;
    while( true ) {
      plVar15 = (longlong *)0x0;
      if ((plVar17 == (longlong *)0x0) || (plVar17 != local_5a8)) {
        _invalid_parameter_noinfo();
      }
      if ((longlong *)puVar13 == plVar16) break;
      plVar16 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_638 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar16 = plVar15;
      }
      if (plVar17 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar19 = plVar15;
      }
      else {
        plVar19 = (longlong *)*plVar17;
      }
      if ((undefined4 *)plVar19[4] <= puVar13) {
        _invalid_parameter_noinfo();
      }
      puVar14 = (undefined8 *)(**(code **)(*plVar16 + 0x60))(plVar16,*puVar13);
      local_5e0 = puVar14;
      if (puVar14 != (undefined8 *)0x0) {
        local_5f0 = operator_new(8);
        if (local_5f0 != (longlong *)0x0) {
          *local_5f0 = (longlong)local_578;
          plVar15 = local_5f0;
        }
        local_560 = (undefined8 *)0x0;
        local_558 = (undefined8 *)0x0;
        local_550 = 0;
        local_5d8 = local_5f0;
        local_578[0] = plVar15;
        FUN_140109210(puVar14,local_578);
        plVar16 = local_560;
        local_5f0 = local_560;
        local_4a8 = (longlong *)0x0;
        if (local_558 < local_560) {
          _invalid_parameter_noinfo();
        }
        local_5d8 = local_578[0];
        local_4a8 = local_578[0];
        plVar15 = local_578[0];
        while( true ) {
          puVar3 = local_558;
          local_488 = (longlong *)0x0;
          if (local_558 < local_560) {
            _invalid_parameter_noinfo();
          }
          local_488 = local_578[0];
          if ((plVar15 == (longlong *)0x0) || (plVar15 != local_578[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar16 == puVar3) break;
          if (plVar15 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar18 = 0;
          }
          else {
            lVar18 = *plVar15;
          }
          if (*(undefined8 **)(lVar18 + 0x20) <= plVar16) {
            _invalid_parameter_noinfo();
          }
          local_5c8 = (longlong *)*plVar16;
          if (local_5c8 != (longlong *)0x0) {
            if (plVar17 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar18 = 0;
            }
            else {
              lVar18 = *plVar17;
            }
            if (*(undefined4 **)(lVar18 + 0x20) <= puVar13) {
              _invalid_parameter_noinfo();
            }
            local_5f4 = *puVar13;
            cVar4 = FUN_140167b70(param_1);
            if (cVar4 != '\0') {
              local_5f4 = FUN_140100c20(puVar14);
            }
            local_5f8 = FUN_1400fda10(puVar14,1,1);
            plVar17 = local_5c8;
            uVar5 = (**(code **)(*local_5c8 + 0x30))(local_5c8,8);
            uVar6 = (**(code **)(*plVar17 + 0x30))(plVar17,7);
            uVar7 = (**(code **)(*plVar17 + 0x30))(plVar17,6);
            uVar8 = (**(code **)(*plVar17 + 0x30))(plVar17,5);
            uVar9 = (**(code **)(*plVar17 + 0x30))(plVar17,4);
            uVar10 = (**(code **)(*plVar17 + 0x30))(plVar17,3);
            uVar11 = (**(code **)(*plVar17 + 0x30))(plVar17,2);
            uVar12 = (**(code **)*local_5c8)();
            local_608 = local_5f8;
            local_638 = uVar10;
            local_630 = uVar9;
            local_628 = uVar8;
            local_620 = uVar7;
            local_618 = uVar6;
            local_610 = uVar5;
            cVar4 = FUN_1403f1a50(local_468,uVar12,local_5f4,uVar11);
            plVar15 = local_5d8;
            plVar16 = local_5f0;
            plVar17 = local_5b8;
            puVar13 = local_5e8;
            puVar14 = local_5e0;
            param_1 = local_5d0;
            if (cVar4 == '\0') {
              (**(code **)(*local_5d0 + 0x130))(local_5d0,local_468);
              FUN_1403f1b60(local_468);
              local_5f8 = FUN_1400fda10(local_5e0,1,1);
              plVar17 = local_5c8;
              uVar5 = (**(code **)(*local_5c8 + 0x30))(local_5c8,8);
              uVar6 = (**(code **)(*plVar17 + 0x30))(plVar17,7);
              uVar7 = (**(code **)(*plVar17 + 0x30))(plVar17,6);
              uVar8 = (**(code **)(*plVar17 + 0x30))(plVar17,5);
              uVar9 = (**(code **)(*plVar17 + 0x30))(plVar17,4);
              uVar10 = (**(code **)(*plVar17 + 0x30))(plVar17,3);
              uVar11 = (**(code **)(*plVar17 + 0x30))(plVar17,2);
              uVar12 = (**(code **)*local_5c8)();
              local_608 = local_5f8;
              local_638 = uVar10;
              local_630 = uVar9;
              local_628 = uVar8;
              local_620 = uVar7;
              local_618 = uVar6;
              local_610 = uVar5;
              FUN_1403f1a50(local_468,uVar12,local_5f4,uVar11);
              plVar15 = local_5d8;
              plVar16 = local_5f0;
              plVar17 = local_5b8;
              puVar13 = local_5e8;
              puVar14 = local_5e0;
              param_1 = local_5d0;
            }
          }
          if (plVar15 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar18 = 0;
          }
          else {
            lVar18 = *plVar15;
          }
          if (*(undefined8 **)(lVar18 + 0x20) <= plVar16) {
            _invalid_parameter_noinfo();
          }
          plVar16 = plVar16 + 1;
          local_5f0 = plVar16;
        }
        if (local_560 != (undefined8 *)0x0) {
          operator_delete(local_560);
        }
        local_560 = (undefined8 *)0x0;
        local_558 = (undefined8 *)0x0;
        local_550 = 0;
        operator_delete(local_578[0]);
      }
      lVar18 = 0;
      if (plVar17 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar18 = *plVar17;
      }
      if (*(undefined4 **)(lVar18 + 0x20) <= puVar13) {
        _invalid_parameter_noinfo();
      }
      puVar13 = puVar13 + 1;
      plVar16 = local_598;
      local_5e8 = puVar13;
    }
    uVar1 = param_1[0x19c];
    local_5a8 = (longlong *)0x0;
    if ((ulonglong)param_1[0x19d] < uVar1) {
      _invalid_parameter_noinfo();
    }
    local_5a8 = (longlong *)param_1[0x199];
    uStack_5a0._0_4_ = (undefined4)uVar1;
    uStack_5a0._4_4_ = (undefined4)(uVar1 >> 0x20);
    uStack_580 = (undefined4)uStack_5a0;
    uStack_57c = uStack_5a0._4_4_;
    uVar2 = param_1[0x19d];
    local_598 = (longlong *)0x0;
    uStack_5a0 = uVar1;
    local_588 = local_5a8;
    if (uVar2 < (ulonglong)param_1[0x19c]) {
      _invalid_parameter_noinfo();
    }
    local_598 = (longlong *)param_1[0x199];
    uStack_590._0_4_ = (undefined4)uVar2;
    uStack_590._4_4_ = (undefined4)(uVar2 >> 0x20);
    uStack_4d0 = (undefined4)uStack_590;
    uStack_4cc = uStack_590._4_4_;
    puVar13 = (undefined4 *)CONCAT44(uStack_57c,uStack_580);
    plVar17 = local_588;
    uStack_590 = uVar2;
    local_4d8 = local_598;
    while( true ) {
      plVar16 = (longlong *)0x0;
      local_5e8 = puVar13;
      if ((plVar17 == (longlong *)0x0) || (plVar17 != local_4d8)) {
        _invalid_parameter_noinfo();
      }
      if (puVar13 == (undefined4 *)CONCAT44(uStack_4cc,uStack_4d0)) break;
      plVar15 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_638 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar15 = plVar16;
      }
      if (plVar17 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar19 = plVar16;
      }
      else {
        plVar19 = (longlong *)*plVar17;
      }
      if ((undefined4 *)plVar19[4] <= puVar13) {
        _invalid_parameter_noinfo();
      }
      puVar14 = (undefined8 *)(**(code **)(*plVar15 + 0x60))(plVar15,*puVar13);
      local_5e0 = puVar14;
      if (puVar14 != (undefined8 *)0x0) {
        local_5a8 = operator_new(8);
        if (local_5a8 != (longlong *)0x0) {
          *local_5a8 = (longlong)local_518;
          plVar16 = local_5a8;
        }
        local_500 = (undefined8 *)0x0;
        local_4f8 = (undefined8 *)0x0;
        local_4f0 = 0;
        local_598 = local_5a8;
        local_518[0] = plVar16;
        FUN_140109210(puVar14,local_518);
        plVar16 = local_500;
        local_5f0 = local_500;
        local_5b8 = (longlong *)0x0;
        if (local_4f8 < local_500) {
          _invalid_parameter_noinfo();
        }
        local_5d8 = local_518[0];
        local_5b8 = local_518[0];
        plVar15 = local_518[0];
        while( true ) {
          puVar3 = local_4f8;
          local_498 = (longlong *)0x0;
          if (local_4f8 < local_500) {
            _invalid_parameter_noinfo();
          }
          local_498 = local_518[0];
          if ((plVar15 == (longlong *)0x0) || (plVar15 != local_518[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar16 == puVar3) break;
          if (plVar15 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar18 = 0;
          }
          else {
            lVar18 = *plVar15;
          }
          if (*(undefined8 **)(lVar18 + 0x20) <= plVar16) {
            _invalid_parameter_noinfo();
          }
          local_5c8 = (longlong *)*plVar16;
          if (local_5c8 != (longlong *)0x0) {
            if (plVar17 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar18 = 0;
            }
            else {
              lVar18 = *plVar17;
            }
            if (*(undefined4 **)(lVar18 + 0x20) <= puVar13) {
              _invalid_parameter_noinfo();
            }
            local_5f4 = *puVar13;
            cVar4 = FUN_140167b70(param_1);
            if (cVar4 != '\0') {
              local_5f4 = FUN_140100c20(puVar14);
            }
            local_5f8 = FUN_1400fda10(puVar14,1,1);
            plVar17 = local_5c8;
            uVar5 = (**(code **)(*local_5c8 + 0x30))(local_5c8,8);
            uVar6 = (**(code **)(*plVar17 + 0x30))(plVar17,7);
            uVar7 = (**(code **)(*plVar17 + 0x30))(plVar17,6);
            uVar8 = (**(code **)(*plVar17 + 0x30))(plVar17,5);
            uVar9 = (**(code **)(*plVar17 + 0x30))(plVar17,4);
            uVar10 = (**(code **)(*plVar17 + 0x30))(plVar17,3);
            uVar11 = (**(code **)(*plVar17 + 0x30))(plVar17,2);
            uVar12 = (**(code **)*local_5c8)();
            local_608 = local_5f8;
            local_638 = uVar10;
            local_630 = uVar9;
            local_628 = uVar8;
            local_620 = uVar7;
            local_618 = uVar6;
            local_610 = uVar5;
            cVar4 = FUN_1403f1a50(local_468,uVar12,local_5f4,uVar11);
            plVar15 = local_5d8;
            plVar16 = local_5f0;
            plVar17 = local_588;
            puVar13 = local_5e8;
            puVar14 = local_5e0;
            param_1 = local_5d0;
            if (cVar4 == '\0') {
              (**(code **)(*local_5d0 + 0x130))(local_5d0,local_468);
              FUN_1403f1b60(local_468);
              local_5f8 = FUN_1400fda10(local_5e0,1,1);
              plVar17 = local_5c8;
              uVar5 = (**(code **)(*local_5c8 + 0x30))(local_5c8,8);
              uVar6 = (**(code **)(*plVar17 + 0x30))(plVar17,7);
              uVar7 = (**(code **)(*plVar17 + 0x30))(plVar17,6);
              uVar8 = (**(code **)(*plVar17 + 0x30))(plVar17,5);
              uVar9 = (**(code **)(*plVar17 + 0x30))(plVar17,4);
              uVar10 = (**(code **)(*plVar17 + 0x30))(plVar17,3);
              uVar11 = (**(code **)(*plVar17 + 0x30))(plVar17,2);
              uVar12 = (**(code **)*local_5c8)();
              local_608 = local_5f8;
              local_638 = uVar10;
              local_630 = uVar9;
              local_628 = uVar8;
              local_620 = uVar7;
              local_618 = uVar6;
              local_610 = uVar5;
              FUN_1403f1a50(local_468,uVar12,local_5f4,uVar11);
              plVar15 = local_5d8;
              plVar16 = local_5f0;
              plVar17 = local_588;
              puVar13 = local_5e8;
              puVar14 = local_5e0;
              param_1 = local_5d0;
            }
          }
          if (plVar15 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar18 = 0;
          }
          else {
            lVar18 = *plVar15;
          }
          if (*(undefined8 **)(lVar18 + 0x20) <= plVar16) {
            _invalid_parameter_noinfo();
          }
          plVar16 = plVar16 + 1;
          local_5f0 = plVar16;
        }
        if (local_500 != (undefined8 *)0x0) {
          operator_delete(local_500);
        }
        local_500 = (undefined8 *)0x0;
        local_4f8 = (undefined8 *)0x0;
        local_4f0 = 0;
        operator_delete(local_518[0]);
      }
      lVar18 = 0;
      if (plVar17 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar18 = *plVar17;
      }
      if (*(undefined4 **)(lVar18 + 0x20) <= puVar13) {
        _invalid_parameter_noinfo();
      }
      puVar13 = puVar13 + 1;
    }
    (**(code **)(*param_1 + 0x130))(param_1,local_468);
    FUN_1403f19c0(local_468);
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1401c3a80  @1401c3a80  [medium:callgraph-r0]  (orig: FUN_1401c3a80)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401c3a80(longlong *param_1,char param_2)

{
  undefined4 *puVar1;
  undefined1 uVar2;
  undefined8 *puVar3;
  char cVar4;
  undefined1 uVar5;
  undefined1 uVar6;
  byte bVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  ulong uVar14;
  longlong *plVar15;
  longlong lVar16;
  char *pcVar17;
  undefined8 *puVar18;
  longlong lVar19;
  ulonglong uVar20;
  longlong *plVar21;
  undefined8 uVar22;
  ulonglong uVar23;
  undefined1 auStack_13d8 [32];
  int *local_13b8;
  undefined4 local_13b0;
  undefined1 local_13a8;
  undefined4 local_13a0;
  undefined4 local_1398;
  undefined4 local_1390;
  undefined1 local_1388;
  undefined4 local_1380;
  char local_1378;
  int local_1374;
  ulonglong local_1370;
  uint local_1368;
  undefined4 local_1364;
  ulonglong local_1360;
  longlong local_1358;
  undefined8 local_1350;
  undefined4 local_1348;
  char local_1344 [16];
  char local_1334 [16];
  char local_1324 [16];
  undefined4 local_1314;
  undefined4 local_1310;
  undefined8 local_1308;
  undefined8 local_1300;
  undefined4 local_12f8;
  undefined1 local_12f4;
  undefined8 local_12f0;
  undefined2 local_12e8;
  undefined1 local_12e6;
  undefined1 local_12e5;
  undefined2 local_12e4;
  undefined2 local_12e2;
  undefined2 local_12e0;
  undefined2 local_12de;
  undefined1 local_12dc;
  undefined4 local_12d8;
  undefined2 local_12d4;
  undefined1 local_12d2;
  undefined4 local_12d0;
  undefined2 local_12cc;
  undefined1 local_12ca;
  undefined4 local_12c8;
  undefined4 local_12c4;
  undefined1 local_12c0;
  undefined4 local_12bc;
  char local_12b8 [36];
  undefined4 local_1294;
  undefined2 local_1290;
  undefined2 local_128e;
  undefined4 local_128c;
  undefined4 local_1288;
  undefined4 local_1284;
  undefined4 local_1280;
  undefined4 local_127c;
  undefined4 local_1278;
  undefined4 local_1274;
  undefined4 local_1270;
  undefined4 local_126c;
  undefined4 local_1268;
  undefined4 local_1264;
  undefined4 local_1260;
  undefined4 local_125c;
  undefined4 local_1258;
  undefined1 local_1254;
  undefined2 local_1252;
  undefined2 local_1250;
  undefined4 local_124c;
  undefined4 local_1248;
  undefined4 local_1244;
  undefined4 local_1240;
  undefined4 local_123c;
  undefined4 local_1238;
  undefined2 local_1234;
  undefined2 local_1232;
  undefined4 local_1230;
  undefined4 local_122c;
  undefined4 local_1228;
  undefined4 local_1224;
  undefined4 local_1220;
  longlong local_1218;
  undefined4 local_1210;
  undefined4 local_120c;
  undefined4 local_1208;
  undefined2 local_1204;
  undefined2 local_1202;
  undefined2 local_1200;
  undefined2 local_11fe;
  undefined4 local_11fc;
  undefined4 local_11f8;
  undefined4 local_11f4;
  undefined4 local_11f0;
  undefined4 local_11ec;
  undefined4 local_11e8;
  undefined1 local_11e4;
  undefined4 local_11e0;
  undefined4 local_11dc;
  uint local_11d8;
  undefined4 local_11d4;
  undefined4 local_11d0;
  undefined1 local_11cc;
  undefined4 local_11c8;
  undefined4 local_11c4;
  undefined1 local_11c0;
  longlong local_11b8;
  longlong local_11b0;
  undefined4 local_11a8;
  undefined4 local_11a4;
  undefined4 local_11a0;
  undefined4 local_119c;
  undefined4 local_1198;
  undefined4 local_1194;
  undefined1 local_1190;
  undefined4 local_118c;
  undefined2 local_1188;
  undefined4 local_1184;
  undefined2 local_1180;
  undefined2 local_117e;
  undefined4 local_117c;
  undefined4 local_1178;
  undefined4 local_1174;
  undefined4 local_1170;
  undefined1 local_116c;
  undefined1 local_116b;
  char local_116a [34];
  undefined1 local_1148 [1072];
  undefined1 local_d18 [1072];
  undefined1 local_8e8 [1072];
  char local_4b8 [127];
  undefined1 local_439;
  undefined4 local_438;
  undefined4 auStack_434 [3];
  undefined1 auStack_428 [4];
  undefined4 auStack_424 [3];
  undefined1 auStack_418 [4];
  undefined4 auStack_414 [247];
  ulonglong local_38;
  undefined8 local_30;
  
  local_30 = 0x1401c3a94;
  local_1350 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_13d8;
  if ((char)param_1[0x259] == '\0') {
    uVar20 = 0;
    *(undefined4 *)((longlong)param_1 + 0xf9c) = 0;
    local_1378 = param_2;
    iVar8 = FUN_14016b120(param_1 + 0x152);
    *(int *)(param_1 + 500) = iVar8;
    if ((param_1[0x151] != 0) && (iVar8 != 0)) {
      plVar15 = (longlong *)**(undefined8 **)(param_1[0x151] + 0x10);
      plVar15 = (longlong *)(**(code **)(*plVar15 + 0x20))(plVar15,&DAT_140951730);
      uVar9 = (**(code **)(*plVar15 + 0x40))(plVar15);
      *(undefined4 *)((longlong)param_1 + 0xf9c) = uVar9;
    }
    plVar15 = (longlong *)FUN_1401181a0();
    lVar16 = *plVar15;
    uVar9 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar16 + 0x88))(plVar15,uVar9);
    lVar16 = FUN_140008520((int)param_1[0x246]);
    if (*(longlong *)(lVar16 + 0x140) == 0) {
      local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x149);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar23 = uVar20;
    }
    else {
      uVar23 = *(ulonglong *)(lVar16 + 0x140);
    }
    (**(code **)(*param_1 + 8))(param_1);
    FUN_14024eae0(uVar23);
    FUN_1403ef2a0(local_d18);
    local_1348 = 0;
    memset(local_1344,0,0x1fc);
    local_1348 = (**(code **)(*param_1 + 8))(param_1);
    if ((param_2 == '\x03') || (param_2 == '\x04')) {
      local_1348 = (**(code **)(*param_1 + 0x38))(param_1);
    }
    lVar16 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
    if (lVar16 != 0) {
      pcVar17 = (char *)(**(code **)(param_1[2] + 0x18))(param_1 + 2);
      strncpy(local_1344,pcVar17,0x10);
    }
    lVar16 = (**(code **)(param_1[2] + 0x28))(param_1 + 2);
    if (lVar16 != 0) {
      pcVar17 = (char *)(**(code **)(param_1[2] + 0x28))(param_1 + 2);
      strncpy(local_1334,pcVar17,0x10);
    }
    lVar16 = (**(code **)(*param_1 + 0x40))(param_1);
    if (lVar16 != 0) {
      pcVar17 = (char *)(**(code **)(*param_1 + 0x40))(param_1);
      strncpy(local_1324,pcVar17,0x10);
    }
    local_1314 = *(undefined4 *)((longlong)param_1 + 0xeac);
    local_1310 = (undefined4)param_1[0x1d6];
    local_1308 = 0;
    local_1300 = 0;
    local_12f8 = 0;
    local_12f4 = *(undefined1 *)((longlong)param_1 + 0xecc);
    local_12f0 = (**(code **)(*param_1 + 0xa0))(param_1);
    local_12e8 = (undefined2)param_1[0x1db];
    local_12e6 = *(undefined1 *)((longlong)param_1 + 0xeda);
    local_12e5 = *(undefined1 *)((longlong)param_1 + 0xedb);
    local_12e4 = *(undefined2 *)((longlong)param_1 + 0xedc);
    local_12e2 = *(undefined2 *)((longlong)param_1 + 0xede);
    local_12e0 = (undefined2)param_1[0x1dc];
    local_12de = *(undefined2 *)((longlong)param_1 + 0xee2);
    local_12dc = *(undefined1 *)((longlong)param_1 + 0xee4);
    local_12d8 = (undefined4)param_1[0x1dd];
    local_12d4 = *(undefined2 *)((longlong)param_1 + 0xeec);
    local_12d2 = *(undefined1 *)((longlong)param_1 + 0xeee);
    local_12d0 = (undefined4)param_1[0x1de];
    local_12cc = *(undefined2 *)((longlong)param_1 + 0xef4);
    local_12ca = *(undefined1 *)((longlong)param_1 + 0xef6);
    local_12c8 = (undefined4)param_1[0x1df];
    local_12c4 = *(undefined4 *)((longlong)param_1 + 0xefc);
    local_12c0 = (undefined1)param_1[0x1e0];
    local_12bc = *(undefined4 *)((longlong)param_1 + 0xf04);
    cVar4 = FUN_140167b70(param_1);
    if (cVar4 == '\0') {
      iVar8 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
      if ((iVar8 != 0) && (lVar16 = FUN_140087ed0(), lVar16 != 0)) {
        plVar15 = (longlong *)FUN_140087ed0();
        lVar16 = *plVar15;
        uVar9 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
        (**(code **)(lVar16 + 0x290))(plVar15,uVar9);
        _snprintf(local_12b8,0x24,"%s");
      }
    }
    else {
      _snprintf(local_12b8,0x24,"%s");
    }
    local_1294 = (undefined4)param_1[0x1e1];
    local_1290 = *(undefined2 *)((longlong)param_1 + 0xf0c);
    local_128e = *(undefined2 *)((longlong)param_1 + 0xf0e);
    local_128c = (undefined4)param_1[0x1e2];
    local_1288 = (undefined4)param_1[0x1e3];
    local_1284 = *(undefined4 *)((longlong)param_1 + 0xf24);
    local_1280 = (undefined4)param_1[0x1e5];
    local_127c = *(undefined4 *)((longlong)param_1 + 0xf2c);
    local_1278 = (undefined4)param_1[0x1e6];
    local_1274 = *(undefined4 *)((longlong)param_1 + 0xf34);
    local_1270 = (undefined4)param_1[0x1e7];
    local_126c = *(undefined4 *)((longlong)param_1 + 0xf3c);
    local_1268 = (undefined4)param_1[0x1e8];
    local_1264 = (undefined4)param_1[0x1ea];
    local_1260 = *(undefined4 *)((longlong)param_1 + 0xf54);
    local_125c = (undefined4)param_1[0x1eb];
    local_1258 = *(undefined4 *)((longlong)param_1 + 0xf5c);
    local_1254 = (undefined1)param_1[0x1f2];
    local_1252 = *(undefined2 *)((longlong)param_1 + 0xf92);
    local_1250 = *(undefined2 *)((longlong)param_1 + 0xf94);
    local_124c = (undefined4)param_1[499];
    local_1248 = 0;
    local_1244 = (undefined4)param_1[0x1f5];
    local_1240 = *(undefined4 *)((longlong)param_1 + 0xfac);
    local_123c = (undefined4)param_1[0x1f6];
    local_1238 = *(undefined4 *)((longlong)param_1 + 0xfb4);
    local_1234 = (undefined2)param_1[0x1f7];
    local_1232 = *(undefined2 *)((longlong)param_1 + 0xfba);
    local_1230 = *(undefined4 *)((longlong)param_1 + 0xfbc);
    local_122c = (undefined4)param_1[0x1f8];
    local_1228 = *(undefined4 *)((longlong)param_1 + 0xfc4);
    local_1224 = (undefined4)param_1[0x1f9];
    local_1220 = *(undefined4 *)((longlong)param_1 + 0xfcc);
    local_1218 = param_1[0x1fa];
    local_1210 = (undefined4)param_1[0x1fb];
    local_120c = *(undefined4 *)((longlong)param_1 + 0xfdc);
    local_1208 = (undefined4)param_1[0x1fc];
    local_1204 = *(undefined2 *)((longlong)param_1 + 0xfe4);
    local_1202 = *(undefined2 *)((longlong)param_1 + 0xfe6);
    local_1200 = (undefined2)param_1[0x1fd];
    local_11fe = *(undefined2 *)((longlong)param_1 + 0xfea);
    local_11fc = *(undefined4 *)((longlong)param_1 + 0xfec);
    local_11f8 = (undefined4)param_1[0x1fe];
    local_11f4 = *(undefined4 *)((longlong)param_1 + 0xff4);
    local_11f0 = (undefined4)param_1[0x1ff];
    local_11ec = *(undefined4 *)((longlong)param_1 + 0xffc);
    local_11e8 = (undefined4)param_1[0x200];
    local_11e4 = *(undefined1 *)((longlong)param_1 + 0x1004);
    local_11e0 = (undefined4)param_1[0x201];
    local_11dc = *(undefined4 *)((longlong)param_1 + 0x100c);
    local_11d8 = (uint)*(byte *)((longlong)param_1 + 0x1024);
    local_11d4 = (undefined4)param_1[0x205];
    local_11d0 = *(undefined4 *)((longlong)param_1 + 0x102c);
    local_11cc = (undefined1)param_1[0x206];
    local_11c8 = 0;
    local_11c4 = (undefined4)param_1[0x207];
    local_11c0 = *(undefined1 *)((longlong)param_1 + 0x103c);
    local_11b8 = param_1[0x208];
    local_11b0 = param_1[0x209];
    local_11a8 = *(undefined4 *)((longlong)param_1 + 0xf9c);
    local_11a4 = (undefined4)param_1[500];
    local_11a0 = (undefined4)param_1[0x21e];
    local_119c = *(undefined4 *)((longlong)param_1 + 0xb2c);
    local_1198 = (undefined4)param_1[0x6e];
    local_1194 = *(undefined4 *)((longlong)param_1 + 0x11ac);
    local_1190 = *(char *)((longlong)param_1 + 0x954) != '\0';
    local_118c = (undefined4)param_1[0x238];
    local_1188 = *(undefined2 *)((longlong)param_1 + 0x105a);
    local_1184 = *(undefined4 *)((longlong)param_1 + 0x105c);
    local_1180 = (undefined2)param_1[0x20c];
    local_117e = (undefined2)param_1[0x32];
    local_117c = (undefined4)param_1[0x171];
    local_1178 = FUN_140373290(param_1 + 0x1cf);
    local_1174 = FUN_140374250(param_1 + 0x1cf);
    local_1170 = FUN_1403732c0(param_1 + 0x1cf);
    local_116c = FUN_140167cb0(param_1);
    local_116b = FUN_140167d60(param_1);
    pcVar17 = (char *)FUN_140167bb0(param_1);
    tq::StrCopy(local_116a,pcVar17,0x20);
    cVar4 = FUN_1403ef350(local_d18,0,&local_1348);
    if (cVar4 == '\0') {
      log_InlineLogERROR("msgBaseUserInfo.Create falil!");
      FUN_1403ef2f0(local_d18);
    }
    else {
      (**(code **)(*param_1 + 0x130))(param_1,local_d18);
      FUN_1403f4080(local_8e8);
      cVar4 = FUN_1403f4130(local_8e8,0,*(undefined1 *)((longlong)param_1 + 0x51c));
      if (cVar4 == '\0') {
        local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x645a);
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_1403f40d0(local_8e8);
        FUN_1403ef2f0(local_d18);
      }
      else {
        (**(code **)(*param_1 + 0x130))(param_1,local_8e8);
        lVar16 = FUN_140008520((int)param_1[0x246]);
        if (*(longlong *)(lVar16 + 0xf8) == 0) {
          local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x142);
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar23 = uVar20;
        }
        else {
          uVar23 = *(ulonglong *)(lVar16 + 0xf8);
        }
        FUN_1401585b0(uVar23,param_1);
        lVar16 = FUN_140008520((int)param_1[0x246]);
        if (*(longlong *)(lVar16 + 0x100) == 0) {
          local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x144);
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar23 = uVar20;
        }
        else {
          uVar23 = *(ulonglong *)(lVar16 + 0x100);
        }
        uVar9 = (**(code **)(*param_1 + 8))(param_1);
        FUN_1402f1b90(uVar23,uVar9);
        lVar16 = FUN_140008520((int)param_1[0x246]);
        if (*(longlong *)(lVar16 + 0x1a8) == 0) {
          local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x159);
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar23 = uVar20;
        }
        else {
          uVar23 = *(ulonglong *)(lVar16 + 0x1a8);
        }
        FUN_1402e6e00(uVar23,param_1);
        lVar16 = FUN_140008520((int)param_1[0x246]);
        if (*(longlong *)(lVar16 + 0x1c0) == 0) {
          local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x15c);
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar23 = uVar20;
        }
        else {
          uVar23 = *(ulonglong *)(lVar16 + 0x1c0);
        }
        FUN_1401eb340(uVar23,param_1);
        lVar16 = FUN_140008520((int)param_1[0x246]);
        if (*(longlong *)(lVar16 + 0x1c0) == 0) {
          local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x15c);
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar23 = uVar20;
        }
        else {
          uVar23 = *(ulonglong *)(lVar16 + 0x1c0);
        }
        FUN_1401e74a0(uVar23,param_1);
        lVar16 = FUN_140008520((int)param_1[0x246]);
        if (*(longlong *)(lVar16 + 0x1d0) == 0) {
          local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x15e);
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar23 = uVar20;
        }
        else {
          uVar23 = *(ulonglong *)(lVar16 + 0x1d0);
        }
        FUN_1401f6500(uVar23);
        FUN_14019a540(param_1);
        FUN_14019aae0(param_1);
        local_438._0_1_ = 0;
        memset((void *)((longlong)&local_438 + 1),0,0x3ff);
        local_1374 = 0;
        puVar18 = (undefined8 *)FUN_1401181a0();
        puVar3 = (undefined8 *)*puVar18;
        uVar9 = (**(code **)(*param_1 + 8))(param_1);
        local_13b8 = &local_1374;
        cVar4 = (*(code *)*puVar3)(puVar18,uVar9,&local_438,0x400);
        if (cVar4 != '\0') {
          FUN_1403f1ea0(local_1148);
          FUN_1403f1f50(local_1148,0);
          FUN_1403f22e0(local_1148,param_1 + 0x1ec);
          FUN_1403f2300(local_1148,param_1 + 0x1ef);
          local_1368 = 0;
          while (iVar8 = (int)uVar20, iVar8 < local_1374) {
            lVar19 = (longlong)iVar8;
            lVar16 = lVar19 * 0x28;
            puVar1 = &local_438 + lVar19 * 10;
            if (puVar1 != (undefined4 *)0x0) {
              local_1380 = auStack_414[lVar19 * 10];
              local_1388 = auStack_418[lVar16];
              local_1390 = auStack_424[lVar19 * 10 + 2];
              local_1398 = auStack_424[lVar19 * 10 + 1];
              local_13a0 = *(undefined4 *)(auStack_428 + lVar16 + 4);
              local_13a8 = auStack_428[lVar16 + 1];
              local_13b0 = CONCAT31(local_13b0._1_3_,auStack_428[lVar16]);
              local_13b8 = (int *)CONCAT44(local_13b8._4_4_,auStack_434[lVar19 * 10 + 2]);
              iVar10 = FUN_1403f1f80(local_1148,*puVar1,auStack_434[lVar19 * 10],
                                     auStack_434[lVar19 * 10 + 1]);
              if (iVar10 == 0) {
                (**(code **)(*param_1 + 0x130))(param_1,local_1148);
                FUN_1403f20e0(local_1148);
                local_1380 = auStack_414[lVar19 * 10];
                local_1388 = auStack_418[lVar16];
                local_1390 = auStack_424[lVar19 * 10 + 2];
                local_1398 = auStack_424[lVar19 * 10 + 1];
                local_13a0 = *(undefined4 *)(auStack_428 + lVar16 + 4);
                local_13a8 = auStack_428[lVar16 + 1];
                local_13b0 = CONCAT31(local_13b0._1_3_,auStack_428[lVar16]);
                local_13b8 = (int *)CONCAT44(local_13b8._4_4_,auStack_434[lVar19 * 10 + 2]);
                FUN_1403f1f80(local_1148,*puVar1,auStack_434[lVar19 * 10],
                              auStack_434[lVar19 * 10 + 1]);
              }
            }
            local_1368 = iVar8 + 1;
            uVar20 = (ulonglong)local_1368;
          }
          (**(code **)(*param_1 + 0x130))(param_1,local_1148);
          FUN_1403f1ef0(local_1148);
        }
        uVar20 = (**(code **)(*(longlong *)param_1[0x222] + 0x10))();
        local_1360 = uVar20;
        if (uVar20 != 0) {
          FUN_1403f0130(local_1148);
          uVar9 = (**(code **)(*param_1 + 8))(param_1);
          FUN_1403f01e0(local_1148,uVar9,0);
          for (local_1370 = 0; local_1370 < uVar20; local_1370 = local_1370 + 1) {
            lVar16 = (**(code **)(*(longlong *)param_1[0x222] + 0x18))();
            local_1358 = lVar16;
            if (lVar16 != 0) {
              uVar2 = *(undefined1 *)(lVar16 + 0x1a);
              uVar5 = FUN_14039d8e0(lVar16);
              uVar6 = FUN_14039d7e0(lVar16);
              uVar9 = FUN_14039d860(lVar16);
              uVar11 = FUN_14039d760(lVar16);
              uVar12 = FUN_14039d9f0(lVar16);
              uVar13 = FUN_14039d9d0(local_1358);
              local_13a0 = CONCAT31(local_13a0._1_3_,uVar2);
              local_13b0 = CONCAT31(local_13b0._1_3_,uVar6);
              local_13b8 = (int *)CONCAT44(local_13b8._4_4_,uVar9);
              local_13a8 = uVar5;
              cVar4 = FUN_1403f0220(local_1148,uVar13,uVar12,uVar11);
              if (cVar4 == '\0') {
                (**(code **)(*param_1 + 0x130))(param_1,local_1148);
                uVar9 = (**(code **)(*param_1 + 8))(param_1);
                FUN_1403f01e0(local_1148,uVar9);
                local_1370 = local_1370 - 1;
              }
            }
            uVar20 = local_1360;
          }
          iVar8 = FUN_1403f02f0(local_1148);
          if (iVar8 != 0) {
            (**(code **)(*param_1 + 0x130))(param_1,local_1148);
          }
          FUN_1403f0180(local_1148);
        }
        plVar15 = (longlong *)0x0;
        lVar16 = FUN_140008520((int)param_1[0x246]);
        if (*(longlong *)(lVar16 + 0x100) == 0) {
          local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x144);
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar21 = plVar15;
        }
        else {
          plVar21 = *(longlong **)(lVar16 + 0x100);
        }
        uVar9 = (**(code **)(*param_1 + 8))(param_1);
        FUN_1402f28d0(plVar21,uVar9,0);
        FUN_140167210(param_1);
        FUN_14017acd0(param_1,1);
        lVar16 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
        if (lVar16 == 0) {
          FUN_1403f40d0(local_8e8);
          FUN_1403ef2f0(local_d18);
        }
        else {
          uVar9 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
          uVar11 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
          cVar4 = FUN_1402c3cc0(lVar16,uVar11,uVar9);
          if (cVar4 != '\0') {
            plVar21 = *(longlong **)(*(longlong *)(lVar16 + 0x58) + 8);
            plVar21 = (longlong *)(**(code **)(*plVar21 + 0x10))(plVar21,4);
            bVar7 = (**(code **)(*plVar21 + 0x58))(plVar21);
            if ((bVar7 >> 2 & 1) == 0) {
              uVar9 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
              uVar11 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
              uVar12 = (**(code **)(param_1[2] + 0x168))(param_1 + 2);
              local_13b8 = (int *)CONCAT44(local_13b8._4_4_,1);
              FUN_1401732e0(param_1,uVar12,uVar11,uVar9);
            }
          }
          local_1364 = (**(code **)(*param_1 + 8))(param_1);
          lVar19 = FUN_140008520((int)param_1[0x246]);
          if (*(longlong *)(lVar19 + 0x80) == 0) {
            local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x140);
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar21 = plVar15;
          }
          else {
            plVar21 = *(longlong **)(lVar19 + 0x80);
          }
          local_13b8 = &local_1364;
          (**(code **)(*plVar21 + 0x50))(plVar21,8,0x15f9d,0xea65);
          FUN_1401bfb90(param_1,0,0);
          uVar22 = FUN_140008520((int)param_1[0x246]);
          plVar21 = (longlong *)FUN_1400876b0(uVar22);
          lVar19 = (**(code **)(*plVar21 + 0x10))(plVar21,0xbcf,1);
          param_1[0x220] = lVar19;
          if (lVar19 == 0) {
            log_InlineLogERROR("Cross wait map(%u) is not found!");
            param_1[0x220] = lVar16;
          }
          if (local_1378 == '\x03') {
            FUN_14017bb90(param_1,3);
            *(undefined4 *)((longlong)param_1 + 0x135c) = 0;
            *(undefined4 *)(param_1 + 0x26c) = 0;
            *(undefined4 *)((longlong)param_1 + 0x1364) = 0;
            *(undefined4 *)(param_1 + 0x26d) = 0;
            FUN_140361e70(local_1148);
            uVar9 = (**(code **)(*param_1 + 0x38))(param_1);
            cVar4 = FUN_140361f20(local_1148,uVar9,2);
            if (cVar4 != '\0') {
              (**(code **)(*param_1 + 0x130))(param_1,local_1148);
            }
            FUN_140361ec0(local_1148);
          }
          else if (local_1378 == '\x04') {
            FUN_14017bb90(param_1,4);
            *(undefined4 *)((longlong)param_1 + 0x135c) = 0;
            *(undefined4 *)(param_1 + 0x26c) = 0;
            *(undefined4 *)((longlong)param_1 + 0x1364) = 0;
            *(undefined4 *)(param_1 + 0x26d) = 0;
            FUN_140361e70(local_1148);
            uVar9 = (**(code **)(*param_1 + 0x38))(param_1);
            cVar4 = FUN_140361f20(local_1148,uVar9,4);
            if (cVar4 != '\0') {
              (**(code **)(*param_1 + 0x130))(param_1,local_1148);
            }
            FUN_140361ec0(local_1148);
          }
          else {
            memset(local_4b8,0,0x80);
            uVar9 = *(undefined4 *)((longlong)param_1 + 0x1304);
            uVar11 = (**(code **)(*param_1 + 8))(param_1);
            local_13b0 = uVar9;
            local_13b8._0_4_ = uVar11;
            _snprintf(local_4b8,0x7f,"%u %u %u");
            local_439 = 0;
            lVar16 = FUN_140008520((int)param_1[0x246]);
            if (*(longlong *)(lVar16 + 0x80) == 0) {
              local_13b8 = (int *)CONCAT44(local_13b8._4_4_,0x140);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              plVar15 = *(longlong **)(lVar16 + 0x80);
            }
            local_13b8 = (int *)local_4b8;
            (**(code **)(*plVar15 + 0x50))(plVar15,6,0x11171,0x80);
          }
          *(undefined1 *)(param_1 + 0x259) = 1;
          *(undefined4 *)((longlong)param_1 + 0x12d4) = 10;
          uVar14 = tq::TimeGet(0);
          *(uint *)(param_1 + 0x25b) = uVar14 / 1000;
          FUN_1403f40d0(local_8e8);
          FUN_1403ef2f0(local_d18);
        }
      }
    }
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1401e74a0  @1401e74a0  [medium:callgraph-r1]  (orig: FUN_1401e74a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401e74a0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined1 uVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  longlong lVar12;
  longlong lVar13;
  longlong lVar14;
  undefined1 auStack_528 [32];
  undefined4 local_508;
  undefined8 local_500;
  longlong local_4f8;
  undefined4 *local_4f0;
  undefined4 *local_4e8;
  undefined4 local_4d8;
  undefined1 local_4d4;
  undefined4 local_4c8;
  undefined1 uStack_4c4;
  undefined4 local_4c0;
  undefined4 local_4bc;
  longlong *local_4b8;
  longlong local_4b0;
  longlong local_4a8;
  undefined8 *local_4a0;
  longlong local_498;
  undefined8 local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_488 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_528;
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar11 = (undefined8 *)(*(undefined8 **)(param_1 + 0xc0))[1];
    cVar4 = *(char *)((longlong)puVar11 + 0x29);
    puVar2 = *(undefined8 **)(param_1 + 0xc0);
    while (cVar4 == '\0') {
      if (*(uint *)(puVar11 + 3) < uVar5) {
        puVar9 = (undefined8 *)puVar11[2];
        puVar11 = puVar2;
      }
      else {
        puVar9 = (undefined8 *)*puVar11;
      }
      puVar2 = puVar11;
      puVar11 = puVar9;
      cVar4 = *(char *)((longlong)puVar9 + 0x29);
    }
    local_4a0 = puVar2;
    local_4a8 = *(longlong *)(param_1 + 0x90);
    puVar11 = *(undefined8 **)(param_1 + 0xc0);
    if (*(longlong *)(param_1 + 0x90) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar2 == puVar11) || (uVar5 < *(uint *)(puVar2 + 3))) {
      local_490 = *(undefined8 *)(param_1 + 0xc0);
      local_498 = *(longlong *)(param_1 + 0x90);
      plVar10 = &local_498;
    }
    else {
      plVar10 = &local_4a8;
    }
    plVar1 = (longlong *)*plVar10;
    local_4b0 = plVar10[1];
    lVar12 = *(longlong *)(param_1 + 0xc0);
    local_4b8 = plVar1;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x90))) {
      _invalid_parameter_noinfo();
    }
    lVar14 = local_4b0;
    if (local_4b0 != lVar12) {
      lVar12 = 0;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = lVar12;
      }
      else {
        lVar13 = *plVar1;
      }
      if (lVar14 == *(longlong *)(lVar13 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar14 = *(longlong *)(lVar14 + 0x20);
      if (lVar14 != 0) {
        uVar6 = FUN_1403fda90(lVar14);
        uVar8 = FUN_1403fd8b0(lVar14,3);
        local_4c0 = FUN_1403fd5d0(lVar14,5);
        local_4bc = FUN_1403fd5d0(lVar14,6);
        local_4a8 = *(longlong *)(param_1 + 0xc);
        local_4c8 = 0;
        uStack_4c4 = 0;
        local_4d8 = (**(code **)(*param_2 + 8))(param_2);
        FUN_1401e34f0(param_1 + 0xd0,&local_4b8,&local_4d8);
        plVar10 = local_4b8;
        lVar14 = *(longlong *)(param_1 + 0x100);
        if ((local_4b8 == (longlong *)0x0) || (local_4b8 != *(longlong **)(param_1 + 0xd0))) {
          _invalid_parameter_noinfo();
        }
        lVar13 = local_4b0;
        if (local_4b0 != lVar14) {
          if (plVar10 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar14 = lVar12;
          }
          else {
            lVar14 = *plVar10;
          }
          if (lVar13 == *(longlong *)(lVar14 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar14 = *(longlong *)(lVar13 + 0x20);
          if (lVar14 != 0) {
            uVar3 = FUN_1403fe830(lVar14,2);
            local_4c8 = CONCAT31(local_4c8._1_3_,uVar3);
            uVar7 = FUN_1403fe980(lVar14,3);
            local_4c8._1_3_ = (undefined3)uVar7;
            uStack_4c4 = (undefined1)((uint)uVar7 >> 0x18);
          }
        }
        local_4d8 = (**(code **)(*param_2 + 8))(param_2);
        FUN_1401e3b30(param_1 + 0x150,&local_4b8,&local_4d8);
        plVar10 = local_4b8;
        lVar14 = *(longlong *)(param_1 + 0x180);
        if ((local_4b8 == (longlong *)0x0) || (local_4b8 != *(longlong **)(param_1 + 0x150))) {
          _invalid_parameter_noinfo();
        }
        lVar13 = local_4b0;
        if (local_4b0 != lVar14) {
          if (plVar10 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar12 = *plVar10;
          }
          if (lVar13 == *(longlong *)(lVar12 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar12 = *(longlong *)(lVar13 + 0x20);
          if (lVar12 != 0) {
            local_4d8 = local_4c8;
            local_4d4 = uStack_4c4;
            local_4f0 = &local_4d8;
            local_4f8 = local_4a8;
            local_500 = CONCAT44(local_500._4_4_,uVar6);
            local_508 = local_4bc;
            FUN_1403ff280(lVar12,param_2,uVar8,(undefined1)local_4c0);
            return;
          }
        }
        FUN_140401a90(local_478);
        local_4d8 = local_4c8;
        local_4d4 = uStack_4c4;
        local_500 = FUN_1401669e0(param_2);
        local_4e8 = &local_4d8;
        local_4f0 = (undefined4 *)local_4a8;
        local_4f8 = CONCAT44(local_4f8._4_4_,uVar6);
        local_508 = local_4bc;
        cVar4 = FUN_140401b50(local_478,0,uVar8,(undefined1)local_4c0);
        if (cVar4 == '\0') {
          FUN_140401ae0(local_478);
        }
        else {
          (**(code **)(*param_2 + 0x130))(param_2,local_478);
          FUN_140401ae0(local_478);
        }
      }
    }
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1401eb340  @1401eb340  [medium:callgraph-r1]  (orig: FUN_1401eb340)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401eb340(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  undefined1 auStack_4f8 [32];
  longlong local_4d8;
  undefined8 uStack_4d0;
  longlong *local_4c8;
  longlong lStack_4c0;
  undefined8 local_4b8;
  undefined8 *local_4b0;
  longlong *local_4a8 [6];
  undefined8 *local_478;
  undefined8 local_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  if (param_2 != (longlong *)0x0) {
    local_468 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
    uVar4 = (**(code **)(*param_2 + 8))(param_2);
    puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x240))[1];
    cVar3 = *(char *)((longlong)puVar8 + 0x61);
    puVar2 = *(undefined8 **)(param_1 + 0x240);
    while (cVar3 == '\0') {
      if (*(uint *)(puVar8 + 3) < uVar4) {
        puVar6 = (undefined8 *)puVar8[2];
        puVar8 = puVar2;
      }
      else {
        puVar6 = (undefined8 *)*puVar8;
      }
      puVar2 = puVar8;
      puVar8 = puVar6;
      cVar3 = *(char *)((longlong)puVar6 + 0x61);
    }
    local_4b0 = puVar2;
    local_4b8 = *(longlong *)(param_1 + 0x210);
    puVar8 = *(undefined8 **)(param_1 + 0x240);
    if (*(longlong *)(param_1 + 0x210) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar2 == puVar8) || (uVar4 < *(uint *)(puVar2 + 3))) {
      uStack_4d0 = *(undefined8 *)(param_1 + 0x240);
      local_4d8 = *(longlong *)(param_1 + 0x210);
      plVar7 = &local_4d8;
    }
    else {
      plVar7 = &local_4b8;
    }
    plVar1 = (longlong *)*plVar7;
    local_4c8 = plVar1;
    lStack_4c0 = plVar7[1];
    lVar9 = *(longlong *)(param_1 + 0x240);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x210))) {
      _invalid_parameter_noinfo();
    }
    lVar11 = lStack_4c0;
    if (lStack_4c0 != lVar9) {
      FUN_140402260(local_458);
      cVar3 = FUN_140402310(local_458);
      if (cVar3 == '\0') {
        FUN_1404022b0(local_458);
      }
      else {
        lVar9 = 0;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = lVar9;
        }
        else {
          lVar10 = *plVar1;
        }
        if (lVar11 == *(longlong *)(lVar10 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_1401e8c10(local_4a8,lVar11 + 0x20);
        plVar7 = local_4a8[0];
        puVar8 = (undefined8 *)*local_478;
        while( true ) {
          puVar2 = local_478;
          if ((plVar7 == (longlong *)0x0) || (plVar7 != local_4a8[0])) {
            _invalid_parameter_noinfo();
          }
          if (puVar8 == puVar2) break;
          if (plVar7 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar9;
          }
          else {
            lVar11 = *plVar7;
          }
          if (puVar8 == *(undefined8 **)(lVar11 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          local_4b8 = CONCAT71(local_4b8._1_7_,*(undefined1 *)(puVar8 + 3));
          if (plVar7 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar9;
          }
          else {
            lVar11 = *plVar7;
          }
          if (puVar8 == *(undefined8 **)(lVar11 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          local_4b8 = CONCAT44(*(undefined4 *)((longlong)puVar8 + 0x1c),(undefined4)local_4b8);
          lVar11 = local_4b8;
          cVar3 = FUN_140402370(local_458,local_4b8);
          if (cVar3 == '\0') {
            (**(code **)(*param_2 + 0x130))(param_2,local_458);
            FUN_140402420(local_458);
            FUN_140402370(local_458,lVar11);
          }
          if (plVar7 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)puVar8 + 0x21) == '\0') {
            puVar2 = (undefined8 *)puVar8[2];
            if (*(char *)((longlong)puVar2 + 0x21) == '\0') {
              cVar3 = *(char *)((longlong)*puVar2 + 0x21);
              puVar8 = puVar2;
              puVar2 = (undefined8 *)*puVar2;
              while (cVar3 == '\0') {
                cVar3 = *(char *)((longlong)*puVar2 + 0x21);
                puVar8 = puVar2;
                puVar2 = (undefined8 *)*puVar2;
              }
            }
            else {
              cVar3 = *(char *)((longlong)puVar8[1] + 0x21);
              puVar6 = (undefined8 *)puVar8[1];
              puVar2 = puVar8;
              while ((puVar8 = puVar6, cVar3 == '\0' && (puVar2 == (undefined8 *)puVar8[2]))) {
                cVar3 = *(char *)((longlong)puVar8[1] + 0x21);
                puVar6 = (undefined8 *)puVar8[1];
                puVar2 = puVar8;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
        }
        iVar5 = FUN_140402480(local_458);
        if (iVar5 != 0) {
          (**(code **)(*param_2 + 0x130))(param_2,local_458);
        }
        uStack_4d0 = *local_478;
        FUN_1401dff20(local_4a8,&local_4b8,&local_4d8,&local_4c8);
        operator_delete(local_478);
        local_478 = (undefined8 *)0x0;
        local_470 = 0;
        operator_delete(local_4a8[0]);
        FUN_1404022b0(local_458);
      }
    }
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1401f6500  @1401f6500  [medium:callgraph-r1]  (orig: FUN_1401f6500)
void FUN_1401f6500(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  undefined4 local_res18 [4];
  longlong *local_48;
  longlong lStack_40;
  longlong *local_38 [2];
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_res18[0] = (**(code **)(*param_2 + 8))(param_2);
    plVar1 = (longlong *)(param_1 + 0x18);
    FUN_1401f5550(plVar1,&local_48,local_res18);
    lVar2 = *(longlong *)(param_1 + 0x48);
    lVar3 = 0;
    local_38[0] = (longlong *)*plVar1;
    if ((local_48 == (longlong *)0x0) || (local_48 != local_38[0])) {
      _invalid_parameter_noinfo();
    }
    if (lStack_40 == lVar2) {
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogERROR("CInnerStrengthMgr::SendUserInfoToCross not found user data, idUser:%u.");
    }
    else {
      if (local_48 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar2 = lVar3;
      }
      else {
        lVar2 = *local_48;
      }
      if (lStack_40 == *(longlong *)(lVar2 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong *)(lStack_40 + 0x20) == 0) {
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR(
                          "CInnerStrengthMgr::SendInnerStrengthInfoToCross CInnerStrengthPlayer pointer is null, idUser:%u."
                          );
        FUN_1401f5190(plVar1,local_38,&local_48);
      }
      else {
        if (local_48 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar2 = lVar3;
        }
        else {
          lVar2 = *local_48;
        }
        if (lStack_40 == *(longlong *)(lVar2 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_140404490(*(undefined8 *)(lStack_40 + 0x20),param_2);
        if (local_48 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar3 = *local_48;
        }
        if (lStack_40 == *(longlong *)(lVar3 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_1404048f0(*(undefined8 *)(lStack_40 + 0x20),param_2);
      }
    }
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_14024eae0  @14024eae0  [medium:callgraph-r1]  (orig: FUN_14024eae0)
undefined1 FUN_14024eae0(void)

{
  longlong lVar1;
  
  lVar1 = FUN_14024e590();
  if (lVar1 == 0) {
    return 0;
  }
  FUN_14041d1e0(lVar1);
  return 1;
}

// ==== CCrossMsgLoadUserInfo::ctor_or_dtor  @1402b5280  [high:vtable-assign]  (orig: FUN_1402b5280)
undefined8 * FUN_1402b5280(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLoadUserInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLoadUserInfo::ctor_or_dtor  @1402b52d0  [high:vtable-assign]  (orig: FUN_1402b52d0)
void FUN_1402b52d0(undefined8 *param_1)

{
  *param_1 = CCrossMsgLoadUserInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLoadUserInfo::vfunc_1  @1402b5300  [high:rtti-vtable]  (orig: FUN_1402b5300)
undefined8 FUN_1402b5300(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLoadUserInfo::ctor_or_dtor  @1402b5370  [high:vtable-assign]  (orig: FUN_1402b5370)
undefined8 * FUN_1402b5370(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLoadUserInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgLoadUserInfo::vfunc_3  @1402b53c0  [high:rtti-vtable]  (orig: FUN_1402b53c0)
void FUN_1402b53c0(longlong param_1)

{
  short sVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  
  if (*(short **)(param_1 + 0x428) != (short *)0x0) {
    sVar1 = **(short **)(param_1 + 0x428);
    if (sVar1 == 0) {
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar3 = (longlong *)FUN_140087650(uVar2);
      lVar4 = (**(code **)(*plVar3 + 0x98))
                        (plVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (lVar4 != 0) {
        FUN_1401c3a80(lVar4,0);
      }
    }
    else {
      if (sVar1 == 2) {
        uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar3 = (longlong *)FUN_140087650(uVar2);
        lVar4 = (**(code **)(*plVar3 + 0xa0))
                          (plVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                           *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
        if (lVar4 != 0) {
          FUN_1401c3a80(lVar4,4);
          return;
        }
LAB_1402b5435:
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
      if (sVar1 == 3) {
        uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar3 = (longlong *)FUN_140087650(uVar2);
        lVar4 = (**(code **)(*plVar3 + 0x98))
                          (plVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        if (lVar4 != 0) {
          FUN_1401c3a80(lVar4,1);
          return;
        }
      }
      else if (sVar1 == 4) {
        uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar3 = (longlong *)FUN_140087650(uVar2);
        lVar4 = (**(code **)(*plVar3 + 0xa0))
                          (plVar3,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c))
        ;
        if (lVar4 != 0) {
          FUN_1401c3a80(lVar4,3);
          return;
        }
        goto LAB_1402b5435;
      }
    }
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1402e6e00  @1402e6e00  [medium:callgraph-r1]  (orig: FUN_1402e6e00)
void FUN_1402e6e00(longlong param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  if (param_2 != (longlong *)0x0) {
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar1 = *(char *)((longlong)puVar8 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x38);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar8 + 3) < uVar5) {
        puVar6 = (undefined8 *)puVar8[2];
        puVar8 = puVar3;
      }
      else {
        puVar6 = (undefined8 *)*puVar8;
      }
      puVar3 = puVar8;
      puVar8 = puVar6;
      cVar1 = *(char *)((longlong)puVar6 + 0x29);
    }
    puVar8 = *(undefined8 **)(param_1 + 0x38);
    local_30 = puVar3;
    local_38 = *(longlong *)(param_1 + 8);
    if (*(longlong *)(param_1 + 8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar8) || (uVar5 < *(uint *)(puVar3 + 3))) {
      plVar7 = &local_28;
      local_20 = *(undefined8 *)(param_1 + 0x38);
      local_28 = *(longlong *)(param_1 + 8);
    }
    else {
      plVar7 = &local_38;
    }
    plVar2 = (longlong *)*plVar7;
    lVar9 = *(longlong *)(param_1 + 0x38);
    local_18 = plVar2;
    local_10 = plVar7[1];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    lVar4 = local_10;
    if (local_10 != lVar9) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)(lVar4 + 0x20);
      if (lVar9 != 0) {
        FUN_140479080(lVar9,param_2);
      }
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1402f1b90  @1402f1b90  [medium:callgraph-r1]  (orig: FUN_1402f1b90)
void FUN_1402f1b90(void)

{
  longlong lVar1;
  
  lVar1 = FUN_1402f1610();
  if (lVar1 != 0) {
    FUN_14048a7b0(lVar1);
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1403af2a0  @1403af2a0  [medium:callgraph-r2]  (orig: FUN_1403af2a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403af2a0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_2 != (longlong *)0x0) {
    local_478 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
    iVar5 = (**(code **)(*param_2 + 8))(param_2);
    if (iVar5 == *(int *)(param_1 + 0x4c)) {
      FUN_14045da90(local_468);
      cVar4 = FUN_14045db40(local_468);
      if (cVar4 == '\0') {
        FUN_14045dae0(local_468);
      }
      else {
        plVar8 = (longlong *)**(undefined8 **)(param_1 + 0x38);
        plVar1 = *(longlong **)(param_1 + 8);
        while( true ) {
          plVar2 = *(longlong **)(param_1 + 0x38);
          if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          if (plVar8 == plVar2) break;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar9 = 0;
          }
          else {
            lVar9 = *plVar1;
          }
          if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          plVar2 = (longlong *)plVar8[4];
          if (plVar2 != (longlong *)0x0) {
            uVar6 = (**(code **)(*plVar2 + 0x10))(plVar2,3);
            uVar7 = (**(code **)(*plVar2 + 0x10))(plVar2,2);
            cVar4 = FUN_14045db70(local_468,uVar7,uVar6);
            if (cVar4 == '\0') {
              (**(code **)(*param_2 + 0x130))(param_2,local_468);
              FUN_14045db40(local_468);
              uVar6 = (**(code **)(*plVar2 + 0x10))(plVar2,3);
              uVar7 = (**(code **)(*plVar2 + 0x10))(plVar2,2);
              FUN_14045db70(local_468,uVar7,uVar6);
            }
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
            plVar2 = (longlong *)plVar8[2];
            if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
              cVar4 = *(char *)(*plVar2 + 0x29);
              plVar8 = plVar2;
              plVar2 = (longlong *)*plVar2;
              while (cVar4 == '\0') {
                cVar4 = *(char *)(*plVar2 + 0x29);
                plVar8 = plVar2;
                plVar2 = (longlong *)*plVar2;
              }
            }
            else {
              cVar4 = *(char *)(plVar8[1] + 0x29);
              plVar3 = (longlong *)plVar8[1];
              plVar2 = plVar8;
              while ((plVar8 = plVar3, cVar4 == '\0' && (plVar2 == (longlong *)plVar8[2]))) {
                cVar4 = *(char *)(plVar8[1] + 0x29);
                plVar3 = (longlong *)plVar8[1];
                plVar2 = plVar8;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
        }
        iVar5 = FUN_14045db60(local_468);
        if (iVar5 != 0) {
          (**(code **)(*param_2 + 0x130))(param_2,local_468);
        }
        FUN_14045dae0(local_468);
      }
    }
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1403ef5a0  @1403ef5a0  [medium:callgraph-r2]  (orig: FUN_1403ef5a0)
undefined8 FUN_1403ef5a0(longlong param_1,undefined2 param_2,undefined4 param_3)

{
  undefined2 *puVar1;
  
  *(undefined4 *)(param_1 + 8) = 0x9c5f;
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = 0;
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_1403ef5e0  @1403ef5e0  [medium:callgraph-r2]  (orig: FUN_1403ef5e0)
undefined8 FUN_1403ef5e0(longlong param_1,void *param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *(int *)(*(longlong *)(param_1 + 0x428) + 8);
  if (0x3fb < (longlong)(iVar2 + 1) * 0x40 + 0x4cU) {
    return 0;
  }
  memcpy((void *)((longlong)iVar2 * 0x40 + 0xc + *(longlong *)(param_1 + 0x428)),param_2,0x40);
  piVar1 = (int *)(*(longlong *)(param_1 + 0x428) + 8);
  *piVar1 = *piVar1 + 1;
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x40;
  return 1;
}

// ==== CCrossMsgLoadUserInfo::helper_1403f02f0  @1403f02f0  [medium:callgraph-r1]  (orig: FUN_1403f02f0)
undefined4 FUN_1403f02f0(longlong param_1)

{
  return *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8);
}

// ==== CCrossMsgLoadUserInfo::helper_1403f17a0  @1403f17a0  [medium:callgraph-r2]  (orig: FUN_1403f17a0)
undefined8 FUN_1403f17a0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 8) = 0x9c45;
  *(undefined4 *)(param_1 + 0xc) = 0x88;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 4) = 0;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_1403f17d0  @1403f17d0  [medium:callgraph-r2]  (orig: FUN_1403f17d0)
undefined8 FUN_1403f17d0(longlong param_1,void *param_2)

{
  int *piVar1;
  
  if (0x3fb < (longlong)*(int *)(param_1 + 0xc) + 0x88U) {
    return 0;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x80;
  memcpy((void *)((longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 0x80 + 8 +
                 *(longlong *)(param_1 + 0x428)),param_2,0x80);
  piVar1 = (int *)(*(longlong *)(param_1 + 0x428) + 4);
  *piVar1 = *piVar1 + 1;
  return 1;
}

// ==== CCrossMsgLoadUserInfo::helper_1403f1830  @1403f1830  [medium:callgraph-r2]  (orig: FUN_1403f1830)
void FUN_1403f1830(longlong param_1)

{
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x88;
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1403f1a20  @1403f1a20  [medium:callgraph-r2]  (orig: FUN_1403f1a20)
undefined8 FUN_1403f1a20(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 8) = 0x9c4b;
  *(undefined4 *)(param_1 + 0xc) = 8;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 4) = 0;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_1403f1a50  @1403f1a50  [medium:callgraph-r2]  (orig: FUN_1403f1a50)
ulonglong FUN_1403f1a50(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                       undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  int *piVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  lVar3 = (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4);
  uVar2 = lVar3 * 0x28 + 0x30;
  if (0x3fb < uVar2) {
    return uVar2 & 0xffffffffffffff00;
  }
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8 + lVar3 * 0x28) = param_2;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0xc +
   (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_3;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x10 +
   (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_4;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x14 +
   (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_5;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x18 +
   (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_6;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x1c +
   (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_7;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x20 +
   (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_8;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x24 +
   (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_9;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) +
   ((longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 5 + 5) * 8) = param_10;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x2c +
   (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_11;
  lVar3 = *(longlong *)(param_1 + 0x428);
  piVar1 = (int *)(lVar3 + 4);
  *piVar1 = *piVar1 + 1;
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x28;
  return CONCAT71((int7)((ulonglong)lVar3 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_1403f1b60  @1403f1b60  [medium:callgraph-r2]  (orig: FUN_1403f1b60)
void FUN_1403f1b60(longlong param_1)

{
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = 0;
  *(undefined4 *)(param_1 + 0xc) = 8;
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1403f1f50  @1403f1f50  [medium:callgraph-r1]  (orig: FUN_1403f1f50)
undefined8 FUN_1403f1f50(longlong param_1,undefined2 param_2)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 8) = 0x9c47;
  *(undefined4 *)(param_1 + 0xc) = 0x60;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 4) = 0;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_1403f1f80  @1403f1f80  [medium:callgraph-r1]  (orig: FUN_1403f1f80)
undefined8
FUN_1403f1f80(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined1 param_6,undefined1 param_7,undefined4 param_8,
             undefined4 param_9,undefined4 param_10,undefined1 param_11,undefined4 param_12)

{
  int *piVar1;
  
  if (0x3fb < (longlong)*(int *)(param_1 + 0xc) + 0x28U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x28;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x38 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_2;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x3c +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_3;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x40 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_4;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x44 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_5;
  *(undefined1 *)
   (*(longlong *)(param_1 + 0x428) + 0x48 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_6;
  *(undefined1 *)
   (*(longlong *)(param_1 + 0x428) + 0x49 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_7;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x4c +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_8;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) +
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 5 + 10) * 8) = param_9;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x54 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_10;
  *(undefined1 *)
   (*(longlong *)(param_1 + 0x428) + 0x58 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_11;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x5c +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x28) = param_12;
  piVar1 = (int *)(*(longlong *)(param_1 + 0x428) + 4);
  *piVar1 = *piVar1 + 1;
  return 1;
}

// ==== CCrossMsgLoadUserInfo::helper_1403f20e0  @1403f20e0  [medium:callgraph-r1]  (orig: FUN_1403f20e0)
void FUN_1403f20e0(longlong param_1)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c47;
  *(undefined4 *)(param_1 + 0xc) = 0x60;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = 0;
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1403f22e0  @1403f22e0  [medium:callgraph-r1]  (orig: FUN_1403f22e0)
void FUN_1403f22e0(longlong param_1,undefined8 param_2)

{
  FUN_14039eb90(param_2,*(longlong *)(param_1 + 0x428) + 8);
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1403f2300  @1403f2300  [medium:callgraph-r1]  (orig: FUN_1403f2300)
void FUN_1403f2300(longlong param_1,undefined8 param_2)

{
  FUN_14039eb90(param_2,*(longlong *)(param_1 + 0x428) + 0x20);
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1403fd8b0  @1403fd8b0  [medium:callgraph-r2]  (orig: FUN_1403fd8b0)
undefined1 * FUN_1403fd8b0(longlong param_1)

{
  longlong *plVar1;
  undefined1 *puVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x0001403fd905. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*plVar1 + 0x78))(plVar1);
  return puVar2;
}

// ==== CCrossMsgLoadUserInfo::helper_1403ff280  @1403ff280  [medium:callgraph-r2]  (orig: FUN_1403ff280)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403ff280(longlong param_1,longlong *param_2,undefined8 param_3,undefined1 param_4,
                  undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 *param_8)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  byte bVar8;
  undefined1 auStack_518 [32];
  undefined4 local_4f8;
  undefined8 local_4f0;
  undefined4 local_4e8;
  undefined8 local_4e0;
  undefined4 *local_4d8;
  undefined1 local_4c8 [32];
  undefined4 local_4a8;
  undefined1 local_4a4;
  undefined8 local_498;
  undefined1 local_488 [1072];
  ulonglong local_58;
  uint uVar9;
  
  if (param_2 != (longlong *)0x0) {
    local_498 = 0xfffffffffffffffe;
    local_58 = DAT_1409707c0 ^ (ulonglong)auStack_518;
    FUN_140401a90(local_488);
    local_4a8 = *param_8;
    local_4a4 = *(undefined1 *)(param_8 + 1);
    local_4f0 = FUN_1401669e0(param_2);
    local_4d8 = &local_4a8;
    local_4e0 = param_7;
    local_4e8 = param_6;
    local_4f8 = param_5;
    cVar3 = FUN_140401b50(local_488,0,param_3,param_4);
    if (cVar3 == '\0') {
      FUN_140401ae0(local_488);
    }
    else {
      plVar7 = (longlong *)**(undefined8 **)(param_1 + 0x40);
      plVar1 = *(longlong **)(param_1 + 0x10);
      while( true ) {
        plVar2 = *(longlong **)(param_1 + 0x40);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x10))) {
          _invalid_parameter_noinfo();
        }
        if (plVar7 == plVar2) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *plVar1;
        }
        if (plVar7 == *(longlong **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar2 = (longlong *)plVar7[4];
        if (plVar2 != (longlong *)0x0) {
          local_4c8[0] = 0;
          local_4c8[1] = 0;
          local_4c8[2] = 0;
          local_4c8[3] = 0;
          local_4c8[4] = 0;
          local_4c8[5] = 0;
          local_4c8[6] = 0;
          local_4c8[7] = 0;
          local_4c8[8] = 0;
          local_4c8[9] = 0;
          local_4c8[10] = 0;
          local_4c8[0xb] = 0;
          local_4c8[0xc] = 0;
          local_4c8[0xd] = 0;
          local_4c8[0xe] = 0;
          local_4c8[0xf] = 0;
          local_4c8[0x10] = 0;
          local_4c8[0x11] = 0;
          lVar6 = 0;
          uVar9 = 1;
          do {
            if (9 < lVar6) break;
            plVar5 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,uVar9 * 2 + 1);
            uVar4 = (**(code **)(*plVar5 + 0x20))(plVar5);
            local_4c8[lVar6 * 2] = uVar4;
            plVar5 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,uVar9 * 2 + 2);
            uVar4 = (**(code **)(*plVar5 + 0x20))(plVar5);
            local_4c8[lVar6 * 2 + 1] = uVar4;
            lVar6 = lVar6 + 1;
            bVar8 = (char)uVar9 + 1;
            uVar9 = (uint)bVar8;
          } while (bVar8 < 10);
          cVar3 = FUN_140401c40(local_488,local_4c8);
          if (cVar3 == '\0') {
            (**(code **)(*param_2 + 0x130))(param_2,local_488);
            FUN_140401cd0(local_488);
            FUN_140401c40(local_488,local_4c8);
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
          plVar2 = (longlong *)plVar7[2];
          if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
            cVar3 = *(char *)(*plVar2 + 0x29);
            plVar7 = plVar2;
            plVar2 = (longlong *)*plVar2;
            while (cVar3 == '\0') {
              cVar3 = *(char *)(*plVar2 + 0x29);
              plVar7 = plVar2;
              plVar2 = (longlong *)*plVar2;
            }
          }
          else {
            cVar3 = *(char *)(plVar7[1] + 0x29);
            plVar5 = (longlong *)plVar7[1];
            plVar2 = plVar7;
            while ((plVar7 = plVar5, cVar3 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
              cVar3 = *(char *)(plVar7[1] + 0x29);
              plVar5 = (longlong *)plVar7[1];
              plVar2 = plVar7;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      (**(code **)(*param_2 + 0x130))(param_2,local_488);
      FUN_140401ae0(local_488);
    }
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_140401b50  @140401b50  [medium:callgraph-r2]  (orig: FUN_140401b50)
ulonglong FUN_140401b50(longlong param_1,undefined1 param_2,char *param_3,undefined1 param_4,
                       undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined8 param_8,
                       undefined4 *param_9)

{
  longlong lVar1;
  ulonglong in_RAX;
  ulonglong uVar2;
  undefined7 extraout_var;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    uVar2 = in_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10) = 0;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1f) = param_7;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x12) = param_2;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x11) = param_4;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x13) = param_5;
    *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0x17) = param_6;
    *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0x23) = param_8;
    lVar1 = *(longlong *)(param_1 + 0x428);
    *(undefined4 *)(lVar1 + 0x2b) = *param_9;
    *(undefined1 *)(lVar1 + 0x2f) = *(undefined1 *)(param_9 + 1);
    tq::SafeCopy(*(char **)(param_1 + 0x428),param_3,0x10);
    *(undefined4 *)(param_1 + 0xc) = 0x30;
    *(undefined4 *)(param_1 + 8) = 0x9c54;
    uVar2 = CONCAT71(extraout_var,1);
  }
  return uVar2;
}

// ==== CCrossMsgLoadUserInfo::helper_140401c40  @140401c40  [medium:callgraph-r3]  (orig: FUN_140401c40)
ulonglong FUN_140401c40(longlong param_1,undefined8 *param_2)

{
  char *pcVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX;
  }
  else {
    uVar3 = (longlong)*(int *)(param_1 + 0xc) + 0x12;
    if (uVar3 < 0x400) {
      uVar3 = (ulonglong)*(byte *)(lVar2 + 0x10);
      *(undefined8 *)(lVar2 + 0x30 + uVar3 * 0x12) = *param_2;
      *(undefined8 *)(lVar2 + 0x38 + uVar3 * 0x12) = param_2[1];
      *(undefined2 *)(lVar2 + 0x40 + uVar3 * 0x12) = *(undefined2 *)(param_2 + 2);
      lVar2 = *(longlong *)(param_1 + 0x428);
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x12;
      pcVar1 = (char *)(lVar2 + 0x10);
      *pcVar1 = *pcVar1 + '\x01';
      return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CCrossMsgLoadUserInfo::helper_140401cd0  @140401cd0  [medium:callgraph-r3]  (orig: FUN_140401cd0)
void FUN_140401cd0(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x30;
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_140402310  @140402310  [medium:callgraph-r2]  (orig: FUN_140402310)
ulonglong FUN_140402310(longlong param_1)

{
  undefined4 *puVar1;
  ulonglong extraout_RAX;
  
  puVar1 = *(undefined4 **)(param_1 + 0x428);
  if (puVar1 == (undefined4 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  *puVar1 = 0;
  *(undefined4 *)(param_1 + 8) = 0x9c53;
  *(undefined4 *)(param_1 + 0xc) = 4;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_140402370  @140402370  [medium:callgraph-r2]  (orig: FUN_140402370)
ulonglong FUN_140402370(longlong param_1,undefined8 param_2)

{
  uint *puVar1;
  int *piVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  
  if (0x3fb < (longlong)*(int *)(param_1 + 0xc) + 8U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  puVar1 = *(uint **)(param_1 + 0x428);
  if (puVar1 == (uint *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 8;
  *(undefined8 *)(puVar1 + (ulonglong)*puVar1 * 2 + 1) = param_2;
  piVar2 = *(int **)(param_1 + 0x428);
  *piVar2 = *piVar2 + 1;
  return CONCAT71((int7)((ulonglong)piVar2 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_140402420  @140402420  [medium:callgraph-r2]  (orig: FUN_140402420)
void FUN_140402420(longlong param_1)

{
  if (*(undefined4 **)(param_1 + 0x428) == (undefined4 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  **(undefined4 **)(param_1 + 0x428) = 0;
  *(undefined4 *)(param_1 + 0xc) = 4;
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_140402480  @140402480  [medium:callgraph-r2]  (orig: FUN_140402480)
undefined4 FUN_140402480(longlong param_1)

{
  if (*(undefined4 **)(param_1 + 0x428) == (undefined4 *)0x0) {
    return 0;
  }
  return **(undefined4 **)(param_1 + 0x428);
}

// ==== CCrossMsgLoadUserInfo::helper_140404490  @140404490  [medium:callgraph-r2]  (orig: FUN_140404490)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140404490(longlong param_1,longlong *param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  char cVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong lVar8;
  bool bVar9;
  undefined1 auStack_4f8 [32];
  undefined4 local_4d8;
  longlong *local_4c8;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  longlong *local_4b8;
  undefined8 *local_4b0;
  longlong *local_4a8;
  undefined8 uStack_4a0;
  undefined8 *local_498;
  undefined8 local_490;
  longlong *local_488;
  undefined1 local_478 [1088];
  ulonglong local_38;
  
  local_490 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  local_4b8 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_4d8 = 0xef;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_14045d010(local_478);
    cVar5 = FUN_14045d0d0(local_478);
    if (cVar5 != '\0') {
      puVar1 = *(undefined8 **)(param_1 + 0x80);
      puVar6 = (undefined8 *)*puVar1;
      plVar2 = *(longlong **)(param_1 + 0x50);
      local_4c8 = plVar2;
      local_488 = plVar2;
LAB_140404580:
      do {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (puVar6 == puVar1) {
          puVar6 = (undefined8 *)**(undefined8 **)(param_1 + 0x80);
          plVar3 = *(longlong **)(param_1 + 0x50);
          uStack_4a0._0_4_ = SUB84(puVar6,0);
          uStack_4a0._4_4_ = (undefined4)((ulonglong)puVar6 >> 0x20);
          uStack_4c0 = (undefined4)uStack_4a0;
          uStack_4bc = uStack_4a0._4_4_;
          local_4c8 = plVar3;
          local_4a8 = plVar3;
          uStack_4a0 = puVar6;
          do {
            while( true ) {
              while( true ) {
                if ((plVar3 == (longlong *)0x0) || (plVar3 != plVar2)) {
                  _invalid_parameter_noinfo();
                }
                if (puVar6 == puVar1) {
                  cVar5 = FUN_14045d480(local_478);
                  if (cVar5 == '\0') {
                    (**(code **)(*param_2 + 0x130))(param_2,local_478);
                  }
                  FUN_14045d060(local_478);
                  return;
                }
                if (plVar3 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar8 = 0;
                }
                else {
                  lVar8 = *plVar3;
                }
                if (puVar6 == *(undefined8 **)(lVar8 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                if (puVar6[4] != 0) {
                  if (plVar3 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    lVar8 = 0;
                  }
                  else {
                    lVar8 = *plVar3;
                  }
                  if (puVar6 == *(undefined8 **)(lVar8 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  cVar5 = FUN_14045d2c0(local_478,puVar6[4]);
                  if (cVar5 == '\0') {
                    (**(code **)(*param_2 + 0x130))(param_2,local_478);
                    FUN_14045d420(local_478);
                    if (plVar3 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar8 = 0;
                    }
                    else {
                      lVar8 = *plVar3;
                    }
                    if (puVar6 == *(undefined8 **)(lVar8 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    cVar5 = FUN_14045d2c0(local_478,puVar6[4]);
                    if (cVar5 == '\0') {
                      (**(code **)(*param_2 + 8))(param_2);
                      log_InlineLogERROR(
                                        "CInnerStrengthPlayer::SendInnerStrengthInfoToCross msg AppendAttrib failed, idUser:%u."
                                        );
                      FUN_14045d060(local_478);
                      return;
                    }
                  }
                }
                if (plVar3 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                }
                if (*(char *)((longlong)puVar6 + 0x29) == '\0') break;
                _invalid_parameter_noinfo();
              }
              puVar7 = puVar6;
              puVar4 = (undefined8 *)puVar6[2];
              if (*(char *)((longlong)puVar6[2] + 0x29) != '\0') break;
              do {
                puVar6 = puVar4;
                puVar4 = (undefined8 *)*puVar6;
                local_498 = puVar6;
              } while (*(char *)((longlong)*puVar6 + 0x29) == '\0');
            }
            do {
              puVar6 = (undefined8 *)puVar7[1];
              if (*(char *)((longlong)puVar6 + 0x29) != '\0') break;
              bVar9 = puVar7 == (undefined8 *)puVar6[2];
              puVar7 = puVar6;
            } while (bVar9);
          } while( true );
        }
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar8 = 0;
        }
        else {
          lVar8 = *plVar2;
        }
        if (puVar6 == *(undefined8 **)(lVar8 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (puVar6[4] != 0) {
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = 0;
          }
          else {
            lVar8 = *plVar2;
          }
          if (puVar6 == *(undefined8 **)(lVar8 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          cVar5 = FUN_14045d170(local_478,puVar6[4]);
          if (cVar5 == '\0') {
            (**(code **)(*param_2 + 0x130))(param_2,local_478);
            FUN_14045d420(local_478);
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar8 = 0;
            }
            else {
              lVar8 = *plVar2;
            }
            if (puVar6 == *(undefined8 **)(lVar8 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            cVar5 = FUN_14045d170(local_478,puVar6[4]);
            if (cVar5 == '\0') {
              (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR(
                                "CInnerStrengthPlayer::SendInnerStrengthInfoToCross msg append failed, idUser:%u."
                                );
              FUN_14045d060(local_478);
              return;
            }
          }
        }
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar6 + 0x29) != '\0') {
          _invalid_parameter_noinfo();
          goto LAB_140404580;
        }
        puVar7 = puVar6;
        puVar4 = (undefined8 *)puVar6[2];
        if (*(char *)((longlong)puVar6[2] + 0x29) == '\0') {
          do {
            puVar6 = puVar4;
            puVar4 = (undefined8 *)*puVar6;
            local_4b0 = puVar6;
          } while (*(char *)((longlong)*puVar6 + 0x29) == '\0');
        }
        else {
          do {
            puVar6 = (undefined8 *)puVar7[1];
            if (*(char *)((longlong)puVar6 + 0x29) != '\0') break;
            bVar9 = puVar7 == (undefined8 *)puVar6[2];
            puVar7 = puVar6;
          } while (bVar9);
        }
      } while( true );
    }
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(
                      "CInnerStrengthPlayer::SendInnerStrengthInfoToCross msg create failed, idUser:%u."
                      );
    FUN_14045d060(local_478);
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_1404048f0  @1404048f0  [medium:callgraph-r2]  (orig: FUN_1404048f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404048f0(longlong param_1,longlong *param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  char cVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong lVar7;
  bool bVar8;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined8 *local_498;
  longlong *local_490;
  undefined8 local_488;
  longlong *local_480;
  longlong *local_470;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_490 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_4a8 = 0x133;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_1 + 0x48) != 0) {
    FUN_14045cc80(local_458);
    cVar4 = FUN_14045cd40(local_458);
    if (cVar4 != '\0') {
      puVar1 = *(undefined8 **)(param_1 + 0x40);
      puVar5 = (undefined8 *)*puVar1;
      plVar2 = *(longlong **)(param_1 + 0x10);
      local_480 = plVar2;
      local_470 = plVar2;
      do {
        while( true ) {
          while( true ) {
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (puVar5 == puVar1) {
              cVar4 = FUN_14045ce90(local_458);
              if (cVar4 == '\0') {
                (**(code **)(*param_2 + 0x130))(param_2,local_458);
              }
              FUN_14045ccd0(local_458);
              return;
            }
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar2;
            }
            if (puVar5 == *(undefined8 **)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (*(int *)((longlong)puVar5 + 0x1c) != 0) {
              if (plVar2 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar7 = 0;
              }
              else {
                lVar7 = *plVar2;
              }
              if (puVar5 == *(undefined8 **)(lVar7 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              if (plVar2 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar7 = 0;
              }
              else {
                lVar7 = *plVar2;
              }
              if (puVar5 == *(undefined8 **)(lVar7 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              cVar4 = FUN_14045cdb0(local_458,*(undefined1 *)(puVar5 + 3),
                                    *(undefined4 *)((longlong)puVar5 + 0x1c));
              if (cVar4 == '\0') {
                (**(code **)(*param_2 + 8))(param_2);
                log_InlineLogERROR(
                                  "CInnerStrengthPlayer::SendInnerStrengthAttribSumToCross msg append failed, idUser:%u."
                                  );
                FUN_14045ccd0(local_458);
                return;
              }
            }
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)puVar5 + 0x21) == '\0') break;
            _invalid_parameter_noinfo();
          }
          puVar6 = puVar5;
          puVar3 = (undefined8 *)puVar5[2];
          if (*(char *)((longlong)puVar5[2] + 0x21) != '\0') break;
          do {
            puVar5 = puVar3;
            puVar3 = (undefined8 *)*puVar5;
            local_498 = puVar5;
          } while (*(char *)((longlong)*puVar5 + 0x21) == '\0');
        }
        do {
          puVar5 = (undefined8 *)puVar6[1];
          if (*(char *)((longlong)puVar5 + 0x21) != '\0') break;
          bVar8 = puVar6 == (undefined8 *)puVar5[2];
          puVar6 = puVar5;
        } while (bVar8);
      } while( true );
    }
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(
                      "CInnerStrengthPlayer::SendInnerStrengthAttribSumToCross msg create failed, idUser:%u."
                      );
    FUN_14045ccd0(local_458);
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_14045cd40  @14045cd40  [medium:callgraph-r3]  (orig: FUN_14045cd40)
ulonglong FUN_14045cd40(longlong param_1)

{
  undefined2 *puVar1;
  ulonglong extraout_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 8) = 0x9c60;
  *(undefined4 *)(param_1 + 0xc) = 2;
  *puVar1 = 0;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_14045cdb0  @14045cdb0  [medium:callgraph-r3]  (orig: FUN_14045cdb0)
ulonglong FUN_14045cdb0(longlong param_1,undefined1 param_2,undefined4 param_3)

{
  ushort *puVar1;
  short *psVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  
  puVar1 = *(ushort **)(param_1 + 0x428);
  if (puVar1 == (ushort *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX;
  }
  else {
    uVar3 = (longlong)*(int *)(param_1 + 0xc) + 5;
    if (uVar3 < 0x400) {
      *(undefined1 *)((ulonglong)*puVar1 * 5 + 2 + (longlong)puVar1) = param_2;
      *(undefined4 *)
       ((ulonglong)**(ushort **)(param_1 + 0x428) * 5 + 3 + (longlong)*(ushort **)(param_1 + 0x428))
           = param_3;
      psVar2 = *(short **)(param_1 + 0x428);
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 5;
      *psVar2 = *psVar2 + 1;
      return CONCAT71((int7)((ulonglong)psVar2 >> 8),1);
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CCrossMsgLoadUserInfo::helper_14045ce90  @14045ce90  [medium:callgraph-r3]  (orig: FUN_14045ce90)
ulonglong FUN_14045ce90(longlong param_1)

{
  ulonglong extraout_RAX;
  
  if (*(short **)(param_1 + 0x428) == (short *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  return (ulonglong)(**(short **)(param_1 + 0x428) == 0);
}

// ==== CCrossMsgLoadUserInfo::helper_14045d0d0  @14045d0d0  [medium:callgraph-r3]  (orig: FUN_14045d0d0)
ulonglong FUN_14045d0d0(longlong param_1)

{
  ushort *puVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c5a;
  *(undefined4 *)(param_1 + 0xc) = 4;
  **(undefined2 **)(param_1 + 0x428) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = 0;
  uVar2 = (ulonglong)**(ushort **)(param_1 + 0x428);
  puVar1 = *(ushort **)(param_1 + 0x428) + uVar2 * 2;
  *(ulonglong *)(param_1 + 0x430) = uVar2 + 4 + (longlong)puVar1;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_14045d170  @14045d170  [medium:callgraph-r3]  (orig: FUN_14045d170)
ulonglong FUN_14045d170(longlong param_1,longlong param_2)

{
  ushort *puVar1;
  undefined1 uVar2;
  undefined2 uVar3;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar4;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = extraout_RAX;
  }
  else {
    if (param_2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return extraout_RAX_00 & 0xffffffffffffff00;
    }
    uVar4 = (longlong)*(int *)(param_1 + 0xc) + 5;
    if (uVar4 < 0x400) {
      puVar1 = *(ushort **)(param_1 + 0x428);
      uVar3 = FUN_1404db500(param_2);
      *(undefined2 *)((ulonglong)*puVar1 * 5 + 4 + (longlong)puVar1) = uVar3;
      puVar1 = *(ushort **)(param_1 + 0x428);
      uVar2 = FUN_1404db5c0(param_2);
      *(undefined1 *)((ulonglong)*puVar1 * 5 + 6 + (longlong)puVar1) = uVar2;
      puVar1 = *(ushort **)(param_1 + 0x428);
      uVar2 = FUN_1404db810(param_2);
      *(undefined1 *)((ulonglong)*puVar1 * 5 + 7 + (longlong)puVar1) = uVar2;
      puVar1 = *(ushort **)(param_1 + 0x428);
      uVar2 = FUN_1404dba10(param_2);
      *(undefined1 *)((ulonglong)*puVar1 * 5 + 8 + (longlong)puVar1) = uVar2;
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 5;
      **(short **)(param_1 + 0x428) = **(short **)(param_1 + 0x428) + 1;
      uVar4 = (ulonglong)**(ushort **)(param_1 + 0x428);
      puVar1 = *(ushort **)(param_1 + 0x428) + uVar4 * 2;
      *(ulonglong *)(param_1 + 0x430) = uVar4 + 4 + (longlong)puVar1;
      return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
    }
  }
  return uVar4 & 0xffffffffffffff00;
}

// ==== CCrossMsgLoadUserInfo::helper_14045d2c0  @14045d2c0  [medium:callgraph-r3]  (orig: FUN_14045d2c0)
undefined8 FUN_14045d2c0(longlong param_1,longlong param_2)

{
  short *psVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*(longlong *)(param_1 + 0x428) != 0) {
    uVar2 = FUN_1404db500(param_2);
    iVar4 = 8;
    do {
      if (0x3ff < (longlong)*(int *)(param_1 + 0xc) + 7U) {
        return 0;
      }
      iVar3 = FUN_1404db6c0(param_2,iVar4);
      if (iVar3 != 0) {
        *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 7;
        *(char *)((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 7 + 2 +
                 *(longlong *)(param_1 + 0x430)) = (char)iVar4 + -7;
        *(int *)((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 7 + 3 +
                *(longlong *)(param_1 + 0x430)) = iVar3;
        *(undefined2 *)
         ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 7 +
         *(longlong *)(param_1 + 0x430)) = uVar2;
        psVar1 = (short *)(*(longlong *)(param_1 + 0x428) + 2);
        *psVar1 = *psVar1 + 1;
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < 0x16);
    return 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CCrossMsgLoadUserInfo::helper_14045d420  @14045d420  [medium:callgraph-r3]  (orig: FUN_14045d420)
void FUN_14045d420(longlong param_1)

{
  if (*(undefined2 **)(param_1 + 0x428) == (undefined2 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  **(undefined2 **)(param_1 + 0x428) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = 0;
  *(undefined4 *)(param_1 + 0xc) = 4;
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_14045d480  @14045d480  [medium:callgraph-r3]  (orig: FUN_14045d480)
ulonglong FUN_14045d480(longlong param_1)

{
  short *psVar1;
  ulonglong extraout_RAX;
  
  psVar1 = *(short **)(param_1 + 0x428);
  if (psVar1 == (short *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  if ((*psVar1 == 0) && (psVar1[1] == 0)) {
    return 1;
  }
  return 0;
}

// ==== CCrossMsgLoadUserInfo::helper_14045d770  @14045d770  [medium:callgraph-r3]  (orig: FUN_14045d770)
undefined8 FUN_14045d770(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 8) = 0x9c51;
  *(undefined4 *)(param_1 + 0xc) = 8;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 4) = 0;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_14045d7a0  @14045d7a0  [medium:callgraph-r3]  (orig: FUN_14045d7a0)
ulonglong FUN_14045d7a0(longlong param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                       undefined4 param_9,undefined4 param_10)

{
  int *piVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  
  if (0x3fb < (longlong)*(int *)(param_1 + 0xc) + 0x24U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x24;
  *(undefined1 *)(lVar2 + 8 + (ulonglong)*(uint *)(lVar2 + 4) * 0x24) = param_2;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0xc +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x24) = param_3;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x10 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x24) = param_4;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x14 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x24) = param_5;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x18 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x24) = param_6;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x1c +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x24) = param_7;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x20 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x24) = param_8;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) +
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 9 + 9) * 4) = param_9;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x28 +
   (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 4) * 0x24) = param_10;
  lVar2 = *(longlong *)(param_1 + 0x428);
  piVar1 = (int *)(lVar2 + 4);
  *piVar1 = *piVar1 + 1;
  return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_14045d900  @14045d900  [medium:callgraph-r3]  (orig: FUN_14045d900)
undefined4 FUN_14045d900(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return 0;
  }
  return *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4);
}

// ==== CCrossMsgLoadUserInfo::helper_14045db40  @14045db40  [medium:callgraph-r3]  (orig: FUN_14045db40)
undefined8 FUN_14045db40(longlong param_1)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 8) = 0x9c46;
  *(undefined4 *)(param_1 + 0xc) = 4;
  *puVar1 = 0;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_14045db60  @14045db60  [medium:callgraph-r3]  (orig: FUN_14045db60)
undefined4 FUN_14045db60(longlong param_1)

{
  return **(undefined4 **)(param_1 + 0x428);
}

// ==== CCrossMsgLoadUserInfo::helper_14045db70  @14045db70  [medium:callgraph-r3]  (orig: FUN_14045db70)
ulonglong FUN_14045db70(longlong param_1,undefined1 param_2,uint param_3)

{
  uint *puVar1;
  int *piVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  
  if (0x3fb < (longlong)*(int *)(param_1 + 0xc) + 8U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  puVar1 = *(uint **)(param_1 + 0x428);
  if (puVar1 == (uint *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 8;
  *(undefined1 *)(puVar1 + (ulonglong)*puVar1 * 2 + 1) = param_2;
  (*(uint **)(param_1 + 0x428))[(ulonglong)**(uint **)(param_1 + 0x428) * 2 + 2] = param_3;
  piVar2 = *(int **)(param_1 + 0x428);
  *piVar2 = *piVar2 + 1;
  return CONCAT71((int7)((ulonglong)piVar2 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_14045de40  @14045de40  [medium:callgraph-r3]  (orig: FUN_14045de40)
undefined8 FUN_14045de40(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 8) = 0x9c48;
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 8) = 0;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_14045de80  @14045de80  [medium:callgraph-r3]  (orig: FUN_14045de80)
ulonglong FUN_14045de80(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
                       undefined2 param_5,undefined4 param_6,undefined1 param_7,undefined2 param_8,
                       undefined1 param_9,undefined4 param_10,undefined1 param_11)

{
  ulonglong uVar1;
  int *piVar2;
  longlong lVar3;
  
  uVar1 = (longlong)*(int *)(param_1 + 0xc) + 0x20;
  if (0x3ff < uVar1) {
    return uVar1 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x20;
  *(undefined4 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x20 + 0xc +
   *(longlong *)(param_1 + 0x428)) = param_2;
  *(undefined4 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x20 + 0x10 +
   *(longlong *)(param_1 + 0x428)) = param_3;
  *(undefined2 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x20 + 0x14 +
   *(longlong *)(param_1 + 0x428)) = param_4;
  *(undefined2 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x20 + 0x16 +
   *(longlong *)(param_1 + 0x428)) = param_5;
  *(undefined4 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x20 + 0x18 +
   *(longlong *)(param_1 + 0x428)) = param_6;
  *(undefined1 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x20 + 0x1c +
   *(longlong *)(param_1 + 0x428)) = param_7;
  *(undefined2 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x20 + 0x1e +
   *(longlong *)(param_1 + 0x428)) = param_8;
  *(undefined1 *)
   (((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) + 1) * 0x20 +
   *(longlong *)(param_1 + 0x428)) = param_9;
  *(undefined4 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x20 + 0x24 +
   *(longlong *)(param_1 + 0x428)) = param_10;
  *(undefined1 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x20 + 0x28 +
   *(longlong *)(param_1 + 0x428)) = param_11;
  lVar3 = *(longlong *)(param_1 + 0x428);
  piVar2 = (int *)(lVar3 + 8);
  *piVar2 = *piVar2 + 1;
  return CONCAT71((int7)((ulonglong)lVar3 >> 8),1);
}

// ==== CCrossMsgLoadUserInfo::helper_14045df90  @14045df90  [medium:callgraph-r3]  (orig: FUN_14045df90)
undefined4 FUN_14045df90(longlong param_1)

{
  return *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8);
}

// ==== CCrossMsgLoadUserInfo::helper_140479080  @140479080  [medium:callgraph-r2]  (orig: FUN_140479080)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140479080(longlong param_1,longlong *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong *plVar9;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined4 local_4b0;
  int local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  int local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_480 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
    if ((*(longlong *)(param_1 + 0x20) != 0) && (*(longlong *)(param_1 + 0x28) != 0)) {
      FUN_14045d6c0(local_478);
      if (*(longlong *)(param_1 + 0x20) == 0) {
        uVar4 = 0;
      }
      else {
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                           (*(longlong **)(param_1 + 0x20),0x12);
        uVar4 = (**(code **)(*plVar9 + 0x50))(plVar9);
      }
      cVar1 = FUN_14045d770(local_478,uVar4);
      if (cVar1 == '\0') {
        FUN_14045d710(local_478);
      }
      else {
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                           (*(longlong **)(param_1 + 0x20),2);
        iVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        local_488 = iVar2;
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                           (*(longlong **)(param_1 + 0x28),2);
        iVar3 = (**(code **)(*plVar9 + 0x50))(plVar9);
        if ((iVar2 != 0) || (iVar3 != 0)) {
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),3);
          uVar4 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),4);
          uVar5 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),5);
          uVar6 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),3);
          uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),4);
          uVar8 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),5);
          local_490 = (**(code **)(*plVar9 + 0x50))(plVar9);
          local_4b8 = uVar5;
          local_4b0 = uVar6;
          local_4a8 = iVar3;
          local_4a0 = uVar7;
          local_498 = uVar8;
          FUN_14045d7a0(local_478,1,local_488,uVar4);
        }
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                           (*(longlong **)(param_1 + 0x20),6);
        iVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        local_488 = iVar2;
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                           (*(longlong **)(param_1 + 0x28),6);
        iVar3 = (**(code **)(*plVar9 + 0x50))(plVar9);
        if ((iVar2 != 0) || (iVar3 != 0)) {
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),7);
          uVar4 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),8);
          uVar5 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),9);
          uVar6 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),7);
          uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),8);
          uVar8 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),9);
          local_490 = (**(code **)(*plVar9 + 0x50))(plVar9);
          local_4b8 = uVar5;
          local_4b0 = uVar6;
          local_4a8 = iVar3;
          local_4a0 = uVar7;
          local_498 = uVar8;
          FUN_14045d7a0(local_478,2,local_488,uVar4);
        }
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                           (*(longlong **)(param_1 + 0x20),10);
        iVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        local_488 = iVar2;
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                           (*(longlong **)(param_1 + 0x28),10);
        iVar3 = (**(code **)(*plVar9 + 0x50))(plVar9);
        if ((iVar2 != 0) || (iVar3 != 0)) {
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0xb);
          uVar4 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0xc);
          uVar5 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0xd);
          uVar6 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0xb);
          uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0xc);
          uVar8 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0xd);
          local_490 = (**(code **)(*plVar9 + 0x50))(plVar9);
          local_4b8 = uVar5;
          local_4b0 = uVar6;
          local_4a8 = iVar3;
          local_4a0 = uVar7;
          local_498 = uVar8;
          FUN_14045d7a0(local_478,3,local_488,uVar4);
        }
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                           (*(longlong **)(param_1 + 0x20),0xe);
        iVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        local_488 = iVar2;
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                           (*(longlong **)(param_1 + 0x28),0xe);
        iVar3 = (**(code **)(*plVar9 + 0x50))(plVar9);
        if ((iVar2 != 0) || (iVar3 != 0)) {
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0xf);
          uVar4 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0x10);
          uVar5 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0x11);
          uVar6 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0xf);
          uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0x10);
          uVar8 = (**(code **)(*plVar9 + 0x50))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0x11);
          local_490 = (**(code **)(*plVar9 + 0x50))(plVar9);
          local_4b8 = uVar5;
          local_4b0 = uVar6;
          local_4a8 = iVar3;
          local_4a0 = uVar7;
          local_498 = uVar8;
          FUN_14045d7a0(local_478,4,local_488,uVar4);
        }
        iVar2 = FUN_14045d900(local_478);
        if (iVar2 != 0) {
          (**(code **)(*param_2 + 0x130))(param_2,local_478);
        }
        FUN_14045d710(local_478);
      }
    }
  }
  return;
}

// ==== CCrossMsgLoadUserInfo::helper_14048a7b0  @14048a7b0  [medium:callgraph-r2]  (orig: FUN_14048a7b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14048a7b0(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined1 uVar3;
  undefined1 uVar4;
  char cVar5;
  undefined2 uVar6;
  undefined2 uVar7;
  undefined2 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  int iVar13;
  longlong *plVar14;
  longlong lVar15;
  undefined1 auStack_4f8 [32];
  undefined2 local_4d8;
  undefined4 local_4d0;
  undefined1 local_4c8;
  undefined2 local_4c0;
  undefined1 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined1 local_498;
  longlong *local_490;
  longlong *local_488;
  longlong local_480;
  longlong local_478;
  undefined8 local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_470 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  local_478 = param_1;
  FUN_14045dd90(local_468);
  uVar9 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
  FUN_14045de40(local_468,uVar9,0);
  plVar14 = (longlong *)**(longlong **)(param_1 + 0x38);
  local_488 = *(longlong **)(param_1 + 8);
  local_490 = plVar14;
  while( true ) {
    plVar1 = *(longlong **)(param_1 + 0x38);
    if ((local_488 == (longlong *)0x0) || (local_488 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar14 == plVar1) break;
    if (local_488 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar15 = 0;
    }
    else {
      lVar15 = *local_488;
    }
    if (plVar14 == *(longlong **)(lVar15 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar15 = plVar14[4];
    local_480 = lVar15;
    if (lVar15 != 0) {
      local_498 = FUN_1404184d0(lVar15);
      uVar9 = FUN_140418e40(lVar15,8);
      uVar3 = FUN_140418c50(lVar15,7);
      uVar6 = FUN_140418c50(lVar15,6);
      uVar4 = FUN_140418c50(lVar15,5);
      uVar10 = FUN_140418c50(lVar15,4);
      uVar7 = FUN_140418c50(lVar15,3);
      uVar8 = FUN_140418c50(lVar15,2);
      uVar11 = FUN_140418c50(local_480,1);
      uVar12 = FUN_140418c50(local_480,0);
      local_4a8 = local_498;
      local_4d8 = uVar7;
      local_4d0 = uVar10;
      local_4c8 = uVar4;
      local_4c0 = uVar6;
      local_4b8 = uVar3;
      local_4b0 = uVar9;
      cVar5 = FUN_14045de80(local_468,uVar12,uVar11,uVar8);
      lVar15 = local_478;
      plVar14 = local_490;
      param_1 = local_478;
      if (cVar5 == '\0') {
        (**(code **)(**(longlong **)(local_478 + 0x1c8) + 0x130))
                  (*(longlong **)(local_478 + 0x1c8),local_468);
        uVar9 = (**(code **)(**(longlong **)(lVar15 + 0x1c8) + 8))();
        FUN_14045de40(local_468,uVar9,0);
        lVar15 = local_480;
        local_498 = FUN_1404184d0(local_480);
        uVar9 = FUN_140418c50(lVar15,8);
        uVar3 = FUN_140418c50(lVar15,7);
        uVar6 = FUN_140418c50(lVar15,6);
        uVar4 = FUN_140418c50(lVar15,5);
        uVar10 = FUN_140418c50(lVar15,4);
        uVar7 = FUN_140418c50(lVar15,3);
        uVar8 = FUN_140418c50(lVar15,2);
        uVar11 = FUN_140418c50(lVar15,1);
        uVar12 = FUN_140418c50(local_480,0);
        local_4a8 = local_498;
        local_4d8 = uVar7;
        local_4d0 = uVar10;
        local_4c8 = uVar4;
        local_4c0 = uVar6;
        local_4b8 = uVar3;
        local_4b0 = uVar9;
        FUN_14045de80(local_468,uVar12,uVar11,uVar8);
        plVar14 = local_490;
        param_1 = local_478;
      }
    }
    if (local_488 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar14 + 0x29) == '\0') {
      plVar1 = (longlong *)plVar14[2];
      if (*(char *)((longlong)plVar1 + 0x29) == '\0') {
        cVar5 = *(char *)(*plVar1 + 0x29);
        plVar14 = plVar1;
        plVar1 = (longlong *)*plVar1;
        while (local_490 = plVar14, cVar5 == '\0') {
          cVar5 = *(char *)(*plVar1 + 0x29);
          plVar14 = plVar1;
          plVar1 = (longlong *)*plVar1;
        }
      }
      else {
        cVar5 = *(char *)(plVar14[1] + 0x29);
        plVar2 = (longlong *)plVar14[1];
        plVar1 = plVar14;
        while ((plVar14 = plVar2, local_490 = plVar14, cVar5 == '\0' &&
               (plVar1 == (longlong *)plVar14[2]))) {
          cVar5 = *(char *)(plVar14[1] + 0x29);
          plVar2 = (longlong *)plVar14[1];
          plVar1 = plVar14;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  iVar13 = FUN_14045df90(local_468);
  if (iVar13 != 0) {
    (**(code **)(**(longlong **)(param_1 + 0x1c8) + 0x130))
              (*(longlong **)(param_1 + 0x1c8),local_468);
  }
  FUN_14045dde0(local_468);
  return;
}

