// ==== CMsgGiveBack::helper_14010b4b0  @14010b4b0  [medium:callgraph-r3]  (orig: FUN_14010b4b0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14010b4b0(undefined8 param_1,longlong param_2,undefined4 *param_3)

{
  ushort uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pVirGm",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\lostitemmgr.cpp"
                      );
  }
  else if (param_3 == (undefined4 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pInfo",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\lostitemmgr.cpp"
                      );
  }
  else {
    uVar1 = *(ushort *)(param_3 + 1);
    if (uVar1 != 0) {
      if (uVar1 < 3) {
        if (*(short *)((longlong)param_3 + 6) == 1) {
          tq::TimeGet(2);
          tq::MyLogSave("gmlog/GiveBack_Opt_VirGM",
                        "CN[%u]: VirGM[name=%s], optType[%d], Item[id=%u, type=%u], from_id[%u], target_id[%u], case_num[%u], getway[%s], Time[%u]"
                        ,*param_3,param_2);
        }
        else if (*(short *)((longlong)param_3 + 6) == 2) {
          tq::TimeGet(2);
          tq::MyLogSave("gmlog/GiveBack_Opt_VirGM",
                        "CN[%u]: VirGM[name=%s], optType[%d], Item[id=%u, type=%u], from_id[%u], target_id[%u], case_num[%u], getway[%s], Time[%u]"
                        ,*param_3,param_2);
        }
      }
      else if (uVar1 == 3) {
        tq::TimeGet(2);
        tq::MyLogSave("gmlog/GiveBack_Opt_VirGM",
                      "CN[%u]: VirGM[name=%s], optType[%d], Item[id=%u, type=%u], Emoney[%u], from_id[%u], target_id[%u], case_num[%u], Time[%u]"
                      ,*param_3,param_2);
      }
      else if (uVar1 == 4) {
        tq::TimeGet(2);
        tq::MyLogSave("gmlog/GiveBack_Opt_VirGM",
                      "CN[%u]: VirGM[name=%s], optType[%d], Item[id=%u, type=%u], Money[%u], from_id[%u], target_id[%u], case_num[%u], Time[%u]"
                      ,*param_3,param_2);
      }
    }
  }
  return;
}

// ==== CMsgGiveBack::helper_14010b870  @14010b870  [medium:callgraph-r3]  (orig: FUN_14010b870)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_14010b870(basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_1,
             basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *param_2,
             undefined4 *param_3)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_1,param_2);
  *(undefined4 *)(param_1 + 0x28) = *param_3;
  *(undefined4 *)(param_1 + 0x2c) = param_3[1];
  *(undefined4 *)(param_1 + 0x30) = param_3[2];
  *(undefined4 *)(param_1 + 0x34) = param_3[3];
  *(undefined4 *)(param_1 + 0x38) = param_3[4];
  *(undefined4 *)(param_1 + 0x3c) = param_3[5];
  *(undefined4 *)(param_1 + 0x40) = param_3[6];
  *(undefined4 *)(param_1 + 0x44) = param_3[7];
  *(undefined4 *)(param_1 + 0x48) = param_3[8];
  return param_1;
}

// ==== CMsgGiveBack::helper_14010c180  @14010c180  [medium:callgraph-r2]  (orig: FUN_14010c180)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_14010c180(longlong param_1,longlong param_2,undefined4 *param_3)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined8 uVar10;
  longlong *plVar11;
  IStringManager *pIVar12;
  undefined1 auStack_cc8 [32];
  ulonglong local_ca8;
  uint local_ca0;
  undefined8 local_c98;
  uint local_c88;
  undefined4 local_c84;
  undefined4 local_c80;
  longlong *local_c78;
  longlong *local_c70;
  longlong local_c68;
  longlong *local_c60;
  longlong *local_c58;
  undefined8 local_c50;
  char local_c48;
  undefined1 local_c47 [1023];
  char local_848 [1023];
  undefined1 local_449;
  char local_448 [1024];
  ulonglong local_48;
  
  local_c50 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_cc8;
  local_c68 = param_2;
  if (param_2 == 0) {
    local_ca8 = CONCAT44(local_ca8._4_4_,0x265);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 10;
  }
  else if (param_3 == (undefined4 *)0x0) {
    local_ca8 = CONCAT44(local_ca8._4_4_,0x269);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 10;
  }
  else if (*(short *)(param_3 + 1) == 3) {
    _snprintf(local_448,0x400,
              "SELECT id,account_id,emoney,emoney_mono,chk_sum FROM cq_user WHERE id=%u LIMIT 1");
    FUN_140008520(*(undefined4 *)(param_1 + 0x108));
    plVar6 = (longlong *)InstanceGet();
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,local_448,2);
    local_c58 = plVar6;
    if ((plVar6 == (longlong *)0x0) || (lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6), lVar7 == 0))
    {
      if (plVar6 != (longlong *)0x0) {
        (**(code **)*plVar6)(plVar6);
      }
      uVar3 = 4;
    }
    else {
      plVar8 = (longlong *)(**(code **)(*plVar6 + 0x38))(plVar6);
      local_c60 = plVar8;
      if (plVar8 == (longlong *)0x0) {
        local_ca8 = CONCAT44(local_ca8._4_4_,0x281);
        log_InlineLogERROR(&DAT_1406d9c10);
        (**(code **)*plVar6)(plVar6);
        uVar3 = 9;
      }
      else {
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"emoney");
        uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
        local_c88 = uVar4;
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"emoney_mono");
        local_c80 = (**(code **)(*plVar9 + 0x40))(plVar9);
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"chk_sum");
        (**(code **)(*plVar9 + 0x40))(plVar9);
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"account_id");
        uVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
        local_c70 = (longlong *)CONCAT44(local_c70._4_4_,uVar3);
        if (uVar4 < (uint)param_3[2]) {
          (**(code **)*plVar8)(plVar8,1);
          (**(code **)*plVar6)(plVar6);
          uVar3 = 7;
        }
        else {
          plVar9 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            local_ca8 = CONCAT44(local_ca8._4_4_,0x3c0);
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar9 = (longlong *)0x0;
          }
          local_ca0 = local_ca0 & 0xffffff00;
          local_ca8 = local_ca8 & 0xffffffff00000000;
          plVar9 = (longlong *)(**(code **)(*plVar9 + 0x18))(plVar9,0xb238e,param_3[4],0xcd);
          local_c78 = plVar9;
          if (plVar9 == (longlong *)0x0) {
            local_ca8 = CONCAT44(local_ca8._4_4_,0x293);
            log_InlineLogERROR(&DAT_1406d9c10);
            (**(code **)*plVar8)(plVar8,1);
            (**(code **)*plVar6)(plVar6);
            uVar3 = 0;
          }
          else {
            uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x108));
            plVar11 = (longlong *)FUN_140087650(uVar10);
            lVar7 = (**(code **)(*plVar11 + 0x98))(plVar11,param_3[3]);
            if (lVar7 == 0) {
              local_c88 = local_c88 - param_3[2];
              uVar3 = FUN_1403714b0((ulonglong)local_c70 & 0xffffffff,local_c88,local_c80);
              plVar11 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"emoney");
              (**(code **)(*plVar11 + 0xb8))(plVar11,local_c88);
              plVar11 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"chk_sum");
              (**(code **)(*plVar11 + 0xb8))(plVar11,uVar3);
              (**(code **)(*plVar8 + 0x38))(plVar8,0);
            }
            else {
              uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x108));
              plVar11 = (longlong *)FUN_140087650(uVar10);
              (**(code **)(*plVar11 + 0x68))(plVar11,*(undefined4 *)(lVar7 + 0xf10),600);
              local_ca8 = 0;
              cVar2 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x2e0))
                                ((longlong *)(lVar7 + 0x10),0x1d,(longlong)(int)-param_3[2],1);
              if (cVar2 == '\0') {
                local_ca8 = CONCAT44(local_ca8._4_4_,0x2a0);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              local_c88 = *(int *)(lVar7 + 0xfa4);
              uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x108));
              plVar11 = (longlong *)FUN_140087650(uVar10);
              (**(code **)(*plVar11 + 0x50))(plVar11,lVar7,&DAT_140709660);
            }
            FUN_140104140(plVar9,0xd,param_3[2],1);
            uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x108));
            plVar9 = (longlong *)FUN_140087650(uVar10);
            lVar7 = (**(code **)(*plVar9 + 0x98))(plVar9);
            local_c84 = 0;
            if (lVar7 == 0) {
              local_c48 = '\0';
              memset(local_c47,0,0x3ff);
              _snprintf(&local_c48,0x3ff,"SELECT emoney FROM cq_user WHERE id=%u LIMIT 1");
              FUN_140008520(*(undefined4 *)(param_1 + 0x108));
              plVar9 = (longlong *)InstanceGet();
              plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,&local_c48,2);
              local_c70 = plVar9;
              if ((plVar9 != (longlong *)0x0) &&
                 (lVar7 = (**(code **)(*plVar9 + 0x40))(plVar9), lVar7 != 0)) {
                plVar11 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,"emoney");
                local_c84 = (**(code **)(*plVar11 + 0x48))(plVar11);
              }
              if (plVar9 != (longlong *)0x0) {
                (**(code **)*plVar9)(plVar9);
              }
            }
            else {
              local_c84 = *(undefined4 *)(lVar7 + 0xfa4);
              pIVar12 = theInstance();
              lVar1 = *(longlong *)(lVar7 + 0x10);
              uVar10 = (*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_GIVEBACK_EMONEY");
              (**(code **)(lVar1 + 0x358))(lVar7 + 0x10,uVar10,param_3[2]);
            }
            FUN_140008520(*(undefined4 *)(param_1 + 0x108));
            local_c98 = InstanceGet();
            local_ca0 = local_c84;
            local_ca8._0_4_ = local_c88;
            FUN_1401667d0(0x13,param_3[3],param_3[4],param_3[2]);
            local_ca0 = *param_3;
            local_ca8._0_4_ = param_3[2];
            _snprintf(local_848,0x400,"%d %u %u");
            local_449 = 0;
            plVar9 = (longlong *)FUN_1400e1de0();
            lVar7 = *plVar9;
            local_ca0 = (**(code **)(*local_c78 + 8))();
            local_ca8._0_4_ = 1;
            (**(code **)(lVar7 + 8))(plVar9,"SYSTEM",param_3[3],local_848);
            plVar9 = (longlong *)FUN_1400e1de0();
            lVar7 = *plVar9;
            local_ca0 = (**(code **)(*local_c78 + 8))(local_c78);
            local_ca8._0_4_ = 2;
            (**(code **)(lVar7 + 8))(plVar9,"SYSTEM",param_3[4],local_848);
            plVar9 = local_c78;
            uVar3 = FUN_1400fda10(local_c78,1,1);
            uVar5 = (**(code **)(*plVar9 + 8))(plVar9);
            local_ca8._0_4_ = uVar3;
            FUN_14010b4b0(param_1,local_c68,param_3,uVar5);
            plVar11 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_ca8._0_4_ = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar11 = (longlong *)0x0;
            }
            lVar7 = *plVar11;
            uVar3 = (**(code **)(*plVar9 + 8))(plVar9);
            (**(code **)(lVar7 + 0x58))(plVar11,uVar3,0);
            (**(code **)*plVar8)(plVar8,1);
            (**(code **)*plVar6)(plVar6);
            uVar3 = 1;
          }
        }
      }
    }
  }
  else {
    uVar3 = 9;
  }
  return uVar3;
}

// ==== CMsgGiveBack::helper_14010c8a0  @14010c8a0  [medium:callgraph-r2]  (orig: FUN_14010c8a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_14010c8a0(longlong param_1,longlong param_2,undefined4 *param_3)

{
  uint uVar1;
  longlong lVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined8 uVar11;
  longlong *plVar12;
  IStringManager *pIVar13;
  undefined1 auStack_8b8 [32];
  undefined4 local_898;
  uint local_890;
  longlong local_888;
  longlong local_880;
  longlong local_878;
  longlong local_870;
  undefined8 local_868;
  longlong *local_860;
  longlong *local_858;
  char local_848 [1023];
  undefined1 local_449;
  char local_448 [1023];
  undefined1 local_49;
  ulonglong local_48;
  
  local_868 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_8b8;
  local_888 = param_1;
  local_870 = param_2;
  if (param_2 == 0) {
    local_898 = 0x2e6;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 10;
  }
  else if (param_3 == (undefined4 *)0x0) {
    local_898 = 0x2ea;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 10;
  }
  else if (*(short *)(param_3 + 1) == 4) {
    _snprintf(local_448,0x400,"SELECT id,money,money_saved FROM cq_user WHERE id=%u LIMIT 1");
    local_49 = 0;
    FUN_140008520(*(undefined4 *)(param_1 + 0x108));
    plVar7 = (longlong *)InstanceGet();
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,local_448,2);
    local_858 = plVar7;
    if ((plVar7 == (longlong *)0x0) || (lVar8 = (**(code **)(*plVar7 + 0x40))(plVar7), lVar8 == 0))
    {
      if (plVar7 != (longlong *)0x0) {
        (**(code **)*plVar7)(plVar7);
      }
      uVar3 = 4;
    }
    else {
      plVar9 = (longlong *)(**(code **)(*plVar7 + 0x38))(plVar7);
      local_860 = plVar9;
      if (plVar9 == (longlong *)0x0) {
        local_898 = 0x302;
        log_InlineLogERROR(&DAT_1406d9c10);
        (**(code **)*plVar7)(plVar7);
        uVar3 = 9;
      }
      else {
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"money");
        uVar4 = (**(code **)(*plVar10 + 0x40))(plVar10);
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"money_saved");
        lVar8 = (**(code **)(*plVar10 + 0x60))(plVar10);
        local_878 = lVar8;
        if (lVar8 + (ulonglong)uVar4 < (ulonglong)(uint)param_3[2]) {
          (**(code **)*plVar9)(plVar9,CONCAT71((int7)(lVar8 + (ulonglong)uVar4 >> 8),1));
          (**(code **)*plVar7)(plVar7);
          uVar3 = 8;
        }
        else {
          plVar10 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            local_898 = 0x3c0;
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar10 = (longlong *)0x0;
          }
          local_890 = local_890 & 0xffffff00;
          local_898 = 0;
          plVar10 = (longlong *)(**(code **)(*plVar10 + 0x18))(plVar10,729999,param_3[4],0xcd);
          if (plVar10 == (longlong *)0x0) {
            local_898 = 0x312;
            log_InlineLogERROR(&DAT_1406d9c10);
            (**(code **)*plVar9)(plVar9,1);
            (**(code **)*plVar7)(plVar7);
            uVar3 = 0;
          }
          else {
            uVar11 = FUN_140008520(*(undefined4 *)(local_888 + 0x108));
            plVar12 = (longlong *)FUN_140087650(uVar11);
            local_880 = (**(code **)(*plVar12 + 0x98))(plVar12,param_3[3]);
            if (local_880 != 0) {
              uVar11 = FUN_140008520(*(undefined4 *)(local_888 + 0x108));
              plVar12 = (longlong *)FUN_140087650(uVar11);
              (**(code **)(*plVar12 + 0x68))(plVar12,*(undefined4 *)(local_880 + 0xf10),600);
              uVar11 = FUN_140008520(*(undefined4 *)(local_888 + 0x108));
              plVar12 = (longlong *)FUN_140087650(uVar11);
              (**(code **)(*plVar12 + 0x50))(plVar12,local_880,&DAT_140709758);
            }
            FUN_140104140(plVar10,0xd,param_3[2],1);
            uVar1 = param_3[2];
            if (uVar4 < uVar1) {
              lVar8 = lVar8 - (ulonglong)(uVar1 - uVar4);
              local_878 = lVar8;
            }
            uVar5 = uVar4;
            if (uVar1 < uVar4) {
              uVar5 = uVar1;
            }
            plVar12 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"money");
            (**(code **)(*plVar12 + 0xb8))(plVar12,uVar4 - uVar5);
            plVar12 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"money_saved");
            (**(code **)(*plVar12 + 0x98))(plVar12,lVar8);
            (**(code **)(*plVar9 + 0x38))(plVar9,1);
            uVar11 = FUN_140008520(*(undefined4 *)(local_888 + 0x108));
            plVar12 = (longlong *)FUN_140087650(uVar11);
            lVar8 = (**(code **)(*plVar12 + 0x98))(plVar12,param_3[4]);
            if (lVar8 != 0) {
              pIVar13 = theInstance();
              lVar2 = *(longlong *)(lVar8 + 0x10);
              uVar11 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_GIVEBACK_MONEY");
              (**(code **)(lVar2 + 0x358))(lVar8 + 0x10,uVar11,param_3[2]);
            }
            local_890 = *param_3;
            local_898 = param_3[2];
            _snprintf(local_848,0x400,"%d %u %u");
            local_449 = 0;
            plVar12 = (longlong *)FUN_1400e1de0();
            lVar8 = *plVar12;
            local_890 = (**(code **)(*plVar10 + 8))(plVar10);
            local_898 = 1;
            (**(code **)(lVar8 + 8))(plVar12,"SYSTEM",param_3[3],local_848);
            plVar12 = (longlong *)FUN_1400e1de0();
            lVar8 = *plVar12;
            local_890 = (**(code **)(*plVar10 + 8))(plVar10);
            local_898 = 2;
            (**(code **)(lVar8 + 8))(plVar12,"SYSTEM",param_3[4],local_848);
            uVar3 = FUN_1400fda10(plVar10,1,1);
            uVar6 = (**(code **)(*plVar10 + 8))(plVar10);
            local_898 = uVar3;
            FUN_14010b4b0(local_888,local_870,param_3,uVar6);
            plVar12 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_898 = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar12 = (longlong *)0x0;
            }
            lVar8 = *plVar12;
            uVar3 = (**(code **)(*plVar10 + 8))(plVar10);
            (**(code **)(lVar8 + 0x58))(plVar12,uVar3,0);
            (**(code **)*plVar9)(plVar9,1);
            (**(code **)*plVar7)(plVar7);
            uVar3 = 1;
          }
        }
      }
    }
  }
  else {
    uVar3 = 9;
  }
  return uVar3;
}

// ==== CMsgGiveBack::helper_14010e350  @14010e350  [medium:callgraph-r3]  (orig: FUN_14010e350)
longlong *
FUN_14010e350(longlong *param_1,longlong *param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  bool bVar5;
  bool bVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  longlong local_38;
  undefined8 *local_30;
  
  puVar9 = (undefined8 *)((undefined8 *)param_1[6])[1];
  bVar5 = true;
  cVar1 = *(char *)((longlong)puVar9 + 0x69);
  puVar3 = (undefined8 *)param_1[6];
  while (cVar1 == '\0') {
    bVar5 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      (param_3,(basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                               (puVar9 + 3));
    if (bVar5) {
      puVar8 = (undefined8 *)*puVar9;
    }
    else {
      puVar8 = (undefined8 *)puVar9[2];
    }
    puVar3 = puVar9;
    puVar9 = puVar8;
    cVar1 = *(char *)((longlong)puVar8 + 0x69);
  }
  lVar2 = *param_1;
  puVar9 = puVar3;
  local_38 = lVar2;
  puVar8 = puVar3;
  if (bVar5 == false) {
LAB_14010e49d:
    local_30 = puVar8;
    bVar6 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       (puVar9 + 3),param_3);
    if (!bVar6) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14010e4d5;
    }
  }
  else {
    puVar9 = *(undefined8 **)param_1[6];
    local_30 = puVar3;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar3 != puVar9) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar3 + 0x69) == '\0') {
        puVar9 = (undefined8 *)*puVar3;
        if (*(char *)((longlong)puVar9 + 0x69) == '\0') {
          cVar1 = *(char *)((longlong)puVar9[2] + 0x69);
          puVar4 = (undefined8 *)puVar9[2];
          while (puVar8 = puVar9, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar4[2] + 0x69);
            puVar9 = puVar4;
            puVar4 = (undefined8 *)puVar4[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar3[1] + 0x69);
          puVar8 = (undefined8 *)puVar3[1];
          puVar4 = puVar3;
          while ((puVar9 = puVar8, cVar1 == '\0' && (puVar4 == (undefined8 *)*puVar9))) {
            cVar1 = *(char *)((longlong)puVar9[1] + 0x69);
            puVar8 = (undefined8 *)puVar9[1];
            puVar4 = puVar9;
            local_30 = puVar9;
          }
          puVar8 = puVar9;
          if (*(char *)((longlong)puVar4 + 0x69) != '\0') {
            _invalid_parameter_noinfo();
            puVar9 = puVar4;
            puVar8 = local_30;
          }
        }
      }
      else {
        puVar9 = (undefined8 *)puVar3[2];
        puVar8 = puVar9;
        if (*(char *)((longlong)puVar9 + 0x69) != '\0') {
          local_30 = puVar9;
          _invalid_parameter_noinfo();
          puVar8 = local_30;
        }
      }
      goto LAB_14010e49d;
    }
    bVar5 = true;
  }
  plVar7 = (longlong *)FUN_14010db20(param_1,&local_38,bVar5,puVar3,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar7[1];
  *param_2 = *plVar7;
LAB_14010e4d5:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgGiveBack::helper_14010e500  @14010e500  [medium:callgraph-r3]  (orig: FUN_14010e500)
undefined8 * FUN_14010e500(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x69) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14010bb70(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x69) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x69) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x69) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0xd;
        plVar8 = plVar8 + 0xd;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14010e6ec;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x69) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x69) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x69);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x69);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x69) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x69);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x69);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14010e6ec:
  if ((char)plVar2[0xd] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0xd] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0xd] == '\0') {
            *(undefined1 *)(plVar9 + 0xd) = 1;
            *(undefined1 *)(plVar8 + 0xd) = 0;
            FUN_14010ce90(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x69) == '\0') {
            if ((*(char *)(*plVar9 + 0x68) != '\x01') || (*(char *)(plVar9[2] + 0x68) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x68) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x68) = 1;
                *(undefined1 *)(plVar9 + 0xd) = 0;
                FUN_14010b9c0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0xd) = (char)plVar8[0xd];
              *(undefined1 *)(plVar8 + 0xd) = 1;
              *(undefined1 *)(plVar9[2] + 0x68) = 1;
              FUN_14010ce90(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xd) = 0;
          }
        }
        else {
          if ((char)plVar9[0xd] == '\0') {
            *(undefined1 *)(plVar9 + 0xd) = 1;
            *(undefined1 *)(plVar8 + 0xd) = 0;
            FUN_14010b9c0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x69) == '\0') {
            if ((*(char *)(plVar9[2] + 0x68) != '\x01') || (*(char *)(*plVar9 + 0x68) != '\x01')) {
              if (*(char *)(*plVar9 + 0x68) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x68) = 1;
                *(undefined1 *)(plVar9 + 0xd) = 0;
                FUN_14010ce90(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0xd) = (char)plVar8[0xd];
              *(undefined1 *)(plVar8 + 0xd) = 1;
              *(undefined1 *)(*plVar9 + 0x68) = 1;
              FUN_14010b9c0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xd) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0xd) = 1;
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(plVar2 + 3));
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMsgGiveBack::helper_14010e910  @14010e910  [medium:callgraph-r3]  (orig: FUN_14010e910)
longlong *
FUN_14010e910(longlong *param_1,longlong *param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  char cVar1;
  undefined8 *puVar2;
  bool bVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)((undefined8 *)param_1[6])[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x69);
  puVar2 = (undefined8 *)param_1[6];
  while (cVar1 == '\0') {
    bVar3 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       (puVar6 + 3),param_3);
    if (bVar3) {
      puVar5 = (undefined8 *)puVar6[2];
      puVar6 = puVar2;
    }
    else {
      puVar5 = (undefined8 *)*puVar6;
    }
    puVar2 = puVar6;
    puVar6 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x69);
  }
  puVar6 = (undefined8 *)param_1[6];
  local_20 = puVar2;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar6) ||
     (bVar3 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                        (param_3,(basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                                 (puVar2 + 3)), bVar3)) {
    plVar4 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar4 = &local_28;
  }
  *param_2 = *plVar4;
  param_2[1] = plVar4[1];
  return param_2;
}

// ==== CMsgGiveBack::helper_14010ee60  @14010ee60  [medium:callgraph-r2]  (orig: FUN_14010ee60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

char FUN_14010ee60(longlong param_1,char *param_2,char *param_3)

{
  char cVar1;
  char cVar2;
  longlong lVar3;
  ulong uVar4;
  longlong *plVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  char *pcVar8;
  longlong lVar9;
  undefined1 auStack_558 [32];
  char *local_538;
  char *local_530;
  longlong *local_528;
  undefined4 local_518;
  undefined4 uStack_514;
  undefined4 uStack_510;
  undefined4 uStack_50c;
  longlong *local_508 [3];
  undefined8 local_4f0;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_4e8 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_4c0 [80];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_470 [16];
  char local_460 [16];
  ulong local_450;
  char local_448 [1023];
  undefined1 local_49;
  ulonglong local_48;
  
  local_4f0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_558;
  if (param_2 != (char *)0x0) {
    uVar7 = 0xffffffffffffffff;
    pcVar8 = param_2;
    do {
      if (uVar7 == 0) break;
      uVar7 = uVar7 - 1;
      cVar1 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar1 != '\0');
    if ((~uVar7 != 1) && (~uVar7 - 1 < 0x10)) {
      if (param_3 != (char *)0x0) {
        uVar7 = 0xffffffffffffffff;
        pcVar8 = param_3;
        do {
          if (uVar7 == 0) break;
          uVar7 = uVar7 - 1;
          cVar1 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar1 != '\0');
        if ((~uVar7 != 1) && (~uVar7 - 1 < 0x10)) {
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470,param_2);
          FUN_14010e910(param_1 + 200,&local_518,local_470);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470);
          local_528 = *(longlong **)(param_1 + 0xf8);
          lVar9 = 0;
          local_508[0] = *(longlong **)(param_1 + 200);
          plVar5 = (longlong *)CONCAT44(uStack_514,local_518);
          if ((plVar5 == (longlong *)0x0) || (plVar5 != local_508[0])) {
            _invalid_parameter_noinfo();
          }
          lVar3 = CONCAT44(uStack_50c,uStack_510);
          if ((longlong *)lVar3 == local_528) {
            local_538 = param_2;
            local_530 = param_3;
            _snprintf(local_448,0x400,
                      "SELECT * FROM %s where name=\'%s\' AND password=MD5(\'%s\') LIMIT 1",
                      s_cq_virtual_gm_14094c8f8);
            local_49 = 0;
            FUN_140008520(*(undefined4 *)(param_1 + 0x108));
            plVar5 = (longlong *)InstanceGet();
            plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,local_448,2);
            local_528 = plVar5;
            if ((plVar5 != (longlong *)0x0) &&
               (lVar9 = (**(code **)(*plVar5 + 0x40))(plVar5), lVar9 != 0)) {
              local_450 = tq::TimeGet(1);
              tq::SafeCopy((char *)local_470,param_2,0x10);
              tq::SafeCopy(local_460,param_3,0x10);
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8,param_2);
              uVar6 = FUN_14010b870(local_4c0,local_4e8,local_470);
              FUN_14010e350(param_1 + 200,local_508,uVar6);
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4c0);
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
              (**(code **)*plVar5)(plVar5);
              return '\x01';
            }
            if (plVar5 != (longlong *)0x0) {
              (**(code **)*plVar5)(plVar5);
            }
            return '\x02';
          }
          if (plVar5 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar9 = *plVar5;
          }
          if (lVar3 == *(longlong *)(lVar9 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          uVar4 = tq::TimeGet(1);
          if (0xe0f < uVar4 - *(int *)(lVar3 + 0x60)) {
            FUN_14010e500(param_1 + 200,local_508,&local_518);
            return '\x02';
          }
          pcVar8 = (char *)(lVar3 + 0x50);
          lVar9 = (longlong)param_3 - (longlong)pcVar8;
          do {
            cVar1 = *pcVar8;
            cVar2 = pcVar8[lVar9];
            if (cVar1 != cVar2) break;
            pcVar8 = pcVar8 + 1;
          } while (cVar2 != '\0');
          return (cVar1 != cVar2) + '\x01';
        }
      }
      local_538 = (char *)CONCAT44(local_538._4_4_,0x3a3);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",
                         "pszPwd && strlen(pszPwd) > 0 && strlen(pszPwd) < _MAX_NAMESIZE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\lostitemmgr.cpp"
                        );
      return '\0';
    }
  }
  local_538 = (char *)CONCAT44(local_538._4_4_,0x3a2);
  log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",
                     "pszName && strlen(pszName) > 0 && strlen(pszName) < _MAX_NAMESIZE",
                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\lostitemmgr.cpp"
                    );
  return '\0';
}

// ==== CMsgGiveBack::helper_14010f560  @14010f560  [medium:callgraph-r3]  (orig: FUN_14010f560)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_14010f560(longlong param_1,longlong param_2,undefined4 *param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong lVar13;
  IStringManager *pIVar14;
  undefined8 uVar15;
  longlong *plVar16;
  undefined1 auStack_1588 [32];
  int local_1568;
  undefined4 local_1560;
  longlong *local_1558;
  longlong *local_1550;
  undefined4 *local_1548;
  longlong *local_1540;
  longlong *local_1538;
  longlong local_1530;
  longlong *local_1528;
  uint local_1520;
  uint local_151c;
  longlong *local_1518;
  uint local_1510;
  uint local_150c;
  longlong *local_1508 [3];
  longlong *local_14f0;
  longlong *local_14e8;
  undefined8 local_14e0;
  longlong *local_14d8 [3];
  void *local_14c0;
  undefined8 local_14b8;
  undefined8 local_14b0;
  longlong local_14a8;
  longlong *local_14a0 [3];
  void *local_1488;
  undefined8 local_1480;
  undefined8 local_1478;
  longlong *local_1470;
  longlong *local_1460;
  undefined8 local_1450;
  char local_1448;
  undefined1 local_1447 [1022];
  undefined1 local_1049;
  char local_1048 [1023];
  undefined1 local_c49;
  char local_c48 [1023];
  undefined1 local_849;
  char local_848 [1023];
  undefined1 local_449;
  char local_448 [1023];
  undefined1 local_49;
  ulonglong local_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x14010f576;
  local_1450 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_1588;
  local_1548 = param_3;
  local_1530 = param_1;
  local_14a8 = param_2;
  if (param_2 == 0) {
    local_1568 = 0xb1;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 10;
  }
  else if (param_3 == (undefined4 *)0x0) {
    local_1568 = 0xb5;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 10;
  }
  else if (*(short *)(param_3 + 1) == 1) {
    iVar2 = param_3[2];
    local_1538 = (longlong *)CONCAT44(local_1538._4_4_,iVar2);
    if (iVar2 == 0) {
      uVar3 = 5;
    }
    else {
      plVar16 = (longlong *)0x0;
      local_1550 = (longlong *)0x0;
      plVar6 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_1568 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar6 = plVar16;
      }
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x60))(plVar6,iVar2);
      local_1550 = plVar6;
      if (plVar6 == (longlong *)0x0) {
        local_1568 = iVar2;
        _snprintf(local_448,0x400,"SELECT * FROM cq_item WHERE player_id=%u AND id=%u LIMIT 1");
        local_49 = 0;
        local_1558 = (longlong *)(local_1530 + 0x108);
        FUN_140008520(*(undefined4 *)local_1558);
        plVar6 = (longlong *)InstanceGet();
        plVar7 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,local_448,2);
        local_1540 = plVar7;
        if ((plVar7 == (longlong *)0x0) ||
           (lVar8 = (**(code **)(*plVar7 + 0x40))(plVar7), lVar8 == 0)) {
          if (plVar7 != (longlong *)0x0) {
            (**(code **)*plVar7)(plVar7);
          }
          return 5;
        }
        plVar6 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_1568 = 0x3c0;
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar6 = plVar16;
        }
        lVar8 = *plVar6;
        uVar9 = (**(code **)(*plVar7 + 0x38))(plVar7);
        plVar6 = (longlong *)(**(code **)(lVar8 + 0x10))(plVar6,uVar9,0);
        local_1550 = plVar6;
        if (plVar6 == (longlong *)0x0) {
          local_1568 = 0xd2;
          log_InlineLogERROR(&DAT_1406d9c10);
          (**(code **)*plVar7)(plVar7);
          return 10;
        }
        iVar2 = FUN_1400fda10(plVar6,7,1);
        if (iVar2 == 0xce) {
          _snprintf(&local_1448,0x400,"SELECT id FROM cq_mail WHERE item_id=%u");
          FUN_140008520((int)*local_1558);
          plVar10 = (longlong *)InstanceGet();
          plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,&local_1448,2);
          local_151c = 0;
          plVar10 = plVar16;
          while( true ) {
            iVar2 = (**(code **)(*plVar11 + 0x40))(plVar11);
            iVar4 = (int)plVar10;
            if (iVar2 <= iVar4) break;
            (**(code **)(*plVar11 + 0x30))(plVar11,(longlong)iVar4);
            plVar10 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,&DAT_1406de8d4);
            (**(code **)(*plVar10 + 0x40))(plVar10);
            tq::MyLogSave("gmlog/GiveBack_Opt_VirGM",
                          "OffLine Delete ID[%u] item[%u] from Mail success!");
            local_151c = iVar4 + 1;
            plVar10 = (longlong *)(ulonglong)local_151c;
          }
          (**(code **)*plVar11)(plVar11);
          _snprintf(&local_1448,0x400,"Delete FROM cq_mail WHERE item_id=%u");
          plVar10 = (longlong *)(local_1530 + 0x108);
          FUN_140008520(*(undefined4 *)plVar10);
          plVar11 = (longlong *)InstanceGet();
          (**(code **)(*plVar11 + 0x30))(plVar11,&local_1448,0,0);
        }
        else {
          plVar10 = local_1558;
          if ((((0x1d < iVar2) && (iVar2 != 0xc9)) && (iVar2 != 0xcb)) &&
             ((iVar2 != 0xca && (iVar2 != 0xd0)))) {
            log_InlineLogWARNING
                      ("CLostItemMgr::ProcessGiveBackTradeItem. OffLine Item[%u] Position[%d] Error"
                      );
            plVar10 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_1568 = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar10 = plVar16;
            }
            lVar8 = *plVar10;
            uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
            (**(code **)(lVar8 + 0x58))(plVar10,uVar3,0);
            (**(code **)*plVar7)(plVar7);
            return 10;
          }
        }
        uVar3 = FUN_1400fda10(plVar6,1,1);
        cVar1 = FUN_1400ff940(uVar3);
        if (cVar1 != '\0') {
          memset(local_1048,0,0x400);
          (**(code **)(*plVar6 + 8))(plVar6);
          _snprintf(local_1048,0x400,"SELECT * FROM cq_itemstatus WHERE iditem=%u");
          local_c49 = 0;
          FUN_140008520((int)*plVar10);
          plVar10 = (longlong *)InstanceGet();
          plVar10 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,local_1048,2);
          local_1518 = plVar10;
          if (((plVar10 == (longlong *)0x0) ||
              (lVar8 = (**(code **)(*plVar10 + 0x40))(plVar10), lVar8 == 0)) &&
             (plVar10 != (longlong *)0x0)) {
            (**(code **)*plVar10)(plVar10);
            local_1518 = (longlong *)0x0;
            plVar10 = plVar16;
          }
          if (plVar10 != (longlong *)0x0) {
            local_1558 = operator_new(8);
            local_14a0[0] = plVar16;
            if (local_1558 != (longlong *)0x0) {
              *local_1558 = (longlong)local_14a0;
              local_14a0[0] = local_1558;
            }
            local_1488 = (void *)0x0;
            local_1480 = 0;
            local_1478 = 0;
            local_1538 = local_1558;
            (**(code **)(*plVar10 + 0x30))(plVar10,0);
            local_1520 = 0;
            plVar11 = plVar16;
            while( true ) {
              plVar12 = (longlong *)(**(code **)(*plVar10 + 0x40))(plVar10);
              if (plVar12 <= plVar11) break;
              (**(code **)(*plVar10 + 0x30))(plVar10,plVar11);
              local_1558 = (longlong *)(**(code **)(*plVar10 + 0x38))(plVar10);
              FUN_140019370(local_14a0,&local_1558);
              local_1520 = (int)plVar11 + 1;
              plVar11 = (longlong *)(ulonglong)local_1520;
            }
            FUN_140108580(plVar6,local_14a0,0);
            (**(code **)*plVar10)(plVar10);
            local_1518 = (longlong *)0x0;
            if (local_1488 != (void *)0x0) {
              operator_delete(local_1488);
            }
            local_1488 = (void *)0x0;
            local_1480 = 0;
            local_1478 = 0;
            operator_delete(local_14a0[0]);
          }
        }
        if (plVar7 != (longlong *)0x0) {
          (**(code **)*plVar7)(plVar7);
        }
      }
      else {
        iVar4 = FUN_1400fda10(plVar6,7,1);
        if (iVar4 == 0xca) {
          plVar7 = (longlong *)CurrentInstanceGet();
          plVar7 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,0x12);
          if (plVar7 == (longlong *)0x0) {
            log_InlineLogERROR("CLostItemMgr::ProcessGiveBackTradeItem. NULL == pIProider");
            return 10;
          }
          cVar1 = (**(code **)(*plVar7 + 0x40))(plVar7,param_3[3],iVar2,0x14);
          if (cVar1 == '\0') {
            log_InlineLogERROR(&DAT_14070a120);
            return 10;
          }
          lVar8 = *plVar7;
          uVar3 = FUN_1400fda10(plVar6,2,1);
          cVar1 = (**(code **)(lVar8 + 0x38))(plVar7,param_3[3],uVar3,iVar2);
          if (cVar1 == '\0') {
            log_InlineLogERROR(&DAT_14070a0d0);
            return 10;
          }
        }
        else if (iVar4 == 0xce) {
          _snprintf(local_1048,0x400,"SELECT id FROM cq_mail WHERE item_id=%u");
          FUN_140008520(*(undefined4 *)(local_1530 + 0x108));
          plVar7 = (longlong *)InstanceGet();
          plVar10 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,local_1048,2);
          local_1510 = 0;
          plVar7 = plVar16;
          while( true ) {
            iVar2 = (**(code **)(*plVar10 + 0x40))(plVar10);
            iVar4 = (int)plVar7;
            if (iVar2 <= iVar4) break;
            (**(code **)(*plVar10 + 0x30))(plVar10,(longlong)iVar4);
            plVar7 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,&DAT_1406de8d4);
            (**(code **)(*plVar7 + 0x40))(plVar7);
            tq::MyLogSave("gmlog/GiveBack_Opt_VirGM",
                          "OnLine Delete ID[%u] item[%u] from Mail success!");
            local_1510 = iVar4 + 1;
            plVar7 = (longlong *)(ulonglong)local_1510;
          }
          (**(code **)*plVar10)(plVar10);
          _snprintf(local_1048,0x400,"Delete FROM cq_mail WHERE item_id=%u");
          FUN_140008520(*(undefined4 *)(local_1530 + 0x108));
          plVar7 = (longlong *)InstanceGet();
          (**(code **)(*plVar7 + 0x30))(plVar7,local_1048,0,0);
        }
        else if ((((0x1d < iVar4) && (iVar4 != 0xc9)) && (iVar4 != 0xcb)) && (iVar4 != 0xd0)) {
          log_InlineLogWARNING
                    ("CLostItemMgr::ProcessGiveBackTradeItem. OnLine Item[%u] Position[%d] Error");
          return 10;
        }
      }
      if (plVar6 == (longlong *)0x0) {
        local_1568 = 0x145;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar3 = 10;
      }
      else {
        iVar2 = FUN_1400fda10(plVar6,3,1);
        lVar8 = local_1530;
        if (iVar2 == param_3[3]) {
          uVar9 = FUN_140008520(*(undefined4 *)(local_1530 + 0x108));
          plVar7 = (longlong *)FUN_140087650(uVar9);
          lVar13 = (**(code **)(*plVar7 + 0x98))(plVar7,param_3[3]);
          if (lVar13 != 0) {
            uVar9 = FUN_140008520(*(undefined4 *)(lVar8 + 0x108));
            plVar7 = (longlong *)FUN_140087650(uVar9);
            (**(code **)(*plVar7 + 0x68))(plVar7,*(undefined4 *)(lVar13 + 0xf10),600);
            uVar9 = FUN_140008520(*(undefined4 *)(lVar8 + 0x108));
            plVar7 = (longlong *)FUN_140087650(uVar9);
            (**(code **)(*plVar7 + 0x50))(plVar7,lVar13,&DAT_14070a028);
          }
          iVar2 = FUN_1400fda10(plVar6,0x17,1);
          if (iVar2 != 0) {
            plVar7 = (longlong *)FUN_140087f50();
            lVar13 = *plVar7;
            uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
            (**(code **)(lVar13 + 0x48))(plVar7,param_3[3],uVar3);
            FUN_140104140(plVar6,0x17,0);
          }
          cVar1 = FUN_1400ff650(plVar6);
          if (cVar1 != '\0') {
            local_1448 = '\0';
            memset(local_1447,0,0x3ff);
            local_1568 = (**(code **)(*plVar6 + 8))(plVar6);
            _snprintf(&local_1448,0x400,
                      "UPDATE GhostContract SET owner_id = %u WHERE Item_id = %u LIMIT 1");
            local_1049 = 0;
            FUN_140008520(*(undefined4 *)(lVar8 + 0x108));
            plVar7 = (longlong *)InstanceGet();
            (**(code **)(*plVar7 + 0x30))(plVar7,&local_1448,1);
          }
          FUN_140104140(plVar6,2,param_3[4]);
          FUN_140104140(plVar6,3,param_3[4]);
          FUN_140104140(plVar6,7,0xcd);
          FUN_140104140(plVar6,0x12,0,1);
          uVar9 = FUN_140008520(*(undefined4 *)(lVar8 + 0x108));
          plVar7 = (longlong *)FUN_140087650(uVar9);
          local_1540 = (longlong *)(**(code **)(*plVar7 + 0x98))(plVar7,param_3[4]);
          local_1558 = operator_new(8);
          local_1508[0] = plVar16;
          if (local_1558 != (longlong *)0x0) {
            *local_1558 = (longlong)local_1508;
            local_1508[0] = local_1558;
          }
          local_14f0 = (longlong *)0x0;
          local_14e8 = (longlong *)0x0;
          local_14e0 = 0;
          local_1538 = local_1558;
          FUN_140109210(plVar6,local_1508);
          if (((longlong)local_14e8 - (longlong)local_14f0 & 0xfffffffffffffff8U) == 0) {
            uVar3 = FUN_1400fda10(plVar6,1,1);
            cVar1 = FUN_1400ff940(uVar3);
            if (cVar1 != '\0') {
              memset(local_848,0,0x400);
              (**(code **)(*plVar6 + 8))(plVar6);
              _snprintf(local_848,0x400,"SELECT * FROM cq_itemstatus WHERE iditem=%u");
              local_449 = 0;
              FUN_140008520(*(undefined4 *)(lVar8 + 0x108));
              plVar7 = (longlong *)InstanceGet();
              plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,local_848,2);
              local_1528 = plVar7;
              if (((plVar7 == (longlong *)0x0) ||
                  (lVar8 = (**(code **)(*plVar7 + 0x40))(plVar7), lVar8 == 0)) &&
                 (plVar7 != (longlong *)0x0)) {
                (**(code **)*plVar7)(plVar7);
                local_1528 = (longlong *)0x0;
                plVar7 = plVar16;
              }
              if (plVar7 != (longlong *)0x0) {
                local_1558 = operator_new(8);
                local_14d8[0] = plVar16;
                if (local_1558 != (longlong *)0x0) {
                  *local_1558 = (longlong)local_14d8;
                  local_14d8[0] = local_1558;
                }
                local_14c0 = (void *)0x0;
                local_14b8 = 0;
                local_14b0 = 0;
                local_150c = 0;
                plVar10 = plVar16;
                local_1538 = local_1558;
                while( true ) {
                  plVar11 = (longlong *)(**(code **)(*plVar7 + 0x40))(plVar7);
                  if (plVar11 <= plVar10) break;
                  (**(code **)(*plVar7 + 0x30))(plVar7,plVar10);
                  local_1538 = (longlong *)(**(code **)(*plVar7 + 0x38))(plVar7);
                  FUN_140019370(local_14d8,&local_1538);
                  local_150c = (int)plVar10 + 1;
                  plVar10 = (longlong *)(ulonglong)local_150c;
                }
                FUN_140108580(plVar6,local_14d8,0);
                (**(code **)*plVar7)(plVar7);
                local_1528 = (longlong *)0x0;
                FUN_140109210(plVar6,local_1508);
                if (local_14c0 != (void *)0x0) {
                  operator_delete(local_14c0);
                }
                local_14c0 = (void *)0x0;
                local_14b8 = 0;
                local_14b0 = 0;
                operator_delete(local_14d8[0]);
              }
            }
          }
          plVar10 = local_14f0;
          plVar7 = local_1540;
          if (0 < (int)((longlong)local_14e8 - (longlong)local_14f0 >> 3)) {
            local_1460 = (longlong *)0x0;
            if (local_14e8 < local_14f0) {
              _invalid_parameter_noinfo();
            }
            plVar11 = local_1508[0];
            local_1460 = local_1508[0];
            while( true ) {
              plVar12 = local_14e8;
              local_1470 = (longlong *)0x0;
              if (local_14e8 < local_14f0) {
                _invalid_parameter_noinfo();
              }
              local_1470 = local_1508[0];
              if ((plVar11 == (longlong *)0x0) || (plVar11 != local_1508[0])) {
                _invalid_parameter_noinfo();
              }
              plVar7 = local_1540;
              if (plVar10 == plVar12) break;
              if (plVar11 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar7 = plVar16;
              }
              else {
                plVar7 = (longlong *)*plVar11;
              }
              if ((longlong *)plVar7[4] <= plVar10) {
                _invalid_parameter_noinfo();
              }
              plVar7 = (longlong *)*plVar10;
              if (plVar7 != (longlong *)0x0) {
                (**(code **)(*plVar7 + 0x38))(plVar7,2);
                (**(code **)(*plVar7 + 0x38))(plVar7,9);
                (**(code **)(*plVar7 + 0x50))(plVar7);
              }
              if (plVar11 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar7 = plVar16;
              }
              else {
                plVar7 = (longlong *)*plVar11;
              }
              if ((longlong *)plVar7[4] <= plVar10) {
                _invalid_parameter_noinfo();
              }
              plVar10 = plVar10 + 1;
            }
            if (local_1540 != (longlong *)0x0) {
              uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
              FUN_14019a030(plVar7,uVar3,0,0);
            }
          }
          if (local_14f0 != (longlong *)0x0) {
            operator_delete(local_14f0);
          }
          local_14f0 = (longlong *)0x0;
          local_14e8 = (longlong *)0x0;
          local_14e0 = 0;
          operator_delete(local_1508[0]);
          if (plVar7 != (longlong *)0x0) {
            plVar10 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_1568 = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar10 = plVar16;
            }
            lVar8 = *plVar10;
            uVar3 = FUN_1400fda10(plVar6,1,1);
            lVar8 = (**(code **)(lVar8 + 0x70))(plVar10,uVar3);
            if (lVar8 == 0) {
              local_1568 = 0x1a5;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              pIVar14 = theInstance();
              plVar10 = (longlong *)
                        (**(code **)(**(longlong **)(lVar8 + 8) + 0x10))
                                  (*(longlong **)(lVar8 + 8),1);
              uVar9 = (**(code **)(*plVar10 + 0x78))(plVar10);
              lVar8 = *(longlong *)((longlong)plVar7 + 0x10);
              uVar15 = (*(code *)**(undefined8 **)pIVar14)(pIVar14,"STR_GIVEBACK_ITEM");
              (**(code **)(lVar8 + 0x358))((longlong *)((longlong)plVar7 + 0x10),uVar15,uVar9);
            }
          }
          local_1568 = FUN_1400fda10(plVar6,1,1);
          local_1560 = *param_3;
          _snprintf(local_c48,0x400,"%d %u %u");
          local_849 = 0;
          plVar7 = (longlong *)FUN_1400e1de0();
          lVar8 = *plVar7;
          local_1560 = (**(code **)(*plVar6 + 8))(plVar6);
          local_1568 = 1;
          (**(code **)(lVar8 + 8))(plVar7,"SYSTEM",param_3[3],local_c48);
          plVar7 = (longlong *)FUN_1400e1de0();
          lVar8 = *plVar7;
          local_1560 = (**(code **)(*plVar6 + 8))(plVar6);
          local_1568 = 2;
          (**(code **)(lVar8 + 8))(plVar7,"SYSTEM",param_3[4],local_c48);
          uVar3 = FUN_1400fda10(plVar6,1,1);
          uVar5 = (**(code **)(*plVar6 + 8))(plVar6);
          local_1568 = uVar3;
          FUN_14010b4b0(local_1530,local_14a8,param_3,uVar5);
          plVar7 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            local_1568 = 0x3c0;
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar7 = plVar16;
          }
          lVar8 = *plVar7;
          uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
          (**(code **)(lVar8 + 0x58))(plVar7,uVar3,0);
          uVar3 = 1;
        }
        else {
          uVar3 = 5;
        }
      }
    }
  }
  else {
    uVar3 = 9;
  }
  return uVar3;
}

// ==== CMsgGiveBack::helper_140110670  @140110670  [medium:callgraph-r3]  (orig: FUN_140110670)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_140110670(longlong param_1,longlong param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  IStringManager *pIVar13;
  undefined8 uVar14;
  longlong *plVar15;
  longlong *plVar16;
  undefined1 auStack_968 [32];
  int local_948;
  undefined4 local_940;
  char local_938;
  longlong local_930;
  longlong *local_928;
  longlong *local_920;
  undefined4 *local_918;
  longlong *local_910;
  longlong *local_908;
  uint local_900;
  undefined4 *local_8f8;
  longlong *local_8f0;
  longlong local_8e8;
  longlong *local_8e0 [3];
  longlong *local_8c8;
  longlong *local_8c0;
  undefined8 local_8b8;
  longlong *local_8b0 [3];
  void *local_898;
  undefined8 local_890;
  undefined8 local_888;
  longlong *local_880;
  longlong local_870;
  undefined8 local_868;
  longlong *local_860;
  char local_848 [1023];
  undefined1 local_449;
  char local_448 [1023];
  undefined1 local_49;
  ulonglong local_48;
  
  local_868 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_968;
  local_930 = param_1;
  local_918 = param_3;
  local_8f8 = param_3;
  local_8e8 = param_1;
  local_870 = param_2;
  if (param_2 == 0) {
    local_948 = 0x1c1;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = 10;
  }
  else if (param_3 == (undefined4 *)0x0) {
    local_948 = 0x1c5;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = 10;
  }
  else if (*(short *)(param_3 + 1) == 1) {
    iVar1 = param_3[2];
    if (iVar1 == 0) {
      uVar4 = 5;
    }
    else {
      local_938 = '\0';
      memset(local_848,0,0x400);
      local_948 = iVar1;
      _snprintf(local_848,0x400,"SELECT * FROM cq_pk_item WHERE hunter=%u AND item=%u LIMIT 1");
      local_449 = 0;
      FUN_140008520(*(undefined4 *)(param_1 + 0x108));
      plVar6 = (longlong *)InstanceGet();
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,local_848,2);
      local_8f0 = plVar6;
      if ((plVar6 == (longlong *)0x0) || (lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6), lVar7 == 0)
         ) {
        if (plVar6 != (longlong *)0x0) {
          (**(code **)*plVar6)(plVar6);
        }
        uVar4 = 5;
      }
      else {
        plVar16 = (longlong *)0x0;
        local_920 = (longlong *)0x0;
        plVar8 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_948 = 0x3c0;
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar8 = plVar16;
        }
        plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))();
        local_920 = plVar8;
        if (plVar8 == (longlong *)0x0) {
          memset(local_848,0,0x400);
          _snprintf(local_848,0x400,"SELECT * FROM cq_item WHERE id=%u LIMIT 1");
          local_449 = 0;
          FUN_140008520(*(undefined4 *)(param_1 + 0x108));
          plVar8 = (longlong *)InstanceGet();
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,local_848,2);
          local_928 = plVar9;
          if ((plVar9 == (longlong *)0x0) ||
             (lVar7 = (**(code **)(*plVar9 + 0x40))(plVar9), lVar7 == 0)) {
            if (plVar9 != (longlong *)0x0) {
              (**(code **)*plVar9)(plVar9);
            }
            (**(code **)*plVar6)(plVar6);
            return 5;
          }
          plVar8 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            local_948 = 0x3c0;
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar8 = plVar16;
          }
          lVar7 = *plVar8;
          uVar10 = (**(code **)(*plVar9 + 0x38))(plVar9);
          plVar8 = (longlong *)(**(code **)(lVar7 + 0x10))(plVar8,uVar10,0);
          local_920 = plVar8;
          if (plVar8 == (longlong *)0x0) {
            local_948 = 0x1f0;
            log_InlineLogERROR(&DAT_1406d9c10);
            (**(code **)*plVar9)(plVar9);
            (**(code **)*plVar6)(plVar6);
            return 10;
          }
          local_938 = '\x01';
          uVar4 = FUN_1400fda10(plVar8,1,1);
          cVar3 = FUN_1400ff940(uVar4);
          if (cVar3 != '\0') {
            memset(local_848,0,0x400);
            (**(code **)(*plVar8 + 8))(plVar8);
            _snprintf(local_848,0x400,"SELECT * FROM cq_itemstatus WHERE iditem=%u");
            local_449 = 0;
            FUN_140008520(*(undefined4 *)(local_930 + 0x108));
            plVar11 = (longlong *)InstanceGet();
            plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,local_848,2);
            local_908 = plVar11;
            if (((plVar11 == (longlong *)0x0) ||
                (lVar7 = (**(code **)(*plVar11 + 0x40))(plVar11), lVar7 == 0)) &&
               (plVar11 != (longlong *)0x0)) {
              (**(code **)*plVar11)(plVar11);
              local_908 = (longlong *)0x0;
              plVar11 = plVar16;
            }
            if (plVar11 != (longlong *)0x0) {
              local_910 = operator_new(8);
              local_8b0[0] = plVar16;
              if (local_910 != (longlong *)0x0) {
                *local_910 = (longlong)local_8b0;
                local_8b0[0] = local_910;
              }
              local_898 = (void *)0x0;
              local_890 = 0;
              local_888 = 0;
              local_880 = local_910;
              (**(code **)(*plVar11 + 0x30))(plVar11,0);
              local_900 = 0;
              plVar15 = plVar16;
              while( true ) {
                plVar12 = (longlong *)(**(code **)(*plVar11 + 0x40))(plVar11);
                if (plVar12 <= plVar15) break;
                (**(code **)(*plVar11 + 0x30))(plVar11,plVar15);
                local_910 = (longlong *)(**(code **)(*plVar11 + 0x38))(plVar11);
                FUN_140019370(local_8b0,&local_910);
                local_900 = (int)plVar15 + 1;
                plVar15 = (longlong *)(ulonglong)local_900;
              }
              FUN_140108580(plVar8,local_8b0,0);
              (**(code **)*plVar11)(plVar11);
              local_908 = (longlong *)0x0;
              if (local_898 != (void *)0x0) {
                operator_delete(local_898);
              }
              local_898 = (void *)0x0;
              local_890 = 0;
              local_888 = 0;
              operator_delete(local_8b0[0]);
            }
          }
          if (plVar9 != (longlong *)0x0) {
            (**(code **)*plVar9)(plVar9);
          }
          param_1 = local_930;
          param_3 = local_918;
          if (plVar8 == (longlong *)0x0) {
            local_948 = 0x211;
            log_InlineLogERROR(&DAT_1406d9c10);
            if (plVar6 != (longlong *)0x0) {
              (**(code **)*plVar6)(plVar6);
            }
            return 10;
          }
        }
        plVar9 = (longlong *)CurrentInstanceGet();
        plVar9 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,0x13);
        if (plVar9 == (longlong *)0x0) {
          if (plVar6 != (longlong *)0x0) {
            (**(code **)*plVar6)(plVar6);
          }
          uVar4 = 10;
        }
        else {
          lVar7 = *plVar9;
          uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
          cVar3 = (**(code **)(lVar7 + 0x50))(plVar9,param_3[3],uVar4);
          if (cVar3 == '\0') {
            if (local_938 != '\0') {
              plVar9 = DAT_140975b60;
              if (DAT_140975b60 == (longlong *)0x0) {
                local_948 = 0x3c0;
                log_InlineLogERROR(&DAT_1406d9c10);
                plVar9 = plVar16;
              }
              lVar7 = *plVar9;
              uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
              (**(code **)(lVar7 + 0x58))(plVar9,uVar4,0);
            }
            if (plVar6 != (longlong *)0x0) {
              (**(code **)*plVar6)(plVar6);
            }
            uVar4 = 10;
          }
          else {
            FUN_140104140(plVar8,2,param_3[4]);
            FUN_140104140(plVar8,3,param_3[4]);
            FUN_140104140(plVar8,7,0xcd);
            FUN_140104140(plVar8,0x12,0,1);
            uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x108));
            plVar9 = (longlong *)FUN_140087650(uVar10);
            plVar9 = (longlong *)(**(code **)(*plVar9 + 0x98))(plVar9,param_3[4]);
            local_928 = plVar9;
            local_910 = operator_new(8);
            local_8e0[0] = plVar16;
            if (local_910 != (longlong *)0x0) {
              *local_910 = (longlong)local_8e0;
              local_8e0[0] = local_910;
            }
            local_8c8 = (longlong *)0x0;
            local_8c0 = (longlong *)0x0;
            local_8b8 = 0;
            local_880 = local_910;
            FUN_140109210(plVar8,local_8e0);
            plVar11 = local_8c8;
            if (0 < (int)((longlong)local_8c0 - (longlong)local_8c8 >> 3)) {
              local_880 = (longlong *)0x0;
              if (local_8c0 < local_8c8) {
                _invalid_parameter_noinfo();
              }
              plVar15 = local_8e0[0];
              local_880 = local_8e0[0];
              while( true ) {
                plVar12 = local_8c0;
                local_860 = (longlong *)0x0;
                if (local_8c0 < local_8c8) {
                  _invalid_parameter_noinfo();
                }
                local_860 = local_8e0[0];
                if ((plVar15 == (longlong *)0x0) || (plVar15 != local_8e0[0])) {
                  _invalid_parameter_noinfo();
                }
                plVar9 = local_928;
                if (plVar11 == plVar12) break;
                if (plVar15 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  plVar9 = plVar16;
                }
                else {
                  plVar9 = (longlong *)*plVar15;
                }
                if ((longlong *)plVar9[4] <= plVar11) {
                  _invalid_parameter_noinfo();
                }
                plVar9 = (longlong *)*plVar11;
                if (plVar9 != (longlong *)0x0) {
                  (**(code **)(*plVar9 + 0x38))(plVar9,2);
                  (**(code **)(*plVar9 + 0x38))(plVar9,9);
                  (**(code **)(*plVar9 + 0x50))(plVar9);
                }
                if (plVar15 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  plVar9 = plVar16;
                }
                else {
                  plVar9 = (longlong *)*plVar15;
                }
                if ((longlong *)plVar9[4] <= plVar11) {
                  _invalid_parameter_noinfo();
                }
                plVar11 = plVar11 + 1;
              }
            }
            if (plVar9 != (longlong *)0x0) {
              uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
              FUN_14019a030(plVar9,uVar4,0,0);
            }
            if (local_8c8 != (longlong *)0x0) {
              operator_delete(local_8c8);
            }
            local_8c8 = (longlong *)0x0;
            local_8c0 = (longlong *)0x0;
            local_8b8 = 0;
            operator_delete(local_8e0[0]);
            if (plVar9 != (longlong *)0x0) {
              plVar11 = DAT_140975b60;
              if (DAT_140975b60 == (longlong *)0x0) {
                local_948 = 0x3c0;
                log_InlineLogERROR(&DAT_1406d9c10);
                plVar11 = plVar16;
              }
              lVar7 = *plVar11;
              uVar4 = FUN_1400fda10(plVar8,1,1);
              lVar7 = (**(code **)(lVar7 + 0x70))(plVar11,uVar4);
              if (lVar7 == 0) {
                local_948 = 0x246;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                pIVar13 = theInstance();
                plVar11 = (longlong *)
                          (**(code **)(**(longlong **)(lVar7 + 8) + 0x10))
                                    (*(longlong **)(lVar7 + 8),1);
                uVar10 = (**(code **)(*plVar11 + 0x78))(plVar11);
                lVar7 = *(longlong *)((longlong)plVar9 + 0x10);
                uVar14 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_GIVEBACK_ITEM");
                (**(code **)(lVar7 + 0x358))((longlong *)((longlong)plVar9 + 0x10),uVar14,uVar10);
              }
            }
            local_948 = FUN_1400fda10(plVar8,1,1);
            puVar2 = local_918;
            local_940 = *local_918;
            _snprintf(local_448,0x400,"%d %u %u");
            local_49 = 0;
            plVar9 = (longlong *)FUN_1400e1de0();
            lVar7 = *plVar9;
            local_940 = (**(code **)(*plVar8 + 8))(plVar8);
            local_948 = 2;
            (**(code **)(lVar7 + 8))(plVar9,"SYSTEM",puVar2[4],local_448);
            uVar4 = FUN_1400fda10(plVar8,1,1);
            uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
            local_948 = uVar4;
            FUN_14010b4b0(local_930,local_870,puVar2,uVar5);
            plVar9 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_948 = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar9 = plVar16;
            }
            lVar7 = *plVar9;
            uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
            (**(code **)(lVar7 + 0x58))(plVar9,uVar4,0);
            if (plVar6 != (longlong *)0x0) {
              (**(code **)*plVar6)(plVar6);
            }
            uVar4 = 1;
          }
        }
      }
    }
  }
  else {
    uVar4 = 9;
  }
  return uVar4;
}

// ==== CMsgGiveBack::helper_140111320  @140111320  [medium:callgraph-r2]  (orig: FUN_140111320)
undefined8 FUN_140111320(undefined8 param_1,longlong param_2,longlong param_3)

{
  undefined8 uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 10;
  }
  else if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 10;
  }
  else if (*(short *)(param_3 + 4) == 1) {
    if (*(short *)(param_3 + 6) == 1) {
      uVar1 = FUN_14010f560();
    }
    else if (*(short *)(param_3 + 6) == 2) {
      uVar1 = FUN_140110670();
    }
    else {
      uVar1 = 9;
    }
  }
  else {
    uVar1 = 9;
  }
  return uVar1;
}

// ==== CMsgGiveBack::helper_1401113e0  @1401113e0  [medium:callgraph-r1]  (orig: FUN_1401113e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_1401113e0(longlong param_1,longlong param_2,int *param_3)

{
  short sVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  char *pcVar6;
  undefined1 auStack_488 [32];
  char *local_468;
  int local_460;
  char *local_458;
  undefined4 local_450;
  longlong *local_448;
  undefined8 local_440;
  char local_438 [1023];
  undefined1 local_39;
  ulonglong local_38;
  
  local_440 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (param_2 == 0) {
    local_468 = (char *)CONCAT44(local_468._4_4_,0x43);
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar2 = 10;
  }
  else if (param_3 == (int *)0x0) {
    local_468 = (char *)CONCAT44(local_468._4_4_,0x47);
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar2 = 10;
  }
  else if ((((*param_3 == 0) || (param_3[3] == 0)) || (param_3[4] == 0)) || (param_3[2] == 0)) {
    local_450 = 0x50;
    local_458 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\lostitemmgr.cpp";
    local_460 = param_3[2];
    local_468 = (char *)CONCAT44(local_468._4_4_,param_3[4]);
    tq::SysLogSave("miantuxing_error",&DAT_14070a4f0);
    iVar2 = 9;
  }
  else {
    iVar2 = FUN_14010ee60(param_1,param_2,param_2 + 0x10);
    if (iVar2 == 1) {
      _snprintf(local_438,0x400,"SELECT name FROM cq_user WHERE id=%u LIMIT 1");
      local_39 = 0;
      FUN_140008520(*(undefined4 *)(param_1 + 0x108));
      plVar3 = (longlong *)InstanceGet();
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,local_438,2);
      local_448 = plVar3;
      if ((plVar3 != (longlong *)0x0) && (lVar4 = (**(code **)(*plVar3 + 0x40))(plVar3), lVar4 != 0)
         ) {
        plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,0);
        pcVar6 = (char *)(**(code **)(*plVar5 + 0x78))(plVar5);
        tq::SafeCopy((char *)(param_3 + 5),pcVar6,0x10);
        sVar1 = (short)param_3[1];
        if (sVar1 == 1) {
          iVar2 = FUN_140111320(param_1,param_2,param_3);
          (**(code **)*plVar3)(plVar3);
          return iVar2;
        }
        if (sVar1 == 2) {
          (**(code **)*plVar3)(plVar3);
          return 0;
        }
        if (sVar1 == 3) {
          iVar2 = FUN_14010c180(param_1,param_2,param_3);
          (**(code **)*plVar3)(plVar3);
          return iVar2;
        }
        if (sVar1 != 4) {
          (**(code **)*plVar3)(plVar3);
          return 9;
        }
        iVar2 = FUN_14010c8a0(param_1,param_2,param_3);
        (**(code **)*plVar3)(plVar3);
        return iVar2;
      }
      if (plVar3 != (longlong *)0x0) {
        (**(code **)*plVar3)(plVar3);
      }
      iVar2 = 3;
    }
    else {
      local_460 = 0x58;
      local_468 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\lostitemmgr.cpp";
      tq::SysLogSave("miantuxing_error",&DAT_14070a580);
    }
  }
  return iVar2;
}

// ==== CMsgGiveBack::helper_1401116a0  @1401116a0  [medium:callgraph-r0]  (orig: FUN_1401116a0)
undefined8 FUN_1401116a0(undefined8 param_1,longlong param_2,longlong param_3)

{
  undefined8 uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 10;
  }
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 10;
  }
  uVar1 = FUN_1401113e0();
  return uVar1;
}

// ==== CMsgGiveBack::helper_140148ba0  @140148ba0  [medium:callgraph-r0]  (orig: FUN_140148ba0)
undefined1 FUN_140148ba0(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  puVar1 = (undefined8 *)FUN_140008520(*(undefined4 *)(param_1 + 4));
  (**(code **)*puVar1)(puVar1,0x10000,param_2);
  return 1;
}

// ==== CMsgGiveBack::helper_1403714b0  @1403714b0  [medium:callgraph-r3]  (orig: FUN_1403714b0)
uint FUN_1403714b0(uint param_1,uint param_2,uint param_3)

{
  int local_18 [6];
  
  local_18[0] = 0x1c32094;
  local_18[1] = 0x2f93c2;
  local_18[2] = 0x9234d5;
  return local_18[param_2 % 3] + (param_1 & param_3) + param_1 ^ param_2;
}

// ==== CMsgGiveBack::helper_140451520  @140451520  [medium:callgraph-r0]  (orig: FUN_140451520)
undefined8 FUN_140451520(longlong param_1)

{
  if (*(longlong *)(param_1 + 0xe8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return *(undefined8 *)(param_1 + 0xe8);
  }
  return *(undefined8 *)(param_1 + 0xe8);
}

// ==== CMsgGiveBack::ctor_or_dtor  @140451580  [high:vtable-assign]  (orig: FUN_140451580)
undefined8 * FUN_140451580(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgGiveBack::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgGiveBack::ctor_or_dtor  @1404515d0  [high:vtable-assign]  (orig: FUN_1404515d0)
void FUN_1404515d0(undefined8 *param_1)

{
  *param_1 = CMsgGiveBack::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgGiveBack::vfunc_1  @140451600  [high:rtti-vtable]  (orig: FUN_140451600)
ulonglong FUN_140451600(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x8fc);
}

// ==== CMsgGiveBack::ctor_or_dtor  @140451630  [high:vtable-assign]  (orig: FUN_140451630)
undefined8 * FUN_140451630(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgGiveBack::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgGiveBack::vfunc_3  @140451680  [high:rtti-vtable]  (orig: FUN_140451680)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140451680(longlong param_1)

{
  undefined4 *puVar1;
  int iVar2;
  char *pcVar3;
  undefined8 uVar4;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined4 local_4a8;
  undefined4 local_4a4;
  undefined8 local_4a0;
  undefined4 local_498;
  undefined4 local_494;
  undefined4 local_490;
  undefined4 local_48c;
  undefined4 local_488;
  undefined4 local_484;
  undefined4 local_480;
  undefined4 local_47c;
  undefined4 local_478;
  undefined8 local_470;
  undefined8 local_468;
  undefined8 local_460;
  undefined8 local_458;
  undefined4 local_450;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_4a0 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (*(int *)(param_1 + 0x414) == 0x10000) {
    pcVar3 = DAT_140975bd8;
    if (DAT_140975bd8 == (char *)0x0) {
      local_4b8 = 0x3ce;
      log_InlineLogERROR(&DAT_1406d9c10);
      pcVar3 = (char *)0x0;
    }
    if (*pcVar3 == '\0') {
      tq::SysLogSave("miantuxing_error",&DAT_14077dcd0);
    }
    else {
      local_484 = 0;
      local_480 = 0;
      local_47c = 0;
      local_478 = 0;
      puVar1 = *(undefined4 **)(param_1 + 0x428);
      local_498 = *puVar1;
      local_494 = puVar1[1];
      local_490 = puVar1[2];
      local_48c = puVar1[3];
      local_488 = puVar1[4];
      local_470 = *(undefined8 *)(puVar1 + 5);
      local_468 = *(undefined8 *)(puVar1 + 7);
      local_460 = *(undefined8 *)(puVar1 + 9);
      local_458 = *(undefined8 *)(puVar1 + 0xb);
      local_450 = puVar1[0xd];
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar4 = FUN_140451520(uVar4);
      local_4a4 = FUN_1401116a0(uVar4,&local_470,&local_498);
      local_4a8 = local_498;
      FUN_140453a60(local_448);
      iVar2 = FUN_140453de0(local_448,0xe8,2,&local_4a8);
      if (iVar2 == 0) {
        local_4b8 = 0x4b;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        pcVar3 = DAT_140975bd8;
        if (DAT_140975bd8 == (char *)0x0) {
          local_4b8 = 0x3ce;
          log_InlineLogERROR(&DAT_1406d9c10);
          pcVar3 = (char *)0x0;
        }
        FUN_140148ba0(pcVar3,local_448);
      }
      FUN_140453ab0(local_448);
    }
  }
  else {
    tq::SysLogSave("miantuxing_error",&DAT_14077dd00);
  }
  return;
}

// ==== CMsgGiveBack::helper_140453de0  @140453de0  [medium:callgraph-r0]  (orig: FUN_140453de0)
bool FUN_140453de0(longlong param_1,undefined1 param_2,int param_3,void *param_4)

{
  bool bVar1;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    bVar1 = false;
  }
  else {
    bVar1 = (longlong)param_3 * 4 + 0x1cU < 0x3fc;
    if (bVar1) {
      FUN_1402b5600();
      *(undefined4 *)(param_1 + 8) = 0x7f4;
      *(int *)(param_1 + 0xc) = param_3 * 4 + 4;
      **(undefined1 **)(param_1 + 0x428) = param_2;
      *(char *)(*(longlong *)(param_1 + 0x428) + 1) = (char)param_3;
      memcpy((void *)(*(longlong *)(param_1 + 0x428) + 4),param_4,(longlong)param_3 * 4);
    }
    else {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  return bVar1;
}

