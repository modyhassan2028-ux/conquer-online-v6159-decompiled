// ==== CTableWittnessMgr::ctor_or_dtor  @1404bfa40  [high:vtable-assign]  (orig: FUN_1404bfa40)
void FUN_1404bfa40(undefined8 *param_1)

{
  *param_1 = CTableWittnessMgr::vftable;
  param_1 = param_1 + 1;
  FUN_1403f9e60(param_1);
  FUN_1403fba40(param_1);
  operator_delete((void *)*param_1);
  return;
}

// ==== CTableWittnessMgr::ctor_or_dtor  @1404c0160  [high:vtable-assign]  (orig: FUN_1404c0160)
undefined8 * FUN_1404c0160(undefined8 *param_1)

{
  *param_1 = CTableWittnessMgr::vftable;
  FUN_1403fc8a0(param_1 + 1);
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined4 *)((longlong)param_1 + 0x4c) = 0;
  return param_1;
}

// ==== CTableWittnessMgr::ctor_or_dtor  @1404c01a0  [high:vtable-assign]  (orig: FUN_1404c01a0)
undefined8 * FUN_1404c01a0(undefined8 *param_1,uint param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CTableWittnessMgr::vftable;
  puVar1 = param_1 + 1;
  FUN_1403f9e60(puVar1);
  FUN_1403fba40(puVar1);
  operator_delete((void *)*puVar1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CTableWittnessMgr::ctor_or_dtor  @1404c0220  [high:vtable-assign]  (orig: FUN_1404c0220)
undefined8 * FUN_1404c0220(undefined4 param_1,undefined4 param_2)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CTableWittnessMgr::vftable;
    FUN_1403fc8a0(puVar1 + 1);
    *(undefined4 *)(puVar1 + 9) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x4c) = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *(undefined4 *)((longlong)puVar1 + 0x4c) = param_1;
    *(undefined4 *)(puVar1 + 9) = param_2;
    FUN_1403f9e60(puVar1 + 1);
  }
  return puVar1;
}

