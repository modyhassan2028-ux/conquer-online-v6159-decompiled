// ==== CRankActor@adapter::helper_140177130  @140177130  [medium:callgraph-r0]  (orig: FUN_140177130)
void FUN_140177130(longlong param_1,uint param_2,int param_3)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  int iVar4;
  longlong lVar5;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  lVar5 = 0;
  lVar3 = *(longlong *)(lVar2 + 0x1a8);
  if (*(longlong *)(lVar2 + 0x1a8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = lVar5;
  }
  cVar1 = FUN_1402e1b70(lVar3);
  if (cVar1 == '\0') {
    iVar4 = 3;
    if (2 < param_3) {
      if (param_3 < 0xf) {
        iVar4 = 2;
      }
      else {
        iVar4 = 0;
        if (param_3 < 0x32) {
          iVar4 = 1;
        }
      }
    }
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    lVar3 = *(longlong *)(lVar3 + 0x1a8);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = lVar5;
    }
    lVar3 = FUN_1402e69e0(lVar3,param_1,param_2 & 0xff);
    if (399 < lVar3) {
      iVar4 = 3;
    }
    if (param_2 == 1) {
      if (*(int *)(param_1 + 0x1248) != iVar4) {
        *(int *)(param_1 + 0x1248) = iVar4;
      }
    }
    else if (param_2 == 2) {
      if (*(int *)(param_1 + 0x124c) != iVar4) {
        *(int *)(param_1 + 0x124c) = iVar4;
      }
    }
    else if (param_2 == 3) {
      if (*(int *)(param_1 + 0x1250) != iVar4) {
        *(int *)(param_1 + 0x1250) = iVar4;
      }
    }
    else if (param_2 == 4) {
      if (*(int *)(param_1 + 0x1254) != iVar4) {
        *(int *)(param_1 + 0x1254) = iVar4;
      }
    }
    else {
      log_InlineLogWARNING("CUser::OnFateSortChg. FateType[%d]");
    }
    return;
  }
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  lVar3 = *(longlong *)(lVar3 + 0x1a8);
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = lVar5;
  }
  FUN_1402e7020(lVar3,param_1,param_2 & 0xff,param_3 + 1);
  return;
}

// ==== CRankActor@adapter::helper_1401f6870  @1401f6870  [medium:callgraph-r0]  (orig: FUN_1401f6870)
undefined8 FUN_1401f6870(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong lVar4;
  undefined4 local_res10 [2];
  longlong *local_38;
  longlong lStack_30;
  longlong *local_28 [2];
  
  plVar1 = (longlong *)(param_1 + 0x18);
  local_res10[0] = param_2;
  FUN_1401f5550(plVar1,&local_38,local_res10,param_4,0xfffffffffffffffe);
  lVar3 = *(longlong *)(param_1 + 0x48);
  lVar4 = 0;
  local_28[0] = (longlong *)*plVar1;
  if ((local_38 == (longlong *)0x0) || (local_38 != local_28[0])) {
    _invalid_parameter_noinfo();
  }
  if (lStack_30 == lVar3) {
    log_InlineLogERROR("CInnerStrengthMgr::GetUserTotalValue not found user data, idUser:%u.");
    uVar2 = 0;
  }
  else {
    if (local_38 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar4;
    }
    else {
      lVar3 = *local_38;
    }
    if (lStack_30 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(lStack_30 + 0x20) == 0) {
      log_InlineLogERROR("CInnerStrengthMgr::GetUserTotalValue data pointer is null, idUser:%u.");
      FUN_1401f5190(plVar1,local_28,&local_38);
      uVar2 = 0;
    }
    else {
      if (local_38 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar4 = *local_38;
      }
      if (lStack_30 == *(longlong *)(lVar4 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar2 = FUN_140402ec0(*(undefined8 *)(lStack_30 + 0x20));
    }
  }
  return uVar2;
}

// ==== CRankActor@adapter::helper_1402e1b70  @1402e1b70  [medium:callgraph-r1]  (orig: FUN_1402e1b70)
undefined1 FUN_1402e1b70(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x90);
}

// ==== CRankActor@adapter::helper_1402e7020  @1402e7020  [medium:callgraph-r1]  (orig: FUN_1402e7020)
void FUN_1402e7020(longlong param_1,longlong *param_2,undefined1 param_3,undefined4 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  uint uVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < uVar4) {
      puVar9 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar9 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar9;
    cVar1 = *(char *)((longlong)puVar9 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_40 = puVar3;
  local_48 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (uVar4 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x38);
    local_38 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_48;
  }
  plVar2 = (longlong *)*plVar7;
  lVar10 = *(longlong *)(param_1 + 0x38);
  local_28 = plVar2;
  local_20 = plVar7[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_20;
  if (lVar10 != local_20) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar5 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar10 = *(longlong *)(lVar5 + 0x20);
    if (lVar10 != 0) {
      lVar5 = FUN_1402e69e0(param_1,param_2,param_3);
      if (399 < lVar5) {
        param_4 = 1;
      }
      uVar6 = FUN_14047b5e0(*(undefined8 *)(param_1 + 0xa8),param_3,param_4);
      FUN_140477b40(lVar10,param_3,uVar6);
    }
  }
  return;
}

// ==== CRankActor@adapter::helper_140477960  @140477960  [medium:callgraph-r3]  (orig: FUN_140477960)
void FUN_140477960(longlong param_1,char param_2,char param_3,undefined4 param_4)

{
  longlong *plVar1;
  undefined4 uVar2;
  
  if ((param_2 != '\0') && (*(longlong *)(param_1 + 0x28) != 0)) {
    if (param_2 == '\x01') {
      if (param_3 == '\x01') {
        uVar2 = 2;
      }
      else if (param_3 == '\x02') {
        uVar2 = 3;
      }
      else if (param_3 == '\x03') {
        uVar2 = 4;
      }
      else {
        if (param_3 != '\x04') {
          return;
        }
        uVar2 = 5;
      }
    }
    else if (param_2 == '\x02') {
      if (param_3 == '\x01') {
        uVar2 = 6;
      }
      else if (param_3 == '\x02') {
        uVar2 = 7;
      }
      else if (param_3 == '\x03') {
        uVar2 = 8;
      }
      else {
        if (param_3 != '\x04') {
          return;
        }
        uVar2 = 9;
      }
    }
    else if (param_2 == '\x03') {
      if (param_3 == '\x01') {
        uVar2 = 10;
      }
      else if (param_3 == '\x02') {
        uVar2 = 0xb;
      }
      else if (param_3 == '\x03') {
        uVar2 = 0xc;
      }
      else {
        if (param_3 != '\x04') {
          return;
        }
        uVar2 = 0xd;
      }
    }
    else {
      if (param_2 != '\x04') {
        return;
      }
      if (param_3 == '\x01') {
        uVar2 = 0xe;
      }
      else if (param_3 == '\x02') {
        uVar2 = 0xf;
      }
      else if (param_3 == '\x03') {
        uVar2 = 0x10;
      }
      else {
        if (param_3 != '\x04') {
          return;
        }
        uVar2 = 0x11;
      }
    }
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                       (*(longlong **)(param_1 + 0x28),uVar2);
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_4);
  }
  return;
}

// ==== CRankActor@adapter::helper_140477b40  @140477b40  [medium:callgraph-r2]  (orig: FUN_140477b40)
void FUN_140477b40(undefined8 param_1,char param_2,longlong *param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  uint uVar4;
  
  if (param_3 == (longlong *)0x0) {
    if ((byte)(param_2 - 1U) < 4) {
      uVar4 = 1;
      do {
        FUN_140477960(param_1,param_2,uVar4 & 0xff,0);
        uVar4 = uVar4 + 1;
      } while ((int)uVar4 < 5);
    }
  }
  else {
    uVar4 = 1;
    plVar3 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,1);
    cVar1 = (**(code **)(*plVar3 + 0x20))(plVar3);
    if ((byte)(cVar1 - 1U) < 4) {
      do {
        plVar3 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,uVar4 + 2);
        uVar2 = (**(code **)(*plVar3 + 0x50))(plVar3);
        FUN_140477960(param_1,cVar1,uVar4 & 0xff,uVar2);
        uVar4 = uVar4 + 1;
      } while ((int)uVar4 < 5);
    }
  }
  return;
}

// ==== CRankActor@adapter::helper_14047b5e0  @14047b5e0  [medium:callgraph-r2]  (orig: FUN_14047b5e0)
undefined8 FUN_14047b5e0(longlong param_1,byte param_2,int param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  uint uVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  uVar9 = ((uint)param_2 - param_3 / 1000) * 1000 + param_3;
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < uVar9) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (uVar9 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar10 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar10) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CRankActor@adapter::vfunc_1  @1405b49b0  [high:rtti-vtable]  (orig: FUN_1405b49b0)
void FUN_1405b49b0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CRankActor@adapter::vfunc_0  @1405b49d0  [high:rtti-vtable]  (orig: FUN_1405b49d0)
bool FUN_1405b49d0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    return false;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  return lVar2 != 0;
}

// ==== CRankActor@adapter::vfunc_1  @1405b4a00  [high:rtti-vtable]  (orig: FUN_1405b4a00)
undefined8 FUN_1405b4a00(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar1 != (longlong *)0x0) && (lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1), lVar2 != 0)) {
                    /* WARNING: Could not recover jumptable at 0x0001405b4a79. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x18))(lVar2 + 0x10);
    return uVar3;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CRankActor@adapter::vfunc_5  @1405b4a80  [high:rtti-vtable]  (orig: FUN_1405b4a80)
undefined8 FUN_1405b4a80(void)

{
  return 0;
}

// ==== CRankActor@adapter::vfunc_6  @1405b4a90  [high:rtti-vtable]  (orig: FUN_1405b4a90)
undefined8 FUN_1405b4a90(void)

{
  return 0;
}

// ==== CRankActor@adapter::vfunc_7  @1405b4aa0  [high:rtti-vtable]  (orig: FUN_1405b4aa0)
undefined1 FUN_1405b4aa0(void)

{
  return 0;
}

// ==== CRankActor@adapter::vfunc_9  @1405b4ab0  [high:rtti-vtable]  (orig: FUN_1405b4ab0)
undefined8 FUN_1405b4ab0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar1 != (longlong *)0x0) && (lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1), lVar2 != 0)) {
    uVar3 = FUN_140165370(lVar2);
    return uVar3;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CRankActor@adapter::vfunc_10  @1405b4b30  [high:rtti-vtable]  (orig: FUN_1405b4b30)
void FUN_1405b4b30(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    FUN_140177130(lVar2,param_3,param_4);
  }
  return;
}

// ==== CRankActor@adapter::vfunc_4  @1405b4bb0  [high:rtti-vtable]  (orig: FUN_1405b4bb0)
undefined8 FUN_1405b4bb0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,8);
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b4bdf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x128))(plVar1,param_2);
    return uVar2;
  }
  return 0;
}

// ==== CRankActor@adapter::vfunc_11  @1405b4bf0  [high:rtti-vtable]  (orig: FUN_1405b4bf0)
void FUN_1405b4bf0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar3 != (longlong *)0x0) &&
     (plVar3 = (longlong *)(**(code **)(*plVar3 + 0x2b0))(plVar3), plVar3 != (longlong *)0x0)) {
    plVar4 = (longlong *)FUN_1401181a0();
    lVar1 = *plVar4;
    uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
    (**(code **)(lVar1 + 0x90))(plVar4,uVar2,param_3);
  }
  return;
}

// ==== CRankActor@adapter::vfunc_12  @1405b4c70  [high:rtti-vtable]  (orig: FUN_1405b4c70)
void FUN_1405b4c70(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    FUN_140170e90(lVar2,param_3);
  }
  return;
}

// ==== CRankActor@adapter::vfunc_13  @1405b4ce0  [high:rtti-vtable]  (orig: FUN_1405b4ce0)
undefined8 FUN_1405b4ce0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b4d70. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CRankActor@adapter::vfunc_14  @1405b4d80  [high:rtti-vtable]  (orig: FUN_1405b4d80)
void FUN_1405b4d80(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x358))((longlong *)(lVar2 + 0x10),param_3);
    }
  }
  return;
}

// ==== CRankActor@adapter::vfunc_0  @1405b4dc0  [high:rtti-vtable]  (orig: FUN_1405b4dc0)
void FUN_1405b4dc0(longlong param_1)

{
  FUN_1405b4e20(param_1 + -8);
  return;
}

// ==== CRankActor@adapter::helper_1405b4e20  @1405b4e20  [medium:callgraph-r0]  (orig: FUN_1405b4e20)
undefined8 * FUN_1405b4e20(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CRankActor::vftable;
  param_1[1] = adapter::CRankActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CRankActor@adapter::vfunc_2  @1405b4e70  [high:rtti-vtable]  (orig: FUN_1405b4e70)
void FUN_1405b4e70(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar2 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(ushort *)(param_3 + 8) - 4,0,uVar4);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),puVar3);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CRankActor@adapter::vfunc_3  @1405b4f70  [high:rtti-vtable]  (orig: FUN_1405b4f70)
void FUN_1405b4f70(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                             param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,0,uVar4);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x348))((longlong *)(lVar2 + 0x10),puVar3,1);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CRankActor@adapter::vfunc_8  @1405b5040  [high:rtti-vtable]  (orig: FUN_1405b5040)
undefined8 FUN_1405b5040(longlong param_1,undefined8 param_2,undefined1 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar3 = *(longlong *)(lVar3 + 0x1a8);
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = 0;
  }
  uVar4 = FUN_1402e69e0(lVar3,lVar2,param_3);
  return uVar4;
}

// ==== CRankActor@adapter::vfunc_15  @1405b5150  [high:rtti-vtable]  (orig: FUN_1405b5150)
void FUN_1405b5150(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x1d0);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1401f6870(lVar1,param_2);
  return;
}

