// ==== CCrossMsg2ndPwd::ctor_or_dtor  @1403f4080  [high:vtable-assign]  (orig: FUN_1403f4080)
undefined8 * FUN_1403f4080(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsg2ndPwd::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsg2ndPwd::ctor_or_dtor  @1403f40d0  [high:vtable-assign]  (orig: FUN_1403f40d0)
void FUN_1403f40d0(undefined8 *param_1)

{
  *param_1 = CCrossMsg2ndPwd::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsg2ndPwd::vfunc_1  @1403f4100  [high:rtti-vtable]  (orig: FUN_1403f4100)
undefined8 FUN_1403f4100(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsg2ndPwd::ctor_or_dtor  @1403f4160  [high:vtable-assign]  (orig: FUN_1403f4160)
undefined8 * FUN_1403f4160(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsg2ndPwd::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsg2ndPwd::vfunc_3  @1403f41b0  [high:rtti-vtable]  (orig: FUN_1403f41b0)
void FUN_1403f41b0(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  
  if (*(char **)(param_1 + 0x428) != (char *)0x0) {
    cVar1 = **(char **)(param_1 + 0x428);
    if (cVar1 == '\0') {
      uVar2 = *(undefined4 *)(param_1 + 0x41c);
      uVar3 = *(undefined4 *)(param_1 + 0x420);
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar4 = FUN_140087650(uVar4);
      lVar6 = FUN_1402af110(uVar4,uVar2,uVar3);
      if (lVar6 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0001403f4283. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        log_InlineLogOSWARNING
                  ("CCrossMsg2ndPwd::Process not found user, idServer:%lu, idOSUser:%lu");
        return;
      }
      *(bool *)(lVar6 + 0x51c) = *(char *)(*(longlong *)(param_1 + 0x428) + 1) != '\0';
    }
    else if (cVar1 == '\x01') {
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar5 = (longlong *)FUN_140087650(uVar4);
      lVar6 = (**(code **)(*plVar5 + 0x98))(plVar5,*(undefined4 *)(param_1 + 0x420));
      if (lVar6 != 0) {
        *(bool *)(lVar6 + 0x51c) = *(char *)(*(longlong *)(param_1 + 0x428) + 1) != '\0';
        return;
      }
    }
  }
  return;
}

