// ==== CAntiCheatActor@adapter::helper_14008a4b0  @14008a4b0  [medium:callgraph-r0]  (orig: FUN_14008a4b0)
undefined1 FUN_14008a4b0(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x318);
}

// ==== CAntiCheatActor@adapter::helper_14008a5e0  @14008a5e0  [medium:callgraph-r0]  (orig: FUN_14008a5e0)
undefined4 FUN_14008a5e0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x310);
}

// ==== CAntiCheatActor@adapter::helper_14008a5f0  @14008a5f0  [medium:callgraph-r0]  (orig: FUN_14008a5f0)
undefined4 FUN_14008a5f0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x314);
}

// ==== CAntiCheatActor@adapter::helper_14008aad0  @14008aad0  [medium:callgraph-r0]  (orig: FUN_14008aad0)
void FUN_14008aad0(undefined8 param_1,undefined4 param_2)

{
  FUN_14050c390(param_2);
  return;
}

// ==== CAntiCheatActor@adapter::helper_14008b180  @14008b180  [medium:callgraph-r0]  (orig: FUN_14008b180)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14008b180(longlong param_1,undefined4 param_2,undefined4 param_3,char *param_4)

{
  char cVar1;
  ulonglong uVar2;
  char *pcVar3;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined4 local_444;
  uint local_440;
  undefined1 local_43c [1044];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  uVar2 = 0xffffffffffffffff;
  pcVar3 = param_4;
  do {
    if (uVar2 == 0) break;
    uVar2 = uVar2 - 1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  memset((void *)((longlong)&local_448 + 1),0,0x417);
  local_440 = (uint)(~uVar2 - 1);
  if (local_440 < 0x40a) {
    local_448 = param_2;
    local_444 = param_3;
    memcpy(local_43c,param_4,~uVar2 - 1 & 0xffffffff);
    if (*(longlong *)(param_1 + 0x80) != 0) {
      local_458 = &local_448;
      (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                (*(longlong **)(param_1 + 0x80),2,0x4e2f,0x418);
    }
  }
  return;
}

// ==== CAntiCheatActor@adapter::helper_140160850  @140160850  [medium:callgraph-r0]  (orig: FUN_140160850)
undefined8 FUN_140160850(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,*(undefined4 *)(param_1 + 0xdc4));
  if (lVar1 != 0) {
    uVar2 = FUN_1400fda10(lVar1,0xc,1);
    return uVar2;
  }
  return 0;
}

// ==== CAntiCheatActor@adapter::helper_140165d80  @140165d80  [medium:callgraph-r0]  (orig: FUN_140165d80)
undefined4 FUN_140165d80(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1270);
}

// ==== CAntiCheatActor@adapter::helper_140165d90  @140165d90  [medium:callgraph-r0]  (orig: FUN_140165d90)
void FUN_140165d90(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x1270) = 0;
  return;
}

// ==== CAntiCheatActor@adapter::helper_1401673c0  @1401673c0  [medium:callgraph-r0]  (orig: FUN_1401673c0)
undefined4 FUN_1401673c0(longlong param_1)

{
  ulong uVar1;
  int iVar2;
  
  uVar1 = tq::TimeGet(0);
  iVar2 = uVar1 - *(int *)(param_1 + 0x12f8);
  return CONCAT31((int3)((uint)iVar2 >> 8),60000 < iVar2);
}

// ==== CAntiCheatActor@adapter::vfunc_1  @14057ea60  [high:rtti-vtable]  (orig: FUN_14057ea60)
void FUN_14057ea60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_0  @14057ea80  [high:rtti-vtable]  (orig: FUN_14057ea80)
undefined1 * FUN_14057ea80(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057ead8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_1  @14057eae0  [high:rtti-vtable]  (orig: FUN_14057eae0)
undefined4 FUN_14057eae0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined4 *)(lVar1 + 0xf10);
}

// ==== CAntiCheatActor@adapter::vfunc_2  @14057eb40  [high:rtti-vtable]  (orig: FUN_14057eb40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14057eb40(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x50);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CAntiCheatActor@adapter::vfunc_3  @14057eca0  [high:rtti-vtable]  (orig: FUN_14057eca0)
undefined8 FUN_14057eca0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0xffffffff;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057ecf4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_4  @14057ed00  [high:rtti-vtable]  (orig: FUN_14057ed00)
void FUN_14057ed00(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057ed6e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
            (*(longlong **)(param_1 + 0x10),lVar1,param_3);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_6  @14057ed80  [high:rtti-vtable]  (orig: FUN_14057ed80)
void FUN_14057ed80(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401ca920(lVar1,param_3,param_4,0);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_8  @14057ee00  [high:rtti-vtable]  (orig: FUN_14057ee00)
bool FUN_14057ee00(longlong param_1,undefined8 param_2,int param_3)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x168))(lVar2 + 0x10);
  return iVar1 == param_3;
}

// ==== CAntiCheatActor@adapter::vfunc_9  @14057ee70  [high:rtti-vtable]  (orig: FUN_14057ee70)
undefined8 FUN_14057ee70(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x230))(lVar2 + 0x10);
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}

// ==== CAntiCheatActor@adapter::vfunc_10  @14057eeb0  [high:rtti-vtable]  (orig: FUN_14057eeb0)
undefined8 FUN_14057eeb0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057ef03. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_11  @14057ef10  [high:rtti-vtable]  (orig: FUN_14057ef10)
void FUN_14057ef10(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401732e0(lVar1,param_3,param_4,param_5,param_6);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_12  @14057ef90  [high:rtti-vtable]  (orig: FUN_14057ef90)
bool FUN_14057ef90(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined1 param_6)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = FUN_1401c55b0(lVar2,param_3,param_4,param_5,param_6);
  return iVar1 == 0;
}

// ==== CAntiCheatActor@adapter::vfunc_14  @14057f020  [high:rtti-vtable]  (orig: FUN_14057f020)
undefined8 FUN_14057f020(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057f073. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_15  @14057f080  [high:rtti-vtable]  (orig: FUN_14057f080)
undefined8 FUN_14057f080(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057f0d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_16  @14057f0e0  [high:rtti-vtable]  (orig: FUN_14057f0e0)
undefined8 FUN_14057f0e0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0xffffffff;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057f134. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x50))(lVar1 + 0x10);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_17  @14057f140  [high:rtti-vtable]  (orig: FUN_14057f140)
bool FUN_14057f140(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  plVar3 = (longlong *)(lVar2 + 0x10);
  lVar2 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x160))(plVar3);
  if (lVar2 == 0) {
    return false;
  }
  plVar3 = (longlong *)(**(code **)(*plVar3 + 0x160))(plVar3);
  iVar1 = (**(code **)(*plVar3 + 8))(plVar3);
  return iVar1 == 0x40f;
}

// ==== CAntiCheatActor@adapter::vfunc_20  @14057f1e0  [high:rtti-vtable]  (orig: FUN_14057f1e0)
void FUN_14057f1e0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057f207. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x278))(lVar1 + 0x10);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_21  @14057f210  [high:rtti-vtable]  (orig: FUN_14057f210)
void FUN_14057f210(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057f23f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2d8))((longlong *)(lVar1 + 0x10),param_3);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_24  @14057f250  [high:rtti-vtable]  (orig: FUN_14057f250)
undefined8 FUN_14057f250(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140160850(lVar1);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_25  @14057f2b0  [high:rtti-vtable]  (orig: FUN_14057f2b0)
undefined8 FUN_14057f2b0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1401663b0(lVar1);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_26  @14057f310  [high:rtti-vtable]  (orig: FUN_14057f310)
undefined8 FUN_14057f310(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165d80(lVar1);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_27  @14057f370  [high:rtti-vtable]  (orig: FUN_14057f370)
void FUN_14057f370(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165d90(lVar1);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_28  @14057f3d0  [high:rtti-vtable]  (orig: FUN_14057f3d0)
undefined1 FUN_14057f3d0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0x12c8);
}

// ==== CAntiCheatActor@adapter::vfunc_31  @14057f400  [high:rtti-vtable]  (orig: FUN_14057f400)
bool FUN_14057f400(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CAntiCheatActor@adapter::vfunc_32  @14057f420  [high:rtti-vtable]  (orig: FUN_14057f420)
undefined1 FUN_14057f420(void)

{
  return 0;
}

// ==== CAntiCheatActor@adapter::vfunc_34  @14057f430  [high:rtti-vtable]  (orig: FUN_14057f430)
undefined8 FUN_14057f430(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 1;
  }
  uVar2 = FUN_1401673c0(lVar1);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_36  @14057f460  [high:rtti-vtable]  (orig: FUN_14057f460)
void FUN_14057f460(undefined8 param_1,undefined4 param_2,undefined1 param_3)

{
  FUN_140006ad0(param_2,param_3);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_38  @14057f470  [high:rtti-vtable]  (orig: FUN_14057f470)
undefined8 FUN_14057f470(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    iVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x168))(lVar2 + 0x10);
    if ((iVar1 != 0x1772) && (iVar1 != 0x1774)) {
      return 1;
    }
  }
  return 0;
}

// ==== CAntiCheatActor@adapter::vfunc_39  @14057f4b0  [high:rtti-vtable]  (orig: FUN_14057f4b0)
ulonglong FUN_14057f4b0(longlong param_1)

{
  uint uVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  uVar3 = 0;
  if (lVar2 != 0) {
    uVar3 = FUN_1401649c0(lVar2);
    if ((int)uVar3 == 0) {
      uVar3 = (ulonglong)(uint)*(byte *)(lVar2 + 0xeee) * 0xcccccccd & 0xffffffff;
      uVar1 = *(byte *)(lVar2 + 0xeee) / 10;
      if ((uVar1 == 2) || (uVar1 == 5)) {
        return CONCAT71((int7)(uVar3 >> 8),1);
      }
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CAntiCheatActor@adapter::vfunc_40  @14057f520  [high:rtti-vtable]  (orig: FUN_14057f520)
ulonglong FUN_14057f520(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR("CAntiCheatActor::IsOsUser: user = %u");
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140167b70(lVar1);
  return uVar2;
}

// ==== CAntiCheatActor@adapter::vfunc_0  @14057f560  [high:rtti-vtable]  (orig: FUN_14057f560)
void FUN_14057f560(longlong param_1)

{
  FUN_14057f5c0(param_1 + -8);
  return;
}

// ==== CAntiCheatActor@adapter::helper_14057f5c0  @14057f5c0  [medium:callgraph-r0]  (orig: FUN_14057f5c0)
undefined8 * FUN_14057f5c0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CAntiCheatActor::vftable;
  param_1[1] = adapter::CAntiCheatActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CAntiCheatActor@adapter::vfunc_5  @14057f6c0  [high:rtti-vtable]  (orig: FUN_14057f6c0)
bool FUN_14057f6c0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x20))(*(longlong **)(lVar1 + 0x88),param_2);
  return lVar1 != 0;
}

// ==== CAntiCheatActor@adapter::vfunc_7  @14057f730  [high:rtti-vtable]  (orig: FUN_14057f730)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14057f730(longlong param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined1 auStack_478 [32];
  uint local_458;
  undefined4 local_450;
  undefined4 local_448;
  char local_438;
  undefined1 local_437 [1023];
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar4 + 0x98) == 0) {
    local_458 = 0x131;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x98) + 0x10))
                    (*(longlong **)(lVar4 + 0x98),param_3,1);
  if (lVar4 == 0) {
    local_458 = 0x92;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar1 = (**(code **)(**(longlong **)(lVar4 + 0x58) + 0x10))(*(longlong **)(lVar4 + 0x58),0xb);
    uVar2 = (**(code **)(**(longlong **)(lVar4 + 0x58) + 0x10))(*(longlong **)(lVar4 + 0x58),0xc);
    lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar4 == 0) {
      local_438 = '\0';
      memset(local_437,0,0x3ff);
      local_458 = uVar1;
      local_450 = uVar2;
      local_448 = param_2;
      _snprintf(&local_438,0x3ff,
                "UPDATE cq_user SET recordmap_id = %u, recordx = %d, recordy = %d WHERE id = %u LIMIT 1"
               );
      FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      plVar5 = (longlong *)InstanceGet();
      (**(code **)(*plVar5 + 0x30))(plVar5,&local_438,0,1);
    }
    else {
      iVar3 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x168))(lVar4 + 0x10);
      if (iVar3 != param_3) {
        local_458 = local_458 & 0xffffff00;
        FUN_1401c55b0(lVar4,param_3,uVar1,uVar2);
      }
    }
  }
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_13  @14057f8f0  [high:rtti-vtable]  (orig: FUN_14057f8f0)
void FUN_14057f8f0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_18  @14057f9b0  [high:rtti-vtable]  (orig: FUN_14057f9b0)
void FUN_14057f9b0(longlong param_1)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uVar1 = *(undefined4 *)(param_1 + 0x18);
  uVar2 = FUN_140008520(uVar1);
  FUN_14008aad0(uVar2,uVar1);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_19  @14057f9d0  [high:rtti-vtable]  (orig: FUN_14057f9d0)
void FUN_14057f9d0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_22  @14057fa90  [high:rtti-vtable]  (orig: FUN_14057fa90)
undefined8 FUN_14057fa90(longlong param_1)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if ((lVar1 != 0) && (*(longlong *)(lVar1 + 0xa88) != 0)) {
    plVar2 = (longlong *)**(undefined8 **)(*(longlong *)(lVar1 + 0xa88) + 0x10);
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,&DAT_140951730);
                    /* WARNING: Could not recover jumptable at 0x00014057fad7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
    return uVar3;
  }
  return 0;
}

// ==== CAntiCheatActor@adapter::vfunc_23  @14057fae0  [high:rtti-vtable]  (orig: FUN_14057fae0)
ulonglong FUN_14057fae0(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = (longlong *)(lVar1 + 0x10);
  lVar1 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x160))(plVar2);
  if (lVar1 == 0) {
    return 0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x160))(plVar2);
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x19) & 1);
}

// ==== CAntiCheatActor@adapter::vfunc_29  @14057fb90  [high:rtti-vtable]  (orig: FUN_14057fb90)
void FUN_14057fb90(void)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(0xe);
  FUN_14008a5e0(uVar1);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_30  @14057fbb0  [high:rtti-vtable]  (orig: FUN_14057fbb0)
void FUN_14057fbb0(void)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(0xe);
  FUN_14008a5f0(uVar1);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_33  @14057fbd0  [high:rtti-vtable]  (orig: FUN_14057fbd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14057fbd0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  undefined8 uVar9;
  undefined1 auStack_898 [32];
  undefined4 local_878;
  undefined4 local_870;
  undefined4 local_868;
  undefined4 local_858;
  undefined8 local_850;
  char local_848;
  undefined1 local_847 [1023];
  char local_448 [1023];
  undefined1 local_49;
  ulonglong local_48;
  
  local_850 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_898;
  local_858 = param_2;
  _snprintf(local_448,0x400,"SELECT  id, recordmap_id FROM cq_user WHERE id = %u LIMIT 1");
  local_49 = 0;
  plVar5 = (longlong *)InstanceGet();
  plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,local_448,2);
  if ((plVar6 == (longlong *)0x0) || (lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6), lVar7 == 0)) {
    if (plVar6 != (longlong *)0x0) {
      (**(code **)*plVar6)(plVar6);
    }
    log_InlineLogERROR(
                      "CAntiCheatActor::OfflineUserGotoJail wants to arrest player(idUser:%u), but cant not query db at %s, %d"
                      );
    return 0;
  }
  plVar8 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0);
  iVar1 = (**(code **)(*plVar8 + 0x40))(plVar8);
  plVar8 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,1);
  iVar2 = (**(code **)(*plVar8 + 0x40))(plVar8);
  (**(code **)*plVar6)(plVar6);
  if (iVar1 == 0) {
    local_878 = 0x1e7;
    log_InlineLogERROR(
                      "CAntiCheatActor::OfflineUserGotoJail wants to arrest player(idUser:%u), but his ID is %u at %s, %d"
                      );
    return 0;
  }
  if (iVar2 == 0x1772) {
    log_InlineLogWARNING
              (
              "CAntiCheatActor::OfflineUserGotoJail wants to arrest player(idUser:%u), but he is already in the map at %s, %d"
              );
    return 1;
  }
  uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  plVar6 = (longlong *)FUN_1400876b0(uVar9);
  lVar7 = (**(code **)(*plVar6 + 0x10))(plVar6,param_3,1);
  if (lVar7 == 0) {
    local_878 = 0x1f5;
    log_InlineLogDBERROR
              (
              "table:cq_map/cq_dynamap, CAntiCheatActor::OfflineUserGotoJail wants to arrest player(idUser:%u), bug cant find map(%u) at %s, %d"
              );
    return 0;
  }
  uVar3 = (**(code **)(**(longlong **)(lVar7 + 0x58) + 0x10))(*(longlong **)(lVar7 + 0x58),0xb);
  local_858 = uVar3;
  uVar4 = (**(code **)(**(longlong **)(lVar7 + 0x58) + 0x10))();
  local_848 = '\0';
  memset(local_847,0,0x3ff);
  local_878 = uVar3;
  local_870 = uVar4;
  local_868 = param_2;
  _snprintf(&local_848,0x3ff,
            "UPDATE cq_user SET recordmap_id = %u, recordx = %d, recordy = %d WHERE id = %u LIMIT 1"
           );
  (**(code **)(*plVar5 + 0x30))(plVar5,&local_848,0,1);
  return 1;
}

// ==== CAntiCheatActor@adapter::vfunc_35  @14057fe40  [high:rtti-vtable]  (orig: FUN_14057fe40)
void FUN_14057fe40(void)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(0xe);
  FUN_14008a4b0(uVar1);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_37  @14057fe60  [high:rtti-vtable]  (orig: FUN_14057fe60)
void FUN_14057fe60(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(0xe);
  FUN_14008b180(uVar1,param_2,param_3,param_4);
  return;
}

// ==== CAntiCheatActor@adapter::vfunc_41  @14057fea0  [high:rtti-vtable]  (orig: FUN_14057fea0)
void FUN_14057fea0(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006c50(*(undefined8 *)(lVar1 + 0xb0),param_2);
  return;
}

