// ==== CClanPKArenicActor@adapter::vfunc_1  @140589950  [high:rtti-vtable]  (orig: FUN_140589950)
void FUN_140589950(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_9  @140589970  [high:rtti-vtable]  (orig: FUN_140589970)
undefined8 FUN_140589970(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165970(lVar1);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_10  @1405899d0  [high:rtti-vtable]  (orig: FUN_1405899d0)
undefined8 FUN_1405899d0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140589a23. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_11  @140589a30  [high:rtti-vtable]  (orig: FUN_140589a30)
undefined8 FUN_140589a30(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140589a83. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x78))(lVar1 + 0x10);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_12  @140589a90  [high:rtti-vtable]  (orig: FUN_140589a90)
undefined8 FUN_140589a90(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140589ae1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0xa0))(plVar1);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_7  @140589af0  [high:rtti-vtable]  (orig: FUN_140589af0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140589af0(longlong param_1,undefined8 param_2,undefined2 param_3,char *param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_4 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x75);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8c0 = 0xffff00;
      local_8c8 = 0;
      local_8b8 = param_3;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CClanPKArenicActor@adapter::vfunc_8  @140589c50  [high:rtti-vtable]  (orig: FUN_140589c50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140589c50(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x8f);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CClanPKArenicActor@adapter::vfunc_23  @140589db0  [high:rtti-vtable]  (orig: FUN_140589db0)
bool FUN_140589db0(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = FUN_140166ec0(lVar2);
  return iVar1 != 0;
}

// ==== CClanPKArenicActor@adapter::vfunc_51  @140589e10  [high:rtti-vtable]  (orig: FUN_140589e10)
undefined8 FUN_140589e10(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140589e63. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_21  @140589e70  [high:rtti-vtable]  (orig: FUN_140589e70)
undefined8 FUN_140589e70(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_14018eb30(lVar1);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_22  @140589ed0  [high:rtti-vtable]  (orig: FUN_140589ed0)
ulonglong FUN_140589ed0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140589f41. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x178))(plVar1,param_3,param_4);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_13  @140589f50  [high:rtti-vtable]  (orig: FUN_140589f50)
undefined1 * FUN_140589f50(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x000140589fa8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_14  @140589fb0  [high:rtti-vtable]  (orig: FUN_140589fb0)
undefined8 FUN_140589fb0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058a003. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x30))(lVar1 + 0x10);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_15  @14058a010  [high:rtti-vtable]  (orig: FUN_14058a010)
undefined1 FUN_14058a010(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0xeee);
}

// ==== CClanPKArenicActor@adapter::vfunc_18  @14058a070  [high:rtti-vtable]  (orig: FUN_14058a070)
bool FUN_14058a070(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CClanPKArenicActor@adapter::vfunc_19  @14058a090  [high:rtti-vtable]  (orig: FUN_14058a090)
ulonglong FUN_14058a090(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong lVar1;
  ulonglong uVar2;
  
  if (param_2 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    in_RAX = 0;
    if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014058a0bd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x250))(lVar1 + 0x10);
      return uVar2;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CClanPKArenicActor@adapter::vfunc_20  @14058a0d0  [high:rtti-vtable]  (orig: FUN_14058a0d0)
void FUN_14058a0d0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401732e0(lVar1,param_3,param_4,param_5,param_6);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_16  @14058a150  [high:rtti-vtable]  (orig: FUN_14058a150)
undefined8 FUN_14058a150(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058a1a3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_17  @14058a1b0  [high:rtti-vtable]  (orig: FUN_14058a1b0)
undefined8 FUN_14058a1b0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058a203. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_24  @14058a210  [high:rtti-vtable]  (orig: FUN_14058a210)
ulonglong FUN_14058a210(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_1401c7e10(lVar1,param_3);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_25  @14058a270  [high:rtti-vtable]  (orig: FUN_14058a270)
ulonglong FUN_14058a270(longlong param_1,undefined8 param_2,undefined4 param_3,int *param_4)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_1401c7c60(lVar1,param_3,*param_4,param_4[1],param_4[2] - *param_4,
                        param_4[3] - param_4[1]);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_27  @14058a300  [high:rtti-vtable]  (orig: FUN_14058a300)
bool FUN_14058a300(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  int iVar1;
  longlong lVar2;
  uint in_stack_ffffffffffffffe8;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = FUN_1401c55b0(lVar2,param_3,param_4,param_5,in_stack_ffffffffffffffe8 & 0xffffff00);
  return iVar1 == 0;
}

// ==== CClanPKArenicActor@adapter::vfunc_28  @14058a380  [high:rtti-vtable]  (orig: FUN_14058a380)
ulonglong FUN_14058a380(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058a3d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_29  @14058a3e0  [high:rtti-vtable]  (orig: FUN_14058a3e0)
void FUN_14058a3e0(longlong param_1,undefined8 param_2,undefined1 param_3,undefined1 param_4,
                  undefined1 param_5)

{
  longlong lVar1;
  uint in_stack_ffffffffffffffe8;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401c6d40(lVar1,param_3,param_4,param_5,in_stack_ffffffffffffffe8 & 0xffffff00);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_30  @14058a460  [high:rtti-vtable]  (orig: FUN_14058a460)
undefined8 FUN_14058a460(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140161f90(lVar1);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_31  @14058a4c0  [high:rtti-vtable]  (orig: FUN_14058a4c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14058a4c0(longlong param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    local_498 = 0x19e;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140161fa0(lVar2,param_3);
    FUN_140362560(local_478);
    cVar1 = FUN_140362910(local_478,0x60,param_2,(longlong)param_3);
    if (cVar1 != '\0') {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_478);
    }
    FUN_1403625e0(local_478);
  }
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_32  @14058a5a0  [high:rtti-vtable]  (orig: FUN_14058a5a0)
void FUN_14058a5a0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401a6420(lVar1,param_3,param_4,param_5);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_33  @14058a620  [high:rtti-vtable]  (orig: FUN_14058a620)
void FUN_14058a620(longlong param_1,undefined8 param_2,undefined1 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140162110(lVar1,0x20,param_3);
  }
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_34  @14058a660  [high:rtti-vtable]  (orig: FUN_14058a660)
undefined8 FUN_14058a660(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058a6b3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x80))(lVar1 + 0x10);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_35  @14058a6c0  [high:rtti-vtable]  (orig: FUN_14058a6c0)
undefined8 FUN_14058a6c0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058a711. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x88))(plVar1);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_36  @14058a720  [high:rtti-vtable]  (orig: FUN_14058a720)
undefined8 FUN_14058a720(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1403837b0(lVar1);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_38  @14058a780  [high:rtti-vtable]  (orig: FUN_14058a780)
ulonglong FUN_14058a780(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                       undefined2 param_5,undefined1 param_6)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140339ec0(lVar1,param_3,param_4,param_5,param_6);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_39  @14058a800  [high:rtti-vtable]  (orig: FUN_14058a800)
undefined8
FUN_14058a800(longlong param_1,undefined8 param_2,undefined4 param_3,undefined2 param_4,
             undefined1 param_5,undefined1 param_6)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140340e50(lVar1,param_3,param_4,param_5,1,0,param_6);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_41  @14058a8a0  [high:rtti-vtable]  (orig: FUN_14058a8a0)
undefined8 FUN_14058a8a0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058a8f3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_71  @14058a900  [high:rtti-vtable]  (orig: FUN_14058a900)
ulonglong FUN_14058a900(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058a997. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x248))(plVar1,param_2);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_72  @14058a9a0  [high:rtti-vtable]  (orig: FUN_14058a9a0)
undefined1 * FUN_14058a9a0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined1 *puVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058aa41. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*plVar1 + 0x290))(plVar1,param_2);
  return puVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_76  @14058aa50  [high:rtti-vtable]  (orig: FUN_14058aa50)
void FUN_14058aa50(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar2 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x00014058aab2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + 0x10))(plVar2,param_2,2);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_66  @14058aac0  [high:rtti-vtable]  (orig: FUN_14058aac0)
undefined1 FUN_14058aac0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 uVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)FUN_140118320();
  if (plVar2 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014058aaee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(*plVar2 + 0x20))(plVar2,param_2,param_3);
    return uVar1;
  }
  return 0;
}

// ==== CClanPKArenicActor@adapter::vfunc_67  @14058ab00  [high:rtti-vtable]  (orig: FUN_14058ab00)
bool FUN_14058ab00(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)FUN_140118320();
  if (plVar2 != (longlong *)0x0) {
    iVar1 = (**(code **)(*plVar2 + 0x30))(plVar2,param_2);
    return iVar1 != 0;
  }
  return false;
}

// ==== CClanPKArenicActor@adapter::vfunc_62  @14058ab40  [high:rtti-vtable]  (orig: FUN_14058ab40)
ulonglong FUN_14058ab40(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR("CClanPKArenicActor::IsUserInArenic, not found arenic module interface");
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058abba. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 8))(plVar1,param_2);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_63  @14058abc0  [high:rtti-vtable]  (orig: FUN_14058abc0)
ulonglong FUN_14058abc0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  undefined8 *puVar2;
  ulonglong extraout_RAX_00;
  ulonglong uVar3;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  puVar2 = (undefined8 *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
  if (puVar2 == (undefined8 *)0x0) {
    log_InlineLogERROR("CClanPKArenicActor::IsArenicWitness, not found arenic module interface");
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058ac3a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)*puVar2)(puVar2,param_2);
  return uVar3;
}

// ==== CClanPKArenicActor@adapter::vfunc_64  @14058ac40  [high:rtti-vtable]  (orig: FUN_14058ac40)
void FUN_14058ac40(undefined8 param_1,undefined4 param_2,undefined1 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
  if (plVar1 == (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014058acb7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("CClanPKArenicActor::ExitArenicWitness, not found arenic module interface");
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058acd1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xa8))(plVar1,param_2,param_3);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_68  @14058ace0  [high:rtti-vtable]  (orig: FUN_14058ace0)
undefined8 FUN_14058ace0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)FUN_140118320();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014058acff. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x28))(plVar1,param_2);
    return uVar2;
  }
  return 0;
}

// ==== CClanPKArenicActor@adapter::vfunc_69  @14058ad10  [high:rtti-vtable]  (orig: FUN_14058ad10)
undefined8 FUN_14058ad10(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  plVar2 = (longlong *)FUN_140118320();
  if (plVar2 != (longlong *)0x0) {
    iVar1 = (**(code **)(*plVar2 + 0x28))(plVar2,param_2);
    if (iVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014058ad4e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2,iVar1,0);
      return uVar3;
    }
  }
  return 0;
}

// ==== CClanPKArenicActor@adapter::vfunc_70  @14058ad60  [high:rtti-vtable]  (orig: FUN_14058ad60)
undefined1 FUN_14058ad60(undefined8 param_1,undefined4 param_2)

{
  undefined1 uVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)FUN_140118320();
  if (plVar2 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014058ad7f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(*plVar2 + 0x80))(plVar2,param_2);
    return uVar1;
  }
  return 0;
}

// ==== CClanPKArenicActor@adapter::vfunc_54  @14058ad90  [high:rtti-vtable]  (orig: FUN_14058ad90)
ulonglong FUN_14058ad90(undefined8 param_1,int param_2,byte param_3)

{
  ulonglong in_RAX;
  
  if (param_3 < 4) {
    return (ulonglong)(param_2 == *(int *)(&DAT_1407aabf0 + (ulonglong)param_3 * 4));
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CClanPKArenicActor@adapter::vfunc_0  @14058adb0  [high:rtti-vtable]  (orig: FUN_14058adb0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14058adb0(longlong param_1,undefined8 param_2,char param_3)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  longlong *plVar6;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  undefined2 local_4c0;
  uint local_4b8;
  undefined4 local_4b0;
  undefined8 local_4a8;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  plVar6 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar6 == (longlong *)0x0) {
    local_4c8 = 0x34b;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140362560(local_498);
    uVar1 = (**(code **)(plVar6[2] + 0x50))(plVar6 + 2);
    uVar2 = (**(code **)(plVar6[2] + 0x48))(plVar6 + 2);
    uVar3 = (**(code **)(plVar6[2] + 0x40))(plVar6 + 2);
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    local_4b0 = 0;
    local_4b8 = (uint)(param_3 != '\0');
    local_4c0 = 1000;
    local_4c8 = CONCAT22(local_4c8._2_2_,uVar1);
    iVar5 = FUN_140362620(local_498,uVar4,uVar3,uVar2);
    if (iVar5 != 0) {
      (**(code **)(plVar6[2] + 0x350))(plVar6 + 2,local_498);
    }
    FUN_1403625e0(local_498);
  }
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_45  @14058aee0  [high:rtti-vtable]  (orig: FUN_14058aee0)
void FUN_14058aee0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165950(lVar1,param_3,1);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_46  @14058af40  [high:rtti-vtable]  (orig: FUN_14058af40)
void FUN_14058af40(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140177500(lVar1,param_3,1);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_47  @14058afa0  [high:rtti-vtable]  (orig: FUN_14058afa0)
undefined8 FUN_14058afa0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165940(lVar1);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_48  @14058b000  [high:rtti-vtable]  (orig: FUN_14058b000)
undefined8 FUN_14058b000(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165930(lVar1);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_49  @14058b060  [high:rtti-vtable]  (orig: FUN_14058b060)
void FUN_14058b060(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
  if (plVar1 == (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014058b0c5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR(
                      "CClanPKArenicActor::OnUserArenicHornorChange, not found arenic module interface"
                      );
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058b0d6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x110))(plVar1,param_2);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_42  @14058b0e0  [high:rtti-vtable]  (orig: FUN_14058b0e0)
ulonglong FUN_14058b0e0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5,undefined1 param_6,undefined1 param_7,undefined1 param_8)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140385de0(lVar1,param_3,param_4,param_5,param_6,param_7,param_8);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_43  @14058b180  [high:rtti-vtable]  (orig: FUN_14058b180)
void FUN_14058b180(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x00014058b19a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x30))(plVar1,param_2);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_44  @14058b1a0  [high:rtti-vtable]  (orig: FUN_14058b1a0)
void FUN_14058b1a0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar3 = (longlong *)FUN_1401181a0();
  cVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2,0x6a);
  if (cVar1 != '\0') {
    plVar3 = (longlong *)FUN_1401181a0();
    (**(code **)(*plVar3 + 0x10))(plVar3,param_2,0x6a);
  }
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_26  @14058b230  [high:rtti-vtable]  (orig: FUN_14058b230)
undefined8 FUN_14058b230(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  cVar1 = FUN_1401a4030(lVar2,param_3);
  if (cVar1 == '\0') {
    FUN_140179040(lVar2,param_3);
    return 0;
  }
  return 1;
}

// ==== CClanPKArenicActor@adapter::vfunc_0  @14058b2c0  [high:rtti-vtable]  (orig: FUN_14058b2c0)
void FUN_14058b2c0(longlong param_1)

{
  FUN_14058b320(param_1 + -8);
  return;
}

// ==== CClanPKArenicActor@adapter::helper_14058b320  @14058b320  [medium:callgraph-r0]  (orig: FUN_14058b320)
undefined8 * FUN_14058b320(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CClanPKArenicActor::vftable;
  param_1[1] = adapter::CClanPKArenicActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CClanPKArenicActor@adapter::vfunc_6  @14058b420  [high:rtti-vtable]  (orig: FUN_14058b420)
void FUN_14058b420(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_53  @14058b4e0  [high:rtti-vtable]  (orig: FUN_14058b4e0)
bool FUN_14058b4e0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  return lVar1 != 0;
}

// ==== CClanPKArenicActor@adapter::vfunc_56  @14058b560  [high:rtti-vtable]  (orig: FUN_14058b560)
ulonglong FUN_14058b560(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x14) & 1);
}

// ==== CClanPKArenicActor@adapter::vfunc_57  @14058b630  [high:rtti-vtable]  (orig: FUN_14058b630)
ulonglong FUN_14058b630(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x1e) & 1);
}

// ==== CClanPKArenicActor@adapter::vfunc_58  @14058b700  [high:rtti-vtable]  (orig: FUN_14058b700)
ulonglong FUN_14058b700(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 2) & 1);
}

// ==== CClanPKArenicActor@adapter::vfunc_59  @14058b7d0  [high:rtti-vtable]  (orig: FUN_14058b7d0)
void FUN_14058b7d0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x00014058b831. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x158))(*(longlong **)(lVar1 + 0x98),param_2);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_60  @14058b840  [high:rtti-vtable]  (orig: FUN_14058b840)
ulonglong FUN_14058b840(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  uint extraout_var;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)(extraout_var & 1);
}

// ==== CClanPKArenicActor@adapter::vfunc_61  @14058b910  [high:rtti-vtable]  (orig: FUN_14058b910)
void FUN_14058b910(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x00014058b964. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x150))();
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_37  @14058b970  [high:rtti-vtable]  (orig: FUN_14058b970)
undefined8 FUN_14058b970(longlong param_1)

{
  undefined2 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  undefined8 uVar6;
  uint in_stack_ffffffffffffffd8;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = *(undefined2 *)(lVar5 + 0xf0e);
  uVar2 = *(undefined2 *)(lVar5 + 0xf0c);
  uVar3 = FUN_140161f50(lVar5);
  in_stack_ffffffffffffffd8 = in_stack_ffffffffffffffd8 & 0xffffff00;
  iVar4 = FUN_1401c55b0(lVar5,uVar3,uVar2,uVar1,in_stack_ffffffffffffffd8);
  if (iVar4 != 0) {
    local_18 = 0;
    local_14 = 0;
    local_10 = 0;
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    uVar6 = FUN_1400d6610(uVar6);
    FUN_140006c50(uVar6,&local_18);
    FUN_1401c55b0(lVar5,local_18,local_14,local_10,in_stack_ffffffffffffffd8 & 0xffffff00);
  }
  return 1;
}

// ==== CClanPKArenicActor@adapter::vfunc_40  @14058ba60  [high:rtti-vtable]  (orig: FUN_14058ba60)
void FUN_14058ba60(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x180);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1400df9c0(lVar1,param_2);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_3  @14058bac0  [high:rtti-vtable]  (orig: FUN_14058bac0)
void FUN_14058bac0(longlong param_1,longlong param_2,int param_3)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined4 uVar4;
  
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0xffffffff,*(undefined2 *)(param_2 + 10),
                         param_2 + 0xc,*(ushort *)(param_2 + 8) - 4,0,0xfffffffffffffffe);
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar4 = 0xffffffff;
    if (param_3 != 0) {
      lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                        (*(longlong **)(param_1 + 0x10),param_3);
      uVar4 = 0xffffffff;
      if (lVar2 != 0) {
        uVar4 = *(undefined4 *)(lVar2 + 0x122c);
      }
    }
    plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar3 + 0x68))(plVar3,puVar1,uVar4);
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_5  @14058bba0  [high:rtti-vtable]  (orig: FUN_14058bba0)
void FUN_14058bba0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar4);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 0x68))(plVar3,puVar2,0xffffffff);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_4  @14058bc90  [high:rtti-vtable]  (orig: FUN_14058bc90)
void FUN_14058bc90(longlong param_1,undefined8 param_2,int param_3)

{
  longlong lVar1;
  longlong *plVar2;
  undefined4 uVar3;
  
  if (param_3 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_3);
    if (lVar1 != 0) {
      uVar3 = *(undefined4 *)(lVar1 + 0x122c);
      goto LAB_14058bcca;
    }
  }
  uVar3 = 0xffffffff;
LAB_14058bcca:
  plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  (**(code **)(*plVar2 + 0x60))(plVar2,param_2,uVar3,0,0xffffff,0x7e6);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_52  @14058bd10  [high:rtti-vtable]  (orig: FUN_14058bd10)
ulonglong FUN_14058bd10(longlong param_1)

{
  uint extraout_var;
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong *plVar3;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX;
  }
  else {
    lVar1 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x160))(lVar1 + 0x10);
    uVar2 = 0;
    if (lVar1 != 0) {
      plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
      (**(code **)(*plVar3 + 0x58))(plVar3);
      return (ulonglong)(extraout_var & 1);
    }
  }
  return uVar2 & 0xffffffffffffff00;
}

// ==== CClanPKArenicActor@adapter::vfunc_1  @14058bda0  [high:rtti-vtable]  (orig: FUN_14058bda0)
ulonglong FUN_14058bda0(longlong param_1,undefined4 param_2,int param_3)

{
  longlong lVar1;
  ulonglong uVar2;
  ulonglong extraout_RAX;
  undefined8 uVar3;
  
  if (param_3 == 0) {
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar1 + 0xa8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar2 = FUN_140145f60(*(undefined8 *)(lVar1 + 0xa8),param_2,0,0,0,0);
    return uVar2;
  }
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),param_3);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  uVar3 = FUN_140087730(uVar3);
  uVar2 = FUN_140145f60(uVar3,param_2,lVar1,0,0,0);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_73  @14058bec0  [high:rtti-vtable]  (orig: FUN_14058bec0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_14058bec0(longlong param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  undefined1 auStack_68 [32];
  undefined4 local_48;
  char local_38 [32];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  if (param_2 == (char *)0x0) {
    local_48 = 0x359;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_38[0] = '\0';
    local_38[1] = '\0';
    local_38[2] = '\0';
    local_38[3] = '\0';
    local_38[4] = '\0';
    local_38[5] = '\0';
    local_38[6] = '\0';
    local_38[7] = '\0';
    local_38[8] = '\0';
    local_38[9] = '\0';
    local_38[10] = '\0';
    local_38[0xb] = '\0';
    local_38[0xc] = '\0';
    local_38[0xd] = '\0';
    local_38[0xe] = '\0';
    local_38[0xf] = '\0';
    local_38[0x10] = '\0';
    local_38[0x11] = '\0';
    local_38[0x12] = '\0';
    local_38[0x13] = '\0';
    local_38[0x14] = '\0';
    local_38[0x15] = '\0';
    local_38[0x16] = '\0';
    local_38[0x17] = '\0';
    local_38[0x18] = '\0';
    local_38[0x19] = '\0';
    local_38[0x1a] = '\0';
    local_38[0x1b] = '\0';
    local_38[0x1c] = '\0';
    local_38[0x1d] = '\0';
    local_38[0x1e] = '\0';
    local_38[0x1f] = 0;
    strncpy(local_38,param_2,0x20);
    iVar2 = tq::StringCheck(local_38,0);
    if (iVar2 != 0) {
      iVar2 = tq::NameStrCheck(local_38,true);
      if (iVar2 != 0) {
        uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        cVar1 = FUN_14008a1d0(uVar3,local_38,1);
        return cVar1 == '\0';
      }
    }
  }
  return false;
}

// ==== CClanPKArenicActor@adapter::vfunc_75  @14058bfa0  [high:rtti-vtable]  (orig: FUN_14058bfa0)
void FUN_14058bfa0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x200);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140269300(lVar1,param_2,param_3,param_4,param_5);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_74  @14058c020  [high:rtti-vtable]  (orig: FUN_14058c020)
void FUN_14058c020(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006c50(*(undefined8 *)(lVar1 + 0xb0),param_2);
  return;
}

// ==== CClanPKArenicActor@adapter::vfunc_55  @14058c090  [high:rtti-vtable]  (orig: FUN_14058c090)
ulonglong FUN_14058c090(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_14011dbb0(lVar1);
  return uVar2;
}

// ==== CClanPKArenicActor@adapter::vfunc_50  @14058c140  [high:rtti-vtable]  (orig: FUN_14058c140)
undefined1 FUN_14058c140(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined1 uVar8;
  longlong *plVar9;
  longlong *local_res8;
  longlong *local_res18;
  longlong *local_60 [3];
  longlong *local_48;
  longlong *local_40;
  undefined8 local_38;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar5 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x98) + 0x10))
                    (*(longlong **)(lVar5 + 0x98),param_2,1);
  uVar8 = 0;
  if (lVar5 != 0) {
    local_res8 = operator_new(8);
    plVar9 = (longlong *)0x0;
    local_60[0] = plVar9;
    if (local_res8 != (longlong *)0x0) {
      *local_res8 = (longlong)local_60;
      local_60[0] = local_res8;
    }
    local_48 = (longlong *)0x0;
    local_40 = (longlong *)0x0;
    local_38 = 0;
    local_res18 = local_res8;
    FUN_1402d2100(lVar5,local_60);
    plVar6 = local_48;
    if (((longlong)local_40 - (longlong)local_48 & 0xfffffffffffffff8U) == 0) {
      if (local_48 != (longlong *)0x0) {
        operator_delete(local_48);
      }
      local_48 = (longlong *)0x0;
      local_40 = (longlong *)0x0;
      local_38 = 0;
      operator_delete(local_60[0]);
      uVar8 = 0;
    }
    else {
      if (local_40 < local_48) {
        _invalid_parameter_noinfo();
      }
      plVar3 = local_40;
      plVar1 = local_60[0];
      if (local_40 < local_48) {
        _invalid_parameter_noinfo();
      }
      plVar2 = local_60[0];
      uVar8 = 0;
      while( true ) {
        if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar2)) {
          _invalid_parameter_noinfo();
        }
        if (plVar6 == plVar3) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar9;
        }
        else {
          plVar7 = (longlong *)*plVar1;
        }
        if ((longlong *)plVar7[4] <= plVar6) {
          _invalid_parameter_noinfo();
        }
        plVar7 = (longlong *)*plVar6;
        if (plVar7 != (longlong *)0x0) {
          local_res8 = (longlong *)0x0;
          cVar4 = (**(code **)(*plVar7 + 0x40))(plVar7,&local_res8);
          if ((cVar4 != '\0') && (local_res8 != (longlong *)0x0)) {
            local_res18 = (longlong *)0x0;
            cVar4 = (**(code **)(*local_res8 + 0x298))(local_res8,0x1001,&local_res18);
            if ((cVar4 != '\0') && (local_res18 != (longlong *)0x0)) {
              (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                        (*(longlong **)(param_1 + 0x10),local_res18,
                         "CClanPKArenicActor::ClearArenicMap, invalid stay in clan pk arenic");
              uVar8 = 1;
            }
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar9;
        }
        else {
          plVar7 = (longlong *)*plVar1;
        }
        if ((longlong *)plVar7[4] <= plVar6) {
          _invalid_parameter_noinfo();
        }
        plVar6 = plVar6 + 1;
      }
      if (local_48 != (longlong *)0x0) {
        operator_delete(local_48);
      }
      local_48 = (longlong *)0x0;
      local_40 = (longlong *)0x0;
      local_38 = 0;
      operator_delete(local_60[0]);
    }
  }
  return uVar8;
}

// ==== CClanPKArenicActor@adapter::vfunc_65  @14058c3b0  [high:rtti-vtable]  (orig: FUN_14058c3b0)
undefined8 FUN_14058c3b0(undefined8 param_1,undefined4 param_2,longlong param_3)

{
  longlong *plVar1;
  ulonglong uVar2;
  
  FUN_140036640(param_3);
  plVar1 = (longlong *)FUN_140118320();
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x38))(plVar1,param_2,param_3);
  }
  uVar2 = *(longlong *)(param_3 + 0x20) - *(longlong *)(param_3 + 0x18);
  return CONCAT71((int7)(uVar2 >> 8),(uVar2 & 0xfffffffffffffffc) != 0);
}

// ==== CClanPKArenicActor@adapter::vfunc_2  @14058c400  [high:rtti-vtable]  (orig: FUN_14058c400)
void FUN_14058c400(longlong param_1,longlong *param_2,undefined8 param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  undefined4 *puVar9;
  longlong *local_res20;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  
  local_res20 = operator_new(8);
  local_68[0] = (longlong *)0x0;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_68;
    local_68[0] = local_res20;
  }
  local_50 = (undefined4 *)0x0;
  local_48 = (undefined4 *)0x0;
  local_40 = 0;
  puVar9 = (undefined4 *)param_2[3];
  if ((undefined4 *)param_2[4] < puVar9) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (ulonglong *)*param_2;
  do {
    uVar7 = 0;
    puVar2 = (undefined4 *)param_2[4];
    if (puVar2 < (undefined4 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != (ulonglong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar9 == puVar2) {
      plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar6 + 0x38))(plVar6,local_68,param_3);
      if (local_50 != (undefined4 *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (undefined4 *)0x0;
      local_48 = (undefined4 *)0x0;
      local_40 = 0;
      operator_delete(local_68[0]);
      if ((void *)param_2[3] != (void *)0x0) {
        operator_delete((void *)param_2[3]);
      }
      param_2[3] = 0;
      param_2[4] = 0;
      param_2[5] = 0;
      operator_delete((void *)*param_2);
      return;
    }
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar8 = uVar7;
    }
    else {
      uVar8 = *puVar1;
    }
    if (*(undefined4 **)(uVar8 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),*puVar9);
    puVar2 = local_48;
    if (lVar4 != 0) {
      local_res20 = (longlong *)CONCAT44(local_res20._4_4_,*(undefined4 *)(lVar4 + 0x122c));
      if (local_50 != (undefined4 *)0x0) {
        uVar7 = local_40 - (longlong)local_50 >> 2;
      }
      if ((ulonglong)((longlong)local_48 - (longlong)local_50 >> 2) < uVar7) {
        *local_48 = *(undefined4 *)(lVar4 + 0x122c);
        local_48 = local_48 + 1;
      }
      else {
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        puVar3 = local_50;
        plVar6 = local_68[0];
        if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) == 0) {
          lVar4 = 0;
        }
        else {
          if (local_48 < local_50) {
            _invalid_parameter_noinfo();
          }
          if ((plVar6 == (longlong *)0x0) || (plVar6 != local_68[0])) {
            _invalid_parameter_noinfo();
          }
          lVar4 = (longlong)puVar2 - (longlong)puVar3 >> 2;
        }
        local_88 = SUB84(plVar6,0);
        uStack_84 = (undefined4)((ulonglong)plVar6 >> 0x20);
        uStack_80 = SUB84(puVar2,0);
        uStack_7c = (undefined4)((ulonglong)puVar2 >> 0x20);
        local_78 = local_88;
        uStack_74 = uStack_84;
        uStack_70 = uStack_80;
        uStack_6c = uStack_7c;
        FUN_140036c20(local_68,&local_78,1,&local_res20);
        puVar2 = local_50;
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        plVar6 = local_68[0];
        if (local_68[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *local_68[0];
        }
        if (puVar2 + lVar4 <= *(undefined4 **)(lVar5 + 0x20)) {
          if (plVar6 == (longlong *)0x0) {
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar6;
          }
          if (*(undefined4 **)(lVar5 + 0x18) <= puVar2 + lVar4) goto LAB_14058c610;
        }
        _invalid_parameter_noinfo();
      }
    }
LAB_14058c610:
    uVar7 = 0;
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      uVar7 = *puVar1;
    }
    if (*(undefined4 **)(uVar7 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    puVar9 = puVar9 + 1;
  } while( true );
}

