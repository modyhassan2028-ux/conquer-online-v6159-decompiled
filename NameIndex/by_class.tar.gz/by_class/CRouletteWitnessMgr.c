// ==== CRouletteWitnessMgr::ctor_or_dtor  @1404dcc40  [high:vtable-assign]  (orig: FUN_1404dcc40)
void FUN_1404dcc40(undefined8 *param_1)

{
  *param_1 = CRouletteWitnessMgr::vftable;
  param_1 = param_1 + 1;
  FUN_14000a7b0(param_1);
  FUN_14000c310(param_1);
  operator_delete((void *)*param_1);
  return;
}

// ==== CRouletteWitnessMgr::ctor_or_dtor  @1404dcc90  [high:vtable-assign]  (orig: FUN_1404dcc90)
undefined8 * FUN_1404dcc90(undefined8 *param_1)

{
  *param_1 = CRouletteWitnessMgr::vftable;
  FUN_14000ef40(param_1 + 1);
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined4 *)((longlong)param_1 + 0x4c) = 0;
  return param_1;
}

// ==== CRouletteWitnessMgr::ctor_or_dtor  @1404dccd0  [high:vtable-assign]  (orig: FUN_1404dccd0)
undefined8 * FUN_1404dccd0(undefined8 *param_1,uint param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CRouletteWitnessMgr::vftable;
  puVar1 = param_1 + 1;
  FUN_14000a7b0(puVar1);
  FUN_14000c310(puVar1);
  operator_delete((void *)*puVar1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CRouletteWitnessMgr::ctor_or_dtor  @1404dcd50  [high:vtable-assign]  (orig: FUN_1404dcd50)
undefined8 * FUN_1404dcd50(undefined4 param_1,undefined4 param_2)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CRouletteWitnessMgr::vftable;
    FUN_14000ef40(puVar1 + 1);
    *(undefined4 *)(puVar1 + 9) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x4c) = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *(undefined4 *)((longlong)puVar1 + 0x4c) = param_1;
    *(undefined4 *)(puVar1 + 9) = param_2;
    FUN_14000a7b0(puVar1 + 1);
  }
  return puVar1;
}

