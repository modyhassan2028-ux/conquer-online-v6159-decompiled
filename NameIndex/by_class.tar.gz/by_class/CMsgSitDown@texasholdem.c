// ==== CMsgSitDown@texasholdem::helper_140217e40  @140217e40  [medium:callgraph-r3]  (orig: FUN_140217e40)
undefined8 * FUN_140217e40(undefined8 *param_1,uint *param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong *local_1e8;
  undefined8 *puStack_1e0;
  longlong *local_1d8;
  undefined8 *puStack_1d0;
  longlong *local_1c8;
  undefined8 *puStack_1c0;
  longlong *local_1b8 [6];
  undefined8 *local_188;
  undefined8 local_180;
  void *local_178 [8];
  undefined4 local_138;
  undefined4 local_134;
  undefined4 local_130;
  undefined4 local_12c;
  undefined8 local_128;
  undefined8 local_120;
  undefined8 local_118;
  undefined8 local_110;
  undefined8 local_108;
  undefined1 local_100 [16];
  undefined1 local_f0 [16];
  uint local_e0 [2];
  void *local_d8 [8];
  void *local_98 [14];
  
  local_108 = 0xfffffffffffffffe;
  puVar6 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar6[1] + 0xd1) == '\0') {
    puVar3 = (undefined8 *)puVar6[1];
    do {
      if (*(uint *)(puVar3 + 3) < *param_2) {
        puVar4 = (undefined8 *)puVar3[2];
      }
      else {
        puVar4 = (undefined8 *)*puVar3;
        puVar6 = puVar3;
      }
      puVar3 = puVar4;
    } while (*(char *)((longlong)puVar4 + 0xd1) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar3 = (undefined8 *)param_1[6];
  local_1d8 = plVar5;
  puStack_1d0 = puVar6;
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar7 = (longlong *)0x0;
  if ((puVar6 == puVar3) || (*param_2 < *(uint *)(puVar6 + 3))) {
    local_1e8 = local_1d8;
    puStack_1e0 = puStack_1d0;
    plVar5 = operator_new(8);
    local_1b8[0] = plVar7;
    if (plVar5 != (longlong *)0x0) {
      *plVar5 = (longlong)local_1b8;
      local_1b8[0] = plVar5;
    }
    local_188 = (undefined8 *)FUN_140009e80(local_1b8);
    *(undefined1 *)((longlong)local_188 + 0x1d) = 1;
    local_188[1] = local_188;
    *local_188 = local_188;
    local_188[2] = local_188;
    local_180 = 0;
    FUN_14000ef40(local_178);
    cVar1 = *(char *)((longlong)local_188[1] + 0x1d);
    plVar5 = (longlong *)local_188[1];
    while (cVar1 == '\0') {
      FUN_1400098c0(local_1b8,plVar5[2]);
      plVar2 = (longlong *)*plVar5;
      operator_delete(plVar5);
      plVar5 = plVar2;
      cVar1 = *(char *)((longlong)plVar2 + 0x1d);
    }
    local_188[1] = local_188;
    local_180 = 0;
    *local_188 = local_188;
    local_188[2] = local_188;
    FUN_14000a7b0(local_178);
    local_138 = 0;
    local_134 = 0;
    local_130 = 0;
    local_12c = 0;
    local_128 = 0;
    local_120 = 0;
    local_118 = 0;
    local_110 = 0;
    local_e0[0] = *param_2;
    FUN_140215870(local_d8,local_1b8);
    puVar6 = (undefined8 *)FUN_1402179b0(param_1,local_100,&local_1e8,local_e0);
    local_1d8 = (longlong *)*puVar6;
    puStack_1d0 = (undefined8 *)puVar6[1];
    FUN_14000c310(local_98);
    operator_delete(local_98[0]);
    FUN_14000c310(local_d8);
    operator_delete(local_d8[0]);
    FUN_14000c310(local_178);
    operator_delete(local_178[0]);
    puStack_1e0 = (undefined8 *)*local_188;
    local_1c8 = local_1b8[0];
    puStack_1c0 = local_188;
    local_1e8 = local_1b8[0];
    FUN_14000bd50(local_1b8,local_f0,&local_1e8,&local_1c8);
    operator_delete(local_188);
    local_188 = (undefined8 *)0x0;
    local_180 = 0;
    operator_delete(local_1b8[0]);
    puVar6 = puStack_1d0;
    plVar5 = local_1d8;
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    plVar7 = (longlong *)*plVar5;
  }
  if (puVar6 == (undefined8 *)plVar7[6]) {
    _invalid_parameter_noinfo();
  }
  return puVar6 + 4;
}

// ==== CMsgSitDown@texasholdem::helper_140218300  @140218300  [medium:callgraph-r2]  (orig: FUN_140218300)
void FUN_140218300(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  undefined8 uVar6;
  longlong lVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  uint local_res10 [2];
  undefined4 local_res18 [2];
  longlong local_68;
  undefined8 *local_60;
  longlong local_58;
  undefined8 local_50;
  longlong local_48;
  undefined8 *local_40;
  
  if (param_2 != 0) {
    local_res18[0] = FUN_1403bc320(param_2);
    cVar3 = FUN_1403bc2d0(param_2);
    if (cVar3 != '\0') {
      uVar4 = FUN_1403bc2e0(param_2);
      puVar1 = *(undefined8 **)(param_1 + 0xd0);
      lVar7 = *(longlong *)(param_1 + 0xa0);
      cVar3 = *(char *)((longlong)puVar1[1] + 0x2d);
      puVar2 = puVar1;
      puVar10 = (undefined8 *)puVar1[1];
      while (cVar3 == '\0') {
        if (*(uint *)(puVar10 + 3) < uVar4) {
          puVar8 = (undefined8 *)puVar10[2];
          puVar10 = puVar2;
        }
        else {
          puVar8 = (undefined8 *)*puVar10;
        }
        puVar2 = puVar10;
        puVar10 = puVar8;
        cVar3 = *(char *)((longlong)puVar8 + 0x2d);
      }
      local_60 = puVar2;
      local_68 = lVar7;
      local_res10[0] = uVar4;
      if (lVar7 == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar2 == puVar1) || (uVar4 < *(uint *)(puVar2 + 3))) {
        plVar9 = &local_58;
        local_50 = *(undefined8 *)(param_1 + 0xd0);
        local_58 = *(longlong *)(param_1 + 0xa0);
      }
      else {
        plVar9 = &local_68;
      }
      local_48 = *plVar9;
      local_40 = (undefined8 *)plVar9[1];
      if ((local_48 == 0) || (local_48 != lVar7)) {
        _invalid_parameter_noinfo();
      }
      if (local_40 != puVar1) {
        iVar5 = FUN_1403c03e0(param_2);
        if (iVar5 < 9) {
          if (iVar5 < 7) {
            if (iVar5 < 4) {
              if (iVar5 < 1) {
                uVar6 = FUN_140217cc0(param_1 + 0x60,local_res10);
                FUN_14000d630(uVar6,local_res18);
                lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
                FUN_14000d630(lVar7 + 0x40,local_res18);
                lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
                FUN_14000d630(lVar7 + 0x80,local_res18);
                lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
                FUN_14000d630(lVar7 + 0xc0,local_res18);
                lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
                FUN_14000d480(lVar7 + 0x100,&local_48,local_res18);
                return;
              }
              uVar6 = FUN_140217cc0(param_1 + 0x60,local_res10);
              FUN_14000d480(uVar6,&local_48,local_res18);
              lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
              FUN_14000d630(lVar7 + 0x40,local_res18);
            }
            else {
              uVar6 = FUN_140217cc0(param_1 + 0x60,local_res10);
              FUN_14000d630(uVar6,local_res18);
              lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
              FUN_14000d480(lVar7 + 0x40,&local_48,local_res18);
            }
            lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
            FUN_14000d630(lVar7 + 0x80,local_res18);
          }
          else {
            uVar6 = FUN_140217cc0(param_1 + 0x60,local_res10);
            FUN_14000d630(uVar6,local_res18);
            lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
            FUN_14000d630(lVar7 + 0x40,local_res18);
            lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
            FUN_14000d480(lVar7 + 0x80,&local_48,local_res18);
          }
          lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
          FUN_14000d630(lVar7 + 0xc0,local_res18);
        }
        else {
          uVar6 = FUN_140217cc0(param_1 + 0x60,local_res10);
          FUN_14000d630(uVar6,local_res18);
          lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
          FUN_14000d630(lVar7 + 0x40,local_res18);
          lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
          FUN_14000d630(lVar7 + 0x80,local_res18);
          lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
          FUN_14000d480(lVar7 + 0xc0,&local_48,local_res18);
        }
        lVar7 = FUN_140217cc0(param_1 + 0x60,local_res10);
        FUN_14000d630(lVar7 + 0x100,local_res18);
        return;
      }
    }
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1402187b0  @1402187b0  [medium:callgraph-r2]  (orig: FUN_1402187b0)
void FUN_1402187b0(longlong param_1,char param_2,uint param_3,int param_4)

{
  longlong lVar1;
  uint local_res18 [4];
  
  local_res18[0] = param_3;
  if (param_2 == '\0') {
    local_res18[0] = param_3 + (param_3 / 1000000) * -1000000 + 1000000;
  }
  if (param_4 == 0) {
    lVar1 = FUN_140217e40(param_1 + 0xe0,local_res18);
    *(int *)(lVar1 + 0x88) = *(int *)(lVar1 + 0x88) + 1;
    return;
  }
  lVar1 = FUN_140217e40(param_1 + 0xe0,local_res18);
  *(int *)(lVar1 + 0x8c) = *(int *)(lVar1 + 0x8c) + 1;
  return;
}

// ==== CMsgSitDown@texasholdem::helper_14031c520  @14031c520  [medium:callgraph-r3]  (orig: FUN_14031c520)
void FUN_14031c520(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_14031bf40();
  if (lVar1 != 0) {
    FUN_1404bfa90(lVar1,param_3);
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403bc2e0  @1403bc2e0  [medium:callgraph-r3]  (orig: FUN_1403bc2e0)
undefined4 FUN_1403bc2e0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x290);
}

// ==== CMsgSitDown@texasholdem::helper_1403bcb00  @1403bcb00  [medium:callgraph-r3]  (orig: FUN_1403bcb00)
void FUN_1403bcb00(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x81) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x81) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x81);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x81);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x81);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x81);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001403bcb27. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403c03e0  @1403c03e0  [medium:callgraph-r3]  (orig: FUN_1403c03e0)
undefined4 FUN_1403c03e0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x140);
}

// ==== CMsgSitDown@texasholdem::helper_1403c3630  @1403c3630  [medium:callgraph-r3]  (orig: FUN_1403c3630)
void FUN_1403c3630(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1403c3630(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403c5200  @1403c5200  [medium:callgraph-r3]  (orig: FUN_1403c5200)
void FUN_1403c5200(longlong param_1,undefined2 *param_2)

{
  undefined2 *puVar1;
  undefined2 uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined2 *puVar7;
  
  puVar7 = (undefined2 *)(param_1 + 2);
  uVar6 = 2;
  do {
    if (puVar7 == param_2) {
      return;
    }
    uVar5 = 0x7fff;
    uVar3 = rand();
    uVar3 = uVar3 & 0x7fff;
    if (0x7fff < uVar6) {
      do {
        if (uVar5 == 0xffffffff) break;
        uVar4 = rand();
        uVar5 = uVar5 << 0xf | 0x7fff;
        uVar3 = uVar4 & 0x7fff | uVar3 << 0xf;
      } while (uVar5 < uVar6);
    }
    puVar1 = (undefined2 *)(param_1 + ((ulonglong)uVar3 % (ulonglong)uVar6) * 2);
    if (puVar7 != puVar1) {
      uVar2 = *puVar7;
      *puVar7 = *puVar1;
      *puVar1 = uVar2;
    }
    puVar7 = puVar7 + 1;
    uVar6 = uVar6 + 1;
  } while( true );
}

// ==== CMsgSitDown@texasholdem::helper_1403c55d0  @1403c55d0  [medium:callgraph-r2]  (orig: FUN_1403c55d0)
void FUN_1403c55d0(undefined2 *param_1,longlong param_2,undefined2 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined2 *)0x0) {
      *param_1 = *param_3;
    }
    param_1 = param_1 + 1;
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403c5610  @1403c5610  [medium:callgraph-r3]  (orig: FUN_1403c5610)
void FUN_1403c5610(undefined8 *param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = *param_3;
    }
    param_1 = param_1 + 1;
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403c60a0  @1403c60a0  [medium:callgraph-r2]  (orig: FUN_1403c60a0)
void FUN_1403c60a0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1403c3630(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403c6120  @1403c6120  [medium:callgraph-r3]  (orig: FUN_1403c6120)
void FUN_1403c6120(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x25);
  while (cVar1 == '\0') {
    FUN_1403c3680(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x25);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403c6960  @1403c6960  [medium:callgraph-r3]  (orig: FUN_1403c6960)
undefined8 * FUN_1403c6960(undefined8 *param_1,undefined8 *param_2,byte *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x1a) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(byte *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x1a) != '\0') && (*param_3 < *(byte *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x1a) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x1a) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x1a) == '\0') {
    do {
      if (*param_3 < *(byte *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x1a) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMsgSitDown@texasholdem::helper_1403c73f0  @1403c73f0  [medium:callgraph-r2]  (orig: FUN_1403c73f0)
undefined8 * FUN_1403c73f0(undefined8 *param_1,undefined8 *param_2,byte *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x81) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(byte *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x81) != '\0') && (*param_3 < *(byte *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x81) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x81) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x81) == '\0') {
    do {
      if (*param_3 < *(byte *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x81) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMsgSitDown@texasholdem::helper_1403c9700  @1403c9700  [medium:callgraph-r2]  (orig: FUN_1403c9700)
undefined8 FUN_1403c9700(longlong param_1,int *param_2)

{
  char cVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong lVar7;
  
  *param_2 = 0;
  puVar2 = *(undefined8 **)(param_1 + 0x138);
  plVar3 = *(longlong **)(param_1 + 0x108);
  puVar6 = (undefined8 *)*puVar2;
  while( true ) {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar6 == puVar2) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar3;
    }
    if (puVar6 == *(undefined8 **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)(puVar6 + 0xc) == '\x01') {
      *param_2 = *param_2 + 1;
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar6 + 0x81) == '\0') {
      puVar4 = (undefined8 *)puVar6[2];
      if (*(char *)((longlong)puVar4 + 0x81) == '\0') {
        cVar1 = *(char *)((longlong)*puVar4 + 0x81);
        puVar6 = puVar4;
        puVar4 = (undefined8 *)*puVar4;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar4 + 0x81);
          puVar6 = puVar4;
          puVar4 = (undefined8 *)*puVar4;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar6[1] + 0x81);
        puVar5 = (undefined8 *)puVar6[1];
        puVar4 = puVar6;
        while ((puVar6 = puVar5, cVar1 == '\0' && (puVar4 == (undefined8 *)puVar6[2]))) {
          cVar1 = *(char *)((longlong)puVar6[1] + 0x81);
          puVar5 = (undefined8 *)puVar6[1];
          puVar4 = puVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return 1;
}

// ==== CMsgSitDown@texasholdem::helper_1403c9910  @1403c9910  [medium:callgraph-r1]  (orig: FUN_1403c9910)
undefined1 FUN_1403c9910(undefined8 param_1)

{
  char cVar1;
  int local_res10 [6];
  
  local_res10[0] = 0;
  cVar1 = FUN_1403c9700(param_1,local_res10);
  if ((cVar1 != '\0') && (1 < local_res10[0])) {
    return 1;
  }
  return 0;
}

// ==== CMsgSitDown@texasholdem::helper_1403c9940  @1403c9940  [medium:callgraph-r3]  (orig: FUN_1403c9940)
undefined8 FUN_1403c9940(undefined8 param_1,longlong *param_2,int param_3)

{
  char cVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong lVar6;
  
  puVar2 = (undefined8 *)param_2[6];
  param_2 = (longlong *)*param_2;
  puVar5 = (undefined8 *)*puVar2;
  while( true ) {
    if (param_2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar5 == puVar2) {
      return 0;
    }
    if (param_2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *param_2;
    }
    if (puVar5 == *(undefined8 **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(int *)(puVar5 + 4) == param_3) break;
    if (param_2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar5 + 0x81) == '\0') {
      puVar3 = (undefined8 *)puVar5[2];
      if (*(char *)((longlong)puVar3 + 0x81) == '\0') {
        cVar1 = *(char *)((longlong)*puVar3 + 0x81);
        puVar5 = puVar3;
        puVar3 = (undefined8 *)*puVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar3 + 0x81);
          puVar5 = puVar3;
          puVar3 = (undefined8 *)*puVar3;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar5[1] + 0x81);
        puVar4 = (undefined8 *)puVar5[1];
        puVar3 = puVar5;
        while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)puVar5[2]))) {
          cVar1 = *(char *)((longlong)puVar5[1] + 0x81);
          puVar4 = (undefined8 *)puVar5[1];
          puVar3 = puVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return 1;
}

// ==== CMsgSitDown@texasholdem::helper_1403c9b60  @1403c9b60  [medium:callgraph-r3]  (orig: FUN_1403c9b60)
ulonglong FUN_1403c9b60(longlong *param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = 0;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 - 2;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    lVar2 = lVar3;
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1403c9bd7;
  }
  _invalid_parameter_noinfo();
LAB_1403c9bd7:
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x20) <= uVar1) {
    _invalid_parameter_noinfo();
  }
  return uVar1;
}

// ==== CMsgSitDown@texasholdem::helper_1403cc130  @1403cc130  [medium:callgraph-r2]  (orig: FUN_1403cc130)
undefined4 FUN_1403cc130(longlong param_1)

{
  longlong lVar1;
  longlong *local_18;
  longlong local_10;
  
  FUN_1403c9dd0((longlong *)(param_1 + 0x108),&local_18,param_1 + 0x188);
  lVar1 = *(longlong *)(param_1 + 0x138);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x108))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 == lVar1) {
    return 0;
  }
  if (local_18 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar1 = 0;
  }
  else {
    lVar1 = *local_18;
  }
  if (local_10 == *(longlong *)(lVar1 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return *(undefined4 *)(local_10 + 0x20);
}

// ==== CMsgSitDown@texasholdem::helper_1403cc7d0  @1403cc7d0  [medium:callgraph-r2]  (orig: FUN_1403cc7d0)
longlong FUN_1403cc7d0(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_1403c6960(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x1a) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x1a) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x1a);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x1a);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x1a);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x1a);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140203080(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMsgSitDown@texasholdem::helper_1403ccb80  @1403ccb80  [medium:callgraph-r3]  (orig: FUN_1403ccb80)
longlong * FUN_1403ccb80(longlong *param_1,longlong *param_2,byte *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x51) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(byte *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x51) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(byte *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgSitDown@texasholdem::helper_1403ce790  @1403ce790  [medium:callgraph-r3]  (orig: FUN_1403ce790)
void FUN_1403ce790(longlong param_1,longlong param_2,ulonglong param_3,undefined2 *param_4)

{
  undefined2 uVar1;
  void *pvVar2;
  undefined1 uVar3;
  longlong lVar4;
  undefined2 *puVar5;
  undefined8 uVar6;
  longlong lVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  undefined2 *puVar10;
  longlong local_res8;
  
  lVar7 = *(longlong *)(param_1 + 0x18);
  if (lVar7 == 0) {
    uVar8 = 0;
  }
  else {
    uVar8 = *(longlong *)(param_1 + 0x28) - lVar7 >> 1;
  }
  if (param_3 != 0) {
    lVar4 = *(longlong *)(param_1 + 0x20);
    lVar7 = lVar4 - lVar7 >> 1;
    if (0x7fffffffffffffffU - lVar7 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1403bd360();
    }
    uVar9 = param_3 + lVar7;
    if (uVar8 < uVar9) {
      if (0x7fffffffffffffff - (uVar8 >> 1) < uVar8) {
        uVar8 = 0;
      }
      else {
        uVar8 = uVar8 + (uVar8 >> 1);
      }
      if (uVar8 < uVar9) {
        uVar8 = uVar9;
      }
      lVar4 = FUN_1403c10f0(param_1 + 0x10,uVar8);
      lVar7 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 1;
      local_res8._0_1_ = (undefined1)lVar4;
      uVar3 = (undefined1)local_res8;
      local_res8 = lVar4;
      FUN_1403c55d0(lVar4 + lVar7 * 2,param_3,param_4,param_1 + 0x10,uVar3,0);
      FUN_1403c28f0(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar4,
                    param_1 + 0x10,(undefined1)local_res8,0,1);
      FUN_1403c28f0(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    lVar4 + (lVar7 + param_3) * 2,param_1 + 0x10,(undefined1)local_res8,0,2);
      pvVar2 = *(void **)(param_1 + 0x18);
      lVar7 = *(longlong *)(param_1 + 0x20);
      if (pvVar2 != (void *)0x0) {
        operator_delete(pvVar2);
      }
      *(ulonglong *)(param_1 + 0x28) = lVar4 + uVar8 * 2;
      *(ulonglong *)(param_1 + 0x20) = lVar4 + (param_3 + (lVar7 - (longlong)pvVar2 >> 1)) * 2;
      *(longlong *)(param_1 + 0x18) = lVar4;
    }
    else if ((ulonglong)(lVar4 - *(longlong *)(param_2 + 8) >> 1) < param_3) {
      uVar1 = *param_4;
      local_res8 = CONCAT62(local_res8._2_6_,uVar1);
      lVar7 = local_res8;
      local_res8._0_1_ = (undefined1)uVar1;
      uVar3 = (undefined1)local_res8;
      local_res8 = lVar7;
      FUN_1403c28f0(*(longlong *)(param_2 + 8),lVar4,*(longlong *)(param_2 + 8) + param_3 * 2,
                    param_1 + 0x10,uVar3,0);
      FUN_1403c55d0(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 1),
                    &local_res8,param_1 + 0x10,(undefined1)local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 2;
      lVar7 = *(longlong *)(param_1 + 0x20);
      for (puVar5 = *(undefined2 **)(param_2 + 8); puVar5 != (undefined2 *)(lVar7 + param_3 * -2);
          puVar5 = puVar5 + 1) {
        *puVar5 = uVar1;
      }
    }
    else {
      uVar1 = *param_4;
      lVar7 = lVar4 + param_3 * -2;
      uVar6 = FUN_1403c28f0(lVar7,lVar4,lVar4,param_1 + 0x10);
      *(undefined8 *)(param_1 + 0x20) = uVar6;
      FUN_1403c8ee0(*(undefined8 *)(param_2 + 8),lVar7,lVar4);
      puVar10 = *(undefined2 **)(param_2 + 8);
      puVar5 = puVar10 + param_3;
      for (; puVar10 != puVar5; puVar10 = puVar10 + 1) {
        *puVar10 = uVar1;
      }
    }
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403cfb80  @1403cfb80  [medium:callgraph-r1]  (orig: FUN_1403cfb80)
void FUN_1403cfb80(longlong param_1,int param_2,undefined1 param_3,char param_4)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  int local_res10 [2];
  undefined1 local_res18 [16];
  longlong *local_50;
  longlong local_48;
  longlong *local_40 [3];
  
  if (*(longlong *)(param_1 + 0x218) == 0) {
    local_res10[0] = param_2;
    local_res18[0] = param_3;
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
    if (*(longlong *)(lVar2 + 0x108) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = 0;
    }
    else {
      uVar3 = *(undefined8 *)(lVar2 + 0x108);
    }
    lVar2 = 0;
    FUN_140218300(uVar3,param_1);
    if (param_4 == '\0') {
      FUN_140203500(param_1 + 0x250,local_40,local_res18);
      if (*(int *)(param_1 + 0x298) != 0) {
        FUN_1403cd010(param_1 + 0x2a8,&local_50,local_res10);
        lVar1 = *(longlong *)(param_1 + 0x2d8);
        local_40[0] = *(longlong **)(param_1 + 0x2a8);
        if ((local_50 == (longlong *)0x0) || (local_50 != local_40[0])) {
          _invalid_parameter_noinfo();
        }
        if (local_48 != lVar1) {
          if (local_50 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar2 = *local_50;
          }
          if (local_48 == *(longlong *)(lVar2 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          *(undefined1 *)(local_48 + 0x1c) = 0;
          if (*(int *)(param_1 + 0x29c) == param_2) {
            FUN_1403e79f0(param_1,0);
          }
        }
      }
    }
    else {
      FUN_1403cc7d0(param_1 + 0x250,local_res18);
    }
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403cfe50  @1403cfe50  [medium:callgraph-r1]  (orig: FUN_1403cfe50)
void FUN_1403cfe50(longlong *param_1)

{
  undefined2 uVar1;
  undefined2 *puVar2;
  undefined2 *puVar3;
  longlong lVar4;
  undefined2 *puVar5;
  undefined2 *puVar6;
  
  puVar2 = (undefined2 *)param_1[4];
  if (puVar2 < (undefined2 *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  puVar3 = (undefined2 *)param_1[3];
  if ((undefined2 *)param_1[4] < puVar3) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 < (undefined2 *)param_1[3]) || ((undefined2 *)param_1[4] < puVar3)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((puVar2 < (undefined2 *)param_1[3]) || ((undefined2 *)param_1[4] < puVar2)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (puVar3 != puVar2) {
    puVar5 = (undefined2 *)param_1[4];
    if (puVar2 != puVar5) {
      puVar6 = puVar2;
      do {
        uVar1 = *puVar6;
        puVar6 = puVar6 + 1;
        *(undefined2 *)((longlong)puVar3 + (-2 - (longlong)puVar2) + (longlong)puVar6) = uVar1;
      } while (puVar6 != puVar5);
    }
    param_1[4] = (longlong)(puVar3 + ((longlong)puVar5 - (longlong)puVar2 >> 1));
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403d0370  @1403d0370  [medium:callgraph-r3]  (orig: FUN_1403d0370)
undefined4 *
FUN_1403d0370(undefined4 *param_1,undefined4 *param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = *param_2;
  *(undefined2 *)(param_1 + 1) = *(undefined2 *)(param_2 + 1);
  FUN_1403cda70(param_1 + 2,param_2 + 2,param_3,param_4,0xfffffffffffffffe);
  *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
  *(undefined1 *)(param_1 + 0x10) = *(undefined1 *)(param_2 + 0x10);
  *(undefined1 *)((longlong)param_1 + 0x41) = *(undefined1 *)((longlong)param_2 + 0x41);
  *(undefined1 *)((longlong)param_1 + 0x42) = *(undefined1 *)((longlong)param_2 + 0x42);
  *(undefined1 *)((longlong)param_1 + 0x43) = *(undefined1 *)((longlong)param_2 + 0x43);
  *(undefined1 *)(param_1 + 0x11) = *(undefined1 *)(param_2 + 0x11);
  *(undefined1 *)((longlong)param_1 + 0x45) = *(undefined1 *)((longlong)param_2 + 0x45);
  *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
  *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x14);
  *(undefined1 *)(param_1 + 0x16) = *(undefined1 *)(param_2 + 0x16);
  return param_1;
}

// ==== CMsgSitDown@texasholdem::helper_1403d0600  @1403d0600  [medium:callgraph-r2]  (orig: FUN_1403d0600)
longlong * FUN_1403d0600(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffffe) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 1;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1403ce790(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 2;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1403d06f3;
  }
  _invalid_parameter_noinfo();
LAB_1403d06f3:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMsgSitDown@texasholdem::helper_1403d2ad0  @1403d2ad0  [medium:callgraph-r1]  (orig: FUN_1403d2ad0)
void FUN_1403d2ad0(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) >> 1;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) >> 1) < uVar3) {
    FUN_1403c55d0(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 2;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_1403d0600(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403d2ba0  @1403d2ba0  [medium:callgraph-r3]  (orig: FUN_1403d2ba0)
void FUN_1403d2ba0(longlong *param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong lVar6;
  
  if (param_1 != param_2) {
    puVar3 = (undefined8 *)*param_1;
    *param_1 = *param_2;
    *param_2 = (longlong)puVar3;
    puVar4 = (undefined8 *)*param_1;
    if (puVar4 != puVar3) {
      uVar5 = *puVar4;
      *puVar4 = *puVar3;
      *puVar3 = uVar5;
    }
    plVar1 = param_2 + 3;
    plVar2 = param_1 + 3;
    if (plVar2 != plVar1) {
      lVar6 = *plVar2;
      *plVar2 = *plVar1;
      *plVar1 = lVar6;
    }
    plVar1 = param_2 + 4;
    plVar2 = param_1 + 4;
    if (plVar2 != plVar1) {
      lVar6 = *plVar2;
      *plVar2 = *plVar1;
      *plVar1 = lVar6;
    }
    param_2 = param_2 + 5;
    param_1 = param_1 + 5;
    if (param_1 != param_2) {
      lVar6 = *param_1;
      *param_1 = *param_2;
      *param_2 = lVar6;
    }
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403d2e90  @1403d2e90  [medium:callgraph-r3]  (orig: FUN_1403d2e90)
longlong * FUN_1403d2e90(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1403d0ad0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1403d2f84;
  }
  _invalid_parameter_noinfo();
LAB_1403d2f84:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMsgSitDown@texasholdem::helper_1403d3980  @1403d3980  [medium:callgraph-r2]  (orig: FUN_1403d3980)
void FUN_1403d3980(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong *plVar3;
  undefined1 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong lVar7;
  int iVar8;
  int iVar9;
  undefined1 local_res8;
  undefined1 local_res9;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  FUN_1403cfe50();
  uVar4 = local_res8;
  iVar9 = 1;
  do {
    if (((*(byte *)((longlong)param_1 + 0x1c4) == 0) || (iVar9 == 1)) ||
       ((int)(uint)*(byte *)((longlong)param_1 + 0x1c4) <= iVar9)) {
      iVar8 = 0;
      local_res8 = (undefined1)iVar9;
      do {
        uVar1 = param_1[3];
        local_res9 = (undefined1)iVar8;
        if (uVar1 == 0) {
          uVar6 = 0;
        }
        else {
          uVar6 = (longlong)(param_1[5] - uVar1) >> 1;
        }
        uVar2 = param_1[4];
        if ((ulonglong)((longlong)(uVar2 - uVar1) >> 1) < uVar6) {
          FUN_1403c55d0(uVar2,1,&local_res8,param_1 + 2,uVar4,0);
          param_1[4] = uVar2 + 2;
        }
        else {
          if (uVar2 < uVar1) {
            _invalid_parameter_noinfo();
          }
          uVar1 = param_1[3];
          lVar5 = *param_1;
          if ((param_1[4] - uVar1 & 0xfffffffffffffffe) == 0) {
            lVar7 = 0;
          }
          else {
            if ((ulonglong)param_1[4] < uVar1) {
              _invalid_parameter_noinfo();
            }
            if ((lVar5 == 0) || (lVar5 != *param_1)) {
              _invalid_parameter_noinfo();
            }
            lVar7 = (longlong)(uVar2 - uVar1) >> 1;
          }
          local_48 = (undefined4)lVar5;
          uStack_44 = (undefined4)((ulonglong)lVar5 >> 0x20);
          uStack_40 = (undefined4)uVar2;
          uStack_3c = (undefined4)(uVar2 >> 0x20);
          local_38 = local_48;
          uStack_34 = uStack_44;
          uStack_30 = uStack_40;
          uStack_2c = uStack_3c;
          FUN_1403ce790(param_1,&local_38,1,&local_res8);
          uVar1 = param_1[3];
          if ((ulonglong)param_1[4] < uVar1) {
            _invalid_parameter_noinfo();
          }
          plVar3 = (longlong *)*param_1;
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar3;
          }
          uVar1 = uVar1 + lVar7 * 2;
          if (uVar1 <= *(ulonglong *)(lVar5 + 0x20)) {
            if (plVar3 == (longlong *)0x0) {
              lVar5 = 0;
            }
            else {
              lVar5 = *plVar3;
            }
            if (*(ulonglong *)(lVar5 + 0x18) <= uVar1) goto LAB_1403d3b02;
          }
          _invalid_parameter_noinfo();
        }
LAB_1403d3b02:
        iVar8 = iVar8 + 1;
      } while (iVar8 < 4);
    }
    iVar9 = iVar9 + 1;
    if (0xd < iVar9) {
      uVar1 = param_1[4];
      if (uVar1 < (ulonglong)param_1[3]) {
        _invalid_parameter_noinfo();
      }
      uVar6 = param_1[3];
      lVar5 = *param_1;
      if ((ulonglong)param_1[4] < uVar6) {
        _invalid_parameter_noinfo();
      }
      if ((*param_1 == 0) || (*param_1 != lVar5)) {
        _invalid_parameter_noinfo();
      }
      if (uVar6 != uVar1) {
        FUN_1403c5200(uVar6,uVar1,0);
      }
      FUN_1403cfe50(param_1 + 6);
      return;
    }
  } while( true );
}

// ==== CMsgSitDown@texasholdem::helper_1403d3b90  @1403d3b90  [medium:callgraph-r2]  (orig: FUN_1403d3b90)
ulonglong FUN_1403d3b90(longlong *param_1,undefined2 *param_2)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined2 *puVar3;
  ulonglong uVar4;
  
  if ((param_1[4] - param_1[3] & 0xfffffffffffffffeU) == 0) {
    FUN_1403d2ba0(param_1,param_1 + 6);
    uVar4 = param_1[4];
    if (uVar4 < (ulonglong)param_1[3]) {
      _invalid_parameter_noinfo();
    }
    uVar1 = param_1[3];
    lVar2 = *param_1;
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_1 == 0) || (*param_1 != lVar2)) {
      _invalid_parameter_noinfo();
    }
    if (uVar1 != uVar4) {
      FUN_1403c5200(uVar1,uVar4,0);
    }
  }
  if ((param_1[4] - param_1[3] & 0xfffffffffffffffeU) != 0) {
    puVar3 = (undefined2 *)FUN_1403c9b60(param_1);
    *param_2 = *puVar3;
    uVar4 = param_1[4] - param_1[3];
    if ((uVar4 & 0xfffffffffffffffe) != 0) {
      uVar4 = param_1[4] - 2;
      param_1[4] = uVar4;
    }
    return CONCAT71((int7)(uVar4 >> 8),1);
  }
  return param_1[4] - param_1[3] & 0xffffffffffffff00;
}

// ==== CMsgSitDown@texasholdem::helper_1403d7780  @1403d7780  [medium:callgraph-r2]  (orig: FUN_1403d7780)
void FUN_1403d7780(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) >> 3;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) >> 3) < uVar3) {
    FUN_1403c5610(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 8;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_1403d2e90(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403d86c0  @1403d86c0  [medium:callgraph-r2]  (orig: FUN_1403d86c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403d86c0(longlong param_1,byte param_2)

{
  ulonglong *puVar1;
  longlong lVar2;
  longlong lVar3;
  char cVar4;
  byte bVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined4 uVar9;
  uint uVar10;
  ulonglong uVar11;
  void *pvVar12;
  int iVar13;
  void *pvVar14;
  void *pvVar15;
  undefined1 auStack_9d8 [32];
  ushort *local_9b8;
  ushort *local_9b0;
  undefined2 local_9a8;
  undefined4 local_9a0;
  undefined4 local_998;
  undefined4 local_990;
  void *local_988;
  byte local_978;
  ushort local_974 [2];
  byte local_970;
  byte local_96f;
  undefined4 local_96c;
  uint local_968;
  void *local_960;
  longlong *local_958;
  uint local_950;
  uint local_94c;
  longlong *local_948 [3];
  void *local_930;
  longlong local_928;
  undefined8 local_920;
  ulonglong *local_918;
  longlong local_910;
  ulonglong *local_908;
  longlong local_900;
  longlong local_8f8;
  ulonglong *local_8f0;
  longlong local_8e8;
  ulonglong *local_8e0;
  ulonglong *local_8d0;
  undefined8 local_8c0;
  undefined1 local_8b8 [1072];
  undefined1 local_488 [1072];
  ushort local_58 [2];
  undefined4 local_54;
  undefined2 local_50;
  undefined4 local_4e;
  undefined2 local_48;
  undefined4 local_46;
  ushort local_40 [4];
  ulonglong local_38;
  
  local_8c0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_9d8;
  local_970 = param_2;
  local_96f = param_2;
  local_8f8 = param_1;
  local_958 = operator_new(8);
  if (local_958 == (longlong *)0x0) {
    local_948[0] = (longlong *)0x0;
  }
  else {
    *local_958 = (longlong)local_948;
    local_948[0] = local_958;
  }
  local_930 = (void *)0x0;
  local_928 = 0;
  local_920 = 0;
  local_960 = (void *)0x0;
  local_978 = param_2;
  local_96c = FUN_1403cc130(param_1);
  local_94c = 0;
  pvVar15 = (void *)0x0;
  pvVar14 = pvVar15;
  while ((int)pvVar14 < 9) {
    FUN_1403ccc50(param_1 + 0x108,&local_908);
    puVar1 = local_908;
    lVar8 = *(longlong *)(param_1 + 0x138);
    local_918 = *(ulonglong **)(param_1 + 0x108);
    if ((local_908 == (ulonglong *)0x0) || (local_908 != local_918)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_900;
    if (local_900 != lVar8) {
      if (puVar1 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        pvVar12 = pvVar15;
      }
      else {
        pvVar12 = (void *)*puVar1;
      }
      if (lVar3 == *(longlong *)((longlong)pvVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)(lVar3 + 0x60) == '\x02') {
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
        plVar7 = (longlong *)FUN_140087650(uVar6);
        lVar8 = (**(code **)(*plVar7 + 0x98))(plVar7,*(undefined4 *)(lVar3 + 0x20));
        if (lVar8 != 0) {
          local_54 = *(undefined4 *)(lVar3 + 0x20);
          local_58[0] = 0xd;
          local_58[1] = 4;
          FUN_1403d7780(local_948,local_58);
        }
      }
    }
    local_94c = (int)pvVar14 + 1;
    local_978 = (char)(param_2 + local_94c) + (char)((int)(param_2 + local_94c) / 9) * -9;
    pvVar14 = (void *)(ulonglong)local_94c;
  }
  lVar8 = local_928 - (longlong)local_930 >> 3;
  pvVar14 = pvVar15;
  if (lVar8 != 0) {
    if (lVar8 == 0) {
      _invalid_parameter_noinfo();
    }
    local_960 = local_930;
    pvVar14 = local_930;
  }
  local_968 = 0;
  pvVar12 = pvVar15;
  uVar9 = local_96c;
  local_978 = param_2;
  while (uVar10 = (uint)pvVar12, (int)uVar10 < 9) {
    FUN_1403ccc50(param_1 + 0x108,&local_8f0);
    puVar1 = local_8f0;
    lVar8 = *(longlong *)(param_1 + 0x138);
    local_8e0 = *(ulonglong **)(param_1 + 0x108);
    if ((local_8f0 == (ulonglong *)0x0) || (local_8f0 != local_8e0)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_8e8;
    uVar9 = local_96c;
    if (local_8e8 != lVar8) {
      if (puVar1 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        pvVar12 = pvVar15;
      }
      else {
        pvVar12 = (void *)*puVar1;
      }
      if (lVar3 == *(longlong *)((longlong)pvVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar9 = local_96c;
      if (*(char *)(lVar3 + 100) == '\0') {
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
        plVar7 = (longlong *)FUN_140087650(uVar6);
        local_958 = (longlong *)(**(code **)(*plVar7 + 0x98))(plVar7,*(undefined4 *)(lVar3 + 0x20));
        uVar9 = local_96c;
        if (local_958 != (longlong *)0x0) {
          FUN_1404dab60(local_8b8);
          if (*(char *)(lVar3 + 0x60) == '\0') {
            FUN_1404dabb0(local_8b8);
            uVar9 = local_96c;
          }
          else {
            FUN_1403cfe50(lVar3 + 0x28);
            local_950 = 0;
            pvVar12 = pvVar15;
            while (pvVar14 = local_960, uVar9 = local_96c, iVar13 = (int)pvVar12, iVar13 < 2) {
              cVar4 = FUN_1403d3b90(param_1);
              if (cVar4 != '\0') {
                FUN_1403ccb80(param_1 + 0xc0,&local_918);
                puVar1 = local_918;
                lVar8 = *(longlong *)(param_1 + 0xf0);
                local_8d0 = *(ulonglong **)(param_1 + 0xc0);
                if ((local_918 == (ulonglong *)0x0) || (local_918 != local_8d0)) {
                  _invalid_parameter_noinfo();
                }
                lVar2 = local_910;
                if (local_910 != lVar8) {
                  if (puVar1 == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    pvVar14 = pvVar15;
                  }
                  else {
                    pvVar14 = (void *)*puVar1;
                  }
                  if (lVar2 == *(longlong *)((longlong)pvVar14 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  if ((*(longlong *)(lVar2 + 0x40) - *(longlong *)(lVar2 + 0x38) &
                      0xfffffffffffffffeU) == 4) {
                    uVar11 = (ulonglong)iVar13;
                    if (1 < uVar11) {
                      _invalid_parameter_noinfo();
                    }
                    if (*(char *)(*(longlong *)(lVar2 + 0x38) + uVar11 * 2) != '\0') {
                      if ((ulonglong)
                          (*(longlong *)(lVar2 + 0x40) - *(longlong *)(lVar2 + 0x38) >> 1) <= uVar11
                         ) {
                        _invalid_parameter_noinfo();
                      }
                      local_974[0] = *(ushort *)(*(longlong *)(lVar2 + 0x38) + uVar11 * 2);
                    }
                  }
                }
                FUN_1403d2ad0(lVar3 + 0x28);
                bVar5 = FUN_1404dad90(local_974);
                local_58[iVar13] = (ushort)bVar5;
                local_40[iVar13] = local_974[0] >> 8;
              }
              local_950 = iVar13 + 1;
              pvVar12 = (void *)(ulonglong)local_950;
            }
            local_908 = (ulonglong *)(local_928 - (longlong)local_930 >> 3);
            local_988 = local_960;
            local_990 = *(undefined4 *)(param_1 + 0x18c);
            local_998 = *(undefined4 *)(param_1 + 400);
            local_9a0 = local_96c;
            local_9a8 = SUB82(local_908,0);
            local_9b0 = local_40;
            local_9b8 = local_58;
            cVar4 = FUN_1404dac10(local_8b8,0,0,2);
            if (cVar4 != '\0') {
              (**(code **)(local_958[2] + 0x350))(local_958 + 2,local_8b8);
            }
            FUN_1404dabb0(local_8b8);
            uVar10 = local_968;
          }
        }
      }
    }
    local_968 = uVar10 + 1;
    local_978 = (char)(local_96f + local_968) + (char)((int)(local_96f + local_968) / 9) * -9;
    pvVar12 = (void *)(ulonglong)local_968;
  }
  FUN_1404dab60(local_488);
  local_48 = 0;
  local_46 = 0;
  local_50 = 0;
  local_4e = 0;
  local_958 = (longlong *)(local_928 - (longlong)local_930 >> 3);
  local_990 = *(undefined4 *)(param_1 + 0x18c);
  local_998 = *(undefined4 *)(param_1 + 400);
  local_9a8 = SUB82(local_958,0);
  local_9b0 = &local_50;
  local_9b8 = &local_48;
  local_9a0 = uVar9;
  local_988 = pvVar14;
  cVar4 = FUN_1404dac10(local_488,0,0,2);
  if (cVar4 != '\0') {
    FUN_14031c520(*(undefined8 *)(param_1 + 0x220),*(undefined4 *)(param_1 + 0x210),local_488);
  }
  FUN_1404dabb0(local_488);
  if (local_930 != (void *)0x0) {
    operator_delete(local_930);
  }
  local_930 = (void *)0x0;
  local_928 = 0;
  local_920 = 0;
  operator_delete(local_948[0]);
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403da1e0  @1403da1e0  [medium:callgraph-r3]  (orig: FUN_1403da1e0)
longlong * FUN_1403da1e0(longlong *param_1,longlong *param_2,byte *param_3)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  bool bVar4;
  longlong local_28;
  undefined8 *local_20;
  
  puVar3 = (undefined8 *)param_1[6];
  bVar4 = true;
  if (*(char *)((longlong)puVar3[1] + 0x81) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      puVar3 = puVar1;
      bVar4 = *param_3 < *(byte *)(puVar3 + 3);
      if (bVar4) {
        puVar1 = (undefined8 *)*puVar3;
      }
      else {
        puVar1 = (undefined8 *)puVar3[2];
      }
    } while (*(char *)((longlong)puVar1 + 0x81) == '\0');
  }
  local_28 = *param_1;
  local_20 = puVar3;
  if (bVar4 == false) {
LAB_1403da2a3:
    if (*param_3 <= *(byte *)(local_20 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_28;
      goto LAB_1403da2ce;
    }
  }
  else {
    puVar1 = *(undefined8 **)param_1[6];
    if (local_28 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar3 != puVar1) {
      FUN_1403bdf20(&local_28);
      goto LAB_1403da2a3;
    }
    bVar4 = true;
  }
  plVar2 = (longlong *)FUN_1403d9a70(param_1,&local_28,bVar4,puVar3,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_20 = (undefined8 *)plVar2[1];
  *param_2 = *plVar2;
LAB_1403da2ce:
  param_2[1] = (longlong)local_20;
  return param_2;
}

// ==== CMsgSitDown@texasholdem::helper_1403daab0  @1403daab0  [medium:callgraph-r3]  (orig: FUN_1403daab0)
undefined8 * FUN_1403daab0(longlong *param_1,undefined8 *param_2,longlong *param_3,byte *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  byte bVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1403d9a70(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(byte *)(lVar3 + 0x18)) {
        FUN_1403d9a70(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(byte *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1403d9a70(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        bVar8 = *param_4;
        if (bVar8 < *(byte *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          FUN_1403bdf20(&local_38);
          bVar8 = *param_4;
          if (*(byte *)(local_30 + 3) < bVar8) {
            if (*(char *)(local_30[2] + 0x81) != '\0') {
              FUN_1403d9a70(param_1,param_2,0,local_30,param_4);
              return param_2;
            }
            FUN_1403d9a70(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(byte *)(param_3[1] + 0x18) < bVar8) {
          local_38 = *param_3;
          plVar4 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x81) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x81) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x81);
              plVar5 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar5 + 0x81);
                plVar9 = plVar5;
                plVar5 = (longlong *)*plVar5;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x81);
              plVar6 = (longlong *)local_30[1];
              plVar5 = local_30;
              while ((plVar9 = plVar6, cVar1 == '\0' && (plVar5 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x81);
                plVar6 = (longlong *)plVar9[1];
                plVar5 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar4) || (*param_4 < *(byte *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x81) != '\0') {
              FUN_1403d9a70(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1403d9a70(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar7 = (undefined8 *)FUN_1403da1e0(param_1,&local_38,param_4);
    *param_2 = *puVar7;
    param_2[1] = puVar7[1];
  }
  return param_2;
}

// ==== CMsgSitDown@texasholdem::helper_1403dad60  @1403dad60  [medium:callgraph-r3]  (orig: FUN_1403dad60)
void FUN_1403dad60(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x81);
  while (cVar1 == '\0') {
    FUN_1403dad60(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    if ((void *)param_2[8] != (void *)0x0) {
      operator_delete((void *)param_2[8]);
    }
    param_2[8] = 0;
    param_2[9] = 0;
    param_2[10] = 0;
    operator_delete((void *)param_2[5]);
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x81);
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403db4f0  @1403db4f0  [medium:callgraph-r2]  (orig: FUN_1403db4f0)
undefined8 * FUN_1403db4f0(undefined8 *param_1,byte *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined1 local_118 [8];
  longlong *local_110 [3];
  void *local_f8;
  undefined8 local_f0;
  undefined8 local_e8;
  undefined4 local_c8;
  undefined4 local_c4;
  undefined8 *local_b8;
  undefined8 *puStack_b0;
  undefined8 local_a8;
  byte local_a0 [8];
  undefined1 local_98 [8];
  void *local_90;
  void *local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined1 local_38 [16];
  
  local_a8 = 0xfffffffffffffffe;
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x81) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(byte *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x81) == '\0');
  }
  puVar1 = (undefined8 *)*param_1;
  puVar2 = (undefined8 *)param_1[6];
  if (puVar1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar5 = (longlong *)0x0;
  if ((puVar4 == puVar2) || (*param_2 < *(byte *)(puVar4 + 3))) {
    local_b8 = puVar1;
    puStack_b0 = puVar4;
    plVar3 = operator_new(8);
    local_110[0] = plVar5;
    if (plVar3 != (longlong *)0x0) {
      *plVar3 = (longlong)local_110;
      local_110[0] = plVar3;
    }
    local_f8 = (void *)0x0;
    local_f0 = 0;
    local_e8 = 0;
    local_c8 = 0;
    local_c4 = 0;
    local_a0[0] = *param_2;
    FUN_1403d0370(local_98,local_118);
    puVar4 = (undefined8 *)FUN_1403daab0(param_1,local_38,&local_b8,local_a0);
    puVar1 = (undefined8 *)*puVar4;
    puVar4 = (undefined8 *)puVar4[1];
    if (local_78 != (void *)0x0) {
      operator_delete(local_78);
    }
    local_78 = (void *)0x0;
    local_70 = 0;
    local_68 = 0;
    operator_delete(local_90);
    if (local_f8 != (void *)0x0) {
      operator_delete(local_f8);
    }
    local_f8 = (void *)0x0;
    local_f0 = 0;
    local_e8 = 0;
    operator_delete(local_110[0]);
  }
  if (puVar1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    plVar5 = (longlong *)*puVar1;
  }
  if (puVar4 == (undefined8 *)plVar5[6]) {
    _invalid_parameter_noinfo();
  }
  return puVar4 + 4;
}

// ==== CMsgSitDown@texasholdem::helper_1403db900  @1403db900  [medium:callgraph-r2]  (orig: FUN_1403db900)
longlong * FUN_1403db900(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar1 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar1) {
    lVar1 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar1) {
      FUN_1403dad60(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar1 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar2 = param_3[1];
    FUN_1403bcb00(param_3);
    local_28 = lVar1;
    lStack_20 = lVar2;
    FUN_1403da2f0(param_1,local_18,&local_28);
  }
  lVar1 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar1;
  return param_2;
}

// ==== CMsgSitDown@texasholdem::helper_1403dc1f0  @1403dc1f0  [medium:callgraph-r3]  (orig: FUN_1403dc1f0)
undefined8 *
FUN_1403dc1f0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1403c3a90(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x81) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1403dba60(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMsgSitDown@texasholdem::helper_1403dc330  @1403dc330  [medium:callgraph-r1]  (orig: FUN_1403dc330)
longlong FUN_1403dc330(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_1403c73f0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x81) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x81) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x81);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x81);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x81);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x81);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_1403db900(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMsgSitDown@texasholdem::helper_1403dcae0  @1403dcae0  [medium:callgraph-r3]  (orig: FUN_1403dcae0)
undefined8 * FUN_1403dcae0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1403c3a90(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x81) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMsgSitDown@texasholdem::helper_1403df920  @1403df920  [medium:callgraph-r2]  (orig: FUN_1403df920)
undefined8 FUN_1403df920(longlong param_1)

{
  undefined8 uVar1;
  longlong *plVar2;
  char cVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong lVar10;
  bool bVar11;
  longlong *local_348 [6];
  longlong *local_318;
  longlong local_310;
  longlong *local_308;
  longlong *plStack_300;
  undefined4 local_2f8;
  undefined4 uStack_2f4;
  longlong *plStack_2f0;
  undefined4 local_2e8;
  undefined4 uStack_2e4;
  longlong *plStack_2e0;
  undefined4 local_2d8;
  undefined4 uStack_2d4;
  longlong *plStack_2d0;
  longlong *plStack_2c0;
  longlong *local_2b8;
  longlong *plStack_2b0;
  longlong *local_2a8;
  longlong *local_298;
  longlong *plStack_290;
  longlong *local_288;
  undefined8 local_278;
  undefined8 uStack_270;
  longlong *local_268;
  longlong *local_258;
  longlong *plStack_250;
  undefined8 local_248;
  undefined8 uStack_240;
  longlong *plStack_230;
  longlong *plStack_220;
  undefined8 local_218;
  undefined8 uStack_210;
  longlong *local_208;
  longlong *local_1f8;
  longlong *plStack_1f0;
  longlong *local_1e8;
  longlong *plStack_1e0;
  longlong *local_1d8;
  longlong *local_1d0;
  longlong *local_1c8;
  longlong *local_1c0;
  undefined8 local_1b8;
  longlong *plStack_1b0;
  longlong *local_1a8;
  longlong *plStack_1a0;
  longlong *local_198;
  longlong *plStack_190;
  undefined4 local_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 local_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  longlong *local_168;
  longlong *plStack_160;
  longlong *local_158;
  longlong *plStack_150;
  undefined4 local_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  longlong *local_138;
  undefined8 local_128;
  longlong *plStack_120;
  longlong *local_118;
  longlong *local_108;
  undefined8 local_f8;
  longlong *plStack_f0;
  longlong *local_e8;
  longlong *local_d8;
  longlong *local_c8;
  longlong *local_b8;
  undefined8 local_a8;
  longlong *plStack_a0;
  undefined8 local_98;
  undefined8 local_88;
  longlong *plStack_80;
  longlong *local_78;
  longlong *local_68;
  longlong *plStack_60;
  longlong *local_58;
  undefined8 local_48;
  longlong *plStack_40;
  
  local_98 = 0xfffffffffffffffe;
  if (*(ulonglong *)(param_1 + 0x140) <= *(ulonglong *)(param_1 + 0x180)) {
    FUN_1403dc1f0(local_348,param_1 + 0x148);
    plVar8 = local_348[0];
    plVar5 = (longlong *)*local_318;
    lVar10 = 0;
    local_308 = local_348[0];
    plStack_300 = plVar5;
LAB_1403df9a0:
    plVar4 = local_318;
    local_c8 = local_348[0];
    if ((plVar8 == (longlong *)0x0) || (plVar8 != local_348[0])) {
      _invalid_parameter_noinfo();
    }
    plVar6 = local_318;
    plVar7 = local_348[0];
    if (plVar5 != plVar4) {
      if (plVar8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar8;
      }
      if (plVar5 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      cVar3 = FUN_1403c9940(param_1,param_1 + 0x108,(int)plVar5[4]);
      plVar7 = plStack_300;
      plVar4 = local_308;
      if (cVar3 == '\0') {
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar5 + 0x81) == '\0') {
          plVar6 = plVar5;
          plVar2 = (longlong *)plVar5[2];
          if (*(char *)(plVar5[2] + 0x81) == '\0') {
            do {
              plVar5 = plVar2;
              plVar2 = (longlong *)*plVar5;
              plStack_300 = plVar5;
              local_1d8 = plVar5;
            } while (*(char *)(*plVar5 + 0x81) == '\0');
          }
          else {
            do {
              plVar5 = (longlong *)plVar6[1];
              plStack_300 = plVar5;
              if (*(char *)((longlong)plVar5 + 0x81) != '\0') break;
              bVar11 = plVar6 == (longlong *)plVar5[2];
              plVar6 = plVar5;
            } while (bVar11);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        local_68 = plVar4;
        plStack_60 = plVar7;
        FUN_1403da2f0(local_348,&local_1b8,&local_68);
      }
      else {
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar5 + 0x81) == '\0') {
          plVar4 = plVar5;
          plVar7 = (longlong *)plVar5[2];
          if (*(char *)(plVar5[2] + 0x81) == '\0') {
            do {
              plVar5 = plVar7;
              plVar7 = (longlong *)*plVar5;
              plStack_300 = plVar5;
              local_288 = plVar5;
            } while (*(char *)(*plVar5 + 0x81) == '\0');
          }
          else {
            do {
              plVar5 = (longlong *)plVar4[1];
              plStack_300 = plVar5;
              if (*(char *)((longlong)plVar5 + 0x81) != '\0') break;
              bVar11 = plVar4 == (longlong *)plVar5[2];
              plVar4 = plVar5;
            } while (bVar11);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      goto LAB_1403df9a0;
    }
    local_248._0_4_ = SUB84(local_348[0],0);
    local_148 = (undefined4)local_248;
    local_248._4_4_ = (undefined4)((ulonglong)local_348[0] >> 0x20);
    uStack_144 = local_248._4_4_;
    if (local_310 == *(longlong *)(param_1 + 0x140)) {
      plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x138);
      plVar5 = *(longlong **)(param_1 + 0x108);
      plVar8 = (longlong *)*local_318;
      local_298 = local_348[0];
      plStack_300 = plVar8;
      local_2b8 = plVar5;
      plStack_2b0 = plVar4;
      plStack_290 = plVar8;
      local_1a8 = plVar5;
      plStack_1a0 = plVar4;
LAB_1403dfe10:
      plVar6 = *(longlong **)(param_1 + 0x138);
      local_138 = *(longlong **)(param_1 + 0x108);
      if ((plVar5 == (longlong *)0x0) || (plVar5 != local_138)) {
        _invalid_parameter_noinfo();
      }
      plVar2 = local_318;
      if (plVar4 == plVar6) {
LAB_1403e0210:
        plVar8 = local_318;
        plVar5 = local_348[0];
        uStack_210 = local_318;
        local_218 = local_348[0];
        plStack_2d0 = (longlong *)*local_318;
        local_1f8 = local_348[0];
        local_218._0_4_ = SUB84(local_348[0],0);
        local_218._4_4_ = (undefined4)((ulonglong)local_348[0] >> 0x20);
        uStack_210._0_4_ = SUB84(local_318,0);
        uStack_210._4_4_ = (undefined4)((ulonglong)local_318 >> 0x20);
        local_188 = (undefined4)local_218;
        uStack_184 = local_218._4_4_;
        uStack_180 = (undefined4)uStack_210;
        uStack_17c = uStack_210._4_4_;
        local_2d8 = (undefined4)local_218;
        uStack_2d4 = local_218._4_4_;
        local_108 = local_348[0];
        local_218 = plVar5;
        uStack_210 = plVar8;
        plStack_1f0 = plStack_2d0;
        if (local_348[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        plVar4 = local_318;
        local_e8 = local_348[0];
        if ((plVar5 == (longlong *)0x0) || (plVar5 != local_348[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar8 == plVar4) {
          local_1c8 = (longlong *)local_318[1];
          plVar5 = local_1c8;
          while (*(char *)((longlong)plVar5 + 0x81) == '\0') {
            FUN_1403dad60(local_348,plVar5[2]);
            plVar8 = (longlong *)*plVar5;
            local_1c8 = plVar8;
            if (plVar5[8] != 0) {
              operator_delete((void *)plVar5[8]);
            }
            plVar5[8] = 0;
            plVar5[9] = 0;
            plVar5[10] = 0;
            operator_delete((void *)plVar5[5]);
            operator_delete(plVar5);
            plVar5 = plVar8;
          }
          local_318[1] = (longlong)local_318;
          local_310 = 0;
          *local_318 = (longlong)local_318;
          local_318[2] = (longlong)local_318;
          local_168 = local_348[0];
        }
        else {
          lVar10 = CONCAT44(uStack_2d4,local_2d8);
          plVar8 = (longlong *)CONCAT44(uStack_17c,uStack_180);
          lVar9 = CONCAT44(uStack_184,local_188);
          plVar5 = plStack_2d0;
          while( true ) {
            if ((lVar10 == 0) || (lVar10 != lVar9)) {
              _invalid_parameter_noinfo();
            }
            plVar4 = plStack_2d0;
            if (plVar5 == plVar8) break;
            uVar1 = CONCAT44(uStack_2d4,local_2d8);
            if (lVar10 == 0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)plVar5 + 0x81) == '\0') {
              plVar7 = plVar5;
              plVar6 = (longlong *)plVar5[2];
              if (*(char *)(plVar5[2] + 0x81) == '\0') {
                do {
                  plVar5 = plVar6;
                  plVar6 = (longlong *)*plVar5;
                  plStack_2d0 = plVar5;
                  local_1c0 = plVar5;
                } while (*(char *)(*plVar5 + 0x81) == '\0');
              }
              else {
                do {
                  plVar5 = (longlong *)plVar7[1];
                  plStack_2d0 = plVar5;
                  if (*(char *)((longlong)plVar5 + 0x81) != '\0') break;
                  bVar11 = plVar7 == (longlong *)plVar5[2];
                  plVar7 = plVar5;
                } while (bVar11);
              }
            }
            else {
              _invalid_parameter_noinfo();
            }
            plStack_1b0 = plVar4;
            local_1b8 = uVar1;
            FUN_1403da2f0(local_348,&local_88,&local_1b8);
          }
          local_48 = CONCAT44(uStack_2d4,local_2d8);
          plStack_40 = plStack_2d0;
          plStack_2c0 = plVar5;
          local_168 = local_348[0];
          plStack_160 = plVar5;
        }
        local_348[0] = local_168;
        operator_delete(local_318);
        local_318 = (longlong *)0x0;
        local_310 = 0;
        operator_delete(local_348[0]);
        return 0;
      }
      local_d8 = local_348[0];
      if ((plVar7 == (longlong *)0x0) || (plVar7 != local_348[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == plVar2) goto LAB_1403e0210;
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar5;
      }
      if (plVar4 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar7 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar7;
      }
      if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar2 = local_318;
      plVar6 = local_348[0];
      if ((int)plVar4[4] == (int)plVar8[4]) {
        if (plVar5 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar4 + 0x81) == '\0') {
          plVar6 = plVar4;
          plVar2 = (longlong *)plVar4[2];
          if (*(char *)(plVar4[2] + 0x81) == '\0') {
            do {
              plVar4 = plVar2;
              plVar2 = (longlong *)*plVar4;
              local_1d0 = plVar4;
            } while (*(char *)(*plVar4 + 0x81) == '\0');
          }
          else {
            do {
              plVar4 = (longlong *)plVar6[1];
              if (*(char *)((longlong)plVar4 + 0x81) != '\0') break;
              bVar11 = plVar6 == (longlong *)plVar4[2];
              plVar6 = plVar4;
            } while (bVar11);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar8 + 0x81) == '\0') {
          plVar6 = plVar8;
          plVar2 = (longlong *)plVar8[2];
          if (*(char *)(plVar8[2] + 0x81) == '\0') {
            do {
              plVar8 = plVar2;
              plVar2 = (longlong *)*plVar8;
              local_2a8 = plVar8;
            } while (*(char *)(*plVar8 + 0x81) == '\0');
          }
          else {
            do {
              plVar8 = (longlong *)plVar6[1];
              if (*(char *)((longlong)plVar8 + 0x81) != '\0') break;
              bVar11 = plVar6 == (longlong *)plVar8[2];
              plVar6 = plVar8;
            } while (bVar11);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        goto LAB_1403dfe10;
      }
      uStack_270 = local_318;
      plVar8 = uStack_270;
      local_278 = local_348[0];
      plVar5 = local_278;
      plStack_2e0 = (longlong *)*local_318;
      local_258 = local_348[0];
      local_278._0_4_ = SUB84(local_348[0],0);
      local_278._4_4_ = (undefined4)((ulonglong)local_348[0] >> 0x20);
      uStack_270._0_4_ = SUB84(local_318,0);
      uStack_270._4_4_ = (undefined4)((ulonglong)local_318 >> 0x20);
      local_178 = (undefined4)local_278;
      uStack_174 = local_278._4_4_;
      uStack_170 = (undefined4)uStack_270;
      uStack_16c = uStack_270._4_4_;
      local_2e8 = (undefined4)local_278;
      uStack_2e4 = local_278._4_4_;
      local_58 = local_348[0];
      local_278 = plVar5;
      uStack_270 = plVar8;
      plStack_250 = plStack_2e0;
      if (local_348[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      plVar5 = local_318;
      local_b8 = local_348[0];
      if ((plVar6 == (longlong *)0x0) || (plVar6 != local_348[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == plVar5) {
        FUN_1403dad60(local_348,local_318[1]);
        local_318[1] = (longlong)local_318;
        local_310 = 0;
        *local_318 = (longlong)local_318;
        local_318[2] = (longlong)local_318;
        local_198 = local_348[0];
      }
      else {
        lVar10 = CONCAT44(uStack_2e4,local_2e8);
        plVar5 = plStack_2e0;
        while( true ) {
          if ((lVar10 == 0) || (lVar10 != CONCAT44(uStack_174,local_178))) {
            _invalid_parameter_noinfo();
          }
          plVar8 = plStack_2e0;
          if (plVar5 == (longlong *)CONCAT44(uStack_16c,uStack_170)) break;
          uVar1 = CONCAT44(uStack_2e4,local_2e8);
          if (lVar10 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x81) == '\0') {
            plVar4 = plVar5;
            plVar7 = (longlong *)plVar5[2];
            if (*(char *)(plVar5[2] + 0x81) == '\0') {
              do {
                plVar5 = plVar7;
                plVar7 = (longlong *)*plVar5;
                plStack_2e0 = plVar5;
                local_268 = plVar5;
              } while (*(char *)(*plVar5 + 0x81) == '\0');
            }
            else {
              do {
                plVar5 = (longlong *)plVar4[1];
                plStack_2e0 = plVar5;
                if (*(char *)((longlong)plVar5 + 0x81) != '\0') break;
                bVar11 = plVar4 == (longlong *)plVar5[2];
                plVar4 = plVar5;
              } while (bVar11);
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          plStack_120 = plVar8;
          local_128 = uVar1;
          FUN_1403da2f0(local_348,&local_a8,&local_128);
        }
        local_88 = CONCAT44(uStack_2e4,local_2e8);
        plStack_80 = plStack_2e0;
        plStack_230 = plVar5;
        local_198 = local_348[0];
        plStack_190 = plVar5;
      }
      local_348[0] = local_198;
      operator_delete(local_318);
      local_318 = (longlong *)0x0;
      local_310 = 0;
      operator_delete(local_348[0]);
    }
    else {
      uStack_240 = local_318;
      plVar5 = uStack_240;
      local_248 = local_348[0];
      plStack_2f0 = (longlong *)*local_318;
      local_1e8 = local_348[0];
      uStack_240._0_4_ = SUB84(local_318,0);
      uStack_240._4_4_ = (undefined4)((ulonglong)local_318 >> 0x20);
      uStack_140 = (undefined4)uStack_240;
      uStack_13c = uStack_240._4_4_;
      local_2f8 = local_148;
      uStack_2f4 = uStack_144;
      local_118 = local_348[0];
      uStack_240 = plVar5;
      plStack_1e0 = plStack_2f0;
      if (local_348[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      plVar5 = local_318;
      local_78 = local_348[0];
      if ((plVar7 == (longlong *)0x0) || (plVar7 != local_348[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 == plVar5) {
        FUN_1403dad60(local_348,local_318[1]);
        local_318[1] = (longlong)local_318;
        local_310 = 0;
        *local_318 = (longlong)local_318;
        local_318[2] = (longlong)local_318;
        local_158 = local_348[0];
      }
      else {
        lVar10 = CONCAT44(uStack_2f4,local_2f8);
        plVar8 = (longlong *)CONCAT44(uStack_13c,uStack_140);
        lVar9 = CONCAT44(uStack_144,local_148);
        plVar5 = plStack_2f0;
        while( true ) {
          if ((lVar10 == 0) || (lVar10 != lVar9)) {
            _invalid_parameter_noinfo();
          }
          plVar4 = plStack_2f0;
          if (plVar5 == plVar8) break;
          uVar1 = CONCAT44(uStack_2f4,local_2f8);
          if (lVar10 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x81) == '\0') {
            plVar7 = plVar5;
            plVar6 = (longlong *)plVar5[2];
            if (*(char *)(plVar5[2] + 0x81) == '\0') {
              do {
                plVar5 = plVar6;
                plVar6 = (longlong *)*plVar5;
                plStack_2f0 = plVar5;
                local_208 = plVar5;
              } while (*(char *)(*plVar5 + 0x81) == '\0');
            }
            else {
              do {
                plVar5 = (longlong *)plVar7[1];
                plStack_2f0 = plVar5;
                if (*(char *)((longlong)plVar5 + 0x81) != '\0') break;
                bVar11 = plVar7 == (longlong *)plVar5[2];
                plVar7 = plVar5;
              } while (bVar11);
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          plStack_f0 = plVar4;
          local_f8 = uVar1;
          FUN_1403da2f0(local_348,&local_1b8,&local_f8);
        }
        local_a8 = CONCAT44(uStack_2f4,local_2f8);
        plStack_a0 = plStack_2f0;
        plStack_220 = plVar5;
        local_158 = local_348[0];
        plStack_150 = plVar5;
      }
      local_348[0] = local_158;
      operator_delete(local_318);
      local_318 = (longlong *)0x0;
      local_310 = 0;
      operator_delete(local_348[0]);
    }
  }
  return 1;
}

// ==== CMsgSitDown@texasholdem::helper_1403e0520  @1403e0520  [medium:callgraph-r2]  (orig: FUN_1403e0520)
void FUN_1403e0520(longlong param_1)

{
  undefined1 uVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  int iVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  IStringManager *pIVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  undefined8 *puVar15;
  longlong lVar16;
  bool bVar17;
  undefined8 *local_res10;
  void **local_res18;
  longlong *local_358 [6];
  longlong *local_328;
  longlong local_320;
  undefined4 local_318;
  undefined4 uStack_314;
  longlong *plStack_310;
  undefined4 local_308;
  undefined4 uStack_304;
  longlong *plStack_300;
  longlong *local_2f8;
  longlong *local_2e8;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  longlong *plStack_2d0;
  undefined8 local_2c8;
  undefined8 uStack_2c0;
  longlong *local_2b8;
  longlong *plStack_2b0;
  longlong *local_2a8;
  longlong *plStack_290;
  longlong *local_288;
  longlong *local_278;
  undefined8 uStack_270;
  longlong *local_268;
  undefined8 local_258;
  undefined8 uStack_250;
  undefined8 *local_248;
  longlong *local_238;
  longlong *plStack_230;
  longlong *local_228;
  undefined8 *local_220;
  undefined4 local_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  longlong *local_208;
  longlong *plStack_200;
  longlong *local_1f8;
  longlong *plStack_1f0;
  undefined4 local_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined8 local_1d8;
  longlong *plStack_1d0;
  longlong *local_1c8;
  longlong *local_1b8;
  longlong *local_1a8;
  undefined8 local_198;
  longlong *plStack_190;
  undefined8 local_188;
  longlong *plStack_180;
  undefined8 local_178;
  undefined8 local_168;
  longlong *plStack_160;
  longlong *local_148;
  longlong *local_138;
  longlong *local_128;
  longlong *local_118;
  undefined1 local_108 [8];
  undefined1 local_100 [8];
  void *local_f8 [3];
  void *local_e0;
  undefined8 local_d8;
  undefined8 local_d0;
  undefined1 local_a0 [8];
  undefined1 local_98 [8];
  void *local_90 [3];
  void *local_78;
  undefined8 local_70;
  undefined8 local_68;
  
  local_178 = 0xfffffffffffffffe;
  if ((*(int *)(param_1 + 0x210) != 0) && (*(char *)(param_1 + 0x208) == '\0')) {
    puVar15 = *(undefined8 **)(param_1 + 0x138);
    puVar13 = (undefined8 *)*puVar15;
    plVar11 = *(longlong **)(param_1 + 0x108);
    local_res10 = puVar15;
    local_2f8 = plVar11;
    local_1a8 = plVar11;
    FUN_1403dcae0(local_358);
    plVar7 = plVar11;
LAB_1403e05b5:
    lVar8 = 0;
    if ((plVar11 == (longlong *)0x0) || (plVar11 != plVar7)) {
      _invalid_parameter_noinfo();
    }
    plVar10 = local_328;
    plVar7 = local_358[0];
    if (puVar13 != puVar15) {
      if (plVar11 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar16 = lVar8;
      }
      else {
        lVar16 = *plVar11;
      }
      if (puVar13 == *(undefined8 **)(lVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar11 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar8 = *plVar11;
      }
      if (puVar13 == *(undefined8 **)(lVar8 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar1 = *(undefined1 *)(puVar13 + 3);
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
      plVar7 = (longlong *)FUN_140087650(uVar6);
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x98))(plVar7,*(undefined4 *)(puVar13 + 4));
      if (plVar7 != (longlong *)0x0) {
        if ((*(int *)(param_1 + 0x1bc) == 0) &&
           (lVar8 = (**(code **)(*plVar7 + 0x60))(plVar7),
           lVar8 < (longlong)(ulonglong)(uint)(*(int *)(param_1 + 0x1c0) * 10))) {
          pIVar9 = theInstance();
          lVar8 = plVar7[2];
          uVar6 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_NOT_ENOUTH_DEPOSIT");
          (**(code **)(lVar8 + 0x358))(plVar7 + 2,uVar6);
          local_108[0] = uVar1;
          FUN_1403d0370(local_100,puVar13 + 4);
          FUN_1403da1e0(local_358,&local_168,local_108);
          local_res18 = local_f8;
          if (local_e0 != (void *)0x0) {
            operator_delete(local_e0);
          }
          local_e0 = (void *)0x0;
          local_d8 = 0;
          local_d0 = 0;
          operator_delete(local_f8[0]);
          puVar15 = local_res10;
        }
        else if ((*(int *)(param_1 + 0x1bc) == 1) &&
                (*(uint *)((longlong)plVar7 + 0xfa4) < (uint)(*(int *)(param_1 + 0x1c0) * 10))) {
          pIVar9 = theInstance();
          lVar8 = plVar7[2];
          uVar6 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_NOT_ENOUTH_DEPOSIT");
          (**(code **)(lVar8 + 0x358))(plVar7 + 2,uVar6);
          local_a0[0] = uVar1;
          FUN_1403d0370(local_98,puVar13 + 4);
          FUN_1403da1e0(local_358,&local_168,local_a0);
          local_res18 = local_90;
          if (local_78 != (void *)0x0) {
            operator_delete(local_78);
          }
          local_78 = (void *)0x0;
          local_70 = 0;
          local_68 = 0;
          operator_delete(local_90[0]);
          puVar15 = local_res10;
        }
      }
      if (plVar11 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar13 + 0x81) == '\0') {
        puVar14 = puVar13;
        puVar4 = (undefined8 *)puVar13[2];
        plVar7 = local_2f8;
        if (*(char *)((longlong)puVar13[2] + 0x81) == '\0') {
          do {
            puVar13 = puVar4;
            puVar4 = (undefined8 *)*puVar13;
            local_220 = puVar13;
          } while (*(char *)((longlong)*puVar13 + 0x81) == '\0');
        }
        else {
          do {
            puVar13 = (undefined8 *)puVar14[1];
            if (*(char *)((longlong)puVar13 + 0x81) != '\0') break;
            bVar17 = puVar14 == (undefined8 *)puVar13[2];
            puVar14 = puVar13;
          } while (bVar17);
        }
      }
      else {
        _invalid_parameter_noinfo();
        plVar7 = local_2f8;
      }
      goto LAB_1403e05b5;
    }
    if (local_320 == 0) {
      uStack_2c0 = local_328;
      local_2c8 = local_358[0];
      plVar11 = local_2c8;
      plStack_300 = (longlong *)*local_328;
      local_2b8 = local_358[0];
      local_2c8._0_4_ = SUB84(local_358[0],0);
      local_2c8._4_4_ = (undefined4)((ulonglong)local_358[0] >> 0x20);
      uStack_2c0._0_4_ = SUB84(local_328,0);
      uStack_2c0._4_4_ = (undefined4)((ulonglong)local_328 >> 0x20);
      local_1e8 = (undefined4)local_2c8;
      uStack_1e4 = local_2c8._4_4_;
      uStack_1e0 = (undefined4)uStack_2c0;
      uStack_1dc = uStack_2c0._4_4_;
      local_308 = (undefined4)local_2c8;
      uStack_304 = local_2c8._4_4_;
      local_138 = local_358[0];
      local_2c8 = plVar11;
      uStack_2c0 = plVar10;
      plStack_2b0 = plStack_300;
      if (local_358[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      plVar11 = local_328;
      local_148 = local_358[0];
      if ((plVar7 == (longlong *)0x0) || (plVar7 != local_358[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar10 == plVar11) {
        FUN_1403dad60(local_358,local_328[1]);
        local_328[1] = (longlong)local_328;
        local_320 = 0;
        *local_328 = (longlong)local_328;
        local_328[2] = (longlong)local_328;
        local_1f8 = local_358[0];
      }
      else {
        lVar8 = CONCAT44(uStack_304,local_308);
        plVar7 = (longlong *)CONCAT44(uStack_1dc,uStack_1e0);
        lVar16 = CONCAT44(uStack_1e4,local_1e8);
        plVar11 = plStack_300;
        while( true ) {
          if ((lVar8 == 0) || (lVar8 != lVar16)) {
            _invalid_parameter_noinfo();
          }
          plVar10 = plStack_300;
          if (plVar11 == plVar7) break;
          uVar6 = CONCAT44(uStack_304,local_308);
          if (lVar8 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar11 + 0x81) == '\0') {
            plVar12 = plVar11;
            plVar3 = (longlong *)plVar11[2];
            if (*(char *)(plVar11[2] + 0x81) == '\0') {
              do {
                plVar11 = plVar3;
                plVar3 = (longlong *)*plVar11;
                plStack_300 = plVar11;
                local_2a8 = plVar11;
              } while (*(char *)(*plVar11 + 0x81) == '\0');
            }
            else {
              do {
                plVar11 = (longlong *)plVar12[1];
                plStack_300 = plVar11;
                if (*(char *)((longlong)plVar11 + 0x81) != '\0') break;
                bVar17 = plVar12 == (longlong *)plVar11[2];
                plVar12 = plVar11;
              } while (bVar17);
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          plStack_190 = plVar10;
          local_198 = uVar6;
          FUN_1403da2f0(local_358,&local_1d8,&local_198);
        }
        local_188 = CONCAT44(uStack_304,local_308);
        plStack_180 = plStack_300;
        plStack_290 = plVar11;
        local_1f8 = local_358[0];
        plStack_1f0 = plVar11;
      }
      local_358[0] = local_1f8;
      operator_delete(local_328);
      local_328 = (longlong *)0x0;
      local_320 = 0;
      operator_delete(local_358[0]);
    }
    else {
      plVar11 = (longlong *)*local_328;
      local_2e8 = local_358[0];
LAB_1403e0b30:
      plVar10 = local_328;
      local_118 = local_358[0];
      if ((plVar7 == (longlong *)0x0) || (plVar7 != local_358[0])) {
        _invalid_parameter_noinfo();
      }
      plVar12 = local_358[0];
      if (plVar11 != plVar10) {
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar16 = lVar8;
        }
        else {
          lVar16 = *plVar7;
        }
        if (plVar11 == *(longlong **)(lVar16 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar16 = lVar8;
        }
        else {
          lVar16 = *plVar7;
        }
        if (plVar11 == *(longlong **)(lVar16 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar16 = plVar11[3];
        local_res10 = (undefined8 *)CONCAT71(local_res10._1_7_,(char)lVar16);
        lVar2 = plVar11[4];
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
        plVar10 = (longlong *)FUN_140087650(uVar6);
        plVar10 = (longlong *)(**(code **)(*plVar10 + 0x98))(plVar10,(int)plVar11[4]);
        if ((plVar10 != (longlong *)0x0) &&
           (iVar5 = (**(code **)(*plVar10 + 8))(plVar10), iVar5 != *(int *)(param_1 + 0x194))) {
          FUN_1403e7110(param_1,plVar10,0);
        }
        FUN_1403dc330(param_1 + 0x108,&local_res10);
        FUN_1403cfb80(param_1,(int)lVar2,(char)lVar16,0);
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar11 + 0x81) == '\0') {
          plVar10 = plVar11;
          plVar12 = (longlong *)plVar11[2];
          if (*(char *)(plVar11[2] + 0x81) == '\0') {
            do {
              plVar11 = plVar12;
              plVar12 = (longlong *)*plVar11;
              local_228 = plVar11;
            } while (*(char *)(*plVar11 + 0x81) == '\0');
          }
          else {
            do {
              plVar11 = (longlong *)plVar10[1];
              if (*(char *)((longlong)plVar11 + 0x81) != '\0') break;
              bVar17 = plVar10 == (longlong *)plVar11[2];
              plVar10 = plVar11;
            } while (bVar17);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        goto LAB_1403e0b30;
      }
      plVar11 = (longlong *)*local_328;
      local_278 = local_358[0];
      uStack_270._0_4_ = SUB84(plVar11,0);
      uStack_270._4_4_ = (undefined4)((ulonglong)plVar11 >> 0x20);
      uStack_2e0 = (undefined4)uStack_270;
      uStack_2dc = uStack_270._4_4_;
      uStack_270 = plVar11;
LAB_1403e0cf0:
      plVar7 = local_328;
      local_1c8 = local_358[0];
      if ((plVar12 == (longlong *)0x0) || (plVar12 != local_358[0])) {
        _invalid_parameter_noinfo();
      }
      plVar3 = local_328;
      plVar10 = local_358[0];
      if (plVar11 != plVar7) {
        if (plVar12 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar16 = lVar8;
        }
        else {
          lVar16 = *plVar12;
        }
        if (plVar11 == *(longlong **)(lVar16 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (plVar12 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar16 = lVar8;
        }
        else {
          lVar16 = *plVar12;
        }
        if (plVar11 == *(longlong **)(lVar16 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar16 = plVar11[3];
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
        plVar7 = (longlong *)FUN_140087650(uVar6);
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x98))(plVar7,(int)plVar11[4]);
        if ((plVar7 != (longlong *)0x0) &&
           (iVar5 = (**(code **)(*plVar7 + 8))(plVar7), iVar5 != *(int *)(param_1 + 0x194))) {
          FUN_1403d8ec0(param_1,*(undefined4 *)(param_1 + 0x210),plVar7,(char)lVar16,0);
        }
        if (plVar12 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar11 + 0x81) == '\0') {
          plVar7 = plVar11;
          plVar10 = (longlong *)plVar11[2];
          if (*(char *)(plVar11[2] + 0x81) == '\0') {
            do {
              plVar11 = plVar10;
              plVar10 = (longlong *)*plVar11;
              local_288 = plVar11;
            } while (*(char *)(*plVar11 + 0x81) == '\0');
          }
          else {
            do {
              plVar11 = (longlong *)plVar7[1];
              if (*(char *)((longlong)plVar11 + 0x81) != '\0') break;
              bVar17 = plVar7 == (longlong *)plVar11[2];
              plVar7 = plVar11;
            } while (bVar17);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        goto LAB_1403e0cf0;
      }
      uStack_250 = local_328;
      plVar7 = uStack_250;
      local_258 = local_358[0];
      plVar11 = local_258;
      plStack_310 = (longlong *)*local_328;
      local_238 = local_358[0];
      local_258._0_4_ = SUB84(local_358[0],0);
      local_258._4_4_ = (undefined4)((ulonglong)local_358[0] >> 0x20);
      uStack_250._0_4_ = SUB84(local_328,0);
      uStack_250._4_4_ = (undefined4)((ulonglong)local_328 >> 0x20);
      local_218 = (undefined4)local_258;
      uStack_214 = local_258._4_4_;
      uStack_210 = (undefined4)uStack_250;
      uStack_20c = uStack_250._4_4_;
      local_318 = (undefined4)local_258;
      uStack_314 = local_258._4_4_;
      local_128 = local_358[0];
      local_258 = plVar11;
      uStack_250 = plVar7;
      plStack_230 = plStack_310;
      if (local_358[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      plVar11 = local_328;
      local_1b8 = local_358[0];
      if ((plVar10 == (longlong *)0x0) || (plVar10 != local_358[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == plVar11) {
        local_248 = (undefined8 *)local_328[1];
        puVar15 = local_248;
        while (local_res10 = puVar15, *(char *)((longlong)puVar15 + 0x81) == '\0') {
          FUN_1403dad60(local_358,puVar15[2]);
          puVar13 = (undefined8 *)*puVar15;
          puVar14 = puVar15 + 5;
          local_res10 = puVar14;
          local_248 = puVar13;
          if (puVar15[8] != 0) {
            operator_delete((void *)puVar15[8]);
          }
          puVar15[8] = 0;
          puVar15[9] = 0;
          puVar15[10] = 0;
          operator_delete((void *)*puVar14);
          operator_delete(puVar15);
          puVar15 = puVar13;
        }
        local_328[1] = (longlong)local_328;
        local_320 = 0;
        *local_328 = (longlong)local_328;
        local_328[2] = (longlong)local_328;
        local_208 = local_358[0];
      }
      else {
        lVar8 = CONCAT44(uStack_314,local_318);
        plVar7 = (longlong *)CONCAT44(uStack_20c,uStack_210);
        lVar16 = CONCAT44(uStack_214,local_218);
        plVar11 = plStack_310;
        while( true ) {
          if ((lVar8 == 0) || (lVar8 != lVar16)) {
            _invalid_parameter_noinfo();
          }
          plVar10 = plStack_310;
          if (plVar11 == plVar7) break;
          uVar6 = CONCAT44(uStack_314,local_318);
          if (lVar8 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar11 + 0x81) == '\0') {
            plVar12 = plVar11;
            plVar3 = (longlong *)plVar11[2];
            if (*(char *)(plVar11[2] + 0x81) == '\0') {
              do {
                plVar11 = plVar3;
                plVar3 = (longlong *)*plVar11;
                plStack_310 = plVar11;
                local_268 = plVar11;
              } while (*(char *)(*plVar11 + 0x81) == '\0');
            }
            else {
              do {
                plVar11 = (longlong *)plVar12[1];
                plStack_310 = plVar11;
                if (*(char *)((longlong)plVar11 + 0x81) != '\0') break;
                bVar17 = plVar12 == (longlong *)plVar11[2];
                plVar12 = plVar11;
              } while (bVar17);
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          plStack_1d0 = plVar10;
          local_1d8 = uVar6;
          FUN_1403da2f0(local_358,&local_188,&local_1d8);
        }
        local_168 = CONCAT44(uStack_314,local_318);
        plStack_160 = plStack_310;
        plStack_2d0 = plVar11;
        local_208 = local_358[0];
        plStack_200 = plVar11;
      }
      local_358[0] = local_208;
      operator_delete(local_328);
      local_328 = (longlong *)0x0;
      local_320 = 0;
      operator_delete(local_358[0]);
    }
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1403e1140  @1403e1140  [medium:callgraph-r1]  (orig: FUN_1403e1140)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403e1140(longlong param_1)

{
  longlong *plVar1;
  uint3 uVar2;
  undefined8 *puVar3;
  char cVar4;
  byte bVar5;
  undefined4 uVar6;
  ulong uVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  undefined8 uVar13;
  undefined4 *puVar14;
  longlong lVar15;
  byte bVar16;
  undefined8 *puVar17;
  undefined8 *puVar18;
  uint uVar19;
  int iVar20;
  bool bVar21;
  undefined1 auStack_e38 [32];
  undefined8 local_e18;
  undefined8 local_e10;
  undefined8 local_e08;
  undefined4 local_e00;
  undefined8 local_df8;
  undefined4 local_df0;
  void *local_de8;
  undefined2 local_dd8;
  byte local_dd4;
  undefined1 local_dd3;
  bool local_dd0;
  char local_dcf;
  int local_dcc;
  uint local_dc8;
  longlong *local_dc0;
  longlong *local_db0 [3];
  void *local_d98;
  longlong local_d90;
  undefined8 local_d88;
  undefined8 local_d80;
  int local_d78;
  undefined8 *local_d70;
  longlong *local_d68;
  undefined8 *local_d58;
  undefined8 *local_d50;
  longlong local_d48 [2];
  longlong *local_d38;
  undefined8 local_d28;
  longlong *local_d20;
  undefined1 local_d08 [1104];
  undefined1 local_8b8 [1072];
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_d28 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_e38;
  if (*(int *)(param_1 + 0x210) == 0) {
    return;
  }
  if (*(char *)(param_1 + 0x208) != '\0') {
    return;
  }
  iVar20 = 0;
  *(undefined4 *)(param_1 + 0x194) = 0;
  FUN_1403e0520();
  local_d78 = 0;
  cVar4 = '\x01';
  local_dcf = '\x01';
  local_dc0 = *(longlong **)(param_1 + 0x138);
  puVar11 = (undefined8 *)*local_dc0;
  plVar12 = *(longlong **)(param_1 + 0x108);
  local_d20 = plVar12;
LAB_1403e11f0:
  do {
    plVar9 = local_dc0;
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar11 == plVar9) {
      if (cVar4 == '\0') {
        return;
      }
      if (iVar20 < 2) {
        return;
      }
      FUN_1403d3980(param_1);
      puVar11 = *(undefined8 **)(param_1 + 0x138);
      puVar17 = (undefined8 *)*puVar11;
      plVar9 = (longlong *)0x0;
      plVar12 = *(longlong **)(param_1 + 0x108);
      bVar16 = 0;
      local_dd4 = 0;
      local_dd3 = 0;
      local_d70 = puVar11;
      local_d68 = plVar12;
      local_d38 = plVar12;
      FUN_1404dab60(local_8b8);
      local_dc0 = operator_new(8);
      if (local_dc0 != (longlong *)0x0) {
        *local_dc0 = (longlong)local_db0;
        plVar9 = local_dc0;
      }
      local_d98 = (void *)0x0;
      local_d90 = 0;
      local_d88 = 0;
      local_dc8 = 1;
      local_dd0 = true;
      local_db0[0] = plVar9;
      local_d80 = local_dc0;
      if (*(char *)(param_1 + 0x188) != -1) {
        cVar4 = FUN_1403df920(param_1);
        local_dd0 = cVar4 != '\0';
        local_dc8 = (uint)local_dd0;
      }
      uVar19 = local_dc8;
      *(int *)(param_1 + 0x214) = *(int *)(param_1 + 0x214) + 1;
      FUN_1403c60a0(param_1 + 0x1c8);
      plVar9 = plVar12;
      do {
        while( true ) {
          while( true ) {
            if ((plVar12 == (longlong *)0x0) || (plVar12 != plVar9)) {
              _invalid_parameter_noinfo();
            }
            if (puVar17 == puVar11) {
              lVar10 = local_d90 - (longlong)local_d98 >> 3;
              if (lVar10 != 0) {
                if (lVar10 == 0) {
                  _invalid_parameter_noinfo();
                }
                puVar11 = (undefined8 *)(local_d90 - (longlong)local_d98 >> 3);
                local_d70 = puVar11;
                local_e00 = FUN_1403cc130(param_1);
                local_de8 = local_d98;
                local_df0 = *(undefined4 *)(param_1 + 0x18c);
                local_df8 = CONCAT44(local_df8._4_4_,*(undefined4 *)(param_1 + 400));
                local_e08 = CONCAT62(local_e08._2_6_,(short)puVar11);
                local_e10 = 0;
                local_e18 = 0;
                cVar4 = FUN_1404dac10(local_8b8,7,4);
                if (cVar4 != '\0') {
                  FUN_1403d63a0(param_1,local_8b8,0);
                }
              }
              uVar8 = 0;
              if ((char)uVar19 == '\0') {
                FUN_1403cf3e0(param_1,param_1 + 0x188);
              }
              else {
                FUN_1403d3980(param_1);
              }
              if (*(char *)(param_1 + 0x100) != -1) {
                lVar10 = *(longlong *)(param_1 + 0x138);
                lVar15 = *(longlong *)(param_1 + 0x108);
                local_d48[0] = lVar15;
                plVar12 = (longlong *)
                          FUN_1403ccc50((longlong *)(param_1 + 0x108),local_d48,param_1 + 0x100);
                if ((*plVar12 == 0) || (*plVar12 != lVar15)) {
                  _invalid_parameter_noinfo();
                }
                if (plVar12[1] != lVar10) {
                  *(undefined1 *)(param_1 + 0x188) = *(undefined1 *)(param_1 + 0x100);
                }
              }
              local_dd8 = CONCAT11(local_dd8._1_1_,*(undefined1 *)(param_1 + 0x188));
              cVar4 = FUN_1403cf3e0(param_1,&local_dd8);
              if (cVar4 == '\0') {
                if (local_d98 != (void *)0x0) {
                  operator_delete(local_d98);
                }
                local_d98 = (void *)0x0;
                local_d90 = 0;
                local_d88 = 0;
                operator_delete(local_db0[0]);
                FUN_1404dabb0(local_8b8);
              }
              else {
                uVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
                plVar12 = (longlong *)FUN_140087650(uVar13);
                lVar10 = *plVar12;
                puVar14 = (undefined4 *)FUN_1403db4f0(param_1 + 0x108,&local_dd8);
                plVar12 = (longlong *)(**(code **)(lVar10 + 0x98))(plVar12,*puVar14);
                if (plVar12 != (longlong *)0x0) {
                  iVar20 = *(int *)(param_1 + 0x1c0) / 2;
                  lVar10 = (longlong)iVar20;
                  if (*(int *)(param_1 + 0x1bc) == 0) {
                    cVar4 = (**(code **)(*plVar12 + 0x178))(plVar12,lVar10,1);
                    if (cVar4 != '\0') {
                      lVar15 = plVar12[0x1e2];
                      uVar13 = (**(code **)(plVar12[2] + 0x18))();
                      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                      local_df8 = CONCAT44(local_df8._4_4_,iVar20);
                      local_e10 = CONCAT44(local_e10._4_4_,uVar6);
                      local_e18 = CONCAT44(local_e18._4_4_,*(undefined4 *)(param_1 + 0x214));
                      local_e08 = uVar13;
                      local_e00 = (int)lVar15;
                      tq::MyLogSave("gmlog/texasholdem",
                                    "NpcOwner[%u] Table[%u] Index[%u] Small Blinds money lose: %u\t%s\t%u\t700\t702\t%d\t"
                                   );
                    }
                  }
                  else if (*(int *)(param_1 + 0x1bc) == 1) {
                    local_e18 = 0;
                    cVar4 = (**(code **)(plVar12[2] + 0x2e0))(plVar12 + 2,0x1d,(longlong)-iVar20,1);
                    if (cVar4 != '\0') {
                      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                      local_e18._0_4_ = iVar20;
                      FUN_1401742b0(plVar12,0xf,uVar6);
                      lVar15 = plVar12[0x1e2];
                      uVar13 = (**(code **)(plVar12[2] + 0x18))(plVar12 + 2);
                      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                      local_df8 = CONCAT44(local_df8._4_4_,iVar20);
                      local_e10 = CONCAT44(local_e10._4_4_,uVar6);
                      local_e18 = CONCAT44(local_e18._4_4_,*(undefined4 *)(param_1 + 0x214));
                      local_e08 = uVar13;
                      local_e00 = (int)lVar15;
                      tq::MyLogSave("gmlog/texasholdem",
                                    "NpcOwner[%u] Table[%u] Index[%u] Small Blinds emoney lose: %u\t%s\t%u\t700\t702\t%d\t"
                                   );
                    }
                  }
                  lVar15 = FUN_1403db4f0(param_1 + 0x108,&local_dd8);
                  *(longlong *)(lVar15 + 0x38) = *(longlong *)(lVar15 + 0x38) + lVar10;
                  *(longlong *)(param_1 + 0x1a8) = *(longlong *)(param_1 + 0x1a8) + lVar10;
                  *(byte *)(param_1 + 0x18b) = (byte)local_dd8;
                  uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                  *(undefined4 *)(param_1 + 400) = uVar6;
                }
                cVar4 = FUN_1403cf3e0(param_1,&local_dd8);
                if (cVar4 == '\0') {
                  if (local_d98 != (void *)0x0) {
                    operator_delete(local_d98);
                  }
                  local_d98 = (void *)0x0;
                  local_d90 = 0;
                  local_d88 = 0;
                  operator_delete(local_db0[0]);
                  FUN_1404dabb0(local_8b8);
                }
                else {
                  uVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
                  plVar12 = (longlong *)FUN_140087650(uVar13);
                  lVar10 = *plVar12;
                  puVar14 = (undefined4 *)FUN_1403db4f0(param_1 + 0x108,&local_dd8);
                  plVar12 = (longlong *)(**(code **)(lVar10 + 0x98))(plVar12,*puVar14);
                  if (plVar12 != (longlong *)0x0) {
                    iVar20 = *(int *)(param_1 + 0x1c0);
                    lVar10 = (longlong)iVar20;
                    if (*(int *)(param_1 + 0x1bc) == 0) {
                      cVar4 = (**(code **)(*plVar12 + 0x178))(plVar12,lVar10,1);
                      if (cVar4 != '\0') {
                        lVar15 = plVar12[0x1e2];
                        uVar13 = (**(code **)(plVar12[2] + 0x18))();
                        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                        local_df8 = CONCAT44(local_df8._4_4_,iVar20);
                        local_e10 = CONCAT44(local_e10._4_4_,uVar6);
                        local_e18 = CONCAT44(local_e18._4_4_,*(undefined4 *)(param_1 + 0x214));
                        local_e08 = uVar13;
                        local_e00 = (int)lVar15;
                        tq::MyLogSave("gmlog/texasholdem",
                                      "NpcOwner[%u] Table[%u] Index[%u] Big Blinds money lose: %u\t%s\t%u\t700\t702\t%d\t"
                                     );
                      }
                    }
                    else if (*(int *)(param_1 + 0x1bc) == 1) {
                      plVar9 = plVar12 + 2;
                      local_e18 = 0;
                      cVar4 = (**(code **)(*plVar9 + 0x2e0))(plVar9,0x1d,(longlong)-iVar20,1);
                      if (cVar4 != '\0') {
                        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                        local_e18._0_4_ = iVar20;
                        FUN_1401742b0(plVar12,0xf,uVar6);
                        lVar15 = plVar12[0x1e2];
                        uVar13 = (**(code **)(*plVar9 + 0x18))(plVar9);
                        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                        local_df8 = CONCAT44(local_df8._4_4_,iVar20);
                        local_e10 = CONCAT44(local_e10._4_4_,uVar6);
                        local_e18 = CONCAT44(local_e18._4_4_,*(undefined4 *)(param_1 + 0x214));
                        local_e08 = uVar13;
                        local_e00 = (int)lVar15;
                        tq::MyLogSave("gmlog/texasholdem",
                                      "NpcOwner[%u] Table[%u] Index[%u] Big Blinds emoney lose: %u\t%s\t%u\t700\t702\t%d\t"
                                     );
                      }
                    }
                    lVar15 = FUN_1403db4f0(param_1 + 0x108,&local_dd8);
                    *(longlong *)(lVar15 + 0x38) = *(longlong *)(lVar15 + 0x38) + lVar10;
                    *(longlong *)(param_1 + 0x1a0) = lVar10;
                    *(longlong *)(param_1 + 0x1a8) = *(longlong *)(param_1 + 0x1a8) + lVar10;
                    *(byte *)(param_1 + 0x18a) = (byte)local_dd8;
                    uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                    *(undefined4 *)(param_1 + 0x18c) = uVar6;
                  }
                  *(longlong *)(param_1 + 0x198) =
                       (longlong)(*(int *)(param_1 + 0x1c0) / 2 + *(int *)(param_1 + 0x1c0));
                  if (*(longlong *)(param_1 + 0x218) == 0) {
                    FUN_140459c90(local_d08);
                    cVar4 = FUN_140459d40(local_d08,2,*(undefined8 *)(param_1 + 0x1a8));
                    if (cVar4 != '\0') {
                      FUN_1403d74e0(param_1,local_d08,0);
                    }
                    FUN_140459ce0(local_d08);
                  }
                  else {
                    FUN_140362560(local_d08);
                    cVar4 = FUN_140362910(local_d08,0xea,*(undefined4 *)(param_1 + 0x210),
                                          *(undefined8 *)(param_1 + 0x1a8));
                    if (cVar4 != '\0') {
                      FUN_1403d74e0(param_1,local_d08,0);
                    }
                    FUN_1403625e0(local_d08);
                  }
                  cVar4 = FUN_1403cf3e0(param_1,&local_dd8);
                  if (cVar4 == '\0') {
                    if (local_d98 != (void *)0x0) {
                      operator_delete(local_d98);
                    }
                    local_d98 = (void *)0x0;
                    local_d90 = 0;
                    local_d88 = 0;
                    operator_delete(local_db0[0]);
                    FUN_1404dabb0(local_8b8);
                  }
                  else {
                    *(byte *)(param_1 + 0x189) = (byte)local_dd8;
                    *(undefined1 *)(param_1 + 0x208) = 1;
                    FUN_140362560(local_488);
                    cVar4 = FUN_140362910(local_488,0xe9,*(undefined4 *)(param_1 + 0x210),
                                          *(undefined1 *)(param_1 + 0x208));
                    if (cVar4 != '\0') {
                      FUN_1403d74e0(param_1,local_488,0);
                    }
                    if ((char)local_dc8 == '\0') {
                      FUN_1403d86c0(param_1,*(undefined1 *)(param_1 + 0x189));
                      *(undefined1 *)(param_1 + 0x208) = 1;
                      FUN_140362560(local_d08);
                      cVar4 = FUN_140362910(local_d08,0xe9,*(undefined4 *)(param_1 + 0x210),
                                            *(undefined1 *)(param_1 + 0x208));
                      if (cVar4 != '\0') {
                        FUN_1403d74e0(param_1,local_d08,0);
                      }
                      *(undefined4 *)(param_1 + 0x238) = 4;
                      uVar7 = tq::TimeGet(0);
                      *(uint *)(param_1 + 0x23c) = uVar7 / 1000;
                      FUN_1403625e0(local_d08);
                    }
                    else {
                      *(undefined4 *)(param_1 + 0x230) = 7;
                      uVar7 = tq::TimeGet(0);
                      *(uint *)(param_1 + 0x234) = uVar7 / 1000;
                    }
                    lVar10 = *(longlong *)(param_1 + 0x218);
                    lVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
                    if (*(longlong *)(lVar15 + 0x108) == 0) {
                      local_e18 = CONCAT44(local_e18._4_4_,0x145);
                      log_InlineLogERROR(&DAT_1406d9c10);
                    }
                    else {
                      uVar8 = *(undefined8 *)(lVar15 + 0x108);
                    }
                    FUN_1402187b0(uVar8,lVar10 != 0,*(undefined4 *)(param_1 + 0x1b4),
                                  *(undefined4 *)(param_1 + 0x1bc));
                    FUN_1403625e0(local_488);
                    if (local_d98 != (void *)0x0) {
                      operator_delete(local_d98);
                    }
                    local_d98 = (void *)0x0;
                    local_d90 = 0;
                    local_d88 = 0;
                    operator_delete(local_db0[0]);
                    FUN_1404dabb0(local_8b8);
                  }
                }
              }
              return;
            }
            if (plVar12 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar10 = 0;
            }
            else {
              lVar10 = *plVar12;
            }
            if (puVar17 == *(undefined8 **)(lVar10 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            puVar17[0xb] = 0;
            *(undefined1 *)((longlong)puVar17 + 0x61) = 0;
            *(undefined1 *)((longlong)puVar17 + 0x62) = 0;
            if (*(char *)(puVar17 + 0xc) == '\x01') {
              *(undefined1 *)(puVar17 + 0xc) = 2;
            }
            if (*(char *)(puVar17 + 0xc) == '\x02') {
              puVar11 = (undefined8 *)FUN_1403cff10(param_1 + 0x1c8,puVar17 + 4);
              *puVar11 = 0;
              uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
              plVar9 = (longlong *)FUN_140087650(uVar8);
              plVar9 = (longlong *)
                       (**(code **)(*plVar9 + 0x98))(plVar9,*(undefined4 *)(puVar17 + 4));
              if (plVar9 != (longlong *)0x0) {
                iVar20 = *(int *)(param_1 + 0x1c0) / 2;
                local_dcc = iVar20;
                if (*(int *)(param_1 + 0x1bc) == 0) {
                  cVar4 = (**(code **)(*plVar9 + 0x178))(plVar9,(longlong)iVar20,1);
                  if (cVar4 != '\0') {
                    local_dc0 = (longlong *)CONCAT44(local_dc0._4_4_,(int)plVar9[0x1e2]);
                    if (plVar12 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar10 = 0;
                    }
                    else {
                      lVar10 = *plVar12;
                    }
                    if (puVar17 == *(undefined8 **)(lVar10 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    uVar8 = (**(code **)(plVar9[2] + 0x18))();
                    uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
                    local_e08 = (**(code **)(*plVar9 + 0x60))(plVar9);
                    local_de8 = (void *)CONCAT44(local_de8._4_4_,local_dcc);
                    local_df0 = local_dc0._0_4_;
                    local_e10 = CONCAT44(local_e10._4_4_,(uint)*(byte *)(puVar17 + 3));
                    local_e18 = CONCAT44(local_e18._4_4_,*(undefined4 *)(param_1 + 0x214));
                    local_e00 = uVar6;
                    local_df8 = uVar8;
                    tq::MyLogSave("gmlog/texasholdem",
                                  "NpcOwner[%u] Table[%u] Index[%u] Ante Seat[%d] UserMoney[%I64d] money lose: %u\t%s\t%u\t700\t702\t%d\t"
                                 );
                    bVar16 = local_dd4;
                    iVar20 = local_dcc;
                  }
                }
                else if (*(int *)(param_1 + 0x1bc) == 1) {
                  plVar1 = plVar9 + 2;
                  local_e18 = 0;
                  cVar4 = (**(code **)(*plVar1 + 0x2e0))(plVar1,0x1d,(longlong)-iVar20);
                  bVar16 = local_dd4;
                  if (cVar4 != '\0') {
                    uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
                    local_e18 = CONCAT44(local_e18._4_4_,iVar20);
                    FUN_1401742b0(plVar9,0xf,uVar6);
                    local_dc0 = (longlong *)CONCAT44(local_dc0._4_4_,(int)plVar9[0x1e2]);
                    local_dcc = *(int *)((longlong)plVar9 + 0xfa4);
                    if (plVar12 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar10 = 0;
                    }
                    else {
                      lVar10 = *plVar12;
                    }
                    if (puVar17 == *(undefined8 **)(lVar10 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    uVar8 = (**(code **)(*plVar1 + 0x18))(plVar1);
                    local_e00 = (**(code **)(*plVar9 + 8))(plVar9);
                    local_de8 = (void *)CONCAT44(local_de8._4_4_,iVar20);
                    local_df0 = local_dc0._0_4_;
                    local_e08 = CONCAT44(local_e08._4_4_,local_dcc);
                    local_e10 = CONCAT44(local_e10._4_4_,(uint)*(byte *)(puVar17 + 3));
                    local_e18 = CONCAT44(local_e18._4_4_,*(undefined4 *)(param_1 + 0x214));
                    local_df8 = uVar8;
                    tq::MyLogSave("gmlog/texasholdem",
                                  "NpcOwner[%u] Table[%u] Index[%u] Ante Seat[%u] UserEMoney[%d] emoney lose: %u\t%s\t%u\t700\t702\t%d\t"
                                 );
                    bVar16 = local_dd4;
                  }
                }
                puVar17[0xb] = puVar17[0xb] + (longlong)iVar20;
                *(longlong *)(param_1 + 0x1a8) = *(longlong *)(param_1 + 0x1a8) + (longlong)iVar20;
                uVar19 = local_dc8;
              }
              puVar11 = local_d70;
              if (((char)uVar19 != '\0') &&
                 (cVar4 = FUN_1403d3b90(param_1,&local_dd8), puVar11 = local_d70, cVar4 != '\0')) {
                uVar2 = CONCAT12(local_dd8._1_1_,(undefined2)local_d80);
                local_d80 = (longlong *)CONCAT44(*(undefined4 *)(puVar17 + 4),(uint)uVar2);
                *(undefined2 *)((longlong)puVar17 + 0x24) = local_dd8;
                bVar5 = FUN_1404dad90(&local_dd8);
                local_d80 = (longlong *)CONCAT62(local_d80._2_6_,(ushort)bVar5);
                FUN_1403d7780(local_db0,&local_d80);
                FUN_1403d2ad0(param_1 + 0x30,&local_dd8);
                puVar11 = local_d70;
                if (bVar16 < (byte)local_dd8) {
                  if (plVar12 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    lVar10 = 0;
                  }
                  else {
                    lVar10 = *plVar12;
                  }
                  if (puVar17 == *(undefined8 **)(lVar10 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  *(undefined1 *)(param_1 + 0x188) = *(undefined1 *)(puVar17 + 3);
                  local_dd4 = (byte)local_dd8;
                  puVar11 = local_d70;
                  bVar16 = (byte)local_dd8;
                }
              }
            }
            if (plVar12 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)puVar17 + 0x81) == '\0') break;
            _invalid_parameter_noinfo();
            plVar9 = local_d68;
          }
          puVar18 = puVar17;
          puVar3 = (undefined8 *)puVar17[2];
          plVar9 = local_d68;
          if (*(char *)((longlong)puVar17[2] + 0x81) != '\0') break;
          do {
            puVar17 = puVar3;
            puVar3 = (undefined8 *)*puVar17;
            local_d58 = puVar17;
          } while (*(char *)((longlong)*puVar17 + 0x81) == '\0');
        }
        do {
          puVar17 = (undefined8 *)puVar18[1];
          if (*(char *)((longlong)puVar17 + 0x81) != '\0') break;
          bVar21 = puVar18 == (undefined8 *)puVar17[2];
          puVar18 = puVar17;
        } while (bVar21);
      } while( true );
    }
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar12;
    }
    if (puVar11 == *(undefined8 **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)(puVar11 + 0xc) != '\x01') {
      cVar4 = '\0';
    }
    local_dcf = cVar4;
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
    plVar9 = (longlong *)FUN_140087650(uVar8);
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x98))(plVar9,*(undefined4 *)(puVar11 + 4));
    if ((plVar9 != (longlong *)0x0) && (*(char *)(puVar11 + 0xc) == '\x01')) {
      if ((*(int *)(param_1 + 0x1bc) == 0) &&
         (lVar10 = (**(code **)(*plVar9 + 0x60))(plVar9),
         lVar10 < (longlong)(ulonglong)(uint)(*(int *)(param_1 + 0x1c0) * 10))) {
        uVar8 = (**(code **)(plVar9[2] + 0x18))();
        uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
        local_e10 = CONCAT44(local_e10._4_4_,uVar6);
        local_e18 = CONCAT44(local_e18._4_4_,*(undefined4 *)(param_1 + 0x214));
        local_e08 = uVar8;
        tq::MyLogSave("gmlog/texasholdem",
                      "NpcOwner[%u] Table[%u] Index[%u] user:%u[%s] try to cheat!!");
        return;
      }
      if ((*(int *)(param_1 + 0x1bc) == 1) &&
         (*(uint *)((longlong)plVar9 + 0xfa4) < (uint)(*(int *)(param_1 + 0x1c0) * 10))) {
        uVar8 = (**(code **)(plVar9[2] + 0x18))();
        uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
        local_e10 = CONCAT44(local_e10._4_4_,uVar6);
        local_e18 = CONCAT44(local_e18._4_4_,*(undefined4 *)(param_1 + 0x214));
        local_e08 = uVar8;
        tq::MyLogSave("gmlog/texasholdem",
                      "NpcOwner[%u] Table[%u] Index[%u] user:%u[%s] try to cheat!!");
        return;
      }
      iVar20 = iVar20 + 1;
      local_d78 = iVar20;
      uVar8 = FUN_140161000(plVar9);
      FUN_1403b5020(uVar8);
    }
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar11 + 0x81) != '\0') {
      _invalid_parameter_noinfo();
      goto LAB_1403e11f0;
    }
    puVar17 = puVar11;
    puVar18 = (undefined8 *)puVar11[2];
    if (*(char *)((longlong)puVar11[2] + 0x81) == '\0') {
      do {
        puVar11 = puVar18;
        puVar18 = (undefined8 *)*puVar11;
        local_d50 = puVar11;
      } while (*(char *)((longlong)*puVar11 + 0x81) == '\0');
    }
    else {
      do {
        puVar11 = (undefined8 *)puVar17[1];
        if (*(char *)((longlong)puVar11 + 0x81) != '\0') break;
        bVar21 = puVar17 == (undefined8 *)puVar11[2];
        puVar17 = puVar11;
      } while (bVar21);
    }
  } while( true );
}

// ==== CMsgSitDown@texasholdem::helper_1403e7110  @1403e7110  [medium:callgraph-r0]  (orig: FUN_1403e7110)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403e7110(longlong param_1,longlong *param_2,char param_3)

{
  char cVar1;
  byte bVar2;
  ulonglong uVar3;
  longlong *plVar4;
  longlong lVar5;
  char cVar6;
  char cVar7;
  int iVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  undefined8 *puVar11;
  ulonglong uVar12;
  longlong lVar13;
  undefined1 auStack_da8 [32];
  uint local_d88;
  char local_d78;
  char local_d77;
  undefined8 local_d68;
  undefined8 uStack_d60;
  undefined4 local_d58;
  uint uStack_d54;
  undefined8 local_d48;
  undefined8 uStack_d40;
  ulonglong local_d38;
  longlong *local_d30;
  longlong *local_d20;
  undefined8 local_d10;
  undefined4 local_d08;
  undefined4 uStack_d04;
  undefined4 uStack_d00;
  undefined4 uStack_cfc;
  undefined4 local_cf8;
  undefined4 uStack_cf4;
  undefined4 uStack_cf0;
  undefined4 uStack_cec;
  undefined1 local_ce8 [1072];
  undefined1 local_8b8 [1072];
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_d10 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_da8;
  if ((*(int *)(param_1 + 0x210) == 0) || (param_2 == (longlong *)0x0)) {
    uVar10 = 0;
  }
  else if ((int)param_2[0x248] == 0) {
    uVar10 = 0;
  }
  else if (*(byte *)((longlong)param_2 + 0x1244) < 9) {
    local_d77 = param_3;
    FUN_1403ccc50(param_1 + 0x108,&local_d68,(longlong)param_2 + 0x1244);
    plVar4 = local_d68;
    lVar13 = *(longlong *)(param_1 + 0x138);
    local_d20 = *(longlong **)(param_1 + 0x108);
    if ((local_d68 == (longlong *)0x0) || (local_d68 != local_d20)) {
      _invalid_parameter_noinfo();
    }
    lVar5 = uStack_d60;
    if (uStack_d60 == lVar13) {
      uVar10 = 0;
    }
    else {
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = 0;
      }
      else {
        lVar13 = *plVar4;
      }
      if (lVar5 == *(longlong *)(lVar13 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar8 = (**(code **)(*param_2 + 8))(param_2);
      if (iVar8 == *(int *)(lVar5 + 0x20)) {
        local_d78 = *(char *)((longlong)param_2 + 0x1244);
        if ((*(char *)(param_1 + 0x208) != '\0') && (*(char *)(param_1 + 0x189) == local_d78)) {
          FUN_1403e5a50(param_1,*(char *)(param_1 + 0x189),param_2,0);
          FUN_1403ccc50(param_1 + 0x108,&local_d68,&local_d78);
          lVar13 = *(longlong *)(param_1 + 0x138);
          local_d30 = *(longlong **)(param_1 + 0x108);
          if ((local_d68 == (longlong *)0x0) || (local_d68 != local_d30)) {
            _invalid_parameter_noinfo();
          }
          if (uStack_d60 == lVar13) {
            return 1;
          }
          if (local_d68 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar13 = 0;
          }
          else {
            lVar13 = *local_d68;
          }
          if (uStack_d60 == *(longlong *)(lVar13 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          iVar8 = (**(code **)(*param_2 + 8))(param_2);
          if (*(int *)(uStack_d60 + 0x20) != iVar8) {
            return 1;
          }
        }
        cVar7 = local_d78;
        uVar3 = *(ulonglong *)(lVar5 + 0x48);
        local_d48 = 0;
        if (uVar3 < *(ulonglong *)(lVar5 + 0x40)) {
          _invalid_parameter_noinfo();
        }
        uVar10 = *(undefined8 *)(lVar5 + 0x28);
        local_d48._0_4_ = (undefined4)uVar10;
        local_d48._4_4_ = (undefined4)((ulonglong)uVar10 >> 0x20);
        uStack_d40._0_4_ = (undefined4)uVar3;
        uStack_d40._4_4_ = (undefined4)(uVar3 >> 0x20);
        local_cf8 = (undefined4)local_d48;
        uStack_cf4 = local_d48._4_4_;
        uStack_cf0 = (undefined4)uStack_d40;
        uStack_cec = uStack_d40._4_4_;
        uVar12 = *(ulonglong *)(lVar5 + 0x40);
        local_d68 = (longlong *)0x0;
        local_d48 = uVar10;
        uStack_d40 = uVar3;
        if (*(ulonglong *)(lVar5 + 0x48) < uVar12) {
          _invalid_parameter_noinfo();
        }
        uVar10 = *(undefined8 *)(lVar5 + 0x28);
        local_d68._0_4_ = (undefined4)uVar10;
        local_d68._4_4_ = (undefined4)((ulonglong)uVar10 >> 0x20);
        uStack_d60._0_4_ = (undefined4)uVar12;
        uStack_d60._4_4_ = (undefined4)(uVar12 >> 0x20);
        local_d08 = (undefined4)local_d68;
        uStack_d04 = local_d68._4_4_;
        uStack_d00 = (undefined4)uStack_d60;
        uStack_cfc = uStack_d60._4_4_;
        local_d68 = (longlong *)uVar10;
        uStack_d60 = uVar12;
        for (; local_d38 = uVar12, uVar12 != uVar3; uVar12 = uVar12 + 2) {
          FUN_1403d2ad0(param_1 + 0x30,uVar12);
        }
        FUN_1403cfe50(lVar5 + 0x28);
        if (*(char *)(lVar5 + 0x60) == '\x02') {
          puVar11 = (undefined8 *)FUN_1403cff10(param_1 + 0x1c8,lVar5 + 0x20);
          *puVar11 = *(undefined8 *)(lVar5 + 0x58);
        }
        cVar1 = *(char *)(lVar5 + 0x60);
        if (local_d77 != '\0') {
          FUN_140452f10(local_ce8);
          uVar9 = (**(code **)(*param_2 + 8))(param_2);
          cVar6 = FUN_140452fc0(local_ce8,1,*(undefined4 *)(param_1 + 0x1b4),uVar9);
          if (cVar6 != '\0') {
            uVar9 = (**(code **)(*param_2 + 8))(param_2);
            FUN_1403d63a0(param_1,local_ce8,uVar9);
            (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_ce8);
          }
          FUN_140452f60(local_ce8);
        }
        FUN_140453760(local_8b8);
        uVar9 = (**(code **)(*param_2 + 8))(param_2);
        local_d88 = CONCAT31(local_d88._1_3_,cVar7);
        cVar6 = FUN_140453810(local_8b8,1,*(undefined4 *)(param_1 + 0x210),uVar9);
        if (cVar6 != '\0') {
          FUN_1403d74e0(param_1,local_8b8,0);
        }
        bVar2 = *(byte *)((longlong)param_2 + 0x1244);
        (**(code **)(*param_2 + 8))(param_2);
        local_d88 = (uint)bVar2;
        tq::MyLogSave("gmlog/texasholdemwitness",
                      "CTexasHoldEm::OnUserStandUp. SetTexasHoldEmInfo none User[%u] StandUp Table[%u] Seat[%u]"
                     );
        FUN_1403dc330(param_1 + 0x108,&local_d78);
        uVar9 = (**(code **)(*param_2 + 8))(param_2);
        FUN_1403cfb80(param_1,uVar9,cVar7,0);
        local_d58 = 0;
        uStack_d54 = uStack_d54 & 0xffffff00;
        param_2[0x248] = (ulonglong)uStack_d54 << 0x20;
        if (*(char *)(param_1 + 0x208) == '\0') {
          iVar8 = FUN_14016b120(param_1 + 0x248);
          if ((iVar8 < 1) && (cVar7 = FUN_1403c9910(param_1), cVar7 != '\0')) {
            FUN_1403e1140(param_1);
          }
        }
        else if ((cVar1 == '\x02') && (cVar7 = FUN_1403e3280(param_1), cVar7 == '\0')) {
          FUN_1403e44e0(param_1);
        }
        FUN_140362560(local_488);
        cVar7 = FUN_140362910(local_488,0xeb,*(undefined4 *)(param_1 + 0x210),
                              *(undefined8 *)(param_1 + 0x140));
        if (cVar7 != '\0') {
          uVar9 = (**(code **)(*param_2 + 8))(param_2);
          FUN_1403d74e0(param_1,local_488,uVar9);
        }
        FUN_1403625e0(local_488);
        FUN_1404537b0(local_8b8);
        uVar10 = 1;
      }
      else {
        uVar10 = 0;
      }
    }
  }
  else {
    uVar10 = 0;
  }
  return uVar10;
}

// ==== CMsgSitDown@texasholdem::helper_1403e79f0  @1403e79f0  [medium:callgraph-r2]  (orig: FUN_1403e79f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403e79f0(longlong param_1,char param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined1 local_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  FUN_140459f10(local_458);
  local_470 = 2;
  local_478 = 0;
  cVar2 = FUN_140459fc0(local_458,(param_2 == '\0') + '\x03',*(undefined4 *)(param_1 + 0x2a0),
                        *(undefined4 *)(param_1 + 0x29c));
  if (cVar2 != '\0') {
    FUN_1403d6ff0(param_1,local_458);
  }
  uVar1 = *(undefined4 *)(param_1 + 0x29c);
  FUN_1403c6120(param_1 + 0x2a8);
  *(undefined4 *)(param_1 + 0x29c) = 0;
  *(undefined4 *)(param_1 + 0x2a0) = 0;
  *(undefined4 *)(param_1 + 0x298) = 0;
  *(undefined4 *)(param_1 + 0x294) = 0;
  if (param_2 != '\0') {
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
    plVar4 = (longlong *)FUN_140087650(uVar3);
    lVar5 = (**(code **)(*plVar4 + 0x98))(plVar4,uVar1);
    if (lVar5 != 0) {
      FUN_1403e7910(param_1,lVar5);
    }
  }
  FUN_140459f60(local_458);
  return;
}

// ==== CMsgSitDown@texasholdem::helper_140452f10  @140452f10  [medium:callgraph-r1]  (orig: FUN_140452f10)
undefined8 * FUN_140452f10(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = texasholdem::CMsgShowHandExit::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgSitDown@texasholdem::helper_140452f60  @140452f60  [medium:callgraph-r1]  (orig: FUN_140452f60)
void FUN_140452f60(undefined8 *param_1)

{
  *param_1 = texasholdem::CMsgShowHandExit::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgSitDown@texasholdem::helper_140452fc0  @140452fc0  [medium:callgraph-r1]  (orig: FUN_140452fc0)
undefined8 FUN_140452fc0(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 8) = 0x830;
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 8) = param_4;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgSitDown@texasholdem::helper_140453760  @140453760  [medium:callgraph-r1]  (orig: FUN_140453760)
undefined8 * FUN_140453760(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = texasholdem::CMsgSitDown::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgSitDown@texasholdem::helper_1404537b0  @1404537b0  [medium:callgraph-r1]  (orig: FUN_1404537b0)
void FUN_1404537b0(undefined8 *param_1)

{
  *param_1 = texasholdem::CMsgSitDown::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgSitDown@texasholdem::vfunc_1  @1404537e0  [high:rtti-vtable]  (orig: FUN_1404537e0)
undefined8 FUN_1404537e0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgSitDown@texasholdem::helper_140453810  @140453810  [medium:callgraph-r1]  (orig: FUN_140453810)
undefined8
FUN_140453810(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4,
             undefined1 param_5)

{
  *(undefined4 *)(param_1 + 8) = 0x87b;
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_5;
  return 1;
}

// ==== CMsgSitDown@texasholdem::vfunc_0  @140453850  [high:rtti-vtable]  (orig: FUN_140453850)
undefined8 * FUN_140453850(undefined8 *param_1,uint param_2)

{
  *param_1 = texasholdem::CMsgSitDown::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgSitDown@texasholdem::vfunc_3  @1404538a0  [high:rtti-vtable]  (orig: FUN_1404538a0)
void FUN_1404538a0(longlong param_1)

{
  short sVar1;
  short *psVar2;
  char cVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x88))(*(longlong **)(lVar4 + 0x90),param_1);
  if (lVar4 != 0) {
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar6 = *(longlong *)(lVar5 + 0x108);
    if (*(longlong *)(lVar5 + 0x108) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar6 = 0;
    }
    cVar3 = FUN_140215360(lVar6,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (cVar3 != '\0') {
      lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar6 = *(longlong *)(lVar6 + 0x108);
      if (lVar6 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar6 = 0;
      }
      lVar6 = FUN_140214ce0(lVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if ((lVar6 != 0) && (cVar3 = FUN_1403bc2d0(lVar6), cVar3 == '\0')) {
        psVar2 = *(short **)(param_1 + 0x428);
        sVar1 = *psVar2;
        if (sVar1 == 0) {
          FUN_1403e26a0(lVar6,lVar4,1,(char)psVar2[6]);
        }
        else {
          if (sVar1 == 1) {
            FUN_1403e7110(lVar6,lVar4,1);
            return;
          }
          if (sVar1 == 4) {
            FUN_1403d8ec0(lVar6,*(undefined4 *)(psVar2 + 2),lVar4,(char)psVar2[6],1);
            return;
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1404dab60  @1404dab60  [medium:callgraph-r2]  (orig: FUN_1404dab60)
undefined8 * FUN_1404dab60(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = texasholdem::CMsgShowHandDealtCard::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgSitDown@texasholdem::helper_1404dabb0  @1404dabb0  [medium:callgraph-r2]  (orig: FUN_1404dabb0)
void FUN_1404dabb0(undefined8 *param_1)

{
  *param_1 = texasholdem::CMsgShowHandDealtCard::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgSitDown@texasholdem::helper_1404dac10  @1404dac10  [medium:callgraph-r2]  (orig: FUN_1404dac10)
ulonglong FUN_1404dac10(longlong param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
                       longlong param_5,longlong param_6,ushort param_7,undefined4 param_8,
                       undefined4 param_9,uint param_10,longlong param_11)

{
  uint uVar1;
  ulonglong uVar2;
  ushort uVar3;
  ushort uVar4;
  
  memset(*(void **)(param_1 + 0x428),0,0x30);
  *(undefined4 *)(param_1 + 8) = 0x82b;
  uVar2 = (ulonglong)param_7 * 8 + 0x28;
  uVar1 = (uint)uVar2;
  *(uint *)(param_1 + 0xc) = uVar1;
  if (uVar1 < 0x3fc) {
    if (5 < param_4) {
      param_4 = 5;
    }
    **(undefined2 **)(param_1 + 0x428) = param_2;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = param_3;
    *(ushort *)(*(longlong *)(param_1 + 0x428) + 4) = param_4;
    uVar3 = 0;
    for (uVar4 = 0; uVar4 < param_4; uVar4 = uVar4 + 1) {
      uVar2 = (ulonglong)uVar4;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 6 + uVar2 * 2) =
           *(undefined2 *)(param_5 + uVar2 * 2);
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10 + uVar2 * 2) =
           *(undefined2 *)(param_6 + uVar2 * 2);
    }
    *(ushort *)(*(longlong *)(param_1 + 0x428) + 0x1a) = param_7;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = param_8;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x20) = param_9;
    uVar2 = (ulonglong)param_10;
    *(uint *)(*(longlong *)(param_1 + 0x428) + 0x24) = param_10;
    if (param_11 != 0) {
      for (; uVar3 < param_7; uVar3 = uVar3 + 1) {
        uVar2 = *(ulonglong *)(param_1 + 0x428);
        *(undefined8 *)(uVar2 + 0x28 + (ulonglong)uVar3 * 8) =
             *(undefined8 *)(param_11 + (ulonglong)uVar3 * 8);
      }
    }
    uVar2 = CONCAT71((int7)(uVar2 >> 8),1);
  }
  else {
    uVar2 = uVar2 & 0xffffffffffffff00;
  }
  return uVar2;
}

// ==== CMsgSitDown@texasholdem::helper_1404dad90  @1404dad90  [medium:callgraph-r2]  (orig: FUN_1404dad90)
int FUN_1404dad90(byte *param_1)

{
  if (*param_1 == 1) {
    return 0xc;
  }
  return *param_1 - 2;
}

