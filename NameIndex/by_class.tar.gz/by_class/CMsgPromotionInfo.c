// ==== CMsgPromotionInfo::ctor_or_dtor  @1404552d0  [high:vtable-assign]  (orig: FUN_1404552d0)
undefined8 * FUN_1404552d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgPromotionInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgPromotionInfo::ctor_or_dtor  @140455320  [high:vtable-assign]  (orig: FUN_140455320)
void FUN_140455320(undefined8 *param_1)

{
  *param_1 = CMsgPromotionInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgPromotionInfo::vfunc_1  @140455350  [high:rtti-vtable]  (orig: FUN_140455350)
ulonglong FUN_140455350(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x52c);
}

// ==== CMsgPromotionInfo::vfunc_3  @1404554a0  [high:rtti-vtable]  (orig: FUN_1404554a0)
void FUN_1404554a0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgPromotionInfo::ctor_or_dtor  @140455500  [high:vtable-assign]  (orig: FUN_140455500)
undefined8 * FUN_140455500(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgPromotionInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

