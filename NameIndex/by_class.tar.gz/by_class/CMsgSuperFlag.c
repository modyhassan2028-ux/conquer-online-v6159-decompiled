// ==== CMsgSuperFlag::helper_1400781b0  @1400781b0  [medium:callgraph-r3]  (orig: FUN_1400781b0)
void FUN_1400781b0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMsgSuperFlag::helper_140078210  @140078210  [medium:callgraph-r3]  (orig: FUN_140078210)
void FUN_140078210(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMsgSuperFlag::helper_140078290  @140078290  [medium:callgraph-r3]  (orig: FUN_140078290)
void FUN_140078290(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400782b4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMsgSuperFlag::helper_1400788d0  @1400788d0  [medium:callgraph-r2]  (orig: FUN_1400788d0)
undefined8 * FUN_1400788d0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140078290(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_140078abc;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_140078abc:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1400781b0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140078210(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1400781b0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140078210(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1400781b0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_140078210(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMsgSuperFlag::helper_1400795e0  @1400795e0  [medium:callgraph-r1]  (orig: FUN_1400795e0)
longlong * FUN_1400795e0(longlong *param_1,longlong *param_2,int *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(int *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(int *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgSuperFlag::helper_14020cda0  @14020cda0  [medium:callgraph-r1]  (orig: FUN_14020cda0)
bool FUN_14020cda0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  byte bVar1;
  char cVar2;
  longlong lVar3;
  longlong *plVar4;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar3 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x98) + 0x10))
                    (*(longlong **)(lVar3 + 0x98),param_2,0);
  if (lVar3 != 0) {
    plVar4 = *(longlong **)(*(longlong *)(lVar3 + 0x58) + 8);
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,4);
    bVar1 = (**(code **)(*plVar4 + 0x58))(plVar4);
    if ((bVar1 >> 1 & 1) == 0) {
      cVar2 = FUN_1402c3cc0(lVar3,param_3,param_4);
      return cVar2 != '\0';
    }
  }
  return false;
}

// ==== CMsgSuperFlag::helper_14020ea80  @14020ea80  [medium:callgraph-r0]  (orig: FUN_14020ea80)
undefined8 FUN_14020ea80(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgSuperFlag::helper_14020ec80  @14020ec80  [medium:callgraph-r0]  (orig: FUN_14020ec80)
undefined1 FUN_14020ec80(undefined8 param_1,longlong param_2,undefined4 param_3)

{
  undefined1 uVar1;
  longlong lVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = FUN_14020ea80(param_1,param_3);
    if (lVar2 != 0) {
      uVar1 = FUN_1404149f0(lVar2,param_2);
      return uVar1;
    }
  }
  return 0;
}

// ==== CMsgSuperFlag::helper_140413a90  @140413a90  [medium:callgraph-r2]  (orig: FUN_140413a90)
undefined8 FUN_140413a90(undefined8 param_1,longlong param_2,undefined4 param_3,char *param_4)

{
  longlong lVar1;
  IStringManager *pIVar2;
  char *pcVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  switch(param_3) {
  case 1:
    pIVar2 = theInstance();
    pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"STR_SUPERFLAG_MSG_IN_BOOTHING");
    strncpy(param_4,pcVar3,0x100);
    return 1;
  case 2:
    pIVar2 = theInstance();
    pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"STR_SUPERFLAG_MSG_WRONG_TARGET_MAP")
    ;
    strncpy(param_4,pcVar3,0x100);
    return 1;
  case 3:
    pIVar2 = theInstance();
    pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"STR_SUPERFLAG_MSG_WRONG_TARGET_POS")
    ;
    strncpy(param_4,pcVar3,0x100);
    return 1;
  case 4:
    lVar1 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x160))(param_2 + 0x10);
    if (lVar1 != 0) {
      pIVar2 = theInstance();
      (**(code **)(**(longlong **)(lVar1 + 0x58) + 0x18))(*(longlong **)(lVar1 + 0x58),1);
      pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)
                                 (pIVar2,"STR_SUPERFLAG_MSG_MAP_TRANS_DISABLE");
      _snprintf(param_4,0x100,pcVar3);
      param_4[0xff] = '\0';
      return 1;
    }
    break;
  case 7:
    pIVar2 = theInstance();
    pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"STR_SUPERFLAG_MSG_WRONG_RECORD_MAP")
    ;
    strncpy(param_4,pcVar3,0x100);
    return 1;
  case 8:
    pIVar2 = theInstance();
    pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"STR_SUPERFLAG_MSG_WRONG_RECORD_POS")
    ;
    strncpy(param_4,pcVar3,0x100);
    return 1;
  }
  return 0;
}

// ==== CMsgSuperFlag::helper_140413e40  @140413e40  [medium:callgraph-r1]  (orig: FUN_140413e40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_140413e40(undefined4 *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  undefined1 auStack_68 [32];
  undefined4 local_48;
  char local_38 [40];
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  if (param_2 == (char *)0x0) {
    local_48 = 0x30;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_38[0] = '\0';
    local_38[1] = '\0';
    local_38[2] = '\0';
    local_38[3] = '\0';
    local_38[4] = '\0';
    local_38[5] = '\0';
    local_38[6] = '\0';
    local_38[7] = '\0';
    local_38[8] = '\0';
    local_38[9] = '\0';
    local_38[10] = '\0';
    local_38[0xb] = '\0';
    local_38[0xc] = '\0';
    local_38[0xd] = '\0';
    local_38[0xe] = '\0';
    local_38[0xf] = '\0';
    local_38[0x10] = '\0';
    local_38[0x11] = '\0';
    local_38[0x12] = '\0';
    local_38[0x13] = '\0';
    local_38[0x14] = '\0';
    local_38[0x15] = '\0';
    local_38[0x16] = '\0';
    local_38[0x17] = '\0';
    local_38[0x18] = '\0';
    local_38[0x19] = '\0';
    local_38[0x1a] = '\0';
    local_38[0x1b] = '\0';
    local_38[0x1c] = '\0';
    local_38[0x1d] = '\0';
    local_38[0x1e] = '\0';
    local_38[0x1f] = '\0';
    local_38[0x20] = '\0';
    local_38[0x21] = '\0';
    local_38[0x22] = '\0';
    local_38[0x23] = 0;
    strncpy(local_38,param_2,0x24);
    iVar2 = tq::StringCheck(local_38,0);
    if (iVar2 != 0) {
      iVar2 = tq::NameStrCheck(local_38,false);
      if (iVar2 != 0) {
        uVar3 = FUN_140008520(*param_1);
        cVar1 = FUN_14008a1d0(uVar3,local_38,0);
        return cVar1 == '\0';
      }
    }
  }
  return false;
}

// ==== CMsgSuperFlag::helper_140413f20  @140413f20  [medium:callgraph-r1]  (orig: FUN_140413f20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140413f20(longlong param_1,longlong *param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,char param_6)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined1 auStack_5c8 [32];
  uint local_5a8;
  undefined4 local_5a0;
  undefined4 local_598;
  undefined8 local_588;
  undefined1 local_578 [1072];
  undefined1 local_148 [256];
  ulonglong local_48;
  
  local_588 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_5c8;
  if (param_2 == (longlong *)0x0) {
    local_5a8 = 0x240;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar2 = 0;
    plVar4 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_5a8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    lVar3 = (**(code **)(*plVar4 + 0x60))(plVar4,*(undefined4 *)(param_1 + 4));
    if (lVar3 != 0) {
      uVar2 = FUN_1400fda10(lVar3,4,1);
    }
    if (param_6 != '\0') {
      cVar1 = FUN_140413a90(param_1,param_2,param_5,local_148);
      if (cVar1 != '\0') {
        (**(code **)(*param_2 + 0x150))(param_2,0x843,local_148);
      }
    }
    FUN_140451eb0(local_578);
    local_5a0 = param_5;
    local_5a8 = local_5a8 & 0xffffff00;
    local_598 = uVar2;
    cVar1 = FUN_140451f30(local_578,param_3,*(undefined4 *)(param_1 + 4),param_4);
    if (cVar1 != '\0') {
      (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_578);
    }
    FUN_140451f00(local_578);
  }
  return;
}

// ==== CMsgSuperFlag::helper_140414210  @140414210  [medium:callgraph-r2]  (orig: FUN_140414210)
undefined8 * FUN_140414210(longlong *param_1,undefined8 *param_2,longlong *param_3,int *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  int iVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_140078d80(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(int *)(lVar3 + 0x18)) {
        FUN_140078d80(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(int *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_140078d80(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        iVar7 = *param_4;
        if (iVar7 < *(int *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          iVar7 = *param_4;
          if ((int)plVar8[3] < iVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_140078d80(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_140078d80(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(int *)(param_3[1] + 0x18) < iVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < (int)plVar9[3])) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_140078d80(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_140078d80(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_140079430(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CMsgSuperFlag::helper_140414530  @140414530  [medium:callgraph-r1]  (orig: FUN_140414530)
undefined8 FUN_140414530(longlong param_1,int param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  plVar1 = (longlong *)(param_1 + 8);
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar2 = *(char *)((longlong)puVar8 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x38);
  while (cVar2 == '\0') {
    if (*(int *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar4;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar4 = puVar8;
    puVar8 = puVar6;
    cVar2 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar4;
  local_38 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar8) || (param_2 < *(int *)(puVar4 + 3))) {
    plVar9 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *plVar1;
  }
  else {
    plVar9 = &local_38;
  }
  plVar3 = (longlong *)*plVar9;
  lVar10 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar3;
  local_10 = plVar9[1];
  if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (local_10 == lVar10) {
    uVar7 = 0;
  }
  else {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = *(longlong **)(lVar5 + 0x20);
    if (plVar3 != (longlong *)0x0) {
      (**(code **)(*plVar3 + 0x40))(plVar3,0);
      (**(code **)*plVar3)(plVar3,1);
    }
    local_18 = (longlong *)*plVar9;
    local_10 = plVar9[1];
    FUN_1400788d0(plVar1,&local_28,&local_18);
    uVar7 = 1;
  }
  return uVar7;
}

// ==== CMsgSuperFlag::helper_140414680  @140414680  [medium:callgraph-r1]  (orig: FUN_140414680)
undefined8 FUN_140414680(longlong param_1,int param_2,undefined4 *param_3)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *plVar7;
  char *_Source;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar2 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(int *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar2;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar2 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar2;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar8) || (param_2 < *(int *)(puVar2 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar6 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar6;
  local_10 = plVar7[1];
  if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_10;
  if (local_10 != lVar9) {
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar6;
    }
    if (lVar3 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = *(longlong **)(lVar3 + 0x20);
    if (plVar7 != (longlong *)0x0) {
      plVar6 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,2);
      uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
      *param_3 = uVar4;
      plVar6 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,3);
      uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
      param_3[1] = uVar4;
      plVar6 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
      uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
      param_3[2] = uVar4;
      plVar6 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,5);
      uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
      param_3[3] = uVar4;
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,6);
      _Source = (char *)(**(code **)(*plVar7 + 0x78))(plVar7);
      strncpy((char *)(param_3 + 4),_Source,0x20);
      return 1;
    }
  }
  return 0;
}

// ==== CMsgSuperFlag::helper_140414830  @140414830  [medium:callgraph-r1]  (orig: FUN_140414830)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140414830(longlong param_1,longlong param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  uint uVar5;
  undefined1 auStack_4f8 [32];
  undefined4 local_4d8;
  undefined4 local_4d0;
  undefined4 local_4c8;
  undefined8 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4ac;
  undefined4 local_4a8;
  undefined4 local_4a4;
  undefined8 local_4a0;
  undefined8 local_498;
  undefined8 local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  longlong *plVar6;
  
  local_4b8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (param_2 == 0) {
    local_4d8 = 0x21f;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar6 = (longlong *)0x0;
    uVar2 = 0;
    plVar4 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_4d8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = plVar6;
    }
    lVar3 = (**(code **)(*plVar4 + 0x60))(plVar4,*(undefined4 *)(param_1 + 4));
    if (lVar3 != 0) {
      uVar2 = FUN_1400fda10(lVar3,4,1);
    }
    FUN_140451eb0(local_478);
    local_4d0 = 0;
    local_4d8 = CONCAT31(local_4d8._1_3_,1);
    local_4c8 = uVar2;
    cVar1 = FUN_140451f30(local_478,param_3,*(undefined4 *)(param_1 + 4),param_4);
    if (cVar1 == '\0') {
      FUN_140451f00(local_478);
    }
    else {
      do {
        local_4b0 = 0;
        local_4ac = 0;
        local_4a8 = 0;
        local_4a4 = 0;
        local_4a0 = 0;
        local_498 = 0;
        local_490 = 0;
        local_488 = 0;
        cVar1 = FUN_140414680(param_1,plVar6,&local_4b0);
        if (cVar1 != '\0') {
          FUN_140452070(local_478,&local_4b0);
        }
        uVar5 = (int)plVar6 + 1;
        plVar6 = (longlong *)(ulonglong)uVar5;
      } while ((int)uVar5 < 10);
      (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_478);
      FUN_140451f00(local_478);
    }
  }
  return;
}

// ==== CMsgSuperFlag::helper_1404149f0  @1404149f0  [medium:callgraph-r1]  (orig: FUN_1404149f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404149f0(longlong param_1,longlong param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong *plVar5;
  uint uVar6;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined8 local_498;
  undefined4 local_490;
  undefined4 local_48c;
  undefined4 local_488;
  undefined4 local_484;
  undefined8 local_480;
  undefined8 local_478;
  undefined8 local_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  longlong *plVar7;
  
  local_498 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (param_2 == 0) {
    local_4a8 = 0x285;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    plVar7 = (longlong *)0x0;
    plVar5 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_4a8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = plVar7;
    }
    lVar4 = (**(code **)(*plVar5 + 0x60))(plVar5,*(undefined4 *)(param_1 + 4));
    uVar3 = 0;
    if (lVar4 != 0) {
      uVar2 = FUN_1400fda10(lVar4,4,1);
      FUN_140451eb0(local_458);
      cVar1 = FUN_140451fd0(local_458,0,*(undefined4 *)(param_1 + 4),uVar2);
      if (cVar1 == '\0') {
        FUN_140451f00(local_458);
        uVar3 = 0;
      }
      else {
        do {
          local_490 = 0;
          local_48c = 0;
          local_488 = 0;
          local_484 = 0;
          local_480 = 0;
          local_478 = 0;
          local_470 = 0;
          local_468 = 0;
          cVar1 = FUN_140414680(param_1,plVar7,&local_490);
          if (cVar1 != '\0') {
            FUN_140452070(local_458,&local_490);
          }
          uVar6 = (int)plVar7 + 1;
          plVar7 = (longlong *)(ulonglong)uVar6;
        } while ((int)uVar6 < 10);
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_458)
        ;
        FUN_140451f00(local_458);
        uVar3 = 1;
      }
    }
  }
  return uVar3;
}

// ==== CMsgSuperFlag::helper_140414b90  @140414b90  [medium:callgraph-r1]  (orig: FUN_140414b90)
undefined8 * FUN_140414b90(longlong *param_1,int *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(int *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(int *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_140414210(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CMsgSuperFlag::helper_140414c90  @140414c90  [medium:callgraph-r0]  (orig: FUN_140414c90)
undefined8 FUN_140414c90(longlong param_1,longlong param_2,uint param_3,char *param_4)

{
  longlong lVar1;
  longlong *plVar2;
  char cVar3;
  undefined8 uVar4;
  longlong *plVar5;
  ulonglong uVar6;
  char *pcVar7;
  longlong lVar8;
  uint local_res18 [2];
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  
  local_res18[0] = param_3;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = 0;
  }
  else if (param_4 == (char *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = 0;
  }
  else {
    uVar6 = 0xffffffffffffffff;
    pcVar7 = param_4;
    do {
      if (uVar6 == 0) break;
      uVar6 = uVar6 - 1;
      cVar3 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar3 != '\0');
    if (~uVar6 - 1 < 0x25) {
      cVar3 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x220))();
      if (cVar3 == '\0') {
        FUN_140413f20(param_1,param_2,2,param_3,6,0);
        uVar4 = 0;
      }
      else {
        cVar3 = FUN_140332fe0(param_2,*(undefined4 *)(param_1 + 4));
        if (cVar3 == '\0') {
          FUN_140413f20(param_1,param_2,2,param_3,6,0);
          uVar4 = 0;
        }
        else if (param_3 < 10) {
          cVar3 = FUN_140413e40(param_1,param_4);
          if (cVar3 == '\0') {
            FUN_140413f20(param_1,param_2,2,param_3,6,0);
            uVar4 = 0;
          }
          else {
            FUN_1400795e0(param_1 + 8,&local_50,local_res18);
            lVar1 = *(longlong *)(param_1 + 0x38);
            lVar8 = 0;
            local_40 = *(longlong **)(param_1 + 8);
            if ((local_50 == (longlong *)0x0) || (local_50 != local_40)) {
              _invalid_parameter_noinfo();
            }
            if (local_48 == lVar1) {
              FUN_140413f20(param_1,param_2,2,param_3,0,1);
              uVar4 = 0;
            }
            else {
              if (local_50 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                lVar8 = *local_50;
              }
              if (local_48 == *(longlong *)(lVar8 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              plVar2 = *(longlong **)(local_48 + 0x20);
              if (plVar2 == (longlong *)0x0) {
                FUN_140413f20(param_1,param_2,2,param_3,6,0);
                uVar4 = 0;
              }
              else {
                plVar5 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,6);
                (**(code **)(*plVar5 + 0x80))(plVar5,param_4);
                (**(code **)(*plVar2 + 0x38))(plVar2,0);
                FUN_140414830(param_1,param_2,2,param_3);
                uVar4 = 1;
              }
            }
          }
        }
        else {
          FUN_140413f20(param_1,param_2,2,param_3,0,1);
          uVar4 = 0;
        }
      }
    }
    else {
      FUN_140413f20(param_1,param_2,2,param_3,6,0,0xfffffffffffffffe);
      uVar4 = 0;
    }
  }
  return uVar4;
}

// ==== CMsgSuperFlag::helper_140414f60  @140414f60  [medium:callgraph-r0]  (orig: FUN_140414f60)
undefined8 FUN_140414f60(undefined4 *param_1,longlong param_2,uint param_3)

{
  char cVar1;
  byte bVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  uint local_res18 [2];
  
  local_res18[0] = param_3;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    cVar1 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x220))(param_2 + 0x10);
    if (cVar1 == '\0') {
      FUN_140413f20(param_1,param_2,1,param_3,6,0);
      uVar6 = 0;
    }
    else {
      cVar1 = FUN_140332fe0(param_2,param_1[1]);
      if (cVar1 == '\0') {
        FUN_140413f20(param_1,param_2,1,param_3,6,0);
        uVar6 = 0;
      }
      else if (param_3 < 10) {
        plVar7 = (longlong *)(**(code **)(*(longlong *)(param_2 + 0x10) + 0x160))(param_2 + 0x10);
        if (plVar7 == (longlong *)0x0) {
          FUN_140413f20(param_1,param_2,1,param_3,7,1);
          uVar6 = 0;
        }
        else {
          lVar8 = FUN_140008520(*param_1);
          if (*(longlong *)(lVar8 + 0x128) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar6 = 0;
          }
          else {
            uVar6 = *(undefined8 *)(lVar8 + 0x128);
          }
          uVar3 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x48))(param_2 + 0x10);
          uVar4 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x40))(param_2 + 0x10);
          uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
          cVar1 = FUN_14020cda0(uVar6,uVar5,uVar4,uVar3);
          if (cVar1 == '\0') {
            plVar7 = (longlong *)
                     (**(code **)(**(longlong **)(plVar7[0xb] + 8) + 0x10))
                               (*(longlong **)(plVar7[0xb] + 8),4);
            bVar2 = (**(code **)(*plVar7 + 0x58))(plVar7);
            if ((bVar2 >> 1 & 1) == 0) {
              FUN_140413f20(param_1,param_2,1,param_3,8,1);
            }
            else {
              FUN_140413f20(param_1,param_2,1,param_3,7,1);
            }
            uVar6 = 0;
          }
          else {
            FUN_140414530(param_1,param_3);
            plVar9 = (longlong *)InstanceGet();
            plVar9 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"cq_super_flag");
            if (plVar9 == (longlong *)0x0) {
              FUN_140413f20(param_1,param_2,1,param_3,6,0);
              uVar6 = 0;
            }
            else {
              plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,1);
              (**(code **)(*plVar10 + 0xb8))(plVar10,param_1[1]);
              plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
              (**(code **)(*plVar10 + 0xb0))(plVar10,param_3);
              plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,3);
              lVar8 = *plVar10;
              uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
              (**(code **)(lVar8 + 0xb8))(plVar10,uVar3);
              plVar7 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,4);
              lVar8 = *plVar7;
              uVar3 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x40))(param_2 + 0x10);
              (**(code **)(lVar8 + 0xb0))(plVar7,uVar3);
              plVar7 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,5);
              lVar8 = *plVar7;
              uVar3 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x48))(param_2 + 0x10);
              (**(code **)(lVar8 + 0xb0))(plVar7,uVar3);
              plVar7 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,6);
              (**(code **)(*plVar7 + 0x80))(plVar7,&DAT_1406dd892);
              cVar1 = (**(code **)(*plVar9 + 0x50))(plVar9,1);
              if (cVar1 == '\0') {
                (**(code **)*plVar9)(plVar9,1);
                uVar6 = 0;
              }
              else {
                puVar11 = (undefined8 *)FUN_140414b90(param_1 + 2,local_res18);
                *puVar11 = plVar9;
                FUN_140414830(param_1,param_2,1,param_3);
                uVar6 = 1;
              }
            }
          }
        }
      }
      else {
        log_InlineLogERROR("CSuperFlag::AddMapPos, super flag: %u, wrong index: %d");
        FUN_140413f20(param_1,param_2,1,param_3,0,1);
        uVar6 = 0;
      }
    }
  }
  return uVar6;
}

// ==== CMsgSuperFlag::helper_140415750  @140415750  [medium:callgraph-r0]  (orig: FUN_140415750)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140415750(undefined4 *param_1,longlong param_2,undefined4 param_3)

{
  char cVar1;
  byte bVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  int iVar8;
  undefined1 auStack_a8 [32];
  uint local_88;
  undefined4 local_80;
  undefined4 local_78;
  undefined4 *local_70;
  undefined8 local_68;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  undefined8 local_50;
  undefined8 local_48;
  undefined8 local_40;
  undefined8 local_38;
  ulonglong local_30;
  
  local_68 = 0xfffffffffffffffe;
  local_30 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  local_78 = param_3;
  local_70 = param_1;
  if (param_2 == 0) {
    local_88 = 0x173;
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  cVar1 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x220))(param_2 + 0x10);
  if (cVar1 == '\0') {
    return 0;
  }
  iVar3 = FUN_140166ec0(param_2);
  if (iVar3 != 0) {
    local_80 = CONCAT31(local_80._1_3_,1);
    local_88 = 1;
    FUN_140413f20(param_1,param_2,3,param_3);
    return 0;
  }
  lVar4 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x160))(param_2 + 0x10);
  if (lVar4 == 0) {
    local_80 = CONCAT31(local_80._1_3_,1);
    local_88 = 6;
    FUN_140413f20(param_1,param_2,3,param_3);
    return 0;
  }
  plVar5 = *(longlong **)(*(longlong *)(lVar4 + 0x58) + 8);
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,4);
  bVar2 = (**(code **)(*plVar5 + 0x58))(plVar5);
  if ((bVar2 >> 6 & 1) != 0) {
    local_80 = CONCAT31(local_80._1_3_,1);
    local_88 = 4;
    FUN_140413f20(param_1,param_2,3,param_3);
    return 0;
  }
  plVar5 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    local_88 = 0x3c0;
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = (longlong *)0x0;
  }
  lVar4 = (**(code **)(*plVar5 + 0x60))(plVar5,param_1[1]);
  if (lVar4 == 0) {
    local_80 = CONCAT31(local_80._1_3_,1);
    local_88 = 6;
    FUN_140413f20(param_1,param_2,3,param_3);
    return 0;
  }
  iVar3 = FUN_1400fda10(lVar4,4,1);
  if (iVar3 < 1) {
    local_80 = CONCAT31(local_80._1_3_,1);
    local_88 = 5;
    FUN_140413f20(param_1,param_2,3,param_3);
    return 0;
  }
  cVar1 = FUN_140332fe0(param_2,param_1[1]);
  if (cVar1 != '\0') {
    local_60 = 0;
    local_5c = 0;
    local_58 = 0;
    local_54 = 0;
    local_50 = 0;
    local_48 = 0;
    local_40 = 0;
    local_38 = 0;
    cVar1 = FUN_140414680(param_1,param_3,&local_60);
    if (cVar1 == '\0') {
      local_80 = CONCAT31(local_80._1_3_,1);
      local_88 = 0;
      FUN_140413f20(param_1,param_2,3,param_3);
      return 0;
    }
    lVar6 = FUN_140008520(*param_1);
    if (*(longlong *)(lVar6 + 0x128) == 0) {
      local_88 = 0x14a;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = (longlong *)0x0;
    }
    else {
      plVar5 = *(longlong **)(lVar6 + 0x128);
    }
    cVar1 = FUN_14020cda0(plVar5,local_5c,local_58,local_54);
    if (cVar1 == '\0') {
      uVar7 = FUN_140008520(*param_1);
      plVar5 = (longlong *)FUN_1400876b0(uVar7);
      lVar4 = (**(code **)(*plVar5 + 0x10))(plVar5,local_5c,1);
      if (lVar4 != 0) {
        plVar5 = *(longlong **)(*(longlong *)(lVar4 + 0x58) + 8);
        plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,4);
        bVar2 = (**(code **)(*plVar5 + 0x58))(plVar5);
        if ((bVar2 >> 1 & 1) == 0) {
          local_80 = CONCAT31(local_80._1_3_,1);
          local_88 = 3;
          FUN_140413f20(param_1,param_2,3,param_3);
          return 0;
        }
      }
      local_80 = CONCAT31(local_80._1_3_,1);
      local_88 = 2;
      FUN_140413f20(param_1,param_2,3,param_3);
      return 0;
    }
    iVar8 = iVar3 + -1;
    if (iVar3 + -1 < 0) {
      iVar8 = 0;
    }
    FUN_140104140(lVar4,4,iVar8);
    plVar5 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_88 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = (longlong *)0x0;
    }
    local_80 = 0;
    local_88 = 0;
    (**(code **)(*plVar5 + 0x130))(plVar5,param_2,lVar4,3);
    local_88 = local_88 & 0xffffff00;
    iVar3 = FUN_1401c55b0(param_2,local_5c,local_58,local_54);
    if (iVar3 == 0) {
      FUN_140414830(param_1,param_2,3,param_3);
      return 1;
    }
    local_80 = CONCAT31(local_80._1_3_,1);
    local_88 = 6;
    FUN_140413f20(param_1,param_2,3,param_3);
    return 0;
  }
  local_80 = CONCAT31(local_80._1_3_,1);
  local_88 = 6;
  FUN_140413f20(param_1,param_2,3,param_3);
  return 0;
}

// ==== CMsgSuperFlag::helper_140415be0  @140415be0  [medium:callgraph-r0]  (orig: FUN_140415be0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140415be0(longlong param_1,longlong *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  longlong lVar6;
  ulonglong uVar7;
  undefined8 uVar8;
  longlong *plVar9;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pUser",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\superflag.cpp"
                      );
  }
  else {
    cVar1 = (**(code **)(param_2[2] + 0x220))(param_2 + 2);
    if (cVar1 == '\0') {
      FUN_140413f20(param_1,param_2,4);
    }
    else {
      cVar1 = FUN_140332fe0(param_2,*(undefined4 *)(param_1 + 4));
      if (cVar1 == '\0') {
        FUN_140413f20(param_1,param_2,4);
      }
      else {
        plVar9 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          plVar9 = (longlong *)0x0;
        }
        lVar6 = (**(code **)(*plVar9 + 0x60))(plVar9,*(undefined4 *)(param_1 + 4));
        if (lVar6 == 0) {
          FUN_140413f20(param_1,param_2,4,0);
        }
        else {
          iVar2 = FUN_1400fda10(lVar6,4,1);
          iVar3 = FUN_1400fda10(lVar6,5,1);
          if ((iVar2 < iVar3) && (-1 < iVar2)) {
            uVar4 = ((iVar3 - iVar2) + 1) / 2;
            if (*(uint *)((longlong)param_2 + 0xfa4) < uVar4) {
              FUN_140413f20(param_1,param_2,4);
              return 0;
            }
            cVar1 = (**(code **)(param_2[2] + 0x2e0))(param_2 + 2,0x1d,(longlong)(int)-uVar4,1);
            if (cVar1 == '\0') {
              uVar7 = (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR("CSuperFlag::Repair, failed in decrease user(%u) emoney: %d",
                                 uVar7 & 0xffffffff,(ulonglong)uVar4);
              FUN_140413f20(param_1,param_2,4);
              return 0;
            }
            uVar5 = (**(code **)(*param_2 + 8))(param_2);
            FUN_1401742b0(param_2,0x23,uVar5);
            uVar8 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
            uVar7 = (**(code **)(*param_2 + 8))(param_2);
            tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t0\t0\t%d\t%d\t1\t",uVar7 & 0xffffffff,
                          uVar8);
            uVar8 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
            uVar7 = (**(code **)(*param_2 + 8))(param_2);
            tq::MyLogSave("gmlog/superflag",
                          "repair: user:%u(%s), super flag:%u, curent amount: %d, amount limit: %d, cost: %d"
                          ,uVar7 & 0xffffffff,uVar8);
            FUN_140104140(lVar6,4,iVar3);
            FUN_140414830(param_1,param_2,4);
            plVar9 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                );
              plVar9 = (longlong *)0x0;
            }
            (**(code **)(*plVar9 + 0x130))(plVar9,param_2,lVar6,3);
            return 1;
          }
          FUN_140413f20(param_1,param_2,4);
        }
      }
    }
  }
  return 0;
}

// ==== CMsgSuperFlag::ctor_or_dtor  @140451eb0  [high:vtable-assign]  (orig: FUN_140451eb0)
undefined8 * FUN_140451eb0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgSuperFlag::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgSuperFlag::ctor_or_dtor  @140451f00  [high:vtable-assign]  (orig: FUN_140451f00)
void FUN_140451f00(undefined8 *param_1)

{
  *param_1 = CMsgSuperFlag::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgSuperFlag::helper_140451f30  @140451f30  [medium:callgraph-r2]  (orig: FUN_140451f30)
undefined8
FUN_140451f30(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined1 param_5,undefined4 param_6,undefined4 param_7)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x4c;
  *(undefined4 *)(param_1 + 8) = 0x83e;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_5;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_6;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_7;
  return CONCAT71((uint7)(uint3)((uint)param_7 >> 8),1);
}

// ==== CMsgSuperFlag::helper_140451fd0  @140451fd0  [medium:callgraph-r2]  (orig: FUN_140451fd0)
undefined8 FUN_140451fd0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x4c;
  *(undefined4 *)(param_1 + 8) = 0x83e;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 0x14) = param_4;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgSuperFlag::vfunc_1  @140452040  [high:rtti-vtable]  (orig: FUN_140452040)
undefined8 FUN_140452040(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgSuperFlag::helper_140452070  @140452070  [medium:callgraph-r2]  (orig: FUN_140452070)
undefined8 FUN_140452070(longlong param_1,void *param_2)

{
  int *piVar1;
  
  if (0x3ff < (longlong)*(int *)(param_1 + 0xc) + 0x30U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  memcpy((void *)(*(longlong *)(param_1 + 0x428) + 0x1c +
                 (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 0x18) * 0x30),param_2,0x30);
  piVar1 = (int *)(*(longlong *)(param_1 + 0x428) + 0x18);
  *piVar1 = *piVar1 + 1;
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x30;
  return 1;
}

// ==== CMsgSuperFlag::ctor_or_dtor  @140452100  [high:vtable-assign]  (orig: FUN_140452100)
undefined8 * FUN_140452100(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgSuperFlag::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgSuperFlag::vfunc_3  @140452150  [high:rtti-vtable]  (orig: FUN_140452150)
void FUN_140452150(longlong param_1,longlong param_2)

{
  int iVar1;
  int *piVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  
  if (param_2 != 0) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar3 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))
                      (*(longlong **)(lVar3 + 0x90),param_1);
    if (lVar3 != 0) {
      lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar4 = *(longlong *)(lVar4 + 0x128);
      if (lVar4 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar4 = 0;
      }
      lVar4 = FUN_14020ea80(lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (lVar4 != 0) {
        piVar2 = *(int **)(param_1 + 0x428);
        iVar1 = *piVar2;
        if (iVar1 == 0) {
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar5 = FUN_140117f70(uVar5);
          FUN_14020ec80(uVar5,lVar3,piVar2[1]);
        }
        else {
          if (iVar1 == 1) {
            FUN_140414f60(lVar4,lVar3,piVar2[2]);
            return;
          }
          if (iVar1 == 2) {
            if (piVar2[6] == 1) {
              FUN_140414c90(lVar4,lVar3,piVar2[7],piVar2 + 0xb);
              return;
            }
          }
          else {
            if (iVar1 == 3) {
              FUN_140415750(lVar4,lVar3,piVar2[2]);
              return;
            }
            if (iVar1 == 4) {
              FUN_140415be0(lVar4,lVar3);
              return;
            }
          }
        }
      }
    }
  }
  return;
}

