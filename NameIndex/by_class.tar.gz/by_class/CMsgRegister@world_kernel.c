// ==== CMsgRegister@world_kernel::helper_1400673a0  @1400673a0  [medium:callgraph-r1]  (orig: FUN_1400673a0)
undefined8 FUN_1400673a0(void)

{
  longlong lVar1;
  
  if (DAT_140975af8 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = DAT_140975af8;
  if (*(longlong *)(DAT_140975af8 + 0x70) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return *(undefined8 *)(lVar1 + 0x70);
}

// ==== CMsgRegister@world_kernel::helper_140068c80  @140068c80  [medium:callgraph-r0]  (orig: FUN_140068c80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_140068c80(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 param_5,int param_6,undefined4 param_7,undefined4 param_8)

{
  char cVar1;
  undefined1 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong *plVar8;
  uint uVar9;
  uint uVar10;
  ulonglong uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  undefined1 auStack_588 [32];
  undefined8 local_568;
  undefined8 local_560;
  int local_558;
  int local_550;
  int local_548;
  int local_540;
  undefined4 local_538;
  uint local_530;
  uint local_528;
  uint local_520;
  uint local_518;
  uint local_510;
  uint local_508;
  uint local_500;
  uint local_4f8;
  undefined1 *local_4f0;
  undefined1 *local_4e8;
  undefined4 local_4d8;
  ushort local_4d4;
  ushort local_4d2;
  int local_4d0;
  int local_4cc;
  undefined8 local_4c8;
  longlong local_4c0;
  undefined8 local_4b8;
  undefined8 local_4b0;
  undefined8 local_4a8;
  undefined1 local_498;
  undefined8 local_497;
  undefined8 local_48f;
  undefined8 local_487;
  undefined8 local_47f;
  undefined8 local_477;
  undefined8 local_46f;
  undefined8 local_467;
  undefined8 local_45f;
  undefined8 local_457;
  undefined1 local_44f;
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_4a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_588;
  local_4c8 = param_3;
  local_4b8 = param_4;
  local_4b0 = param_4;
  uVar6 = FUN_140067320();
  lVar7 = FUN_140073c40(uVar6,0x3ea);
  uVar2 = 0;
  if (lVar7 != 0) {
    local_4c0 = *(longlong *)(param_1 + 0x1c0) - *(longlong *)(param_1 + 0x1b8) >> 3;
    iVar3 = tq::RandGet((int)local_4c0);
    uVar11 = (ulonglong)iVar3;
    if ((ulonglong)(*(longlong *)(param_1 + 0x1c0) - *(longlong *)(param_1 + 0x1b8) >> 3) <= uVar11)
    {
      _invalid_parameter_noinfo();
    }
    local_4d2 = *(ushort *)(*(longlong *)(param_1 + 0x1b8) + uVar11 * 8);
    if ((ulonglong)(*(longlong *)(param_1 + 0x1c0) - *(longlong *)(param_1 + 0x1b8) >> 3) <= uVar11)
    {
      _invalid_parameter_noinfo();
    }
    local_4d4 = *(ushort *)(*(longlong *)(param_1 + 0x1b8) + 4 + uVar11 * 8);
    if ((param_6 < 0x3eb) || ((0x3ec < param_6 && ((param_6 < 0x7d1 || (0x7d2 < param_6)))))) {
      uVar2 = 0;
    }
    else {
      switch(param_7) {
      case 0:
      case 1:
        uVar10 = 100;
        local_4d8 = 100;
        break;
      case 2:
      case 3:
        uVar10 = 10;
        local_4d8 = 10;
        break;
      case 4:
      case 5:
        uVar10 = 0x28;
        local_4d8 = 0x28;
        break;
      case 6:
      case 7:
        uVar10 = 0x14;
        local_4d8 = 0x14;
        break;
      case 8:
      case 9:
        uVar10 = 0x32;
        local_4d8 = 0x32;
        break;
      case 10:
      case 0xb:
        uVar10 = 0x3c;
        local_4d8 = 0x3c;
        break;
      case 0xc:
      case 0xd:
        uVar10 = 0x46;
        local_4d8 = 0x46;
        break;
      case 0xe:
      case 0xf:
        uVar10 = 0x50;
        local_4d8 = 0x50;
        break;
      default:
        uVar10 = 0x14;
        local_4d8 = 0x14;
      }
      uVar13 = 7;
      iVar3 = tq::RandGet(7);
      iVar4 = tq::RandGet(10);
      local_4d0 = iVar4 + 0x156 + iVar3 * 100;
      if (uVar10 == 0x3c) {
        if ((param_6 / 1000) % 10 == 1) {
          local_4d0 = 0x3c;
        }
        else {
          iVar3 = tq::RandGet(7);
          local_4d0 = iVar3 * 100 + 0x168;
        }
        uVar9 = 4;
        uVar14 = 3;
        uVar13 = 1;
        uVar12 = 2;
      }
      else if (uVar10 == 100) {
        uVar14 = 0;
        uVar9 = 3;
        uVar13 = 2;
        uVar12 = 5;
      }
      else if (uVar10 == 0x50) {
        uVar9 = 3;
        uVar14 = 5;
        uVar13 = 2;
        uVar12 = 0;
      }
      else if (uVar10 == 0x46) {
        uVar9 = 3;
        uVar14 = 4;
        uVar13 = 3;
        uVar12 = 0;
      }
      else if (uVar10 == 0x32) {
        uVar9 = 1;
        uVar14 = 1;
        uVar13 = 8;
        uVar12 = 0;
      }
      else if (uVar10 == 0x28) {
        uVar9 = 1;
        uVar14 = 2;
        uVar12 = 0;
      }
      else if (uVar10 == 10) {
        uVar9 = 3;
        uVar14 = 5;
        uVar13 = 2;
        uVar12 = 0;
      }
      else {
        uVar10 = 0x14;
        local_4d8 = 0x14;
        uVar9 = 3;
        uVar14 = 5;
        uVar13 = 2;
        uVar12 = 0;
      }
      local_4cc = (uVar12 + uVar9 * 8 + uVar13 + uVar14) * 3;
      iVar3 = (param_6 / 1000) % 10;
      if (iVar3 == 1) {
        if (uVar10 == 0x32) {
          iVar3 = tq::RandGet(5);
          param_6 = param_6 + (iVar3 + (0x67 - param_6 / 10000)) * 10000;
        }
        else if (uVar10 == 0x3c) {
          iVar3 = tq::RandGet(0x14);
          param_6 = param_6 + (iVar3 + (0x6d - param_6 / 10000)) * 10000;
        }
        else if (uVar10 == 0x46) {
          iVar3 = tq::RandGet(5);
          param_6 = param_6 + (iVar3 + (0x9a - param_6 / 10000)) * 10000;
        }
        else if (uVar10 == 0x50) {
          iVar3 = tq::RandGet(5);
          param_6 = param_6 + (iVar3 + (0xa4 - param_6 / 10000)) * 10000;
        }
        else {
          iVar3 = tq::RandGet(0x66);
          param_6 = param_6 + 10000 + (iVar3 - param_6 / 10000) * 10000;
        }
      }
      else if (iVar3 == 2) {
        if (uVar10 == 0x32) {
          iVar3 = tq::RandGet(5);
          param_6 = param_6 + (iVar3 + (0x123 - param_6 / 10000)) * 10000;
        }
        else if (uVar10 == 0x3c) {
          iVar3 = tq::RandGet(0x14);
          param_6 = param_6 + (iVar3 + (300 - param_6 / 10000)) * 10000;
        }
        else if (uVar10 == 0x46) {
          iVar3 = tq::RandGet(5);
          param_6 = param_6 + (iVar3 + (0x159 - param_6 / 10000)) * 10000;
        }
        else if (uVar10 == 0x50) {
          iVar3 = tq::RandGet(5);
          param_6 = param_6 + (iVar3 + (0x163 - param_6 / 10000)) * 10000;
        }
        else {
          iVar3 = tq::RandGet(0x5a);
          param_6 = param_6 + (iVar3 + (0xc9 - param_6 / 10000)) * 10000;
        }
      }
      else {
        param_6 = param_6 + (param_6 / 1000) * -1000 + 1000;
        param_6 = param_6 + (param_6 / 10000) * -10000 + 10000;
      }
      local_4c0 = DAT_140975af8;
      if (DAT_140975af8 == 0) {
        local_568 = CONCAT44(local_568._4_4_,0x128);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      local_4c0 = DAT_140975af8;
      if (DAT_140975af8 == 0) {
        local_568 = CONCAT44(local_568._4_4_,0x369);
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar2 = 0;
      }
      else {
        cVar1 = FUN_140056a60(DAT_140975af8);
        local_4f8 = 0;
        if (cVar1 != '\0') {
          local_4f8 = 0xff;
        }
        local_448 = '\0';
        memset(local_447,0,0x3ff);
        local_498 = 0;
        local_497 = 0;
        local_48f = 0;
        local_487 = 0;
        local_47f = 0;
        local_477 = 0;
        local_46f = 0;
        local_467 = 0;
        local_45f = 0;
        local_457 = 0;
        local_44f = 0;
        cVar1 = FUN_140056910(local_4c0,param_8,&local_498);
        if (cVar1 == '\0') {
          local_568 = CONCAT44(local_568._4_4_,0x376);
          log_InlineLogERROR(
                            "CUserList::CreateNewPlayer, idAccount[%lu] szName[%s] can not find channel_account at %s, %d"
                            );
          uVar2 = 0;
        }
        else {
          local_44f = 0;
          if (DAT_140975c00 == '\0') {
            local_4f0 = &local_498;
            local_528 = (uint)local_4d4;
            local_530 = (uint)local_4d2;
            local_538 = 0x3ea;
            local_540 = 100;
            local_548 = uVar12 * 5;
            local_550 = local_4cc;
            local_558 = local_4d0;
            local_560 = CONCAT44(local_560._4_4_,param_6);
            local_568 = local_4c8;
            local_520 = uVar14;
            local_518 = uVar13;
            local_510 = uVar9;
            local_508 = uVar12;
            local_500 = uVar10;
            _snprintf(&local_448,0x400,
                      "INSERT cq_user SET account_id=%u,name=\'%s\',lookface=%d,hair=%d,life=%d,mana=%d,money=%u,recordmap_id=%u, recordx=%u, recordy=%u,strength=%d,speed=%d,health=%d,soul=%d,profession=%d,business=%d,channel_account=\'%s\'"
                     );
          }
          else {
            local_4e8 = &local_498;
            local_4f0 = (undefined1 *)CONCAT44(local_4f0._4_4_,local_4f8);
            local_520 = (uint)local_4d4;
            local_528 = (uint)local_4d2;
            local_530 = 0x3ea;
            local_538 = 100;
            local_540 = uVar12 * 5;
            local_548 = local_4cc;
            local_550 = local_4d0;
            local_560 = local_4b0;
            local_568 = local_4c8;
            local_558 = param_6;
            local_518 = uVar14;
            local_510 = uVar13;
            local_508 = uVar9;
            local_500 = uVar12;
            local_4f8 = uVar10;
            _snprintf(&local_448,0x400,
                      "INSERT cq_user SET account_id=%u,name=\'%s\',lastname=\'%s\',lookface=%d,hair=%d,life=%d,mana=%d,money=%u,recordmap_id=%u, recordx=%u, recordy=%u,strength=%d,speed=%d,health=%d,soul=%d,profession=%d,business=%d,channel_account=\'%s\'"
                     );
          }
          local_49 = 0;
          if (DAT_140975af8 == 0) {
            local_568 = CONCAT44(local_568._4_4_,0x128);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar8 = (longlong *)InstanceGet(DAT_140975af8);
          cVar1 = (**(code **)(*plVar8 + 0x30))(plVar8,&local_448,1);
          uVar2 = 0;
          if (cVar1 != '\0') {
            if (DAT_140975af8 == 0) {
              local_568 = CONCAT44(local_568._4_4_,0x128);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            plVar8 = (longlong *)InstanceGet(DAT_140975af8);
            uVar5 = (**(code **)(*plVar8 + 0x18))(plVar8);
            uVar6 = FUN_1400673a0();
            FUN_1400799a0(uVar6,uVar5,uVar10);
            uVar2 = 1;
          }
        }
      }
    }
  }
  return uVar2;
}

// ==== CMsgRegister@world_kernel::helper_1400799a0  @1400799a0  [medium:callgraph-r1]  (orig: FUN_1400799a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400799a0(longlong param_1,int param_2,undefined4 param_3)

{
  longlong *plVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong lVar11;
  undefined1 auStack_4e8 [32];
  int local_4c8;
  int local_4c0;
  int local_4b8;
  int local_4b0;
  int local_4a8;
  int local_4a0;
  int local_498;
  undefined4 local_488;
  int local_484;
  undefined4 local_480;
  int local_47c;
  longlong *local_478;
  longlong local_470;
  longlong *local_468;
  undefined8 local_458;
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_458 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  local_480 = param_3;
  local_47c = param_2;
  FUN_1400795e0((longlong *)(param_1 + 8),&local_478,&local_480);
  lVar10 = *(longlong *)(param_1 + 0x38);
  lVar11 = 0;
  local_468 = *(longlong **)(param_1 + 8);
  if ((local_478 == (longlong *)0x0) || (local_478 != local_468)) {
    _invalid_parameter_noinfo();
  }
  if (local_470 == lVar10) {
    log_InlineLogERROR(
                      "CNewbieInfo::CreateNewbieItem, can not find profession: %d, for create user: %u"
                      );
    uVar8 = 0;
  }
  else {
    if (local_478 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar11 = *local_478;
    }
    if (local_470 == *(longlong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(local_470 + 0x20);
    if (plVar1 == (longlong *)0x0) {
      local_4c8 = 0x6f;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar8 = 0;
    }
    else if (DAT_140975b60 == (longlong *)0x0) {
      local_4c8 = 0x72;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar8 = 0;
    }
    else {
      local_448 = '\0';
      memset(local_447,0,0x3ff);
      local_484 = 2;
      while (iVar2 = local_484, local_484 < 9) {
        plVar9 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,local_484);
        iVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
        if ((iVar4 != 0) &&
           (lVar10 = (**(code **)(*DAT_140975b60 + 0x70))(DAT_140975b60,iVar4), lVar10 != 0)) {
          iVar7 = 0;
          local_488 = 0;
          switch(iVar2) {
          case 2:
            iVar7 = 5;
            local_488 = 5;
            break;
          case 3:
            iVar7 = 4;
            local_488 = 4;
            break;
          case 4:
            iVar7 = 1;
            local_488 = 1;
            break;
          case 5:
            iVar7 = 8;
            local_488 = 8;
            break;
          case 6:
            iVar7 = 2;
            local_488 = 2;
            break;
          case 7:
            iVar7 = 6;
            local_488 = 6;
            break;
          case 8:
            iVar7 = 3;
            local_488 = 3;
          }
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))
                             (*(longlong **)(lVar10 + 8),0x15);
          iVar5 = (**(code **)(*plVar9 + 0x48))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))
                             (*(longlong **)(lVar10 + 8),0x16);
          iVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
          memset(&local_448,0,0x400);
          if (iVar2 == 8) {
            local_4a0 = tq::RandGet(7);
            local_4a0 = local_4a0 + 3;
            local_4c8 = param_2;
            local_4c0 = param_2;
            local_4b8 = iVar5;
            local_4b0 = iVar6;
            local_4a8 = iVar7;
            _snprintf(&local_448,0x400,
                      "INSERT cq_item SET type=%u,owner_id=%u,player_id=%u,amount=%d,amount_limit=%d,position=%d,color=%d, accumulate_num = 1"
                     );
          }
          else {
            local_4c8 = param_2;
            local_4c0 = param_2;
            local_4b8 = iVar5;
            local_4b0 = iVar6;
            local_4a8 = iVar7;
            _snprintf(&local_448,0x400,
                      "INSERT cq_item SET type=%u,owner_id=%u,player_id=%u,amount=%d,amount_limit=%d,position=%d, accumulate_num = 1"
                     );
          }
          local_49 = 0;
          if (DAT_140975af8 == 0) {
            local_4c8 = 0x128;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar9 = (longlong *)InstanceGet(DAT_140975af8);
          cVar3 = (**(code **)(*plVar9 + 0x30))(plVar9,&local_448,1);
          if (cVar3 == '\0') {
            log_InlineLogERROR(
                              "CNewbieInfo::CreateNewbieItem, failed in creating equipment(type:%d) for user(%u)"
                              );
          }
          else {
            if (DAT_140975af8 == 0) {
              local_4c8 = 0x128;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            plVar9 = (longlong *)InstanceGet(DAT_140975af8);
            iVar7 = (**(code **)(*plVar9 + 0x18))(plVar9);
            local_498 = 0;
            local_4a0 = 0;
            local_4a8 = 0;
            local_4b0 = 0;
            local_4b8 = 0;
            local_4c0 = 0;
            local_4c8 = 0;
            FUN_1400fe140(iVar7,param_2,iVar4,0);
            memset(&local_448,0,0x400);
            local_4c8 = iVar7;
            _snprintf(&local_448,0x400,"UPDATE cq_item SET chk_sum=%u WHERE id=%u LIMIT 1");
            local_49 = 0;
            if (DAT_140975af8 == 0) {
              local_4c8 = 0x128;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            plVar9 = (longlong *)InstanceGet(DAT_140975af8);
            (**(code **)(*plVar9 + 0x30))(plVar9,&local_448,0,1);
          }
        }
        local_484 = iVar2 + 1;
      }
      local_484 = 9;
      while (iVar2 = local_484, local_484 < 0x1c) {
        plVar9 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,local_484);
        iVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
        if ((iVar4 != 0) &&
           (lVar10 = (**(code **)(*DAT_140975b60 + 0x70))(DAT_140975b60,iVar4), lVar10 != 0)) {
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))
                             (*(longlong **)(lVar10 + 8),0x15);
          iVar7 = (**(code **)(*plVar9 + 0x48))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))
                             (*(longlong **)(lVar10 + 8),0x16);
          iVar5 = (**(code **)(*plVar9 + 0x48))(plVar9);
          memset(&local_448,0,0x400);
          local_4c8 = param_2;
          local_4c0 = param_2;
          local_4b8 = iVar7;
          local_4b0 = iVar5;
          _snprintf(&local_448,0x400,
                    "INSERT cq_item SET type=%u,owner_id=%u,player_id=%u,amount=%d,amount_limit=%d, accumulate_num = 1"
                   );
          local_49 = 0;
          if (DAT_140975af8 == 0) {
            local_4c8 = 0x128;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar9 = (longlong *)InstanceGet(DAT_140975af8);
          cVar3 = (**(code **)(*plVar9 + 0x30))(plVar9,&local_448,1);
          if (cVar3 == '\0') {
            log_InlineLogERROR(
                              "CNewbieInfo::CreateNewbieItem, failed in creating item(type:%d) for user(%u)"
                              );
          }
          else {
            if (DAT_140975af8 == 0) {
              local_4c8 = 0x128;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            plVar9 = (longlong *)InstanceGet(DAT_140975af8);
            iVar7 = (**(code **)(*plVar9 + 0x18))(plVar9);
            local_4c8 = 0;
            local_4c0 = local_4c8;
            local_4b8 = local_4c8;
            local_4b0 = local_4c8;
            local_4a8 = local_4c8;
            local_4a0 = local_4c8;
            local_498 = local_4c8;
            FUN_1400fe140(iVar7,param_2,iVar4,0);
            plVar9 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,iVar2 + 1);
            iVar5 = (**(code **)(*plVar9 + 0x48))(plVar9);
            if ((0 < iVar5) && (cVar3 = FUN_140102780(iVar4), cVar3 != '\0')) {
              memset(&local_448,0,0x400);
              local_4c8 = iVar7;
              _snprintf(&local_448,0x400,"UPDATE cq_item SET accumulate_num=%d WHERE id=%u LIMIT 1")
              ;
              local_49 = 0;
              if (DAT_140975af8 == 0) {
                local_4c8 = 0x128;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              plVar9 = (longlong *)InstanceGet(DAT_140975af8);
              (**(code **)(*plVar9 + 0x30))(plVar9,&local_448,0,1);
            }
            memset(&local_448,0,0x400);
            local_4c8 = iVar7;
            _snprintf(&local_448,0x400,"UPDATE cq_item SET chk_sum=%u WHERE id=%u LIMIT 1");
            local_49 = 0;
            if (DAT_140975af8 == 0) {
              local_4c8 = 0x128;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            plVar9 = (longlong *)InstanceGet(DAT_140975af8);
            (**(code **)(*plVar9 + 0x30))(plVar9,&local_448,0,1);
          }
        }
        local_484 = iVar2 + 2;
      }
      local_484 = 0x1d;
      while (iVar2 = local_484, local_484 < 0x21) {
        plVar9 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,local_484);
        iVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
        if (iVar4 != 0) {
          memset(&local_448,0,0x400);
          local_4c8 = iVar4;
          _snprintf(&local_448,0x400,"INSERT cq_magic SET ownerid=%u, type=%u");
          local_49 = 0;
          if (DAT_140975af8 == 0) {
            local_4c8 = 0x128;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar9 = (longlong *)InstanceGet(DAT_140975af8);
          (**(code **)(*plVar9 + 0x30))(plVar9,&local_448,0,1);
        }
        local_484 = iVar2 + 1;
      }
      uVar8 = 1;
    }
  }
  return uVar8;
}

// ==== CMsgRegister@world_kernel::vfunc_1  @1400836b0  [high:rtti-vtable]  (orig: FUN_1400836b0)
ulonglong FUN_1400836b0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3e9);
}

// ==== CMsgRegister@world_kernel::vfunc_3  @1400836e0  [high:rtti-vtable]  (orig: FUN_1400836e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400836e0(longlong *param_1)

{
  ushort uVar1;
  ushort uVar2;
  undefined4 uVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  undefined8 uVar7;
  IStringManager *pIVar8;
  longlong lVar9;
  ulonglong uVar10;
  char *pcVar11;
  undefined1 auStack_4e8 [32];
  longlong local_4c8;
  uint local_4c0;
  uint local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined4 local_488;
  undefined8 local_480;
  undefined1 local_478 [1088];
  ulonglong local_38;
  
  local_480 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  uVar3 = *(undefined4 *)((longlong)param_1 + 0x414);
  if (DAT_140975af8 == 0) {
    local_4c8 = CONCAT44(local_4c8._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  iVar6 = FUN_14005cf90(DAT_140975af8,uVar3);
  uVar3 = *(undefined4 *)((longlong)param_1 + 0x414);
  if (DAT_140975af8 == 0) {
    local_4c8 = CONCAT44(local_4c8._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  local_488 = FUN_14005ce90(DAT_140975af8,uVar3);
  piVar4 = (int *)param_1[0x84];
  if (*piVar4 == 1) {
    uVar3 = *(undefined4 *)((longlong)param_1 + 0x414);
    if (DAT_140975af8 == 0) {
      local_4c8 = CONCAT44(local_4c8._4_4_,0x128);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_14005f600(DAT_140975af8,uVar3);
    uVar3 = *(undefined4 *)((longlong)param_1 + 0x414);
    uVar7 = FUN_140054e10();
    FUN_1400674b0(uVar7,uVar3,iVar6);
    return;
  }
  if (piVar4[0x12] != iVar6) {
    if (iVar6 == 0) {
      return;
    }
    local_4c8 = CONCAT44(local_4c8._4_4_,0x38);
    log_InlineLogWARNING("CMsgRegister Account[%u] unequal to right Account[%u] at %s, %d");
    return;
  }
  iVar6 = tq::StringCheck((char *)(piVar4 + 1),0);
  if (iVar6 == 0) {
    FUN_14007a560(local_478);
    pIVar8 = theInstance();
    uVar7 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_ERROR_ILLEGAL_ACCOUNT");
    local_498 = 1;
    local_4a0 = 0;
    local_4a8 = 0;
    local_4b0 = (uint)local_4b0._2_2_ << 0x10;
    local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
    local_4c0 = 0xffffff;
    local_4c8 = 0;
    iVar6 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
    if (iVar6 != 0) {
      (**(code **)(*param_1 + 0x20))(param_1,local_478);
    }
    FUN_14007a5e0(local_478);
    return;
  }
  iVar6 = tq::StringCheck((char *)(param_1[0x84] + 0x34),0);
  if (iVar6 == 0) {
    FUN_14007a560(local_478);
    pIVar8 = theInstance();
    uVar7 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_ERROR_ILLEGAL_PASSWORD");
    local_498 = 1;
    local_4a0 = 0;
    local_4a8 = 0;
    local_4b0 = (uint)local_4b0._2_2_ << 0x10;
    local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
    local_4c0 = 0xffffff;
    local_4c8 = 0;
    iVar6 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
    if (iVar6 != 0) {
      (**(code **)(*param_1 + 0x20))(param_1,local_478);
    }
    FUN_14007a5e0(local_478);
    return;
  }
  uVar10 = 0xffffffffffffffff;
  pcVar11 = (char *)(param_1[0x84] + 0x14);
  do {
    if (uVar10 == 0) break;
    uVar10 = uVar10 - 1;
    cVar5 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar5 != '\0');
  if ((~uVar10 - 1 < 0x10) &&
     (iVar6 = tq::NameStrCheck((char *)(param_1[0x84] + 0x14),false), iVar6 != 0)) {
    lVar9 = param_1[0x84];
    uVar7 = FUN_140054dc0();
    cVar5 = FUN_140056730(uVar7,lVar9 + 0x14);
    if (cVar5 == '\0') {
      if (DAT_140975c00 != '\0') {
        iVar6 = tq::NameStrCheck((char *)(param_1[0x84] + 0x24),false);
        if (iVar6 != 0) {
          lVar9 = param_1[0x84];
          uVar7 = FUN_140054dc0();
          cVar5 = FUN_140056730(uVar7,lVar9 + 0x24);
          if (cVar5 == '\0') goto LAB_140083ac1;
        }
        FUN_14007a560(local_478);
        pIVar8 = theInstance();
        uVar7 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_ERROR_ILLEGAL_NAME");
        local_498 = 1;
        local_4a0 = 0;
        local_4a8 = 0;
        local_4b0 = (uint)local_4b0._2_2_ << 0x10;
        local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
        local_4c0 = 0xffffff;
        local_4c8 = 0;
        iVar6 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
        if (iVar6 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,local_478);
        }
        FUN_14007a5e0(local_478);
        return;
      }
LAB_140083ac1:
      lVar9 = param_1[0x84];
      uVar1 = *(ushort *)(lVar9 + 0x46);
      uVar2 = *(ushort *)(lVar9 + 0x44);
      uVar7 = FUN_140054e10();
      local_4a8 = local_488;
      local_4b0 = *(uint *)(lVar9 + 0x48);
      local_4b8 = (uint)uVar1;
      local_4c0 = (uint)uVar2;
      local_4c8 = lVar9 + 0x34;
      cVar5 = FUN_140068c80(uVar7,lVar9 + 4,lVar9 + 0x14,lVar9 + 0x24);
      if (cVar5 == '\0') {
        FUN_14007a560(local_478);
        pIVar8 = theInstance();
        uVar7 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_ERROR_DUPLICATE_NAME");
        local_498 = 1;
        local_4a0 = 0;
        local_4a8 = 0;
        local_4b0 = local_4b0 & 0xffff0000;
        local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
        local_4c0 = 0xffffff;
        local_4c8 = 0;
        iVar6 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
        if (iVar6 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,local_478);
        }
        FUN_14007a5e0(local_478);
        return;
      }
      FUN_14007a560(local_478);
      local_498 = 1;
      local_4a0 = 0;
      local_4a8 = 0;
      local_4b0 = local_4b0 & 0xffff0000;
      local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
      local_4c0 = 0xffffff;
      local_4c8 = 0;
      iVar6 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS","ANSWER_OK");
      if (iVar6 != 0) {
        (**(code **)(*param_1 + 0x20))(param_1,local_478);
      }
      if (param_1[0x84] != -0x4c) {
        lVar9 = FUN_140054dc0();
        if (lVar9 == 0) {
          FUN_14007a5e0(local_478);
          return;
        }
        FUN_140055a90(lVar9,*(undefined4 *)(param_1[0x84] + 0x48),param_1[0x84] + 0x4c);
      }
      lVar9 = param_1[0x84];
      uVar7 = FUN_140054dc0();
      FUN_1400568e0(uVar7,*(undefined4 *)(lVar9 + 0x48),1);
      FUN_14007a5e0(local_478);
      return;
    }
  }
  FUN_14007a560(local_478);
  pIVar8 = theInstance();
  uVar7 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_ERROR_ILLEGAL_NAME");
  local_498 = 1;
  local_4a0 = 0;
  local_4a8 = 0;
  local_4b0 = (uint)local_4b0._2_2_ << 0x10;
  local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
  local_4c0 = 0xffffff;
  local_4c8 = 0;
  iVar6 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
  if (iVar6 != 0) {
    (**(code **)(*param_1 + 0x20))(param_1,local_478);
  }
  FUN_14007a5e0(local_478);
  return;
}

// ==== CMsgRegister@world_kernel::vfunc_0  @140083d20  [high:rtti-vtable]  (orig: FUN_140083d20)
undefined8 * FUN_140083d20(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgRegister::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

