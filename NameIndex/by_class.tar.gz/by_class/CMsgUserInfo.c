// ==== CMsgUserInfo::ctor_or_dtor  @14044df40  [high:vtable-assign]  (orig: FUN_14044df40)
undefined8 * FUN_14044df40(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgUserInfo::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x8e),0x382,true);
  return param_1;
}

// ==== CMsgUserInfo::ctor_or_dtor  @14044dfc0  [high:vtable-assign]  (orig: FUN_14044dfc0)
void FUN_14044dfc0(undefined8 *param_1)

{
  *param_1 = CMsgUserInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgUserInfo::vfunc_1  @14044e000  [high:rtti-vtable]  (orig: FUN_14044e000)
ulonglong FUN_14044e000(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3ee);
}

// ==== CMsgUserInfo::vfunc_3  @14044e360  [high:rtti-vtable]  (orig: FUN_14044e360)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14044e360(void)

{
  undefined1 auStack_48 [32];
  undefined4 local_28;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_48;
  local_28 = 0x72;
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgUserInfo::ctor_or_dtor  @14044e3b0  [high:vtable-assign]  (orig: FUN_14044e3b0)
undefined8 * FUN_14044e3b0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgUserInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

