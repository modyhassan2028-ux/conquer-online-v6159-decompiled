// ==== CDeathMarkedMgr::helper_1402347f0  @1402347f0  [medium:callgraph-r3]  (orig: FUN_1402347f0)
void FUN_1402347f0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x61) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CDeathMarkedMgr::helper_140235150  @140235150  [medium:callgraph-r3]  (orig: FUN_140235150)
void FUN_140235150(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x61) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x61) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x61);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x61);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x61);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x61);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140235174. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CDeathMarkedMgr::helper_140235330  @140235330  [medium:callgraph-r3]  (orig: FUN_140235330)
void FUN_140235330(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x61) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CDeathMarkedMgr::helper_140235a80  @140235a80  [medium:callgraph-r1]  (orig: FUN_140235a80)
void FUN_140235a80(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x68);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 0xc) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x61) = 0;
  return;
}

// ==== CDeathMarkedMgr::helper_140239830  @140239830  [medium:callgraph-r2]  (orig: FUN_140239830)
undefined8 * FUN_140239830(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong local_b8;
  undefined8 uStack_b0;
  longlong local_a8;
  undefined8 *puStack_a0;
  undefined8 local_98;
  undefined **local_90 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_78 [40];
  undefined1 local_50 [16];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  local_98 = 0xfffffffffffffffe;
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x61) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_90);
    local_90[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_78,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_90[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_90,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140235150(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x61) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0xc;
        plVar8 = plVar8 + 0xc;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_140239a1d;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x61);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x61);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x61);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x61);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_140239a1d:
  if ((char)plVar2[0xc] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0xc] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0xc] == '\0') {
            *(undefined1 *)(plVar9 + 0xc) = 1;
            *(undefined1 *)(plVar8 + 0xc) = 0;
            FUN_140235330(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
            if ((*(char *)(*plVar9 + 0x60) != '\x01') || (*(char *)(plVar9[2] + 0x60) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x60) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x60) = 1;
                *(undefined1 *)(plVar9 + 0xc) = 0;
                FUN_1402347f0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0xc) = (char)plVar8[0xc];
              *(undefined1 *)(plVar8 + 0xc) = 1;
              *(undefined1 *)(plVar9[2] + 0x60) = 1;
              FUN_140235330(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xc) = 0;
          }
        }
        else {
          if ((char)plVar9[0xc] == '\0') {
            *(undefined1 *)(plVar9 + 0xc) = 1;
            *(undefined1 *)(plVar8 + 0xc) = 0;
            FUN_1402347f0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
            if ((*(char *)(plVar9[2] + 0x60) != '\x01') || (*(char *)(*plVar9 + 0x60) != '\x01')) {
              if (*(char *)(*plVar9 + 0x60) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x60) = 1;
                *(undefined1 *)(plVar9 + 0xc) = 0;
                FUN_140235330(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0xc) = (char)plVar8[0xc];
              *(undefined1 *)(plVar8 + 0xc) = 1;
              *(undefined1 *)(*plVar9 + 0x60) = 1;
              FUN_1402347f0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xc) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0xc) = 1;
  }
  plVar9 = plVar2 + 4;
  puStack_a0 = (undefined8 *)plVar2[10];
  local_b8 = *plVar9;
  uStack_b0 = *puStack_a0;
  local_a8 = local_b8;
  FUN_140236ff0(plVar9,local_50,&local_b8,&local_a8);
  operator_delete((void *)plVar2[10]);
  plVar2[10] = 0;
  plVar2[0xb] = 0;
  operator_delete((void *)*plVar9);
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CDeathMarkedMgr::helper_140239c70  @140239c70  [medium:callgraph-r2]  (orig: FUN_140239c70)
void FUN_140239c70(undefined8 param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined1 local_18 [16];
  
  uVar5 = 0xfffffffffffffffe;
  cVar2 = *(char *)((longlong)param_2 + 0x61);
  while (cVar2 == '\0') {
    FUN_140239c70(param_1,param_2[2]);
    plVar3 = (longlong *)*param_2;
    plVar1 = param_2 + 4;
    puVar4 = (undefined8 *)param_2[10];
    local_58 = (undefined4)*plVar1;
    uStack_54 = (undefined4)((ulonglong)*plVar1 >> 0x20);
    uStack_50 = SUB84(puVar4,0);
    uStack_4c = (undefined4)((ulonglong)puVar4 >> 0x20);
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    uStack_40 = (undefined4)*puVar4;
    uStack_3c = (undefined4)((ulonglong)*puVar4 >> 0x20);
    local_28 = local_58;
    uStack_24 = uStack_54;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    FUN_140236ff0(plVar1,local_18,&local_28,&local_38,uVar5);
    operator_delete((void *)param_2[10]);
    param_2[10] = 0;
    param_2[0xb] = 0;
    operator_delete((void *)*plVar1);
    operator_delete(param_2);
    param_2 = plVar3;
    cVar2 = *(char *)((longlong)plVar3 + 0x61);
  }
  return;
}

// ==== CDeathMarkedMgr::helper_14023a340  @14023a340  [medium:callgraph-r1]  (orig: FUN_14023a340)
longlong * FUN_14023a340(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140239c70(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x61) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x61) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x61);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x61);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x61);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x61);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140239830(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CDeathMarkedMgr::helper_14023a520  @14023a520  [medium:callgraph-r0]  (orig: FUN_14023a520)
void FUN_14023a520(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14023a340((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CDeathMarkedMgr::ctor_or_dtor  @14023ae70  [high:vtable-assign]  (orig: FUN_14023ae70)
void FUN_14023ae70(undefined8 *param_1)

{
  *param_1 = CDeathMarkedMgr::vftable;
  FUN_14023a520(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_14023a520(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CDeathMarkedMgr::helper_14023b740  @14023b740  [medium:callgraph-r0]  (orig: FUN_14023b740)
undefined8 * FUN_14023b740(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140235a80(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x61) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CDeathMarkedMgr::ctor_or_dtor  @14023b7c0  [high:vtable-assign]  (orig: FUN_14023b7c0)
undefined8 * FUN_14023b7c0(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CDeathMarkedMgr::vftable;
  FUN_14023b740(param_1 + 1);
  FUN_14023b740(param_1 + 9);
  *(undefined4 *)(param_1 + 0x11) = param_2;
  return param_1;
}

// ==== CDeathMarkedMgr::ctor_or_dtor  @14023b810  [high:vtable-assign]  (orig: FUN_14023b810)
undefined8 * FUN_14023b810(undefined8 *param_1,uint param_2)

{
  *param_1 = CDeathMarkedMgr::vftable;
  FUN_14023a520(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_14023a520(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CDeathMarkedMgr::ctor_or_dtor  @14023b8a0  [high:vtable-assign]  (orig: FUN_14023b8a0)
undefined8 * FUN_14023b8a0(undefined4 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x90);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CDeathMarkedMgr::vftable;
    FUN_14023b740(puVar1 + 1);
    FUN_14023b740(puVar1 + 9);
    *(undefined4 *)(puVar1 + 0x11) = param_1;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

