// ==== CCrossMsgSetUserEnterOSID::ctor_or_dtor  @1400f7f70  [high:vtable-assign]  (orig: FUN_1400f7f70)
undefined8 * FUN_1400f7f70(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgSetUserEnterOSID::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgSetUserEnterOSID::ctor_or_dtor  @1400f7fc0  [high:vtable-assign]  (orig: FUN_1400f7fc0)
void FUN_1400f7fc0(undefined8 *param_1)

{
  *param_1 = CCrossMsgSetUserEnterOSID::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgSetUserEnterOSID::vfunc_1  @1400f7ff0  [high:rtti-vtable]  (orig: FUN_1400f7ff0)
undefined8 FUN_1400f7ff0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgSetUserEnterOSID::ctor_or_dtor  @1400f8100  [high:vtable-assign]  (orig: FUN_1400f8100)
undefined8 * FUN_1400f8100(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgSetUserEnterOSID::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgSetUserEnterOSID::vfunc_3  @1400f8150  [high:rtti-vtable]  (orig: FUN_1400f8150)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400f8150(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (*(longlong *)(param_1 + 0x428) == 0) {
    local_468 = 0x34;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0x90) == 0) {
      local_468 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x98))
                       (*(longlong **)(lVar4 + 0x90),*(undefined4 *)(param_1 + 0x420));
    if ((plVar5 != (longlong *)0x0) && ((char)plVar5[0x259] != '\0')) {
      cVar1 = **(char **)(param_1 + 0x428);
      if (cVar1 != '\x01') {
        if (cVar1 == '\x02') {
          FUN_140168a30(plVar5,0);
          FUN_140368e20(local_448);
          uVar2 = FUN_140168a20(plVar5);
          uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
          cVar1 = FUN_140368ed0(local_448,2,uVar3,uVar2);
          if (cVar1 != '\0') {
            (**(code **)(*plVar5 + 0x130))(plVar5,local_448);
          }
          FUN_140368e70(local_448);
          return;
        }
        if (cVar1 != '\x03') {
          return;
        }
      }
      FUN_140168a30(plVar5,*(undefined4 *)(*(char **)(param_1 + 0x428) + 4));
      FUN_140368e20(local_448);
      uVar2 = FUN_140168a20(plVar5);
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      cVar1 = FUN_140368ed0(local_448,5,uVar3,uVar2);
      if (cVar1 != '\0') {
        (**(code **)(*plVar5 + 0x130))(plVar5,local_448);
      }
      FUN_140368e70(local_448);
    }
  }
  return;
}

// ==== CCrossMsgSetUserEnterOSID::helper_140168a30  @140168a30  [medium:callgraph-r0]  (orig: FUN_140168a30)
void FUN_140168a30(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1304) = param_2;
  return;
}

// ==== CCrossMsgSetUserEnterOSID::vfunc_2  @1402b5630  [high:rtti-vtable]  (orig: FUN_1402b5630)
bool FUN_1402b5630(longlong param_1)

{
  return *(int *)(param_1 + 8) != 0;
}

// ==== CCrossMsgSetUserEnterOSID::vfunc_4  @1402ba250  [high:rtti-vtable]  (orig: FUN_1402ba250)
void FUN_1402ba250(longlong param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  
  if (*(int *)(param_1 + 0x414) == -1) {
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                    /* WARNING: Could not recover jumptable at 0x0001402ba2fe. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar2 + 0x30))(plVar2,*(undefined4 *)(param_1 + 0x418),param_2);
    return;
  }
  if ((*(int *)(param_1 + 0x420) == 0) && (*(int *)(param_1 + 0x41c) == 0)) {
    puVar1 = (undefined8 *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                    /* WARNING: Could not recover jumptable at 0x0001402ba29f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)*puVar1)(puVar1,*(undefined4 *)(param_1 + 0x414),param_2);
    return;
  }
  plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  (**(code **)(*plVar2 + 0x28))
            (plVar2,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c),param_2,3);
  return;
}

