// ==== CCrossMsgAdditionBattleEffect::helper_140194bc0  @140194bc0  [medium:callgraph-r0]  (orig: FUN_140194bc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140194bc0(longlong *param_1,short param_2,int param_3,longlong param_4)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  int *piVar8;
  int iVar9;
  undefined1 auStack_d08 [32];
  int local_ce8;
  undefined8 local_ce0;
  undefined1 local_cd8 [1072];
  undefined1 local_8a8 [1072];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_ce0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_d08;
  local_ce8 = param_3;
  uVar1 = (**(code **)(*param_1 + 8))();
  if ((0xee69a15e < uVar1) && (*(int *)((longlong)param_1 + 0x12fc) != 0)) {
    lVar5 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    if (lVar5 != 0) {
      lVar5 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
      plVar6 = *(longlong **)(*(longlong *)(lVar5 + 0x58) + 8);
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
      uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
      if ((uVar7 >> 0x1f & 1) != 0) {
        iVar9 = 0;
        if (param_3 < 1) {
          return;
        }
        piVar8 = (int *)(param_4 + 4);
        do {
          iVar3 = piVar8[-1];
          if (iVar3 == 2) {
            FUN_14039e680(local_8a8);
            iVar3 = *piVar8;
            uVar2 = (**(code **)(*param_1 + 8))(param_1);
            iVar3 = FUN_14039e700(local_8a8,uVar2,0x24,(longlong)iVar3);
            if (iVar3 != 0) {
              FUN_14039e9a0(local_8a8,0x24);
              (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_8a8);
            }
            FUN_14039e6d0(local_8a8);
          }
          else if (iVar3 == 3) {
            FUN_14039e680(local_478);
            iVar3 = *piVar8;
            uVar2 = (**(code **)(*param_1 + 8))(param_1);
            iVar3 = FUN_14039e700(local_478,uVar2,0x2c,(longlong)iVar3);
            if (iVar3 != 0) {
              (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
            }
            FUN_14039e6d0(local_478);
          }
          else if (iVar3 == 4) {
            plVar6 = (longlong *)CurrentInstanceGet();
            if ((plVar6 != (longlong *)0x0) &&
               (plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0xb),
               plVar6 != (longlong *)0x0)) {
              lVar5 = *plVar6;
              uVar2 = (**(code **)(*param_1 + 8))(param_1);
              (**(code **)(lVar5 + 0x40))(plVar6,uVar2,*piVar8);
            }
          }
          else if (iVar3 == 5) {
            FUN_14039e680(local_cd8);
            uVar2 = (**(code **)(*param_1 + 8))(param_1);
            iVar3 = FUN_14039e700(local_cd8,uVar2,0x2a);
            if (iVar3 != 0) {
              FUN_14039e9a0(local_cd8,0x2a,(longlong)*piVar8);
              (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_cd8);
            }
            FUN_14039e6d0(local_cd8);
          }
          else {
            log_InlineLogDBERROR
                      (
                      "CUser::UpdateAdditionBattleEffectFromGS. CROSS_ADDITIONBATTLEEFFECT[%d][%d] is Error"
                      );
          }
          iVar9 = iVar9 + 1;
          piVar8 = piVar8 + 2;
        } while (iVar9 < param_3);
        return;
      }
    }
    iVar9 = 0;
    if (0 < local_ce8) {
      piVar8 = (int *)(param_4 + 4);
      do {
        iVar3 = piVar8[-1];
        if (iVar3 == 2) {
          iVar3 = *piVar8;
          iVar4 = (**(code **)(param_1[2] + 0x1a8))(param_1 + 2);
          if (iVar4 != iVar3) {
            FUN_140194840(param_1,iVar3,0);
          }
          goto LAB_140194fd4;
        }
        if (iVar3 == 3) {
          if (param_1[0x220] == 0) {
LAB_140194f91:
            iVar3 = (int)param_1[0x165];
          }
          else {
            plVar6 = *(longlong **)(*(longlong *)(param_1[0x220] + 0x58) + 8);
            plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
            uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
            if ((uVar7 >> 0x34 & 1) == 0) goto LAB_140194f91;
            iVar3 = 0;
          }
          if (iVar3 != *piVar8) {
            FUN_140194ac0(param_1);
          }
        }
        else if (iVar3 == 4) {
          if ((int)param_1[5] != *piVar8) {
            *(int *)(param_1 + 5) = *piVar8;
            FUN_140194390(param_1);
            plVar6 = (longlong *)CurrentInstanceGet();
            if ((plVar6 != (longlong *)0x0) &&
               (plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0xb),
               plVar6 != (longlong *)0x0)) {
              lVar5 = *plVar6;
              uVar2 = (**(code **)(*param_1 + 8))(param_1);
              (**(code **)(lVar5 + 0x40))(plVar6,uVar2);
            }
          }
        }
        else if (iVar3 == 5) {
          if (param_1[0x220] == 0) {
LAB_140194ed0:
            iVar3 = (int)param_1[0x247];
          }
          else {
            plVar6 = *(longlong **)(*(longlong *)(param_1[0x220] + 0x58) + 8);
            plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
            uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
            if ((uVar7 >> 0x34 & 1) == 0) goto LAB_140194ed0;
            iVar3 = 0;
          }
          if ((iVar3 != *piVar8) || (param_2 == 3)) {
            FUN_140194940(param_1,*piVar8,0,param_2 == 3);
          }
        }
        else {
          log_InlineLogDBERROR
                    (
                    "CUser::UpdateAdditionBattleEffectFromGS. CROSS_ADDITIONBATTLEEFFECT[%d][%d] is Error"
                    );
        }
LAB_140194fd4:
        iVar9 = iVar9 + 1;
        piVar8 = piVar8 + 2;
      } while (iVar9 < local_ce8);
    }
  }
  return;
}

// ==== CCrossMsgAdditionBattleEffect::ctor_or_dtor  @1403f04c0  [high:vtable-assign]  (orig: FUN_1403f04c0)
undefined8 * FUN_1403f04c0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgAdditionBattleEffect::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgAdditionBattleEffect::ctor_or_dtor  @1403f0510  [high:vtable-assign]  (orig: FUN_1403f0510)
void FUN_1403f0510(undefined8 *param_1)

{
  *param_1 = CCrossMsgAdditionBattleEffect::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgAdditionBattleEffect::vfunc_1  @1403f0540  [high:rtti-vtable]  (orig: FUN_1403f0540)
undefined8 FUN_1403f0540(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgAdditionBattleEffect::ctor_or_dtor  @1403f0680  [high:vtable-assign]  (orig: FUN_1403f0680)
undefined8 * FUN_1403f0680(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgAdditionBattleEffect::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgAdditionBattleEffect::vfunc_3  @1403f06d0  [high:rtti-vtable]  (orig: FUN_1403f06d0)
void FUN_1403f06d0(longlong param_1)

{
  short sVar1;
  undefined2 *puVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  
  sVar1 = **(short **)(param_1 + 0x428);
  if (sVar1 == 0) {
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar5 = (longlong *)FUN_140087650(uVar4);
    lVar3 = (**(code **)(*plVar5 + 0x98))(plVar5,*(undefined4 *)(param_1 + 0x420));
    if (lVar3 == 0) {
      return;
    }
    FUN_14018ad50(lVar3,1,1);
    return;
  }
  if (sVar1 != 1) {
    if (sVar1 == 2) {
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar5 = (longlong *)FUN_140087650(uVar4);
      lVar3 = (**(code **)(*plVar5 + 0x98))(plVar5,*(undefined4 *)(param_1 + 0x420));
      if (lVar3 == 0) {
        return;
      }
      FUN_14018ad50(lVar3,3,1);
      return;
    }
    if (sVar1 != 3) {
      return;
    }
  }
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0xa0))
                    (*(longlong **)(lVar3 + 0x90),*(undefined4 *)(param_1 + 0x420),
                     *(undefined4 *)(param_1 + 0x41c));
  if (lVar3 == 0) {
    return;
  }
  puVar2 = *(undefined2 **)(param_1 + 0x428);
  FUN_140194bc0(lVar3,*puVar2,*(undefined4 *)(puVar2 + 2),puVar2 + 4);
  return;
}

