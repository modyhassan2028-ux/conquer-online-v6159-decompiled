// ==== CMsg91MobileRecharge::ctor_or_dtor  @14045a260  [high:vtable-assign]  (orig: FUN_14045a260)
undefined8 * FUN_14045a260(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsg91MobileRecharge::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsg91MobileRecharge::ctor_or_dtor  @14045a2b0  [high:vtable-assign]  (orig: FUN_14045a2b0)
void FUN_14045a2b0(undefined8 *param_1)

{
  *param_1 = CMsg91MobileRecharge::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsg91MobileRecharge::vfunc_1  @14045a2e0  [high:rtti-vtable]  (orig: FUN_14045a2e0)
ulonglong FUN_14045a2e0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x54b);
}

// ==== CMsg91MobileRecharge::ctor_or_dtor  @14045a310  [high:vtable-assign]  (orig: FUN_14045a310)
undefined8 * FUN_14045a310(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsg91MobileRecharge::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsg91MobileRecharge::vfunc_3  @14045a360  [high:rtti-vtable]  (orig: FUN_14045a360)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14045a360(longlong param_1,longlong param_2)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  if (param_2 != 0) {
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar1 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
    }
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x88))
                       (*(longlong **)(lVar1 + 0x90),param_1);
    if (plVar2 != (longlong *)0x0) {
      lVar1 = plVar2[0x1e2];
      uVar3 = (**(code **)(*plVar2 + 8))(plVar2);
      tq::MyLogSave("gmlog/NDSDKPayments",
                    "receive payments message from client succeed,iduser:[%lu],idacount:[%lu],ServerID:[%lu],Platform:[%lu]"
                    ,uVar3 & 0xffffffff,(int)lVar1);
      (**(code **)(*plVar2 + 8))(plVar2);
      lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar2 = *(longlong **)(lVar1 + 0x80);
      if (plVar2 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMsgPort",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        plVar2 = (longlong *)0x0;
      }
      (**(code **)(*plVar2 + 0x50))(plVar2,2,0x4e35,0xc);
    }
  }
  return;
}

